from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    anthropic_api_key: str = ""
    planner_model: str = "claude-sonnet-4-20250514"
    synthesizer_model: str = "claude-sonnet-4-20250514"

    skills_dir: str = "./skills"
    max_parallel_steps: int = 5
    planner_timeout_seconds: int = 30
    skill_timeout_seconds: int = 120

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
