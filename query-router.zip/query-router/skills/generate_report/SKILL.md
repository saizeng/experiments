---
name: generate_report
description: Generates a formatted PDF or DOCX report from deal data including key metrics, timeline, and risk factors
trigger: when user asks for a report, summary document, deal brief, or formatted output for a deal
parameters:
  - name: deal_id
    type: string
    required: true
    description: The deal identifier to generate a report for
  - name: format
    type: string
    required: false
    default: pdf
    description: Output format — pdf or docx
  - name: sections
    type: list
    required: false
    default: null
    description: Optional list of sections to include (e.g., overview, financials, risks, timeline)
---

# Generate Report

This skill produces a formatted report for a given deal.

## Input

Receives JSON on stdin with:
- `deal_id` — the deal to report on
- `format` — output format (pdf/docx)
- `sections` — optional filter on which sections to include
- `upstream` — data from prior execution steps (e.g., deal details from the structured API)

## Output

Writes JSON to stdout:
```json
{
  "file_path": "/tmp/reports/acme_deal_report.pdf",
  "title": "Acme Corp Acquisition — Deal Report",
  "pages": 12
}
```

## Implementation Notes

The `run.py` script should:
1. Read JSON from stdin
2. Use `upstream` data if available, otherwise call the structured API directly
3. Build the report using your preferred templating engine
4. Write the file and output the result JSON
