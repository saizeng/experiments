"""Client for the structured-data chatbot API."""

from __future__ import annotations

import logging
from typing import Any

import httpx

from app.config import settings

logger = logging.getLogger(__name__)


class StructuredClient:
    """Thin async wrapper around the structured-data chatbot endpoint.

    Adapt the `query` method to match your actual API contract.
    """

    def __init__(self) -> None:
        self._base_url = settings.structured_api_url
        self._headers: dict[str, str] = {}
        if settings.structured_api_key:
            self._headers["Authorization"] = f"Bearer {settings.structured_api_key}"

    async def query(self, question: str, context: dict[str, Any] | None = None) -> str:
        """Send *question* to the structured chatbot and return its answer.

        Parameters
        ----------
        question : str
            Natural-language question routed by the planner.
        context : dict, optional
            Upstream step results injected by the executor (e.g., deal IDs
            from a previous step).
        """
        payload: dict[str, Any] = {"question": question}
        if context:
            payload["context"] = context

        async with httpx.AsyncClient(timeout=settings.executor_timeout_seconds) as client:
            resp = await client.post(
                self._base_url,
                json=payload,
                headers=self._headers,
            )
            resp.raise_for_status()

        data = resp.json()
        # ── Adapt this to your API's response shape ──
        # Common patterns:
        #   data["answer"]
        #   data["response"]
        #   data["choices"][0]["message"]["content"]
        return data.get("answer", data.get("response", str(data)))
