<a id='649468e3-2dc0-46b1-ae41-3ac78c99b569'></a>

Harvard Business School logo
Harvard Business School
NEW
VENTURE
COMPETITION

<a id='1d2eb1e2-2058-4160-a757-fd0563e7b199'></a>

<::logo: [Unidentifiable] 
 A light blue shield with a pattern of crosses and squares, topped with three indistinct shapes.::>

<a id='c7dca299-50f1-4dfd-9e8e-ff45a127dcdc'></a>

Pitch Deck Example

<a id='f03f5687-a74b-4a72-9475-1464e944b6a7'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem to the left of the text, with the word "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='690a14f4-c109-44aa-abd9-0f29ee570be7'></a>

GOAL

<a id='b7d352dc-cebb-4c20-8bb1-d49ffae1113e'></a>

* The goal of your pitch deck is to give a snapshot of your investment opportunity, taking into consideration your impact, growth potential, viability, and the ability of your team to execute your plan.

<a id='1b0dd7f0-2550-431c-acec-af1f88999a7b'></a>

• Think of this as the most compelling elements of your executive summary presented visually and verbally.

<a id='1675d0bd-851d-4635-83eb-f28872e45d19'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='cdb22853-34d2-4b38-aa35-985a110b0516'></a>

Housekeeping

<a id='8ca4388a-e4bf-4217-b366-a3ab82023048'></a>

- Keep in mind that you will be allotted 10 minutes or less to present and may need to adjust the content and number of slides accordingly.

<a id='b72daf40-9b97-4fb8-9ba8-3be11e5778eb'></a>

* Ensure slides are not text or data heavy and use at least a 30pt font.

<a id='a4fd2f38-2cc3-431a-bc06-24625c767c44'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='683f03f2-bb38-4b4a-a485-1a29f0835fe7'></a>

Cover page

<a id='416c9137-7ea7-4726-9e6b-7cb725d551cb'></a>

TAGLINE: Define your
venture with a short
declarative sentence,
getting to the heart of
your venture's unique
advantage.

<a id='d7785ab1-7682-4054-b9bb-305067c65151'></a>

Harvard
Business
School
NEW
VENTURE
COMPETITION

<a id='5242f4b4-f4d4-44ed-a49e-f1a6024a4a3d'></a>

<::logo: Unidentified Company/Organization/Brand
Unreadable text
A light blue shield with an unreadable inscription at the top and a stylized cross pattern with leaves in the main field.:>

<a id='e4d50a21-6f71-44b8-8b2d-c97b01a5b0a8'></a>

DATE:
PRESENTER NAME:

<a id='4fb051da-a59d-4453-9a54-8e0edb019ff3'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, three containing books and one with crossed axes, beside the institution's name in red and black text.::>

<!-- PAGE BREAK -->

<a id='3c98988c-ab27-4e5b-ae37-e26edb92aade'></a>

Problem

<a id='ebc94d67-059d-411f-b3e3-73f9efc12a31'></a>

"The goal is to get everyone nodding and buying in."
- Guy Kawasaki, The Art of the Start

<a id='71e73438-0a0d-4acd-a5c2-d2e592e59855'></a>

* Describe the pain of the customer (or the customer's customer)
* Outline how the customer addresses the issue today and why current solutions don't work.
* Is it costing the customer time, money, frustration...
Define the pain point. ($ amount, time lost, etc.)

<a id='9aae521b-1529-4153-a8ac-a2f4f57e22ce'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='b4db76f7-0d25-4a79-9b5e-66af55082de0'></a>

Solution

<a id='e2e9443d-0fee-4f35-8d91-452450ab50f0'></a>

- Demonstrate your company's value proposition to make the customer's life better
- Provide cases, customer insights, case studies
- Show scalability

<a id='d26fef1f-fe49-49a3-aaae-ac5e6b3959b1'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='1fc18c7a-7a8e-427b-905d-09f0c45d377f'></a>

Market Size/Dynamic

<a id='d10da77f-c5cc-488b-96dc-62db024ded3c'></a>

_"Good analysis will therefore involve careful segmentation of the true addressable market and thoughtful descriptions of how those customers will pay for the solution over time to build up a picture of a realistic market size." - Michael Skok_

<a id='956837c4-3f37-49d3-9aeb-d3ad46229c7c'></a>

* Identify/profile the customer you cater to
* Provide bottoms-up market sizing: the number of potential customers and the price of the product sold into those customers. * The government census data is a good resource for this analysis.

<a id='115261be-0775-4bea-9828-099c649eb63a'></a>

- Changing trends, new technologies, and forces driving this segment

<a id='9872d52a-7f24-47e1-9d07-027899ecdb68'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='d2c82058-98ee-45f9-a14c-428db25401e3'></a>

Competition

<a id='1750a50c-31af-4ed2-ae1b-cd7236dfb169'></a>

* Give a list of direct competitors, substitutes, or those about to emerge
* Why hasn't anyone done this before? What are the barriers to entry that keep someone from doing this and/or what would keep a competitor from imitating your product or entering your market?

<a id='31a294cc-c48b-4ff2-9783-6c451058f24a'></a>

* Highlight your venture's competitive advantages

<a id='36aeedd5-41a2-4787-a5dc-efc1885db619'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='e769c6bc-96af-468d-91b5-63e1aaaa2fdf'></a>

Go-to-Market Strategy

<a id='0d81edef-6e3c-44af-b81b-6dc06df68b55'></a>

Tip: What are you selling?
Who are you selling it to?
How will you reach your target market?
Where will you promote your product?

<a id='14e24856-f8f2-4913-b8ef-5c25b18f7463'></a>

- What is your plan for execution?
- Summarize sales, marketing, and partnership plans

<a id='7fe12c00-2834-492c-bc7f-a862e0fa91fe'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='74c3017c-036a-4222-b8aa-08dcb7f15868'></a>

Product

<a id='31066dcd-bef8-43f1-a0bd-88fc7f04b267'></a>

* Product line-up (form factor, functionality, features, architecture, intellectual property)

<a id='4e870537-7c9b-4f88-94ab-745269f714fb'></a>

* Development roadmap

<a id='d10f7cb3-2343-4f49-b986-b6abcb651741'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four symbols, accompanied by the words "Harvard Business School" in red and black text.::>

<!-- PAGE BREAK -->

<a id='00c71e41-a749-4ba7-92b9-5e8b3d616f8c'></a>

Business Model

<a id='b9318375-a494-4126-86b0-67f15bacd2ac'></a>

"Explain how you make money –who pays you, your channels of distribution, and your gross margins." - Guy Kawasaki, The Art of the Start

<a id='d8f341cb-c43c-47f8-85e0-5cc080e85973'></a>

* Revenue model
* Pricing
* Average account size and/or lifetime value
* Sales & distribution model
* Customer/pipeline list

<a id='d8263a06-923b-43d8-896f-5a7a8ac40207'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='4f15464f-f290-452d-8b59-aaca55d86a2b'></a>

Key Milestones

<a id='45e043d9-227f-4b3f-9cb0-cd79e0dfcd49'></a>

* Outline current milestones achieved and future milestones.
* Customer research
* MVP development
* Product launch
* Beta users
* Market testing
* Marketing role out/CAC

<a id='8e4a86d3-6f6e-413f-bcc3-581549928a45'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='9e756947-26d4-4a28-aa3b-144201f3b834'></a>

Financial Snapshot

<a id='8916cd98-57fb-455e-95e2-feb64f9c0b46'></a>

Tip: "Define assumptions so it's clear that you've developed a realistic model."

*   Provide a 3 year forecast, including annual revenue,
    net income, and key metrics (customers and
    conversion rates).

<a id='a543c2b7-88af-42c3-aa8e-21e88cd37cb9'></a>

- Prepare supplemental information such as
  - Product launch
  - Go-to-market execution
  - Other?

<a id='9177b6e2-546f-4e87-aace-8e5431221668'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='826856d0-6dda-4c7e-aee8-7d50eb3fe651'></a>

Capital Requirements

<a id='658fc7a4-d38b-40a9-8416-02788fe65152'></a>

Tip: How much capital will you need prior to becoming cash flow positive and how will your funds be applied? You need to explain the minimum required equity you need to reach your next key milestone.

<a id='2972dfc6-5063-4fe1-b107-9fa2654f2553'></a>

* Customer research- focus groups, surveys
* MVP development
* Product launch
* Go-to-market execution
* Other?

<a id='d21b5b38-7552-4371-8ebf-7cca75cd85a3'></a>

<::logo: Harvard Business School
Harvard Business School
A shield emblem with a cross pattern and four books is placed to the left of the institution's name in red and black text.::>

<!-- PAGE BREAK -->

<a id='f903cca6-b149-4d8c-b52d-d2d5e3841e36'></a>

Team

<a id='1ea9b653-f1b1-4d76-93ae-7ff6e967c958'></a>

Tip: You need to convey that you are the team to execute this venture!

<a id='acdbfe6a-e29f-41db-9518-04f00f02cb1a'></a>

*   Founders & Management
    *   What key skills or experience that relate to the product or leading of the company
*   Board of Directors/Board of Advisors
    *   Highlight spheres of influence

<a id='79890744-372d-459a-b4d2-59b637b91bb9'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='365b88b0-c8b0-4488-b588-070a105475cd'></a>

Appendix

<a id='88c6df54-e07d-47af-ba91-e1625996fe70'></a>

Additional slides that can be used for follow-up questions.

<a id='946d92a0-fd4a-44c3-99b6-e7a285b793d0'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with three open books above a black cross-like symbol, accompanied by the institution's name in red and black text.::>