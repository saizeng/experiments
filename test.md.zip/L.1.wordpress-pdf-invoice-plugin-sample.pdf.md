<a id='4a357b20-6909-4e69-a8bf-30cbde7dda6f'></a>

<::logo: SlicedInvoices
SlicedInvoices
A pie chart symbol in dark blue and light blue, with the text "SlicedInvoices" next to it in a flowing script font, transitioning from light blue to dark blue.::>

<a id='7e84054e-ad5b-4ced-909b-13823cc49ac7'></a>

Invoice

<a id='3352b576-9f8b-4010-be88-54cd562f0349'></a>

From:
DEMO - Sliced Invoices
Suite 5A-1204
123 Somewhere Street
Your City AZ 12345
admin@slicedinvoices.com

<a id='48bf2625-5b97-4f6d-adf2-a65673c7de1a'></a>

<table id="0-1">
<tr><td id="0-2">Invoice Number</td><td id="0-3">INV-3337</td></tr>
<tr><td id="0-4">Order Number</td><td id="0-5">12345</td></tr>
<tr><td id="0-6">Invoice Date</td><td id="0-7">January 25, 2016</td></tr>
<tr><td id="0-8">Due Date</td><td id="0-9">January 31, 2016</td></tr>
<tr><td id="0-a">Total Due</td><td id="0-b">$93.50</td></tr>
</table>

<a id='4e3ef8db-706b-4402-912f-6ec997e70786'></a>

To:
Test Business
123 Somewhere St
Melbourne, VIC 3000
test@test.com

<a id='488da6eb-edd6-4f5e-801d-18229ac2444c'></a>

<table id="0-c">
<tr><td id="0-d">Hrs/Qty</td><td id="0-e">Service</td><td id="0-f">Rate/Price</td><td id="0-g">Adjust</td><td id="0-h">Sub Total</td></tr>
<tr><td id="0-i">1.00</td><td id="0-j">Web Design This is a sample description...</td><td id="0-k">$85.00</td><td id="0-l">0.00%</td><td id="0-m">$85.00</td></tr>
</table>

<a id='d3c8fc84-9fbe-4ffa-9197-1131fba0a0f2'></a>

<table id="0-n">
<tr><td id="0-o">Sub Total</td><td id="0-p">$85.00</td></tr>
<tr><td id="0-q">Tax</td><td id="0-r">$8.50</td></tr>
<tr><td id="0-s">Total</td><td id="0-t">$93.50</td></tr>
</table>

<a id='a892a233-5b05-4ad6-8282-dc7ea17d2902'></a>

ANZ Bank
ACC # 1234 1234
BSB # 4321 432

<a id='edaea22e-dfb2-4924-9e27-3f29357f27e1'></a>

Payment is due within 30 days from date of invoice. Late payment is subject to fees of 5% per month.
Thanks for choosing DEMO - Sliced Invoices I admin@slicedinvoices.com
Page 1/1