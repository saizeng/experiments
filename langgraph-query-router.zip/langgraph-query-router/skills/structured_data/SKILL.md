---
name: structured_data
description: >
  Chatbot API for structured deal data. Answers questions about deals,
  clients, interactions, revenue, expenses, and wallet.
trigger: >
  when user asks about deal metrics, revenue, expenses, client info,
  interaction history, wallet data, or any quantitative question
category: data_source
parameters:
  - name: query
    type: string
    required: true
    description: Natural-language question for the structured data chatbot
---

# Structured Data Skill

Wraps the structured-data chatbot API (deals, clients, interactions,
revenue, expenses, wallet).
