<a id='2547e96c-dcf0-43f3-a0b1-58914a4d083a'></a>

McKinsey
& Company

<a id='1a89b9a3-cbf7-42c7-903d-a0ac08c4f729'></a>

## Chilean Hydrogen
Pathway

<a id='e133c850-81ec-436b-b5dd-1d6e30020faa'></a>

Final Report

December 2020

<a id='f5bc6901-9f50-4a01-a013-4c301f1f07ba'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company
is strictly prohibited

<!-- PAGE BREAK -->

<a id='6435a1f8-cd6e-43ec-ba61-14d3cb5393bf'></a>

Table of contents

<table><thead><tr><th>Chapter</th><th>Page</th></tr></thead><tbody><tr><td>Chapter 1: State of global Hydrogen industry</td><td>Page 3-28</td></tr><tr><td>Chapter 2: Business case for domestic Hydrogen<br>production and end use application</td><td>Page 29-50</td></tr><tr><td>Chapter 3: Business case for Hydrogen exportation</td><td>Page 51-56</td></tr><tr><td>Chapter 4: Hydrogen industry development targets and<br>roadmap</td><td>Page 57-60</td></tr><tr><td>Chapter 5: Relevant stakeholders for the hydrogen industry</td><td>Page 61-73</td></tr><tr><td>Chapter 6: Government role in hydrogen industry<br>development</td><td>Page 74-83</td></tr></tbody></table>

<a id='ae6a9c88-829d-4008-943d-b455682b992c'></a>

McKinsey & Company

<a id='400ce6b8-ea16-4ac1-a4f6-7d5b8db717c2'></a>

2

<!-- PAGE BREAK -->

<a id='16002e42-4d13-4a16-9564-efb3309f029e'></a>

Chapter 1: State of global Hydrogen industry

<a id='3524aaf1-97b8-4e37-bf9d-a8e6394e15a5'></a>

Chapter content description
- State of the global **Hydrogen industry, including**: production, transportation, distribution and utilization of Hydrogen (specific focus on Green Hydrogen)
- **Development of hydrogen market, including**: hydrogen projects and investment analysis by key market and segment of the hydrogen value chain
- **Roadmaps and strategies for hydrogen development in key markets** including key strategic initiatives, incentive mechanisms and other forms of public support

<a id='58cf52f9-668a-45f2-b562-29e1de469d8c'></a>

Activities included
* Activity 1.1
* Activity 1.2

<a id='259d7d8c-7a95-4414-a336-dbcb0de98cd3'></a>

McKinsey & Company

<a id='3e7f960f-65fa-4403-a66d-c7b0288cedac'></a>

3

<!-- PAGE BREAK -->

<a id='80a3fd25-a66b-454b-ad54-428a9e2b7212'></a>

1.1/ Blue and Green hydrogen are two low-carbon production methods of H2 with the highest future potential

<a id='b0cc33ce-a49a-4cd0-8161-57e0765a7c3f'></a>

<::Oval shape with 'X' inside, indicating CO2 emissions (kg CO2 per kgH2 produced)
: figure::>

<a id='6c6306b8-30b1-43b7-b785-701853e64f5d'></a>

<table><thead><tr><th rowspan="2"></th><th colspan="3">Low-carbon H2</th></tr><tr><th>Grey<br>H2</th><th>Blue<br>H2</th><th>Green<br>H2</th></tr></thead><tbody><tr><td>Production<br>process</td><td>Split<sup>1</sup> natural gas<br>into H2 and CO2<br><br><br>~10</td><td>Similar to Grey but additionally capture,<br>potentially use, and store CO2<br><br>~1-3<br>Most CO2<br>stored</td><td>Split water into H2 and O2 in an electrolyzer that<br>is powered by renewables<br><br>~0<br>Assuming Green<br>electricity mix<sup>2</sup></td></tr><tr><td>Investments<br>and complexity</td><td>Large scale, one-off facilities<br><br>Requiring triple-digit million<br>EURCAPEX per facility<br><br>3-5 years EPC</td><td>Large scale and one-off facilities<br><br>Requiring triple-digit mn EUR CAPEX per facility<br><br>5-10+ years EPC duration, contingent upon<br>development of CO2 storage site</td><td>Small-scale (5-10MW) facilities that can be<br>replicated, similar to utility-scale batteries<sup>3</sup><br><br>Requiring single/double-digit EUR mn CAPEX<br>per facility, expecting 50-70% reduction until 2030<br><br>1-3 years EPC duration</td></tr><tr><td>Direct link to<br>power sector</td><td>&#128489; &#10006;</td><td>&#128489; &#10006;</td><td>&#128489; &#10003;</td></tr></tbody></table>

<a id='d96a704e-0295-4536-b23e-6e2af40734ef'></a>

1. Process: Sulfur Removal, Synthesis Gas Production via Steam-Methane Reforming (SMR) or Auto-Thermal Reforming (ATR), CO Shift Reaction, Purification. The latter is expected to offer higher efficiencies in combination with CCS. In addition, Grey hydrogen can also be produced from coal gasfication.
2. In Australia, producing hydrogen from electrolyzers that run on grid electricity would lead to an emission intensity of ~40 kgCO2/kgH2.
3. Especially PEM electrolyzers can be largely pre-assembled, containerized, and stacked.

<a id='bd218bb7-3d2d-422b-ab72-fe7d527a3a31'></a>

McKinsey & Company

<a id='8ee1dc86-8ab3-4777-bac0-7937196e9e89'></a>

4

<!-- PAGE BREAK -->

<a id='9d1c8069-0a53-4ff0-afff-ce158993ae4e'></a>

## 1.1/ Blue H2 is cheaper today, but Green H2 is the ´new solar´ with costs decreasing rapidly

Global H2 demand and production costs¹

<a id='80353404-9a5d-4830-8ad5-6ad681b221e7'></a>

<::Figure: A legend and a flow diagram illustrating the evolution of hydrogen production methods and associated costs. The legend shows:
option Least-cost option: [x]
option 2nd least-cost option: [ ]

The diagram depicts a transition from Grey H2 to Blue H2 to Green H2 production:
- Grey H2 (grey box)
  - Arrow pointing right with text: High emission prices, falling CCS cost, availability of CO2 use cases and storage sites
- Blue H2 (dark blue box)
  - Arrow pointing right with text: High gas and emission prices, falling electrolyzer and renewables cost
- Green H2 (teal box)
:diagram::>

<::Table: This table presents global hydrogen demand and production costs for Grey, Blue, and Green H2 across different years.

| | Global H2 demand Mt p.a. | Thereof Grey H2 Mt p.a. (Share %) | Thereof Blue+Green H2 Mt p.a. | Production cost Grey H2 $/kg | Blue H2 $/kg | Green H2 $/kg |
|---|---|---|---|---|---|---|
| 2018 | 73 | 73 (100%) | ~0 | ~1.0-2.5 | ~1.5-3.0 | 4.3 |
| 2030 | 110 | 73+X (>70%) | Up to 37 | ~1.0-2.5 | ~1.5-3.0 | 2.0 |
| 2050 | 545 | 73+/-X (<20%) | Up to 472 | " | " | 1.3 |

1. Estimates by Hydrogen Council; Grey H2 production costs assuming natural gas prices of $4-$8/mmBtu; Blue H2 costs assuming Grey costs + $0.5/kg; Green H2 costs assuming IRENA database weighted average solar PV costs (auctions and PPAs) in 2020
:table::>

<a id='ce8bc9ee-1aa2-4c41-bb1c-c80c16404e79'></a>

McKinsey & Company

<a id='bcb410d4-8c93-4cda-b8d7-ddae03c82d35'></a>

5

<!-- PAGE BREAK -->

<a id='daf65842-a688-48be-bd9e-540c9a3c5a92'></a>

1.1/ The Green H2 production relies on carbon-free power generation and electrolyzers which split water H2 and an O2 biproduct

<a id='0dfd3c73-b106-43a8-9a27-5182a236babd'></a>

<::Diagram: Hydrogen Value Chain::>The diagram illustrates the hydrogen value chain, categorized by production type (Blue H2 and Green H2) and segmented into Upstream, Midstream (Logistics and Trading), and Downstream stages. The top row outlines the process for Blue H2, and the bottom row for Green H2. The Midstream and Downstream stages are common to both Blue and Green H2, with some distinctions in the downstream applications for existing (Grey H2) vs. new (decarbonization) segments.nn**Upstream (incl. CAO¹)**nn**Blue H2:**n- **Natural gas exploration and transport:** Depicted by an oil rig, a gas flare, and a valve system.n- **SMR/ATR (Steam Methane Reforming/Auto Thermal Reforming):** Represented by a factory icon. Byproducts: Sulfur, CO, CO2, steam, heat.n- **CO2 Sequestration & Storage:** Shown with a CO2 cloud and a valve system.nn**Green H2:**n- **Carbon-free power generation³:** Illustrated with icons for a nuclear power plant, solar panels, a wind turbine, and a hydroelectric dam.n- **Electrolyzer:** Represented by an electrolyzer unit. Byproduct: O2.nn**Midstream (Logistics and Trading)**nThis section is common for both Blue and Green H2:
- **H2 compression:** Depicted by a pressure gauge icon.
- **Trucking:** Shown with a tanker truck icon.
- **Fueling infrastructure:** Represented by a gas station icon.
- **H2 intermediary storage:** Illustrated by a storage tank icon.
- **H2 grid or blending into gas network:** Depicted by a valve system.
- **Shipping (liquid H2):** Shown with a ship icon.nn**Downstream**nn**Existing segment: Using Grey H2:**
- **Selling H2 as industrial feedstock²:** Represented by a factory with a tank.nn**New segments: Potential use of H2 to decarbonize:**
- **Selling H2 to transport industry:** Illustrated with icons for a car, a truck, an airplane, and a ship.
- **Selling H2 to industry for industrial heat processes:** Represented by a factory icon.
- **Selling H2 to heat and power homes²:** Shown with a house icon.
- **Selling/using H2 to fuel gas plants:** Depicted by a power plant icon.::>

<a id='e8ed215a-552c-49fe-b153-7e3e5107807f'></a>

1. Commercial Asset Optimization
2. Refining, ammonia, methanol, olefin, steel 2 Blending H2 in natural gas networks or dedicated H2 networks 3 Water electrolysis based on "grey" electricity mixes may result in "fake-green" H2 with higher emissions than Grey H2

---

<a id='3cfc994b-080b-4326-8fb4-c453afdb0124'></a>

McKinsey & Company

<a id='49c876a1-ffcc-4828-8cfc-380c5dc8c8ec'></a>

12

<!-- PAGE BREAK -->

<a id='03c24464-b210-4353-9561-4da41878bc32'></a>

1.1 / Hydrogen's value chain is decomposed into production ('green'
or not), handling and final use (across several verticals)

<a id='8afd12e5-79a0-41a0-a4cd-fd60f835a413'></a>

<::Flowchart showing a three-step process::>
Production (techniques)¹
Handling (steps)
Final use

1. Hydrogen produced r
<::

<a id='dc16ccc5-39c7-439a-9bae-a7524a568036'></a>

**Reforming/ gasification of fossil feedstock**
100%+ of current production. Natural gas, oil, coal or biogas is used to get hydrogen:
* Steam methane reforming (SMR)
* Petroliquids or coal gasification
Can be associated to a carbon capture & storage facility to make H2 production more sustainable

<a id='9c85cdc5-4128-4349-9319-02948f5de5fc'></a>

## Electrolysis
Splitting of water to get hydrogen, using renewable or fossil fuel-based energy.
*   2 power sources: on-site or from the grid
*   3 main technologies: alkaline (most mature), PEM¹ (increasing interest) and high-temperature splitting (nascent)

<a id='8961b5aa-f6d9-4513-9829-ccecd98687a3'></a>

**Other techniques**
Other (nascent) techniques to produce hydrogen include:
* Biomass gasification
* Biological / Bacterial production
* Direct solar water splitting

<a id='e9cd607b-4b9b-4167-b260-937d5c241e27'></a>

**Storage**

Storage of hydrogen or hydrogen-based fuels & feedstock

*   For short duration & small volumes, storing in tanks and / or solid materials
*   For longer duration & large volumes, storing in salt caverns, depleted gas wells or aquifers

<a id='68f6feda-7f9f-464b-af04-5415482f34c5'></a>

## Transmission
Transmission of hydrogen for long distances / large flows
* Can involve pipelines (H₂ or methane), rail transport, ships and / or trucks
* Can transport hydrogen in a gaseous or liquid form, or transport liquid organic H₂ carriers

<a id='244209f7-4062-42a0-ab85-74196ff1b706'></a>

# Distribution
Transmission of hydrogen for shorter distances to the final user
* Can involve pipelines and / or trucks
* Can transport hydrogen in a gaseous or liquid form, or transport liquid organic H₂ carriers

<a id='56b38e8f-c17c-4710-bcb7-9e54bae5d3ea'></a>

<::Infographic presenting five categories, each with an icon and a bulleted list of items:
- Power storage & generation (icon: wind turbine)
  - Battery storage / Buffer
  - Power generation
- Transport (icon: car)
  - Cars
  - Vans / Minibuses
  - Trucks
  - Ships & Planes
  - Forklifts
  - Trains & Trams
- Industry feedstock (icon: factory building)
  - Oil refining
  - Ammonia / Methanol production
  - Steel (iron ore reduction)
- Industrial energy (icon: factory building)
  - Low industry heat
  - Medium industry heat
  - High industry heat
- Building heat and power (icon: house)
  - Heating
  - Onsite power generation
: infographic::>

<a id='72b5bc80-dd60-4e0d-b18e-cf524116a95e'></a>

1. Hydrogen produced may then be transformed to hydrogen carriers (ammonia, methanol, etc.)
2. Polymer electrolyte membrane

<a id='124a58ea-ed65-4a97-9eb8-479e4cfcbd4d'></a>

Source: IEA 2019; McKinsey analysis

<a id='ab6cc12e-fea9-4978-ad2d-4a34a140c20d'></a>

McKinsey & Company

<a id='8f6e2113-3965-4a83-afa1-f69496e5681a'></a>

7

<!-- PAGE BREAK -->

<a id='430cd976-f3a3-4d1a-93a4-e438621c9890'></a>

1.1 / Since 2018, the hydrogen industry has been experiencing unprecedented momentum

<a id='598f8f14-8bac-4fef-a4ea-403ed4e7f19b'></a>

Not Exhaustive Hydrogen Categories: Transportation (dark blue), Industrial energy (light blue), Building heat (darker blue), Power generation/storage (cyan), Overarching (dark grey), Hydrogen Production (light grey), Hydrogen Infrastructure (grey)

<::timeline:
Year: 2018
- Jan 18 (Overarching): Foundation of Japan H2 Mobility
- Mar 5 (Transportation): FCEV taxi fleet in Paris expanded to 100 FCEVs
- Mar 29 (Hydrogen Infrastructure): Hydrogen roadmap for the Netherlands
- May 2 (Hydrogen Production): Shell and ITM Power agree to build then world's largest electrolysis plant (10 MW) in Germany
- May 14 (Hydrogen Production): NEL announces to build world's largest electrolyzer production plant (360 MW/year) in early 2020
- Jun 24 (Transportation): Siemens and PowerCell announce development of fuel cells for ships
- Jul 25 (Transportation): First hydrogen train starts operating in Germany
- Aug 14 (Overarching): Hydrogen Council expands to 53 members
- Aug 22 (Power generation/storage): ITM Power gets funding to explore 100 MW power-to-gas storage project
- Aug 29 (Transportation): Hyundai announces supply of 1,000 hydrogen fuel cell lorries to Swiss H2 Energy
- Sep 5 (Overarching): Northeast of the US announces start of HRS roll-out
- Sep 17 (Transportation): Hyundai announces FCEV Vision 2030: 7bn USD invest, 700,000 units by 2030
- Sep 27 (Overarching): tk announces carbon-neutrality by 2050, $10bn EUR investments
- Sep 28 (Hydrogen Production): RWE and Innogy announce plans for 100 MW electrolyzer in Netherlands
- Oct 3 (Power generation/storage): 100 MW power-to-gas project by Gasunie, Tennet and Thyssengas starting 2022
- Oct 10 (Overarching): Air Liquide acquires ~20% of Hydrogenics
- Oct 12 (Transportation): Ship-maker CMB announces several hydrogen investments
- Oct 16 (Transportation): Bosch and Hanwa invest over $230m in Nikola
- Oct 22 (Overarching): EDF launches subsidiary to develop hydrogen solutions for industry
- Nov 12 (Transportation): Chinese plans to build hydrogen infrastructure for ~50k FCEVs by 2025
- Dec 12 (Transportation): Toyota aims for 30k FCEV sales per year after 2020 - build two new fuel cell facilities

Year: 2019
- Jan 25 (Overarching): French strategy plan: France as a leader in hydrogen technology
- Feb 5 (Power generation/storage): Yara and Engie to build 20 MW green hydrogen plant
- Feb 18 (Overarching): IEA launches hydrogen report with major reversal of their perspective, report endorsed by G20 energy ministers
- Mar 15 (Hydrogen Production): Linde announces quadrupling of hydrogen and syngas capacity at $1.9b Jurong Island complex
- Apr 8 (Transportation): CNH announces $250m investment in Nikola and JV for hydrogen truck production
- Jun 19 (Overarching): Engie's power-to-gas demo project starts injection of 6% hydrogen in the gas grid, rising to 20%
- Jun 29 (Transportation): Announcement of a test flight of ZeroAvia hydrogen-powered six-seater airplane
- Aug 19 (Overarching): Chinese Weichai strategically invests USD 163m in Ballard
- Aug 27 (Overarching): VW and Stanford University announces significant reduction in platinum use for fuel cells
- Sep 3 (Transportation): Hyundai announces to sell 5,000 FCEVs to France by 2025
- Sep 5 (Hydrogen Production): AirLiquide and Linde announce expansion of liquid H2 production in US
- Undated (below Aug 19): EU energy ministers announce joint hydrogen R&D
- Undated (below Aug 27): New "H2Bus Europe" funding program for 600 fuel cell buses (EUR 40m)
- Undated (below Sep 3): Australian Renewable Energy Agency announces 2-year trial injecting green hydrogen into Sydney's gas grid
- Undated (below Sep 5): China beats FCEV target of 2020 in 2018, on track to become largest fuel cell market
- Undated (below Sep 5): Orsted includes H2 in Dutch offshore auction
- Undated (below Sep 5): Cummins acquires Hydrogenics
::>

Key trends in 2019
Acceleration of momentum as decarbonization commitments become more important
New segments growing, e.g. trucks, trains, ships, synfuel
Push from utilities, renewable developers and oil & gas companies
Large-scale projects with water electrolysis, mostly for use in industry (fertilizers, refining)

<a id='0bc601bd-536a-4429-b89a-d9a4bcd58b0e'></a>

Source: Press releases; McKinsey

<a id='f640513b-dcda-4e17-bf56-531a9573d678'></a>

McKinsey & Company

<a id='ff5f5daf-437c-4f82-9f2f-d78e7006cb89'></a>

8

<!-- PAGE BREAK -->

<a id='4e8beede-70ff-4119-a57b-fcc1ceeda7f0'></a>

**1.1 / Investment has been led by large industrials teaming up for large flagship projects – to reach technological and commercial maturity**

---

<a id='7ceb2d94-3df8-4bdf-bf73-8597b1544755'></a>

<::World map illustrating various hydrogen projects and their associated companies and locations.: map::>

**100 MW Power-to-Gas** (Germany flag)
- amprion
- Open Grid Europe

**Falkenhagen** (Germany flag)
- uniper

**H2 FC trucks** (USA flag)
- KENWORTH
- UPS
- TOYOTA
- Air Liquide (logo)
- Shell (logo)

**Hynet and H21 heating UK** (UK flag)
- JM Johnson Matthey
- Northern Gas Networks
- equinor
- Cadent
- Progressive energy

**Offshore hydrogen** (Belgium flag)
- Orsted

**Westküste** (Germany flag)
- Orsted
- Open Grid Europe
- The Gas Wheel
- Holcim
- thyssenkrupp
- RAFFINERIE HEIDE
- EDF

**Magnum H2 power plant** (Netherlands flag)
- VATTENFALL
- Gasunie
- equinor

**Northern lights** (Norway flag, Denmark flag)
- equinor
- Shell (logo)
- TOTAL

**Hybrit - Steel CO2 free** (Sweden flag)
- SSAB
- LKAB
- VATTENFALL

**H2 FC trains** (France flag)
- THE LINDE GROUP
- ALSTOM
- LNVG

**Centurion – Cavern – energy flexibility** (Germany flag)
- Cadent
- inovyn
- storengy

**Rhineland refinery** (Germany flag)
- Shell (logo)
- ITM POWER

**Green steel voestalpine** (Austria flag)
- SIEMENS

**H2 FC trucks fleet** (Germany flag)
- Shell (logo)
- Air Liquide (logo)

**H2 Mobility Korea** (South Korea flag)
- Air Liquide (logo)
- nel
- HYUNDAI
- KOGAS
- HONDA

**H2 Mobility Japan** (Japan flag)
- Air Liquide (logo)
- Iwatani
- JAPAN H: MOBILITY (JHyM)
- JXTG Nippon Oil & Energy

**LH2 supply chain** (Japan flag, Oman flag)
- Iwatani
- Kawasaki
- Marubeni
- Shell (logo)

**20 MW green H2 production for ammonia** (Australia flag, Netherlands flag)
- YARA
- ENGIE

<a id='4a63cf4f-1b4b-4ebf-b841-65ccab7f1be4'></a>

Source: Press releases; McKinsey

<a id='b278a5f0-d9b4-4627-a463-67f5975ce8d2'></a>

McKinsey & Company

<a id='db7e825c-a79a-45d5-9abd-4147199c92c7'></a>

9

<!-- PAGE BREAK -->

<a id='25d72678-4426-4517-9ca3-7a3023a9e064'></a>

1.1 / Global green H2 production capacities are limited, but expected to increase significantly with ~9.5 GW announced until 2025

<a id='77844514-9243-4259-a3c7-a247337531d0'></a>

Selected project examples Global electrolysis project announcements, GW
<::Bar chart showing global electrolysis project announcements by year (2015-2025) and cumulative capacity in GW, broken down by region. The Y-axis ranges from 0 to 10 GW. The X-axis represents years from 2015 to 2025. Below the cumulative bars, individual project announcements are listed with their capacity, company, and country flag.

Legend:
- Asia Pacific (black)
- Europe (light blue)
- Middle East (dark blue)
- North America (light teal)
- Africa (dark teal)
- Latin America (purple)

Individual Project Announcements:
- 2016:
  - BJE (Beijing Jingneng Clean Energy Co., Limited): 5 GW, China flag (Asia Pacific)
  - NEOEN: 0.05 GW, Australian flag (Asia Pacific)
- 2017:
  - YARA: 0.06 GW, Australian flag (Asia Pacific)
  - ENGIE: No GW specified, Australian flag (Asia Pacific)
- 2018:
  - H2V: 0.5 GW, French flag (Europe)
- 2019:
  - Thyssengas, Tennet, Gasunie: 0.1 GW, German flag (Europe)
- 2020:
  - Amprion, Open Grid Europe, The Gas Wheel: 0.1 GW, German flag (Europe)
- 2022:
  - DEME: 0.5 GW, Oman flag (Middle East)
- 2023:
  - NEOM: 2 GW, Saudi Arabia flag (Middle East)
  - Nouryon, BP, Port of Rotterdam: 0.25 GW, Netherlands flag (Europe)
  - Unknown project (?3): 0.5 GW, German flag (Europe)

Cumulative Capacity Stacked Bars:
- 2021: Primarily Middle East (dark blue) and Europe (light blue) with small contributions from other regions.
- 2022: Growth in Middle East and Europe.
- 2023: Significant growth, predominantly Middle East and Europe.
- 2024: Continued growth.
- 2025: Highest cumulative capacity, with Middle East and Europe being the largest contributors, followed by Asia Pacific and Africa.: chart::>

<a id='9435e8c0-1d3b-45dd-900a-b883e5cba423'></a>

1. Plant assumed to be constructed over 5 years
2. Various plants announced to be constructed until 2025
3. Government announcements, most likely allocated through tenders/auction

<a id='70ba36c9-2c90-4b60-b6b5-06ad11bee008'></a>

Source: IEA, Press research, McKinsey

<a id='25dd9772-eee2-4d7f-a6e5-36c5f1cd815f'></a>

McKinsey & Company

<a id='d2e56297-9a55-42b2-8725-6c7b619dacd9'></a>

13

<!-- PAGE BREAK -->

<a id='586c50b1-cb8f-4286-bb5e-4e9d593ca15d'></a>

1.2 / Countries have establish hydrogen roadmaps with different levels of detail on key issues for the promotion of the industry

---

option Detailed next: [ ]
option Mentioned but not detailed: [x]
option Considered in detail: [x]

PRELIMINARY | NOT EXHAUSTIVE

<a id='85575883-46e4-4bb2-b12c-5959d7e2bab6'></a>

<::Table: Hydrogen Economy Indicators by Country/Region::>
| Indicators | European Union | Netherlands | Germany | South Korea | Australia | Chile |
|---|---|---|---|---|---|---|
| H2 production projection (Mton) | 1Mton by 2024<br>10Mton to 2040 | NA | NA | 0.5 Mton to 2022<br>5 Mton to 2040 | NA | 11M 2040 |
| Installed electrolysis Capacity | 6GW by 2024<br>40GW by 2030 | 0.5 GW by 2025<br>3-4GW by 2030 | 5GW by 2030<br>10GW by 2035/40 | NA | NA | 5 GW 2025<br>25GW 2030 |
| Investment | 180-470 EUR B by 2050 | NA | 9 EUR B to boost h2 demand | 2.3 USD B to 2022 for the H2 vehicle industry | NA | 45 USD b 2030<br>+300 USD b 2050 |
<::/Table::>

<a id='f277e4ac-659e-4132-b258-eeaa895c7ef4'></a>

<::Table: Checkmark grid for various domains
| Domains |   |   |   |   |   |   |
| :-------------------------- | :- | :- | :- | :- | :- | :- |
| 1 Vision and targets        | option : [x] | option : [x] | option : [x] | option : [x] | option : [ ] | option : [x] |
| 2 Regulation and licensing  | option : [x] | option : [x] | option : [ ] | option : [x] | option : [ ] | option : [x] |
| 3 Coordination and partnerships | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] |
| 4 Financing and incentives  | option : [ ] | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] |
| 5 Infrastructure            | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] | option : [ ] |
| 6 Research & Development    | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] |
| 7 Skilled Labor             | option : [ ] | option : [x] | option : [ ] | option : [x] | option : [ ] | option : [ ] |
: Table::>

<a id='16a0b536-9ba7-4e5d-ab12-ddc5aa0369b0'></a>

McKinsey & Company

<a id='5da2015a-982a-4b88-a183-149455566205'></a>

11

<!-- PAGE BREAK -->

<a id='2ab3a937-8a06-4766-be4d-2edc663696b8'></a>

1.2 / The EU Hydrogen Strategy For a Climate Neutral Europe

<a id='cfb7d391-e878-4515-9b18-0bd7d14704c0'></a>

# General approach
The EU has agreed on its **EU Hydrogen strategy** as a **roadmap** to build up a large-scale **green hydrogen industry**

<a id='6975b480-ec25-45c9-bbd9-30596020d583'></a>

The roadmap is divided into **3**
**phases** until 2050 that aim at
reaching **increasing levels** of
**maturity** for the H₂ market

<a id='f798ebb1-5342-4b09-b358-f12be2c9468d'></a>

The strategy explores how green hydrogen can help reducing the **EU**
**economy's carbon emissions** in a
**cost-effective way**

It is in line with the **EU's goal** to be
**climate-neutral by 2050**

<a id='6a254a63-5694-4458-8b5a-717eddf238e8'></a>

<::Cumulative investment needs in Europe, EUR bn. The chart shows two bars:
- Bar 1 (2025-30): 24-42
- Bar 2 (2030-50): 180-470
: bar chart::>

<a id='65be2fb9-eedd-4a8e-8700-8173c3bec8d0'></a>

## Overview of key action areas

Vision & targets
Build a concrete **project pipeline** by end of 2020
Develop an **investment agenda** and support further **strategic investments**

<a id='7bd7e597-8fd9-43a5-b0d1-8dbf173e50df'></a>

Coordination
and partnership

Strengthen **EU leadership** internationally
Start cooperation with **Southern and Eastern**
**Neighborhood** partners, **Energy Community**
countries, and the **African Union**

<a id='d4bad9a3-89f4-494e-84a5-9ff0afe69d14'></a>

Financing and
Incentives

Explore **support policies** to increase demand
Implement **EU-wide criteria** for low-carbon H₂ **certification** and introduce a **common threshold**
Develop a pilot scheme for a Carbon CfD² program

<a id='cd6e4ad7-74dc-4aba-a83b-597582450850'></a>

Infrastructure
Build up **infrastructure** for fueling and transport
Design **market rules** to ensure **liquid markets** and
to remove **barriers** for repurposing gas
**infrastructure**
---

<a id='99b8f491-711f-4175-af6a-49b441333270'></a>

**R&D**
Develop **pilot projects** that test full **value chains**
Facilitate **demonstration** of H₂-based technologies

<a id='e22418cc-1979-40cb-a8fe-201ca754d0fa'></a>

11. Contracts for Difference
---
Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='368f5a8d-5793-42b4-99f0-d26acf39fc2e'></a>

<::logo: [European Union] [] [A blue rectangular flag with a circle of twelve yellow stars in the center.]::>

<a id='3bd4c8af-edad-4452-ba8d-f20f9f44f0f1'></a>

NOT EXHAUSTIVE

<a id='266f64c2-b193-4eee-a5be-dbc7877c00be'></a>

Key commitments and targets

6 GW Of installed electrolysis capacity by 2024

<a id='483a8e6d-ffcc-4bc4-af77-f22ce94d46e4'></a>

40 GW Of installed electrolysis capacity by 2030

<a id='ac8cb4df-3ddc-4683-a77c-307954d6a8e3'></a>

<::Green hydrogen production targets, Million tons: bar chart::>  
This bar chart illustrates green hydrogen production targets in million tons for two different years.  
- **2024**: The target is 1 million tons.  
- **2030**: The target is 10 million tons.

<a id='dba59bea-9229-46e9-af73-548322be2112'></a>

McKinsey & Company

<a id='c70f088b-1ea7-439a-a53a-2ddc7b33c517'></a>

12

<!-- PAGE BREAK -->

<a id='2e5d35d5-54f2-4714-a6d6-1943aa0c0874'></a>

1.2 / The EU's Hydrogen Strategy aims at achieving a renewable hydrogen mass market based on a 3-phase-roadmap

<a id='d1579a77-476b-45a3-957a-71af4c7b2ca5'></a>

<::logo: European Union
A blue rectangular flag with twelve yellow stars arranged in a circle in the center.:>

<a id='3635e7e7-def2-40c8-91b4-48164eb238e2'></a>

<::Timeline of hydrogen strategy phases and objectives:chart::>
Related amount of green hydrogen production in the EU, million tons

Phase 1: 2020-2024
Objective: Market launch – Decarbonize existing hydrogen production and facilitating take up of hydrogen consumption in new end-uses

Phase 2: 2025-2030
Objective: Scale up – Expand production and end-use to additional sectors to develop hydrogen as intrinsic part of an integrated energy system

Phase 3: 2030-2050
Objective: Mass market – Deploy renewable hydrogen at large scale to reach all relevant hard-to-decarbonize sectors
<::Bar chart showing Electrolysis capacity targets (GW) per phase:chart::>
Electrolysis capacity targets, GW

Phase 1 (2020-2024): 6 GW (labeled with a circled '1')
Phase 2 (2025-2030): 40 GW (labeled with a circled '10')
Phase 3 (2030-2050): Target indicated by a bar with a dashed outline and a '?' above it

Infrastructure
roadmap
Mostly local on-site supply combined with selective gas blending and build-out start of comprehensive refueling infrastructure¹
Planning of medium range and backbone transmission infrastructure
Expansion to regional hydrogen clusters with transport over short distances also through dedicated hydrogen pipelines
Need for an EU-wide logistical infrastructure to emerge
400 additional refueling stations (no year specified)
Expansion to EU-wide hydrogen infrastructure and hydrogen trading with non-EU partners

Targeted end-use
sectors²
Transport (buses, trucks)
Heavy industries (refineries, steel, chemicals)
Transport (rail, selected maritime, others)
Heating (residential, commercial)
Power system flexibility (storage, backup, buffering)
Transport (aviation, long distance maritime)
Synthetic fuels production

Selected support
schemes
Revision of the ETS and potentially a carbon border adjustment mechanism
Carbon contracts for difference³, competitive tenders and quotas for end-use sectors
The upcoming Sustainable and Smart Mobility Strategy adds further support for transport uses
No dedicated support schemes stated for
Phase 3 as hydrogen mass market expected to
carry itself

<a id='984b586c-99bb-4188-b39d-5cadd3c77d8f'></a>

1. Refueling infrastructure build-out to continue across phases in line with increase in demand for transport applications
2. From phase 2 targeted end-use sectors refers to additions to the sectors mentioned in the previous phase(s)
3. Scheme potentially to be applied within replacement of existing hydrogen production in refineries and fertilizer production, low carbon and circular steel or maritime and aviation applications
4. Focus on hydrogen production capacities

<a id='b1f84523-0769-40cb-9de8-c4724aae52f8'></a>

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='1a77e382-3fb5-4476-ba88-f9467a1b6cbd'></a>

McKinsey & Company

<a id='aa428a66-c460-4e9f-8cef-70b31b27949b'></a>

13

<!-- PAGE BREAK -->

<a id='760449c0-6968-4e94-9981-f34b34dc40ac'></a>

1.2 / Key actions in the EU's Hydrogen Strategy for a climate-neutral Europe – Enabling environment

<a id='c7f758c5-84f4-4a75-ab4f-c538692f379a'></a>

NOT EXHAUSTIVE

<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and targets</td><td>Introducing a roadmap to 2050 for a hydrogen ecosystem</td><td>Establish a clear vision on **hydrogen production targets and deployment timeline**, as well the most relevant end-use sectors per phase<br>Introduce actions around **5 key dimensions**: develop an investment agenda, boost demand an scale up production, design an enabling framework, promote research and innovation, strengthen the international dimension<br>Provide a broad forum to coordinate investment by all stakeholders and engage civil society, through sector-based round tables and a policy-makers' platform, supervised by the European Clean Hydrogen Alliance</td></tr><tr><td>Regulation and licensing</td><td>Designing and enabling market rules</td><td>Design enabling **market rules for the deployment of hydrogen**, including removing barriers for efficient hydrogen infrastructure development (e.g. via repurposing), and ensure access to **liquid markets for hydrogen producers and customers** and the integrity of the internal gas market, through the upcoming legislative reviews (e.g. review of the gas legislation for competitive decarbonized gas markets) (2021)<br>Develop third-party access rules, **clear rules** on connecting electrolyzers to the grid and **streamlining of permitting** and administrative hurdles to reduce undue burden to market access<br>Work to introduce a **comprehensive terminology** and European-wide criteria for the **certification** of renewable and low-carbon hydrogen (by June 2021)<br>Propose measures to facilitate the use of hydrogen and its derivatives in the transport sector in the Commission's upcoming **Sustainable and Smart Mobility Strategy**, and in related policy initiatives (2020)</td></tr></tbody></table>

<a id='9693aa07-5eba-4ae3-b569-d76274ebc813'></a>

Coordination
and
partnerships

Reinforcing EU
leadership in
technical standards
and regulations

Strengthen EU leadership in **international technical standards, regulations and definitions** on hydrogen

Develop the **hydrogen mission** within the next mandate of Mission Innovation (MI2)

Promote cooperation with **Southern and Eastern Neighborhood partners and Energy Community countries, notably Ukraine** on renewable
electricity and hydrogen

Set out a **cooperation process on renewable hydrogen with the African Union** in the framework of the Africa-Europe Green Energy Initiative

Develop a **benchmark for euro denominated transactions** by 2021

<a id='4778eb16-369f-425a-837b-5202a8be7d59'></a>

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='23d3699d-de0b-41f4-b2bd-6d6ab4aefe49'></a>

McKinsey & Company

<a id='f73d8a38-8c69-422e-9d79-0d44fce02d64'></a>

14

<!-- PAGE BREAK -->

<a id='373fcd7f-e809-499a-967d-224402b15243'></a>

1.2 / Key actions in the EU's Hydrogen Strategy for a climate-neutral Europe – Investments and incentives

<a id='3f92055d-941d-43f3-b2d7-07fdfed5251e'></a>

<::logo: [European Union]
[No text]
A blue rectangular flag with a circle of twelve yellow stars in the center.::>

<a id='9792c9d0-e154-4df9-9a70-7c90dc857eb1'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Developing an<br>investment agenda<br>for the EU</td><td>Through the European Clean Hydrogen Alliance, develop an investment agenda to stimulate the roll out of production and use of hydrogen and<br>build a concrete pipeline of projects (by end of 2020)<br>Support strategic investments in clean hydrogen in the context of the Commission's recovery plan, in particular through the Strategic European<br>Investment Window of InvestEU (from 2021)<br>Explore additional support measures, including demand-side policies in end-use sectors and a carbon Contracts for Difference program</td></tr></tbody></table>

<a id='d3042f9e-8bb3-42aa-85f1-fc39c1afab47'></a>

Infrastructure
Designing a
framework for
infrastructure

<::transcription of the content
: icon::>

Start the planning of hydrogen infrastructure, including in the Trans-European Networks for Energy and Transport and the Ten-Year Network Development Plans (TYNDPs) (2021) taking into account also the planning of a network of refueling stations
Accelerate the deployment of different refueling infrastructure in the revision of the Alternative Fuels Infrastructure Directive and the revision of the Regulation on the Trans-European Transport Network (2021)

<a id='c6a9a85e-1c75-4c5f-86f3-1fa0226b34da'></a>

<table><thead><tr><th>R&D</th><th></th></tr></thead><tbody><tr><td>Promoting research<br>and innovation in<br>hydrogen<br>technologies</td><td>Launch a 100 MW electrolyzer and a Green Airports and Ports call for proposals as part of the European Green Deal call under Horizon 2020<br>(Q3 2020)</td></tr><tr><td></td><td>Establish the proposed Clean Hydrogen Partnership, focusing on renewable hydrogen production, storage, transport, distribution and key<br>components for priority end-uses of clean hydrogen at a competitive price (2021)</td></tr><tr><td></td><td>Steer the development of key pilot projects that support Hydrogen value chains, in coordination with the SET Plan (from 2020 onwards)</td></tr><tr><td></td><td>Facilitate the demonstration of innovative hydrogen-based technologies through the launch of calls for proposals under the ETS Innovation Fund<br>(first call launched in July 2020)</td></tr><tr><td></td><td>Launch a call for pilot action on interregional innovation under cohesion policy on Hydrogen Technologies in carbon-intensive regions (2020)</td></tr></tbody></table>

<a id='db60c8c5-4e95-43b9-9c47-7039baba8c8e'></a>

Skilled labor
<::line drawing of a person wearing a graduation cap: icon::>
N/A

<a id='f89182d9-6710-48a8-b78b-693d16b32451'></a>

Support the needed adjustments in upskilling and in the labor market through the **European Clean Hydrogen Alliance**

<a id='d768f47d-b58c-4239-8c9d-f4874e36697c'></a>

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='ef3b41d5-b166-4436-b71a-6b0412fae865'></a>

McKinsey & Company

<a id='5d152266-511f-4f88-97be-566eac526668'></a>

15

<!-- PAGE BREAK -->

<a id='f4795033-0d09-4edd-9cff-25abbc3bdc74'></a>

1.2 / The EU supports hydrogen innovation, demonstration and scale up through different instruments

<a id='9604b3b9-00d3-4ac6-885f-be00313e279b'></a>

<::logo: [European Union] 
A blue rectangular flag with a circle of twelve yellow stars in the center.::>

<a id='4c56a0f2-7e83-48ef-be82-533991b1d4c1'></a>

**Main relevant examples**

---

EU Funding Financial instruments with risk sharing component Loans Technical Assistance

<a id='322c8bc8-535c-4171-8c5c-116e7893843a'></a>

<table id="15-1">
<tr><td id="15-2"></td><td id="15-3"></td><td id="15-4">Pre-commercial development</td><td id="15-5">Uptake, market ready, roll-out</td></tr>
<tr><td id="15-6">Funding sources</td><td id="15-7"></td><td id="15-8">Proof of concept → Pilot → Demonstration</td><td id="15-9">→ Scale up → Roll out</td></tr>
<tr><td id="15-a">EU</td><td id="15-b">Horizon Europe</td><td id="15-c" colspan="2">long arrow pointing right</td></tr>
<tr><td id="15-d"></td><td id="15-e">Connecting Europe Facility (CEF)</td><td id="15-f"></td><td id="15-g">horizontal arrow</td></tr>
<tr><td id="15-h"></td><td id="15-i">LIFE Programme</td><td id="15-j" colspan="2">horizontal arrow pointing right</td></tr>
<tr><td id="15-k"></td><td id="15-l">Innovation Fund</td><td id="15-m">horizontal line</td><td id="15-n">arrow pointing right</td></tr>
<tr><td id="15-o"></td><td id="15-p">InvestEU</td><td id="15-q">horizontal line</td><td id="15-r">arrow pointing right</td></tr>
<tr><td id="15-s"></td><td id="15-t">InnovFin</td><td id="15-u">horizontal line</td><td id="15-v">arrow pointing right</td></tr>
<tr><td id="15-w"></td><td id="15-x">EIB Loans</td><td id="15-y">horizontal line</td><td id="15-z">arrow pointing right</td></tr>
<tr><td id="15-A"></td><td id="15-B">EIB Advisory Hub (EIAH)</td><td id="15-C">horizontal line</td><td id="15-D">arrow pointing right</td></tr>
<tr><td id="15-E">Hybrid, blending EU and national funding</td><td id="15-F">European Structural and Investment Funds (ESIF)</td><td id="15-G">(horizontal arrow)</td><td id="15-H">(horizontal arrow)</td></tr>
<tr><td id="15-I">National Funding on the basis of a European plan</td><td id="15-J">Important Projects of Common Interests (IPCEI)</td><td id="15-K">(horizontal arrow)</td><td id="15-L">(horizontal arrow)</td></tr>
</table>

<a id='9544632b-2740-43bd-a366-450f733c51ce'></a>

McKinsey & Company

<a id='e3cd4884-f914-45f8-aa12-e8230ac55ce6'></a>

16

<!-- PAGE BREAK -->

<a id='63ad1e7f-2c85-4527-bf91-5745b7098c0f'></a>

## 1.2 / South Korea Hydrogen Strategy pursues industrial competitiveness and growth
---


<a id='dca32740-c12b-4526-a713-135290c22333'></a>

## General approach

Long-term targets until 2040 were released in the "Hydrogen Economy Roadmap of Korea" and the "National Roadmap of Hydrogen Technology Development" in 2019

<a id='bf60471e-f3b5-4a4e-851f-4b059539294a'></a>

Next to **hydrogen mobility**, the strategy focuses on the long-term establishment of a "hydrogen-powered" society, with key areas being the **production of hydrogen vehicles**, hydrogen-related **infrastructure** and hydrogen for **power generation**

<a id='557ee91b-5b01-4732-9db9-ca3a4072722b'></a>

**Key measures** include government funding, subsidies, industry alliances and development partnerships with other countries such as Australia, Saudi Arabia, Norway and Israel

<a id='04039b79-7f33-415b-b10e-179f0338196d'></a>

**National OEMs and suppliers** also announced significant investments into hydrogen, e.g. Hyundai Motor Group and its suppliers plan to invest a total of **USD 6.7 bn** and to produce **500k FCEVs** annually by 2030

<a id='07d90170-8654-4b67-951a-ede68737bb81'></a>

# Overview of key action areas

**Vision and targets**

Established targets on **FCEV production** and **refueling stations** in the country

<a id='b0dcb7f9-4f1a-47a2-a66b-39b20c4a7d45'></a>

Regulation and
licensing

Establish legal safety standards to
ensure the reliability and stability of the
hydrogen economy

<a id='ceeafd64-5f0a-41e4-8c1b-66b0c5d29f9f'></a>

Coordination and partnerships

Establish a cooperation system among Korea, China, and Japan, and reinforce participation in global partnerships (e.g. Hydrogen Council)

<a id='f7d052d3-ba82-4a47-9d4c-79df2aacb586'></a>

R & D

Create of a **Hydrogen Industry Cluster**
(2021) for R&D cooperation between
relevant players

<a id='af49ce6e-0c34-4a21-a8fb-70b10f672498'></a>

Skilled labor

Create a **safety professional**
**qualification** to manage safety across all
processes of the hydrogen value chain

<a id='200b0fcc-f812-4e35-acaa-5742ade9a790'></a>

1. Includes grey, blue, and green hydrogen. By 2040 the target is to use 70% low-emissions hydrogen (i.e. blue and green)

<a id='9dffa525-39dd-4e41-b9b2-85138eaa7e0b'></a>

Source: South Korean hydrogen roadmap; MOTIE; Ifri 2018; Green Car Congress; Press search

<a id='a85f5c27-5e8c-483d-bc6e-7cc25d3be881'></a>

<::logo: South Korea

A white rectangular flag with a central red and blue taegeuk symbol, surrounded by four black trigrams in each corner.::>

<a id='e31be4d3-64d4-4fe8-9749-48c19f795ba3'></a>

NOT EXHAUSTIVE

<a id='97d2093e-62b8-45b5-8dd2-844fd0f7b203'></a>

Key commitments and targets

**No. 1** fuel cell producer worldwide

**6.2 Mn** FCEV annual production capacity (incl. passenger cars, trucks, and buses) by 2040

**2.3 Bn USD** for the establishment of a public-private hydrogen vehicle industry ecosystem by 2022

Hydrogen¹ consumption targets,
Million tons per year

<::Bar chart showing hydrogen consumption targets:
- 2022: 0.5 Million tons per year
- 2040: 5 Million tons per year
: chart::>

<a id='ea7c3daf-d30b-4167-98b0-07fc88d1e3a6'></a>

McKinsey & Company

<a id='072f4741-9fad-4745-b781-6349a9461439'></a>

17

<!-- PAGE BREAK -->

<a id='e3c095db-213c-4296-9b9d-637033e933da'></a>

## 1.2 / South Korea focuses on scaling up domestic production of transport and electricity segments

<a id='07ab6658-4f48-475e-9ad3-c74c047ae3ad'></a>

<::logo: [South Korea] [No text] [A white rectangular flag with a red and blue taegeuk symbol in the center, surrounded by four black trigrams in each corner.]::>

<a id='5e435c9e-375f-47ca-b63f-11311cf056ce'></a>

<::NOT EXHAUSTIVE
Legend: X % share target of low-carbon hydrogen

Timeline and Bar Chart showing Hydrogen consumption, million tons per year:
- 2018: 0.1
- 2022: 0.5
- 2040: 5 (70%)
: figure::>

<a id='ff6c8add-1508-42d3-b230-6e0e2c116950'></a>

<table><thead><tr><th></th><th>Col 1</th><th>Col 2</th><th>Col 3</th></tr></thead><tbody><tr><td>Infrastructure roadmap</td><td>14 refueling stations<br>500 tube trailers<br>200km of pipelines</td><td>310 refueling stations<br>Introduction of high-pressure trailers for<br>transport, and large-scale gas storage and<br>transportation<br>Establish pipelines near by-product H2<br>production hubs<br>Build infrastructure for overseas production<br>(from 2022)</td><td>1200 refueling stations<br>Liquefaction and liquid and solid storage and<br>transportation (2030)<br>Construction of a nationwide high-pressure<br>pipeline network (2030)<br>Establish nationwide supply infrastructure (2030)</td></tr><tr><td>Targeted end-use sectors</td><td>Transport: 1.8k FC passenger vehicles<br>production capacity, 2 buses</td><td>Transport: 79k FC passenger vehicles<br>production capacity, 2k buses<br>Centralized power generation: 1.5 GW<br>Decentralized power generation (i.e. home fuel<br>cells): 50 MW</td><td>Transport: 5.9 Mn FC passenger vehicles<br>production capacity, 60k buses, 120k taxi fleet,<br>120k trucks. Domestic and for export². Ships,<br>trains, and drones<br>Centralized power generation: 15 GW<br>Decentralized power generation: 2.1+ GW</td></tr></tbody></table>

<a id='b9675198-cbaf-4083-ae46-85ac17c636bb'></a>

Selected support
schemes

Subsidies for FCEVs purchase to incentivize domestic production of vehicles at the beginning of the strategy (no year specified). Additionally, the
government will also provide funding for the initial expansion of **refueling stations** and establish **more relaxed permit restrictions**.
Support fuel cells deployment for power generation by my means of **weighted Renewable Energy Certificates**. Provision of financial incentives for
**home fuel cells** such as the establishment of an **LNG-exclusive tariff** by 2022

<a id='d78b0008-2281-4986-a6b6-6e97933909ba'></a>

1. Includes grey, blue, and green hydrogen. Includes domestic production and imports;
2. In total, 3.3 Mn units for export and 2.9 Mn units for domestic consumption.

<a id='67cb1739-7a23-465b-ab80-0a6738fef96a'></a>

Source: Ministry of Economic Affairs and Climate Policy of the Netherlands; IEA; International Hydrogen Strategies (World Energy Council Germany); Hydrogen Economy Roadmap of Korea

<a id='7c137af9-0991-48f7-a01a-9705a09bc393'></a>

McKinsey & Company

<a id='ea49948f-7ea6-49b3-9ef2-af75c0add0a6'></a>

18

<!-- PAGE BREAK -->

<a id='5020f2e8-5eba-48d7-8195-a32de960a875'></a>

1.2 / Key actions in for the creation of the hydrogen industrial
ecosystem in South Korea – Enabling environment

<a id='97796b08-64a6-4802-9fe5-785e5b629401'></a>

<::logo: [South Korea]The logo features a white rectangular background with a central red and blue Taegeuk symbol, surrounded by four black trigrams in each corner.::>

<a id='a47eb5ee-3ebd-4b16-a85b-db9ad9bb43a1'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and<br>targets</td><td>Fostering of<br>hydrogen industry</td><td>Focus on creating a new industrial ecosystem and placing South Korea as a global leader in hydrogen utilization, by establishing clear targets,<br>mainly in the <b>transport and power generation sectors</b><br>Support all stages of technological development throughout <b>the entire value chain</b>, from development of source technology in hydrogen-powered<br>vehicles, core components of fuel cells, and storage and transportation, to demonstration, commercialization, and improvement of stability<br>Develop guidebooks on <b>hydrogen safety</b> that address public concerns and include them in the <b>school curricula</b>,<br>Designate a 'Hydrogen Day' and hold an exhibit with new technologies and programs</td></tr><tr><td>Regulation<br>and licensing</td><td>Promoting growth<br>across the entire<br>value chain</td><td>Start a detailed roadmap for supporting the technological development throughout the <b>entire value chain</b>, in collaboration between the Ministry<br>of Industry, Ministry of Science and Technology, Ministry of Land, and the Ministry of Water Resources. In addition, <b>launch a cross-ministerial<br>preliminary feasibility study</b> for hydrogen (2021 to 2030)<br>Establish legal <b>safety standards</b> to ensure the reliability and stability of the hydrogen economy throughout the entire value chain. Enactment of a<br>"<b>Hydrogen Economy Act</b>" to provide an institutional base in H2 2019<br>Provide <b>relaxed licensing standards</b> for transportation companies introducing eco-friendly vehicles like hydrogen buses</td></tr></tbody></table>

<a id='61cfa90c-d291-4e09-b9ed-1b5d63ee0958'></a>

Coordination and Enhancing
partnerships international
cooperation and
industry alliances

Lead international standardization and evaluate at least 15 cases **technical standards in hydrogen production, storage vessels, fueling systems, and fuel cells** by 2030
Establish a **cooperation system among Korea, China, and Japan**, and reinforce participation in **global partnerships** (e.g. Hydrogen Council)
Enhance partnerships for the **development of overseas import base** from e.g. Middle East and Central and South America
Promote a hydrogen economy in South Korea through **industry alliances** and international partnerships
*   **HyNet** (e.g. Hyundai, Air Liquide) promotes the establishment of hydrogen refueling infrastructure
*   **H2Korea** and **FCHEA** sign MoU in Feb. 2020 to increase collaboration in the hydrogen economy

<a id='b6d190aa-fa61-4142-9741-bb1f9a68d1b7'></a>

Source: Ministry of Economic Affairs and Climate Policy of the Netherlands; IEA; International Hydrogen Strategies (World Energy Council Germany); Hydrogen Economy Roadmap of Korea

<a id='09bc0e1b-1d5b-4e44-9d42-9bae8b9eded7'></a>

McKinsey & Company

<a id='e54c9f98-951d-4609-bc6c-556dc1afd679'></a>

19

<!-- PAGE BREAK -->

<a id='069f07b1-56b9-4d82-903c-045eb7cb6a0f'></a>

1.2 / Key actions in for the creation of the hydrogen industrial ecosystem in South Korea – Investments and incentives

<a id='5eb0ae3b-be72-4070-a6fc-88502a8957a9'></a>

<::logo: [South Korea] [No text] [A white rectangular flag with a red and blue taegeuk symbol in the center, surrounded by four black trigrams in each corner.]::>

<a id='5304afe1-20d6-49d7-a114-d7b4b8cd06c5'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Securing the self-proliferation of the technology</td><td>Offer **subsidies for FCEVs purchase** to incentivize domestic production of vehicles and subsidies for the **operation of refueling stations** as well as establish more **relaxed permit restrictions**<br>Support fuel cells deployment for power generation by my means of **weighted Renewable Energy Certificates**. Provide financial incentives for **home fuel cells** such as the establishment of an **LNG-exclusive tariff** by 2022<br>Support FCEV business partners with long-term, **low-interest policy loans and investment expenses**<br>Promote financial support to **establish mass production facilities**</td></tr><tr><td>Infrastructure</td><td>Fostering<br>technology maturity<br>and expansion</td><td>Establish a supply infrastructure network **nationwide by 2030**<br>Convert from high-pressure gas storage to high-efficiency **liquefaction and liquid and solid storage**<br>**Reduce cost of hydrogen distribution** by establishing high-efficiency, high-capacity hydrogen storage and transportation systems</td></tr><tr><td>R&D</td><td>Performing large-scale<br>demonstrations and<br>supporting domestic<br>production</td><td>Create a **Hydrogen Industry Cluster** (2021) for R&D cooperation and for the development of a **large-scale testbeds**<br>Help selected **companies to secure a global position** with R&D and finance support<br>Build up large-scale demonstration projects for different end-uses. Selection of Ansan, Ulsan, and Wanju/Jeonju as **national testbed cities** by the South Korean Ministry of Land, Infrastructure, Transport, and Tourism.<br>**Invest** to optimize the production of FCEV parts. Public funding for the investigation of **hydrogen trains** efficiency and stability, application of **fuel cells on ships**, and other transport-related activities<br>**Start a pilot project for usage of hydrogen trucks** in the public sector, and a demonstration project for the conversion of general freight trucks</td></tr><tr><td>Skilled labor</td><td>Training of safety<br>standards and<br>development<br>specialists</td><td>Create a **safety professional qualification** to manage safety across all processes of the hydrogen value chain<br>Establish a **training program** covering the **design, operation, and safety of hydrogen refueling stations**, for station managers. **Train core personnel** on the design, production, and maintenance of **fuel cells**,<br>Support SMEs with **research personnel and recruitment**</td></tr></tr></tbody></table>

<a id='9b76a6ea-d79d-43b8-971c-0b3a53320dc9'></a>

Source: Ministry of Economic Affairs and Climate Policy of the Netherlands; IEA; International Hydrogen Strategies (World Energy Council Germany); Hydrogen Economy Roadmap of Korea

<a id='6846c0a3-c563-4454-824d-63173400af90'></a>

McKinsey & Company

<a id='82a35b3b-42fd-46be-a6b3-c3fcd728c3f0'></a>

20

<!-- PAGE BREAK -->

<a id='caab51b2-7fe2-4216-8775-dfff00fef0ec'></a>

1.2 / Dutch Hydrogen Strategy

<a id='dfe4ef87-8f9c-46bd-9e0f-f5631a334993'></a>

<::logo: The Netherlands

A rectangular flag with three horizontal stripes of red, white, and blue, with a gray border.::>

<a id='122a7ff9-719d-4161-9013-e502b22cf392'></a>

Electrolysis capacity targets, GW <::Bar chart showing electrolysis capacity targets in GW for different years. The years are displayed in large dark blue horizontal bars with white text. Below these year bars, smaller dark blue bars indicate the capacity targets. A horizontal line serves as the base for the capacity bars. For 2025, the target is 0.5 GW, represented by a short dark blue bar. For 2030, the target is 3-4 GW, indicated by a taller dark blue bar with a dashed outline extending above it, labeled "3-4". For 2050, the target is unknown, represented by a dark blue bar with a dashed outline above it, labeled "?".: chart::>

<a id='ae49803b-d762-4e7d-9635-3568a73425f5'></a>

<table><thead><tr><th>Col 1</th><th>Col 2</th><th>Col 3</th><th>Col 4</th></tr></thead><tbody><tr><td>Infrastructure<br>roadmap</td><td>50 refueling stations. 10% investment costs<br>reduction per year</td><td>N/A</td><td>N/A</td></tr><tr><td></td><td>Port of Rotterdam as international hub for hydrogen import and distribution across Europe (no timeline specified)</td><td></td><td></td></tr><tr><td></td><td>Evaluation of the necessity for grid strengthening and of an obligation for hydrogen blending into the gas grid (no year specified)</td><td></td><td></td></tr></tbody></table>

<a id='fc6980d6-9181-4666-8772-3a2efdddd4ee'></a>

Targeted end-use
sectors

(Icons: truck, building, factory)

**Transport:** 15k FCEV, 3k HDV
**Shipping:** increase use of hydrogen in shipping
industry (no year specified)
**Industry:** upgrading and refineries mentioned
but not concrete plans stated

**Transport:** 300k FCEV
**Aviation fuels:** 14% blending obligation

**Aviation fuels:** 100% blending obligation
**Power generation:** long-term relevance of
hydrogen (no specific targets/plan provided)
**Building sector:** higher relevance after 2030
due to uncertain technology costs

<a id='21fe092c-15be-4af2-82d0-e9d9e30ac977'></a>

Selected support schemes

For a transitional period, to enable scaling up, operational cost support will be available starting 2021 with an annual budget of EUR 35 Mn¹
Starting in 2020, the existing SDE++ scheme² for the generation of sustainable energy will include electrolysis
Development of a system of Guarantees of Origin for green H₂
Allocation of EU funds through the H2 Platform

<a id='befb208a-593f-463d-8f0d-ea48850fc8f4'></a>

1. The funds are made available through rearranging part of the existing DEI+ funds; 2. In total 2,000 full load hours are eligible for subsidy through this scheme with a maximum subsidy amounting to 300 EUR/ton abated CO2

<a id='06edf400-a420-4d17-853a-5fcda944f3d2'></a>

Source: Dutch Government Strategy on Hydrogen, Government publications; International Hydrogen Strategies (World Energy Council Germany)

<a id='9562a612-f2dd-410d-9696-8a4a0f9a5808'></a>

McKinsey & Company

<a id='6b8bb452-efc1-4886-8d8b-23c9dec7f154'></a>

22

<!-- PAGE BREAK -->

<a id='78173c37-283d-4a70-9478-208d2499bf26'></a>

1.2 / Dutch Hydrogen Strategy – Enabling environment

<a id='85d0f2f2-4e91-4edf-a3e3-fd0eaa697049'></a>

<::logo: [Netherlands] [] [A rectangular flag with three horizontal stripes: red on top, white in the middle, and blue on the bottom.]::>

<a id='f8fa2630-4dd0-486a-9c2e-f212c2330d4b'></a>

NOT EXHAUSTIVE

<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and<br>targets</td><td>Introducing a vision<br>for the future based<br>on guidance and<br>phasing</td><td>Establish generation and sector targets in addition to those presented in the Dutch National Climate Agreement. The focus is on the following<br>sectors: ports and industry clusters, transport, built environment, electricity sector, and agricultural sector<br>Retain the current strategic position as an energy hub<br>Foster cost reductions in order to unlock scaling up of hydrogen production and the subsequent set up of the supply chain, by means of new<br>and existing support schemes</td></tr><tr><td>Regulation<br>and licensing</td><td>Developing policy<br>tools to facilitate<br>deployment in<br>collaboration with<br>the private sector</td><td>Introduce a policy agenda based on 4 pillars: legislation and regulation, cost reduction and scaling up green hydrogen, sustainability on final<br>consumption, and a supporting and flanking policy<br>Formulate a National Hydrogen Programme as part of the National Climate Agreement, based on the hydrogen phasing plan leading up to<br>2030<br>Review the formulation of a position on the regulation of the value chain. The main goals are to facilitate the market, to ensure security of supply,<br>and to keep social costs the lowest possible<br>Implement safety standards based on international and European guidelines, and implement a policy framework for hydrogen safety risks<br>Launch a public-private Hydrogen Safety Innovation Programme to address safety issues</td></tr></tbody></table>

<a id='5b42428d-4fda-4f83-8175-7a3b7f153adc'></a>

Coordination Strengthening
and European
partnerships cooperation

<::transcription of the content
: figure::>

Communicate directly with the **European Commission** regarding EU hydrogen policies
Start initiative, together with Austria, to develop common approaches to critical issues such as **standards, market incentives and market regulations**, in a Forum with **Benelux, Germany, France, Austria and Switzerland**
Promote consultations and bilateral cooperation with **North Sea countries** to exploit the significant potential of **offshore wind energy** as key source for the production of green hydrogen beyond 2030.
Focus on a strong European competitive position internationally through the IPCEI¹

<a id='bfca29fe-3d65-4f09-b51c-d0e970a48b94'></a>

1. Important Projects of Common European Interest

<a id='cacca65b-0a35-4363-912e-4421905a460f'></a>

Source: Dutch Government Strategy on Hydrogen; International Hydrogen Strategies (World Energy Council Germany);

<a id='d3510d2f-aeb7-4b1a-ad50-5aa577870384'></a>

McKinsey & Company

<a id='f1ea7514-595b-451e-92ee-268d0f6192db'></a>

23

<!-- PAGE BREAK -->

<a id='cdebcae1-9cf4-4d8f-bf92-b36b6bf6bc56'></a>

1.2 / Dutch Hydrogen Strategy – Investments and incentives

<a id='04e679f5-99f6-4b0d-98a5-3497dd878b52'></a>

<::logo: [The Netherlands] [None] [A rectangular flag with three horizontal stripes of red, white, and blue.]::>

<a id='f042dcc9-3fe9-48ce-ab82-3b8afb2c77c3'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Offering financial<br>support at the<br>various phases of<br>the development<br>process</td><td>Develop a reliable system of <b>Guarantees of Origin (GOs)</b> and certification<br>Introduce a new and temporary <b>support scheme for operating costs related to the scaling up and cost reduction</b> process for green hydrogen<br>Facilitate the scaling-up by making use of the existing <b>Climate Budget funds</b> as of 2021, with an annual budget of <b>EUR 35 Mn</b><br>Include electrolysis hydrogen production in the <b>SDE++ support scheme¹</b>. Blue hydrogen production will be able to compete in the CCS category<br>Explore the feasibility of a <b>blending obligation</b> of hydrogen in the distribution networks</td></tr><tr><td>Infrastructure</td><td>Steering the<br>deployment in<br>collaboration with<br>industrial players</td><td>Review the <b>use of the existing gas grid</b>, and determine whether and under which conditions it could be used for hydrogen<br>Coordinate the optimal placement of hydrogen infrastructure through the <b>Main Energy Infrastructure Programme</b><br>Focus on infrastructure as <b>key enabler for industry clusters</b> sustainability improvements</td></tr><tr><td>R&D</td><td>Offering support<br>schemes for<br>research, scaling up<br>and rolling out</td><td>Support hydrogen projects through annual MOOI² tenders. In 2020, hydrogen projects are eligible to compete for a <b>EUR 17 Mn budget</b> (aprox.<br>MUSD 20), with a maximum <b>individual subsidy of EUR 4 Mn</b> (aprox. MUSD 4.7)<br>Support R&D projects in an <b>industrial environment</b> through the DEI+ program, which covers <b>25-45% of eligible cost up to EUR 15 Mn per project</b> (aprox. 17.6 MUSD)<br>Focus on <b>applied research</b> in collaboration with the business community through, among others, the <b>Netherlands Organization for Applied Scientific Research (TNO)</b><br>Research production and applications of green hydrogen through the <b>Energy Top Sector</b> as part of the various multi-year mission-driven innovation programs</td></tr><tr><td>Skilled labor</td><td>N/A</td><td>N/A</td></tr></tbody></table>
1. Support scheme for cost-effective carbon emissions reduction

<a id='6fd0273f-ddf9-4faa-94ab-37d968e21ef3'></a>

Source: Dutch Government Strategy on Hydrogen; International Hydrogen Strategies (World Energy Council Germany);

<a id='102e3a5d-96c1-4564-8919-22e843bfd0ea'></a>

McKinsey & Company

<a id='af0d2cbc-d144-401c-961e-f608fe54a855'></a>

24

<!-- PAGE BREAK -->

<a id='46fefff7-56e0-4f02-9dd7-efa33cf884d9'></a>

1.2 / German government agrees on National Hydrogen Strategy

<a id='0c989f6d-0240-4121-a9b1-d9e99401f63f'></a>

## Description
German Government agrees on **National**
**Hydrogen Strategy** that aims at providing
a framework for future **production** and
**application of hydrogen** as well as
related innovations and **investments**

<a id='995b0432-9b48-49e5-a982-4d79a04df698'></a>

**Long-term** focus is on **green** production,
however, the role of **other low-carbon**
**pathways** is **acknowledged** as import tool
for **short-** to **mid-term** market acceleration

<a id='fc6614a1-ed3d-4bd3-a820-9c3feac47891'></a>

The strategy aims at laying the **foundation** for a **functioning hydrogen market** until 2023

<a id='059748ba-77ba-4ef0-8b66-ef531ded9b04'></a>

The government and a National
Hydrogen Council will evaluate and
review the strategy every 3 years

<a id='3d46f986-c87a-4a67-a54c-7a22ed2343a8'></a>

Demand for hydrogen in Germany, TWh <::chart: Bar chart showing demand for hydrogen in Germany in TWh. The x-axis represents years, and the y-axis represents TWh. There are two bars: 2020 with a value of 55 TWh, and 2030 with a range of 90-110 TWh.::>

<a id='003bf4df-6a2c-4ff5-ab2f-3182bdbe41c9'></a>

## Overview of key measures
The strategy includes **38 measures** that aim at establishing a value chain for the **production, distribution, and large-scale use of hydrogen**

**Generation**
Support **green hydrogen production** via new **support schemes** (contracts-for-difference, auctions) and investment grants

**Infrastructure**
Plan **supply infrastructure** via dedicated **pipelines** and existing **gas networks**

**Hydrogen usage**
Support **usage** of hydrogen in **various sectors** (e.g., industry, transport, heating) via dedicated **support schemes** and **regulations**, and industry-specific dialogues
Define **standards for hydrogen products** to establish **international market**

**Partnerships**
Intensify **international partnership projects** to enable **imports of green hydrogen** as domestic production (**14 TWh of in 2030**) is expected to be **insufficient for deep decarbonization**

<a id='0dcd9d12-f433-4cc0-8fa8-e5380a91b019'></a>

1. The strategy mentions a target of 2 GW for electrolyzer but does not specify a concrete time frame or if this is additional to the 5-10 GW targets
2. Additional 5 GW to be added until 2035 if possible but no later than 2040

<a id='872d9e4a-b543-46c7-92db-55a3af69ce74'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='810bd10f-0f2f-456f-adc4-fc0c77b83def'></a>

<::logo: [Germany]
[No text]
A rectangular flag with three horizontal stripes of black, red, and gold, from top to bottom, respectively.::>

<a id='c08e7f77-5bbd-4fae-83b7-0f7d9c2f7a22'></a>

Key commitments and targets

**7 bn** EUR investments for **domestic** hydrogen market ramp-up

**2 bn** EUR investments for hydrogen projects within **international partnerships**

**2%** quota for **green hydrogen-** based aviation fuels until 2030 to be investigated

<a id='06f1d800-4924-4975-989c-4eae10fd86a3'></a>

<::Installed electrolysis capacity targets ¹, GW: bar chart::>
<::The chart shows two bars:
- For 2030, the capacity is 5 GW.
- For 2035-40², the capacity is 10 GW.::>

<a id='9f5b4524-1318-4b9f-b1bf-565ca487785f'></a>

McKinsey & Company

<a id='8aece613-6d55-4549-b292-593f2bc0ef24'></a>

25

<!-- PAGE BREAK -->

<a id='c952f0da-7759-482a-9416-f97959c2e43a'></a>

1.2 / Germany's national hydrogen strategy gets continuously revised in 3-year cycle

<a id='90b502a2-acb5-4687-b5cb-7e1ba27ff08f'></a>

---option x: [x] Renewable hydrogen production, TWh/yr<::Horizontal roadmap with three phases:1. Phase 1: 2020-2023: Market launch– Decarbonize existing hydrogen production and facilitating take up of hydrogen consumption in new end-uses2. Phase 2: 2023-2030: Scale up – Expand production and end-use to additional sectors to develop hydrogen as intrinsic part of an integrated energy system3. Beyond 2030: Use hydrogen to establish CO2-neutral economy by 2050: roadmap::>Electrolysis capacity targets, GW<::Bar chart showing electrolysis capacity targets in GW:1. For 2030, a bar represents 5 GW, with an additional circled value of 14 GW.2. For 2035-2040, a bar represents 10 GW, with an additional circled value of 28 GW.: bar chart::> 

<a id='92d38a76-62cc-4cd4-adcf-5e428bbf47a3'></a>

<table><thead><tr><th></th><th></th></tr></thead><tbody><tr><td>Infrastructure roadmap</td><td>Formulate report on recommendations for hydrogen supply through dedicated pipelines as well as<br>hydrogen-readiness of existing gas infrastructure, and buildout of hydrogen gas stations<br>Redesign planning and financing of infrastructure (electricity, heat and gas) to allow for cross-coordination and cost-efficient deployment of energy transition capable energy infrastructure<br>Create hydrogen refueling station infrastructure</td></tr><tr><td>Targeted end-use sectors</td><td>Transport: 3.6 bn EUR in subsidies for vehicles<br>and 1.1 bn for fuels until 2023¹<br>Heating: Support hydrogen fuel cell heating<br>Industry: Subsidize hydrogen use in chemicals<br>and steel. 55 TWh/yr consumption (2020)<br>Transport: 2% green hydrogen in aviation fuel<br>Heating: Further promote hydrogen use<br>Industry: >65TWh/yr consumption</td></tr><tr><td>Selected support schemes</td><td>Subsidies from energy- and climate fonds<br>Exclude green hydrogen from EEG-levy<br>Grant investment support for electrolyzers to support industry shift from grey to green hydrogen<br>Establish pilot project where generators receive difference between CO2 abatement costs for<br>producing green hydrogen (fixed CO2 price) and the CO2 price in the EU emission trading system to<br>guarantee generators stable returns⁴</td></tr></tbody></table>

<a id='7d22b16e-f6d7-4867-90fb-81d70ce71cee'></a>

1. Including electric vehicles and biofuels

<a id='cdebc9b5-72e8-4aee-bfa9-41a82fc178ed'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='8653c778-b480-455c-844b-1ffa553b9525'></a>

McKinsey & Company

<a id='b20f1f11-5e62-47e1-be83-4f9a9f44ef07'></a>

26

<!-- PAGE BREAK -->

<a id='adee842c-f298-48e3-848c-4c2b78a27e0d'></a>

1.2 / Key actions in for the creation of the hydrogen industrial
ecosystem in Germany – Enabling environment

<a id='84de351f-62f3-4f2a-a5e7-d98c4ceab9d1'></a>

<::logo: [Germany] [None] [A rectangular flag with three horizontal stripes: black on top, red in the middle, and gold on the bottom.]::>

<a id='2dab1fcb-ceec-48eb-8740-c50d1b7f3b60'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and targets</td><td>Ramping up the<br>green hydrogen<br>market and using it<br>to enable<br>Germany's energy<br>transition</td><td>Create a global impact on GHG reduction by developing a market for green hydrogen and increase global cooperation<br>Enable hydrogen as a competitive source of energy by driving technological development and advancing cost degression, establish green hydrogen in industrial processes and as a fuel source for seafaring and aviation<br>Establish a domestic market that incentivizes hydrogen use and develop hydrogen infrastructure to take advantage of synergies with the energy transition in Germany<br>Improve the hydrogen framework and R&D continuously</td></tr></tbody></table>

<a id='2423958b-ae18-4664-9b03-63ee00f62a7f'></a>

Regulation
and licensing

<::transcription of the content
: figure::>

Promoting the
growth of the entire
value chain

Implement the continuously revised **hydrogen strategy**
Regulatory **unbundling** of electrolyzers and power and gas **grid operators**
Develop and improve **framework conditions** for pairing **offshore wind** and electrolyzers including the designation of **dedicated land/areas** and the possibility of **additional tenders**
Start a **European dialogue** between regulators and the industry on **decarbonization strategies**, including hydrogen as an option

<a id='4256554b-a556-4340-b0ad-2991071e8073'></a>

Coordination and partnerships

Preceding International Standards and promote industry alliances

Develop joint European regulations and industry standards to establish cross-border hydrogen market and support investments in hydrogen technologies via „Important Project of Common European Interest (IPCEI)"

Integrate hydrogen in international energy partnerships to jointly develop hydrogen technologies and thereby guarantee that Germany's future demand for hydrogen can be met via imports

Advance standardization of hydrogen systems in mobility

<a id='0d55775f-cf07-46d4-8129-b0cc94259f71'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='c4fa1238-0a07-4cea-a20e-c79402599b76'></a>

McKinsey & Company

<a id='7eb85a65-f0ac-42cd-8b41-91e215e02242'></a>

27

<!-- PAGE BREAK -->

<a id='5899852e-728a-46ba-ae90-d209f76025ea'></a>

**1.2 / Key actions in for the creation of the hydrogen industrial ecosystem in Germany – Investments and incentives**

<a id='57d0683d-18be-432b-a8a4-0b42c62cf836'></a>

<::logo: Germany
None
A rectangular flag with three horizontal stripes of black, red, and gold (yellow) from top to bottom.::>

<a id='4e4f443c-21d3-4838-b346-4ea22f90a332'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Establishing green<br>hydrogen as a<br>competitive source<br>of energy</td><td>Subsidies from energy- and climate fonds<br>Exclude green hydrogen from EEG-levy<br>Grant **investment support** for **electrolyzers** to support industry shift from grey to green hydrogen<br>Establish pilot project where generators receive difference between **CO2 abatement costs** for producing **green hydrogen** (fixed CO2 price) and<br>the **CO2 price in the EU emission trading system** to guarantee generators stable returns<sup>4</sup></td></tr><tr><td>Infrastructure</td><td>Developing a<br>reliable and secure<br>infrastructure</td><td>Formulate report on **recommendations** for hydrogen supply through **dedicated pipelines** as well as **hydrogen-readiness of existing gas**<br>**infrastructure**, and buildout of hydrogen gas stations<br>Redesign planning and financing of infrastructure (electricity, heat and gas) to allow for **cross-coordination** and **cost-efficient deployment** of<br>energy transition capable energy infrastructure<br>Create hydrogen refueling station infrastructure</td></tr><tr><td>R&D</td><td>Promoting research<br>and innovation in<br>hydrogen<br>technologies</td><td>Strategically **bundle multiple research initiatives** towards hydrogen and investigate measures to facilitate **market entries** for **new hydrogen**<br>**technologies**<br>Provide **EUR 25 million funding** for hydrogen research in **aviation and shipping respectively** over the 2020-2024 period</td></tr><tr><td>Skilled labor</td><td>Training of safety<br>and development<br>specialists</td><td>Find new ways of collaboration between **research** and **education** to maintain and **expand qualified workforce**<br>**Support** and promote **training and development** of workforce in **hydrogen**, especially in production, processing and maintenance</td></tr></tbody></table>

<a id='b2e0a42b-eb3c-4c78-b587-b2fd26d790c7'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='201d2d97-1e66-4798-891e-ebd59d95ac6b'></a>

McKinsey & Company

<a id='ae9ca068-ece3-4964-ad9b-6f0f1963fd01'></a>

28

<!-- PAGE BREAK -->

<a id='a9ab0969-c991-46d7-922e-1fffc180120e'></a>

Chapter 2: Business case for domestic Hydrogen production and end use application

<a id='261e0775-9ba2-4d49-bd3e-3dcd730e4d7d'></a>

Chapter content
description

- **Business cases for domestic production of green hydrogen** through green renewables, including costs of generation and hydrogen production
- **Business case for prioritized end use applications**¹ including: heavy transport, urban buses, mining trucks (CAEX), natural gas blending, industry heating, green ammonia production and replacement of grey hydrogen
- **Domestic demand projections for green hydrogen in Chile** by end use application
- **Identify enabling factors** with the greatest influence over the business case

<a id='51dabf96-3c57-4d80-a9f4-4b1564e90b65'></a>

Activities
included

* Activity 2.1
* Activity 2.2
* Activity 2.3
* Activity 2.4

<a id='51abfa31-7e2d-474e-9183-c6e89d3b6510'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='1419df87-f758-4493-bec1-db89a8632200'></a>

McKinsey & Company

<a id='e96010d8-16a2-45f9-ae84-4623145d1a32'></a>

29

<!-- PAGE BREAK -->

<a id='6d6f593e-b32b-4712-8631-b368e3af7ab1'></a>

2.1/ To model the
potential of Green
Hydrogen in Chile,
we need to optimize
3 factors of
production costs

<a id='b2cdb334-0106-4bf4-8f06-3a17c7192ae5'></a>

<::Warning icon (triangle with lightning bolt) followed by a list:
Generation cost
- Generation location
- Capacity Factor sequencing
- Generation technology (wind, PV, Bifacial and CSP)
: infobox::>

<a id='b2ce1c38-6fde-4f9b-9e16-ca5a5ece670f'></a>

<::A white circular arrow icon with three arrows pointing clockwise is displayed on a dark blue background. Below the icon, a thin white horizontal line separates it from the text content that follows:

Electrolyzer
utilization

RES blending
Storage technology
: icon and text block::>

<a id='ff390b7b-3035-4507-9cc7-ab44bd43dfaf'></a>

<::icon of a delivery truck
Transmission /
distribution
H2 production location
Transmission costs
Transportation costs
: figure::>

<a id='2b036e3f-bc50-4ce8-8c19-a8318c9e32a4'></a>

McKinsey & Company

<a id='5687cf56-50cc-44c7-b8e9-03c0a7a3beca'></a>

30

<!-- PAGE BREAK -->

<a id='6ac48b15-69a7-4667-b1f0-1a2569997c9a'></a>

2.1/ In the three macro-zones considered, LCOE costs in the northern and
southern zones can reach as low as ~19 USD / MWh and ~21 USD / MWh
respectively by 2025

<a id='df48deb5-4a36-48b9-8541-2228b952fe50'></a>

Levelized cost of energy¹ for competitive zones, USD/MWh
<::
Line chart with Y-axis labeled "USD/MWh" (ranging from 0 to 40) and X-axis labeled "Year" (ranging from 2020 to 2050). Three lines with shaded ranges show the levelized cost of energy for different regions:
- South (dark blue line) decreases from approximately 37 USD/MWh in 2020 to 19 USD/MWh in 2050.
- Central (medium blue line) decreases from approximately 23 USD/MWh in 2020 to 18 USD/MWh in 2050.
- North (light blue line) decreases from approximately 26 USD/MWh in 2020 to 13 USD/MWh in 2050.
: chart::>
Capacity factors by region², %
<::
Table with two main columns: "Competitive zones" and "Uncompetitive zones". Rows are grouped by "Production Zone":
- Northern Production Zone:
  - Competitive zones: Atacama PV 34%, Calama PV 33%, Taltal PV 35%
  - Uncompetitive zones: Coquimbo Wind, Taltal Wind, Calama Wind
- Central Production Zone:
  - Competitive zones: Central PV 23-25%
  - Uncompetitive zones: Chiloe Wind, Biobio Wind, Coquimbo Wind
- Southern Production Zone:
  - Competitive zones: Magallanes wind 56-59%
  - Uncompetitive zones: Bahía Inútil, Offshore wind (Competitiveness still being assessed)
: table::>

<a id='e9e8aff2-bccc-4cc2-834d-5834f216d2a3'></a>

1. Based on 6% WACC, does not include transmission costs
2. Capacity Factors for Tier 1 sites

<a id='6e38dd5c-764d-47e0-b278-0d2063a08339'></a>

Source: McKinsey Hydrogen Cost Model

<a id='d32fd97a-f081-4b2a-8be6-b7868e565cef'></a>

McKinsey & Company

<a id='fcc62e47-7678-46ce-ba73-828fc0bcdfd2'></a>

31

<!-- PAGE BREAK -->

<a id='7491dfe1-e6cf-4443-846d-fdf6b9bbcf7b'></a>

2.1/ Chile´s unparalleled renewable resources in the Atacama and Patagonia makes it the lowest cost place to produce Green Hydrogen in the world

<a id='4908f6ea-c04c-4430-93cd-608088f2355a'></a>

Production cost curve for hydrogen by region, Generation and Electrolyzer costs of LCOH, USD / kg H2
<::line chart::
Title: Production cost curve for hydrogen by region
Y-axis: USD / kg H2 (ranging from 0 to 3.0 in increments of 0.5)
X-axis: Year (2020, 2025, 2030, 2035, 2040, 2045, 2050)

Legend:
- Pink line: Central: select domestic application
- Light blue line: South: export
- Dark blue line: North: export + mining applications

Data points:
- Central (pink line):
  - 2025: 2.5
  - 2030: 1.7
  - 2035: 1.4
  - 2040: 1.2
  - 2045: 1.1
  - 2050: 1.0
- South (light blue line):
  - 2025: 1.7
  - 2030: 1.3
  - 2035: 1.1
  - 2040: 1.0
  - 2045: 0.9
  - 2050: 0.8
- North (dark blue line):
  - 2025: 2.0
  - 2030: 1.4
  - 2035: 1.2
  - 2040: 1.1
  - 2045: 1.0
  - 2050: 0.8
::>
Comparison of production costs 2030
Generation and Electrolyzer costs of LCOH
USD / kg H2
<::bar chart::
Title: Comparison of production costs 2030
Y-axis: USD / kg H2
X-axis: Region

Data:
- Chile: 1.3 (with a bracket indicating 1.4)
- Middle East: 1.8
- Australia: 1.7
- China: 2.2
- Europe: 2.6
- US: 2.1
::>

<a id='8c796a69-2c80-4d00-af82-77e56634339b'></a>

Source: McKinsey model, Minister of Energy capacity factor data and PV / Solar profiles

<a id='e415d82c-498e-4c60-aef2-7b55028db88d'></a>

McKinsey & Company

<a id='e37c0113-0985-4bf1-abad-76b8d4cd7149'></a>

32

<!-- PAGE BREAK -->

<a id='6b940df0-83c4-4694-ab3d-d29be6ea6802'></a>

2.1/ Green hydrogen production cost is projected to drop by 50% within the next 10 years driven by a decrease in electrolyzer costs

<a id='6af6cb9f-49eb-41d1-ad10-0235a25f5cc2'></a>

Cost reduction levers for hydrogen electrolysis connected to dedicated solar PV in Taltal, Chile
USD/kg H₂

<a id='5a45c99e-9bb8-4588-bfa4-5707798fd498'></a>

<::chart: Waterfall chart showing changes from 2025 to 2035. The chart illustrates a reduction from an initial value of 2.0 in 2025 to a final value of 1.1 in 2035, representing an overall decrease of -46%. The changes are broken down as follows: Power generation costs decrease by 0.2, driven by a steep decline in solar PV CAPEX from ~850 $/kW to ~400 $/kW, and solar PV LCOE in Taltal decreases from 19 to 13 USD/MWh. Electrolyzer CAPEX costs decrease by 0.4, attributed to a sharp 55% decrease in 10 years due to larger global production scale, automation in manufacturing, larger individual system size classes (e.g., going from 2-20 MW today to >100 MW per unit), and decreasing BOS¹ costs. Electrolyzer efficiency shows a change of 0-, with efficiency increasing from 68 to 71% due to technical advancements, such as better catalysts. Other costs decrease by 0.2, especially electrolyzer O&M costs, following a reduction in the cost of parts and learning to operate systems. Footnote: 1. Balance of system::>

<a id='c759f469-d585-43be-abd9-deaafb195bb6'></a>

Source: McKinsey Hydrogen Cost Model

<a id='390ac825-e1f1-4351-94de-afd935354bfa'></a>

McKinsey & Company

<a id='c8a6e2db-4a6d-4a89-83bb-9aa0d719b8ba'></a>

33

<!-- PAGE BREAK -->

<a id='a8dccc79-7dc4-484b-86c4-80bb88abb175'></a>

## 2.1/ Different options for solar technology range from fundamental changes to incremental improvements to the system

<a id='1093020e-c58e-4185-85cc-795be6207efd'></a>

option Details to follow: [ ]

<a id='14587e3e-a378-4331-8932-2fe4ea78d9a3'></a>

Fundamental shifts on how the system works

<::illustration of a solar panel (PV) and a concentrated solar power (CSP) trough
: PV vs CSP¹::>

<::illustration of two solar panels, one with single-axis tracking and one with two-axis tracking
: PV 1-axis vs 2-axes tracking::>

<::illustration of a battery
: Battery storage::>

<a id='fd67ea74-32cf-4865-9228-70c290ca98db'></a>

## Incremental improvements to PV technology

*   Manufacturing scale
*   Single vs multi-crystalline Silicon wafers
*   Bifacial modules
*   Perovskite solar cells
*   Professionalization of the industry

<a id='fb81c739-87f5-41f6-962f-9709bb0ef751'></a>

Compared to PV technology, CSP represents a fundamental shift on how the system works, leading to significant differences in LCOE. By contrast, bifacial modules provide incremental improvements to PV technology, with a marginal LCOE change that is highly dependent on specific local characteristics, such as albedo (ground material) and labor cost (more complex engineering work is required for project planning and installation)

<a id='38d6cf8b-6e14-4661-ba4e-68e7e8c98128'></a>

1. Concentrated Solar Power

<a id='1f05fb93-1df6-4aac-8246-ea90409cfa78'></a>

McKinsey & Company

<a id='a514097a-e0f9-4219-87ee-33d1c2e4d4ba'></a>

34

<!-- PAGE BREAK -->

<a id='b980821d-2d7d-4a2a-b821-e61faa02c18d'></a>

2.2-2.3/ Economic breakeven will start with domestic applications; exports of green ammonia will ramp up in the second half of this decade, whereas exporting hydrogen and synfuels will happen after 2030 Not exhaustive Preliminary Prioritization matrix for main hydrogen applications² Uncertainty vs Break-even – size of the bubble represents total potential market for 2030 1 GW Electrolyzer Capacity = ~0,1 Mton <::chart: Bubble chart titled "Prioritization matrix for main hydrogen applications²" with subtitle "Uncertainty vs Break-even – size of the bubble represents total potential market for 2030". The X-axis is "Estimated breakeven" ranging from 2025 to 2035. The Y-axis is "Uncertainty on technological cost evolution" ranging from Low to High. The chart is divided into three waves: Wave 1, Wave 2, and Wave 3, indicating increasing uncertainty and later breakeven. A legend indicates that light blue circles represent "Domestic" applications and red circles represent "International" applications. The size of the bubble represents the total potential market for 2030, with a reference circle representing "5,00 - Mton hydrogen equivalent". Specific applications are plotted as bubbles with their estimated Mton market size: Wave 1 (Low uncertainty, earlier breakeven): - Grey H2 replacement Oil Refinery (0,1 Mton, Domestic, around 2025) - Ammonia Domestic (0,2 Mton, Domestic, around 2025) - Mining Trucks FCEV (0,8 Mton, Domestic, around 2027-2028) - Long distance buses FCEV (0,4 Mton, Domestic, around 2027-2028) - Heavy Duty Trucks long distance (1,0 Mton, Domestic, around 2028-2029) - Medium Duty Truck long distance (0,1 Mton, Domestic, around 2029) Wave 2 (Medium uncertainty, later breakeven): - Ammonia exports (11-23 Mton, International, large red bubble around 2030) - Hydrogen exports (22-34 Mton, International, large red bubble around 2030) - Gas blending with H2 (0,2 Mton, Domestic, around 2030) - SUVs (0,1 Mton, Domestic, around 2030-2031) - Ammonia for domestic shipping (0,5 Mton, Domestic, around 2030-2031) Wave 3 (High uncertainty, later breakeven): - Light road transport FCEV (Domestic, around 2032-2033) - Ammonia Small maritime transport (Domestic, around 2032-2033) - Small passenger cars FCEV (Domestic, around 2033-2034) Additionally, "Power generation and buffering applications most relevant beyond 2035" is noted at the bottom right (Low uncertainty, beyond 2035).::> 5,00 - Mton hydrogen equivalent option Domestic: [x] option International¹: [x] * Commercialization of hydrogen applications will take place in three waves: — Wave I: Domestic ramp up and export preparation — Wave II: Capitalization on export markets — Wave III: Leverage scale to expand * Additional applications (not pictured) can become relevant once the synergies from large scale exports are captured * Key longer term applications (synfuel and methanol) will bring additional market opportunities in 2035+ * Industrial head applications considered, but they are small

<a id='1e00ba5d-3d03-4a70-9a92-c0d1add2cbb9'></a>

1. Considers domestic demand of ammonia and ammonia used for Fertilizers | 2. Does not consider CO2 Tax | 3: Considers main addressable markets (Low range does not consider China)
Source: Team Analysis; Hydrogen Council report; INE Chile; OCDE

<a id='40ab47f1-2d9a-43cc-be31-117f7cbc9114'></a>

McKinsey & Company

<a id='a7534242-f303-4bd0-a064-5e309dcb567a'></a>

35

<!-- PAGE BREAK -->

<a id='6277619e-1bf0-4210-b852-23ae0c63b00a'></a>

## 2.2-2.3 / Market size of the hydrogen industry in Chile

<a id='ac9a21c2-142f-4d9d-adc3-3b8effb4170b'></a>

<::Chilean Hydrogen and derivative market projections: 2025-2050: chart::>Chilean Hydrogen and derivative market projections: 2025-2050. The chart displays projections in B USD. The legend indicates Domestic Market (gray) and International Market (dark gray). The bars represent total market value for different years, broken down by domestic and international components. There is an annotation indicating a growth rate of +12-15% p.a.  Below the chart, there is a table showing required capacities.  B USD:  - 2025: Domestic Market 1, International Market 0, Total 1.  - 2030: Domestic Market 2, International Market 3, Total 5.  - 2035: Domestic Market 5, International Market 11, Total 16.  - 2040: Domestic Market 7, International Market 16, Total 23.  - 2045: Domestic Market 8, International Market 19, Total 28.  - 2050: Domestic Market 9, International Market 24, Total 33.  Required capacities:  | Year | 2025 | 2030 | 2035 | 2040 | 2045 | 2050 |  |---|---|---|---|---|---|---|  | Required GW electrolyzer capacity | 3-5 | 25 | 90 | 130 | 155 | 190 |  | Required GW RES capacity | 5-8 | 40 | 145 | 200 | 250 | 300 |  <::/chart::>However, capturing this opportunity requires the appropriate ramp up of applications: Wave I: Domestic ramp up and export preparation Wave II: Capitalize on export markets Wave III: Leverage scale to expand Detailed next

<a id='69d63ff8-fa01-4cc2-b5a5-f94182926905'></a>

McKinsey & Company

<a id='96015ed9-2d39-4ba9-9f88-9bc94426174f'></a>

36

<!-- PAGE BREAK -->

<a id='86c5cafd-7bd4-4ca5-a0ac-48770a7b7735'></a>

2.2-2.3 / Domestic application anticipation would be focused primarily on grey H2 replacements in oil refinery, grey NH3 replacement in mining / fertilizers and glass blending

<a id='76447159-793b-4126-9d4f-4436ef740377'></a>

Preliminary
<::table
: chart::>
| | Application | Total Potential Market size¹ - USD B 2050 | Electrolyzer capacity required (GW) | 2020 | 2025 | 2030 | 2035 | 2040 |
|---|---|---|---|---|---|---|---|---|
| Estimated break-even with National H2 Strategy (blue diamond) | | | | | | | | |
| Potential break-even without National H2 strategy (grey diamond) | | | | | | | | |
| Potential ramp-up to achieve 100% (grey triangle) | | | | | | | | |
| 1 | Current H2 replacement Oil refinery | 0.2 (horizontal bar) | 1.8 (oval) | | blue diamond (start of 2025), blue horizontal bar extending to 2030, grey triangle (arrow) | grey diamond (mid-2025), grey horizontal bar extending to 2035 | | |
| 2 | Current NH3 replacement Mining + fertilizers | 0.5 (horizontal bar) | 2.2 (oval) | | blue diamond (start of 2025), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (mid-2030), grey horizontal bar extending to 2035 | | |
| 3 | Mining haul trucks | 1.6 (horizontal bar) | 9.3 (oval) | Pilots starting (+30 trucks) | blue diamond (mid-2025), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (start of 2030), grey horizontal bar extending to 2040 | | |
| 4 | Heavy duty trucks | 2.0 (horizontal bar) | 11 (oval) | Pilots starting (+50 trucks) | blue diamond (mid-2025), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (start of 2030), grey horizontal bar extending to 2040 | | |
| 5 | Coaches / buses | 0.8 (horizontal bar) | 4.5 (oval) | Pilots starting | | blue diamond (start of 2030), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (mid-2030), grey horizontal bar extending to 2040 | | |
| 6 | Gas Blending (up to 20% total residential use) | 0.3 (horizontal bar) | 1.8 (oval) | | blue diamond (start of 2025), blue horizontal bar extending to 2030, grey triangle (arrow) | grey diamond (mid-2025), grey horizontal bar extending to 2035 | | |
| | ~6 USD B (total) | | GW Electrolyzer: (w/ National H2 Strategy) | 3 (oval) | 10 (oval) | 25² (oval) | 40² (oval) | |
<::/table::>

<a id='543db292-d68b-4abe-b41c-f8092e78e50c'></a>

1. Consider the transition to hydrogen of 100% of the energy demand of each application
2. Including other domestic applications including: airlines, shipping and large passenger cars

<a id='8c2f4985-b832-43b8-a829-1f390e41af60'></a>

Source: Team analysis; INE, ENAP; DPO

<a id='6af0b88d-bcfd-46fc-88b4-c0ad29737d7a'></a>

McKinsey & Company

<a id='3fc1ee14-9e8e-480d-abee-7c6a00e41eb1'></a>

37

<!-- PAGE BREAK -->

<a id='c4949e99-a81e-41a8-8761-e3df0990702d'></a>

2.2-2.3 / Domestic could account for +3M ton of total hydrogen demand by 2050

<a id='8725d7ee-0d1d-4773-839b-cf62c07826e3'></a>

<::Stacked bar chart titled "Hydrogen uptake for different domestic applications". The y-axis represents "Mtons of hydrogen equivalent". The x-axis represents years: 2025, 30, 35, 40, 45, and 2050. The legend indicates the following categories: Oil refinery (lightest blue/purple), Gas blending (lighter blue), Mining trucks (medium blue), Ammonia (darker teal), Buses (darker blue), and Trucks (darkest blue/black). The bars show the hydrogen uptake for each application, stacked for each year.  Year totals are displayed above each bar.  The values for each segment are as follows:  - **2025**: Total 0.3 Mtons. Individual segment values are too small to read. - **2030**: Total 0.5 Mtons. Individual segment values are too small to read. - **2035**: Total 2.0 Mtons. Segments from bottom up: Trucks 0.8, Buses 0.6, Ammonia 0.2, Mining trucks 0.2, Gas blending 0.1, Oil refinery 0.1. - **2040**: Total 2.7 Mtons. Segments from bottom up: Trucks 1.1, Buses 0.8, Ammonia 0.4, Mining trucks 0.2, Gas blending 0.1, Oil refinery 0.1. - **2045**: Total 3.0 Mtons. Segments from bottom up: Trucks 1.1, Buses 0.9, Ammonia 0.4, Mining trucks 0.2, Gas blending 0.2, Oil refinery 0.2. - **2050**: Total 3.2 Mtons. Segments from bottom up: Trucks 1.2, Buses 1.0, Ammonia 0.4, Mining trucks 0.2, Gas blending 0.2, Oil refinery 0.2.: chart::>

<a id='3f002440-6e0c-4e83-b0d0-5d1b51d9340d'></a>

<::Hydrogen uptake for different domestic applications% of total consumption: line chart. The y-axis represents "% of total consumption" with major ticks at 0, 25, 50, 75, and 100. The x-axis represents the year, with major ticks at 2025, 30, 35, 40, 45, and 2050. There are six lines representing different applications: Oil refinery, Gas blending, Mining trucks, Ammonia, Buses, and Trucks. Oil refinery (black line) starts around 40% in 2025 and reaches nearly 100% by 2030. Gas blending (dark blue line) starts around 5% in 2025 and slowly rises to about 30% by 2050. Mining trucks (teal line) starts near 0% in 2025, increases significantly from 2030, and reaches nearly 100% by 2037. Ammonia (light blue line) starts around 40% in 2025 and reaches nearly 100% by 2040. Buses (pale blue line) starts near 0% in 2025, increases significantly from 2035, and reaches nearly 100% by 2042. Trucks (light purple line) starts near 0% in 2025, increases significantly from 2030, and reaches nearly 100% by 2037.::>

<a id='0badc8a0-22ab-449d-83fb-3bbe48572ac5'></a>

McKinsey & Company

<a id='0d1a3f8e-ae53-4167-a3fb-7928a2a6beca'></a>

38

<!-- PAGE BREAK -->

<a id='319a3b8e-1582-42e0-840f-9ef0ea7d17d3'></a>

2.4/ Factors which produce the largest differences between the results
of the business cases

<a id='950a00ff-e06d-427a-a604-71ae80d310af'></a>

1 Financing and incentives

Sources of funding to facilitate the launch of feasibility studies, pilots and scaled projects

Incentives structured to support supply and demand development for scaled projects

<a id='0d0c01b7-fd05-4433-9b01-7a5b8bfc54b4'></a>

<::A white line icon of a building with columns and a dome, resembling a capitol building, is displayed at the top. Below the icon, a horizontal line separates it from the text. The title "2 Regulation and licensing / permits" is presented, followed by two bullet points: "Long term regulatory structure to diminish uncertainty and minimizes barriers to entry / doing business" and "Acceleration of licensing and permitting processes." : infographic::>

<a id='df299a1a-d131-4073-869a-da099de3fc36'></a>

<::Outline icon of two people shaking hands, representing partnership.
: figure::>

---

③ Coordination and partnerships

Coordination mechanism to create formalized partners with domestic and international actors to promote industry growth and domestic and international supply chain development

<a id='089d13bc-dc42-47aa-b396-268f50704a0e'></a>

<::transcription of the content
: pipes icon::>

4 Infrastructure
Necessary infrastructure to support project
development (transmission, ports, refueling stations
etc...)

<a id='0a511648-1f0f-4d34-a835-36576400e20a'></a>

5 Research & Development

Research and development of technologies for the Chilean context (ex. wind turbines for Patagonian wind profiles and earthquake resistant ammonia production)

<a id='72ea9372-8cc5-42d5-a3dd-d54467db8ed4'></a>

<::An icon of a person wearing a graduation cap is displayed above a horizontal line. Below the line, the number 6 is circled, followed by the text "Skilled Labor". A description below reads: "Ability to attract local talent for construction and production": figure::>

<a id='6d4b72e3-122e-49c6-8b49-8038d847696b'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='a5e9bbbb-e9d3-4a49-bd94-9790cae7e7d7'></a>

McKinsey & Company

<a id='57237b3b-8f08-4e47-bfde-4eb7db3650e0'></a>

39

<!-- PAGE BREAK -->

<a id='0f719771-16ea-4097-b257-3b590d1f432a'></a>

# Chapter 3: Business case for Hydrogen exportation

<a id='7ac28cba-e79e-4f03-a345-2ece2fc59427'></a>

Chapter content description
*   **Demand projections for key export markets of green hydrogen** by end use application and geography (focus on green hydrogen and green ammonia)
*   **Competitiveness assessment of Chile in key export markets**, including: European Union, Japan, South Korea, China and the United States
*   **Key factors which influence the competitiveness of Chile in these export markets**

Activities included
*   Activity 3.1
*   Activity 3.2

<a id='9ff29d40-6fae-4ee4-8a95-31983450367f'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='b5c6f04a-4f25-4bf0-8622-9f3371b79d88'></a>

McKinsey & Company

<a id='424ffcb8-74ef-4330-980d-52bbedf6cc7b'></a>

40

<!-- PAGE BREAK -->

<a id='f8c61bb9-45e2-4d4d-9937-0f225cdb414f'></a>

**3.1 / Ammonia exports:** key potential green ammonia markets for Chile include China, Japan/South Korea, EU, USA and LATAM

<a id='459aaef9-5da9-4e68-a0c2-c9cb0203ef40'></a>

Total Ammonia consumption 2030 – Mton / year NH3
<::chart: Waterfall chart showing total ammonia consumption by 2030 in Mton / year NH3, with blue bars representing 'Export opportunity for Chile'.

**Regions/Categories and their consumption (Mton / year NH3) and associated descriptions:**
*   **China (flag of China):** 65
    *   Current consumption of ammonia is served by domestic offer (+95%)
    *   High availability of renewable resources may allow to address its own domestic demand
*   **European Union (flag of European Union):** 23
    *   Net importers of grey ammonia (+25% of total consumption)
    *   New carbon taxes may favor imports of green ammonia
*   **United States (flag of United States):** 18
    *   Net importers of grey ammonia (+10% of total consumption)
    *   Potential development of domestic market could diminish import needs
*   **Middle east:** 18
*   **India:** 17
*   **Russia:** 15
*   **South America (exc. Chile) (flags of Argentina and Brazil):** 3
    *   Potential attractiveness due to proximity (+75% Brazil and Argentina)
*   **Japan / South Korea (flags of Japan and South Korea):** 3
    *   Net importers of grey ammonia (+60% of total consumption)
    *   High ambitions for green ammonia transition may require high levels of imports
*   **Rest of the world BAU:** 69
*   **Total BAU:** 210
*   **Potential new applications of ammonia:** 40
*   **Total potencial:** 230-290:chart::>

<a id='e644954c-c6c5-4b5f-bebd-12056e2cc98d'></a>

McKinsey & Company

<a id='419297ed-2ed6-4611-bb85-4b378f506cb2'></a>

41

<!-- PAGE BREAK -->

<a id='b2f50787-bb08-438b-8a53-12d83356bef9'></a>

3.1 / **Hydrogen export**: key hydrogen markets for Chile include South Korea, European Union and the United States

<a id='278f4218-ae31-4d7d-a230-00354ce24541'></a>

## Potential demand for green hydrogen per country
Mton H2 / year; Low and high ranges found in strategic roadmaps

<a id='f2c2dd15-9455-4c9c-a5e6-d3c52a27bb9f'></a>

**Preliminary**

<a id='25d564fd-e1f0-4975-95c4-701c0d899c9c'></a>

<::image of the Chinese flag::>

- Domestic production capacity may be sufficient to attend the demand for green hydrogen, however, accelerated expansion may require imports

<::simplified bar chart with two bars:
left bar: a small filled bar below a dashed outline, labeled "36" above.
right bar: a larger filled bar with "40" written inside it, below a dashed outline, labeled "60" above.
: figure::>

<a id='ce5bdb62-7904-477f-8058-68062353701e'></a>

<::European Union flag. Bar chart showing values for 2030 and 2050: 2030 has a total value of 20 with a filled portion of 14. 2050 has a total value of 68 with a filled portion of 23.: chart::>• The limited production capacity in the region may boost imports specially by countries as Germany, Netherlands, Belgium, among others<::USA flag. Bar chart showing values for 2030 and 2050: 2030 has a total value of 17 with a filled portion of 14. 2050 has a total value of 63 with a filled portion of 20.: chart::>• Even though the country counts on its own natural resources, Chilean hydrogen presents an attractive cost structure able to compete with the local market

<a id='47182f29-6a4a-46c7-bda0-868a322edf8c'></a>

<::Bar chart showing two categories: 2030 and 2050. For 2030, the total value is 7, with a dark segment showing 2. For 2050, the total value is 27, with a dark segment showing 11.
: chart::>

<a id='5accb035-b3cd-4ad8-82aa-ef25b12392d0'></a>

Source: China renewable energy outlook 2018; Hydrogen roadmap South Korea 2018; Japan Strategy Energy Plan 2018; Roadmap to a US hydrogen Economy; Perspectives on hydrogen for the APEC region; Hydrogen Council; EU strategic roadmap; The future of Hydrogen IAE;

<a id='5bd45a15-0e10-4329-9478-549887f7cc23'></a>

McKinsey & Company

<a id='f3eb9c26-3180-46b5-a4fc-73d287b28c21'></a>

42

<a id='726213c3-f3dd-4bb3-9e20-b7aae6481c59'></a>

<::
option Export opportunity for Chile: [ ]
option Ambitious scenario: [ ]
option Base scenario: [ ]
: figure::>

<a id='eb3a5fe8-3a9b-4113-859a-50089a32aa5a'></a>

<::logo: [Flags of Japan and South Korea]
[No readable text]
Two rectangular flags are displayed side by side: the Japanese flag with a red circle on a white background, and the South Korean flag featuring a red and blue taegeuk symbol surrounded by four black trigrams on a white background.::>

<a id='d310e41d-acaf-4b48-97e0-5774cca7f30b'></a>

* Japan's Energy foresees the procurement of ~300 Ktons in 2030 and 5-10 Mtons in +2050
* S. Korea plans to start importing hydrogen in 2030

<a id='6e4e6f8f-4028-4574-8f0a-cd821884dd7e'></a>

<::Bar chart with two bars.
- Bar 1: 2030, value 23
- Bar 2: 2050, value 40
: chart::>

<!-- PAGE BREAK -->

<a id='f9ab3edb-2d02-4e19-990c-3d5e6f316ce3'></a>

**3.1 / Export markets have the potential to ramp up starting 2025, provided that long term contracts are brokered with international players**
---


<a id='c9d4d14c-875e-439a-92b8-21cb1859f5c0'></a>

Estimated market size for Chilean exports USD B<::chart: Stacked bar chart showing estimated market size for Chilean exports of Ammonia and Hydrogen in USD B from 2025 to 2050, broken down by destination. A legend indicates colors for LATAM (light blue/cyan), USA (very light blue), Japan/Korea (medium blue), China (darker blue), and Europe (darkest blue/black). The chart also includes two rows of summary data above the main bars.Figure Caption: 1 Total of Ammonia + Hydrogen exports.Top Summary Data:  Total¹:  2025: 0.4  2030: 3  2035: 11  2040: 16  2045: 19  2050: 24  GW Electrolyzer:  2025: 2  2030: 15  2035: 65  2040: 90  2045: 110  2050: 135Ammonia exports:  Year | Europe | China | Japan/Korea | USA | LATAM | Total  ---|---|---|---|---|---|---  2025 | 0.5 | | | | | 0.5  2030 | 1 | 1 | | | | 2  2035 | 2 | 1 | 0 | 1 | | 4  2040 | 3 | 1 | 1 | | | 5  2045 | 3 | 1 | 1 | | | 5  2050 | 3 | 1 | 1 | | | 5Hydrogen exports:  Year | Europe | China | Japan/Korea | USA | LATAM | Total  ---|---|---|---|---|---|---  2025 | | | | | | 0  2030 | 0.5 | | | | | 0.5  2035 | 3 | 1 | 2 | 1 | | 7  2040 | 4 | 1 | 4 | 2 | | 11  2045 | 5 | 1 | 5 | 2 | 1 | 14  2050 | 7 | 2 | 7 | 3 | | 19::>1 Total of Ammonia + Hydrogen exports

<a id='eeaca484-1562-4fee-aed9-b8ee168c434e'></a>

Source: Team analysis; National hydrogen roadmaps of the respective countries -Total of Ammonia + Hydrogen exports

<a id='9ec89ade-9e30-4876-8885-f0725e52b52a'></a>

McKinsey & Company

<a id='dfd191f2-eba7-49cd-bebd-d638709d09fe'></a>

43

<!-- PAGE BREAK -->

<a id='8b5e8931-ea65-4f68-961d-a76a36c98c69'></a>

## 3.2 / Factor that will influence Chilean export competitiveness
---

<a id='c6b086d9-5e01-4a52-9163-d9dd16036fdb'></a>

1
Hydrogen roadmaps and decarbonization
targets of main net importer markets of
green hydrogen and derivatives

<a id='419dc1d7-7c0b-497f-ab5c-166c3c1c9685'></a>

2 Chile's production and transportation costs vs potential competitors to serve those markets

<a id='fe44f985-6f45-4efe-a684-7793b4ba1e29'></a>

3 Acceleration of export production capacity development to capture potential market share

<a id='4927803e-660c-4992-ba92-1eb3f1f39984'></a>

Chile's strategic position will depend on the offset between lower production costs and higher transpiration costs

<a id='f33869dc-006d-417c-86ff-8a408a24404d'></a>

<::Production costs (solid light blue square), Transportation costs (dotted square outline): figure::>

<a id='bdfa7874-4098-4179-8321-f488fd13ea6a'></a>

<::Figure: Bar chart comparing 'Cost to market' for Chile and potential competitors. The chart features two light blue bars on a dark background. Above the left bar, which represents Chile, is the flag of Chile. To the right of the flag, above the right bar, is the label "Potential competitors". Both bars have a dashed line indicating a potential higher cost level above their current filled level. The left bar (Chile) shows a lower 'Cost to market' than the right bar (Potential competitors). Two text annotations with arrows explain factors for Chile's cost: an upward arrow points to the dashed upper part of the left bar, accompanied by the text "Relatively uncertain transportation costs could diminish competitiveness". A downward arrow points to the filled lower part of the left bar, accompanied by the text "Considerable lower production costs make Chile more competitive". The x-axis is labeled "Cost to market".:chart::>

<a id='4443627c-f8d9-4286-a39d-8273e5597558'></a>

McKinsey & Company

<a id='b58bb363-8a1f-4104-a942-3470eb8d4a0f'></a>

44

<!-- PAGE BREAK -->

<a id='d053d227-f681-453b-ba94-3ab03cd3d091'></a>

## Chapter 4: hydrogen industry development targets and roadmap

<a id='484e53eb-6091-46dc-b3d4-d5b90a1189b5'></a>

Chapter content description

*   Hydrogen industry targets for National Green Hydrogen Strategy
*   Roadmap for domestic application development in Chile

<a id='44e40bfb-b01c-41b5-bbd7-5451781d9723'></a>

Activities included

- Activity 4.1

<a id='a8e332a1-007f-4b2e-bd43-0d8aadb4e33e'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='7f760a7a-8018-455c-9938-932da16bac26'></a>

McKinsey & Company

<a id='c620168b-5784-4f44-8990-81dcbe0d4a26'></a>

45

<!-- PAGE BREAK -->

<a id='2fceb1cd-5651-4bf5-acb4-a61754013fe0'></a>

4.1 / We aspire that Chile be among the top 5 producers of green hydrogen worldwide and the top 3 exporters; our target is 5 GW of hydrogen capacity under development by 2025, 25 GW by 2030

<a id='466aedd1-e716-4eb4-bd7d-0d23bba6c833'></a>

Hydrogen Roadmap
Aspiration:
Top 5
Global producers
Top 3
Global exporters

Targets: GW of electrolyzer capacity in development
5 GW
by 2025
25 GW
by 2030
<::Hydrogen valleys:
Map of Chile with two marked locations.
Northern hydrogen valley: A blue dot is located in the northern part of Chile.
Southern hydrogen valley: A blue dot is located in the southern part of Chile.
: map::>

<a id='bb7505c6-69aa-4a21-9ff5-193619fc65ba'></a>

McKinsey & Company

<a id='4b8e67d8-f1f9-4277-a5d4-9e7df3acb5e3'></a>

46

<!-- PAGE BREAK -->

<a id='ecf1fd4f-96d4-49bc-8da0-86910954be1b'></a>

## 4.1 / Capturing this opportunity depends on the short term ramp up of domestic applications
Proposed sequencing and timing of application ramp up
---

<a id='e618c2bb-3411-4680-b2fa-cbca770fe818'></a>

Detailed next

**Wave I: 2025**
**Domestic ramp up and export preparation**

3-5¹ GWs

Sequence of steps

Kick start hydrogen industry with large domestic applications with earliest economic breakeven:
* Grey H2 replacement in Oil Refinery application
* Grey ammonia replacement
* Gas blending
* Pilots for mining Haul Trucks and Heavy Duty Trucks

Build knowledge, scale, and infrastructure to move into export opportunities (primarily Green Ammonia)

1. 3 GW for domestic applications and 2 GW additional based on accelerated export opportunities

<a id='6ebd9584-1856-4564-a7ac-e3cae9d2c50e'></a>

Wave II: 2030

<a id='3c21ffa7-a6a5-4f2c-9216-6d181ebd05dd'></a>

Capitalize on export markets

25 GWs

<a id='4ffcc595-1179-4196-b8fc-e8c477186875'></a>

Leverage domestic base to aggressively scale into a relevant player in the most attractive export markets:

First, Green Ammonia export market (principally: Latam, Europe, US and China)

<a id='37b55c27-f9a1-490d-96cd-29633d5cec29'></a>

Second, Green Hydrogen export
market (principally: Europe, Japan /
South Korea, maybe US and China)

<a id='dd7cc035-6297-471a-80b1-abaf8562d2c6'></a>

Wave III: 2035+
Leverage scale to expand
90+ GWs

<a id='0776a440-6426-42dc-921d-839047391d6d'></a>

- Synergies and economies of scale enable expansion into additional domestic applications
- Scale up export to other markets to become a significant supplier of world energy consumption
- Capture opportunities in future technologies and applications of Green Hydrogen and derivatives as they become economical:

<a id='dbae5866-6450-4241-b5d4-5248e74e96cc'></a>

- Synfuel applications (including Jetfuel)
- Ammonia for shipping

<a id='4188466f-0e2c-42e6-96f2-623563fc11cc'></a>

1. 3 GW for domestic applications and 2 GW additional based on accelerated export opportunities

<a id='a32d31a7-6f0e-4801-813e-fd76f47a0c1e'></a>

Source: McKinsey analysis

<a id='b5674b62-4ea8-447e-9128-448c9bc64ed9'></a>

McKinsey & Company

<a id='880e9777-8a76-44f1-b4c5-266667a0132e'></a>

47

<!-- PAGE BREAK -->

<a id='1578aeb3-272b-4d48-8a67-54294006a58d'></a>

4.1 / Optimal sequence and ramp up timeline of applications, corresponding infrastructure and skilled jobs required
Key milestone for the Chilean hydrogen strategy

Pilot and infrastructure launch
Application and infrastructure ramp up

<a id='dfdabb60-40aa-4ece-bdd4-8d66adc14167'></a>

<::chart::>
| | | **Preparation: Today - 2025** | **Capitalize exports: 2025 - 2030** | **Scale up and expansion : 2030 - onwards** |
|---|---|---|---|---|
| | | **Today** | **2025** | **2030** | **2035** | **2040** |
| **Production** | Electrolyzer capacity (GW) | | 3 - 5 | 25 | 90 | 130 |
| **Application uptake** | **Domestic** | | | | | |
| | H2 replac. (oil refinery) | | Substitution of domestic uses -> | -> Substitution of H2 | | |
| | NH3 replacement | | Substitutions of exports -> | -> Substitution of grey NH3 | | |
| | Mining Haul trucks | | Initial bigger scale pilots -> | | -> +80% fleet renovation | |
| | Heavy duty trucks | | Initial bigger scale pilots -> | | -> +80% fleet renovation | |
| | Coaches / Buses | | | Initial bigger scale pilots -> | | -> +80% fleet renovation |
| | Gas Blending | | -> | | -> +15% blending | |
| | **Exports** | | | | | |
| | NH3 exports | Bilateral partnership agreements -> | Initial exports -> | | -> +80% potential captured | |
| | H2 exports | Bilateral partnership agreements -> | | Initial exports -> | | +80% potential captured |
| **Impact** | Killed jobs required - Construction and industry operation | | 30 k | 145 k | +400 k | +400 k |
::>

<a id='83e81d0c-bdcc-43b3-be24-7959f04829aa'></a>

1. Includes investment in energy generation, electrolyzer, transmission and compression, transportation, liquefaction and refueling facilities
Source: DPO; TCO Model; team Analysis

<a id='113338d0-273e-4871-8d65-f4cc23092174'></a>

McKinsey & Company

<a id='63fb6ba3-4b42-45e8-af23-d2943cadf349'></a>

48

<!-- PAGE BREAK -->

<a id='ba88c2c3-a75d-43b6-abf1-b7458937bcb2'></a>

Chapter 5: relevant stakeholders for the hydrogen industry

<a id='ebfbc66d-9a3f-48ed-b5e4-e3e3b05223ff'></a>

Chapter content description

* Map of relevant stakeholders (private and public, domestic and international) who could have an important role in the development of a Chilean hydrogen ecosystem
* Identify enabling factors which could facilitate the engagement of these stakeholder groups in Chile's developing hydrogen ecosystem

<a id='4adba914-7e4d-44aa-b26a-1fad2a3fe875'></a>

Activities
included

* Activity 5.1
* Activity 5.2
* Activity 5.3
* Activity 5.4

<a id='693264c2-e6ca-439f-aa3b-b10df1a3be24'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='e3bdd5d1-1db4-4d41-8648-345188e1551d'></a>

McKinsey & Company

<a id='a18e084c-cb4d-4beb-ad29-d820de610abf'></a>

49

<!-- PAGE BREAK -->

<a id='95a44a59-f914-4939-851e-1acfc8a69c1b'></a>

5.1 & 5.2/ The development of the Chilean hydrogen
ecosystem will depend on 6 key groups of
stakeholders

<a id='c3358142-61e3-4e25-8d61-0a1da08363c4'></a>

**Off-taker group**
Stakeholders that will diminish the risks of
the projects guaranteeing volume demand;
could be also co-investors

<a id='1680fbfb-54b9-4f9e-b3c2-daff572c3c11'></a>

**Ecosystem builders**Responsible for creating the enabling conditions for the hydrogen market<::A circular diagram divided into six colored segments, numbered 1 through 6 clockwise around its perimeter. Each numbered segment corresponds to one of the stakeholder descriptions surrounding the circle.: diagram::>**Financing investors**Funds or banks willing to invest in the energy market in Latin America**Hydrogen production**Responsible for technology and infrastructure development for hydrogen production, transportation and storage**Demand technology developers**Technology developers for different hydrogen applications – demand side (e.g. transportation)**Electricity generation (provider or developer)**Current or new energy generation players that will dedicate resources to hydrogen projects

<a id='b7a8d69d-fc55-4438-8540-d0971619fdbc'></a>

# Key considerations

*   The coordinated actions of different stakeholder groups will allow to accelerate the growth of the hydrogen market by:
    *   Facilitating the creation of the enabling environment for the market to operate
    *   Rapidly acquiring and incorporating the hydrogen technology development to boost demand
    *   Coordinating financing, energy generation and production promoting the development of new projects

<a id='08e3bcfb-4c2e-4339-a44c-e1ee8c363325'></a>

McKinsey & Company

<a id='964f7de2-f4ba-4b36-8e8c-7a68a28b8632'></a>

50

<!-- PAGE BREAK -->

<a id='b382d533-a0a4-4640-855f-90093a2030be'></a>

**5.1 & 5.2/ Stakeholder groups (1/3)**

<a id='df49429f-ed28-4edf-a5d8-ad368fbaee89'></a>

**Not exhaustive**

<a id='db3021b8-7d4f-4d31-bced-4a04892a1b02'></a>

<::transcription of the content: table::>
| Group | Role(s) | Organizations |
|:---|:---|:---|
| | | XX Possible champions |
| Potential off-takers 1 | Off-takers of green hydrogen production for oil refinery | ENAP; Linde |
| | Off-takers of green hydrogen for mining trucks | Codelco, BHP, Anglo-American, Teck, Antofagasta Minerals, SQM, Barrick gold |
| | Off-takers of green hydrogen for inter-urban buses | Turbus, Pullman Bus |
| | Off-takers of green ammonia for explosives | ENAEX |
| | Off-takers of green hydrogen for gas blending | Metrogas, GasValpo, GasSur |
| | Off-takers of green hydrogen and green ammonia exports | Yara, Mosaic; Linde; ThyssenKrupp, APM Maersk, Air Liquid (Airgas), Casale |
<::/transcription of the content: table::>

<a id='02b719d5-a446-4506-8f52-f24714185914'></a>

Financing
and investors

2

<a id='bbca3367-d5db-4f37-aa8c-f46d35beacb5'></a>

Funding for consortiums projects - international cooperation agencies

<a id='29296515-1e83-454f-b1ca-1d6436151fae'></a>

IDB, World Bank, Development Bank of Japan, Green
Climate Fund, KfW, CAF, CIF

<a id='cb288aff-57c1-4709-ae54-7ee27b080aa4'></a>

Funding for consortiums projects – Institutional investors

Pension funds, wealth management, etc.

<a id='0e80d162-b0a4-425b-8898-056243d825c0'></a>

McKinsey & Company

<a id='ea963e25-d44d-4cd9-aa84-0f11551ce94e'></a>

51

<!-- PAGE BREAK -->

<a id='e6548332-cc65-44fd-bce4-8951b6131e68'></a>

5.1 & 5.2/ Stakeholder groups (2/3)

<a id='0371b840-0182-4d5f-bbfd-8722f9e98d60'></a>

<table id="51-1">
<tr><td id="51-2"></td><td id="51-3" colspan="2">Not exhaustive</td></tr>
<tr><td id="51-4">Group</td><td id="51-5">Role(s)</td><td id="51-6">Organizations xx Possible champions</td></tr>
<tr><td id="51-7" rowspan="4">Technology development (number 3 in circle)</td><td id="51-8">Production of FCEVs and hydrogen technology</td><td id="51-9">Hyunday motor company, Toyota, BMW; LIEBHERR; Alset, hydrogenics, Audi, Faurencia, Daimler</td></tr>
<tr><td id="51-a">Production of hydrogen driven mining truck vehicles</td><td id="51-b">Ballard; Caterpillar; Komatsu</td></tr>
<tr><td id="51-c">Development of hydrogen aircrafts</td><td id="51-d">Boeing, GE aviation, Airbus, Safran</td></tr>
<tr><td id="51-e">Development of ammonia ships &amp; vessels</td><td id="51-f">Maersk, Ultramar</td></tr>
<tr><td id="51-g" rowspan="4">Energy generation (number 4 in circle)</td><td id="51-h">Renewable energy generation</td><td id="51-i">Enel, Colbún, AES Gener; Engie, Repsol, EDPR, Statkraft, RWE, Orsted</td></tr>
<tr><td id="51-j">Wind energy generation infrastructure</td><td id="51-k">Vestas, Orsted, Nordex, Siemens, GE</td></tr>
<tr><td id="51-l">Solar energy generation infrastructure</td><td id="51-m">JinkoSolar, SunPower, Hanwha Q Cells</td></tr>
<tr><td id="51-n">Infrastructure required for energy transmission</td><td id="51-o">Transelec</td></tr>
<tr><td id="51-p" rowspan="4">Hydrogen production (number 5 in a circle)</td><td id="51-q">Production of hydrogen technology</td><td id="51-r">Siemens, Cummins, Nel Hydrogen, Hydrogenics, ITM Power</td></tr>
<tr><td id="51-s">Hydrogen production, transport and storage</td><td id="51-t">Total, COPEC group, Repsol, Engie, Air liquid, BP, Nel Hydrogen, Shell, Vopak, ITM power</td></tr>
<tr><td id="51-u">Production of green ammonia and blue fertilizers</td><td id="51-v">Yara, Mosaic, Air Liquid (Airgas), BASF</td></tr>
<tr><td id="51-w">Production of blue methanol</td><td id="51-x">Methanex</td></tr>
</table>

<a id='4dc0069f-96f5-4b13-879d-e33731917d04'></a>

McKinsey & Company

<a id='1a23357f-7d85-4d8d-bc23-d46127281c60'></a>

52

<!-- PAGE BREAK -->

<a id='eff36464-7c96-4886-a964-bfee713e2857'></a>

5.1 & 5.2/ Stakeholder groups (3/3)

<a id='45da7638-8bb7-40e4-8359-2718466ce565'></a>

Not exhaustive

<a id='addf888c-9d4d-4ef0-9cc2-0416755f3464'></a>

<table id="52-1">
<tr><td id="52-2">Group</td><td id="52-3">Role(s)</td><td id="52-4">Organizations XX Possible champions</td></tr>
<tr><td id="52-5" rowspan="11">Ecosystem builder</td><td id="52-6">Coordination and orchestration of different actors - public and private sector Supporting the design of the regulatory framework</td><td id="52-7">Ministry of Energy</td></tr>
<tr><td id="52-8">Facilitating the establishment of international cooperation agreements</td><td id="52-9">Ministry of Foreign Affairs; Embassies at target countries including: Japan, South Korea, China, EU and USA</td></tr>
<tr><td id="52-a">Development of funding lines for initial pilots and feasibility studies via CORFO and promoting the country as an investment destination</td><td id="52-b">Ministry of Economy, Development and Tourism</td></tr>
<tr><td id="52-c">Development of infrastructure studies and coordination with private organizations for infrastructure development</td><td id="52-d">Ministry of public works</td></tr>
<tr><td id="52-e">Promotion of the adoption of green ammonia and low-carbon fertilizers produced with hydrogen</td><td id="52-f">Ministry of agriculture</td></tr>
<tr><td id="52-g">Establishment of environmental requirements and processes for the development of hydrogen projects</td><td id="52-h">Ministry of environment</td></tr>
<tr><td id="52-i">Promoting and coordinating together with universities the research on hydrogen and derivatives</td><td id="52-j">Ministry of Education, Ministry of Science, Technology, Knowledge and Innovation</td></tr>
<tr><td id="52-k">Design the permits for the operation of hydrogen pilots and coordinate the work with companies</td><td id="52-l">Ministry of mining, Ministry of transportation</td></tr>
<tr><td id="52-m">Promotion of research and education on green hydrogen</td><td id="52-n">U. de Chile, PUC, U. de Concepción, U. de Magallanes, U. de Antofagasta, UTFSM</td></tr>
<tr><td id="52-o">International research and development partners</td><td id="52-p">Fraunhofer, Hydrogen Energy Research Center</td></tr>
<tr><td id="52-q">Representation of the private sector and coordination with public entities</td><td id="52-r">Hydrogen council, H2 Chile, Hydrogen Europe, Ammonia Energy Association</td></tr>
</table>

<a id='be475a4d-b4a2-4160-95f2-1419943473db'></a>

McKinsey & Company

<a id='d62f12f1-57ba-4a5b-9350-1266ab443a92'></a>

53

<!-- PAGE BREAK -->

<a id='3ffc55bd-0c85-453b-bb15-7aa9fdf51c73'></a>

5.3/ Conditions which favor the participation of new actors and potential impacts

<a id='028a0ba0-9fd8-40db-93c8-dfa3c7729ec3'></a>

# Conditions which favor new actor participation

## Aspiration, roadmap and strategic priorities
Transparent aspiration and roadmap to show government support for green hydrogen industry development, defined strategic priorities to enable companies to identify and capitalize on strategically aligned opportunities

## Regulation & licensing / permitting
Establishing stable regulatory frameworks which support long term investment and development, are easy to understand (particularly for international players) and have a clear point of contact to field questions and doubts

# Potential impact of new actor participation

## Development of consortiums (supply & demand)
Consortium launch for domestic and international applications (and most likely by both domestic and international players), providing both supply, demand and financing requirements for hydrogen industry launch

## Attraction of international financing
The establishment of consortiums (and in particular, the involvement of international actors) will facilitate the attraction of international financers (ex. national banks may become more interested if national companies are taking part in the consortium or if consortium actors have pre-existing relationships with international financers)

<a id='80ae5fbb-e962-486a-9fad-f5dc84de20dc'></a>

**Effective coordination**
Creating effective communication and coordination through the establishment of specific task forces (responsible for specific targets) and governance structures (responsible for the overall advancement of the roadmap)

**Reduced costs through synergies**
Increased coordination and partnership building will create cost reducing synergies, particularly in infrastructure, which will accelerate green hydrogen industry development

<a id='18d9d57d-d388-4bf3-8c9b-52e2d586dade'></a>

McKinsey & Company

<a id='5e2e0972-71c9-4aa7-9ac4-5ea4ecf1baac'></a>

54

<!-- PAGE BREAK -->

<a id='8497521f-636c-4c7d-8a80-e2937baebf7d'></a>

# 5.4/ Workshop 1: Private
Actors
Workshop for private actors
---


<a id='23737656-44d3-458b-8d30-b0f1946134e0'></a>

# Objectives

Review Chile's National Green Hydrogen Strategy and clarify questions

<a id='48d12478-4c10-4b6d-bb4d-6bdefc974829'></a>

Discuss the principal opportunities, barriers and
demand offtake sources for the establishment of
successful projects in Chile

<a id='feddbaec-454c-4309-860d-aed98c0e0a7a'></a>

Prioritize these opportunities, barriers and demand off-take sources for further development by the Ministry of Energy

<a id='a4096022-1ccb-4866-93e4-0cbbca991143'></a>

Gain visibility on the immediate next steps for the hydrogen industry in Chile

<a id='d79e3f00-bc06-4884-bd0d-9221e2453a09'></a>

# Agenda

1 Introduction 10:00 - 10:05
2 Review Chile's National Green Hydrogen Strategy 10:05 - 10:35
3 Q&A on national strategy 10:35 - 11:00
4 Small group breakout: building a consortium 11:00 - 11:40
5 What's next? 11:40 - 12:00

<a id='79ada1aa-dda5-4710-9720-5709cb84f5a0'></a>

McKinsey & Company

<a id='718a2d3c-4a2d-42c8-822b-cc3c7710debc'></a>

55

<!-- PAGE BREAK -->

<a id='3e187ffa-8c7b-431c-8bbc-629231e1e477'></a>

5.4/ Workshop 1: National Strategy for Hydrogen Breakout group discussion

<a id='c521b554-c662-4556-a88b-4bf6598a58c4'></a>

<::logo: [Unknown]  A simple line-art icon of a person's head and shoulders with a question mark inside the head, in dark blue.::>

<a id='2f6f2e6e-b2e8-4f4b-aeed-c2c4a0d78233'></a>

Breakout group assignments

<a id='bef625c9-5686-468a-8e4d-0a2d688c1d87'></a>

**Consortium A: Ammonia export**
* H2 Chile, Generadoras, Engie, AME, Mitsui, Sumitomo, GasValpo, RWE, Austrian Solar, Siemens, Air Products
* Facilitator: Xavier Costantini; Note taker: Daniela Hermosilla

<a id='48bc0c07-e707-47d4-bc2d-76359938055b'></a>

**Consortium B: Mining sector**
* UTFSM, H2 Chile, Cummins, CAP, COPEC, Transelec, Pacific Hydro, TCI GECOMP, ENAEX
* Facilitator: Clemens Muller-Falcke; Note taker: María José Lambert

<a id='74258c62-2db2-4a88-b35d-f12ed8a761b0'></a>

**Consortium C**: Domestic applications (natural gas, logistics, oil refinery)
* PUC, ACERA, Walmart, Metrogas, COPEC, Lipigas, GasValpo, ENAP, CCU
* Facilitator: Sarah Toupal; Note taker: Benjamín Maluenda

<a id='7abfe169-e04d-448a-a74a-a2cd7237bba3'></a>

# Discussion questions

* Do you believe in the hydrogen opportunity for your consortium (in what timeline?)
* What are the barriers that stand in the way? How can they be overcome?
* What is required to secure demand offtake for your consortium?

<a id='5bbb6589-2a54-47d5-bd05-890ac2464615'></a>

McKinsey & Company

<a id='56eb1df3-21d0-4330-9658-4907f5458e0a'></a>

56

<!-- PAGE BREAK -->

<a id='bbe5d84a-82f5-4f89-bf17-d9a5cae01c1d'></a>

Workshop 2: Public Actors

<a id='8b1a0922-090d-43ee-86cd-cdd9a82c469d'></a>

# Objectives

Introduce Chile's National Green Hydrogen Strategy and clarify questions

<a id='5ab0bb91-cbc1-4a1b-9acc-f001ca8ec049'></a>

Discuss how hydrogen can help support the goals of each government area and what challenges exist to the successful implementation of the strategy

<a id='0e44bf93-59c7-4dd2-95e0-8701174a9b7a'></a>

Gain visibility on the immediate next steps for the hydrogen industry in Chile

<a id='6bf6c1f2-244b-4879-83bf-6a4f7c2da680'></a>

# Agenda

1.  Introduction 9:00 – 9:10
2.  Review Chile’s National Green Hydrogen Strategy 9:10 – 9:40
3.  Q&A on national strategy 9:40 – 10:20
4.  Small group breakout: opportunities and barriers 10:20 – 10:50
5.  What’s next? 10:50 – 11:00

<a id='962bd627-b834-42bb-a64b-4ddd952ca5ca'></a>

McKinsey & Company

<a id='805bcfb3-cacf-4c9b-b502-7e8103901a3f'></a>

57

<!-- PAGE BREAK -->

<a id='b0dadff5-79e5-4277-9ffc-2511b5bd0ed8'></a>

Breakout group discussion

<a id='cac6dea5-30d7-41c9-9e40-e817713ba2c2'></a>

<::Gear icon::>

**Dynamic**
Divide into small groups

<a id='11913b2d-d91d-464a-957c-4cf5389b023a'></a>

**Break out (25 mins)**
* Discuss and answer questions, supported by facilitators

<a id='431c7c2f-05a0-4ed5-80d8-b4d6d22e27de'></a>

**Break out wrap up (5 mins)**
* Facilitators present results from each breakout group

<a id='2cf9e558-fe74-46c8-a3f1-d84de173cd1d'></a>

?
Discussion questions
What opportunities does
hydrogen offer to your area /
institution (how can hydrogen
support your goals)?

<a id='8014cffd-373d-49a7-9f03-a2296a278b2a'></a>

In thinking about your area, what
are the principal challenges you
see in launching the hydrogen
industry in Chile?

<a id='2a15ae38-b05b-4f39-ae50-338160647ea4'></a>

McKinsey & Company

<a id='6010f19a-e0b5-41d6-8f87-f14eb820fad1'></a>

58

<!-- PAGE BREAK -->

<a id='14a6cdbc-8b4e-4e45-89fb-62ef9ee72d3d'></a>

**Proposed template to fill with your teams:** articulate the opportunities and challenges you see for your department across our eight domains for work
Thinking beyond the high level actions outlined in the national strategy...
---

<a id='544c0bf2-40ad-4615-b36b-cbbcd4fc1903'></a>

Name:

Department:

<::transcription of the content
1 Strategy and targets
2 Regulation and licensing / permits
3 Coordination and partnerships
4 Value chain
: figure::>

<a id='1c13448d-62a5-4249-b238-f5ca1e466340'></a>

<::Numbered list of four items, each with a circled number and a label, presented horizontally:
5 Financing and incentives
6 Infrastructure
7 Research & Development
8 Skilled Labor
: list::>

<a id='08c56aa2-e817-4f61-b4f8-1150d2224fb2'></a>

McKinsey & Company

<a id='6e0adaf5-0273-40ce-9159-5040db3d9604'></a>

59

<!-- PAGE BREAK -->

<a id='bacbac6c-cf0e-4cde-aef9-24b16ae22366'></a>

Chapter 6: government role in hydrogen industry development

<a id='a1160c65-54b8-47b6-aa69-0709c3ef5f32'></a>

Chapter content description

*   **Domains of work** required to support and accelerate the development of the hydrogen industry in Chile (both demand and supply) and definition of key design principals
*   **List of actions taken by international governments** to implement the domain of work according to the key design principal
*   **Recommendation of immediate next steps** for government action by domain to accelerate and successful implement the hydrogen industry roadmap

<a id='82cc4408-5871-43ac-9912-d588b9496b0e'></a>

Activities
included

* Activity 6.1
* Activity 6.2
* Activity 6.3
* Activity 6.4

<a id='3158a530-2d3d-469c-9cb3-fe0478db512b'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='13b5f20e-7d0c-4867-a66a-5104b63011f8'></a>

McKinsey & Company

<a id='ee6f3dd8-323b-4a48-a066-2699bdddea4f'></a>

60

<!-- PAGE BREAK -->

<a id='00c079aa-1e20-422f-b15b-c5ac1ceb600b'></a>

6.1-6.4/ The state will support the development of the industry taking action in 8 domains

<a id='1606fda1-ea68-4733-82bb-399d7f41208e'></a>

Not exhaustive

<::Icon of a line graph with an upward trend and a person standing next to it, indicating strategy and targets: figure::> --- Enabling environment

1 Strategy and targets
Establish a clear vision with targets, strategy, and action plan.
Communicate the strategy and play an active role in mobilizing private and public actors in Chile and beyond.

<::Icon of a building with columns, resembling a government building or courthouse, representing regulation and licensing: figure::>

2 Regulation and licensing / permits
Establish a long term regulatory structure which diminishes uncertainty and minimizes barriers to entry / doing business
Accelerates and streamline licensing and permitting processes

<::Icon of two people holding hands, symbolizing coordination and partnerships: figure::>

3 Coordination and partnerships
Coordinate and establish formal partnerships with domestic and international actors to promote industry growth and domestic and international supply chain development

<::Icon of a chain link, representing the value chain: figure::>

4 Value chain
Maximize value creation and economic development in Chile identifying where the opportunities are for domestic industry along the value chain and putting the right enablers in place

<::Icon of stacked coins and a dollar sign, indicating financing and incentives: figure::>

5 Financing and incentives
Provide sources of funding directly and facilitate access to inexpensive capital
Deployment incentives (production and demand)

<::Icon of connected pipes, symbolizing infrastructure: figure::>

6 Infrastructure
Promote infrastructure developments via PPPs and collaboration among actors to capture infrastructure synergies

<::Icon of a magnifying glass over a gear, representing research and development: figure::>

7 Research & Development
Promote research projects on hydrogen technologies both nationally and with international partners

<::Icon of a person wearing a graduation cap, signifying skilled labor: figure::>

8 Skilled Labor
Develop local talent and skills required for H2 production, refueling, storage, etc.

<a id='5a0f8b0a-9562-49fc-af56-cc616757eeb9'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='6a6a4ebe-0c98-48b5-bdbd-06e4859804e7'></a>

McKinsey & Company

<a id='6b347d80-0448-4bf5-b7db-f7a5bb6a1f67'></a>

61

<!-- PAGE BREAK -->

<a id='9bf8c952-f4e5-4151-a2d2-e751469c65b2'></a>

6.1-6.4/ Enabling actions (1/4)

<a id='2f299dad-58d5-4914-aaca-b7ff8fbeeac0'></a>

Not exhaustive

<a id='633f6aa9-4c17-4191-91d8-1947858137eb'></a>

Not exhaustive
<table id="61-1">
<tr><td id="61-2">Domain</td><td id="61-3">Key design principles</td><td id="61-4">Examples of actions seen in other places</td></tr>
<tr><td id="61-5">Vision &amp; targets</td><td id="61-6">Set clear ambition and direction Create strategy, clear targets and an action plan to support ambition Actively mobilize public and private actors to realize defined strategy (in Chile an internationally) Communicate the benefits of the plan to the society in general</td><td id="61-7">Define national aspiration backed by strategy, targets and action plan, including priorities for industry development and the role of the government and industry actors Mobilize public and private actors to capture strategic opportunities aligned with the aspiration (ex. developing off taker markets, facilitating international financing etc...) Understand the full economic and social impact of the Hydrogen strategy (both supply and demand side) Create the socialization and engagement strategy for the society in general</td></tr>
<tr><td id="61-8">Regulation</td><td id="61-9">Diminish the uncertainty to invest in new projects Facilitate market access Establish safety standards Lay down environmental requirements</td><td id="61-a">Formulate the regulatory framework and protocols for safe production, storage and transportation of hydrogen Establish the rules for grid integration and remuneration for energy production and grid stabilization Create a certification scheme or guarantee of origin to recognize greener supply chains that use green hydrogen</td></tr>
<tr><td id="61-b">Licenses/ permits</td><td id="61-c">Establish clear requirements Design transparent and fast processes Reduce bureaucracy</td><td id="61-d">Establish clear and transparent rules and processes for license granting for H2 projects (plants, refueling stations, storage, etc.) Design a streamlined and transparent application process with clear steps and one only central point of contact Facilitate licenses to access to water sources</td></tr>
</table>

<a id='f0cc0a1a-81ca-42ca-80e0-d3f42332adeb'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='f3e21c6d-56b2-4ce3-93d8-edf6fed196ac'></a>

McKinsey & Company

<a id='4eae8a6f-0861-4072-9fa9-d362ead6eaa1'></a>

62

<!-- PAGE BREAK -->

<a id='cf977183-6715-4faa-99f9-c4e7487789df'></a>

6.1-6.4/ Enabling actions (2/4)

<a id='7f852d1c-09ab-4896-a0e2-2d670eb4685b'></a>

Not exhaustive

<a id='8f3bd15b-f6bb-4117-b439-e2e3d3fd8f38'></a>

Not exhaustive

<a id='7b1285ba-7b5f-40e4-8205-4ca261330077'></a>

<table id="62-1">
<tr><td id="62-2">Domain</td><td id="62-3">Key design principles</td><td id="62-4">Examples of actions seen in other places</td></tr>
<tr><td id="62-5">Coordination with local actors</td><td id="62-6">Orchestrate the efforts of different actors Capture potential synergies between actions Balance H2 supply and demand growth</td><td id="62-7">Create a task force to lead the implementation of the strategy and the orchestration with the different sectors Coordinate the procurement activities of industry actors to promote bulk purchases of different technologies (e.g. buses, HDT)</td></tr>
<tr><td id="62-8">Partnerships with technology providers and investors</td><td id="62-9">Establish partnerships with equipment providers to attract and incorporate new technologies</td><td id="62-a">Establish partnership with PV / Wind energy developers and electrolyzer producers to acquire equipment through bulk / long term contracts, including the attraction of production or assembly lines in Chile Establish consortiums with national and international ammonia and fertilizers producers to attract investments (e.g. mosaic, yara) Establish partnerships with technology producers (e.g. hyundai, caterpillar) to support the technology development and attract early pilots to the country</td></tr>
<tr><td id="62-b">Country to country partnerships</td><td id="62-c">Facilitate market access for exports / imports</td><td id="62-d">Establish free trade agreements and country-to-country collaboration partnerships to facilitate imports / exports of technology and products</td></tr>
<tr><td id="62-e">Value chain development</td><td id="62-f">Identify strategic opportunities for economic development in the value chain (upstream and downstream) Create mechanisms which support local value chain development</td><td id="62-g">Map green hydrogen value chain activities, both upstream and downstream, prioritizing opportunities based on attractiveness (e.g. size and value-added) and fit with local capabilities and advantages Develop a &quot;Zona de franca&quot;: North &amp; South to attract manufacturing investment and develop domestically value adding activities of the supply chain</td></tr>
</table>

<a id='10633113-b20d-4f54-ae1d-e2faa9b8b09a'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='7ecafad8-946f-485f-a19c-3cb93a9a0109'></a>

McKinsey & Company

<a id='96771bca-42bc-48f1-b7cb-861bff3aab33'></a>

63

<!-- PAGE BREAK -->

<a id='796a2e96-7f08-4daa-bd59-7e1a1c314e9f'></a>

6.1-6.4/ Enabling actions (3/4)

<a id='a0133a0e-6791-4c6b-8730-68b9b9749722'></a>

Not exhaustive

<a id='15241845-1ddd-42e9-8781-a01b11914405'></a>

Not exhaustive

<a id='f8455869-ac41-4167-94d9-9b268dfe2020'></a>

<table><thead><tr><th>Domain</th><th>Key design principles</th><th>Examples of actions seen in other places</th></tr></thead><tbody><tr><td>5 Financing</td><td>Provide cheap financing for early proof-of-concepts and pilots to accelerate industry growth without creating industry dependence on government support<br>Attract projects and investments with high scale-up potential and secure long term contracts (potential lock-ins)<br>Protect private investor rights</td><td>Coordinate actors from the financial sectors to establish investment lines for the development of the hydrogen ecosystem<br>Provide financial support for initial feasibility studies with commitment for further scale-up without government financing<br>Create financing lines for the initial construction of green ammonia and blue urea factories<br>Fund pilot projects to test technologies in key applications (mining, transport, H2 replacement, gas blending, etc.) with potential further development without government funding<br>Establish financing lines for fleet renovation (e.g. buses, HDT) with FCEV and/or for shared refueling station at key hubs<br>Advocate for regulation which reduces risks for the deployment of capital for green hydrogen projects in Chile</td></tr><tr><td>Incentives</td><td>Support initial investments in sectors with higher potential of long-term socio-economic gains<br>Apply the most efficient tools to anticipate the industry development without creating industry dependence on government support</td><td>Permit hydrogen producers to use the grid for transmission at marginal costs (not full cost)<br>Create carbon bonds for green energy producers and carbon capture in urea production<br>Create a Carbon tax per ton of CO2 for transport applications<br>Establish royalties abatements for mining companies to incentive investment in FCEV (haul trucks and HDT) - for a limited period of time<br>Import duty on grey ammonia and derivatives<br>Increase subsidies for green fertilizers in the market<br>Establish emissions standards for vehicles and incentives for FCEVs</td></tr></tbody></table>

<a id='7d56d216-f927-49b7-b87e-ffe3913c3d1e'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='8730a3dc-33b3-41d5-a9fd-8b4e0e373f4a'></a>

McKinsey & Company

<a id='d3d391d0-aec7-427a-a531-424df13769b2'></a>

64

<!-- PAGE BREAK -->

<a id='9d0c9946-c897-4225-ab35-c3515e91f343'></a>

6.1-6.4/ Enabling actions (4/4)

<a id='0b669c6c-331e-494b-9595-50f9196299ad'></a>

Not exhaustive

<a id='478ee32f-ea17-4ca9-bbac-2fe5c0d5bf94'></a>

Not exhaustive
<table id="64-1">
<tr><td id="64-2">Domain</td><td id="64-3">Key design principles</td><td id="64-4">Examples of actions seen in other places</td></tr>
<tr><td id="64-5">6 Infrastructure</td><td id="64-6">Facilitate infrastructure development to enable hydrogen / derivative supply and demand Capture synergies in infrastructure development Leverage infrastructure already in place</td><td id="64-7">Establish protocols and rules for repurposing of existing infrastructure (ports, pipelines, etc.) Develop pipeline network for hydrogen and ammonia transport (from production to utilization sites) Develop port infrastructure and road transportation routes via PPPs Build transmission line infrastructure at scale Facilitate the installation of refueling stations at key hubs (e.g. bus terminals, ports, etc.) Reinforce the Infrastructure of key cities / regions to make them more attractive for skilled people</td></tr>
<tr><td id="64-8">7 Research &amp; development</td><td id="64-9">Enable rapid technology development, transfer and adoption Partner with other governments to conduct joint R&amp;D on key topics for Chilean H2 development</td><td id="64-a">Create a research center for green hydrogen that promotes and coordinate research efforts between among bodies and companies Create lines of funding for research (e.g. Fondecyt) on hydrogen related issues at universities and R&amp;D centers of companies Develop research projects together with international research centers / universities on key issues for the Chilean hydrogen economy</td></tr>
<tr><td id="64-b">8 Skilled Labor</td><td id="64-c">Prepare sound technical experts for the industry Give job opportunities to disadvantage communities Promote gender equality</td><td id="64-d">Promote programs and courses on hydrogen related topics in universities and technical centers Support worker training and educational programs in hydrogen production centers, refueling stations, storage points, among others</td></tr>
</table>

<a id='a7990c6d-ecf4-4892-9969-9135c0e484e5'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='ded5a851-8eac-4926-80b3-df49ef4304b8'></a>

McKinsey & Company

<a id='07b97434-2f54-4e11-b8a1-da7824fd815c'></a>

65