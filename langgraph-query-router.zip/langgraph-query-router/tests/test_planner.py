"""Tests for skill registry, state models, and graph routing logic."""

from __future__ import annotations

from pathlib import Path

import pytest

from app.state import PlanStep, StepResult, StepStatus, RouterState
from app.skill_registry import SkillRegistry, _parse_skill_md
from app.graph import _route_after_execute


# ---------------------------------------------------------------------------
# Skill registry
# ---------------------------------------------------------------------------

SAMPLE_SKILL_MD = """\
---
name: test_skill
description: A test skill
trigger: when user says test
category: data_source
parameters:
  - name: query
    type: string
    required: true
    description: The question
---

# Test Skill body
"""


def test_parse_skill_md(tmp_path: Path):
    (tmp_path / "SKILL.md").write_text(SAMPLE_SKILL_MD)
    m = _parse_skill_md(tmp_path / "SKILL.md")
    assert m is not None
    assert m.name == "test_skill"
    assert m.category == "data_source"
    assert len(m.parameters) == 1
    assert m.parameters[0].required is True


def test_parse_missing_frontmatter(tmp_path: Path):
    (tmp_path / "SKILL.md").write_text("# No frontmatter")
    assert _parse_skill_md(tmp_path / "SKILL.md") is None


def test_registry_discovery(tmp_path: Path):
    for name in ["a", "b"]:
        d = tmp_path / name
        d.mkdir()
        (d / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: {name}\ncategory: test\n---\n# {name}\n"
        )
    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    assert len(reg.list_all()) == 2
    assert reg.get("a") is not None
    assert reg.get("nonexistent") is None


def test_registry_summary_has_categories(tmp_path: Path):
    for name, cat in [("ds", "data_source"), ("ws", "search")]:
        d = tmp_path / name
        d.mkdir()
        (d / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: desc\ncategory: {cat}\n---\n# x\n"
        )
    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    summary = reg.summary_for_planner()
    assert "### data_source" in summary
    assert "### search" in summary


# ---------------------------------------------------------------------------
# State model
# ---------------------------------------------------------------------------

def test_plan_step_roundtrip():
    s = PlanStep(step_id=1, description="test", skill_name="web_search",
                 query="q", depends_on=[])
    assert s.skill_name == "web_search"
    assert s.depends_on == []


def test_step_result_defaults():
    r = StepResult(step_id=1)
    assert r.status == StepStatus.PENDING
    assert r.data is None


# ---------------------------------------------------------------------------
# Graph routing logic
# ---------------------------------------------------------------------------

def _make_state(**overrides) -> RouterState:
    base: RouterState = {
        "question": "test",
        "context": {},
        "reasoning": "",
        "plan_steps": [],
        "step_results": [],
        "completed_ids": set(),
        "answer": "",
        "error": "",
    }
    base.update(overrides)
    return base


def test_route_empty_plan():
    """Empty plan → synthesize."""
    state = _make_state()
    assert _route_after_execute(state) == "synthesize"


def test_route_error():
    """Error in state → synthesize."""
    state = _make_state(error="something broke")
    assert _route_after_execute(state) == "synthesize"


def test_route_all_done():
    """All steps completed → synthesize."""
    steps = [PlanStep(step_id=1, description="x", skill_name="a", query="q")]
    state = _make_state(plan_steps=steps, completed_ids={1})
    assert _route_after_execute(state) == "synthesize"


def test_route_ready_steps():
    """Step with no deps, not yet run → execute."""
    steps = [PlanStep(step_id=1, description="x", skill_name="a", query="q")]
    state = _make_state(plan_steps=steps, completed_ids=set())
    assert _route_after_execute(state) == "execute"


def test_route_blocked_steps():
    """Step depends on uncompleted step → synthesize (stuck)."""
    steps = [
        PlanStep(step_id=1, description="x", skill_name="a", query="q"),
        PlanStep(step_id=2, description="y", skill_name="b", query="q", depends_on=[1]),
    ]
    # Step 1 not in completed, step 2 depends on 1 → nothing is ready
    # But step 1 IS ready (no deps, not completed)
    state = _make_state(plan_steps=steps, completed_ids=set())
    assert _route_after_execute(state) == "execute"


def test_route_second_wave():
    """Step 1 done, step 2 depends on 1 → execute step 2."""
    steps = [
        PlanStep(step_id=1, description="x", skill_name="a", query="q"),
        PlanStep(step_id=2, description="y", skill_name="b", query="q", depends_on=[1]),
    ]
    state = _make_state(plan_steps=steps, completed_ids={1})
    assert _route_after_execute(state) == "execute"


def test_route_stuck_deps():
    """Step 2 depends on step 1, but step 1 failed and step 2 can't run → synthesize."""
    steps = [
        PlanStep(step_id=1, description="x", skill_name="a", query="q"),
        PlanStep(step_id=2, description="y", skill_name="b", query="q", depends_on=[1]),
    ]
    # Step 1 completed (even if failed), step 2 deps met → execute
    state = _make_state(plan_steps=steps, completed_ids={1})
    assert _route_after_execute(state) == "execute"

    # Both completed → synthesize
    state2 = _make_state(plan_steps=steps, completed_ids={1, 2})
    assert _route_after_execute(state2) == "synthesize"
