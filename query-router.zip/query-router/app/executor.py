"""Executor: runs an ExecutionPlan by invoking skills.

Every step dispatches to a skill's `run.py` (or `run.sh`) via subprocess.
Independent steps run concurrently; dependent steps wait for upstream results.
"""

from __future__ import annotations

import asyncio
import json
import logging
import pathlib
import sys
from typing import Any

from app.config import settings
from app.models import ExecutionPlan, PlanStep, StepResult, StepStatus
from app.skill_registry import registry

logger = logging.getLogger(__name__)


class Executor:
    async def execute(self, plan: ExecutionPlan) -> list[StepResult]:
        """Execute all steps in *plan*, returning results in step_id order."""

        results: dict[int, StepResult] = {
            step.step_id: StepResult(step_id=step.step_id, skill_name=step.skill_name)
            for step in plan.steps
        }

        # Build adjacency: step_id → set of step_ids that depend on it
        dependents: dict[int, set[int]] = {s.step_id: set() for s in plan.steps}
        for step in plan.steps:
            for dep_id in step.depends_on:
                dependents[dep_id].add(step.step_id)

        # Track remaining in-degree
        in_degree = {s.step_id: len(s.depends_on) for s in plan.steps}
        step_map = {s.step_id: s for s in plan.steps}

        ready: asyncio.Queue[int] = asyncio.Queue()
        for sid, deg in in_degree.items():
            if deg == 0:
                await ready.put(sid)

        completed = 0
        total = len(plan.steps)

        async def worker() -> None:
            nonlocal completed
            while completed < total:
                try:
                    sid = await asyncio.wait_for(ready.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                step = step_map[sid]
                result = results[sid]
                result.status = StepStatus.RUNNING

                # Inject upstream results into the query template
                self._inject_upstream(step, results)

                try:
                    data = await self._run_skill(step, results)
                    result.data = data
                    result.status = StepStatus.SUCCESS
                except Exception as exc:
                    logger.exception("Step %s (%s) failed", sid, step.skill_name)
                    result.error = str(exc)
                    result.status = StepStatus.FAILED

                completed += 1

                for dep_sid in dependents.get(sid, set()):
                    in_degree[dep_sid] -= 1
                    if in_degree[dep_sid] == 0:
                        await ready.put(dep_sid)

        workers = [
            asyncio.create_task(worker())
            for _ in range(min(settings.max_parallel_steps, total))
        ]
        await asyncio.gather(*workers)

        return [results[s.step_id] for s in plan.steps]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _inject_upstream(self, step: PlanStep, results: dict[int, StepResult]) -> None:
        """Replace {step_N_results} placeholders in the query with actual data."""
        for dep_id in step.depends_on:
            dep_result = results[dep_id]
            placeholder = "{" + f"step_{dep_id}_results" + "}"
            if placeholder in step.query:
                step.query = step.query.replace(
                    placeholder,
                    json.dumps(dep_result.data, default=str),
                )

    async def _run_skill(
        self, step: PlanStep, results: dict[int, StepResult]
    ) -> Any:
        """Invoke a skill's runner script via subprocess.

        Convention:
        - Skill folder contains `run.py` (or `run.sh`)
        - Receives JSON on stdin:
            {
                "query": "...",
                "parameters": {...},
                "upstream": { "step_1_results": ..., "step_2_results": ... }
            }
        - Writes JSON (or plain text) to stdout
        """
        manifest = registry.get(step.skill_name)
        if not manifest:
            raise ValueError(f"Unknown skill: {step.skill_name}")

        folder = pathlib.Path(manifest.folder_path)
        runner = folder / "run.py"
        if not runner.exists():
            runner = folder / "run.sh"
        if not runner.exists():
            raise FileNotFoundError(
                f"No run.py or run.sh in skill folder: {folder}"
            )

        # Build upstream context from dependent steps
        upstream: dict[str, Any] = {}
        for dep_id in step.depends_on:
            upstream[f"step_{dep_id}_results"] = results[dep_id].data

        payload = {
            "query": step.query,
            "parameters": step.parameters,
            "upstream": upstream,
        }

        cmd = (
            [sys.executable, str(runner)]
            if runner.suffix == ".py"
            else ["bash", str(runner)]
        )

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(folder),
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=json.dumps(payload).encode()),
            timeout=settings.skill_timeout_seconds,
        )

        if proc.returncode != 0:
            raise RuntimeError(
                f"Skill '{step.skill_name}' exited {proc.returncode}: {stderr.decode()}"
            )

        raw = stdout.decode().strip()
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw
