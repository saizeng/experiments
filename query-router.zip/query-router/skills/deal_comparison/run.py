#!/usr/bin/env python3
"""Stub skill runner for deal comparison — replace with real logic."""

import json
import sys


def main():
    payload = json.load(sys.stdin)
    deal_ids = payload.get("deal_ids", [])
    dimensions = payload.get("dimensions") or ["valuation", "structure", "timeline", "risk"]

    result = {
        "comparison_table": [
            {"deal_id": did, "dimensions": {d: "N/A" for d in dimensions}}
            for did in deal_ids
        ],
        "summary": f"Stub comparison of {len(deal_ids)} deals across {len(dimensions)} dimensions.",
        "deals_analyzed": len(deal_ids),
    }

    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
