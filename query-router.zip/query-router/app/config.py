from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # LLM
    anthropic_api_key: str = ""
    planner_model: str = "claude-sonnet-4-20250514"
    synthesizer_model: str = "claude-sonnet-4-20250514"

    # Data source endpoints
    structured_api_url: str = "http://localhost:9001/chat"
    structured_api_key: str = ""
    unstructured_api_url: str = "http://localhost:9002/chat"
    unstructured_api_key: str = ""

    # Skills
    skills_dir: str = "./skills"

    # Execution
    max_parallel_steps: int = 5
    planner_timeout_seconds: int = 30
    executor_timeout_seconds: int = 120

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
