"""Synthesizer node: merges results from all skill executions.

Single successful step → return data directly (skip LLM call).
Multiple steps or mixed results → LLM reconciliation.
"""

from __future__ import annotations

import json
import logging

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, SystemMessage

from app.config import settings
from app.state import RouterState, StepStatus

logger = logging.getLogger(__name__)

SYNTHESIZER_SYSTEM = """\
You are a financial services assistant synthesizing information from
multiple data sources and tools to answer a user's question.

You will receive:
- The original user question
- The execution plan (which skills were invoked and why)
- The results from each step

Your job:
1. Merge and reconcile all step results into a single, coherent answer.
2. If any step failed, note what information is missing and answer with
   what you have.
3. Be precise with numbers and cite which source provided which fact.
4. If results conflict, flag the discrepancy.
5. Keep the answer concise and well-structured.
"""


async def synthesize_node(state: RouterState) -> dict:
    """LangGraph node: produce the final answer."""

    results = state.get("step_results", [])
    plan_steps = state.get("plan_steps", [])

    # Fast path: single successful step
    successful = [r for r in results if r.status == StepStatus.SUCCESS]
    if len(results) == 1 and len(successful) == 1:
        return {"answer": str(successful[0].data)}

    # Build context for LLM
    step_map = {s.step_id: s for s in plan_steps}
    summaries: list[str] = []
    for r in results:
        step = step_map.get(r.step_id)
        desc = step.description if step else f"Step {r.step_id}"
        skill = step.skill_name if step else r.skill_name
        data_str = (
            json.dumps(r.data, indent=2, default=str)
            if r.data is not None
            else "(no data)"
        )
        error_str = f"\n  Error: {r.error}" if r.error else ""
        summaries.append(
            f"### Step {r.step_id}: {desc}\n"
            f"Skill: {skill}\n"
            f"Status: {r.status.value}{error_str}\n"
            f"Result:\n{data_str}"
        )

    user_content = (
        f"## Original Question\n{state['question']}\n\n"
        f"## Plan Reasoning\n{state.get('reasoning', '')}\n\n"
        f"## Step Results\n\n" + "\n\n".join(summaries)
    )

    llm = ChatAnthropic(
        model=settings.synthesizer_model,
        api_key=settings.anthropic_api_key,
        temperature=0,
        max_tokens=4096,
    )

    response = await llm.ainvoke([
        SystemMessage(content=SYNTHESIZER_SYSTEM),
        HumanMessage(content=user_content),
    ])

    return {"answer": response.content.strip()}
