"""LangGraph state schema.

This TypedDict defines the full state that flows through every node
in the graph. LangGraph persists and updates this between steps.
"""

from __future__ import annotations

from enum import Enum
from typing import Annotated, Any

from langgraph.graph import add_messages
from pydantic import BaseModel, Field
from typing_extensions import TypedDict


# ---------------------------------------------------------------------------
# Sub-models used inside state
# ---------------------------------------------------------------------------

class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"


class PlanStep(BaseModel):
    """A single step in the execution plan."""
    step_id: int
    description: str
    skill_name: str
    query: str
    depends_on: list[int] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(default_factory=dict)


class StepResult(BaseModel):
    """Result from executing one step."""
    step_id: int
    skill_name: str = ""
    status: StepStatus = StepStatus.PENDING
    data: Any = None
    error: str | None = None


# ---------------------------------------------------------------------------
# Graph state
# ---------------------------------------------------------------------------

class RouterState(TypedDict):
    """Full state flowing through the LangGraph graph.

    Keys:
        question: The original user question.
        context: Optional session context from the caller.
        reasoning: Planner's chain-of-thought.
        plan_steps: List of planned steps (set by planner node).
        step_results: Accumulated results (appended by executor node).
        completed_ids: Set of step_ids that have finished.
        answer: Final synthesized answer (set by synthesizer node).
        error: Top-level error message if the pipeline fails.
    """
    question: str
    context: dict[str, Any]
    reasoning: str
    plan_steps: list[PlanStep]
    step_results: list[StepResult]
    completed_ids: set[int]
    answer: str
    error: str
