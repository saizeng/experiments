"""LangGraph graph: plan → execute (loop) → synthesize."""

from __future__ import annotations

import logging

from langgraph.graph import END, START, StateGraph

from app.nodes.executor import execute_node
from app.nodes.planner import plan_node
from app.nodes.synthesizer import synthesize_node
from app.state import RouterState

logger = logging.getLogger(__name__)


def _route_after_execute(state: RouterState) -> str:
    if state.get("error"):
        return "synthesize"

    plan_steps = state.get("plan_steps", [])
    if not plan_steps:
        return "synthesize"

    completed = state.get("completed_ids", set())
    if completed >= {s.step_id for s in plan_steps}:
        return "synthesize"

    for step in plan_steps:
        if step.step_id not in completed:
            if all(dep in completed for dep in step.depends_on):
                return "execute"

    logger.warning("Stuck steps — proceeding to synthesize")
    return "synthesize"


def build_graph():
    graph = StateGraph(RouterState)
    graph.add_node("plan", plan_node)
    graph.add_node("execute", execute_node)
    graph.add_node("synthesize", synthesize_node)

    graph.add_edge(START, "plan")
    graph.add_conditional_edges("plan", _route_after_execute, {"execute": "execute", "synthesize": "synthesize"})
    graph.add_conditional_edges("execute", _route_after_execute, {"execute": "execute", "synthesize": "synthesize"})
    graph.add_edge("synthesize", END)

    return graph.compile()


router_graph = build_graph()
