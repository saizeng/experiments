"""
Stub implementation for Capital IQ retrieval.
Replace this with real API integration.
"""

from typing import Dict, Optional


def run_capitaliq(query: str, company_name: Optional[str] = None) -> Dict:
    return {
        "company": company_name or "Example Company",
        "confidence": "medium",
        "data": {
            "note": "Replace this stub with Capital IQ API logic.",
            "query_received": query,
        },
        "references": [
            {
                "source": "Capital IQ",
                "id": "example-id",
                "title": "Example Capital IQ record",
            }
        ],
    }
