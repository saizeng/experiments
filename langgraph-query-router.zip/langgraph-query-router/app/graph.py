"""LangGraph graph definition.

Builds the stateful graph:

    START → plan → route_or_done → execute → route_or_done → ... → synthesize → END

The `route_or_done` conditional edge checks whether there are still
unfinished steps with satisfied dependencies. If yes, it loops back
to `execute`. If all steps are done (or the plan is empty), it
proceeds to `synthesize`.
"""

from __future__ import annotations

import logging

from langgraph.graph import END, START, StateGraph

from app.nodes.executor import execute_node
from app.nodes.planner import plan_node
from app.nodes.synthesizer import synthesize_node
from app.state import RouterState

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Conditional edge: are there more steps to execute?
# ---------------------------------------------------------------------------

def _route_after_execute(state: RouterState) -> str:
    """Decide whether to loop back to execute or proceed to synthesize.

    Returns:
        "execute"    — there are steps whose deps are met but haven't run yet
        "synthesize" — all steps are done (or plan is empty / errored)
    """
    # If planning failed, go straight to synthesize (it will surface the error)
    if state.get("error"):
        return "synthesize"

    plan_steps = state.get("plan_steps", [])
    if not plan_steps:
        return "synthesize"

    completed = state.get("completed_ids", set())
    total = {s.step_id for s in plan_steps}

    # All done?
    if completed >= total:
        return "synthesize"

    # Any step whose deps are all met but hasn't run?
    for step in plan_steps:
        if step.step_id not in completed:
            if all(dep in completed for dep in step.depends_on):
                return "execute"

    # Remaining steps have unmet deps that will never be satisfied
    # (upstream failed) — give up and synthesize what we have
    logger.warning(
        "Stuck steps detected: completed=%s, total=%s",
        completed, total,
    )
    return "synthesize"


# ---------------------------------------------------------------------------
# Graph builder
# ---------------------------------------------------------------------------

def build_graph() -> StateGraph:
    """Construct and compile the LangGraph state machine."""

    graph = StateGraph(RouterState)

    # Nodes
    graph.add_node("plan", plan_node)
    graph.add_node("execute", execute_node)
    graph.add_node("synthesize", synthesize_node)

    # Edges
    graph.add_edge(START, "plan")
    graph.add_conditional_edges(
        "plan",
        _route_after_execute,
        {"execute": "execute", "synthesize": "synthesize"},
    )
    graph.add_conditional_edges(
        "execute",
        _route_after_execute,
        {"execute": "execute", "synthesize": "synthesize"},
    )
    graph.add_edge("synthesize", END)

    return graph.compile()


# Module-level compiled graph
router_graph = build_graph()
