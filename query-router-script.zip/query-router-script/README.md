# Query Router & Planner (LangGraph + Chat UI)

An intelligent query routing system built on **LangGraph** with a built-in
**chat interface** and conversation history.

Every capability — structured data, document search, web search, report
generation — is a **skill**: a folder with a `SKILL.md` manifest and a
Python module exporting an async `run(query, parameters, upstream)` function.

## Architecture

```
┌─────────────────────────────────────────────────┐
│  Chat UI (FastAPI + HTML/JS)                    │
│  Conversation history, streaming, dark mode     │
└──────────────────┬──────────────────────────────┘
                   │ POST /chat
                   ▼
┌─────────────────────────────────────────────────┐
│  LangGraph State Machine                        │
│                                                 │
│  START → plan → route → execute ──┐             │
│                    ▲    (parallel) │             │
│                    └──────────────┘             │
│                    route → synthesize → END     │
└──────────────────┬──────────────────────────────┘
                   │ invokes directly
                   ▼
┌─────────────────────────────────────────────────┐
│  Skill Registry (auto-discovered SKILL.md)      │
│  ┌──────────────┐ ┌──────────────┐              │
│  │structured    │ │unstructured  │              │
│  │_data.run()   │ │_docs.run()   │  ...         │
│  └──────────────┘ └──────────────┘              │
└─────────────────────────────────────────────────┘
```

## Quick Start

```bash
pip install -e ".[dev]"
cp .env.example .env        # add ANTHROPIC_API_KEY
uvicorn app.main:app --reload
# Open http://localhost:8000 in your browser
```

## Skill Contract

Each skill is a Python module with an async `run` function:

```python
# skills/my_skill/run.py

async def run(query: str, parameters: dict, upstream: dict) -> dict:
    \"\"\"
    Args:
        query: The sub-question routed by the planner.
        parameters: Extra params from the plan step.
        upstream: Results from prior dependent steps.
    Returns:
        dict with the skill's response.
    \"\"\"
    # your logic here
    return {"answer": "..."}
```

No stdin/stdout. No subprocess. Direct async Python call.
