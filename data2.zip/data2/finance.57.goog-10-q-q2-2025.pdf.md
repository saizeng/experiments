<a id='4a178584-2785-41d9-af55-d774d68f9ecd'></a>

UNITED STATES
SECURITIES AND EXCHANGE COMMISSION
Washington, D.C. 20549
---


<a id='fbe8bfe1-2007-4955-90a6-17613e573f7b'></a>

FORM 10-Q

<a id='3da80bbc-95a5-4183-9f06-98a2c48703ec'></a>

(Mark One)

option QUARTERLY REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934: [x]
For the quarterly period ended June 30, 2025
OR
option TRANSITION REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934: [ ]
For the transition period from --- to ---
Commission file number: 001-37580

<a id='fc2c11af-dbfa-4ed4-8185-11b0e5cb1bbf'></a>

**Alphabet Inc.**
(Exact name of registrant as specified in its charter)

---


<a id='5d6824ee-437d-4d3a-80cd-adf2fc3b6a6a'></a>

Delaware
(State or other jurisdiction of incorporation or organization)

61-1767919
(I.R.S. Employer Identification Number)

<a id='af2d5d2f-3f58-47da-994e-e1b1ebe47228'></a>

**1600 Amphitheatre Parkway**
**Mountain View, CA 94043**
(Address of principal executive offices, including zip code)
**(650) 253-0000**
(Registrant's telephone number, including area code)

<a id='85cc074f-d331-4a61-a185-9cc3af414530'></a>

Securities registered pursuant to Section 12(b) of the Act:

<table><thead><tr><th>Title of each class</th><th>Trading Symbol(s)</th><th>Name of each exchange on which registered</th></tr></thead><tbody><tr><td>Class A Common Stock, $0.001 par value</td><td>GOOGL</td><td>Nasdaq Stock Market LLC<br>(Nasdaq Global Select Market)</td></tr><tr><td>Class C Capital Stock, $0.001 par value</td><td>GOOG</td><td>Nasdaq Stock Market LLC<br>(Nasdaq Global Select Market)</td></tr><tr><td>2.500% Senior Notes due 2029</td><td>—</td><td>Nasdaq Stock Market LLC</td></tr><tr><td>3.000% Senior Notes due 2033</td><td>—</td><td>Nasdaq Stock Market LLC</td></tr><tr><td>3.375% Senior Notes due 2037</td><td>—</td><td>Nasdaq Stock Market LLC</td></tr><tr><td>3.875% Senior Notes due 2045</td><td>—</td><td>Nasdaq Stock Market LLC</td></tr><tr><td>4.000% Senior Notes due 2054</td><td>—</td><td>Nasdaq Stock Market LLC</td></tr></tbody></table>

<a id='b84eedb7-a3de-45a9-8bd2-b9a0ad0d1804'></a>

Indicate by check mark whether the registrant: (1) has filed all reports required to be filed by Section 13 or 15(d) of the Securities Exchange Act of 1934 during the preceding 12 months (or for such shorter period that the registrant was required to file such reports), and (2) has been subject to such filing requirements for the past 90 days.
option Yes: [x]
option No: [ ]

<a id='78fc9efb-1dd2-4f8c-ad02-7b436ea115b6'></a>

Indicate by check mark whether the registrant has submitted electronically every Interactive Data File required to be submitted pursuant to Rule 405 of Regulation S-T (§232.405 of this chapter) during the preceding 12 months (or for such shorter period that the registrant was required to submit such files).
option Yes: [x]
option No: [ ]

<a id='15a80d7e-c4b2-4ad7-9d85-6c58d6de8233'></a>

Indicate by check mark whether the registrant is a large accelerated filer, an accelerated filer, a non-accelerated filer, a smaller reporting company, or an emerging growth company. See the definitions of "large accelerated filer," "accelerated filer," "smaller reporting company," and "emerging growth company" in Rule 12b-2 of the Exchange Act.

<a id='7fc64c95-db5d-4088-ac45-727b04398358'></a>

option Large accelerated filer: [x]
option Non-accelerated filer: [ ]
option Emerging growth company: [ ]

option Accelerated filer: [ ]
option Smaller reporting company: [ ]

<a id='a1dc3635-187f-4903-8b85-b76a877b753c'></a>

If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act. option : [ ]

<!-- PAGE BREAK -->

<a id='d7aa78e5-8a61-42fb-be9c-f6ee87c9ed21'></a>

Indicate by check mark whether the registrant is a shell company (as defined in Rule 12b-2 of the Exchange Act).
option Yes: [ ]
option No: [x]

As of July 16, 2025, there were 5,817 million shares of Alphabet's Class A stock outstanding, 847 million shares of Alphabet's Class B stock outstanding, and 5,430 million shares of Alphabet's Class C stock outstanding.
__

<a id='2f0ab232-0ad5-4371-a39f-57c9c6b374a0'></a>

2

<!-- PAGE BREAK -->

<a id='83eecb36-8019-42fa-973d-9eb2c3f43a99'></a>

Table of Contents

<a id='ab667af9-3fde-4033-bd6d-5594a47769b5'></a>

Alphabet Inc.

<a id='830efc41-076e-4325-8590-853b78f12560'></a>

Alphabet Inc.
Form 10-Q
For the Quarterly Period Ended June 30, 2025

<a id='5d3c8eab-24a3-4b7c-b68c-4ac0b3f7e3ae'></a>

## TABLE OF CONTENTS

<a id='51adc647-2323-4a7c-9b81-cf32a13e4dbe'></a>

Note About Forward-Looking Statements

Page No.
4

<a id='712ba018-e65e-42e3-b26b-15a515a25c2e'></a>

<table id="2-1">
<tr><td id="2-2" colspan="3">PART I. FINANCIAL INFORMATION</td></tr>
<tr><td id="2-3">Item 1</td><td id="2-4">Financial Statements</td><td id="2-5">6</td></tr>
<tr><td id="2-6"></td><td id="2-7">Consolidated Balance Sheets - December 31, 2024 and June 30, 2025</td><td id="2-8">6</td></tr>
<tr><td id="2-9"></td><td id="2-a">Consolidated Statements of Income - Three and Six Months Ended June 30, 2024 and 2025</td><td id="2-b">7</td></tr>
<tr><td id="2-c"></td><td id="2-d">Consolidated Statements of Comprehensive Income - Three and Six Months Ended June 30, 2024 and 2025</td><td id="2-e">8</td></tr>
<tr><td id="2-f"></td><td id="2-g">Consolidated Statements of Stockholders&#x27; Equity - Three and Six Months Ended June 30, 2024 and 2025</td><td id="2-h">9</td></tr>
<tr><td id="2-i"></td><td id="2-j">Consolidated Statements of Cash Flows - Six Months Ended June 30, 2024 and 2025</td><td id="2-k">11</td></tr>
<tr><td id="2-l"></td><td id="2-m">Notes to Consolidated Financial Statements</td><td id="2-n">12</td></tr>
<tr><td id="2-o">Item 2</td><td id="2-p">Management&#x27;s Discussion and Analysis of Financial Condition and Results of Operations</td><td id="2-q">37</td></tr>
<tr><td id="2-r">Item 3</td><td id="2-s">Quantitative and Qualitative Disclosures About Market Risk</td><td id="2-t">51</td></tr>
<tr><td id="2-u">Item 4</td><td id="2-v">Controls and Procedures</td><td id="2-w">52</td></tr>
</table>

<a id='5d94d8af-bcbd-4337-b61a-84a75f02766d'></a>

PART II. OTHER INFORMATION

Item 1 Legal Proceedings 53
Item 1A Risk Factors 53
Item 2 Unregistered Sales of Equity Securities and Use of Proceeds 53
Item 5 Other Information 53
Item 6 Exhibits 55
Signatures 57

<a id='cb003138-42cb-47c9-9773-ae8785a447d6'></a>

3

<!-- PAGE BREAK -->

<a id='600bbb42-5451-4daa-8164-a5c6d574ad0f'></a>

Table of Contents

<a id='4e2b82f4-598d-48ed-a9ed-c362f7b5e2bc'></a>

Alphabet Inc.

<a id='f952aede-63eb-4215-a532-ed9ef691afa8'></a>

## Note About Forward-Looking Statements

This Quarterly Report on Form 10-Q contains forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. These include, among other things, statements regarding:

*   the growth of our business and revenues and our expectations about the factors that influence our success and trends in our business;
*   fluctuations in our revenues and margins and various factors contributing to such fluctuations;
*   our expectation that the continuing shift to an online world as the digital economy evolves will continue to benefit our business;
*   our expectation that the revenues that we derive beyond advertising will continue to increase and may affect our margins;
*   our expectation that our traffic acquisition costs (TAC) and the associated TAC rate will fluctuate, which could affect our overall margins;
*   our expectation that our monetization trends will fluctuate, which could affect our revenues and margins;
*   fluctuations in paid clicks and cost-per-click as well as impressions and cost-per-impression, and various factors contributing to such fluctuations;
*   our expectation that we will continue to periodically review, refine, and update our methodologies for monitoring, gathering, and counting the number of paid clicks and impressions, and for identifying the revenues generated by the corresponding click and impression activity;
*   our expectation that our results will be affected by our performance in international markets as users in developing economies increasingly come online;
*   our expectation that our foreign exchange risk management program will not fully offset our net exposure to fluctuations in foreign currency exchange rates;
*   the expected variability of gains and losses related to hedging activities under our foreign exchange risk management program;
*   the amount and timing of revenue recognition from customer contracts with commitments for performance obligations, including our estimate of the remaining amount of commitments and when we expect to recognize revenue;
*   our expectation that our capital expenditures will increase, including our expected spend and the expected increase in our technical infrastructure investment to support the growth of our business and our long-term initiatives, in particular in support of artificial intelligence (AI) products and services;
*   our plans to continue to invest in new businesses, products, services and technologies, and systems, as well as to continue to invest in acquisitions and strategic investments;
*   our pace of hiring and our plans to provide competitive compensation programs;
*   our expectation that our cost of revenues, research and development (R&D) expenses, sales and marketing expenses, and general and administrative expenses may increase in amount and/or may increase as a percentage of revenues and may be affected by a number of factors;
*   estimates of our future employee compensation expenses;
*   our expectation that our other income (expense), net (OI&E), will fluctuate in the future, as it is largely driven by market dynamics;
*   fluctuations in our effective tax rate;
*   seasonal fluctuations in internet usage, advertising expenditures, and underlying business trends such as traditional retail seasonality, which are likely to cause fluctuations in our quarterly results;
*   the sufficiency of our sources of funding;
*   our potential exposure in connection with new and pending investigations, proceedings, and other contingencies, including the possibility that certain legal proceedings to which we are a party could harm our business, financial condition, and operating results;

<a id='426db0b3-fbee-4d4a-8969-3e0d49be273d'></a>

4

<!-- PAGE BREAK -->

<a id='a1b544c2-4f7a-4c5d-aba2-f134a2c6bfcf'></a>

[Table of Contents](link)
Alphabet Inc.

*   our expectation that we will continue to face heightened regulatory scrutiny, and changes in regulatory conditions, laws, and public policies, which could affect our business practices and financial results;
*   the expected timing, amount, and effect of Alphabet Inc.'s share repurchases and dividends;
*   our long-term sustainability goals;
*   our expectations regarding the timing and successful closing and integration of the Wiz, Inc. ("Wiz") acquisition, including the realization of anticipated benefits; and
*   ongoing developments surrounding international trade and the related impact on the macroeconomic environment and our business;

<a id='fcb8ade4-31ca-4c8c-b463-8e8a15b43e25'></a>

as well as other statements regarding our future operations, financial condition and prospects, and business strategies. Forward-looking statements may appear throughout this report and other documents we file with the Securities and Exchange Commission (SEC), including without limitation, the following sections: Part I, Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in this Quarterly Report on Form 10-Q and Part I, Item 1A, "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024. Forward-looking statements generally can be identified by words such as "anticipates," "believes," "could," "estimates," "expects," "intends," "may," "plans," "predicts," "projects," "will be," "will continue," "will likely result," and similar expressions. These forward-looking statements are based on current expectations and assumptions that are subject to risks and uncertainties, which could cause our actual results to differ materially from those reflected in the forward-looking statements. Factors that could cause or contribute to such differences include, but are not limited to, those discussed in this Quarterly Report on Form 10-Q; the risks discussed in Part I, Item 1A, "Risk Factors" and the trends discussed in Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024; and those discussed in other documents we file with the SEC. We undertake no obligation to revise or publicly release the results of any revision to these forward-looking statements, except as required by law. Given these risks and uncertainties, readers are cautioned not to place undue reliance on such forward-looking statements.

<a id='9bdf14ab-c769-44aa-891e-c4677877be1e'></a>

As used herein, "Alphabet," "the company," "we," "us," "our," and similar terms include Alphabet Inc. and its subsidiaries, unless the context indicates otherwise.

<a id='92185325-1511-4a8e-b390-41d9531caaca'></a>

"Alphabet," "Google," and other trademarks of ours appearing in this report are our property. We do not intend our use or display of other companies' trade names or trademarks to imply an endorsement or sponsorship of us by such companies, or any relationship with any of these companies.

<a id='46a683da-9710-409d-a65f-7107b81032bd'></a>

5

<!-- PAGE BREAK -->

<a id='02af42ef-68c1-481e-b0da-8c729bb6e1fb'></a>

# Table of Contents

<a id='206ea68c-1d7c-4573-92a7-7d622d6a8f50'></a>

Alphabet Inc.

<a id='8c741c8d-b5e2-4bc6-aaab-5c067ec6942a'></a>

PART I. FINANCIAL INFORMATION
ITEM 1. FINANCIAL STATEMENTS

<a id='d92d1edd-eb1a-48bb-9376-90ee46a653bd'></a>

Alphabet Inc.
CONSOLIDATED BALANCE SHEETS
(in millions, except par value per share amounts)

<a id='9eec20fa-eaeb-4d27-8eb0-adaf96450059'></a>

<table id="5-1">
<tr><td id="5-2"></td><td id="5-3">As of December 31, 2024</td><td id="5-4">As of June 30, 2025</td></tr>
<tr><td id="5-5"></td><td id="5-6"></td><td id="5-7">(unaudited)</td></tr>
<tr><td id="5-8">Assets</td><td id="5-9"></td><td id="5-a"></td></tr>
<tr><td id="5-b">Current assets:</td><td id="5-c"></td><td id="5-d"></td></tr>
<tr><td id="5-e">Cash and cash equivalents</td><td id="5-f">$ 23,466</td><td id="5-g">$ 21,036</td></tr>
<tr><td id="5-h">Marketable securities</td><td id="5-i">72,191</td><td id="5-j">74,112</td></tr>
<tr><td id="5-k">Total cash, cash equivalents, and marketable securities</td><td id="5-l">95,657</td><td id="5-m">95,148</td></tr>
<tr><td id="5-n">Accounts receivable, net</td><td id="5-o">52,340</td><td id="5-p">55,048</td></tr>
<tr><td id="5-q">Other current assets</td><td id="5-r">15,714</td><td id="5-s">16,020</td></tr>
<tr><td id="5-t">Total current assets</td><td id="5-u">163,71</td><td id="5-v">166,216</td></tr>
<tr><td id="5-w">Non-marketable securities</td><td id="5-x">37,982</td><td id="5-y">52,574</td></tr>
<tr><td id="5-z">Deferred income taxes</td><td id="5-A">17,180</td><td id="5-B">19,289</td></tr>
<tr><td id="5-C">Property and equipment, net</td><td id="5-D">171,036</td><td id="5-E">203,231</td></tr>
<tr><td id="5-F">Operating lease assets</td><td id="5-G">13,588</td><td id="5-H">14,255</td></tr>
<tr><td id="5-I">Goodwill</td><td id="5-J">31,885</td><td id="5-K">32,335</td></tr>
<tr><td id="5-L">Other non-current assets</td><td id="5-M">14,874</td><td id="5-N">14,153</td></tr>
<tr><td id="5-O">Total assets</td><td id="5-P">$ 450,256</td><td id="5-Q">$ 502,053</td></tr>
<tr><td id="5-R">Liabilities and Stockholders&#x27; Equity</td><td id="5-S"></td><td id="5-T"></td></tr>
<tr><td id="5-U">Current liabilities:</td><td id="5-V"></td><td id="5-W"></td></tr>
<tr><td id="5-X">Accounts payable</td><td id="5-Y">$ 7,987</td><td id="5-Z">$ 8,347</td></tr>
<tr><td id="5-10">Accrued compensation and benefits</td><td id="5-11">15,069</td><td id="5-12">12,168</td></tr>
<tr><td id="5-13">Accrued expenses and other curent liabilities</td><td id="5-14">51,228</td><td id="5-15">52,039</td></tr>
<tr><td id="5-16">Accrued revenue share</td><td id="5-17">9,802</td><td id="5-18">9,787</td></tr>
<tr><td id="5-19">Deferred revenue</td><td id="5-1a">5,036</td><td id="5-1b">4,969</td></tr>
<tr><td id="5-1c">Total current liabilities</td><td id="5-1d">89,122</td><td id="5-1e">87,310</td></tr>
<tr><td id="5-1f">Long-term debt</td><td id="5-1g">10,883</td><td id="5-1h">23,607</td></tr>
<tr><td id="5-1i">Income taxes payable, non-current</td><td id="5-1j">8,782</td><td id="5-1k">10,027</td></tr>
<tr><td id="5-1l">Operating lease liabilities</td><td id="5-1m">11,691</td><td id="5-1n">11,952</td></tr>
<tr><td id="5-1o">Other long-term liabilities</td><td id="5-1p">4,694</td><td id="5-1q">6,241</td></tr>
<tr><td id="5-1r">Total liabilities</td><td id="5-1s">125,172</td><td id="5-1t">139,137</td></tr>
<tr><td id="5-1u">Commitments and Contingencies (Note 10)</td><td id="5-1v"></td><td id="5-1w"></td></tr>
<tr><td id="5-1x">Stockholders&#x27; equity:</td><td id="5-1y"></td><td id="5-1z"></td></tr>
<tr><td id="5-1A">Preferred stock, $0.001 par value per share, 100 shares authorized; no shares issued and outstanding</td><td id="5-1B">0</td><td id="5-1C">0</td></tr>
<tr><td id="5-1D">Class A, Class B, and Class C stock and additional paid-in capital, $0.001 par value per share: 300,000 shares authorized (Class A 180,000, Class B 60,000, Class C 60,000); 12,211 (Class A 5,835, Class B 861, Class C 5,515) and 12,104 (Class A 5,816, Class B 849, Class C 5,439) shares issued and outstanding</td><td id="5-1E">84,800</td><td id="5-1F">89,283</td></tr>
<tr><td id="5-1G">Accumulated other comprehensive income (loss)</td><td id="5-1H">(4,800)</td><td id="5-1I">(2,127)</td></tr>
<tr><td id="5-1J">Retained earnings</td><td id="5-1K">245,084</td><td id="5-1L">275,760</td></tr>
<tr><td id="5-1M">Total stockholders&#x27; equity</td><td id="5-1N">325,084</td><td id="5-1O">362,916</td></tr>
<tr><td id="5-1P">Total liabilities and stockholders&#x27; equity</td><td id="5-1Q">$ 450,256</td><td id="5-1R">$ 502.053</td></tr>
</table>

<a id='6c6648dd-e1d8-4516-bebf-be4a36a939de'></a>

See accompanying notes.

<a id='9ad966bd-cb95-487c-9b17-b567f622ba79'></a>

6

<!-- PAGE BREAK -->

<a id='1de7aeb9-e608-4413-a21f-7350cd94ecf0'></a>

Table of Contents

<a id='65cb15f4-ffa2-4092-95f4-fd157e540d3c'></a>

Alphabet Inc.

<a id='535bbbef-4cb0-4a9f-8c92-28110bd3ce1f'></a>

Alphabet Inc.
CONSOLIDATED STATEMENTS OF INCOME
(in millions, except per share amounts; unaudited)
<table id="6-1">
<tr><td id="6-2"></td><td id="6-3" colspan="2">Three Months Ended June 30,</td><td id="6-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="6-5"></td><td id="6-6">2024</td><td id="6-7">2025</td><td id="6-8">2024</td><td id="6-9">2025</td></tr>
<tr><td id="6-a">Revenues</td><td id="6-b">$ 84,742</td><td id="6-c">$ 96,428</td><td id="6-d">$ 165,281</td><td id="6-e">$ 186,662</td></tr>
<tr><td id="6-f" colspan="2">Costs and expenses:</td><td id="6-g" colspan="3"></td></tr>
<tr><td id="6-h">Cost of revenues</td><td id="6-i">35,507</td><td id="6-j">39,039</td><td id="6-k">69,219</td><td id="6-l">75,400</td></tr>
<tr><td id="6-m">Research and development</td><td id="6-n">11,860</td><td id="6-o">13,808</td><td id="6-p">23,763</td><td id="6-q">27,364</td></tr>
<tr><td id="6-r">Sales and marketing</td><td id="6-s">6,792</td><td id="6-t">7,101</td><td id="6-u">13,218</td><td id="6-v">13,273</td></tr>
<tr><td id="6-w">General and administrative</td><td id="6-x">3,158</td><td id="6-y">5,209</td><td id="6-z">6,184</td><td id="6-A">8,748</td></tr>
<tr><td id="6-B">Total costs and expenses</td><td id="6-C">57,317</td><td id="6-D">65,157</td><td id="6-E">112,384</td><td id="6-F">124,785</td></tr>
<tr><td id="6-G">Income from operations</td><td id="6-H">27,425</td><td id="6-I">31,271</td><td id="6-J">52,897</td><td id="6-K">61,877</td></tr>
<tr><td id="6-L">Other income (expense), net</td><td id="6-M">126</td><td id="6-N">2,662</td><td id="6-O">2,969</td><td id="6-P">13,845</td></tr>
<tr><td id="6-Q">Income before income taxes</td><td id="6-R">27,551</td><td id="6-S">33,933</td><td id="6-T">55,866</td><td id="6-U">75,722</td></tr>
<tr><td id="6-V">Provision for income taxes</td><td id="6-W">3,932</td><td id="6-X">5,737</td><td id="6-Y">8,585</td><td id="6-Z">12,986</td></tr>
<tr><td id="6-10">Net income</td><td id="6-11">$ 23,619</td><td id="6-12">$ 28,196</td><td id="6-13">$ 47,281</td><td id="6-14">$ 62,736</td></tr>
<tr><td id="6-15"></td><td id="6-16"></td><td id="6-17"></td><td id="6-18"></td><td id="6-19"></td></tr>
<tr><td id="6-1a">Basic net income per share (Note 12)</td><td id="6-1b">$ 1.91</td><td id="6-1c">$ 2.33</td><td id="6-1d">$ 3.82</td><td id="6-1e">$ 5.16</td></tr>
<tr><td id="6-1f">Diluted net income per share (Note 12)</td><td id="6-1g">$ 1.89</td><td id="6-1h">$ 2.31</td><td id="6-1i">$ 3.78</td><td id="6-1j">$ 5.12</td></tr>
</table>

<a id='ce8463cf-19d9-4239-a9c8-b9f0f92a689a'></a>

See accompanying notes.

<a id='0ea6811a-22ff-46d0-b338-f7ae645e5d3c'></a>

7

<!-- PAGE BREAK -->

<a id='365a8689-1171-4045-a7c4-6744d8586fe9'></a>

Table of Contents

<a id='b4858365-8bb8-4391-8cba-5ee762fba788'></a>

Alphabet Inc.

<a id='980891d6-a143-41ed-94aa-ff803779a280'></a>

Alphabet Inc.
**CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME**
(in millions; unaudited)

<a id='36512bb7-6bc9-49f9-bd2a-6c202186217c'></a>

<table id="7-1">
<tr><td id="7-2"></td><td id="7-3" colspan="2">Three Months Ended June 30,</td><td id="7-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="7-5"></td><td id="7-6">2024</td><td id="7-7">2025</td><td id="7-8">2024</td><td id="7-9">2025</td></tr>
<tr><td id="7-a">Net income</td><td id="7-b">$ 23,619</td><td id="7-c">$ 28,196</td><td id="7-d">$ 47,281</td><td id="7-e">$ 62,736</td></tr>
<tr><td id="7-f" colspan="3">Other comprehensive income (loss):</td><td id="7-g" colspan="2"></td></tr>
<tr><td id="7-h">Change in foreign currency translation adjustment, net of income tax benefit (expense) of $(26), $190, $(44), and $235</td><td id="7-i">(447)</td><td id="7-j">2,610</td><td id="7-k">(950)</td><td id="7-l">3,273</td></tr>
<tr><td id="7-m">Available-for-sale investments:</td><td id="7-n"></td><td id="7-o"></td><td id="7-p"></td><td id="7-q"></td></tr>
<tr><td id="7-r">Change in net unrealized gains (losses)</td><td id="7-s">(93)</td><td id="7-t">191</td><td id="7-u">(453)</td><td id="7-v">836</td></tr>
<tr><td id="7-w">Less: reclassification adjustment for net (gains) losses included in net income</td><td id="7-x">230</td><td id="7-y">(29)</td><td id="7-z">541</td><td id="7-A">(113)</td></tr>
<tr><td id="7-B">Net change, net of income tax benefit (expense) of $(40), $(46), $(26), and $(205)</td><td id="7-C">137</td><td id="7-D">162</td><td id="7-E">88</td><td id="7-F">723</td></tr>
<tr><td id="7-G">Cash flow hedges:</td><td id="7-H"></td><td id="7-I"></td><td id="7-J"></td><td id="7-K"></td></tr>
<tr><td id="7-L">Change in net unrealized gains (losses)</td><td id="7-M">232</td><td id="7-N">(920)</td><td id="7-O">418</td><td id="7-P">(1,233)</td></tr>
<tr><td id="7-Q">Less: reclassification adjustment for net (gains) losses included in net income</td><td id="7-R">(95)</td><td id="7-S">107</td><td id="7-T">(166)</td><td id="7-U">(90)</td></tr>
<tr><td id="7-V">Net change, net of income tax benefit (expense) of $(27), $208, $(50), and $339</td><td id="7-W">137</td><td id="7-X">(813)</td><td id="7-Y">252</td><td id="7-Z">(1,323)</td></tr>
<tr><td id="7-10">Other comprehensive income (loss)</td><td id="7-11">(173)</td><td id="7-12">1,959</td><td id="7-13">(610)</td><td id="7-14">2,673</td></tr>
<tr><td id="7-15">Comprehensive income</td><td id="7-16">$ 23,446</td><td id="7-17">$ 30,155</td><td id="7-18">$ 46,671</td><td id="7-19">$ 65,409</td></tr>
</table>
See accompanying notes.

<a id='3f659736-ff90-4615-9377-f8074acbd19d'></a>

8

<!-- PAGE BREAK -->

<a id='588e6944-9185-4cfa-b534-128925109a39'></a>

Table of Contents

<a id='76f98ac7-c123-4023-9cfb-88ad6023c5ac'></a>

Alphabet Inc.

<a id='5687300f-41ce-43c4-b2ec-71f423ed3063'></a>

Alphabet Inc.
CONSOLIDATED STATEMENTS OF STOCKHOLDERS' EQUITY
(in millions; unaudited)

<a id='d1073df2-c683-4c67-9207-a7a0a04b41ba'></a>

<table id="8-1">
<tr><td id="8-2"></td><td id="8-3" colspan="5">Three Months Ended June 30, 2024</td></tr>
<tr><td id="8-4"></td><td id="8-5" colspan="2">Class A, Class B, Class C Stock and Additional Paid-In Capital</td><td id="8-6" rowspan="2">Accumulated Other Comprehensive Income (Loss)</td><td id="8-7" rowspan="2">Retained Earnings</td><td id="8-8" rowspan="2">Total Stockholders&#x27; Equity</td></tr>
<tr><td id="8-9"></td><td id="8-a">Shares</td><td id="8-b">Amount</td></tr>
<tr><td id="8-c">Balance as of March 31, 2024</td><td id="8-d">12,381</td><td id="8-e">$ 77,913</td><td id="8-f">$ (4,839)</td><td id="8-g">$ 219,770</td><td id="8-h">$ 292,844</td></tr>
<tr><td id="8-i">Stock issued</td><td id="8-j">33</td><td id="8-k">0</td><td id="8-l">0</td><td id="8-m">0</td><td id="8-n">0</td></tr>
<tr><td id="8-o">Stock-based compensation</td><td id="8-p">0</td><td id="8-q">5,908</td><td id="8-r">0</td><td id="8-s">0</td><td id="8-t">5,908</td></tr>
<tr><td id="8-u">Tax withholding related to vesting of restricted stock units and other</td><td id="8-v">0</td><td id="8-w">(3,304)</td><td id="8-x">0</td><td id="8-y">0</td><td id="8-z">(3,304)</td></tr>
<tr><td id="8-A">Repurchases of stock</td><td id="8-B">(92)</td><td id="8-C">(789)</td><td id="8-D">0</td><td id="8-E">(14,809)</td><td id="8-F">(15,598)</td></tr>
<tr><td id="8-G">Dividends and dividend equivalents declared ($0.20 per share)</td><td id="8-H">0</td><td id="8-I">4</td><td id="8-J">0</td><td id="8-K">(2,547)</td><td id="8-L">(2,543)</td></tr>
<tr><td id="8-M">Net income</td><td id="8-N">0</td><td id="8-O">0</td><td id="8-P">0</td><td id="8-Q">23,619</td><td id="8-R">23,619</td></tr>
<tr><td id="8-S">Other comprehensive income (loss)</td><td id="8-T">0</td><td id="8-U">0</td><td id="8-V">(173)</td><td id="8-W">0</td><td id="8-X">(173)</td></tr>
<tr><td id="8-Y">Balance as of June 30, 2024</td><td id="8-Z">12,322</td><td id="8-10">$ 79,732</td><td id="8-11">$ (5,012)</td><td id="8-12">$ 226,033</td><td id="8-13">$ 300,753</td></tr>
</table>

<a id='7bb9c405-7883-421c-a56d-c52473b8f94e'></a>

<table id="8-14">
<tr><td id="8-15"></td><td id="8-16" colspan="5">Six Months Ended June 30, 2024</td></tr>
<tr><td id="8-17"></td><td id="8-18" colspan="2">Class A, Class B, Class C Stock and Additional Paid-In Capital</td><td id="8-19" rowspan="2">Accumulated Other Comprehensive Income (Loss)</td><td id="8-1a" rowspan="2">Retained Earnings</td><td id="8-1b" rowspan="2">Total Stockholders&#x27; Equity</td></tr>
<tr><td id="8-1c"></td><td id="8-1d">Shares</td><td id="8-1e">Amount</td></tr>
<tr><td id="8-1f">Balance as of December 31, 2023</td><td id="8-1g">12,460</td><td id="8-1h">$ 76,534</td><td id="8-1i">$ (4,402)</td><td id="8-1j">$ 211,247</td><td id="8-1k">$ 283,379</td></tr>
<tr><td id="8-1l">Stock issued</td><td id="8-1m">65</td><td id="8-1n">0</td><td id="8-1o">0</td><td id="8-1p">0</td><td id="8-1q">0</td></tr>
<tr><td id="8-1r">Stock-based compensation</td><td id="8-1s">0</td><td id="8-1t">11,201</td><td id="8-1u">0</td><td id="8-1v">0</td><td id="8-1w">11,201</td></tr>
<tr><td id="8-1x">Tax withholding related to vesting of restricted stock units and other</td><td id="8-1y">0</td><td id="8-1z">(6,300)</td><td id="8-1A">0</td><td id="8-1B">0</td><td id="8-1C">(6,300)</td></tr>
<tr><td id="8-1D">Repurchases of stock</td><td id="8-1E">(203)</td><td id="8-1F">(1,707)</td><td id="8-1G">0</td><td id="8-1H">(29,948)</td><td id="8-1I">(31,655)</td></tr>
<tr><td id="8-1J">Dividends and dividend equivalents declared ($0.20 per share)</td><td id="8-1K">0</td><td id="8-1L">4</td><td id="8-1M">0</td><td id="8-1N">(2,547)</td><td id="8-1O">(2,543)</td></tr>
<tr><td id="8-1P">Net income</td><td id="8-1Q">0</td><td id="8-1R">0</td><td id="8-1S">0</td><td id="8-1T">47,281</td><td id="8-1U">47,281</td></tr>
<tr><td id="8-1V">Other comprehensive income (loss)</td><td id="8-1W">0</td><td id="8-1X">0</td><td id="8-1Y">(610)</td><td id="8-1Z">0</td><td id="8-20">(610)</td></tr>
<tr><td id="8-21">Balance as of June 30, 2024</td><td id="8-22">12,322</td><td id="8-23">$ 79,732</td><td id="8-24">$ (5,012)</td><td id="8-25">$ 226,033</td><td id="8-26">$ 300,753</td></tr>
</table>

<a id='2c1688d5-c416-4eea-aa0e-09fcbf6594a1'></a>

9

<!-- PAGE BREAK -->

<a id='a67f11c0-1d6f-49b1-bedd-59f0dd218de7'></a>

Table of Contents

<a id='31b689b9-b3f3-45d8-a88a-a32ebf2799e8'></a>

Alphabet Inc.

<a id='73ee5158-de27-43e4-bc14-e7d54b0fe5cd'></a>

<table id="9-1">
<tr><td id="9-2"></td><td id="9-3" colspan="5">Three Months Ended June 30, 2025</td></tr>
<tr><td id="9-4"></td><td id="9-5" colspan="2">Class A, Class B, Class C Stock and Additional Paid-In Capital</td><td id="9-6" rowspan="2">Accumulated Other Comprehensive Income (Loss)</td><td id="9-7" rowspan="2">Retained Earnings</td><td id="9-8" rowspan="2">Total Stockholders&#x27; Equity</td></tr>
<tr><td id="9-9"></td><td id="9-a">Shares</td><td id="9-b">Amount</td></tr>
<tr><td id="9-c">Balance as of March 31, 2025</td><td id="9-d">12,155</td><td id="9-e">$ 86,725</td><td id="9-f">$ (4,086)</td><td id="9-g">$ 262,628</td><td id="9-h">$ 345,267</td></tr>
<tr><td id="9-i">Stock issued</td><td id="9-j">30</td><td id="9-k">0</td><td id="9-l">0</td><td id="9-m">0</td><td id="9-n">0</td></tr>
<tr><td id="9-o">Stock-based compensation</td><td id="9-p">0</td><td id="9-q">6,045</td><td id="9-r">0</td><td id="9-s">0</td><td id="9-t">6,045</td></tr>
<tr><td id="9-u">Tax withholding related to vesting of restricted stock units and other</td><td id="9-v">0</td><td id="9-w">(2,709)</td><td id="9-x">0</td><td id="9-y">0</td><td id="9-z">(2,709)</td></tr>
<tr><td id="9-A">Repurchases of stock</td><td id="9-B">(81)</td><td id="9-C">(811)</td><td id="9-D">0</td><td id="9-E">(12,452)</td><td id="9-F">(13,263)</td></tr>
<tr><td id="9-G">Dividends and dividend equivalents declared ($0.21 per share)</td><td id="9-H">0</td><td id="9-I">33</td><td id="9-J">0</td><td id="9-K">(2,612)</td><td id="9-L">(2,579)</td></tr>
<tr><td id="9-M">Sale of interest in consolidated entities</td><td id="9-N">0</td><td id="9-O">0</td><td id="9-P">0</td><td id="9-Q">0</td><td id="9-R">0</td></tr>
<tr><td id="9-S">Net income</td><td id="9-T">0</td><td id="9-U">0</td><td id="9-V">0</td><td id="9-W">28,196</td><td id="9-X">28,196</td></tr>
<tr><td id="9-Y">Other comprehensive income (loss)</td><td id="9-Z">0</td><td id="9-10">0</td><td id="9-11">1,959</td><td id="9-12">0</td><td id="9-13">1,959</td></tr>
<tr><td id="9-14">Balance as of June 30, 2025</td><td id="9-15">12,104</td><td id="9-16">$ 89,283</td><td id="9-17">$ (2,127)</td><td id="9-18">$ 275,760</td><td id="9-19">$ 362,916</td></tr>
</table>

<a id='75a025f9-4af6-4f80-9fca-113c1c4e79b7'></a>

<table id="9-1a">
<tr><td id="9-1b"></td><td id="9-1c" colspan="5">Six Months Ended June 30, 2025</td></tr>
<tr><td id="9-1d"></td><td id="9-1e" colspan="2">Class A, Class B, Class C Stock and Additional Paid-In Capital</td><td id="9-1f" rowspan="2">Accumulated Other Comprehensive Income (Loss)</td><td id="9-1g" rowspan="2">Retained Earnings</td><td id="9-1h" rowspan="2">Total Stockholders&#x27; Equity</td></tr>
<tr><td id="9-1i"></td><td id="9-1j">Shares</td><td id="9-1k">Amount</td></tr>
<tr><td id="9-1l">Balance as of December 31, 2024</td><td id="9-1m">12,211</td><td id="9-1n">$ 84,800</td><td id="9-1o">$ (4,800)</td><td id="9-1p">$ 245,084</td><td id="9-1q">$ 325,084</td></tr>
<tr><td id="9-1r">Stock issued</td><td id="9-1s">57</td><td id="9-1t">0</td><td id="9-1u">0</td><td id="9-1v">0</td><td id="9-1w">0</td></tr>
<tr><td id="9-1x">Stock-based compensation</td><td id="9-1y">0</td><td id="9-1z">11,598</td><td id="9-1A">0</td><td id="9-1B">0</td><td id="9-1C">11,598</td></tr>
<tr><td id="9-1D">Tax withholding related to vesting of restricted stock units and other</td><td id="9-1E">0</td><td id="9-1F">(5,949)</td><td id="9-1G">0</td><td id="9-1H">0</td><td id="9-1I">(5,949)</td></tr>
<tr><td id="9-1J">Repurchases of stock</td><td id="9-1K">(164)</td><td id="9-1L">(1,626)</td><td id="9-1M">0</td><td id="9-1N">(26,938)</td><td id="9-1O">(28,564)</td></tr>
<tr><td id="9-1P">Dividends and dividend equivalents declared ($0.41 per share)</td><td id="9-1Q">0</td><td id="9-1R">60</td><td id="9-1S">0</td><td id="9-1T">(5,122)</td><td id="9-1U">(5,062)</td></tr>
<tr><td id="9-1V">Sale of interest in consolidated entities</td><td id="9-1W">0</td><td id="9-1X">400</td><td id="9-1Y">0</td><td id="9-1Z">0</td><td id="9-20">400</td></tr>
<tr><td id="9-21">Net income</td><td id="9-22">0</td><td id="9-23">0</td><td id="9-24">0</td><td id="9-25">62,736</td><td id="9-26">62,736</td></tr>
<tr><td id="9-27">Other comprehensive income (loss)</td><td id="9-28">0</td><td id="9-29">0</td><td id="9-2a">2,673</td><td id="9-2b">0</td><td id="9-2c">2,673</td></tr>
<tr><td id="9-2d">Balance as of June 30, 2025</td><td id="9-2e">12,104</td><td id="9-2f">$ 89,283</td><td id="9-2g">$ (2,127)</td><td id="9-2h">$ 275,760</td><td id="9-2i">$ 362,916</td></tr>
</table>

<a id='c42e7b9f-7a17-44aa-b3f8-cbce7e05c9ec'></a>

See accompanying notes.

<a id='51057bce-b9a8-40a8-97f2-66b0caf1d96a'></a>

10

<!-- PAGE BREAK -->

<a id='458b2c97-602a-4345-ac77-6bde5abd8d92'></a>

Table of Contents

<a id='425d2cd1-f5b1-40e4-bda4-e883fe9024f9'></a>

Alphabet Inc.

<a id='3bb11ea7-1929-471e-84da-ee2ef78faf61'></a>

Alphabet Inc.

**CONSOLIDATED STATEMENTS OF CASH FLOWS**

(in millions; unaudited)

<a id='2ff45201-4707-42c3-94c8-f512ed6677bc'></a>

<table id="10-1">
<tr><td id="10-2"></td><td id="10-3" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="10-4"></td><td id="10-5">2024</td><td id="10-6">2025</td></tr>
<tr><td id="10-7" colspan="3">Operating activities</td></tr>
<tr><td id="10-8">Net income</td><td id="10-9">$ 47,281</td><td id="10-a">$ 62,736</td></tr>
<tr><td id="10-b" colspan="3">Adjustments:</td></tr>
<tr><td id="10-c">Depreciation of property and equipment</td><td id="10-d">7,121</td><td id="10-e">9,485</td></tr>
<tr><td id="10-f">Stock-based compensation expense</td><td id="10-g">11,129</td><td id="10-h">11,514</td></tr>
<tr><td id="10-i">Deferred income taxes</td><td id="10-j">(2,738)</td><td id="10-k">(1,596)</td></tr>
<tr><td id="10-l">Loss (gain) on debt and equity securities, net</td><td id="10-m">(757)</td><td id="10-n">(1,411)</td></tr>
<tr><td id="10-o">Other</td><td id="10-p">1,185</td><td id="10-q">1,041</td></tr>
<tr><td id="10-r" colspan="3">Changes in assets and liabilities, net of effects of acquisitions:</td></tr>
<tr><td id="10-s">Accounts receivable, net</td><td id="10-t">110</td><td id="10-u">(1,201)</td></tr>
<tr><td id="10-v">Income taxes, net</td><td id="10-w">(889)</td><td id="10-x">(2,434)</td></tr>
<tr><td id="10-y">Other assets</td><td id="10-z">(1,532)</td><td id="10-A">(2,767)</td></tr>
<tr><td id="10-B">Accounts payable</td><td id="10-C">(563)</td><td id="10-D">(327)</td></tr>
<tr><td id="10-E">Accrued expenses and other liabilities</td><td id="10-F">(5,176)</td><td id="10-G">(1,560)</td></tr>
<tr><td id="10-H">Accrued revenue share</td><td id="10-I">97</td><td id="10-J">(219)</td></tr>
<tr><td id="10-K">Deferred revenue</td><td id="10-L">220</td><td id="10-M">636</td></tr>
<tr><td id="10-N">Net cash provided by operating activities</td><td id="10-O">55,488</td><td id="10-P">63,897</td></tr>
<tr><td id="10-Q" colspan="3">Investing activities</td></tr>
<tr><td id="10-R">Purchases of property and equipment</td><td id="10-S">(25,198)</td><td id="10-T">(39,643)</td></tr>
<tr><td id="10-U">Purchases of marketable securities</td><td id="10-V">(43,011)</td><td id="10-W">(39,870)</td></tr>
<tr><td id="10-X">Maturities and sales of marketable securities</td><td id="10-Y">58,577</td><td id="10-Z">40,930</td></tr>
<tr><td id="10-10">Purchases of non-marketable securities</td><td id="10-11">(2,199)</td><td id="10-12">(2,312)</td></tr>
<tr><td id="10-13">Maturities and sales of non-marketable securities</td><td id="10-14">605</td><td id="10-15">873</td></tr>
<tr><td id="10-16">Acquisitions, net of cash acquired, and purchases of intangible assets</td><td id="10-17">(87)</td><td id="10-18">(353)</td></tr>
<tr><td id="10-19">Other investing activities</td><td id="10-1a">(32)</td><td id="10-1b">(363)</td></tr>
<tr><td id="10-1c">Net cash used in investing activities</td><td id="10-1d">(11,345)</td><td id="10-1e">(40,738)</td></tr>
<tr><td id="10-1f" colspan="3">Financing activities</td></tr>
<tr><td id="10-1g">Net payments related to stock-based award activities</td><td id="10-1h">(6,138)</td><td id="10-1i">(5,731)</td></tr>
<tr><td id="10-1j">Repurchases of stock</td><td id="10-1k">(31,380)</td><td id="10-1l">(28,706)</td></tr>
<tr><td id="10-1m">Dividend payments</td><td id="10-1n">(2,466)</td><td id="10-1o">(4,977)</td></tr>
<tr><td id="10-1p">Proceeds from issuance of debt, net of costs</td><td id="10-1q">4,875</td><td id="10-1r">31,378</td></tr>
<tr><td id="10-1s">Repayments of debt</td><td id="10-1t">(5,502)</td><td id="10-1u">(18,397)</td></tr>
<tr><td id="10-1v">Proceeds from sale of interest in consolidated entities, net</td><td id="10-1w">8</td><td id="10-1x">400</td></tr>
<tr><td id="10-1y">Net cash used in financing activities</td><td id="10-1z">(40,603)</td><td id="10-1A">(26,033)</td></tr>
<tr><td id="10-1B">Effect of exchange rate changes on cash and cash equivalents</td><td id="10-1C">(363)</td><td id="10-1D">444</td></tr>
<tr><td id="10-1E">Net increase (decrease) in cash and cash equivalents</td><td id="10-1F">3,177</td><td id="10-1G">(2,430)</td></tr>
<tr><td id="10-1H">Cash and cash equivalents at beginning of period</td><td id="10-1I">24,048</td><td id="10-1J">23,466</td></tr>
<tr><td id="10-1K">Cash and cash equivalents at end of period</td><td id="10-1L">$ 27,225</td><td id="10-1M">$ 21,036</td></tr>
</table>

<a id='155dc7e6-218f-433a-acbf-2ab279b29352'></a>

See accompanying notes.

<a id='1a565f91-1af5-4aab-aaa3-b530aeaf1ad2'></a>

11

<!-- PAGE BREAK -->

<a id='fd5c0298-5145-42c2-ad36-2c38eb3c0713'></a>

Table of Contents

<a id='0571cb58-3239-4a30-9410-e8b7849d1f71'></a>

Alphabet Inc.

<a id='1ebcb4ad-d80d-4cd4-ae80-7f572efbc03f'></a>

Alphabet Inc.
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS
(Unaudited)

<a id='2ba20ddc-fc27-4681-a70a-3223348d5b56'></a>

**Note 1. Summary of Significant Accounting Policies**
**Nature of Operations**

Google was incorporated in California in September 1998 and re-incorporated in the State of Delaware in August 2003. In 2015, we implemented a holding company reorganization, and as a result, Alphabet Inc. ("Alphabet") became the successor issuer to Google.

<a id='f5fa581d-6635-469e-ab8e-83f6fe386d24'></a>

We generate revenues by delivering relevant, cost-effective online advertising; cloud-based solutions that provide enterprise customers of all sizes with infrastructure, platform services, and applications; sales of other products and services, such as fees received for subscription-based products, apps and in-app purchases, and devices.

<a id='4be2e12b-380f-437b-9b86-f7159ea0c328'></a>

**Basis of Consolidation**
The consolidated financial statements of Alphabet include the accounts of Alphabet and entities consolidated under the variable interest and voting models. Intercompany balances and transactions have been eliminated.

<a id='7a31ccfc-0b7d-45b7-92af-9eebdf3758ba'></a>

## Unaudited Interim Financial Information

These unaudited interim consolidated financial statements have been prepared in accordance with generally accepted accounting principles in the United States (GAAP), and in our opinion, include all adjustments of a normal recurring nature necessary for fair financial statement presentation. Interim results are not necessarily indicative of the results to be expected for the full year ending December 31, 2025. We have made estimates and assumptions that affect the amounts reported and disclosed in the financial statements and the accompanying notes. Actual results could differ materially from these estimates.

<a id='b397ef65-7b9f-457e-86b6-a611a4c468c4'></a>

These consolidated financial statements and other information presented in this Form 10-Q should be read in conjunction with the consolidated financial statements and the related notes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 filed with the SEC.

<a id='81bb143c-1781-461d-80c9-64147a32c2e0'></a>

**Recently Issued Accounting Pronouncements Not Yet Adopted**
In December 2023, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2023-09 "Income Taxes (Topics 740): Improvements to Income Tax Disclosures" to expand the disclosure requirements for income taxes. Upon adoption, we will be required to disclose additional specified categories in the rate reconciliation in both percentage and dollar amounts. We will also be required to disclose the amount of income taxes paid disaggregated by jurisdiction, among other disclosure requirements. The standard, which is effective for our 2025 annual period, can be applied either prospectively or retrospectively and we are currently assessing which method to adopt.

<a id='311015e3-d02f-415b-917f-4487906da06c'></a>

In November 2024, the FASB issued ASU 2024-03 "Income Statement: Reporting Comprehensive Income-Expense Disaggregation Disclosures (Subtopic 220-40)" to improve the disclosures about an entity's expenses. Upon adoption, we will be required to disclose in the notes to the financial statements a disaggregation of certain expense categories included within the expense captions on the face of the income statement. The standard is effective for our 2027 annual period, and our interim periods beginning in 2028, with early adoption permitted. The standard can be applied either prospectively or retrospectively. We are currently assessing adoption timing and the effect that the updated standard will have on our financial statement disclosures.

<a id='5a857ff8-9ee9-48b5-9418-0a22894edd26'></a>

**Prior Period Reclassifications**
Certain amounts in prior periods have been reclassified to conform with current period presentation.

<a id='a40003cb-b4e7-4757-bbd2-8f568fc45ba5'></a>

12

<!-- PAGE BREAK -->

<a id='72f3eb10-8f5f-4b83-93e5-95c4f70e9c73'></a>

Table of Contents

**Note 2. Revenues**

<a id='db3508f7-3bb3-46ce-a540-01fa22a48dc9'></a>

Alphabet Inc.

<a id='c66b5404-fc0d-4cd3-8fbf-ddfa1d2fd3b9'></a>

Disaggregated Revenues
The following table presents revenues disaggregated by type (in millions):
<table id="12-1">
<tr><td id="12-2"></td><td id="12-3" colspan="2">Three Months Ended June 30,</td><td id="12-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="12-5"></td><td id="12-6">2024</td><td id="12-7">2025</td><td id="12-8">2024</td><td id="12-9">2025</td></tr>
<tr><td id="12-a">Google Search &amp; other</td><td id="12-b">$ 48,509</td><td id="12-c">$ 54,190</td><td id="12-d">$ 94,665</td><td id="12-e">$ 104,892</td></tr>
<tr><td id="12-f">YouTube ads</td><td id="12-g">8,663</td><td id="12-h">9,796</td><td id="12-i">16,753</td><td id="12-j">18,723</td></tr>
<tr><td id="12-k">Google Network</td><td id="12-l">7,444</td><td id="12-m">7,354</td><td id="12-n">14,857</td><td id="12-o">14,610</td></tr>
<tr><td id="12-p">Google advertising</td><td id="12-q">64,616</td><td id="12-r">71,340</td><td id="12-s">126,275</td><td id="12-t">138,225</td></tr>
<tr><td id="12-u">Google subscriptions, platforms, and devices</td><td id="12-v">9,312</td><td id="12-w">11,203</td><td id="12-x">18,051</td><td id="12-y">21,582</td></tr>
<tr><td id="12-z">Google Services total</td><td id="12-A">73,928</td><td id="12-B">82,543</td><td id="12-C">144,326</td><td id="12-D">159,807</td></tr>
<tr><td id="12-E">Google Cloud</td><td id="12-F">10,347</td><td id="12-G">13,624</td><td id="12-H">19,921</td><td id="12-I">25,884</td></tr>
<tr><td id="12-J">Other Bets</td><td id="12-K">365</td><td id="12-L">373</td><td id="12-M">860</td><td id="12-N">823</td></tr>
<tr><td id="12-O">Hedging gains (losses)</td><td id="12-P">102</td><td id="12-Q">(112)</td><td id="12-R">174</td><td id="12-S">148</td></tr>
<tr><td id="12-T">Total revenues</td><td id="12-U">$ 84,742</td><td id="12-V">$ 96,428</td><td id="12-W">$ 165,281</td><td id="12-X">$ 186,662</td></tr>
</table>

<a id='cf76de4e-ab2b-4606-bd03-707356d50381'></a>

The following table presents revenues disaggregated by geography, based on the addresses of our customers
(in millions):
<table id="12-Y">
<tr><td id="12-Z"></td><td id="12-10" colspan="4">Three Months Ended June 30,</td><td id="12-11" colspan="4">Six Months Ended June 30,</td></tr>
<tr><td id="12-12"></td><td id="12-13" colspan="2">2024</td><td id="12-14" colspan="2">2025</td><td id="12-15" colspan="2">2024</td><td id="12-16" colspan="2">2025</td></tr>
<tr><td id="12-17">United States</td><td id="12-18">$ 41,196</td><td id="12-19">49 %</td><td id="12-1a">$ 46,063</td><td id="12-1b">48 %</td><td id="12-1c">$ 79,933</td><td id="12-1d">48 %</td><td id="12-1e">$ 90,027</td><td id="12-1f">48 %</td></tr>
<tr><td id="12-1g">EMEA(1)</td><td id="12-1h">24,683</td><td id="12-1i">29</td><td id="12-1j">28,262</td><td id="12-1k">29</td><td id="12-1l">48,471</td><td id="12-1m">29</td><td id="12-1n">54,185</td><td id="12-1o">29</td></tr>
<tr><td id="12-1p">APAC(1)</td><td id="12-1q">13,823</td><td id="12-1r">16</td><td id="12-1s">16,480</td><td id="12-1t">17</td><td id="12-1u">27,112</td><td id="12-1v">17</td><td id="12-1w">31,334</td><td id="12-1x">17</td></tr>
<tr><td id="12-1y">Other Americas (1)</td><td id="12-1z">4,938</td><td id="12-1A">6</td><td id="12-1B">5,735</td><td id="12-1C">6</td><td id="12-1D">9,591</td><td id="12-1E">6</td><td id="12-1F">10,968</td><td id="12-1G">6</td></tr>
<tr><td id="12-1H">Hedging gains (losses)</td><td id="12-1I">102</td><td id="12-1J">0</td><td id="12-1K">(112)</td><td id="12-1L">0</td><td id="12-1M">174</td><td id="12-1N">0</td><td id="12-1O">148</td><td id="12-1P">0</td></tr>
<tr><td id="12-1Q">Total revenues</td><td id="12-1R">$ 84,742</td><td id="12-1S">100%</td><td id="12-1T">$ 96,428</td><td id="12-1U">100%</td><td id="12-1V">$165,281</td><td id="12-1W">100 %</td><td id="12-1X">$186,662</td><td id="12-1Y">100 %</td></tr>
</table>
(1) Regions represent Europe, the Middle East, and Africa (EMEA); Asia-Pacific (APAC); and Canada and Latin America
("Other Americas").

<a id='158e2a53-a145-4145-b33a-e5d3cf817a77'></a>

# Revenue Backlog

As of June 30, 2025, we had $108.2 billion of remaining performance obligations ("revenue backlog"), primarily related to Google Cloud. Revenue backlog represents commitments in customer contracts for future services that have not yet been recognized as revenue. We expect to recognize approximately 55% of the revenue backlog as revenues over the next 24 months with the remainder to be recognized thereafter. The estimated revenue backlog and timing of revenue recognition for these commitments is largely driven by our ability to deliver in accordance with relevant contract terms and when our customers utilize services. Revenue backlog includes related deferred revenue currently recorded as well as amounts that will be invoiced in future periods, and excludes contracts with an original expected term of one year or less and cancellable contracts.

<a id='d3db3192-92bd-4c3b-9fae-b26eca59936f'></a>

## Deferred Revenues

We record deferred revenues when cash payments are received or due in advance of our performance, including amounts which are refundable. Deferred revenues primarily relate to Google Cloud and Google subscriptions, platforms, and devices. Total deferred revenue as of December 31, 2024 was $6.0 billion, of which $3.5 billion was recognized as revenues for the six months ended June 30, 2025. Total deferred revenue as of June 30, 2025 was $6.8 billion.

<a id='9dcb1a77-425b-4c7e-8aca-d3c3639652cc'></a>

Note 3. Financial Instruments
Fair Value Measurements
*Investments Measured at Fair Value on a Recurring Basis*
Cash, cash equivalents, and marketable equity securities are measured at fair value and classified within

<a id='fb9c03d9-011c-41ce-9279-4a9bc8a43c51'></a>

13

<!-- PAGE BREAK -->

<a id='de2608c0-16ed-49f9-a0b9-5696ff66d7a0'></a>

Table of Contents

<a id='d57d7ff1-3fa8-45b8-a97d-5a030494bfd4'></a>

Alphabet Inc.

<a id='cb4930b8-8983-4ad2-a065-a0ce8f56c49c'></a>

Level 1 and Level 2 in the fair value hierarchy, because we use quoted prices for identical assets in active markets or inputs that are based upon quoted prices for similar instruments in active markets.

<a id='49bfb946-be4d-4117-87e2-f25d5065d6be'></a>

Debt securities are measured at fair value and classified within Level 2 in the fair value hierarchy, because we use quoted market prices to the extent available or alternative pricing sources and models utilizing market observable inputs to determine fair value. For certain marketable debt securities, we have elected the fair value option for which changes in fair value are recorded in OI&E. The fair value option was elected for these securities to align with the unrealized gains and losses from related derivative contracts.

<a id='331886b7-1f2b-4cfa-b592-620f972577d8'></a>

The following tables summarize our cash, cash equivalents, and marketable securities measured at fair value on a recurring basis (in millions):

<a id='0632866c-c1ab-4d46-84ef-2c63dbde5a93'></a>

<table id="13-1">
<tr><td id="13-2"></td><td id="13-3"></td><td id="13-4" colspan="6">As of December 31, 2024</td></tr>
<tr><td id="13-5"></td><td id="13-6">Fair Value Hierarchy</td><td id="13-7">Adjusted Cost</td><td id="13-8">Gross Unrealized Gains</td><td id="13-9">Gross Unrealized Losses</td><td id="13-a">Fair Value</td><td id="13-b">Cash and Cash Equivalents</td><td id="13-c">Marketable Securities</td></tr>
<tr><td id="13-d">Fair value changes recorded in other comprehensive income</td><td id="13-e"></td><td id="13-f"></td><td id="13-g"></td><td id="13-h"></td><td id="13-i"></td><td id="13-j"></td><td id="13-k"></td></tr>
<tr><td id="13-l">Time deposits</td><td id="13-m">Level 2</td><td id="13-n">$ 2,217</td><td id="13-o">$ 0</td><td id="13-p">$ 0</td><td id="13-q">$ 2,217</td><td id="13-r">$ 2,081</td><td id="13-s">$ 136</td></tr>
<tr><td id="13-t">Government bonds</td><td id="13-u">Level 2</td><td id="13-v">27,551</td><td id="13-w">83</td><td id="13-x">(214)</td><td id="13-y">27,420</td><td id="13-z">50</td><td id="13-A">27,370</td></tr>
<tr><td id="13-B">Corporate debt securities</td><td id="13-C">Level 2</td><td id="13-D">18,300</td><td id="13-E">79</td><td id="13-F">(222)</td><td id="13-G">18,157</td><td id="13-H">0</td><td id="13-I">18,157</td></tr>
<tr><td id="13-J">Mortgage-backed and asset-backed securities</td><td id="13-K">Level 2</td><td id="13-L">14,437</td><td id="13-M">63</td><td id="13-N">(385)</td><td id="13-O">14,115</td><td id="13-P">0</td><td id="13-Q">14,115</td></tr>
<tr><td id="13-R">Total investments with fair value change reflected in other comprehensive income (1)</td><td id="13-S"></td><td id="13-T">62,505</td><td id="13-U">225</td><td id="13-V">(821)</td><td id="13-W">61,909</td><td id="13-X">2,131</td><td id="13-Y">59,778</td></tr>
<tr><td id="13-Z">Fair value adjustments recorded in net income</td><td id="13-10"></td><td id="13-11"></td><td id="13-12"></td><td id="13-13"></td><td id="13-14"></td><td id="13-15"></td><td id="13-16"></td></tr>
<tr><td id="13-17">Money market funds</td><td id="13-18">Level 1</td><td id="13-19"></td><td id="13-1a"></td><td id="13-1b"></td><td id="13-1c">8,154</td><td id="13-1d">8,154</td><td id="13-1e">0</td></tr>
<tr><td id="13-1f">Current marketable equity securities (2)</td><td id="13-1g">Level 1</td><td id="13-1h"></td><td id="13-1i"></td><td id="13-1j"></td><td id="13-1k">4,708</td><td id="13-1l">0</td><td id="13-1m">4,708</td></tr>
<tr><td id="13-1n">Mutual funds</td><td id="13-1o">Level 2</td><td id="13-1p"></td><td id="13-1q"></td><td id="13-1r"></td><td id="13-1s">105</td><td id="13-1t">0</td><td id="13-1u">105</td></tr>
<tr><td id="13-1v">Government bonds</td><td id="13-1w">Level 2</td><td id="13-1x"></td><td id="13-1y"></td><td id="13-1z"></td><td id="13-1A">2,035</td><td id="13-1B">696</td><td id="13-1C">1,339</td></tr>
<tr><td id="13-1D">Corporate debt securities</td><td id="13-1E">Level 2</td><td id="13-1F"></td><td id="13-1G"></td><td id="13-1H"></td><td id="13-1I">3,037</td><td id="13-1J">78</td><td id="13-1K">2,959</td></tr>
<tr><td id="13-1L">Mortgage-backed and asset-backed securities</td><td id="13-1M">Level 2</td><td id="13-1N"></td><td id="13-1O"></td><td id="13-1P"></td><td id="13-1Q">3,302</td><td id="13-1R">0</td><td id="13-1S">3,302</td></tr>
<tr><td id="13-1T">Total investments with fair value change recorded in net income</td><td id="13-1U"></td><td id="13-1V"></td><td id="13-1W"></td><td id="13-1X"></td><td id="13-1Y">21,341</td><td id="13-1Z">8,928</td><td id="13-20">12,413</td></tr>
<tr><td id="13-21">Cash</td><td id="13-22"></td><td id="13-23"></td><td id="13-24"></td><td id="13-25"></td><td id="13-26">0</td><td id="13-27">12,407</td><td id="13-28">0</td></tr>
<tr><td id="13-29">Total</td><td id="13-2a"></td><td id="13-2b">$ 62,505</td><td id="13-2c">$ 225</td><td id="13-2d">$ (821)</td><td id="13-2e">83,250</td><td id="13-2f">23,466</td><td id="13-2g">72,191</td></tr>
</table>
(1) Represents gross unrealized gains and losses for debt securities recorded to accumulated other comprehensive income

<a id='bac934c7-c85b-4576-a205-8d6350722f3a'></a>

(2) The long-term portion of marketable equity securities (subject to long-term lock-up restrictions) of $266 million as of December 31, 2024 is included within other non-current assets.

<a id='1b6af6a0-f808-4c33-8926-7d0c7dcddf3f'></a>

14

<!-- PAGE BREAK -->

<a id='0fd8e372-f0db-4a11-b018-b5363fa239b2'></a>

Table of Contents

<a id='7d34f3d5-1d38-4fc2-a975-11cebee9d7be'></a>

Alphabet Inc.

<a id='b8fa3fc3-29d5-4126-8a5b-ca4e95ffa3b6'></a>

<table id="14-1">
<tr><td id="14-2"></td><td id="14-3"></td><td id="14-4" colspan="6">As of June 30, 2025</td></tr>
<tr><td id="14-5"></td><td id="14-6">Fair Value Hierarchy</td><td id="14-7">Adjusted Cost</td><td id="14-8">Gross Unrealized Gains</td><td id="14-9">Gross Unrealized Losses</td><td id="14-a">Fair Value</td><td id="14-b">Cash and Cash Equivalents</td><td id="14-c">Marketable Securities</td></tr>
<tr><td id="14-d">Fair value changes recorded in other comprehensive income</td><td id="14-e"></td><td id="14-f"></td><td id="14-g"></td><td id="14-h"></td><td id="14-i"></td><td id="14-j"></td><td id="14-k"></td></tr>
<tr><td id="14-l">Time deposits</td><td id="14-m">Level 2</td><td id="14-n">$ 3,735</td><td id="14-o">$ 0</td><td id="14-p">$ 0</td><td id="14-q">$ 3,735</td><td id="14-r">$ 3,698</td><td id="14-s">$ 37</td></tr>
<tr><td id="14-t">Government bonds</td><td id="14-u">Level 2</td><td id="14-v">26,738</td><td id="14-w">380</td><td id="14-x">(48)</td><td id="14-y">27,070</td><td id="14-z">2</td><td id="14-A">27,068</td></tr>
<tr><td id="14-B">Corporate debt securities</td><td id="14-C">Level 2</td><td id="14-D">18,382</td><td id="14-E">205</td><td id="14-F">(84)</td><td id="14-G">18,503</td><td id="14-H">1</td><td id="14-I">18,502</td></tr>
<tr><td id="14-J">Mortgage-backed and asset-backed securities</td><td id="14-K">Level 2</td><td id="14-L">14,198</td><td id="14-M">117</td><td id="14-N">(215)</td><td id="14-O">14,100</td><td id="14-P">0</td><td id="14-Q">14,100</td></tr>
<tr><td id="14-R">Total investments with fair value change reflected in other comprehensive income (1)</td><td id="14-S"></td><td id="14-T">63,053</td><td id="14-U">702</td><td id="14-V">(347)</td><td id="14-W">63,408</td><td id="14-X">3,701</td><td id="14-Y">59,707</td></tr>
<tr><td id="14-Z">Fair value adjustments recorded in net income</td><td id="14-10"></td><td id="14-11"></td><td id="14-12"></td><td id="14-13"></td><td id="14-14"></td><td id="14-15"></td><td id="14-16"></td></tr>
<tr><td id="14-17">Money market funds</td><td id="14-18">Level 1</td><td id="14-19"></td><td id="14-1a"></td><td id="14-1b"></td><td id="14-1c">5,473</td><td id="14-1d">5,473</td><td id="14-1e">0</td></tr>
<tr><td id="14-1f">Current marketable equity securities</td><td id="14-1g">Level 1</td><td id="14-1h"></td><td id="14-1i"></td><td id="14-1j"></td><td id="14-1k">5,910</td><td id="14-1l">0</td><td id="14-1m">5,910</td></tr>
<tr><td id="14-1n">Mutual funds</td><td id="14-1o">Level 2</td><td id="14-1p"></td><td id="14-1q"></td><td id="14-1r"></td><td id="14-1s">55</td><td id="14-1t">0</td><td id="14-1u">55</td></tr>
<tr><td id="14-1v">Government bonds</td><td id="14-1w">Level 2</td><td id="14-1x"></td><td id="14-1y"></td><td id="14-1z"></td><td id="14-1A">2,035</td><td id="14-1B">162</td><td id="14-1C">1,873</td></tr>
<tr><td id="14-1D">Corporate debt securities</td><td id="14-1E">Level 2</td><td id="14-1F"></td><td id="14-1G"></td><td id="14-1H"></td><td id="14-1I">3,055</td><td id="14-1J">77</td><td id="14-1K">2,978</td></tr>
<tr><td id="14-1L">Mortgage-backed and asset-backed securities</td><td id="14-1M">Level 2</td><td id="14-1N"></td><td id="14-1O"></td><td id="14-1P"></td><td id="14-1Q">3,589</td><td id="14-1R">0</td><td id="14-1S">3,589</td></tr>
<tr><td id="14-1T">Total investments with fair value change recorded in net income</td><td id="14-1U"></td><td id="14-1V"></td><td id="14-1W"></td><td id="14-1X"></td><td id="14-1Y">20,117</td><td id="14-1Z">5,712</td><td id="14-20">14,405</td></tr>
<tr><td id="14-21">Cash</td><td id="14-22"></td><td id="14-23"></td><td id="14-24"></td><td id="14-25"></td><td id="14-26">0</td><td id="14-27">11,623</td><td id="14-28">0</td></tr>
<tr><td id="14-29">Total</td><td id="14-2a"></td><td id="14-2b">$ 63,053</td><td id="14-2c">$ 702</td><td id="14-2d">$ (347)</td><td id="14-2e">$ 83,525</td><td id="14-2f">$ 21,036</td><td id="14-2g">$ 74,112</td></tr>
</table>
\n(1) Represents gross unrealized gains and losses for debt securities recorded to AOCI.

<a id='cd2b3d9b-137c-4468-a17c-07c64f69eefb'></a>

_Investments Measured at Fair Value on a Nonrecurring Basis_

Our non-marketable equity securities are investments in privately held companies without readily determinable market values. The carrying value of our non-marketable equity securities is adjusted to fair value upon observable transactions for identical or similar investments of the same issuer or impairment. Non-marketable equity securities that have been remeasured during the period based on observable transactions are classified within Level 2 or Level 3 in the fair value hierarchy. Non-marketable equity securities that have been remeasured due to impairment are classified within Level 3. Our valuation methods include option pricing models, market comparable approach, and common stock equivalent method, which may include a combination of the observable transaction price at the transaction date and other unobservable inputs including volatility, expected time to exit, risk free rate, and the rights, and obligations of the securities we hold. These inputs vary significantly based on investment type.

<a id='3b1e8d06-8a55-48f3-a64e-615d5b7095fa'></a>

As of June 30, 2025, the carrying value of our non-marketable equity securities was $49.8 billion, of which $3.2 billion was remeasured at fair value during the three months ended June 30, 2025 and was primarily classified within Level 2 of the fair value hierarchy at the time of measurement.

<a id='47315c79-7aad-49e6-bd0f-155558ad88f6'></a>

15

<!-- PAGE BREAK -->

<a id='d75e16fb-5c71-4710-b9d0-f99c1e19f097'></a>

Table of Contents

<a id='f3b4a172-9d74-4d49-88b4-619af86db239'></a>

Alphabet Inc.

<a id='641682a1-cf27-416f-b298-556d5b8e7524'></a>

**Debt Securities**
The following table summarizes the estimated fair value of investments in available-for-sale marketable debt
securities by effective contractual maturity dates (in millions):

<a id='219fd52e-df5b-4798-8236-d893b8c6bd6c'></a>

<table id="15-1">
<tr><td id="15-2"></td><td id="15-3">As of June 30, 2025</td></tr>
<tr><td id="15-4">Due in 1 year or less</td><td id="15-5">$ 5,930</td></tr>
<tr><td id="15-6">Due in 1 year through 5 years</td><td id="15-7">37,136</td></tr>
<tr><td id="15-8">Due in 5 years through 10 years</td><td id="15-9">11,846</td></tr>
<tr><td id="15-a">Due after 10 years</td><td id="15-b">13,235</td></tr>
<tr><td id="15-c">Total</td><td id="15-d">$ 68,147</td></tr>
</table>

<a id='37342779-39fc-445a-981c-0fc3a8056d97'></a>

The following tables present fair values and gross unrealized losses recorded to AOCI, aggregated by investment category and the length of time that individual securities have been in a continuous loss position (in millions):

<a id='195767b1-e925-4a7c-97bc-38975da1365b'></a>

<table id="15-e">
<tr><td id="15-f"></td><td id="15-g" colspan="6">As of December 31, 2024</td></tr>
<tr><td id="15-h"></td><td id="15-i" colspan="2">Less than 12 Months</td><td id="15-j" colspan="2">12 Months or Greater</td><td id="15-k" colspan="2">Total</td></tr>
<tr><td id="15-l"></td><td id="15-m">Fair Value</td><td id="15-n">Unrealized Loss</td><td id="15-o">Fair Value</td><td id="15-p">Unrealized Loss</td><td id="15-q">Fair Value</td><td id="15-r">Unrealized Loss</td></tr>
<tr><td id="15-s">Government bonds</td><td id="15-t">$ 11,119</td><td id="15-u">$ (126)</td><td id="15-v">$ 2,576</td><td id="15-w">$ (88)</td><td id="15-x">$ 13,695</td><td id="15-y">$ (214)</td></tr>
<tr><td id="15-z">Corporate debt securities</td><td id="15-A">4,228</td><td id="15-B">(17)</td><td id="15-C">6,838</td><td id="15-D">(168)</td><td id="15-E">11,066</td><td id="15-F">(185)</td></tr>
<tr><td id="15-G">Mortgage-backed and asset-backed securities</td><td id="15-H">5,222</td><td id="15-I">(106)</td><td id="15-J">3,813</td><td id="15-K">(279)</td><td id="15-L">9,035</td><td id="15-M">(385)</td></tr>
<tr><td id="15-N">Total</td><td id="15-O">$ 20,569</td><td id="15-P">$ (249)</td><td id="15-Q">$ 13,227</td><td id="15-R">$ (535)</td><td id="15-S">$ 33,796</td><td id="15-T">$ (784)</td></tr>
</table>

<a id='d53ca404-6f0e-4813-b514-2296b0d59e32'></a>

<table id="15-U">
<tr><td id="15-V"></td><td id="15-W" colspan="6">As of June 30, 2025</td></tr>
<tr><td id="15-X"></td><td id="15-Y" colspan="2">Less than 12 Months</td><td id="15-Z" colspan="2">12 Months or Greater</td><td id="15-10" colspan="2">Total</td></tr>
<tr><td id="15-11"></td><td id="15-12">Fair Value</td><td id="15-13">Unrealized Loss</td><td id="15-14">Fair Value</td><td id="15-15">Unrealized Loss</td><td id="15-16">Fair Value</td><td id="15-17">Unrealized Loss</td></tr>
<tr><td id="15-18">Government bonds</td><td id="15-19">$ 2,391</td><td id="15-1a">$ (19)</td><td id="15-1b">$ 1,370</td><td id="15-1c">$ (29)</td><td id="15-1d">$ 3,761</td><td id="15-1e">$ (48)</td></tr>
<tr><td id="15-1f">Corporate debt securities</td><td id="15-1g">1,020</td><td id="15-1h">(1)</td><td id="15-1i">4,247</td><td id="15-1j">(73)</td><td id="15-1k">5,267</td><td id="15-1l">(74)</td></tr>
<tr><td id="15-1m">Mortgage-backed and asset-backed securities</td><td id="15-1n">2,666</td><td id="15-1o">(48)</td><td id="15-1p">2,867</td><td id="15-1q">(167)</td><td id="15-1r">5,533</td><td id="15-1s">(215)</td></tr>
<tr><td id="15-1t">Total</td><td id="15-1u">$ 6,077</td><td id="15-1v">$ (68)</td><td id="15-1w">$ 8,484</td><td id="15-1x">$ (269)</td><td id="15-1y">$ 14,561</td><td id="15-1z">$ (337)</td></tr>
</table>

<a id='fdb027c7-f38c-4fcd-bf15-6ab56109ee98'></a>

We determine realized gains or losses on the sale or extinguishment of debt securities on a specific identification method. The following table summarizes gains and losses for debt securities, reflected as a component of OI&E (in millions):

<a id='6b9d58e2-6e6f-475a-a809-b8a6a774da94'></a>

<table id="15-1A">
<tr><td id="15-1B"></td><td id="15-1C" colspan="2">Three Months Ended June 30,</td><td id="15-1D" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="15-1E"></td><td id="15-1F">2024</td><td id="15-1G">2025</td><td id="15-1H">2024</td><td id="15-1I">2025</td></tr>
<tr><td id="15-1J">Unrealized gain (loss) on fair value option debt securities</td><td id="15-1K">$ (23)</td><td id="15-1L">$ 130</td><td id="15-1M">$ (69)</td><td id="15-1N">$ 227</td></tr>
<tr><td id="15-1O">Gross realized gain on debt securities</td><td id="15-1P">161</td><td id="15-1Q">84</td><td id="15-1R">229</td><td id="15-1S">350</td></tr>
<tr><td id="15-1T">Gross realized loss on debt securities</td><td id="15-1U">(455)</td><td id="15-1V">(63)</td><td id="15-1W">(935)</td><td id="15-1X">(238)</td></tr>
<tr><td id="15-1Y">(Increase) decrease in allowance for credit losses</td><td id="15-1Z">7</td><td id="15-20">14</td><td id="15-21">3</td><td id="15-22">28</td></tr>
<tr><td id="15-23">Total gain (loss) on debt securities recognized in other income (expense), net</td><td id="15-24">$ (310)</td><td id="15-25">$ 165</td><td id="15-26">$ (772)</td><td id="15-27">$ 367</td></tr>
</table>

<a id='101f3877-a3b7-444a-8d16-3d6649e44c32'></a>

**Equity Investments**
The carrying value of equity securities is measured as the total initial cost plus the cumulative net gain (loss).
Gains and losses, including impairments, are included as a component of OI&E in the Consolidated Statements of
Income. See Note 7 for further details on OI&E. Certain of our non-marketable equity securities include our
investments in variable interest entities (VIE) where we are not the primary beneficiary. See Note 5 for further details
on VIE.

<a id='1480fa34-76e1-40a5-9751-4fbd353c86ac'></a>

16

<!-- PAGE BREAK -->

<a id='45a88baa-3b4f-4c03-a667-99ebdf470ebd'></a>

Table of Contents

<a id='e502ca8b-c06e-4288-8434-40464c9978ac'></a>

Alphabet Inc.

<a id='600ccd0f-2dd0-45e2-aa61-b17a6396f9c7'></a>

The carrying values for marketable and non-marketable equity securities are summarized below (in millions):
<table id="16-1">
<tr><td id="16-2"></td><td id="16-3" colspan="3">As of December 31, 2024</td><td id="16-4" colspan="3">As of June 30, 2025</td></tr>
<tr><td id="16-5"></td><td id="16-6">Marketable Equity Securities</td><td id="16-7">Non-Marketable Equity Securities</td><td id="16-8">Total</td><td id="16-9">Marketable Equity Securities</td><td id="16-a">Non-Marketable Equity Securities</td><td id="16-b">Total</td></tr>
<tr><td id="16-c">Total initial cost</td><td id="16-d">$ 4,767</td><td id="16-e">$ 21,240</td><td id="16-f">$ 26,007</td><td id="16-g">$ 4,423</td><td id="16-h">$ 26,152</td><td id="16-i">$ 30,575</td></tr>
<tr><td id="16-j">Cumulative net gain (loss)(1)</td><td id="16-k">312</td><td id="16-l">14,291</td><td id="16-m">14,603</td><td id="16-n">1,552</td><td id="16-o">23,682</td><td id="16-p">25,234</td></tr>
<tr><td id="16-q">Carrying value</td><td id="16-r">$ 5,079</td><td id="16-s">$ 35,531</td><td id="16-t">$ 40,610</td><td id="16-u">$ 5,975</td><td id="16-v">$ 49,834</td><td id="16-w">$ 55,809</td></tr>
</table>
(1) Non-marketable equity securities cumulative net gain (loss) is comprised of $22.7 billion and $32.8 billion of gains and $8.4
billion and $9.1 billion of losses (including impairments) as of December 31, 2024 and June 30, 2025, respectively.

<a id='ea72d698-1914-4729-8410-ab67a372e141'></a>

Gains and Losses on Marketable and Non-marketable Equity Securities
Gains and losses (including impairments), net, for marketable and non-marketable equity securities included in
OI&E are summarized below (in millions):
<table id="16-x">
<tr><td id="16-y"></td><td id="16-z" colspan="2">Three Months Ended June 30,</td><td id="16-A" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="16-B"></td><td id="16-C">2024</td><td id="16-D">2025</td><td id="16-E">2024</td><td id="16-F">2025</td></tr>
<tr><td id="16-G">Realized net gain (loss) on equity securities sold during the period</td><td id="16-H">$ 64</td><td id="16-I">$ 217</td><td id="16-J">$ 184</td><td id="16-K">$ 435</td></tr>
<tr><td id="16-L">Unrealized net gain (loss) on marketable equity securities</td><td id="16-M">(350)</td><td id="16-N">853</td><td id="16-O">(214)</td><td id="16-P">1,088</td></tr>
<tr><td id="16-Q">Unrealized net gain (loss) on non-marketable equity securities (1)</td><td id="16-R">(428)</td><td id="16-S">216</td><td id="16-T">1,559</td><td id="16-U">9,521</td></tr>
<tr><td id="16-V">Total gain (loss) on equity securities in other income (expense), net</td><td id="16-W">$ (714)</td><td id="16-X">$ 1,286</td><td id="16-Y">$ 1,529</td><td id="16-Z">$ 11,044</td></tr>
</table>

<a id='c26712f3-a829-4aa8-8f4c-98bb6892cbc9'></a>

(1) Unrealized gain (loss) on non-marketable equity securities accounted for under the measurement alternative is comprised of $319 million and $660 million of upward adjustments and $745 million and $454 million of downward adjustments (including impairments) for the three months ended June 30, 2024 and 2025, respectively, and $3.1 billion and $10.4 billion of upward adjustments and $1.6 billion and $853 million of downward adjustments (including impairments) for the six months ended June 30, 2024 and 2025, respectively.

<a id='391cb817-b4c7-4206-a5f1-942164b6d8b0'></a>

In the table above, realized net gain (loss) on equity securities sold during the period reflects the difference between the sale proceeds and the carrying value of the equity securities at the beginning of the period or the purchase date, if later.

<a id='28001914-ea76-4385-94e5-8bd52563fa42'></a>

Cumulative net gains (losses) on equity securities sold during the period, which is summarized in the following table (in millions), represents the total net gains (losses) recognized after the initial purchase date of the equity security sold during the period. While these net gains (losses) may have been reflected in periods prior to the period of sale, we believe they are important supplemental information as they reflect the economic net gains (losses) on the securities sold during the period. Cumulative net gains (losses) are calculated as the difference between the sale price and the initial purchase price for the equity security sold during the period.

<a id='7d357c2e-a286-4a1c-9df6-5161e2c58612'></a>

<table id="16-10">
<tr><td id="16-11"></td><td id="16-12" colspan="2">Three Months Ended June 30,</td><td id="16-13" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="16-14"></td><td id="16-15">2024</td><td id="16-16">2025</td><td id="16-17">2024</td><td id="16-18">2025</td></tr>
<tr><td id="16-19">Total sale price</td><td id="16-1a">$ 583</td><td id="16-1b">$ 315</td><td id="16-1c">$ 1,673</td><td id="16-1d">$ 1,068</td></tr>
<tr><td id="16-1e">Total initial cost</td><td id="16-1f">303</td><td id="16-1g">272</td><td id="16-1h">964</td><td id="16-1i">864</td></tr>
<tr><td id="16-1j">Cumulative net gains (losses)</td><td id="16-1k">$ 280</td><td id="16-1l">$ 43</td><td id="16-1m">$ 709</td><td id="16-1n">$ 204</td></tr>
</table>

<a id='f5e1d3eb-7fe8-4a05-894a-bb9c0fcd93d1'></a>

**Equity Securities Accounted for Under the Equity Method**
As of December 31, 2024 and June 30, 2025, equity securities accounted for under the equity method had a carrying value of approximately $2.0 billion and $2.3 billion, respectively. Our share of gains and losses, including impairments, are included as a component of OI&E, in the Consolidated Statements of Income. See Note 7 for further details on OI&E. Certain of our equity method securities include our investments in VIEs where we are not the primary beneficiary. See Note 5 for further details on VIEs.

<a id='bef18819-b6fe-4130-a647-15d19c37e7cd'></a>

Convertible Notes

<a id='21b60483-1a0b-4b01-a5f3-6c717670fcf2'></a>

17

<!-- PAGE BREAK -->

<a id='d3c72bcc-5788-4170-83c8-f97afef1aeac'></a>

Table of Contents

<a id='60ec885a-d081-4d08-ae9b-99f350107b30'></a>

Alphabet Inc.

<a id='d60cac0a-290a-4153-981b-1165fb57a718'></a>

As of December 31, 2024 and June 30, 2025, we had investments in convertible notes of $2.9 billion and $651 million, respectively. During the six months ended June 30, 2025, we converted $3.0 billion of our convertible notes into equity securities, which included gains from conversion of $416 million. These gains were recognized in OI&E within the Consolidated Statement of Income. See Note 7 for further details on OI&E.

<a id='6a1d2270-dc88-4bb6-8d9f-f1f46dfde0e6'></a>

### Derivative Financial Instruments

We use derivative instruments to manage risks relating to our ongoing business operations. The primary risk managed is foreign exchange risk. We use foreign currency contracts to reduce the risk that our cash flows, earnings, and investment in foreign subsidiaries will be adversely affected by foreign currency exchange rate fluctuations. We also enter into derivative instruments to partially offset our exposure to other risks and enhance investment returns.

<a id='37b4a8db-f824-49a1-8927-7c1d076172a6'></a>

We recognize derivative instruments in the Consolidated Balance Sheets at fair value and classify the derivatives primarily within Level 2 in the fair value hierarchy. We present our collar contracts (an option strategy comprised of a combination of purchased and written options) at net fair values and present all other derivatives at gross fair values. The accounting treatment for derivatives is based on the intended use and hedge designation.

<a id='b0202a0e-752f-4701-8913-7f9e97288247'></a>

Cash Flow Hedges

We designate foreign currency forward and option contracts (including collars) as cash flow hedges to hedge certain forecasted revenue transactions denominated in currencies other than the United States (U.S.) dollar. These contracts have maturities of 24 months or less.

<a id='e6d174c8-ddba-45cc-adc2-bc3f68bc5323'></a>

Cash flow hedge amounts included in the assessment of hedge effectiveness are deferred in AOCI and subsequently reclassified to revenue when the hedged item is recognized in earnings. We exclude forward points and time value from our assessment of hedge effectiveness and amortize them on a straight-line basis over the life of the hedging instrument in revenues. The difference between fair value changes of the excluded component and the amount amortized to revenues is recorded in AOCI.

<a id='04f53ba9-7fde-4b0e-b06d-ba2e0d400705'></a>

As of June 30, 2025, the net accumulated loss on our foreign currency cash flow hedges before tax effect was $767 million, which is expected to be reclassified from AOCI into revenues within the next 12 months.

<a id='a3b417a3-c63a-499e-ae7e-42e09fe0526c'></a>

**Fair Value Hedges**

We designate foreign currency forward contracts as fair value hedges to hedge foreign currency risks for our marketable securities denominated in currencies other than the U.S. dollar. Fair value hedge amounts included in the assessment of hedge effectiveness are recognized in OI&E, along with the offsetting gains and losses of the related hedged items. We exclude forward points from the assessment of hedge effectiveness and recognize changes in the excluded component in OI&E.

<a id='ec844018-8d7f-489e-8bfa-eb9cce297479'></a>

_Net Investment Hedges_

We designate foreign currency forward contracts, option contracts (including collars), and foreign currency-denominated debt as net investment hedges to hedge the foreign currency risks related to our investment in foreign subsidiaries. Net investment hedge amounts included in the assessment of hedge effectiveness are recognized in AOCI along with the foreign currency translation adjustment. For derivative instruments, we exclude forward points and time value from the assessment of hedge effectiveness and recognize changes in the excluded component in OI&E.

<a id='79fcb2c8-a902-40ec-ab16-7bc620f43699'></a>

We had no foreign currency-denominated debt as of December 31, 2024 and $7.8 billion carrying value of foreign currency-denominated debt designated as net investment hedges as of June 30, 2025.

<a id='7474bea3-2900-489f-bd3b-d90539634baf'></a>

*Other Derivatives*

We enter into foreign currency forward and option contracts that are not designated as hedging instruments to hedge intercompany transactions and other monetary assets or liabilities denominated in currencies other than the functional currency of a subsidiary. Gains and losses on these derivatives that are not designated as accounting hedges are primarily recorded in OI&E along with the foreign currency gains and losses on monetary assets and liabilities.

<a id='dd7b10e9-a786-4f62-8c61-9bc5f4889763'></a>

We also use derivatives not designated as hedging instruments to manage risks relating to interest rates, commodity prices, and credit exposures, and to enhance investment returns. From time to time, we enter into derivatives to hedge the market price risk on certain of our marketable equity securities. Gains and losses arising from other derivatives are primarily reflected within the "other" component of OI&E. See Note 7 for further details.

<a id='77d4e8e2-98e1-486e-a100-98d76722e9e7'></a>

18

<!-- PAGE BREAK -->

<a id='bee1967e-9dab-44df-b60b-f9467f319db7'></a>

The gross notional amounts of outstanding derivative instruments were as follows (in millions):
<table id="18-1">
<tr><td id="18-2"></td><td id="18-3">As of December 31, 2024</td><td id="18-4">As of June 30, 2025</td></tr>
<tr><td id="18-5" colspan="3">Derivatives designated as hedging instruments:</td></tr>
<tr><td id="18-6" colspan="3">Foreign exchange contracts</td></tr>
<tr><td id="18-7">Cash flow hedges</td><td id="18-8">$ 20,315</td><td id="18-9">$ 22,884</td></tr>
<tr><td id="18-a">Fair value hedges</td><td id="18-b">$ 1,562</td><td id="18-c">$ 0</td></tr>
<tr><td id="18-d">Net investment hedges</td><td id="18-e">6,986</td><td id="18-f">7,668</td></tr>
<tr><td id="18-g" colspan="3">Derivatives not designated as hedging instruments:</td></tr>
<tr><td id="18-h">Foreign exchange contracts</td><td id="18-i">44,227</td><td id="18-j">38,023</td></tr>
<tr><td id="18-k">Other contracts</td><td id="18-l">15,082</td><td id="18-m">17,406</td></tr>
</table>

<a id='929a19b4-4a93-42eb-8843-990964d6f938'></a>

The fair values of outstanding derivative instruments were as follows (in millions):
<table id="18-n">
<tr><td id="18-o"></td><td id="18-p" colspan="2">As of December 31, 2024</td><td id="18-q" colspan="2">As of June 30, 2025</td></tr>
<tr><td id="18-r"></td><td id="18-s">Assets(1)</td><td id="18-t">Liabilities(2)</td><td id="18-u">Assets(1)</td><td id="18-v">Liabilities(2)</td></tr>
<tr><td id="18-w" colspan="5">Derivatives designated as hedging instruments:</td></tr>
<tr><td id="18-x">Foreign exchange contracts</td><td id="18-y">$ 1,054</td><td id="18-z">$ 0</td><td id="18-A">$ 36</td><td id="18-B">$ 1,541</td></tr>
<tr><td id="18-C" colspan="5">Derivatives not designated as hedging instruments:</td></tr>
<tr><td id="18-D">Foreign exchange contracts</td><td id="18-E">200</td><td id="18-F">593</td><td id="18-G">815</td><td id="18-H">188</td></tr>
<tr><td id="18-I">Other contracts</td><td id="18-J">474</td><td id="18-K">19</td><td id="18-L">252</td><td id="18-M">29</td></tr>
<tr><td id="18-N">Total derivatives not designated as hedging instruments</td><td id="18-O">674</td><td id="18-P">612</td><td id="18-Q">1,067</td><td id="18-R">217</td></tr>
<tr><td id="18-S">Total</td><td id="18-T">$ 1,728</td><td id="18-U">$ 612</td><td id="18-V">$ 1,103</td><td id="18-W">$ 1,758</td></tr>
</table>

<a id='05b55fc3-08ea-45ba-9844-7e358fe31b52'></a>

(1) Derivative assets are recorded as other current and non-current assets in the Consolidated Balance Sheets.
(2) Derivative liabilities are recorded as accrued expenses and other liabilities, current and non-current in the Consolidated Balance Sheets.

<a id='66516880-4ded-42fb-a5fa-3518c3d050f0'></a>

The gains (losses) on derivatives and non-derivative financial instruments in cash flow hedging and net investment hedging relationships recognized in other comprehensive income (OCI) are summarized below (in millions):

<a id='df29e9f3-4922-4951-8184-a31951a2966b'></a>

<table id="18-X">
<tr><td id="18-Y"></td><td id="18-Z" colspan="2">Three Months Ended June 30,</td><td id="18-10" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="18-11"></td><td id="18-12">2024</td><td id="18-13">2025</td><td id="18-14">2024</td><td id="18-15">2025</td></tr>
<tr><td id="18-16" colspan="5">Cash flow hedging relationship:</td></tr>
<tr><td id="18-17" colspan="5">Foreign exchange contracts</td></tr>
<tr><td id="18-18">Amount included in the assessment of effectiveness</td><td id="18-19">$ 277</td><td id="18-1a">$ (1,050)</td><td id="18-1b">$ 432</td><td id="18-1c">$ (1,389)</td></tr>
<tr><td id="18-1d">Amount excluded from the assessment of effectiveness</td><td id="18-1e">(7)</td><td id="18-1f">(108)</td><td id="18-1g">51</td><td id="18-1h">(169)</td></tr>
<tr><td id="18-1i" colspan="5">Net investment hedging relationship:</td></tr>
<tr><td id="18-1j" colspan="5">Amount included in the assessment of effectiveness</td></tr>
<tr><td id="18-1k">Foreign exchange contracts</td><td id="18-1l">120</td><td id="18-1m">(643)</td><td id="18-1n">202</td><td id="18-1o">(849)</td></tr>
<tr><td id="18-1p">Foreign currency-denominated debt</td><td id="18-1q">0</td><td id="18-1r">(219)</td><td id="18-1s">0</td><td id="18-1t">(219)</td></tr>
<tr><td id="18-1u">Total</td><td id="18-1v">$ 390</td><td id="18-1w">$ (2,020)</td><td id="18-1x">$ 685</td><td id="18-1y">$ (2,626)</td></tr>
</table>

<a id='e6bbcc3d-e64e-456b-86d4-10ebd2d5f35b'></a>

19

<!-- PAGE BREAK -->

<a id='53c1a8cd-16a5-4ff2-abba-c7f965c250c6'></a>

The table below presents the gains (losses) of derivatives included in the Consolidated Statements of Income:
(in millions):

<a id='2a9209ef-2902-4ee3-b391-66b018fdfc24'></a>

<table id="19-1">
<tr><td id="19-2"></td><td id="19-3" colspan="4">Three Months Ended June 30,</td></tr>
<tr><td id="19-4"></td><td id="19-5" colspan="2">2024</td><td id="19-6" colspan="2">2025</td></tr>
<tr><td id="19-7"></td><td id="19-8">Revenues</td><td id="19-9">Other income (expense), net</td><td id="19-a">Revenues</td><td id="19-b">Other income (expense), net</td></tr>
<tr><td id="19-c">Total amounts included in the Consolidated Statements of Income</td><td id="19-d">$ 84,742</td><td id="19-e">$ 126</td><td id="19-f">$ 96,428</td><td id="19-g">$ 2,662</td></tr>
<tr><td id="19-h"></td><td id="19-i"></td><td id="19-j"></td><td id="19-k"></td><td id="19-l"></td></tr>
<tr><td id="19-m">Effect of cash flow hedges:</td><td id="19-n"></td><td id="19-o"></td><td id="19-p"></td><td id="19-q"></td></tr>
<tr><td id="19-r">Foreign exchange contracts</td><td id="19-s"></td><td id="19-t"></td><td id="19-u"></td><td id="19-v"></td></tr>
<tr><td id="19-w">Amount reclassified from AOCI to income</td><td id="19-x">$ 106</td><td id="19-y">$ 0</td><td id="19-z">$ (138)</td><td id="19-A">$ 0</td></tr>
<tr><td id="19-B">Amount excluded from the assessment of effectiveness (amortized)</td><td id="19-C">(4)</td><td id="19-D">0</td><td id="19-E">26</td><td id="19-F">0</td></tr>
<tr><td id="19-G">Effect of fair value hedges:</td><td id="19-H" colspan="2">(light blue rectangle)</td><td id="19-I"></td><td id="19-J"></td></tr>
<tr><td id="19-K">Foreign exchange contracts</td><td id="19-L"></td><td id="19-M"></td><td id="19-N"></td><td id="19-O"></td></tr>
<tr><td id="19-P">Hedged items</td><td id="19-Q">0</td><td id="19-R">(9)</td><td id="19-S">0</td><td id="19-T">0</td></tr>
<tr><td id="19-U">Derivatives designated as hedging instruments</td><td id="19-V">0</td><td id="19-W">9</td><td id="19-X">0</td><td id="19-Y">0</td></tr>
<tr><td id="19-Z">Amount excluded from the assessment of effectiveness</td><td id="19-10">0</td><td id="19-11">3</td><td id="19-12">0</td><td id="19-13">0</td></tr>
<tr><td id="19-14" colspan="5">Effect of net investment hedges:</td></tr>
<tr><td id="19-15">Foreign exchange contracts</td><td id="19-16"></td><td id="19-17"></td><td id="19-18"></td><td id="19-19"></td></tr>
<tr><td id="19-1a">Amount excluded from the assessment of effectiveness</td><td id="19-1b">0</td><td id="19-1c">31</td><td id="19-1d">0</td><td id="19-1e">29</td></tr>
<tr><td id="19-1f">Effect of non designated hedges:</td><td id="19-1g"></td><td id="19-1h"></td><td id="19-1i"></td><td id="19-1j"></td></tr>
<tr><td id="19-1k">Foreign exchange contracts</td><td id="19-1l">0</td><td id="19-1m">(22)</td><td id="19-1n">0</td><td id="19-1o">180</td></tr>
<tr><td id="19-1p">Other contracts</td><td id="19-1q">0</td><td id="19-1r">26</td><td id="19-1s">0</td><td id="19-1t">(24)</td></tr>
<tr><td id="19-1u">Total gains (losses)</td><td id="19-1v">$ 102</td><td id="19-1w">$ 38</td><td id="19-1x">$ (112)</td><td id="19-1y">$ 185</td></tr>
</table>

<a id='203fab68-7a2d-4aac-b707-2de0880bfa9a'></a>

20

<!-- PAGE BREAK -->

<a id='736d4029-5c67-402a-a0b0-ecc62b9b8fad'></a>

<table id="20-1">
<tr><td id="20-2"></td><td id="20-3" colspan="4">Six Months Ended June 30,</td></tr>
<tr><td id="20-4"></td><td id="20-5" colspan="2">2024</td><td id="20-6" colspan="2">2025</td></tr>
<tr><td id="20-7"></td><td id="20-8">Revenues</td><td id="20-9">Other income (expense), net</td><td id="20-a">Revenues</td><td id="20-b">Other income (expense), net</td></tr>
<tr><td id="20-c">Total amounts included in the Consolidated Statements of Income</td><td id="20-d">$ 165,281</td><td id="20-e">$ 2,969</td><td id="20-f">$ 186,662</td><td id="20-g">$ 13,845</td></tr>
</table>
Effect of cash flow hedges:

<a id='1a2f3a31-3abc-498a-921a-5a0ab6c8ed3d'></a>

<::Foreign exchange contracts
Amount of gains (losses) reclassified from AOCI to income
Amount excluded from the assessment of effectiveness (amortized)
Effect of fair value hedges:
Foreign exchange contracts
Hedged items
Derivatives designated as hedging instruments
Amount excluded from the assessment of effectiveness
Effect of net investment hedges:
Foreign exchange contracts
Amount excluded from the assessment of effectiveness
Effect of non designated hedges:
Foreign exchange contracts
Other contracts
Total gains (losses)

| $ | 180 | $ | 0 | $ | 104 | $ | 0 |
|---|---|---|---|---|---|---|---|
|   | (6) |   | 0 |   | 44 |   | 0 |
|   |   |   |   |   |   |   |   |
|   | 0 |   | (25) |   | 0 |   | (9) |
|   | 0 |   | 24 |   | 0 |   | 9 |
|   | 0 |   | 6 |   | 0 |   | 1 |
|   |   |   |   |   |   |   |   |
|   | 0 |   | 67 |   | 0 |   | 60 |
|   |   |   |   |   |   |   |   |
|   | 0 |   | (1) |   | 0 |   | 245 |
|   | 0 |   | 102 |   | 0 |   | (95) |
| $ | 174 | $ | 173 | $ | 148 | $ | 211 |
: table::>

<a id='8c5a439f-5bf9-4813-a36b-e9e5d52b13e4'></a>

### Offsetting of Derivatives

We enter into master netting arrangements and collateral security arrangements to reduce credit risk. Cash collateral received related to derivative instruments under our collateral security arrangements are included in other current assets with a corresponding liability. Cash and non-cash collateral pledged related to derivative instruments under our collateral security arrangements are included in other current assets.

<a id='03a67cb6-a7c0-45f6-94d9-86eb58ac2239'></a>

The gross amounts of derivative instruments subject to master netting arrangements with various counterparties, and cash and non-cash collateral received and pledged under such agreements were as follows (in millions):

<a id='37ca3a84-a848-46c4-8ef6-d5ed667ee30f'></a>

<table id="20-h">
<tr><td id="20-i"></td><td id="20-j" colspan="6">As of December 31, 2024</td></tr>
<tr><td id="20-k"></td><td id="20-l"></td><td id="20-m"></td><td id="20-n"></td><td id="20-o" colspan="2">Gross Amounts Not Offset in the Consolidated Balance Sheets, but Have Legal Rights to Offset</td><td id="20-p"></td></tr>
<tr><td id="20-q"></td><td id="20-r">Gross Amounts Recognized</td><td id="20-s">Gross Amounts Offset in the Consolidated Balance Sheets</td><td id="20-t">Net Amounts Presented in the Consolidated Balance Sheets</td><td id="20-u">Financial Instruments(1)</td><td id="20-v">Cash and Non-Cash Collateral Received or Pledged</td><td id="20-w">Net Amounts</td></tr>
<tr><td id="20-x">Derivatives assets</td><td id="20-y">$ 1,776</td><td id="20-z">$ (48)</td><td id="20-A">$ 1,728</td><td id="20-B">$ (516)</td><td id="20-C">$ (721)</td><td id="20-D">$ 491</td></tr>
<tr><td id="20-E">Derivatives liabilities</td><td id="20-F">$ 660</td><td id="20-G">$ (48)</td><td id="20-H">$ 612</td><td id="20-I">$ (516)</td><td id="20-J">$ (9)</td><td id="20-K">$ 87</td></tr>
</table>

<a id='8c26373f-6d78-4dcb-b31c-9568e9ca6e84'></a>

21

<!-- PAGE BREAK -->

<a id='27507fb4-a395-4223-b8a8-05b6fa52a81a'></a>

As of June 30, 2025

<a id='d9f94a52-5935-4af3-8b83-c572b98bcf68'></a>

Gross Amounts Not Offset in
the Consolidated Balance
Sheets, but Have Legal Rights
to Offset
---


<a id='e1dcb545-f7e8-40ca-b1bd-306459065197'></a>

<table id="21-1">
<tr><td id="21-2"></td><td id="21-3">Gross Amounts Recognized</td><td id="21-4">Gross Amounts Offset in the Consolidated Balance Sheets</td><td id="21-5">Net Amounts Presented in the Consolidated Balance Sheets</td><td id="21-6">Financial Instruments(1)</td><td id="21-7">Cash and Non-Cash Collateral Received or Pledged</td><td id="21-8">Net Amounts</td></tr>
<tr><td id="21-9">Derivatives assets</td><td id="21-a">$ 1,224</td><td id="21-b">$ (121)</td><td id="21-c">$ 1,103</td><td id="21-d">$ (780)</td><td id="21-e">$ (72)</td><td id="21-f">$ 251</td></tr>
<tr><td id="21-g">Derivatives liabilities</td><td id="21-h">$ 1,879</td><td id="21-i">$ (121)</td><td id="21-j">$ 1,758</td><td id="21-k">$ (780)</td><td id="21-l">$ (32)</td><td id="21-m">$ 946</td></tr>
</table>
(1) The balances as of December 31, 2024 and June 30, 2025 were related to derivatives allowed to be net settled in accordance with our master netting agreements.

<a id='3eb59e22-da93-4b2d-9b3c-06d05df48aa2'></a>

Note 4. Leases
We have entered into operating and finance lease agreements primarily for data centers, land, and offices throughout the world with varying lease terms.

<a id='8f90243f-a207-43f5-b150-a6e090bc51c0'></a>

Components of lease costs were as follows (in millions):
<table id="21-n">
<tr><td id="21-o"></td><td id="21-p" colspan="2">Three Months Ended June 30,</td><td id="21-q" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="21-r"></td><td id="21-s">2024</td><td id="21-t">2025</td><td id="21-u">2024</td><td id="21-v">2025</td></tr>
<tr><td id="21-w">Operating lease cost</td><td id="21-x">$ 802</td><td id="21-y">$ 818</td><td id="21-z">$ 1,606</td><td id="21-A">$ 1,608</td></tr>
<tr><td id="21-B">Finance lease cost:</td><td id="21-C"></td><td id="21-D"></td><td id="21-E"></td><td id="21-F"></td></tr>
<tr><td id="21-G">Amortization of lease assets</td><td id="21-H">99</td><td id="21-I">112</td><td id="21-J">182</td><td id="21-K">208</td></tr>
<tr><td id="21-L">Interest on lease liabilities</td><td id="21-M">7</td><td id="21-N">16</td><td id="21-O">14</td><td id="21-P">31</td></tr>
<tr><td id="21-Q">Finance lease cost</td><td id="21-R">106</td><td id="21-S">128</td><td id="21-T">196</td><td id="21-U">239</td></tr>
<tr><td id="21-V">Variable lease cost</td><td id="21-W">343</td><td id="21-X">372</td><td id="21-Y">686</td><td id="21-Z">732</td></tr>
<tr><td id="21-10">Total lease cost</td><td id="21-11">$ 1,251</td><td id="21-12">$ 1,318</td><td id="21-13">$ 2,488</td><td id="21-14">$ 2,579</td></tr>
</table>

<a id='a813c043-eec0-483a-af8a-c00150a20066'></a>

Supplemental information related to leases was as follows (in millions):
<table id="21-15">
<tr><td id="21-16"></td><td id="21-17">As of December 31, 2024</td><td id="21-18">As of June 30, 2025</td></tr>
<tr><td id="21-19" colspan="3">Weighted average remaining lease term</td></tr>
<tr><td id="21-1a">Operating leases</td><td id="21-1b">7.8 years</td><td id="21-1c">7.8 years</td></tr>
<tr><td id="21-1d">Finance leases</td><td id="21-1e">10.4 years</td><td id="21-1f">9.6 years</td></tr>
<tr><td id="21-1g" colspan="3">Weighted average discount rate</td></tr>
<tr><td id="21-1h">Operating leases</td><td id="21-1i">3.4%</td><td id="21-1j">3.5%</td></tr>
<tr><td id="21-1k">Finance leases</td><td id="21-1l">2.8%</td><td id="21-1m">2.9%</td></tr>
</table>

<a id='b4a325c9-0f41-44b8-9b8b-3324bd96eecd'></a>

22

<!-- PAGE BREAK -->

<a id='f04069ed-3d7c-437b-bf66-87a11ecdfaaa'></a>

<table id="22-1">
<tr><td id="22-2"></td><td id="22-3">As of December 31, 2024</td><td id="22-4">As of June 30, 2025</td></tr>
<tr><td id="22-5" colspan="3">Operating leases:</td></tr>
<tr><td id="22-6">Operating lease assets</td><td id="22-7">$ 13,588</td><td id="22-8">$ 14,255</td></tr>
<tr><td id="22-9">Accrued expenses and other liabilities</td><td id="22-a">$ 2,887</td><td id="22-b">$ 3,007</td></tr>
<tr><td id="22-c">Operating lease liabilities</td><td id="22-d">11,691</td><td id="22-e">11,952</td></tr>
<tr><td id="22-f">Total operating lease liabilities</td><td id="22-g">$ 14,578</td><td id="22-h">$ 14,959</td></tr>
<tr><td id="22-i" colspan="3">Finance Leases:</td></tr>
<tr><td id="22-j">Property and equipment, at cost</td><td id="22-k">$ 4,622</td><td id="22-l">$ 5,410</td></tr>
<tr><td id="22-m">Accumulated depreciation</td><td id="22-n">(2,037)</td><td id="22-o">(2,209)</td></tr>
<tr><td id="22-p">Property and equipment, net</td><td id="22-q">$ 2,585</td><td id="22-r">$ 3,201</td></tr>
<tr><td id="22-s">Accrued expenses and other liabilities</td><td id="22-t">235</td><td id="22-u">100</td></tr>
<tr><td id="22-v">Other long-term liabilities</td><td id="22-w">1,442</td><td id="22-x">2,002</td></tr>
<tr><td id="22-y">Total finance lease liabilities</td><td id="22-z">1,677</td><td id="22-A">2,102</td></tr>
</table>
Supplemental cash flow information related to leases was as follows (in millions):

<a id='b87152e7-c90f-44b4-96ab-7f83b25fd3c2'></a>

<table id="22-B">
<tr><td id="22-C"></td><td id="22-D" colspan="2">Three Months Ended June 30,</td><td id="22-E" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="22-F"></td><td id="22-G">2024</td><td id="22-H">2025</td><td id="22-I">2024</td><td id="22-J">2025</td></tr>
<tr><td id="22-K" colspan="5">Cash payments for lease liabilities:</td></tr>
<tr><td id="22-L">Operating cash flows used for operating leases</td><td id="22-M">$ 844</td><td id="22-N">$ 783</td><td id="22-O">$ 1,686</td><td id="22-P">$ 1,661</td></tr>
<tr><td id="22-Q">Operating cash flows used for finance leases</td><td id="22-R">$ 7</td><td id="22-S">$ 16</td><td id="22-T">$ 14</td><td id="22-U">$ 31</td></tr>
<tr><td id="22-V">Financing cash flows used for finance leases(1)</td><td id="22-W">$ 97</td><td id="22-X">$ 110</td><td id="22-Y">$ 187</td><td id="22-Z">$ 302</td></tr>
<tr><td id="22-10" colspan="5">Assets obtained in exchange for lease liabilities:</td></tr>
<tr><td id="22-11">Operating leases</td><td id="22-12">$ 493</td><td id="22-13">$ 831</td><td id="22-14">$ 897</td><td id="22-15">$ 1,528</td></tr>
<tr><td id="22-16">Finance leases</td><td id="22-17">$ 146</td><td id="22-18">$ 83</td><td id="22-19">$ 165</td><td id="22-1a">$ 606</td></tr>
</table>

<a id='c4ea141a-ca19-4d3a-9e3e-30d0e7471a43'></a>

(1)
Financing cash flows used for financing leases are included within financing activities of the Consolidated Statements of
Cash Flows as repayments of debt.
Future lease payments as of June 30, 2025 were as follows (in millions):

<a id='9b5326ae-8d58-4504-a60d-24b00c159fba'></a>

<table id="22-1b">
<tr><td id="22-1c"></td><td id="22-1d">Operating Leases</td><td id="22-1e">Finance Leases</td></tr>
<tr><td id="22-1f">Remainder of 2025</td><td id="22-1g">$ 2,095</td><td id="22-1h">$ 162</td></tr>
<tr><td id="22-1i">2026</td><td id="22-1j">3,078</td><td id="22-1k">299</td></tr>
<tr><td id="22-1l">2027</td><td id="22-1m">2,549</td><td id="22-1n">301</td></tr>
<tr><td id="22-1o">2028</td><td id="22-1p">2,042</td><td id="22-1q">290</td></tr>
<tr><td id="22-1r">2029</td><td id="22-1s">1,630</td><td id="22-1t">268</td></tr>
<tr><td id="22-1u">Thereafter</td><td id="22-1v">6,035</td><td id="22-1w">1,310</td></tr>
<tr><td id="22-1x">Total future lease payments</td><td id="22-1y">17,429</td><td id="22-1z">2,630</td></tr>
<tr><td id="22-1A">Less imputed interest</td><td id="22-1B">(2,470)</td><td id="22-1C">(528)</td></tr>
<tr><td id="22-1D">Total lease liability balance</td><td id="22-1E">$ 14,959</td><td id="22-1F">$ 2,102</td></tr>
</table>

<a id='41beb953-0311-4652-ae40-bfdf79fce23f'></a>

As of June 30, 2025, we have entered into leases primarily related to data centers that have not yet
commenced with future lease payments of $23.9 billion, that are not yet recorded on our Consolidated Balance
Sheets. These leases will commence between 2025 and 2031 with non-cancelable lease terms between one and
25 years.

<a id='214f443a-8e22-4619-aeb6-cad00d0ae055'></a>

23

<!-- PAGE BREAK -->

<a id='9aaa5844-67ed-49b3-9e11-1bfba781e635'></a>

Note 5. Variable Interest Entities

Consolidated VIEs

We consolidate VIEs in which we hold a variable interest and are the primary beneficiary. The results of operations and financial position of these VIEs are included in our consolidated financial statements.

<a id='b9c9e820-e2b5-40df-9fdf-f46bdfcfa82a'></a>

For certain consolidated VIEs, their assets are not available to us, and their creditors do not have recourse to us. As of December 31, 2024 and June 30, 2025, assets that can only be used to settle obligations of these VIEs were $8.7 billion and $7.0 billion, respectively, and are primarily included in cash and cash equivalents on our Consolidated Balance Sheets. As of December 31, 2024 and June 30, 2025, liabilities for which creditors only have recourse to the VIEs were $2.3 billion and $1.8 billion, respectively. We may continue to fund ongoing operations of certain VIEs that are included within Other Bets.

<a id='46b10e35-a6d6-4209-9d96-465db5c27327'></a>

As of December 31, 2024 and June 30, 2025, total noncontrolling interests (NCI) in our consolidated subsidiaries were $4.2 billion and $4.3 billion, respectively, of which $1.1 billion was redeemable noncontrolling interests (RNCI) in each period. NCI and RNCI are included within additional paid-in capital. Net loss attributable to noncontrolling interests was not material for any period presented and is included within the "other" component of OI&E. See Note 7 for further details on OI&E.

<a id='cf4c6f40-4d50-4900-80dd-c13ba87e3c82'></a>

Unconsolidated VIEs
We have investments in VIEs in which we are not the primary beneficiary. These VIEs include private companies that are primarily early stage companies and certain renewable energy entities in which activities involve power generation using renewable sources.

<a id='d004aeca-bb70-48cb-a337-0a49998c5f51'></a>

We have determined that the governance structures of these entities do not allow us to direct the activities that would significantly affect their economic performance. Therefore, we are not the primary beneficiary, and the results of operations and financial position of these VIEs are not included in our consolidated financial statements. We account for these investments primarily as non-marketable equity securities or equity method investments, which are included within non-marketable securities on our Consolidated Balance Sheets. The maximum exposure of these unconsolidated VIEs is generally based on the current carrying value of the investments and any future funding commitments. As of December 31, 2024 and June 30, 2025, our future funding commitments related to unconsolidated VIE investments were $1.5 billion and $1.4 billion, respectively.

<a id='bfa4b98b-f482-4c9e-a41a-8ba513393fdb'></a>

Note 6. Debt

**Short-Term Debt**

We have a short-term debt financing program of up to $25.0 billion through the issuance of commercial paper. Net proceeds from this program are used for general corporate purposes. We had $2.3 billion and $3.0 billion of commercial paper outstanding as of December 31, 2024 and June 30, 2025, respectively, with a weighted-average effective interest rate of 4.4% in each period. The estimated fair value of the commercial paper approximated its carrying value as of December 31, 2024 and June 30, 2025.

<a id='e49b19d1-fb85-4762-9ef2-ad70de9df095'></a>

Our short-term debt balance also includes the current portion of certain long-term debt.

<a id='f4db6669-bb4e-41e5-aa90-6faa747bd840'></a>

Long-Term Debt

In May 2025, we issued $5.0 billion of U.S. dollar-denominated fixed-rate senior unsecured notes in four tranches: $750 million of 4.00% notes due 2030, $1.25 billion of 4.50% notes due 2035, $1.5 billion of 5.25% notes due 2055, and $1.5 billion of 5.30% notes due 2065. Additionally in May 2025, we issued  6.75 billion of euro-denominated fixed-rate senior unsecured notes in five tranches:  1.5 billion of 2.50% notes due 2029,  1.5 billion of 3.00% notes due 2033,  1.25 billion of 3.38% notes due 2037,  1.25 billion of 3.88% notes due 2045, and  1.25 billion of 4.00% notes due 2054. The net proceeds from all notes issued in May 2025 are used for general corporate purposes.

<a id='e25d8906-a277-43de-b323-248426e8cbe1'></a>

24

<!-- PAGE BREAK -->

<a id='0673c927-2fb0-4484-84a0-b168e5e0fd72'></a>

Total outstanding long-term debt is summarized below (in millions, except percentages):
<table id="24-1">
<tr><td id="24-2"></td><td id="24-3">Maturity</td><td id="24-4">Coupon Rate</td><td id="24-5">Effective Interest Rate</td><td id="24-6">As of December 31, 2024</td><td id="24-7">As of June 30, 2025</td></tr>
<tr><td id="24-8">Debt</td><td id="24-9"></td><td id="24-a"></td><td id="24-b"></td><td id="24-c"></td><td id="24-d"></td></tr>
<tr><td id="24-e">2016 U.S. dollar notes</td><td id="24-f">2026</td><td id="24-g">2.00%</td><td id="24-h">2.23%</td><td id="24-i">$ 2,000</td><td id="24-j">$ 2,000</td></tr>
<tr><td id="24-k">2020 U.S. dollar notes</td><td id="24-l">2025-2060</td><td id="24-m">0.45% -2.25%</td><td id="24-n">0.57% - 2.33%</td><td id="24-o">10,000</td><td id="24-p">10,000</td></tr>
<tr><td id="24-q">2025 U.S. dollar notes</td><td id="24-r">2030-2065</td><td id="24-s">4.00% - 5.30%</td><td id="24-t">4.21% - 5.44%</td><td id="24-u">0</td><td id="24-v">5,000</td></tr>
<tr><td id="24-w">2025 Euro notes (1)</td><td id="24-x">2029 - 2054</td><td id="24-y">2.50% - 4.00%</td><td id="24-z">2.69% - 4.12%</td><td id="24-A">0</td><td id="24-B">7,903</td></tr>
<tr><td id="24-C">Total face value of long-term debt</td><td id="24-D"></td><td id="24-E"></td><td id="24-F"></td><td id="24-G">12,000</td><td id="24-H">24,903</td></tr>
<tr><td id="24-I">Unamortized discount and debt issuance costs (1)</td><td id="24-J"></td><td id="24-K"></td><td id="24-L"></td><td id="24-M">(118)</td><td id="24-N">(296)</td></tr>
<tr><td id="24-O">Less: Current portion of long-term notes (2)</td><td id="24-P"></td><td id="24-Q"></td><td id="24-R"></td><td id="24-S">(999)</td><td id="24-T">(1,000)</td></tr>
<tr><td id="24-U">Total long-term debt</td><td id="24-V"></td><td id="24-W"></td><td id="24-X"></td><td id="24-Y">$ 10,883</td><td id="24-Z">$ 23,607</td></tr>
</table>
(1) Principal, unamortized discount, and debt issuance costs for the euro-denominated notes include the effect of foreign

<a id='47b7ecd9-0536-4c80-ad5b-391269919a12'></a>

(2)
Total current portion of long-term debt is included within accrued expenses and other current liabilities. See Note 7 for further details.

<a id='11dbd022-f464-4a9d-8252-f6702648f59d'></a>

The notes in the table above are fixed-rate senior unsecured obligations and rank equally with each other. We may redeem the notes at any time in whole or in part at specified redemption prices. The effective interest rates are based on proceeds received with interest payable semi-annually, except for the euro-denominated notes, which are payable annually.

<a id='a9fb8ac0-33ed-4765-ae0b-fe444471b086'></a>

The total estimated fair value of the outstanding notes was approximately $9.0 billion and $21.9 billion as of December 31, 2024 and June 30, 2025, respectively. The fair value was determined based on observable market prices of identical instruments in less active markets and is categorized accordingly as Level 2 in the fair value hierarchy.

<a id='5a4f663d-88e1-4212-ad10-6dbfeb71b383'></a>

## Credit Facility

As of June 30, 2025, we had $10.0 billion of revolving credit facilities, of which $4.0 billion expires in April 2026 and $6.0 billion expires in April 2030. The interest rates for all credit facilities are determined based on a formula using certain market rates. No amounts were outstanding under the credit facilities as of December 31, 2024 and June 30, 2025.

<a id='39cf13c5-6357-49ee-b8ab-4084383ca7fb'></a>

Note 7. Supplemental Financial Statement Information
Accounts Receivable

The allowance for credit losses on accounts receivable was $879 million and $878 million as of December 31, 2024 and June 30, 2025, respectively.

<a id='e61b6ee4-82c0-4ee6-87ff-6cd6c20776f4'></a>

Property and Equipment, Net
Property and equipment, net, consisted of the following (in millions):
<table id="24-10">
<tr><td id="24-11"></td><td id="24-12">As of December 31, 2024</td><td id="24-13">As of June 30, 2025</td></tr>
<tr><td id="24-14">Technical infrastructure(1)</td><td id="24-15">$ 139,596</td><td id="24-16">$ 167,467</td></tr>
<tr><td id="24-17">Office space</td><td id="24-18">43,714</td><td id="24-19">45,493</td></tr>
<tr><td id="24-1a">Corporate and other assets</td><td id="24-1b">16,519</td><td id="24-1c">17,920</td></tr>
<tr><td id="24-1d">Property and equipment, in service</td><td id="24-1e">199,829</td><td id="24-1f">230,880</td></tr>
<tr><td id="24-1g">Less: accumulated depreciation</td><td id="24-1h">(79,390)</td><td id="24-1i">(89,349)</td></tr>
<tr><td id="24-1j">Add: assets not yet in service</td><td id="24-1k">50,597</td><td id="24-1l">61,700</td></tr>
<tr><td id="24-1m">Property and equipment, net</td><td id="24-1n">$ 171,036</td><td id="24-1o">$ 203,231</td></tr>
</table>
(1) As of December 31, 2024 and June 30, 2025, approximately 60% of technical infrastructure assets were comprised of servers and network equipment. The remaining balance was comprised of data center land and buildings and related assets.

<a id='0cab127d-c2e2-4843-9b82-77a113f076af'></a>

25

<!-- PAGE BREAK -->

<a id='afeab514-596d-4fe0-a088-cb76d393d974'></a>

Accrued Expenses and Other Current Liabilities
Accrued expenses and other current liabilities consisted of the following (in millions):
<table id="25-1">
<tr><td id="25-2"></td><td id="25-3">As of December 31, 2024</td><td id="25-4">As of June 30, 2025</td></tr>
<tr><td id="25-5">Accrued purchases of property and equipment(1)</td><td id="25-6">$ 7,104</td><td id="25-7">$ 6,818</td></tr>
<tr><td id="25-8">European Commission fines(2)</td><td id="25-9">6,322</td><td id="25-a">7,099</td></tr>
<tr><td id="25-b">Accrued customer liabilities</td><td id="25-c">4,304</td><td id="25-d">4,247</td></tr>
<tr><td id="25-e">Payables to brokers for unsettled investment trades</td><td id="25-f">3,866</td><td id="25-g">3,112</td></tr>
<tr><td id="25-h">Income taxes payable, net</td><td id="25-i">2,905</td><td id="25-j">786</td></tr>
<tr><td id="25-k">Other accrued expenses and current liabilities(3)</td><td id="25-l">26,727</td><td id="25-m">29,977</td></tr>
<tr><td id="25-n">Accrued expenses and other current liabilities</td><td id="25-o">$ 51,228</td><td id="25-p">$ 52,039</td></tr>
</table>

<a id='6f437cdb-14e4-453b-9a08-e58981beed64'></a>

(1) Additional property and equipment purchases of $3.2 billion and $3.8 billion as of December 31, 2024 and June 30, 2025, respectively, were included in accounts payable.
(2) The amounts related to the European Commission (EC) fines, including any under appeal, are included in accrued expenses and other current liabilities on our Consolidated Balance Sheets. Amounts include the effects of foreign exchange and interest. See Note 10 for further details.
(3) As of June 30, 2025, other accrued expenses and current liabilities included a $1.4 billion charge related to a settlement in principle of certain legal matters.

<a id='2611b27e-d3fe-411e-aa66-b20b23813856'></a>

Accumulated Other Comprehensive Income (Loss)
Components of AOCI, net of income tax, were as follows (in millions):
<table id="25-q">
<tr><td id="25-r"></td><td id="25-s">Foreign Currency Translation Adjustments</td><td id="25-t">Unrealized Gains (Losses) on Available-for-Sale Investments</td><td id="25-u">Unrealized Gains (Losses) on Cash Flow Hedges</td><td id="25-v">Total</td></tr>
<tr><td id="25-w">Balance as of December 31, 2023</td><td id="25-x">$ (3,407)</td><td id="25-y">$ (965)</td><td id="25-z">$ (30)</td><td id="25-A">$ (4,402)</td></tr>
<tr><td id="25-B">Other comprehensive income (loss) before reclassifications</td><td id="25-C">(950)</td><td id="25-D">(453)</td><td id="25-E">367</td><td id="25-F">(1,036)</td></tr>
<tr><td id="25-G">Amounts excluded from the assessment of hedge effectiveness recorded in AOCI</td><td id="25-H">0</td><td id="25-I">0</td><td id="25-J">51</td><td id="25-K">51</td></tr>
<tr><td id="25-L">Amounts reclassified from AOCI</td><td id="25-M">0</td><td id="25-N">541</td><td id="25-O">(166)</td><td id="25-P">375</td></tr>
<tr><td id="25-Q">Other comprehensive income (loss)</td><td id="25-R">(950)</td><td id="25-S">88</td><td id="25-T">252</td><td id="25-U">(610)</td></tr>
<tr><td id="25-V">Balance as of June 30, 2024</td><td id="25-W">$ (4,357)</td><td id="25-X">$ (877)</td><td id="25-Y">$ 222</td><td id="25-Z">$ (5,012)</td></tr>
</table>

<a id='171433bb-b720-4554-aab3-29cab9d692a5'></a>

<table id="25-10">
<tr><td id="25-11"></td><td id="25-12">Foreign Currency Translation Adjustments</td><td id="25-13">Unrealized Gains (Losses) on Available-for-Sale Investments</td><td id="25-14">Unrealized Gains (Losses) on Cash Flow Hedges</td><td id="25-15">Total</td></tr>
<tr><td id="25-16">Balance as of December 31, 2024</td><td id="25-17">$ (5,080)</td><td id="25-18">$ (299)</td><td id="25-19">$ 579</td><td id="25-1a">$ (4,800)</td></tr>
<tr><td id="25-1b">Other comprehensive income (loss) before reclassifications</td><td id="25-1c">3,273</td><td id="25-1d">836</td><td id="25-1e">(1,064)</td><td id="25-1f">3,045</td></tr>
<tr><td id="25-1g">Amounts excluded from the assessment of hedge effectiveness recorded in AOCI</td><td id="25-1h">0</td><td id="25-1i">0</td><td id="25-1j">(169)</td><td id="25-1k">(169)</td></tr>
<tr><td id="25-1l">Amounts reclassified from AOCI</td><td id="25-1m">0</td><td id="25-1n">(113)</td><td id="25-1o">(90)</td><td id="25-1p">(203)</td></tr>
<tr><td id="25-1q">Other comprehensive income (loss)</td><td id="25-1r">3,273</td><td id="25-1s">723</td><td id="25-1t">(1,323)</td><td id="25-1u">2,673</td></tr>
<tr><td id="25-1v">Balance as of June 30, 2025</td><td id="25-1w">$ (1,807)</td><td id="25-1x">$ 424</td><td id="25-1y">$ (744)</td><td id="25-1z">$ (2,127)</td></tr>
</table>

<a id='3fd72d39-20f6-4a25-9b25-c8aceaea9e44'></a>

26

<!-- PAGE BREAK -->

<a id='4fdd31df-b0a1-405f-ac3d-5de7252881b3'></a>

The effects on net income of amounts reclassified from AOCI were as follows (in millions):
<table id="26-1">
<tr><td id="26-2"></td><td id="26-3"></td><td id="26-4" colspan="2">Three Months Ended June 30,</td><td id="26-5" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="26-6">AOCI Components</td><td id="26-7">Location</td><td id="26-8">2024</td><td id="26-9">2025</td><td id="26-a">2024</td><td id="26-b">2025</td></tr>
<tr><td id="26-c" colspan="6">Unrealized gains (losses) on available-for-sale investments</td></tr>
<tr><td id="26-d"></td><td id="26-e">Other income (expense), net</td><td id="26-f">$ (295)</td><td id="26-g">$ 37</td><td id="26-h">$ (694)</td><td id="26-i">$ 141</td></tr>
<tr><td id="26-j"></td><td id="26-k">Benefit (provision) for income taxes</td><td id="26-l">65</td><td id="26-m">(8)</td><td id="26-n">153</td><td id="26-o">(28)</td></tr>
<tr><td id="26-p"></td><td id="26-q">Net of income tax</td><td id="26-r">(230)</td><td id="26-s">29</td><td id="26-t">(541)</td><td id="26-u">113</td></tr>
<tr><td id="26-v" colspan="6">Unrealized gains (losses) on cash flow hedges</td></tr>
<tr><td id="26-w">Foreign exchange contracts</td><td id="26-x">Revenue</td><td id="26-y">106</td><td id="26-z">(138)</td><td id="26-A">180</td><td id="26-B">104</td></tr>
<tr><td id="26-C">Interest rate contracts</td><td id="26-D">Other income (expense), net</td><td id="26-E">0</td><td id="26-F">0</td><td id="26-G">1</td><td id="26-H">0</td></tr>
<tr><td id="26-I"></td><td id="26-J">Benefit (provision) for income taxes</td><td id="26-K">(11)</td><td id="26-L">31</td><td id="26-M">(15)</td><td id="26-N">(14)</td></tr>
<tr><td id="26-O"></td><td id="26-P">Net of income tax</td><td id="26-Q">95</td><td id="26-R">(107)</td><td id="26-S">166</td><td id="26-T">90</td></tr>
<tr><td id="26-U" colspan="2">Total amount reclassified, net of income tax</td><td id="26-V">$ (135)</td><td id="26-W">$ (78)</td><td id="26-X">$ (375)</td><td id="26-Y">$ 203</td></tr>
</table>

<a id='e3105f1f-da05-45fd-90bc-91d29821d0cc'></a>

Other Income (Expense), Net
Components of OI&E were as follows (in millions):
<table id="26-Z">
<tr><td id="26-10"></td><td id="26-11" colspan="2">Three Months Ended June 30,</td><td id="26-12" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="26-13"></td><td id="26-14">2024</td><td id="26-15">2025</td><td id="26-16">2024</td><td id="26-17">2025</td></tr>
<tr><td id="26-18">Interest income</td><td id="26-19">$ 1,090</td><td id="26-1a">$ 1,050</td><td id="26-1b">$ 2,151</td><td id="26-1c">$ 2,051</td></tr>
<tr><td id="26-1d">Interest expense(1)</td><td id="26-1e">(67)</td><td id="26-1f">(261)</td><td id="26-1g">(161)</td><td id="26-1h">(295)</td></tr>
<tr><td id="26-1i">Foreign currency exchange gain (loss), net</td><td id="26-1j">(173)</td><td id="26-1k">(69)</td><td id="26-1l">(411)</td><td id="26-1m">(175)</td></tr>
<tr><td id="26-1n">Gain (loss) on debt securities, net</td><td id="26-1o">(310)</td><td id="26-1p">165</td><td id="26-1q">(772)</td><td id="26-1r">367</td></tr>
<tr><td id="26-1s">Gain (loss) on equity securities, net</td><td id="26-1t">(714)</td><td id="26-1u">1,286</td><td id="26-1v">1,529</td><td id="26-1w">11,044</td></tr>
<tr><td id="26-1x">Performance fees</td><td id="26-1y">128</td><td id="26-1z">(83)</td><td id="26-1A">232</td><td id="26-1B">(123)</td></tr>
<tr><td id="26-1C">Income (loss) and impairment from equity method investments, net</td><td id="26-1D">32</td><td id="26-1E">419</td><td id="26-1F">6</td><td id="26-1G">397</td></tr>
<tr><td id="26-1H">Other</td><td id="26-1I">140</td><td id="26-1J">155</td><td id="26-1K">395</td><td id="26-1L">579</td></tr>
<tr><td id="26-1M">Other income (expense), net</td><td id="26-1N">$ 126</td><td id="26-1O">$ 2,662</td><td id="26-1P">$ 2,969</td><td id="26-1Q">$ 13,845</td></tr>
</table>
(1) Interest expense is net of interest capitalized of $43 million and $92 million for the three months ended June 30, 2024 and 2025, respectively, and $86 million and $171 million for the six months ended June 30, 2024 and 2025, respectively.

<a id='1fe3d737-6a45-40b0-acdd-56149a29bfb1'></a>

## Note 8. Acquisitions

### Pending Acquisition

In March 2025, we entered into a definitive agreement to acquire Wiz, a leading cloud security platform, for $32.0 billion, subject to closing adjustments, in an all-cash transaction. The acquisition of Wiz is expected to close in 2026, subject to customary closing conditions, including the receipt of regulatory approvals. Upon the close of the acquisition, Wiz will be part of the Google Cloud segment.

<a id='256aef66-5623-4870-b074-1f5b2ae414f7'></a>

27

<!-- PAGE BREAK -->

<a id='e2b96ce2-b348-4a14-8dbf-a6a600566d06'></a>

Note 9. Goodwill
Changes in the carrying amount of goodwill for the six months ended June 30, 2025 were as follows (in millions):
<table id="27-1">
<tr><td id="27-2"></td><td id="27-3">Google Services</td><td id="27-4">Google Cloud</td><td id="27-5">Other Bets</td><td id="27-6">Total</td></tr>
<tr><td id="27-7">Balance as of December 31, 2024</td><td id="27-8">$ 23,521</td><td id="27-9">$ 7,490</td><td id="27-a">$ 874</td><td id="27-b">$ 31,885</td></tr>
<tr><td id="27-c">Additions</td><td id="27-d">289</td><td id="27-e">9</td><td id="27-f">0</td><td id="27-g">298</td></tr>
<tr><td id="27-h">Foreign currency translation and other adjustments</td><td id="27-i">160</td><td id="27-j">15</td><td id="27-k">(23)</td><td id="27-l">152</td></tr>
<tr><td id="27-m">Balance as of June 30, 2025</td><td id="27-n">$ 23,970</td><td id="27-o">$ 7,514</td><td id="27-p">$ 851</td><td id="27-q">$ 32,335</td></tr>
</table>

<a id='3d08f68f-49d6-4004-8b15-527920bd1398'></a>

## Note 10. Commitments and Contingencies
### Commitments
We have content licensing agreements with future fixed or minimum guaranteed commitments of $8.2 billion as of June 30, 2025, of which the majority is paid quarterly through the first quarter of 2030.

<a id='b0e4fd61-f4ab-40e2-a82b-3c1fc0c80bd7'></a>

## Indemnifications

In the normal course of business, including to facilitate transactions in our services and products and corporate activities, we indemnify certain parties, including advertisers, Google Network partners, distribution partners, customers of Google Cloud offerings, lessors, and service providers with respect to certain matters. We have agreed to defend and/or indemnify certain parties against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. Several of these agreements limit the time within which an indemnification claim can be made and the amount of the claim. In addition, we have entered into indemnification agreements with our officers and directors, and our bylaws contain similar indemnification obligations to our agents.

<a id='5877cc69-89ef-482e-9251-dbd6106511bb'></a>

It is not possible to make a reasonable estimate of the maximum potential amount under these indemnification agreements due to the unique facts and circumstances involved in each particular agreement. Additionally, the payments we have made under such agreements have not had a material adverse effect on our results of operations, cash flows, or financial position. However, to the extent that valid indemnification claims arise in the future, future payments by us could be significant and could have a material adverse effect on our results of operations or cash flows in a particular period.

<a id='4a65f872-f1e3-43dc-893d-0e453ae24756'></a>

As of June 30, 2025, we did not have any material indemnification claims that were probable or reasonably possible.

<a id='edc4c2d8-e7c2-46d3-8dfc-db9df00d9c2d'></a>

## Legal Matters

We record a liability when we believe that it is probable that a loss has been incurred, and the amount can be reasonably estimated. If we determine that a loss is reasonably possible and the loss or range of loss can be estimated, we disclose the reasonably possible loss. We evaluate developments in our legal matters that could affect the amount of liability that has been previously accrued, and the matters and related reasonably possible losses disclosed, and make adjustments as appropriate.

<a id='674edf10-8f99-4c19-82eb-cce07307b56f'></a>

Certain outstanding matters seek speculative, substantial or indeterminate monetary amounts, substantial changes to our business practices and products, or structural remedies. Significant judgment is required to determine both the likelihood of there being a loss and the estimated amount of a loss related to such matters, and we may be unable to estimate the reasonably possible loss or range of losses. The outcomes of outstanding legal matters are inherently unpredictable and subject to significant uncertainties, and could, either individually or in aggregate, have a material adverse effect.

<a id='4e8b0c92-0f84-4d2d-b5a3-6236aa840553'></a>

We expense legal fees in the period in which they are incurred.

<a id='76d1b3d0-5d8e-4ae2-8df4-8c20752fbb93'></a>

**Antitrust Matters**

We are subject to formal and informal inquiries and investigations as well as litigation on various competition matters by regulatory authorities and private parties in the U.S., Europe, and other jurisdictions globally, including the following:

*   ***Shopping:*** In June 2017, the EC announced its decision that certain actions taken by Google relating to its display and ranking of shopping search results and ads infringed European antitrust laws and imposed a ․2.4 billion fine. In 2024, we made a cash payment of $3.0 billion for the fine.

<a id='f5313f7e-a9c7-4833-b63a-0e51ade0ac6e'></a>

28

<!-- PAGE BREAK -->

<a id='fbe8e072-29a7-49a5-85ae-4110ec68a161'></a>

*   *Android*: In July 2018, the EC announced its decision that certain provisions in Google's Android-related distribution agreements infringed European antitrust laws, imposed a ․4.3 billion fine, and directed the termination of the conduct at issue. We appealed the EC decision and implemented changes to certain of our Android distribution practices. In September 2022, the General Court affirmed the EC decision but reduced the fine from ․4.3 billion to ․4.1 billion. We subsequently appealed the General Court's affirmation of the EC decision with the European Court of Justice, which remains pending. In 2018, we recognized a charge of $5.1 billion for the fine, which we reduced by $217 million in 2022.
*   *AdSense for Search*: In March 2019, the EC announced its decision that certain provisions in Google's agreements with AdSense for Search partners infringed European antitrust laws, imposed a fine of ․1.5 billion, and directed actions related to AdSense for Search partners' agreements, which we implemented prior to the decision. In 2019, we recognized a charge of $1.7 billion for the fine and appealed the EC decision. In September 2024, the General Court overturned the EC decision and annulled the ․1.5 billion fine. The EC has appealed the General Court's decision with the European Court of Justice.
*   *Search*: In October 2020, the U.S. Department of Justice (DOJ) and a number of state Attorneys General filed a lawsuit in the U.S. District Court for the District of Columbia alleging that Google violated U.S. antitrust laws relating to Search and Search advertising. In August 2024, the U.S. District Court for the District of Columbia ruled that Google violated such U.S. antitrust laws. A separate proceeding to determine remedies, the range of which vary widely, concluded in May 2025. The DOJ's remedy proposal included alterations to our products and services and our business models and operations, including structural remedies, and our distribution arrangements, among other changes, some of which could have a material adverse effect on our business. We expect a decision on remedies in August 2025, after which we intend to appeal the August 2024 ruling and, potentially, aspects of the remedies decision following our review of that decision.

<a id='8dd42e9c-ce08-4cff-a069-81799b22564e'></a>

Further, in June 2022, the Australian Competition and Consumer Commission and in October 2023, the Japanese Fair Trade Commission (JFTC) each opened an investigation into Search distribution practices. In April 2025, the JFTC issued a cease-and-desist order requiring us to make changes to our Android agreements to ensure they are consistent with Japanese antitrust law. The JFTC did not impose monetary penalties. We are constructively engaging with JFTC regarding compliance with the order.

<a id='21e52ad2-f55f-4f92-9a66-742494430fb0'></a>

Given the nature of these matters, we cannot estimate a possible loss.

<a id='edf2b7bd-13e0-48f8-892c-f0b8e0392bb9'></a>

• *Advertising Technology*: In December 2020, a number of state Attorneys General filed a lawsuit in the U.S. District Court for the Eastern District of Texas alleging that Google violated U.S. antitrust laws as well as state deceptive trade laws relating to its advertising technology. A trial will take place after a decision on remedies is issued in the following DOJ case against Google relating to its advertising technology. In January 2023, the DOJ, along with a number of state Attorneys General, filed a lawsuit in the U.S. District Court for the Eastern District of Virginia alleging that Google violated U.S. antitrust laws relating to its advertising technology, and a number of additional state Attorneys General subsequently joined the lawsuit. In April 2025, the U.S. District Court for the Eastern District of Virginia issued a mixed decision in the DOJ case against Google, ruling that the DOJ failed to show that Google's advertiser tools or acquisitions of DoubleClick and AdMeld were anticompetitive, but that Google's publisher tools violated antitrust laws by excluding rivals. A separate proceeding to determine remedies, the range of which vary widely, is scheduled to take place in September 2025. The DOJ's remedy proposal includes structural remedies, which could have a material adverse effect on our business. We also filed a remedy proposal ahead of the September proceedings. After a decision on remedies, we plan to appeal the adverse portion of the April 2025 decision and, potentially, aspects of the remedies decision following our review of that decision.

<a id='6d1c5a0b-d765-4837-ba96-b614bb65beaf'></a>

Further, in June 2023, the EC issued a Statement of Objections informing Google of its preliminary view that Google violated European antitrust laws relating to its advertising technology, to which we responded. In September 2024, the UK also issued a Statement of Objections on similar grounds, to which we responded.

<a id='52eaa127-7513-4e7b-b94f-ac923938045e'></a>

Given the nature of these matters, we cannot estimate a possible loss.

<a id='8458ebc6-27ee-4e78-b1d1-9a9e5a472e44'></a>

Google Play: In July 2021, a number of state Attorneys General filed a lawsuit in the U.S. District Court for the Northern District of California alleging that Google's operation of Android and Google Play violated U.S. antitrust laws and state antitrust and consumer protection laws. In September 2023, we reached a settlement in principle with 50 state Attorneys General and three territories and recognized a charge. Final approval of the settlement remains pending before the court. In May 2024, we funded the settlement amount to an escrow agent.

<a id='d85ba1f9-2d21-4d23-af5e-6b36180904f1'></a>

29

<!-- PAGE BREAK -->

<a id='ae72b3ae-3421-4fb1-80f4-7a99fa68eb5b'></a>

In December 2023, a California jury delivered a verdict in *Epic Games v. Google* finding that Google violated U.S. antitrust laws related to Google Play's business. Epic did not seek monetary damages. The presiding judge issued a remedies decision in October 2024, ordering a variety of alterations to our business models and operations and contractual agreements for Android and Google Play. We are appealing the verdict and the trial court judge temporarily paused the implementation of the remedies while the Court of Appeals considers our request to pause implementation of the remedies pending the duration of the appeal. Given the nature of this matter, we cannot estimate a possible loss.

<a id='1af5cf43-c2fd-4597-81d3-ff35697e5480'></a>

*   _European Digital Markets Act_: In March 2024, the EC opened two investigations regarding Google's compliance with certain provisions of the European Union's (EU) Digital Markets Act relating to Google Play and Search. In March 2025, the EC issued preliminary findings of non-compliance in both investigations, to which we responded. Given the nature of this matter, we cannot estimate a possible loss.

<a id='342abfa3-e264-49c7-958b-79cb2d859cfb'></a>

In addition to these antitrust proceedings, private individual and collective actions that overlap with claims pursued by regulatory authorities are pending in the U.S. and in several other jurisdictions, including across Europe. Given the nature of these matters, we cannot estimate a possible loss.

<a id='35358169-fccc-41b4-aef4-0c65ecb8c001'></a>

We believe we have strong arguments against these open claims and will defend ourselves vigorously. We continue to cooperate with federal and state regulators in the U.S., the EC, and other regulators around the world.

<a id='6982a9d8-5b92-43ac-8b5f-1ebb76e1a383'></a>

**Privacy Matters**

We are subject to a number of privacy-related laws and regulations, and we currently are party to a number of privacy investigations and lawsuits ongoing in multiple jurisdictions. For example, there are ongoing investigations and litigation in the U.S. and the EU, including those relating to our collection and use of location information, alleged violations of state biometric statutes, the choices we offer users, and advertising practices, which could result in significant fines, judgments, and product changes. In April 2025, we reached a $1.4 billion agreement in principle to settle certain privacy matters.

<a id='e6d20350-fcec-487a-986e-0a665fa17042'></a>

_**Patent and Intellectual Property Claims**_

We have had patent, copyright, trade secret, and trademark infringement lawsuits filed against us claiming that certain of our products, services, and technologies infringe others' intellectual property rights. Adverse results in these lawsuits may include awards of substantial monetary damages, costly royalty or licensing agreements, or orders preventing us from offering certain features, functionalities, products, or services. As a result, we may have to change our business practices and develop non-infringing products or technologies, which could result in a loss of revenues for us and otherwise harm our business. In addition, the U.S. International Trade Commission (ITC) has increasingly become an important forum to litigate intellectual property disputes because an ultimate loss in an ITC action can result in a prohibition on importing infringing products into the U.S. Because the U.S. is an important market, a prohibition on importation could have an adverse effect on us, including preventing us from importing many important products into the U.S. or necessitating workarounds that may limit certain features of our products.

<a id='fb9e5e2f-cdd1-46af-ab38-87b6b195063e'></a>

Further, our customers and partners may discontinue the use of our products, services, and technologies, as a result of injunctions or otherwise, which could result in loss of revenues and adversely affect our business.

<a id='56a26533-238b-4554-aff5-cdf09a07cee0'></a>

_Other_

We are subject to claims, lawsuits, regulatory and government inquiries and investigations, other proceedings, and consent orders involving competition, intellectual property, data privacy and security, tax and related compliance, labor and employment, commercial disputes, content generated by our users, goods and services offered by advertisers or publishers using our platforms, personal injury, consumer protection, Al training, and other matters. For example, we periodically have data incidents that we report to relevant regulators as required by law. Such claims, consent orders, lawsuits, regulatory and government investigations, and other proceedings could result in substantial fines and penalties, injunctive relief, ongoing monitoring and auditing obligations, changes to our products and services, alterations to our business models and operations, and collateral related civil litigation or other adverse consequences, all of which could harm our business, reputation, financial condition, and operating results.

<a id='a0041538-cec3-4093-becd-49ad56ace8f9'></a>

We have ongoing legal matters relating to Russia. For example, some matters concern civil judgments that include compounding penalties imposed upon us in connection with disputes regarding the termination of accounts, including those of sanctioned parties. We do not expect these ongoing legal matters will have a material adverse effect.

<a id='0eef7b9c-c669-4e26-9e7c-8ac0248c6cf7'></a>

Non-Income Taxes

<a id='2e255640-6131-44b8-88dd-965f84fbbf03'></a>

30

<!-- PAGE BREAK -->

<a id='9227c896-eeaf-4d1b-8d2b-f204ba7f7419'></a>

We are under audit by various domestic and foreign tax authorities with regards to non-income tax matters. The subject matter of non-income tax audits primarily arises from disputes on the tax treatment and tax rate applied to the sale of our products and services in these jurisdictions and the tax treatment of certain employee benefits. We accrue non-income taxes that may result from examinations by, or any negotiated agreements with, these tax authorities when a loss is probable and reasonably estimable. If we determine that a loss is reasonably possible and the loss or range of loss can be estimated, we disclose the reasonably possible loss. Due to the inherent complexity and uncertainty of these matters and judicial process in certain jurisdictions, the final outcome may be materially different from our expectations.

<a id='4a97e67b-4912-4347-a978-e8e4e1a987d5'></a>

See Note 14 for information regarding income tax contingencies.

<a id='e5250abd-dccf-4ac7-989e-27da11f94e6f'></a>

Note 11. Stockholders' Equity

<a id='5536519b-9643-4ffd-adea-7bc596fa579b'></a>

# Share Repurchases

In the three and six months ended June 30, 2025, we continued to repurchase both Class A and Class C shares in a manner deemed in the best interest of the company and its stockholders, taking into account the economic cost and prevailing market conditions, including the relative trading prices and volumes of the Class A and Class C shares. During the three and six months ended June 30, 2025, we repurchased $13.3 billion and $28.6 billion of Alphabet's Class A and Class C shares, respectively.

<a id='97e63372-d07f-4ace-9784-cf51f74e7925'></a>

In April 2024, the Board of Directors of Alphabet authorized the company to repurchase up to $70.0 billion of its Class A and Class C shares. In April 2025, the Board of Directors of Alphabet authorized the company to repurchase up to an additional $70.0 billion of Class A and Class C shares. As of June 30, 2025, $86.3 billion remained available for Class A and Class C share repurchases.

<a id='a48fab97-8ed6-4cf1-9a5b-961a52f395a6'></a>

The following table presents Class A and Class C shares repurchased and subsequently retired (in millions):
<table id="30-1">
<tr><td id="30-2"></td><td id="30-3" colspan="2">Three Months Ended June 30, 2025</td><td id="30-4" colspan="2">Six Months Ended June 30, 2025</td></tr>
<tr><td id="30-5"></td><td id="30-6">Shares</td><td id="30-7">Amount</td><td id="30-8">Shares</td><td id="30-9">Amount</td></tr>
<tr><td id="30-a">Class A share repurchases</td><td id="30-b">16</td><td id="30-c">$ 2,537</td><td id="30-d">31</td><td id="30-e">$ 5,303</td></tr>
<tr><td id="30-f">Class C share repurchases</td><td id="30-g">65</td><td id="30-h">10,726</td><td id="30-i">133</td><td id="30-j">23,261</td></tr>
<tr><td id="30-k">Total share repurchases(1)</td><td id="30-l">81</td><td id="30-m">$ 13,263</td><td id="30-n">164</td><td id="30-o">$ 28,564</td></tr>
</table>

<a id='5641b8a7-169d-46c1-88c1-0d5c8b48f94c'></a>

(1) Shares repurchased include unsettled repurchases.
Repurchases are executed from time to time, subject to general business and market conditions and other investment opportunities, through open market purchases or privately negotiated transactions, including through Rule 10b5-1 plans. The repurchase program does not have an expiration date.

<a id='1c19bf00-8abc-49de-bddd-f61ddb24bd62'></a>

Dividends

In the three and six months ended June 30, 2025, total cash dividends were $1.2 billion and $2.4 billion for Class A, $178 million and $350 million for Class B, and $1.1 billion and $2.2 billion for Class C shares, respectively.

<a id='5899221c-95ae-47b4-8edb-4804c626830e'></a>

In April 2025, the Board of Directors of Alphabet increased the quarterly cash dividend by 5% to $0.21 per share of outstanding Class A, Class B, and Class C shares.

<a id='cccbc185-6c01-430f-9ae1-5c27e5e66683'></a>

The company intends to pay quarterly cash dividends in the future, subject to review and approval by the company's Board of Directors in its sole discretion.

<a id='2b846f25-0bed-4f3c-b4de-429d5bb4a71d'></a>

Note 12. Net Income Per Share

The following table sets forth the computation of basic and diluted net income per share of Class A, Class B,
and Class C stock (in millions, except per share amounts):

<a id='7238f888-3c83-401c-9ce1-65a7f1ed41aa'></a>

31

<!-- PAGE BREAK -->

<a id='8e036a5a-b318-43e8-939f-c1ffec3917b6'></a>

<table id="31-1">
<tr><td id="31-2" colspan="3">Three Months Ended June 30,</td></tr>
<tr><td id="31-3">2024</td><td id="31-4"></td><td id="31-5">2025</td></tr>
</table>

<a id='614eb47d-f52c-4c89-868c-0031402c1088'></a>

<table id="31-6">
<tr><td id="31-7"></td><td id="31-8">Class A</td><td id="31-9">Class B</td><td id="31-a">Class C</td><td id="31-b">Consolidated</td><td id="31-c">Class A</td><td id="31-d">Class B</td><td id="31-e">Class C</td><td id="31-f">Consolidated</td></tr>
<tr><td id="31-g" colspan="9">Basic net income per share:</td></tr>
<tr><td id="31-h" colspan="9">Numerator</td></tr>
<tr><td id="31-i">Allocation of distributed earnings (cash dividends paid)</td><td id="31-j">$ 1,173</td><td id="31-k">$ 173</td><td id="31-l">$ 1,120</td><td id="31-m">$ 2,466</td><td id="31-n">$ 1,222</td><td id="31-o">$ 178</td><td id="31-p">$ 1,143</td><td id="31-q">$ 2,543</td></tr>
<tr><td id="31-r">Allocation of undistributed earnings</td><td id="31-s">10,046</td><td id="31-t">1,484</td><td id="31-u">9,623</td><td id="31-v">21,153</td><td id="31-w">12,314</td><td id="31-x">1,803</td><td id="31-y">11,536</td><td id="31-z">25,653</td></tr>
<tr><td id="31-A">Net income</td><td id="31-B">$ 11,219</td><td id="31-C">$ 1,657</td><td id="31-D">$ 10,743</td><td id="31-E">$ 23,619</td><td id="31-F">$ 13,536</td><td id="31-G">$ 1,981</td><td id="31-H">$ 12,679</td><td id="31-I">$ 28,196</td></tr>
</table>
Denominator

<a id='ece1de6e-fcf5-4e4b-b835-cd600d400309'></a>

<table id="31-J">
<tr><td id="31-K">Number of shares used in per share computation</td><td id="31-L">5,862</td><td id="31-M">866</td><td id="31-N">5,615</td><td id="31-O">12,343</td><td id="31-P">5,819</td><td id="31-Q">852</td><td id="31-R">5,451</td><td id="31-S">12,122</td></tr>
<tr><td id="31-T">Basic net income per share</td><td id="31-U">$ 1.91</td><td id="31-V">$ 1.91</td><td id="31-W">$ 1.91</td><td id="31-X">$ 1.91</td><td id="31-Y">$ 2.33</td><td id="31-Z">$ 2.33</td><td id="31-10">$ 2.33</td><td id="31-11">$ 2.33</td></tr>
<tr><td id="31-12">Diluted net income per share:</td><td id="31-13"></td><td id="31-14"></td><td id="31-15"></td><td id="31-16"></td><td id="31-17"></td><td id="31-18"></td><td id="31-19"></td><td id="31-1a"></td></tr>
</table>

<a id='d7721230-f050-4532-b505-6d8cb623f5e7'></a>

<table id="31-1b">
<tr><td id="31-1c" colspan="9">Numerator</td></tr>
<tr><td id="31-1d">Allocation of total earnings for basic computation</td><td id="31-1e">$ 11,219</td><td id="31-1f">$ 1,657</td><td id="31-1g">$ 10,743</td><td id="31-1h">$ 23,619</td><td id="31-1i">$ 13,536</td><td id="31-1j">$ 1,981</td><td id="31-1k">$ 12,679</td><td id="31-1l">$ 28,196</td></tr>
<tr><td id="31-1m">Reallocation of total earnings as a result of conversion of Class B to Class A shares</td><td id="31-1n">1,657</td><td id="31-1o">0</td><td id="31-1p">0</td><td id="31-1q">(1)</td><td id="31-1r">1,981</td><td id="31-1s">0</td><td id="31-1t">0</td><td id="31-1u">(1)</td></tr>
<tr><td id="31-1v">Reallocation of undistributed earnings</td><td id="31-1w">(140)</td><td id="31-1x">(18)</td><td id="31-1y">140</td><td id="31-1z">(1)</td><td id="31-1A">(88)</td><td id="31-1B">(11)</td><td id="31-1C">88</td><td id="31-1D">(1)</td></tr>
<tr><td id="31-1E">Net income</td><td id="31-1F">$ 12,736</td><td id="31-1G">$ 1,639</td><td id="31-1H">$ 10,883</td><td id="31-1I">$ 23,619</td><td id="31-1J">$ 15,429</td><td id="31-1K">$ 1,970</td><td id="31-1L">$ 12,767</td><td id="31-1M">28,196</td></tr>
<tr><td id="31-1N" colspan="9">Denominator</td></tr>
<tr><td id="31-1O">Number of shares used in basic computation</td><td id="31-1P">5,862</td><td id="31-1Q">866</td><td id="31-1R">5,615</td><td id="31-1S">12,343</td><td id="31-1T">5,819</td><td id="31-1U">852</td><td id="31-1V">5,451</td><td id="31-1W">12,122</td></tr>
<tr><td id="31-1X">Weighted-average effect of dilutive securities</td><td id="31-1Y"></td><td id="31-1Z"></td><td id="31-20"></td><td id="31-21"></td><td id="31-22">(light blue rectangle)</td><td id="31-23">(light blue rectangle)</td><td id="31-24">(light blue rectangle)</td><td id="31-25">(light blue rectangle)</td></tr>
<tr><td id="31-26" colspan="9">Add:</td></tr>
<tr><td id="31-27">Conversion of Class B to Class A shares outstanding</td><td id="31-28">866</td><td id="31-29">0</td><td id="31-2a">0</td><td id="31-2b">(1)</td><td id="31-2c">852</td><td id="31-2d">0</td><td id="31-2e">0</td><td id="31-2f">(1)</td></tr>
<tr><td id="31-2g">Restricted stock units and other contingently issuable shares</td><td id="31-2h">0</td><td id="31-2i">0</td><td id="31-2j">152</td><td id="31-2k">152</td><td id="31-2l">0</td><td id="31-2m">0</td><td id="31-2n">76</td><td id="31-2o">76</td></tr>
<tr><td id="31-2p">Number of shares used in per share computation</td><td id="31-2q">6,728</td><td id="31-2r">866</td><td id="31-2s">5,767</td><td id="31-2t">12,495</td><td id="31-2u">6,671</td><td id="31-2v">852</td><td id="31-2w">5,527</td><td id="31-2x">12,198</td></tr>
<tr><td id="31-2y">Diluted net income per share</td><td id="31-2z">$ 1.89</td><td id="31-2A">$ 1.89</td><td id="31-2B">$ 1.89</td><td id="31-2C">$ 1.89</td><td id="31-2D">$ 2.31</td><td id="31-2E">$ 2.31</td><td id="31-2F">$ 2.31</td><td id="31-2G">$ 2.31</td></tr>
</table>
(1) Not applicable for consolidated net income per share.

<a id='49278dcc-d315-413b-b6fa-59afd94fe1dc'></a>

32

<!-- PAGE BREAK -->

<a id='158c350e-05ee-43be-aa0a-cb14f74d72bd'></a>

<table id="32-1">
<tr><td id="32-2" colspan="8">Six Months Ended June 30,</td></tr>
<tr><td id="32-3"></td><td id="32-4" colspan="3">2024</td><td id="32-5" colspan="4">2025</td></tr>
<tr><td id="32-6">Class A</td><td id="32-7">Class B</td><td id="32-8">Class C</td><td id="32-9">Consolidated</td><td id="32-a">Class A</td><td id="32-b">Class B</td><td id="32-c">Class C</td><td id="32-d">Consolidated</td></tr>
</table>

<a id='66f83eae-19d0-409e-b920-c9d9ba7ef9ac'></a>

<table id="32-e">
<tr><td id="32-f" colspan="9">Basic net income per share:</td></tr>
<tr><td id="32-g" colspan="9">Numerator</td></tr>
<tr><td id="32-h">Allocation of distributed earnings (cash dividends paid)</td><td id="32-i">$ 1,173</td><td id="32-j">$ 173</td><td id="32-k">$ 1,120</td><td id="32-l">$ 2,466</td><td id="32-m">$ 2,388</td><td id="32-n">$ 350</td><td id="32-o">$ 2,239</td><td id="32-p">$ 4,977</td></tr>
<tr><td id="32-q">Allocation of undistributed earnings</td><td id="32-r">21,254</td><td id="32-s">3,142</td><td id="32-t">20,419</td><td id="32-u">44,815</td><td id="32-v">27,689</td><td id="32-w">4,064</td><td id="32-x">26,006</td><td id="32-y">57,759</td></tr>
<tr><td id="32-z">Net income</td><td id="32-A">$ 22,427</td><td id="32-B">$ 3,315</td><td id="32-C">$ 21,539</td><td id="32-D">$ 47,281</td><td id="32-E">$ 30,077</td><td id="32-F">$ 4,414</td><td id="32-G">$ 28,245</td><td id="32-H">$ 62,736</td></tr>
</table>
Denominator

<a id='4f19296a-28a3-4b10-a9f8-dd6537efd5bc'></a>

<table id="32-I">
<tr><td id="32-J">Number of shares used in per share computation</td><td id="32-K">5,871</td><td id="32-L">868</td><td id="32-M">5,640</td><td id="32-N">12,379</td><td id="32-O">5,826</td><td id="32-P">855</td><td id="32-Q">5,472</td><td id="32-R">12,153</td></tr>
<tr><td id="32-S">Basic net income per share</td><td id="32-T">$ 3.82</td><td id="32-U">$ 3.82</td><td id="32-V">$ 3.82</td><td id="32-W">$ 3.82</td><td id="32-X">$ 5.16</td><td id="32-Y">$ 5.16</td><td id="32-Z">$ 5.16</td><td id="32-10">$ 5.16</td></tr>
<tr><td id="32-11">Diluted net income per share:</td><td id="32-12"></td><td id="32-13"></td><td id="32-14"></td><td id="32-15"></td><td id="32-16"></td><td id="32-17"></td><td id="32-18"></td><td id="32-19"></td></tr>
</table>

<a id='0fc56948-28a2-4c04-b9d0-1883fd0e24ed'></a>

<table id="32-1a">
<tr><td id="32-1b" colspan="9">Numerator</td></tr>
<tr><td id="32-1c">Allocation of total earnings for basic computation</td><td id="32-1d">$ 22,427</td><td id="32-1e">$ 3,315</td><td id="32-1f">$ 21,539</td><td id="32-1g">$ 47,281</td><td id="32-1h">$ 30,077</td><td id="32-1i">$ 4,414</td><td id="32-1j">$ 28,245</td><td id="32-1k">$ 62,736</td></tr>
<tr><td id="32-1l">Reallocation of total earnings as a result of conversion of Class B to Class A shares</td><td id="32-1m">3,315</td><td id="32-1n">0</td><td id="32-1o">0</td><td id="32-1p">(1)</td><td id="32-1q">4,414</td><td id="32-1r">0</td><td id="32-1s">0</td><td id="32-1t">(1)</td></tr>
<tr><td id="32-1u">Reallocation of undistributed earnings</td><td id="32-1v">(257)</td><td id="32-1w">(33)</td><td id="32-1x">257</td><td id="32-1y">(1)</td><td id="32-1z">(239)</td><td id="32-1A">(31)</td><td id="32-1B">239</td><td id="32-1C">(1)</td></tr>
<tr><td id="32-1D">Net income</td><td id="32-1E">$ 25,485</td><td id="32-1F">$ 3,282</td><td id="32-1G">$ 21,796</td><td id="32-1H">$ 47,281</td><td id="32-1I">$ 34,252</td><td id="32-1J">$ 4,383</td><td id="32-1K">$ 28,484</td><td id="32-1L">$ 62,736</td></tr>
<tr><td id="32-1M" colspan="9">Denominator</td></tr>
<tr><td id="32-1N">Number of shares used in basic computation</td><td id="32-1O">5,871</td><td id="32-1P">868</td><td id="32-1Q">5,640</td><td id="32-1R">12,379</td><td id="32-1S">5,826</td><td id="32-1T">855</td><td id="32-1U">5,472</td><td id="32-1V">12,153</td></tr>
<tr><td id="32-1W">Weighted-average effect of dilutive securities</td><td id="32-1X"></td><td id="32-1Y"></td><td id="32-1Z"></td><td id="32-20"></td><td id="32-21">(light blue rectangle)</td><td id="32-22">(light blue rectangle)</td><td id="32-23">(light blue rectangle)</td><td id="32-24">(light blue rectangle)</td></tr>
<tr><td id="32-25" colspan="9">Add:</td></tr>
<tr><td id="32-26">Conversion of Class B to Class A shares outstanding</td><td id="32-27">868</td><td id="32-28">0</td><td id="32-29">0</td><td id="32-2a">(1)</td><td id="32-2b">855</td><td id="32-2c">0</td><td id="32-2d">0</td><td id="32-2e">(1)</td></tr>
<tr><td id="32-2f">Restricted stock units and other contingently issuable shares</td><td id="32-2g">0</td><td id="32-2h">0</td><td id="32-2i">132</td><td id="32-2j">132</td><td id="32-2k">0</td><td id="32-2l">0</td><td id="32-2m">92</td><td id="32-2n">92</td></tr>
<tr><td id="32-2o">Number of shares used in per share computation</td><td id="32-2p">6,739</td><td id="32-2q">868</td><td id="32-2r">5,772</td><td id="32-2s">12,511</td><td id="32-2t">6,681</td><td id="32-2u">855</td><td id="32-2v">5,564</td><td id="32-2w">12,245</td></tr>
<tr><td id="32-2x">Diluted net income per share</td><td id="32-2y">$ 3.78</td><td id="32-2z">$ 3.78</td><td id="32-2A">$ 3.78</td><td id="32-2B">$ 3.78</td><td id="32-2C">$ 5.13</td><td id="32-2D">$ 5.13</td><td id="32-2E">$ 5.12</td><td id="32-2F">$ 5.12</td></tr>
</table>
(1) Not applicable for consolidated net income per share.

<a id='719f2e51-2080-48cd-8018-3c07c05b479d'></a>

For the periods presented above, the holders of each class are entitled to equal per share dividends or distributions in liquidation in accordance with the Amended and Restated Certificate of Incorporation of Alphabet Inc. Holders of Alphabet unvested stock units are awarded dividend equivalents, which are subject to the same vesting conditions as the underlying award, and settled in Class C shares.

<a id='7198139e-bea3-4042-8e34-d1dff47fc5a0'></a>

Immaterial differences in net income per share across our Class A, Class B, and Class C shares may arise due to the allocation of distributed earnings, which is based on the holders as of the record date, compared with the allocation of undistributed earnings and number of shares, which is based on the weighted average shares outstanding over the periods.

<a id='7adae851-4510-4e99-9731-3dfb5b766ed3'></a>

33

<!-- PAGE BREAK -->

<a id='67e7f3f0-e7c5-4f0a-abca-441687115399'></a>

**Note 13. Compensation Plans**

<a id='ddca1cd2-17f8-4b9c-8381-4619231cea0b'></a>

**Stock-Based Compensation**

For the three months ended June 30, 2024 and 2025, total stock-based compensation (SBC) expense was $5.9 billion and $6.0 billion, including amounts associated with awards we expect to settle in Alphabet stock of $5.7 billion and $5.8 billion, respectively. For the six months ended June 30, 2024 and 2025, total SBC expense was $11.2 billion and $11.5 billion, including amounts associated with awards we expect to settle in Alphabet stock of $10.7 billion and $11.1 billion, respectively.

<a id='87a90208-89a7-429d-8a6b-dbe96d43d50b'></a>

### Stock-Based Award Activities
The following table summarizes the activities for unvested Alphabet restricted stock units (RSUs), which include dividend equivalents awarded to holders of unvested stock, for the six months ended June 30, 2025 (in millions, except per share amounts):

<a id='ebc56bb8-fc29-4c40-8248-ff17ba3f9b4f'></a>

<table id="33-1">
<tr><td id="33-2"></td><td id="33-3">Number of Shares</td><td id="33-4">Weighted-Average Grant-Date Fair Value</td></tr>
<tr><td id="33-5">Unvested as of December 31, 2024</td><td id="33-6">299</td><td id="33-7">$ 122.77</td></tr>
<tr><td id="33-8">Granted</td><td id="33-9">146</td><td id="33-a">$ 175.03</td></tr>
<tr><td id="33-b">Vested</td><td id="33-c">(89)</td><td id="33-d">$ 129.05</td></tr>
<tr><td id="33-e">Forfeited/canceled</td><td id="33-f">(17)</td><td id="33-g">$ 134.20</td></tr>
<tr><td id="33-h">Unvested as of June 30, 2025</td><td id="33-i">339</td><td id="33-j">$ 142.94</td></tr>
</table>

<a id='d06004b9-0027-450c-8e2d-e7b5bb30a741'></a>

As of June 30, 2025, there was $47.0 billion of unrecognized compensation cost related to unvested RSUs.
This amount is expected to be recognized over a weighted-average period of 2.7 years.

<a id='37f11012-74bc-4c40-ad92-09cf3e1c02cd'></a>

Note 14. Income Taxes
The following table presents provision for income taxes (in millions, except for effective tax rate):
<table id="33-k">
<tr><td id="33-l"></td><td id="33-m" colspan="2">Three Months Ended June 30,</td><td id="33-n" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="33-o"></td><td id="33-p">2024</td><td id="33-q">2025</td><td id="33-r">2024</td><td id="33-s">2025</td></tr>
<tr><td id="33-t">Income before provision for income taxes</td><td id="33-u">$ 27,551</td><td id="33-v">$ 33,933</td><td id="33-w">$ 55,866</td><td id="33-x">$ 75,722</td></tr>
<tr><td id="33-y">Provision for income taxes</td><td id="33-z">$ 3,932</td><td id="33-A">$ 5,737</td><td id="33-B">$ 8,585</td><td id="33-C">$ 12,986</td></tr>
<tr><td id="33-D">Effective tax rate</td><td id="33-E">14.3%</td><td id="33-F">16.9%</td><td id="33-G">15.4%</td><td id="33-H">17.1%</td></tr>
</table>

<a id='03820f3c-3c67-4c45-89c7-63b1f13c093d'></a>

We are subject to income taxes in the U.S. and foreign jurisdictions. Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. The total amount of gross unrecognized tax benefits was $12.6 billion and $12.9 billion, of which $10.0 billion and $11.0 billion, if recognized, would affect our effective tax rate, as of December 31, 2024 and June 30, 2025, respectively.

<a id='fbd8a2ea-9049-4e3c-bb15-ec5c6865cb5d'></a>

On July 4, 2025, the One Big Beautiful Bill Act (OBBBA) was signed into law. This legislation includes changes to U.S. federal tax law, which may be subject to further clarification and the issuance of interpretive guidance. We are assessing the legislation and its effect on our consolidated financial statements, which we expect to begin reflecting in the three month period ended September 30, 2025.

<a id='6887cfea-b6ca-42d5-b9c7-0d86f99e348d'></a>

Note 15. Information about Segments and Geographic Areas

We report our segment results as Google Services, Google Cloud, and Other Bets:

* Google Services includes products and services such as ads, Android, Chrome, devices, Google Maps, Google Play, Search, and YouTube. Google Services generates revenues primarily from advertising; fees received for consumer subscription-based products such as YouTube TV, YouTube Music and Premium, and NFL Sunday Ticket, as well as Google One; the sale of apps and in-app purchases; and devices.
* Google Cloud includes infrastructure and platform services, applications, and other services for enterprise customers. Google Cloud generates revenues primarily from consumption-based fees and subscriptions received for Google Cloud Platform services, Google Workspace communication and collaboration tools, and other enterprise services.

<a id='a625ae69-523c-4018-88a2-a17226492f67'></a>

34

<!-- PAGE BREAK -->

<a id='1f0115e2-f0d1-4198-af8c-b00f2cc9e2e5'></a>

*   Other Bets is a combination of multiple operating segments that are not individually material. Revenues from Other Bets are generated primarily from the sale of autonomous transportation services, healthcare-related services and internet services.

<a id='85a04317-f5a6-4c23-a045-bcefb6b0299e'></a>

Revenues, certain costs, such as costs associated with content and traffic acquisition, certain engineering activities, and devices, as well as certain operating expenses are directly attributable to our segments. Due to the integrated nature of Alphabet, other costs and expenses, such as technical infrastructure and office facilities, are managed centrally at a consolidated level. These costs, including the associated depreciation, are allocated to operating segments as a service cost generally based on usage, headcount, or revenue.

<a id='66708d8b-6c5c-4f67-96a7-693825499fc6'></a>

Certain costs are not allocated to our segments because they represent Alphabet-level activities. These costs primarily include certain AI-focused shared R&D activities, including development costs of our general AI models; corporate initiatives such as our philanthropic activities; corporate shared costs such as certain finance, human resource, and legal costs, including certain fines and settlements. Charges associated with employee severance and office space reductions are also not allocated to our segments. Additionally, hedging gains (losses) related to revenue are not allocated to our segments.

<a id='848b97b3-3c27-418d-a0d3-39dd18a6fe15'></a>

Our Chief Operating Decision Maker (CODM) is our Chief Executive Officer, Sundar Pichai. Our CODM uses segment operating income (loss) to allocate resources to our segments in our annual planning process and to assess the performance of our segments, primarily by monitoring actual results versus the annual plan. Our operating segments are not evaluated using asset information.

<a id='a391c425-21ef-4da7-85c9-fc7a49105e0e'></a>

The following table presents revenue, profitability, and expense information about our segments (in millions):
<table id="34-1">
<tr><td id="34-2"></td><td id="34-3" colspan="2">Three Months Ended June 30,</td><td id="34-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="34-5"></td><td id="34-6">2024</td><td id="34-7">2025</td><td id="34-8">2024</td><td id="34-9">2025</td></tr>
<tr><td id="34-a" colspan="5">Revenues:</td></tr>
<tr><td id="34-b">Google Services</td><td id="34-c">$ 73,928</td><td id="34-d">$ 82,543</td><td id="34-e">$ 144,326</td><td id="34-f">$ 159,807</td></tr>
<tr><td id="34-g">Google Cloud</td><td id="34-h">10,347</td><td id="34-i">13,624</td><td id="34-j">19,921</td><td id="34-k">25,884</td></tr>
<tr><td id="34-l">Other Bets</td><td id="34-m">365</td><td id="34-n">373</td><td id="34-o">860</td><td id="34-p">823</td></tr>
<tr><td id="34-q">Hedging gains (losses)</td><td id="34-r">102</td><td id="34-s">(112)</td><td id="34-t">174</td><td id="34-u">148</td></tr>
<tr><td id="34-v">Total revenues</td><td id="34-w">$ 84,742</td><td id="34-x">$ 96,428</td><td id="34-y">$ 165,281</td><td id="34-z">$ 186,662</td></tr>
<tr><td id="34-A" colspan="5">Operating income (loss):</td></tr>
<tr><td id="34-B">Google Services</td><td id="34-C">$ 29,674</td><td id="34-D">$ 33,063</td><td id="34-E">$ 57,571</td><td id="34-F">$ 65,745</td></tr>
<tr><td id="34-G">Google Cloud</td><td id="34-H">1,172</td><td id="34-I">2,826</td><td id="34-J">2,072</td><td id="34-K">5,003</td></tr>
<tr><td id="34-L">Other Bets</td><td id="34-M">(1,134)</td><td id="34-N">(1,246)</td><td id="34-O">(2,154)</td><td id="34-P">(2,472)</td></tr>
<tr><td id="34-Q">Alphabet-level activities</td><td id="34-R">(2,287)</td><td id="34-S">(3,372)</td><td id="34-T">(4,592)</td><td id="34-U">(6,399)</td></tr>
<tr><td id="34-V">Total income from operations</td><td id="34-W">$ 27,425</td><td id="34-X">$ 31,271</td><td id="34-Y">$ 52,897</td><td id="34-Z">$ 61,877</td></tr>
<tr><td id="34-10" colspan="5">Supplemental information about segment expenses:</td></tr>
<tr><td id="34-11" colspan="5">Google Services:</td></tr>
<tr><td id="34-12">Employee compensation expenses</td><td id="34-13">$ 11,240</td><td id="34-14">$ 11,306</td><td id="34-15">$ 22,751</td><td id="34-16">$ 22,643</td></tr>
<tr><td id="34-17">Other costs and expenses</td><td id="34-18">33,014</td><td id="34-19">38,174</td><td id="34-1a">64,004</td><td id="34-1b">71,419</td></tr>
<tr><td id="34-1c">Total Google Services costs and expenses</td><td id="34-1d">$ 44,254</td><td id="34-1e">$ 49,480</td><td id="34-1f">$ 86,755</td><td id="34-1g">$ 94,062</td></tr>
<tr><td id="34-1h" colspan="5">Google Cloud:</td></tr>
<tr><td id="34-1i">Employee compensation expenses</td><td id="34-1j">$ 5,175</td><td id="34-1k">$ 5,517</td><td id="34-1l">$ 10,332</td><td id="34-1m">$ 10,929</td></tr>
<tr><td id="34-1n">Other costs and expenses</td><td id="34-1o">4,000</td><td id="34-1p">5,281</td><td id="34-1q">7,517</td><td id="34-1r">9,952</td></tr>
<tr><td id="34-1s">Total Google Cloud costs and expenses</td><td id="34-1t">$ 9,175</td><td id="34-1u">$ 10,798</td><td id="34-1v">$ 17,849</td><td id="34-1w">$ 20,881</td></tr>
</table>

<a id='60277ba7-8e39-4fc1-8dcd-171fe4998089'></a>

35

<!-- PAGE BREAK -->

<a id='e4e6f986-5b82-4efa-9374-ca495127ed0c'></a>

Google Services and Google Cloud employee compensation expenses include the costs associated with direct and allocated employees. Google Services and Google Cloud other costs and expenses primarily include direct costs, such as advertising and promotional activities and third party services fees as well as allocated costs, such as technical infrastructure and office facilities usage costs. Additionally, Google Services other costs and expenses include content and traffic acquisition costs and device costs.

<a id='9ea0271f-3a9b-4e47-a8f7-09efc12609bf'></a>

See Note 2 for information relating to revenues by geography.
The following table presents long-lived assets by geographic area, which includes property and equipment, net
and operating lease assets (in millions):

<a id='516190e3-1ce0-42d7-8437-43c624a84363'></a>

<table id="35-1">
<tr><td id="35-2"></td><td id="35-3">As of December 31, 2024</td><td id="35-4">As of June 30, 2025</td></tr>
<tr><td id="35-5" colspan="3">Long-lived assets:</td></tr>
<tr><td id="35-6">United States</td><td id="35-7">$ 138,993</td><td id="35-8">$ 160,877</td></tr>
<tr><td id="35-9">International</td><td id="35-a">45,631</td><td id="35-b">56,609</td></tr>
<tr><td id="35-c">Total long-lived assets</td><td id="35-d">$ 184,624</td><td id="35-e">$ 217,486</td></tr>
</table>

<a id='db7de77f-f93d-4180-81d7-170c6c48a056'></a>

36

<!-- PAGE BREAK -->

<a id='e920b845-135e-43a4-b20a-4b9ad6777ce5'></a>

ITEM 2.
**MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS**
Please read the following discussion and analysis of our financial condition and results of operations together with "Note About Forward-Looking Statements" and our consolidated financial statements and related notes included under Item 1 of this Quarterly Report on Form 10-Q as well as our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, including Part I, Item 1A "Risk Factors."

<a id='76d5af07-9b76-4984-b169-f5ad49c7f3cc'></a>

## Understanding Alphabet's Financial Results

Alphabet is a collection of businesses --- the largest of which is Google. We report Google in two segments, Google Services and Google Cloud; we also report all non-Google businesses collectively as Other Bets. For further details on our segments, see Note 15 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='646338d3-355c-4bb2-b66e-1d88cf7440ab'></a>

**Revenues and Monetization Metrics**

We generate revenues by delivering relevant, cost-effective online advertising; cloud-based solutions that provide enterprise customers of all sizes with infrastructure, platform services, and applications; sales of other products and services, such as fees received for subscription-based products, apps and in-app purchases, and devices. For additional information on how we recognize revenue, see Note 1 of the Notes to Consolidated Financial Statements included in Part II, Item 8 in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024.

<a id='0dd66d7d-e982-4f1b-8d09-81cbd5885f8f'></a>

In addition to the long-term trends and their financial effect on our business discussed in "Trends in Our Business and Financial Effect" in Part II, Item 7 of our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, fluctuations in our revenues have been and may continue to be affected by a combination of factors, including:

* changes in foreign currency exchange rates;
* changes in pricing, such as those resulting from changes in fee structures, discounts, and customer incentives;
* general economic conditions and various external dynamics, including geopolitical events, regulations, and other measures and their effect on advertiser, consumer, and enterprise spending;
* new product, service, and market launches; and
* seasonality.

<a id='5f0ee3c4-ba7d-4274-94fe-2a7d43326a95'></a>

Additionally, fluctuations in our revenues generated from advertising ("Google advertising"), other sources ("Google subscriptions, platforms, and devices"), Google Cloud, and Other Bets have been, and may continue to be, affected by other factors unique to each set of revenues, as described below.

<a id='d74b7626-3e22-40b3-8d40-849124cf47da'></a>

**Google Services**

Google Services revenues consist of Google advertising as well as Google subscriptions, platforms, and devices revenues.

<a id='aed02486-cf45-4e65-a159-4ed45a3b7267'></a>

_Google Advertising_

Google advertising revenues are comprised of the following:

* Google Search & other, which includes revenues generated on Google search properties (including revenues from traffic generated by search distribution partners who use Google.com as their default search in browsers, toolbars, etc.), and other Google owned and operated properties like Gmail, Google Maps, and Google Play;
* YouTube ads, which includes revenues generated on YouTube properties; and
* Google Network, which includes revenues generated on Google Network properties participating in AdMob, AdSense, and Google Ad Manager.

<a id='0c25ec54-08c6-45ac-8022-3a07cf7f3933'></a>

We use certain metrics to track how well traffic across various properties is monetized as it relates to our advertising revenues: paid clicks and cost-per-click pertain to traffic on Google Search & other properties, while impressions and cost-per-impression pertain to traffic on our Google Network properties.

<a id='69bee88c-58ca-4610-9da5-e9ff14d1fe53'></a>

37

<!-- PAGE BREAK -->

<a id='c22936f3-3de2-4f34-9bf6-80f3341e0c69'></a>

Paid clicks represent engagement by users and include clicks on advertisements by end-users on Google search properties and other Google owned and operated properties including Gmail, Google Maps, and Google Play. Cost-per-click is defined as click-driven revenues divided by our total number of paid clicks and represents the average amount we charge advertisers for each engagement by users.

<a id='2472578b-3d28-4b28-a253-4ffe50f5c6b5'></a>

Impressions include impressions displayed to users on Google Network properties participating primarily in AdMob, AdSense, and Google Ad Manager. Cost-per-impression is defined as impression-based and click-based revenues divided by our total number of impressions, and represents the average amount we charge advertisers for each impression displayed to users.

<a id='f17ad44b-713b-4c47-8818-fef6e13b7de2'></a>

As our business evolves, we periodically review, refine, and update our methodologies for monitoring, gathering, and counting the number of paid clicks and the number of impressions, and for identifying the revenues generated by the corresponding click and impression activity.

<a id='dbe4dba9-0212-4c64-98e4-1a1fab968674'></a>

Fluctuations in our advertising revenues, as well as the change in paid clicks and cost-per-click on Google Search & other properties and the change in impressions and cost-per-impression on Google Network properties and the correlation between these items have been, and may continue to be, affected by factors in addition to the general factors described above, such as:

*   advertiser competition for keywords;
*   changes in advertising quality, formats, delivery, or policy;
*   changes in device mix;
*   seasonal fluctuations in internet usage, advertising expenditures, and underlying business trends, such as traditional retail seasonality; and
*   traffic growth in emerging markets compared to more mature markets and across various verticals and channels.

<a id='ce06c14d-6adc-438a-a40f-11b0f230581c'></a>

_Google subscriptions, platforms, and devices_
Google subscriptions, platforms, and devices revenues are comprised of the following:

*   consumer subscriptions, which primarily include revenues from YouTube services, such as YouTube TV, YouTube Music and Premium, and NFL Sunday Ticket, as well as Google One;
*   platforms, which primarily include revenues from Google Play sales of apps and in-app purchases;
*   devices, which primarily include sales of the Pixel family of devices; and
*   other products and services.

<a id='f1e9ca2f-5e61-4475-84d4-427707dc699c'></a>

Fluctuations in our Google subscriptions, platforms, and devices revenues have been, and may continue to be, affected by factors in addition to the general factors described above, such as changes in customer usage and demand, number of subscribers, and the timing of product launches.

<a id='0073c8bb-d3c0-4de0-b2f9-b14e7c3cb444'></a>

_**Google Cloud**_

Google Cloud revenues are comprised of the following:

*   Google Cloud Platform, which generates consumption-based fees and subscriptions for infrastructure, platform, and other services. These services provide access to solutions such as AI offerings including our AI infrastructure, Vertex AI platform, and Gemini for Google Cloud: cybersecurity; and data and analytics;
*   Google Workspace, which includes subscriptions for cloud-based communication and collaboration tools for enterprises, such as Calendar, Gmail, Docs, Drive, and Meet, with integrated features like Gemini for Google Workspace; and
*   other enterprise services.

<a id='b32f6d89-44c8-4b8b-a5f3-5f0ab83f8902'></a>

Fluctuations in our Google Cloud revenues have been, and may continue to be, affected by factors in addition to the general factors described above, such as changes in customer usage and demand.

<a id='49391611-20a5-4c14-b083-2fb8ecb852e1'></a>

_Other Bets_
Revenues from Other Bets are generated primarily from the sale of autonomous transportation services, healthcare-related services, and internet services.

<a id='40f28b1e-1023-4435-8de3-f7c37c47f258'></a>

38

<!-- PAGE BREAK -->

<a id='2d900188-928c-4dba-8879-f8fe330a8da6'></a>

### Costs and Expenses

Our cost structure has two components: cost of revenues and operating expenses. Our operating expenses include costs related to R&D, sales and marketing, and general and administrative functions. Certain of our costs and expenses, including those associated with the operation of our technical infrastructure as well as components of our operating expenses, are generally less variable in nature and may not correlate to changes in revenue. Additionally, fluctuations in employee compensation expenses may not directly correlate with changes in headcount due to factors such as annual SBC awards that generally vest over four years.

<a id='3164d652-d5a0-4493-8d5e-43245f6237d0'></a>

**Cost of Revenues**
Cost of revenues is comprised of TAC and other costs of revenues.
*   TAC includes:
    *   amounts paid to our distribution partners who make available our search access points and services. Our distribution partners include browser providers, mobile carriers, original equipment manufacturers, and software developers; and
    *   amounts paid to Google Network partners primarily for ads displayed on their properties.
*   Other cost of revenues primarily includes:
    *   content acquisition costs, which are payments to content providers from whom we license video and other content for distribution, primarily related to YouTube (we pay fees to these content providers based on revenues generated, subscriber counts, or a flat fee);
    *   depreciation expense related to our technical infrastructure;
    *   employee compensation expenses related to our technical infrastructure and other operations such as content review and customer and product support;
    *   inventory and other costs related to the devices we sell; and
    *   other technical infrastructure operations costs, including network capacity, energy, and equipment costs.

<a id='03bc14dc-ade1-45a4-b3a3-4f22e533c072'></a>

TAC as a percentage of revenues generated from ads placed on Google Network properties are significantly higher than TAC as a percentage of revenues generated from ads placed on Google Search & other properties, because most of the advertiser revenues from ads served on Google Network properties are paid as TAC to our Google Network partners.

<a id='86e71b71-d5f5-4f26-b93b-1fc929080df3'></a>

*Operating Expenses*

Operating expenses are generally incurred during our normal course of business, which we categorize as either R&D, sales and marketing, or general and administrative.

<a id='f903dab6-faa6-4db1-8869-4b1fce7bc5b5'></a>

The main components of our R&D expenses are:
* depreciation;
* employee compensation expenses for engineering and technical employees responsible for R&D related to our existing and new products and services; and
* third-party services fees primarily relating to consulting and outsourced services in support of our engineering and product development efforts.

<a id='9fdcdcae-1034-4eac-8b29-a3b953aa0a48'></a>

The main components of our sales and marketing expenses are:

* employee compensation expenses for employees engaged in sales and marketing, sales support, and certain customer service functions; and
* spend relating to our advertising and promotional activities in support of our products and services.

<a id='4ed4c99f-64a2-4504-9966-4ed7839fe995'></a>

The main components of our general and administrative expenses are:

* employee compensation expenses for employees in finance, human resources, information technology, legal, and other administrative support functions;
* expenses relating to legal and other matters, including certain fines and settlements; and

<a id='7750159a-9d4b-40be-8b84-aa85231bdcd5'></a>

39

<!-- PAGE BREAK -->

<a id='3a6532d8-a264-4139-9c4b-debc1600849f'></a>

* third-party services fees, including audit, consulting, outside legal, and other outsourced administrative services.

<a id='b336e626-ba27-44d1-ba43-a6cabc0cf8e0'></a>

_Other Income (Expense), Net_

OI&E, net primarily consists of interest income (expense), the effect of foreign currency exchange gains (losses), net gains (losses) and impairment on our marketable and non-marketable securities, performance fees, and income (loss) and impairment from our equity method investments.

<a id='1d3ab371-4fb8-4deb-bc53-abdae1604102'></a>

For additional information, including how we account for our investments and factors that can drive fluctuations in the value of our investments, see Note 1 of the Notes to Consolidated Financial Statements included in Part II, Item 8 and Item 7A, "Quantitative and Qualitative Disclosures About Market Risk" in our Annual Report on Form 10- K for the fiscal year ended December 31, 2024 as well as Note 3 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='2f1c2492-8f31-4710-8a3d-6a27b6d9d08c'></a>

Provision for Income Taxes

Provision for income taxes represents the estimated amount of federal, state, and foreign income taxes incurred in the U.S. and the many jurisdictions in which we operate. The provision includes the effect of reserve provisions and changes to reserves that are considered appropriate as well as the related net interest and penalties.

<a id='c7f421fd-d665-4dec-a639-f6475a5d8f66'></a>

For additional information, see Note 1 of the Notes to Consolidated Financial Statements included in Part II, Item 8 in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024 as well as Note 14 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='1cccb44d-c62d-4853-bdef-237e57f830dc'></a>

**Executive Overview**
The following table summarizes consolidated financial results (in millions, except per share information and percentages):

<a id='7d90793a-6a4c-4fc1-8f32-fc2f2b34fd66'></a>

<table id="39-1">
<tr><td id="39-2"></td><td id="39-3" colspan="2">Three Months Ended June 30,</td><td id="39-4"></td><td id="39-5"></td></tr>
<tr><td id="39-6"></td><td id="39-7">2024</td><td id="39-8">2025</td><td id="39-9">$ Change</td><td id="39-a">% Change</td></tr>
<tr><td id="39-b">Consolidated revenues</td><td id="39-c">$ 84,742</td><td id="39-d">$ 96,428</td><td id="39-e">$ 11,686</td><td id="39-f">14%</td></tr>
<tr><td id="39-g">Change in consolidated constant currency revenues(1)</td><td id="39-h"></td><td id="39-i"></td><td id="39-j"></td><td id="39-k">13%</td></tr>
<tr><td id="39-l"></td><td id="39-m"></td><td id="39-n"></td><td id="39-o"></td><td id="39-p"></td></tr>
<tr><td id="39-q">Cost of revenues</td><td id="39-r">$ 35,507</td><td id="39-s">$ 39,039</td><td id="39-t">$ 3,532</td><td id="39-u">10 %</td></tr>
<tr><td id="39-v">Operating expenses</td><td id="39-w">$ 21,810</td><td id="39-x">$ 26,118</td><td id="39-y">$ 4,308</td><td id="39-z">20 %</td></tr>
<tr><td id="39-A"></td><td id="39-B"></td><td id="39-C"></td><td id="39-D"></td><td id="39-E"></td></tr>
<tr><td id="39-F">Operating income</td><td id="39-G">$ 27,425</td><td id="39-H">$ 31,271</td><td id="39-I">$ 3,846</td><td id="39-J">14 %</td></tr>
<tr><td id="39-K">Operating margin</td><td id="39-L">32 %</td><td id="39-M">32 %</td><td id="39-N"></td><td id="39-O">0 %</td></tr>
<tr><td id="39-P"></td><td id="39-Q"></td><td id="39-R"></td><td id="39-S"></td><td id="39-T"></td></tr>
<tr><td id="39-U">Other income (expense), net</td><td id="39-V">$ 126</td><td id="39-W">$ 2,662</td><td id="39-X">$ 2,536</td><td id="39-Y">2,013 %</td></tr>
<tr><td id="39-Z"></td><td id="39-10"></td><td id="39-11"></td><td id="39-12"></td><td id="39-13"></td></tr>
<tr><td id="39-14">Net income</td><td id="39-15">$ 23,619</td><td id="39-16">$ 28,196</td><td id="39-17">$ 4,577</td><td id="39-18">19 %</td></tr>
<tr><td id="39-19">Diluted EPS (2)</td><td id="39-1a">$ 1.89</td><td id="39-1b">$ 2.31</td><td id="39-1c">$ 0.42</td><td id="39-1d">22 %</td></tr>
</table>

<a id='cada73f3-9d48-43d2-9b53-b5394813d90d'></a>

(1) See "Use of Non-GAAP Constant Currency Information" below for details relating to our use of constant currency information.
(2) For additional information on the calculation of diluted EPS, see Note 12 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

* Revenues were $96.4 billion, an increase of 14% year over year, primarily driven by an increase in Google Services revenues of $8.6 billion, or 12%, and an increase in Google Cloud revenues of $3.3 billion, or 32%.
* Total constant currency revenues, which exclude the effect of hedging, increased 13% year over year.
* Cost of revenues was $39.0 billion, an increase of 10% year over year, primarily driven by increases in TAC, content acquisition costs, and depreciation expense.

<a id='072319d4-3715-42bb-b1b0-51b953016aa4'></a>

40

<!-- PAGE BREAK -->

<a id='2c0d3162-d05f-4930-8077-65df09ef7946'></a>

* Operating expenses were $26.1 billion, an increase of 20% year over year, primarily driven by increases in expenses related to legal and other matters, employee compensation expenses, and depreciation expense.

<a id='09163669-5dfa-4fd0-9eeb-9424d9d0590e'></a>

### Other Information:

*   General and administrative expenses of $5.2 billion for the three months ended June 30, 2025 included a $1.4 billion charge in our Google Services segment related to a settlement in principle of certain legal matters.
*   In May 2025, Alphabet issued fixed-rate senior unsecured notes for net proceeds of $12.5 billion to be used for general corporate purposes. For additional information, see Note 6 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.
*   Repurchases of Class A and Class C shares were $2.5 billion and $10.7 billion, respectively, totaling $13.3 billion for the three months ended June 30, 2025. For additional information, see Note 11 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.
*   Operating cash flow was $27.7 billion for the three months ended June 30, 2025.
*   Capital expenditures, which primarily reflected investments in technical infrastructure, were $22.4 billion for the three months ended June 30, 2025.
*   As of June 30, 2025, we had 187,103 employees.

<a id='9bdf3ebf-8100-4adf-84f2-88f6a86352aa'></a>

We are monitoring ongoing developments surrounding international trade and the macroeconomic
environment. As a result of volatility in international trade and financial markets, we may experience direct and
indirect effects on our business, operations, and financial results. Our past results may not be indicative of our
future performance, and our financial results may differ materially from historical trends.

<a id='5cd26c05-9ca5-4772-904e-c1470926656b'></a>

On July 4, 2025 the OBBBA was signed into law. We are assessing the legislation and its effects on our business, operations, and financial results, including the potential effects on our effective tax rate.

<a id='fab74316-97da-40d2-a6a9-e3f047510f46'></a>

## Financial Results

<a id='0fce23dd-7c02-4751-9a7c-0ed96e990cb5'></a>

The following table presents revenues by type (in millions):
<table id="40-1">
<tr><td id="40-2"></td><td id="40-3" colspan="2">Three Months Ended June 30,</td><td id="40-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="40-5"></td><td id="40-6">2024</td><td id="40-7">2025</td><td id="40-8">2024</td><td id="40-9">2025</td></tr>
<tr><td id="40-a">Google Search &amp; other</td><td id="40-b">$ 48,509</td><td id="40-c">$ 54,190</td><td id="40-d">$ 94,665</td><td id="40-e">$ 104,892</td></tr>
<tr><td id="40-f">YouTube ads</td><td id="40-g">8,663</td><td id="40-h">9,796</td><td id="40-i">16,753</td><td id="40-j">18,723</td></tr>
<tr><td id="40-k">Google Network</td><td id="40-l">7,444</td><td id="40-m">7,354</td><td id="40-n">14,857</td><td id="40-o">14,610</td></tr>
<tr><td id="40-p">Google advertising</td><td id="40-q">64,616</td><td id="40-r">71,340</td><td id="40-s">126,275</td><td id="40-t">138,225</td></tr>
<tr><td id="40-u">Google subscriptions, platforms, and devices</td><td id="40-v">9,312</td><td id="40-w">11,203</td><td id="40-x">18,051</td><td id="40-y">21,582</td></tr>
<tr><td id="40-z">Google Services total</td><td id="40-A">73,928</td><td id="40-B">82,543</td><td id="40-C">144,326</td><td id="40-D">159,807</td></tr>
<tr><td id="40-E">Google Cloud</td><td id="40-F">10,347</td><td id="40-G">13,624</td><td id="40-H">19,921</td><td id="40-I">25,884</td></tr>
<tr><td id="40-J">Other Bets</td><td id="40-K">365</td><td id="40-L">373</td><td id="40-M">860</td><td id="40-N">823</td></tr>
<tr><td id="40-O">Hedging gains (losses)</td><td id="40-P">102</td><td id="40-Q">(112)</td><td id="40-R">174</td><td id="40-S">148</td></tr>
<tr><td id="40-T">Total revenues</td><td id="40-U">$ 84,742</td><td id="40-V">$ 96,428</td><td id="40-W">$ 165,281</td><td id="40-X">$ 186,662</td></tr>
</table>

<a id='05e7208a-48c0-4e1f-8b21-0ad2594c4c6f'></a>

**_Google Services_**

_Google advertising revenues_

_Google Search & other_

<a id='7e8b6748-15f4-40ac-95f6-9296ce63facf'></a>

Google Search & other revenues increased $5.7 billion and $10.2 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025. The overall growth was driven by interrelated factors including increases in search queries resulting from growth in user adoption and usage on mobile devices; growth in advertiser spending; and improvements we have made in ad formats and delivery.

<a id='38e6d206-f115-4907-8c32-95d1a4af7537'></a>

41

<a id='c2dd2dc4-9a5a-4c35-ba5c-54e7688f4d72'></a>

**_Revenues_**

<!-- PAGE BREAK -->

<a id='48e384a9-6d51-4140-a87d-8d2fdc2daafb'></a>

YouTube ads

<a id='bdc3ba9c-8c0e-4219-8014-fa5a97f79b73'></a>

YouTube ads revenues increased $1.1 billion and $2.0 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025. The growth was driven by our direct response advertising products followed by our brand advertising products, both of which benefited from increased spending by our advertisers.

<a id='bc151d91-e2e4-4c5d-9cd7-1fdeaca7ae95'></a>

_Google Network_
Google Network revenues decreased $90 million from the three months ended June 30, 2024 to the three months ended June 30, 2025, primarily due to a decrease in AdSense and Google Ad Manager revenues, partially offset by an increase in AdMob revenues.

<a id='d271d718-7d0e-4d9a-ba19-9c0b4fa6aca8'></a>

Google Network revenues decreased $247 million from the six months ended June 30, 2024 to the six months ended June 30, 2025, primarily due to a decrease in Google Ad Manager revenues and the unfavorable effect of foreign currency exchange rates. These decreases were partially offset by an increase in AdSense revenues.

<a id='4b3f8072-9825-4279-a672-886d8f1a03e4'></a>

Monetization Metrics
The following table presents changes in monetization metrics for Google Search & other revenues (paid clicks and cost-per-click) and Google Network revenues (impressions and cost-per-impression), expressed as a percentage, from three and six months ended June 30, 2024 to three and six months ended June 30, 2025:

<a id='3c29a8e8-f7e3-4670-b6d4-679b85f93c07'></a>

<table id="41-1">
<tr><td id="41-2"></td><td id="41-3">Three Months Ended</td><td id="41-4">Six Months Ended</td></tr>
<tr><td id="41-5"></td><td id="41-6">June 30, 2025</td><td id="41-7">June 30, 2025</td></tr>
<tr><td id="41-8">Google Search &amp; other</td><td id="41-9"></td><td id="41-a"></td></tr>
<tr><td id="41-b">Paid clicks change</td><td id="41-c">4%</td><td id="41-d">3%</td></tr>
<tr><td id="41-e">Cost-per-click change</td><td id="41-f">8%</td><td id="41-g">8%</td></tr>
<tr><td id="41-h" colspan="3">Google Network</td></tr>
<tr><td id="41-i">Impressions change</td><td id="41-j">(6)%</td><td id="41-k">(5)%</td></tr>
<tr><td id="41-l">Cost-per-impression change</td><td id="41-m">6%</td><td id="41-n">5%</td></tr>
</table>

<a id='9ae8a8ae-b22d-4520-a88b-d5105c1f9d4d'></a>

Changes in paid clicks and impressions are driven by a number of interrelated factors, including changes in advertiser spending; ongoing product and policy changes; and, as it relates to paid clicks, fluctuations in search queries resulting from changes in user adoption and usage, primarily on mobile devices.

<a id='f536209d-ecea-4a5b-a1ff-f9215158c3f1'></a>

Changes in cost-per-click and cost-per-impression are driven by a number of interrelated factors including changes in device mix, geographic mix, advertiser spending, ongoing product and policy changes, product mix, property mix, and changes in foreign currency exchange rates.

<a id='b6035e8f-52b6-46fe-8585-06df744373b8'></a>

Google subscriptions, platforms, and devices
Google subscriptions, platforms, and devices revenues increased $1.9 billion and $3.5 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025. The growth was primarily driven by an increase in subscription revenues. This increase was primarily due to the contribution from growth in paid subscriptions across both YouTube services and Google One.

<a id='555a3fe0-1fbd-4e73-9e48-a59b22215a61'></a>

Google Cloud
Google Cloud revenues increased $3.3 billion and $6.0 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025 primarily driven by growth in Google Cloud Platform largely from infrastructure services.

<a id='a82fe730-1b53-45fc-bb90-613b9e2559be'></a>

42

<!-- PAGE BREAK -->

<a id='2d7588ac-42b4-4187-a55b-04d0f3e35c46'></a>

_Revenues by Geography_
The following table presents revenues by geography as a percentage of revenues, determined based on the addresses of our customers:

<table id="42-1">
<tr><td id="42-2"></td><td id="42-3" colspan="2">Three Months Ended June 30,</td><td id="42-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="42-5"></td><td id="42-6">2024</td><td id="42-7">2025</td><td id="42-8">2024</td><td id="42-9">2025</td></tr>
<tr><td id="42-a">United States</td><td id="42-b">49 %</td><td id="42-c">48 %</td><td id="42-d">48 %</td><td id="42-e">48 %</td></tr>
<tr><td id="42-f">EMEA</td><td id="42-g">29 %</td><td id="42-h">29 %</td><td id="42-i">29 %</td><td id="42-j">29 %</td></tr>
<tr><td id="42-k">APAC</td><td id="42-l">16 %</td><td id="42-m">17 %</td><td id="42-n">17 %</td><td id="42-o">17 %</td></tr>
<tr><td id="42-p">Other Americas</td><td id="42-q">6%</td><td id="42-r">6%</td><td id="42-s">6%</td><td id="42-t">6%</td></tr>
<tr><td id="42-u">Hedging gains (losses)</td><td id="42-v">0%</td><td id="42-w">0%</td><td id="42-x">0%</td><td id="42-y">0%</td></tr>
</table>

<a id='c887d363-9776-4f72-87a4-cf014c162b31'></a>

For additional information, see Note 2 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='7a5c7495-df20-4dd6-92a5-82319e81cc84'></a>

**Use of Non-GAAP Constant Currency Information**
International revenues, which represent a significant portion of our revenues, are generally transacted in multiple currencies and therefore are affected by fluctuations in foreign currency exchange rates.

<a id='a35d35f1-8aaa-47e7-9df9-3ad2ec61e084'></a>

The effect of currency exchange rates on our business is an important factor in understanding period-to-period comparisons. We use non-GAAP constant currency revenues ("constant currency revenues") and non-GAAP percentage change in constant currency revenues ("percentage change in constant currency revenues") for financial and operational decision-making and as a means to evaluate period-to-period comparisons. We believe the presentation of results on a constant currency basis in addition to GAAP results helps improve the ability to understand our performance, because it excludes the effects of foreign currency volatility that are not indicative of our core operating results.

<a id='8b9a26db-2b71-437a-9db7-4bf42c80f33d'></a>

Constant currency information compares results between periods as if exchange rates had remained constant period over period. We define constant currency revenues as revenues excluding the effect of foreign currency exchange rate movements ("FX Effect") as well as hedging activities, which are recognized at the consolidated level. We use constant currency revenues to determine the constant currency revenue percentage change on a year-on-year basis. Constant currency revenues are calculated by translating current period revenues using prior year comparable period exchange rates, as well as excluding any hedging effects realized in the current period.

<a id='325cd83a-36f3-49aa-8183-394d6e76f1ee'></a>

Constant currency revenue percentage change is calculated by determining the change in current period revenues over prior year comparable period revenues where current period foreign currency revenues are translated using prior year comparable period exchange rates and hedging effects are excluded from revenues of both periods.

<a id='d252f91c-958d-43ea-8f97-74274cbaa03c'></a>

These results should be considered in addition to, not as a substitute for, results reported in accordance with GAAP. Results on a constant currency basis, as we present them, may not be comparable to similarly titled measures used by other companies and are not a measure of performance presented in accordance with GAAP.

<a id='eadcdec6-4634-474d-9de3-011787a3a349'></a>

43

<!-- PAGE BREAK -->

<a id='93f7786e-76cb-4c92-ac6f-c9c146eb895e'></a>

The following table presents the foreign currency exchange effect on international revenues and total revenues (in millions, except percentages):

<a id='0405ae06-3642-49b3-ab0c-4f79300827f9'></a>

<table id="43-1">
<tr><td id="43-2"></td><td id="43-3"></td><td id="43-4"></td><td id="43-5" colspan="6">Three Months Ended June 30, 2025</td></tr>
<tr><td id="43-6"></td><td id="43-7"></td><td id="43-8"></td><td id="43-9"></td><td id="43-a"></td><td id="43-b" colspan="4">% Change from Prior Period</td></tr>
<tr><td id="43-c"></td><td id="43-d" colspan="2">Three Months Ended June 30,</td><td id="43-e" rowspan="2">Less FX Effect</td><td id="43-f" rowspan="2">Constant Currency Revenues</td><td id="43-g" rowspan="2">As Reported</td><td id="43-h" rowspan="2">Less Hedging Effect</td><td id="43-i" rowspan="2">Less FX Effect</td><td id="43-j" rowspan="2">Constant Currency Revenues</td></tr>
<tr><td id="43-k"></td><td id="43-l">2024</td><td id="43-m">2025</td></tr>
<tr><td id="43-n">United States</td><td id="43-o">$ 41,196</td><td id="43-p">$ 46,063</td><td id="43-q">$ 0</td><td id="43-r">$ 46,063</td><td id="43-s">12%</td><td id="43-t"></td><td id="43-u">0%</td><td id="43-v">12%</td></tr>
<tr><td id="43-w">EMEA</td><td id="43-x">24,683</td><td id="43-y">28,262</td><td id="43-z">780</td><td id="43-A">27,482</td><td id="43-B">14 %</td><td id="43-C"></td><td id="43-D">3 %</td><td id="43-E">11 %</td></tr>
<tr><td id="43-F">APAC</td><td id="43-G">13,823</td><td id="43-H">16,480</td><td id="43-I">115</td><td id="43-J">16,365</td><td id="43-K">19 %</td><td id="43-L"></td><td id="43-M">1 %</td><td id="43-N">18 %</td></tr>
<tr><td id="43-O">Other Americas</td><td id="43-P">4,938</td><td id="43-Q">5,735</td><td id="43-R">(352)</td><td id="43-S">6,087</td><td id="43-T">16 %</td><td id="43-U"></td><td id="43-V">(7)%</td><td id="43-W">23 %</td></tr>
<tr><td id="43-X">Revenues, excluding hedging effect</td><td id="43-Y">84,640</td><td id="43-Z">96,540</td><td id="43-10">543</td><td id="43-11">95,997</td><td id="43-12">14 %</td><td id="43-13"></td><td id="43-14">1 %</td><td id="43-15">13 %</td></tr>
<tr><td id="43-16">Hedging gains (losses)</td><td id="43-17">102</td><td id="43-18">(112)</td><td id="43-19"></td><td id="43-1a"></td><td id="43-1b"></td><td id="43-1c"></td><td id="43-1d"></td><td id="43-1e"></td></tr>
<tr><td id="43-1f">Total revenues (1)</td><td id="43-1g">$ 84,742</td><td id="43-1h">$ 96,428</td><td id="43-1i"></td><td id="43-1j">$ 95,997</td><td id="43-1k">14 %</td><td id="43-1l">0 %</td><td id="43-1m">1 %</td><td id="43-1n">13 %</td></tr>
</table>
(1) Total constant currency revenues of $96.0 billion for the three months ended June 30, 2025 increased $11.4 billion compared to $84.6 billion in revenues, excluding hedging effect, for the three months ended June 30, 2024.

<a id='3477e417-b414-4f92-a854-6a21d083b909'></a>

EMEA revenue growth was favorably affected by changes in foreign currency exchange rates, primarily due to the U.S. dollar weakening relative to the euro and British pound.

<a id='f7ddc556-4cee-429e-824a-7e19444d25ca'></a>

APAC revenue growth was favorably affected by changes in foreign currency exchange rates, primarily due to the U.S. dollar weakening relative to the Japanese yen, partially offset by the U.S. dollar strengthening relative to the South Korean won and Australian dollar.

<a id='fdd4c99b-2dfa-4775-840b-10f0a342e7cc'></a>

Other Americas revenue growth was unfavorably affected by changes in foreign currency exchange rates, primarily due to the U.S. dollar strengthening relative to the Brazilian real and Mexican peso.

<a id='3ada1f9d-b042-455c-8989-398861cac893'></a>

<table id="43-1o">
<tr><td id="43-1p"></td><td id="43-1q"></td><td id="43-1r"></td><td id="43-1s" colspan="6">Six Months Ended June 30, 2025</td></tr>
<tr><td id="43-1t"></td><td id="43-1u"></td><td id="43-1v"></td><td id="43-1w"></td><td id="43-1x"></td><td id="43-1y" colspan="4">% Change from Prior Period</td></tr>
<tr><td id="43-1z"></td><td id="43-1A" colspan="2">Six months ended June 30,</td><td id="43-1B" rowspan="2">Less FX Effect</td><td id="43-1C" rowspan="2">Constant Currency Revenues</td><td id="43-1D" rowspan="2">As Reported</td><td id="43-1E" rowspan="2">Less Hedging Effect</td><td id="43-1F" rowspan="2">Less FX Effect</td><td id="43-1G" rowspan="2">Constant Currency Revenues</td></tr>
<tr><td id="43-1H"></td><td id="43-1I">2024</td><td id="43-1J">2025</td></tr>
<tr><td id="43-1K">United States</td><td id="43-1L">$ 79,933</td><td id="43-1M">$ 90,027</td><td id="43-1N">$ 0</td><td id="43-1O">$ 90,027</td><td id="43-1P">13%</td><td id="43-1Q"></td><td id="43-1R">0%</td><td id="43-1S">13%</td></tr>
<tr><td id="43-1T">EMEA</td><td id="43-1U">48,471</td><td id="43-1V">54,185</td><td id="43-1W">56</td><td id="43-1X">54,129</td><td id="43-1Y">12 %</td><td id="43-1Z"></td><td id="43-20">0 %</td><td id="43-21">12 %</td></tr>
<tr><td id="43-22">APAC</td><td id="43-23">27,112</td><td id="43-24">31,334</td><td id="43-25">(266)</td><td id="43-26">31,600</td><td id="43-27">16 %</td><td id="43-28"></td><td id="43-29">(1)%</td><td id="43-2a">17 %</td></tr>
<tr><td id="43-2b">Other Americas</td><td id="43-2c">9,591</td><td id="43-2d">10,968</td><td id="43-2e">(852)</td><td id="43-2f">11,820</td><td id="43-2g">14 %</td><td id="43-2h"></td><td id="43-2i">(9)%</td><td id="43-2j">23 %</td></tr>
<tr><td id="43-2k">Revenues, excluding hedging effect</td><td id="43-2l">165,107</td><td id="43-2m">186,514</td><td id="43-2n">(1,062)</td><td id="43-2o">187,576</td><td id="43-2p">13 %</td><td id="43-2q"></td><td id="43-2r">(1)%</td><td id="43-2s">14 %</td></tr>
<tr><td id="43-2t">Hedging gains (losses)</td><td id="43-2u">174</td><td id="43-2v">148</td><td id="43-2w"></td><td id="43-2x"></td><td id="43-2y"></td><td id="43-2z"></td><td id="43-2A"></td><td id="43-2B"></td></tr>
<tr><td id="43-2C">Total revenues(1)</td><td id="43-2D">$ 165,281</td><td id="43-2E">$ 186,662</td><td id="43-2F"></td><td id="43-2G">$ 187,576</td><td id="43-2H">13 %</td><td id="43-2I">0 %</td><td id="43-2J">(1)%</td><td id="43-2K">14 %</td></tr>
</table>

<a id='67b92ac1-daa5-41b8-9a79-cf2a241a928c'></a>

(1) Total constant currency revenues of $187.6 billion for the six months ended June 30, 2025 increased $22.5 billion compared to $165.1 billion in revenues, excluding hedging effect, for the six months ended June 30, 2024.
EMEA revenue growth was not materially affected by changes in foreign currency exchange rates, as the effect of the U.S. dollar weakening relative to the British pound was largely offset by the U.S. dollar strengthening relative to the Turkish lira.
APAC revenue growth was unfavorably affected by changes in foreign currency exchange rates, primarily due to the U.S. dollar strengthening relative to the Australian dollar, South Korean won, and Indian rupee.

<a id='8558bde5-8eaa-47da-8163-b799a5d1d2e8'></a>

Other Americas revenue growth was unfavorably affected by changes in foreign currency exchange rates, primarily due to the U.S. dollar strengthening relative to the Brazilian real and Mexican peso.

<a id='918a0a39-724d-4bd0-848f-2dfec25dc6bb'></a>

**_Costs and Expenses_**

<a id='2c1bd821-c465-4231-9810-a6b558a0fd15'></a>

44

<!-- PAGE BREAK -->

<a id='1de05e64-5439-40d0-9afb-1082f8822da1'></a>

Cost of Revenues
The following table presents cost of revenues, including TAC (in millions, except percentages):
<table id="44-1">
<tr><td id="44-2"></td><td id="44-3" colspan="2">Three Months Ended June 30,</td><td id="44-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="44-5"></td><td id="44-6">2024</td><td id="44-7">2025</td><td id="44-8">2024</td><td id="44-9">2025</td></tr>
<tr><td id="44-a">TAC</td><td id="44-b">$ 13,387</td><td id="44-c">$ 14,705</td><td id="44-d">$ 26,333</td><td id="44-e">$ 28,453</td></tr>
<tr><td id="44-f">Other cost of revenues</td><td id="44-g">22,120</td><td id="44-h">24,334</td><td id="44-i">42,886</td><td id="44-j">46,947</td></tr>
<tr><td id="44-k">Total cost of revenues</td><td id="44-l">$ 35,507</td><td id="44-m">$ 39,039</td><td id="44-n">$ 69,219</td><td id="44-o">$ 75,400</td></tr>
<tr><td id="44-p">Total cost of revenues as a percentage of revenues</td><td id="44-q">42 %</td><td id="44-r">41 %</td><td id="44-s">42 %</td><td id="44-t">40 %</td></tr>
</table>

<a id='55fbd697-4ed0-4cca-a8f0-408ea63b6d3a'></a>

Cost of revenues increased $3.5 billion from the three months ended June 30, 2024 to the three months ended June 30, 2025 due to an increase in other cost of revenues and TAC of $2.2 billion and $1.3 billion, respectively. Cost of revenues increased $6.2 billion from the six months ended June 30, 2024 to the six months ended June 30, 2025 due to an increase in other cost of revenues and TAC of $4.1 billion and $2.1 billion, respectively.

<a id='656d5e7e-25d7-42d4-bc64-55d161794357'></a>

The increase in TAC from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025 was largely due to an increase in TAC paid to distribution partners, primarily driven by growth in revenues subject to TAC. The TAC rate decreased from 20.7% to 20.6% from the three months ended June 30, 2024 to the three months ended June 30, 2025 and decreased from 20.9% to 20.6% from the six months ended June 30, 2024 to the six months ended June 30, 2025, primarily due to a revenue mix shift from Google Network properties to Google Search & other properties partially offset by an increase in the Google Search & other TAC rate. The TAC rate on Google Search & other revenues increased from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025 primarily due to increases related to mobile searches. The TAC rate on Google Network revenues was substantially consistent from the three months ended June 30, 2024 to the three months ended June 30, 2025 and decreased from the six months ended June 30, 2024 to the six months ended June 30, 2025 due to a combination of factors, none of which were individually significant.

<a id='28f8963d-c0ed-463c-a413-fae6b9768a31'></a>

The increase in other cost of revenues from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025 was primarily due to increases in content acquisition costs, largely for YouTube, depreciation expense, and certain app and platform distribution costs.

<a id='2ae7f35c-6eaa-47cb-aba1-6af48f30325e'></a>

*Research and Development*
The following table presents R&D expenses (in millions, except percentages):
<table id="44-u">
<tr><td id="44-v"></td><td id="44-w" colspan="2">Three Months Ended June 30,</td><td id="44-x" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="44-y"></td><td id="44-z">2024</td><td id="44-A">2025</td><td id="44-B">2024</td><td id="44-C">2025</td></tr>
<tr><td id="44-D">Research and development expenses</td><td id="44-E">$ 11,860</td><td id="44-F">$ 13,808</td><td id="44-G">$ 23,763</td><td id="44-H">$ 27,364</td></tr>
<tr><td id="44-I">Research and development expenses as a percentage of revenues</td><td id="44-J">14%</td><td id="44-K">14%</td><td id="44-L">14%</td><td id="44-M">15%</td></tr>
</table>

<a id='a0fee954-432a-4e0a-86a1-3687b3a7fda2'></a>

R&D expenses increased $1.9 billion and $3.6 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025, primarily driven by increases in employee compensation expenses of $851 million and $1.5 billion as well as depreciation expense of $575 million and $1.1 billion, respectively.

<a id='fa5c0da9-fbac-45ac-b67c-5c17b2ef41b6'></a>

*Sales and Marketing*
The following table presents sales and marketing expenses (in millions, except percentages):
<table id="44-N">
<tr><td id="44-O"></td><td id="44-P" colspan="2">Three Months Ended June 30,</td><td id="44-Q" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="44-R"></td><td id="44-S">2024</td><td id="44-T">2025</td><td id="44-U">2024</td><td id="44-V">2025</td></tr>
<tr><td id="44-W">Sales and marketing expenses</td><td id="44-X">$ 6,792</td><td id="44-Y">$ 7,101</td><td id="44-Z">$ 13,218</td><td id="44-10">$ 13,273</td></tr>
<tr><td id="44-11">Sales and marketing expenses as a percentage of revenues</td><td id="44-12">8%</td><td id="44-13">7%</td><td id="44-14">8%</td><td id="44-15">7%</td></tr>
</table>

<a id='daabbd5e-0573-4e16-81ba-4e5a081a27a6'></a>

Sales and marketing expenses increased $309 million from the three months ended June 30, 2024 to the three months ended June 30, 2025, primarily driven by an increase in advertising and promotional activities of $305 million.

<a id='6df4ad10-7b65-4ad3-afdc-47460e94bf7a'></a>

45

<!-- PAGE BREAK -->

<a id='3ee7aa4f-9a30-468c-8ce9-c19c27d4b6d9'></a>

Sales and marketing expenses increased $55 million from the six months ended June 30, 2024 to the six months ended June 30, 2025, primarily driven by an increase in advertising and promotional activities of $361 million, partially offset by a decrease in employee compensation expenses of $314 million.

<a id='53fff579-52b3-47a8-9081-8514e6c6b069'></a>

_General and Administrative_
The following table presents general and administrative expenses (in millions, except percentages):
<table id="45-1">
<tr><td id="45-2"></td><td id="45-3" colspan="2">Three Months Ended June 30,</td><td id="45-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="45-5"></td><td id="45-6">2024</td><td id="45-7">2025</td><td id="45-8">2024</td><td id="45-9">2025</td></tr>
<tr><td id="45-a">General and administrative expenses</td><td id="45-b">$ 3,158</td><td id="45-c">$ 5,209</td><td id="45-d">$ 6,184</td><td id="45-e">$ 8,748</td></tr>
<tr><td id="45-f">General and administrative expenses as a percentage of revenues</td><td id="45-g">4%</td><td id="45-h">5%</td><td id="45-i">4%</td><td id="45-j">5%</td></tr>
</table>

<a id='3b3bf519-ff7f-4744-a0fb-7b87aed1676f'></a>

General and administrative expenses increased $2.1 billion and $2.6 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025, primarily driven by an increase in expenses related to legal and other matters of $2.3 billion and $2.6 billion, respectively, largely due to a settlement in principle of certain legal matters.

<a id='29c360b8-a2a1-4fa4-a5c8-67f7dd3b6cbc'></a>

Segment Profitability

We report our segment results as Google Services, Google Cloud, and Other Bets. Additionally, certain costs are not allocated to our segments because they represent Alphabet-level activities. For further details on our segments, Note 15 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='14e9e817-d3c9-4840-8a9b-028fae5c3cd3'></a>

The following table presents segment operating income (loss) (in millions):
<table id="45-k">
<tr><td id="45-l"></td><td id="45-m" colspan="2">Three Months Ended June 30,</td><td id="45-n" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="45-o"></td><td id="45-p">2024</td><td id="45-q">2025</td><td id="45-r">2024</td><td id="45-s">2025</td></tr>
<tr><td id="45-t" colspan="5">Operating income (loss):</td></tr>
<tr><td id="45-u">Google Services</td><td id="45-v">$ 29,674</td><td id="45-w">$ 33,063</td><td id="45-x">$ 57,571</td><td id="45-y">$ 65,745</td></tr>
<tr><td id="45-z">Google Cloud</td><td id="45-A">1,172</td><td id="45-B">2,826</td><td id="45-C">2,072</td><td id="45-D">5,003</td></tr>
<tr><td id="45-E">Other Bets</td><td id="45-F">(1,134)</td><td id="45-G">(1,246)</td><td id="45-H">(2,154)</td><td id="45-I">(2,472)</td></tr>
<tr><td id="45-J">Alphabet-level activities(1)</td><td id="45-K">(2,287)</td><td id="45-L">(3,372)</td><td id="45-M">(4,592)</td><td id="45-N">(6,399)</td></tr>
<tr><td id="45-O">Total income from operations</td><td id="45-P">$ 27,425</td><td id="45-Q">$ 31,271</td><td id="45-R">$ 52,897</td><td id="45-S">$ 61,877</td></tr>
</table>

<a id='93694bcb-96a7-4df7-be13-4791169bc4fa'></a>

(1) In addition to the costs included in Alphabet-level activities, hedging gains (losses) related to revenue were $102 million and $(112) million for the three months ended June 30, 2024 and 2025, respectively, and $174 million and $148 million for the six months ended June 30, 2024 and 2025, respectively. Alphabet-level activities include charges related to employee severance and office space charges.

<a id='8da9ed23-7a91-4870-96b7-ee11e0f2b96f'></a>

*Google Services*
Google Services operating income increased $3.4 billion from the three months ended June 30, 2024 to the three months ended June 30, 2025. The increase in operating income was primarily driven by an increase in revenues, partially offset by increases in expenses related to legal and other matters, TAC, and content acquisition costs.

<a id='78e908a7-c16a-4fce-9ba8-6a2c47a7a109'></a>

Google Services operating income increased $8.2 billion from the six months ended June 30, 2024 to the six months ended June 30, 2025. The increase in operating income was primarily driven by an increase in revenues, partially offset by increases in TAC and content acquisition costs.

<a id='b04dcc03-dd39-4c9f-a4ce-57abebd1fc04'></a>

*Google Cloud*

Google Cloud operating income increased $1.7 billion and $2.9 billion from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025, respectively. The increase in operating income was primarily driven by an increase in revenues, partially offset by increases in usage costs for technical infrastructure and employee compensation expenses.

<a id='2727e56f-f81b-4470-839a-09fc2e9830b3'></a>

Other Bets

<a id='83fd421b-2cf1-4fd6-8204-bb034a74b1f8'></a>

46

<!-- PAGE BREAK -->

<a id='de6905ad-a6e7-42d4-b127-d23fd6e1fa54'></a>

Other Bets operating loss increased $112 million and $318 million from the three and six months ended June 30, 2024 to the three and six months ended June 30, 2025, respectively. The increase in operating loss was due to a combination of factors, none of which were individually significant.

<a id='91b4f291-11da-4ae7-bbad-d7c19227143f'></a>

_Other Income (Expense), Net_
The following table presents OI&E (in millions):
<table id="46-1">
<tr><td id="46-2"></td><td id="46-3" colspan="2">Three Months Ended June 30,</td><td id="46-4" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="46-5"></td><td id="46-6">2024</td><td id="46-7">2025</td><td id="46-8">2024</td><td id="46-9">2025</td></tr>
<tr><td id="46-a">Interest income</td><td id="46-b">$ 1,090</td><td id="46-c">$ 1,050</td><td id="46-d">$ 2,151</td><td id="46-e">$ 2,051</td></tr>
<tr><td id="46-f">Interest expense</td><td id="46-g">(67)</td><td id="46-h">(261)</td><td id="46-i">(161)</td><td id="46-j">(295)</td></tr>
<tr><td id="46-k">Foreign currency exchange gain (loss), net</td><td id="46-l">(173)</td><td id="46-m">(69)</td><td id="46-n">(411)</td><td id="46-o">(175)</td></tr>
<tr><td id="46-p">Gain (loss) on debt securities, net</td><td id="46-q">(310)</td><td id="46-r">165</td><td id="46-s">(772)</td><td id="46-t">367</td></tr>
<tr><td id="46-u">Gain (loss) on equity securities, net</td><td id="46-v">(714)</td><td id="46-w">1,286</td><td id="46-x">1,529</td><td id="46-y">11,044</td></tr>
<tr><td id="46-z">Performance fees</td><td id="46-A">128</td><td id="46-B">(83)</td><td id="46-C">232</td><td id="46-D">(123)</td></tr>
<tr><td id="46-E">Income (loss) and impairment from equity method investments, net</td><td id="46-F">32</td><td id="46-G">419</td><td id="46-H">6</td><td id="46-I">397</td></tr>
<tr><td id="46-J">Other</td><td id="46-K">140</td><td id="46-L">155</td><td id="46-M">395</td><td id="46-N">579</td></tr>
<tr><td id="46-O">Other income (expense), net</td><td id="46-P">$ 126</td><td id="46-Q">$ 2,662</td><td id="46-R">$ 2,969</td><td id="46-S">$ 13,845</td></tr>
</table>

<a id='4937aebd-af8a-4b1e-83c0-6160dba26114'></a>

OI&E, net increased $2.5 billion from the three months ended June 30, 2024 to the three months ended June 30, 2025 primarily due to an increase in net gains on equity and debt securities. The increase was primarily due to an increase in net unrealized gains on equity securities resulting from market-driven changes and fair value adjustments related to observable transactions, and increased net gains on debt securities due to lower market interest rates.

<a id='a1d56e99-2230-4671-a5c1-b1cfba8f2478'></a>

OI&E, net increased $10.9 billion from the six months ended June 30, 2024 to the six months ended June 30, 2025. The increase was primarily due to an increase in net unrealized gains on equity securities resulting from fair value adjustments related to observable transactions and market-driven changes.

<a id='211d7122-a315-4bdf-8003-c8af8b324ced'></a>

For additional information, see Note 3 and Note 7 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='e73ca765-96ac-4b5e-bf22-40a9b211bbd3'></a>

*Provision for Income Taxes*
The following table presents provision for income taxes (in millions, except effective tax rate):
<table id="46-T">
<tr><td id="46-U"></td><td id="46-V" colspan="2">Three Months Ended June 30,</td><td id="46-W" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="46-X"></td><td id="46-Y">2024</td><td id="46-Z">2025</td><td id="46-10">2024</td><td id="46-11">2025</td></tr>
<tr><td id="46-12">Income before provision for income taxes</td><td id="46-13">$ 27,551</td><td id="46-14">$ 33,933</td><td id="46-15">$ 55,866</td><td id="46-16">$ 75,722</td></tr>
<tr><td id="46-17">Provision for income taxes</td><td id="46-18">$ 3,932</td><td id="46-19">$ 5,737</td><td id="46-1a">$ 8,585</td><td id="46-1b">$ 12,986</td></tr>
<tr><td id="46-1c">Effective tax rate</td><td id="46-1d">14.3%</td><td id="46-1e">16.9%</td><td id="46-1f">15.4%</td><td id="46-1g">17.1%</td></tr>
</table>

<a id='f4ed24e0-3a38-41c3-8487-1968542ddfb3'></a>

The effective tax rate increased from the three months ended June 30, 2024 to the three months ended June 30, 2025. This increase was primarily due to a decrease in SBC-related tax benefits, and a non-deductible legal settlement in the U.S., partially offset by changes in prior period tax positions.

<a id='d0bb3f64-4d95-4bcb-9f09-815686b56846'></a>

The effective tax rate increased from the six months ended June 30, 2024 to the six months ended June 30, 2025. This increase was primarily due to a decrease in SBC-related tax benefits, lower effective tax rate impacts in the U.S. federal Foreign Derived Intangible Income tax deduction, and a non-deductible legal settlement in the U.S., partially offset by changes in prior period tax positions.

<a id='4f98c84f-5164-4b0b-9c06-2734d3953ea4'></a>

On July 4, 2025, the OBBBA was signed into law. This legislation includes changes to U.S. federal tax law, which may be subject to further clarification and the issuance of interpretive guidance. We are assessing the legislation and its effect on our consolidated financial statements, which we expect to begin reflecting in the three month period ended September 30, 2025.

<a id='2b2e3b7d-f914-4f9d-97ba-267cf79de3aa'></a>

The Organization for Economic Cooperation and Development is coordinating negotiations among more than 140 countries with the goal of achieving consensus around substantial changes to international tax policies,

<a id='3d08e40d-0076-4e32-a687-1bfc75cf1744'></a>

47

<!-- PAGE BREAK -->

<a id='f40dcbc0-736b-4f09-beee-2f46d8a9ac79'></a>

including the implementation of a minimum global effective tax rate of 15%. Some countries have already implemented the legislation effective January 1, 2024, and we expect others to follow, however this did not have a material effect on our income tax provision for the period ending June 30, 2025.

<a id='f6574fe5-8c07-401f-a3ac-644fa7ce500e'></a>

**Financial Condition**

*Cash, Cash Equivalents, and Marketable Securities*

As of June 30, 2025, we had $95.1 billion in cash, cash equivalents, and short-term marketable securities. Cash equivalents and marketable securities are comprised of time deposits, money market funds, highly liquid government bonds, corporate debt securities, mortgage-backed and asset-backed securities, and marketable equity securities.

<a id='1c20251f-ed72-4a4e-9230-7d4212fe30e0'></a>

_Sources, Uses of Cash and Related Trends_

Our principal sources of liquidity are cash, cash equivalents, and marketable securities, as well as the cash flow that we generate from operations. The primary use of capital continues to be to invest for the long-term growth of the business. We regularly evaluate our cash and capital structure, including the size, pace, and form of capital return to stockholders.

<a id='f99a34da-012d-4440-be40-723b9309b6dc'></a>

The following table presents cash flows (in millions):
<table id="47-1">
<tr><td id="47-2"></td><td id="47-3" colspan="2">Six Months Ended June 30,</td></tr>
<tr><td id="47-4"></td><td id="47-5">2024</td><td id="47-6">2025</td></tr>
<tr><td id="47-7">Net cash provided by operating activities</td><td id="47-8">55,488</td><td id="47-9">63,897</td></tr>
<tr><td id="47-a">Net cash used in investing activities</td><td id="47-b">(11,345)</td><td id="47-c">(40,738)</td></tr>
<tr><td id="47-d">Net cash used in financing activities</td><td id="47-e">(40,603)</td><td id="47-f">(26,033)</td></tr>
</table>

<a id='efae584c-ea4d-47b3-b788-e40adc407b07'></a>

*Cash Provided by Operating Activities*

Our largest source of cash provided by operations are advertising revenues generated by Google Search & other properties, Google Network properties, and YouTube properties. In Google Services, we also generate cash through consumer subscriptions, the sale of apps and in-app purchases, and devices. In Google Cloud, we generate cash through consumption-based fees and subscriptions for infrastructure, platform, applications, and other cloud services.

<a id='0e86de4b-2e30-4e19-905d-c929f9f34c7b'></a>

Our primary uses of cash from operating activities include payments to distribution and Google Network partners, to employees for compensation, and to content providers. Other uses of cash from operating activities include payments to suppliers for devices, to tax authorities for income taxes, and other general corporate expenditures.

<a id='5ac8948c-6225-463d-9aac-f283d222ad28'></a>

Net cash provided by operating activities increased from the six months ended June 30, 2024 to the six months ended June 30, 2025 due to an increase in cash received from customers, partially offset by an increase in cash payments for cost of revenues and operating expenses and an increase in income tax payments.

<a id='4126ec5d-e510-4726-89cf-8a3fddc0d0d6'></a>

_**Cash Used in Investing Activities**_

Cash provided by investing activities consists primarily of maturities and sales of investments in marketable and non-marketable securities. Cash used in investing activities consists primarily of purchases of marketable and non-marketable securities, purchases of property and equipment, and payments for acquisitions.

<a id='c6075efd-d7b1-4b06-9596-b7bbd9c2af44'></a>

Net cash used in investing activities increased from the six months ended June 30, 2024 to the six months ended June 30, 2025 primarily due to a decrease in maturities and sales of marketable securities and an increase in purchases of property and equipment primarily driven by investments in technical infrastructure.

<a id='712a80cc-510c-47eb-9055-e7c0e2524159'></a>

_Cash Used in Financing Activities_
Cash provided by financing activities consists primarily of proceeds from issuance of debt and proceeds from the sale of interests in consolidated entities. Cash used in financing activities consists primarily of repurchases of stock, net payments related to stock-based award activities, payment of dividends, and repayments of debt.

<a id='59b17219-33c7-41b2-bb75-b02869c29f48'></a>

Net cash used in financing activities decreased from the six months ended June 30, 2024 to the six months ended June 30, 2025 due to an increase in proceeds from issuance of debt, net of repayments.

<a id='ada2c79b-54a6-4084-aa20-29b8bb025a53'></a>

48

<!-- PAGE BREAK -->

<a id='267e9177-d702-4af9-8b8c-5332749ff97d'></a>

*Liquidity and Material Cash Requirements*

We expect existing cash, cash equivalents, short-term marketable securities, and cash flows from operations and financing activities to continue to be sufficient to fund our operating activities and cash commitments for investing and financing activities for at least the next 12 months, and thereafter for the foreseeable future.

<a id='0b398d00-e6ac-47cf-a8a1-bd383c3ab532'></a>

_Capital Expenditures and Leases_
We make investments in land, buildings, and servers and network equipment through purchases of property
and equipment and lease arrangements to provide capacity for the growth of our services and products.

<a id='c7e138ac-280a-49f5-b527-dffd2e131694'></a>

**Capital Expenditures**
Our capital investments in property and equipment consist primarily of the following major categories:
* technical infrastructure, which consists of our investments in servers and network equipment for computing, storage, and networking requirements for ongoing business activities, including AI, and data center land and building construction; and
* office facilities, ground-up development projects, and building improvements (also referred to as "fit-outs").

<a id='8d30d9f0-51a2-4f4e-bbb5-4e8a5d1ad56e'></a>

Assets not yet in service are those that are not ready for our intended use, including assets in the process of construction or assembly, and consists primarily of technical infrastructure. The time frame from date of purchase to placement in service of these assets may extend from months to years. For example, our data center construction projects are generally multi-year projects with multiple phases, where we acquire land and buildings, construct buildings, and secure and install servers and network equipment.

<a id='b4527308-ed9f-4084-a1a3-59c58331be69'></a>

During the six months ended June 30, 2024 and 2025, we spent $25.2 billion and $39.6 billion on capital expenditures, respectively. We expect to increase, relative to 2024, our investment in our technical infrastructure, including servers, network equipment, and data centers, to support the growth of our business and our long-term initiatives, in particular in support of AI products and services. Depreciation of our property and equipment commences when such assets are ready for our intended use. For the six months ended June 30, 2024 and 2025, depreciation on property and equipment was $7.1 billion and $9.5 billion, respectively.

<a id='4f2169f0-fccf-476a-938b-91ddf0ddbd4f'></a>

Leases

As of June 30, 2025, the amount of total future lease payments under operating and finance leases was $17.4 billion and $2.6 billion, respectively.

<a id='a8b796d0-8128-4787-8eb8-81b9aedf838c'></a>

As of June 30, 2025, we have entered into leases primarily related to data centers that have not yet commenced with future lease payments of $23.9 billion. These leases will commence between 2025 and 2031 with non-cancelable lease terms between one and 25 years.

<a id='a7c8e239-82fb-4baf-af12-f0cbb93cdfc7'></a>

For additional information on leases, see Note 4 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='e9d26469-80f6-4378-bd69-90fd7d88cc4e'></a>

_Financing_
We have a short-term debt financing program of up to $25.0 billion through the issuance of commercial paper. Net proceeds from this program are used for general corporate purposes. As of June 30, 2025, we had $3.0 billion of short-term commercial paper outstanding.

<a id='bd68922f-b026-489e-8f7f-6d8528f6e197'></a>

In May 2025, we issued $5.0 billion of U.S. dollar-denominated fixed-rate senior unsecured notes in four tranches: $750 million of 4.00% notes due 2030, $1.25 billion of 4.50% notes due 2035, $1.5 billion of 5.25% notes due 2055, and $1.5 billion of 5.30% notes due 2065. Additionally in May 2025, we issued …6.75 billion of euro-denominated fixed-rate senior unsecured notes in five tranches: …1.5 billion of 2.50% notes due 2029, …1.5 billion of 3.00% notes due 2033, …1.25 billion of 3.38% notes due 2037, …1.25 billion of 3.88% notes due 2045, and …1.25 billion of 4.00% notes due 2054. The net proceeds from all notes issued in May 2025 are used for general corporate purposes.

<a id='71900d6c-d96d-4464-8e45-889579b09c47'></a>

As of June 30, 2025, we had senior unsecured notes outstanding with a total carrying value of $24.6 billion.

<a id='345066b6-602b-4f41-a473-faa173b5e9f9'></a>

As of June 30, 2025, we had $10.0 billion of revolving credit facilities, $4.0 billion expiring in April 2026 and $6.0 billion expiring in April 2030. The interest rates for all credit facilities are determined based on a formula using certain market rates. No amounts have been borrowed under the credit facilities.

<a id='cabb1035-9d4d-41e1-9918-cf830acd5deb'></a>

For additional information, see Note 6 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='df345c93-bdd7-45ca-85a2-7d06b5eea6c2'></a>

49

<!-- PAGE BREAK -->

<a id='59b14007-8738-4876-8d73-691a023eb2e4'></a>

We primarily utilize contract manufacturers for the assembly of our servers used in our technical infrastructure and devices we sell. We have agreements where we may purchase components directly from suppliers and then supply these components to contract manufacturers for use in the assembly of the servers and devices. Certain of these arrangements result in a portion of the cash received from and paid to the contract manufacturers to be presented as financing activities in the Consolidated Statements of Cash Flows included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='0c6fd322-06e0-44ce-9d7f-7d576f42d1ae'></a>

Share Repurchase Program
During the three and six months ended June 30, 2025, we repurchased and subsequently retired 81 million and 164 million shares for $13.3 billion and $28.6 billion, respectively.

<a id='d78b72d1-d660-4d88-b378-96f4f830e6f8'></a>

In April 2024, the Board of Directors of Alphabet authorized the company to repurchase up to $70.0 billion of its Class A and Class C shares. In April 2025, the Board of Directors of Alphabet authorized the company to repurchase up to an additional $70.0 billion of Class A and Class C shares. As of June 30, 2025, $86.3 billion remained available for Class A and Class C share repurchases.

<a id='cfcdc532-be37-44af-b876-fd5919365606'></a>

The following table presents Class A and Class C shares repurchased and subsequently retired (in millions):
<table id="49-1">
<tr><td id="49-2"></td><td id="49-3" colspan="2">Three Months Ended June 30, 2025</td><td id="49-4" colspan="2">Six Months Ended June 30, 2025</td></tr>
<tr><td id="49-5"></td><td id="49-6">Shares</td><td id="49-7">Amount</td><td id="49-8">Shares</td><td id="49-9">Amount</td></tr>
<tr><td id="49-a">Class A share repurchases</td><td id="49-b">16</td><td id="49-c">$ 2,537</td><td id="49-d">31</td><td id="49-e">$ 5,303</td></tr>
<tr><td id="49-f">Class C share repurchases</td><td id="49-g">65</td><td id="49-h">10,726</td><td id="49-i">133</td><td id="49-j">23,261</td></tr>
<tr><td id="49-k">Total share repurchases (1)</td><td id="49-l">81</td><td id="49-m">$ 13,263</td><td id="49-n">164</td><td id="49-o">$ 28,564</td></tr>
</table>
(1) Shares repurchased include unsettled repurchases.

<a id='56cb1cd4-8c8f-4938-869e-6a62395a66b7'></a>

For additional information, see Note 11 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='d76a1f67-5310-4082-a98a-938d40ae5403'></a>

Dividend Program
In the three and six months ended June 30, 2025, total cash dividends were $1.2 billion and $2.4 billion for Class A, $178 million and $350 million for Class B, and $1.1 billion and $2.2 billion for Class C shares, respectively.

<a id='5453a099-1ae5-4b88-9451-edfb467b1b56'></a>

In April 2025, the Board of Directors of Alphabet increased the quarterly cash dividend by 5% to $0.21 per share of outstanding Class A, Class B, and Class C shares.

<a id='1b4b7f7c-0978-44ed-b66b-8212bf9ea838'></a>

The company intends to pay quarterly cash dividends in the future, subject to review and approval by the company's Board of Directors in its sole discretion.

<a id='c8721398-026d-488b-a2ef-7bdccdae9141'></a>

_European Commission Fines_
In 2018 and 2019, the EC announced decisions that certain actions taken by Google infringed European competition law and imposed fines of  4.3 billion ($5.1 billion as of June 30, 2018) and  1.5 billion ($1.7 billion as of March 20, 2019), respectively.

<a id='e96fefe1-9b26-4560-a485-667d61b3f098'></a>

In September 2022, the General Court affirmed the EC decision but reduced the 2018 fine from •4.3 billion to
•4.1 billion. We subsequently appealed the General Court's affirmation of the EC decision with the European Court
of Justice, which remains pending.

<a id='e3d6ce61-1470-467c-aaf5-c28daead368f'></a>

In September 2024, the EU's General Court overturned the 2019 decision and annulled the €1.5 billion fine.
The EC has appealed the General Court's decision to the European Court of Justice.

<a id='76f6ff9b-b371-4dfb-884e-eb2e0873b8d1'></a>

We included the outstanding EC fines, including any under appeal, in accrued expenses and other current liabilities on our Consolidated Balance Sheets. For additional information, see Note 10 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='f8619ed2-26c9-4d5a-ab1b-960ef558d861'></a>

*Taxes*

As of June 30, 2025, we had long-term income taxes payable of $10.0 billion primarily related to uncertain tax positions.

<a id='51a21857-838f-4932-a04a-a5570b75b0b9'></a>

_Purchase Commitments and Other Contractual Obligations_

<a id='a4da9b70-126f-4e06-b21b-5fcbe9419bbc'></a>

50

<!-- PAGE BREAK -->

<a id='ff12aa82-2ef4-45dc-b075-0bafc1e832bb'></a>

As of June 30, 2025, we had material purchase commitments and other contractual obligations of $72.5 billion, of which $51.0 billion was short-term. These amounts primarily consist of purchase orders for certain technical infrastructure as well as the non-cancelable portion or the minimum cancellation fee in certain agreements related to commitments to purchase licenses, including content licenses, inventory, and network capacity. For those agreements with variable terms, we do not estimate the non-cancelable obligation beyond any minimum quantities and/or pricing as of June 30, 2025. In certain instances, the amount of our contractual obligations may change based on the expected timing of order fulfillment from our suppliers. For more information related to our content licenses, see Note 10 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='c03bb607-1402-4dfc-9d70-a35891fa1375'></a>

In addition, we regularly enter into multi-year, non-cancellable agreements to purchase renewable energy and energy attributes, such as renewable energy certificates. These agreements do not include a minimum dollar commitment. The amounts to be paid under these agreements are based on the actual volumes to be generated and are not readily determinable.

<a id='fbaa1214-d041-48af-9729-b804eee90fe7'></a>

We may experience increases in the costs associated with our purchase commitments and other contractual obligations as a result of ongoing developments surrounding international trade. For details on risks related to our manufacturing and supply chain and other risks, refer to Part I, Item 1A, "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ending December 31, 2024.

<a id='11755429-3b97-40e3-97cc-1a66e92ce809'></a>

*Pending Acquisition*

In March 2025, we entered into a definitive agreement to acquire Wiz, a leading cloud security platform, for $32.0 billion, subject to closing adjustments, in an all-cash transaction. The acquisition of Wiz is expected to close in 2026, subject to customary closing conditions, including the receipt of regulatory approvals. For additional information, see Note 8 of the Notes to Consolidated Financial Statements included in Item 1 of this Quarterly Report on Form 10-Q.

<a id='ebd3eda4-3e86-45b5-938d-5bee1192bf04'></a>

**Critical Accounting Estimates**
See Part II, Item 7, "Critical Accounting Estimates" in our Annual Report on Form 10-K for the year ended December 31, 2024.

<a id='81265bb5-fa8e-4706-a15e-f83280aa1a9d'></a>

## Available Information

Our website is located at www.abc.xyz, and our investor relations website is located at www.abc.xyz/investor. Access to our Annual Reports on Form 10-K, Quarterly Reports on Form 10-Q, Current Reports on Form 8-K, and our Proxy Statements, and any amendments to these reports, is available on our investor relations website, free of charge, after we file or furnish them with the SEC and they are available on the SEC's website at www.sec.gov.

<a id='ffa4885a-045f-485c-8538-1bfdaa065733'></a>

We webcast via our investor relations YouTube channel and website our earnings calls and certain events we participate in or host with members of the investment community. Our investor relations website also provides notifications of news or announcements regarding our financial performance and other items that may be material or of interest to our investors, including SEC filings, investor events, press and earnings releases, and blogs. We also share Google news and product updates on Google's Keyword blog at https://www.blog.google/ and News From Google page on X at x.com/NewsFromGoogle, and our executive officers may also use certain social media channels, such as X and LinkedIn, to communicate information about earnings results and company updates, which may be of interest or material to our investors. Further, corporate governance information, including our certificate of incorporation, bylaws, governance guidelines, board committee charters, and code of conduct, is also available on our investor relations website under the heading "Governance." The information contained on, or that may be accessed through our websites or our executive officers' social media channels, is not incorporated by reference into this Quarterly Report on Form 10-Q or in any other report or document we file with the SEC, and any references to our websites are intended to be inactive textual references only.

<a id='1f6adfc9-693f-449a-97da-1c2fdcafd206'></a>

## ITEM 3. QUANTITATIVE AND QUALITATIVE DISCLOSURES ABOUT MARKET RISK

For quantitative and qualitative disclosures about market risk, refer to Part II, Item 7A, Quantitative and Qualitative Disclosures About Market Risk, in our Annual Report on Form 10-K for the year ended December 31, 2024.

<a id='41aab4fe-1a64-48d3-81b0-b6ee61f23b4e'></a>

51

<!-- PAGE BREAK -->

<a id='0a7926ba-902b-40f3-a72d-806cc5821e2d'></a>

**ITEM 4.** **CONTROLS AND PROCEDURES**

<a id='6f13bc12-0539-4d29-9d3b-c6e55429bec0'></a>

### Evaluation of Disclosure Controls and Procedures
Our management, with the participation of our chief executive officer and chief financial officer, evaluated the effectiveness of our disclosure controls and procedures pursuant to Rule 13a-15 under the Exchange Act, as of the end of the period covered by this Quarterly Report on Form 10-Q.

<a id='a2eeea94-426e-45e6-84b6-344cd447a58a'></a>

Based on this evaluation, our chief executive officer and chief financial officer concluded that, as of June 30,
2025, our disclosure controls and procedures are designed at a reasonable assurance level and are effective to
provide reasonable assurance that information we are required to disclose in reports that we file or submit under the
Exchange Act is recorded, processed, summarized, and reported within the time periods specified in the SEC's
rules and forms, and that such information is accumulated and communicated to our management, including our
chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required
disclosure.

<a id='e4104eab-0c47-4582-a964-20957901a581'></a>

**Changes in Internal Control over Financial Reporting**

There have been no changes in our internal control over financial reporting that occurred during the quarter ended June 30, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

<a id='e12c051e-1981-449d-aefe-3eb2dcb6060c'></a>

## Limitations on Effectiveness of Controls and Procedures

In designing and evaluating the disclosure controls and procedures, management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving the desired control objectives. In addition, the design of disclosure controls and procedures must reflect the fact that there are resource constraints and that management is required to apply its judgment in evaluating the benefits of possible controls and procedures relative to their costs.

<a id='1262e4a6-84b1-494b-8678-3a0f0a250d03'></a>

52

<!-- PAGE BREAK -->

<a id='509a29f2-bc4b-4756-839f-eff82d0730f5'></a>

## PART II. OTHER INFORMATION

### ITEM 1. LEGAL PROCEEDINGS

For a description of our material pending legal proceedings, see Note 10 "Commitments and Contingencies - Legal Matters" of the Notes to Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q, which is incorporated herein by reference.

<a id='35457d69-5c37-44ef-9db1-b1f5fd44a0b4'></a>

ITEM 1A. RISK FACTORS

Our operations and financial results are subject to various risks and uncertainties, including but not limited to those described in Part I, Item 1A, "Risk Factors" in our Annual Report on Form 10-K for the year ended December 31, 2024, which could harm our business, reputation, financial condition, and operating results, and affect the trading price of our Class A and Class C stock.

<a id='a8cf6524-0e17-4ff3-92b6-c850a6cd35e9'></a>

For additional information about the ongoing material legal proceedings to which we are subject, see Legal
Proceedings in Part II, Item 1 of this Quarterly Report on Form 10-Q.

<a id='88466f6d-5542-4493-88d7-31dbb0f0d8e1'></a>

ITEM 2. UNREGISTERED SALES OF EQUITY SECURITIES AND USE OF PROCEEDS

Issuer Purchases of Equity Securities

The following table presents information with respect to Alphabet's repurchases of Class A and Class C stock during the quarter ended June 30, 2025.

<a id='dc7fb6f3-31f3-45b9-bd98-e82ef7881498'></a>

<table id="52-1">
<tr><td id="52-2">Period</td><td id="52-3">Total Number of Class A Shares Purchased (in thousands) (1)</td><td id="52-4">Total Number of Class C Shares Purchased (in thousands) (1)</td><td id="52-5">Average Price Paid per Class A Share (2)</td><td id="52-6">Average Price Paid per Class C Share (2)</td><td id="52-7">Total Number of Shares Purchased as Part of Publicly Announced Programs (in thousands) (1)</td><td id="52-8">Approximate Dollar Value of Shares that May Yet Be Purchased Under the Program (in millions)</td></tr>
<tr><td id="52-9">April 1-30</td><td id="52-a">8,471</td><td id="52-b">24,689</td><td id="52-c">$ 155.60</td><td id="52-d">$ 157.25</td><td id="52-e">33,160</td><td id="52-f">94,341</td></tr>
<tr><td id="52-g">May 1-31</td><td id="52-h">4,529</td><td id="52-i">22,447</td><td id="52-j">$ 164.95</td><td id="52-k">$ 166.17</td><td id="52-l">26,976</td><td id="52-m">89,893</td></tr>
<tr><td id="52-n">June 1-30</td><td id="52-o">2,710</td><td id="52-p">17,853</td><td id="52-q">$ 174.18</td><td id="52-r">$ 174.39</td><td id="52-s">20,563</td><td id="52-t">86,325</td></tr>
<tr><td id="52-u">Total</td><td id="52-v">15,710</td><td id="52-w">64,989</td><td id="52-x"></td><td id="52-y"></td><td id="52-z">80,699</td><td id="52-A"></td></tr>
</table>

<a id='1bdf82ad-b017-4a7c-ae8a-4a92e97314d1'></a>

1. Repurchases are being executed from time to time, subject to general business and market conditions and other investment opportunities, through open market purchases or privately negotiated transactions, including through Rule 10b5-1 plans. The repurchase program does not have an expiration date. For additional information related to share repurchases, see Note 11 of the Notes to Consolidated Financial Statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.
2. Average price paid per share includes costs associated with the repurchases.

<a id='791308f0-1d54-48ae-8991-67758bbdcae9'></a>

ITEM 5. OTHER INFORMATION

**10b5-1 Trading Plans**

During the quarter ended June 30, 2025, the following Section 16 officers adopted, modified, or terminated a "Rule 10b5-1 trading arrangement" (as defined in Item 408 of Regulation S-K of the Exchange Act).

*   Amie Thuener O'Toole, Vice President, Corporate Controller and Principal Accounting Officer, terminated a trading plan on April 10, 2025 that was originally entered into on May 31, 2024. She adopted a new trading plan on May 23, 2025 (with the first trade under the new plan scheduled for September 2, 2025). The new trading plan will be effective until September 4, 2026 to sell an aggregate of (i) 11,112 shares of Class C Capital Stock plus (ii) 100% of the (net) shares resulting from the vesting of an additional 19,538 (gross) shares of Class C Capital Stock during the plan period (net shares are net of tax withholding).
*   Kent Walker, President, Global Affairs, Chief Legal Officer and Secretary, effected a trading plan modification by terminating a trading plan on May 5, 2025 that was originally adopted on May 29, 2024, and adopting a new trading plan on May 5, 2025 (with the first trade under the new plan scheduled for August 4, 2025). The new trading plan will be effective until February 23, 2028 to sell an aggregate of (i) 6,018 shares of Class C Capital Stock plus (ii) 100% of the (net) shares resulting from the vesting of an additional 328,909 (gross) shares of Class C Capital Stock during the plan period (net shares are net of tax withholding).

<a id='e8870c63-d490-4187-9e2d-e2276d074242'></a>

53

<!-- PAGE BREAK -->

<a id='615916d3-10f1-4995-91cc-7eed43e5574c'></a>

There were no "non-Rule 10b5-1 trading arrangements" (as defined in Item 408 of Regulation S-K of the Exchange Act) adopted, modified, or terminated during the quarter ended June 30, 2025 by our directors and Section 16 officers.

<a id='66955e4c-fba3-45df-8712-a6becf18d5cc'></a>

54

<!-- PAGE BREAK -->

<a id='c3aeaaf5-3126-49f2-b5a8-414421efa74b'></a>

ITEM 6. EXHIBITS

<a id='f5c64cc3-ced4-4f6f-aff0-996a89d039c4'></a>

<table><thead><tr><th rowspan="2">Exhibit<br>Number</th><th rowspan="2">Description</th><th colspan="2">Incorporated by reference herein</th></tr><tr><th>Form</th><th>Date</th></tr></thead><tbody><tr><td>4.01</td><td>Indenture, dated February 12, 2016, between the Registrant<br>and The Bank of New York Mellon Trust Company, N.A., as<br>Trustee</td><td>Registration<br>Statement on<br>Form S-3 (File<br>No. 333-209510)</td><td>February 16,<br>2016</td></tr><tr><td>4.02</td><td>Form of Global Note representing the Registrant's 2.500% notes<br>due 2029</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 06, 2025</td></tr><tr><td>4.03</td><td>Form of Global Note representing the Registrant's 3.000% notes<br>due 2033</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 06, 2025</td></tr><tr><td>4.04</td><td>Form of Global Note representing the Registrant's 3.375% notes<br>due 2037</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 06, 2025</td></tr><tr><td>4.05</td><td>Form of Global Note representing the Registrant's 3.875% notes<br>due 2045</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 06, 2025</td></tr><tr><td>4.06</td><td>Form of Global Note representing the Registrant's 4.000% notes<br>due 2054</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 06, 2025</td></tr><tr><td>4.07</td><td>Form of Global Note representing the Registrant's 4.000% notes<br>due 2030</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 01, 2025</td></tr><tr><td>4.08</td><td>Form of Global Note representing the Registrant's 4.500% notes<br>due 2035</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 01, 2025</td></tr><tr><td>4.09</td><td>Form of Global Note representing the Registrant's 5.250% notes<br>due 2055</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 01, 2025</td></tr><tr><td>4.10</td><td>Form of Global Note representing the Registrant's 5.300% notes<br>due 2065</td><td>Current Report<br>on Form 8-K<br>(File No.<br>001-37580)</td><td>May 01, 2025</td></tr><tr><td>31.01</td><td>* Certification of Chief Executive Officer pursuant to Exchange<br>Act Rules 13a-14(a) and 15d-14(a), as adopted pursuant to<br>Section 302 of the Sarbanes-Oxley Act of 2002</td><td></td><td></td></tr><tr><td>31.02</td><td>* Certification of Chief Financial Officer pursuant to Exchange Act<br>Rules 13a-14(a) and 15d-14(a), as adopted pursuant to Section<br>302 of the Sarbanes-Oxley Act of 2002</td><td></td><td></td></tr><tr><td>32.01</td><td>† Certifications of Chief Executive Officer and Chief Financial<br>Officer pursuant to 18 U.S.C. Section 1350, as adopted<br>pursuant to Section 906 of the Sarbanes-Oxley Act of 2002</td><td></td><td></td></tr><tr><td>101.INS</td><td>* Inline XBRL Instance Document - the instance document does<br>not appear in the Interactive Data File because its XBRL tags<br>are embedded within the Inline XBRL document.</td><td></td><td></td></tr><tr><td>101.SCH</td><td>* Inline XBRL Taxonomy Extension Schema Document</td><td></td><td></td></tr><tr><td>101.CAL</td><td>* Inline XBRL Taxonomy Extension Calculation Linkbase<br>Document</td><td></td><td></td></tr><tr><td>101.DEF</td><td>* Inline XBRL Taxonomy Extension Definition Linkbase Document</td><td></td><td></td></tr><tr><td>101.LAB</td><td>* Inline XBRL Taxonomy Extension Label Linkbase Document</td><td></td><td></td></tr></tbody></table>

<a id='e99946cf-1ca4-45ff-84ba-682465335f9e'></a>

55

<!-- PAGE BREAK -->

<a id='ce6c45fd-1a9c-43a5-9749-5b2fc7509863'></a>

101.PRE * Inline XBRL Taxonomy Extension Presentation Linkbase Document
104 * Cover Page Interactive Data File (formatted as Inline XBRL and contained in Exhibit 101)

<a id='4efb5357-9728-40f8-94b0-d6f3c860e7f4'></a>

--- 
*   Filed herewith.
‡   Furnished herewith.

<a id='0ae16694-8250-4b90-b17a-44d077b62c1c'></a>

56

<!-- PAGE BREAK -->

<a id='4a6059f3-1bd1-495e-89f8-ea6ebfd1c1d7'></a>

## SIGNATURES

Pursuant to the requirements of the Securities Exchange Act of 1934, the registrant has duly caused this report to be signed on its behalf by the undersigned thereunto duly authorized.

<a id='679d31dd-542d-4eb1-a5f9-559058db381c'></a>

<::attestation: Electronic signature/attestation block
Status: Signed
Signature: legible (indicated by /s/)
Readable Text: ALPHABET INC. By: /s/ ANAT ASHKENAZI Anat Ashkenazi Senior Vice President, Chief Financial Officer
Short description of visual elements and positioning: Top attestation block, right-aligned, with date July 23, 2025 left-aligned.::>

<::attestation: Electronic signature/attestation block
Status: Signed
Signature: legible (indicated by /s/)
Readable Text: ALPHABET INC. By: /s/ AMIE THUENER O'TOOLE Amie Thuener O'Toole Vice President, Corporate Controller and Principal Accounting Officer
Short description of visual elements and positioning: Bottom attestation block, right-aligned, with date July 23, 2025 left-aligned.::>

<a id='ae427eaa-e650-40a3-932f-5c619c69b62f'></a>

57