<a id='443b0e2f-1407-4b97-9d6b-9d9508850b0d'></a>

<::logo: PPL Electric Utilities
PPL Electric Utilities
The logo features the letters "ppl" in a dark blue, sans-serif font, with a light blue, semi-circular burst of square and rectangular dots emanating from the right side of the "l".::>

<a id='035f8799-fbff-4a8a-84d1-07313102ed90'></a>

We deliver.

1-888-220-9991

For hours of operation and to
pay/manage your account, visit
pplelectric.com.
businessaccounts@pplweb.com

<a id='8825d88a-14ff-45d9-8b40-c005d25166ea'></a>

Page 1
<table id="0-1">
<tr><td id="0-2">Meter 300000000</td><td id="0-3">Account 00001-00001</td></tr>
<tr><td id="0-4">Due Date</td><td id="0-5">Amount Due</td></tr>
<tr><td id="0-6">6/19/24</td><td id="0-7">$3,133.19</td></tr>
</table>
Billing Details on Back

<a id='f9c6c2c2-f870-4873-a796-00f02aa7299f'></a>

Service to:
JOHN DOE
123 SERVICE RD
ALLENTOWN PA 18100

<a id='b0192a21-d65e-4946-94b8-81a50948377c'></a>

Supply
$0.00
Effective Date
<::
Usage from May 2 - Jun 3
Donut chart showing Usage Charges: $3,133.19. A line points from the donut chart to a box labeled $3,133.19 Delivery for PPL Electric Utilities.
: figure::>
SHOP FOR ELECTRICITY
Visit PAPowerSwitch.com or www.oca.state.pa.us
If you're shopping, know your contract expiration date.
Account Number: 00001-00001
The price to compare is updated June 1st and December 1st.
Rate: View schedule at pplelectric.com/rates
Consider making a monthly pledge to
Operation HELP to assist those in need to
heat their homes.
WANT TO SAVE?
Maintain HVAC equipment and change
your air filters regularly.

<a id='219acd60-cdfd-43ef-8e1f-cfdbdd46183e'></a>

Usage Summary<::bar chart::>Legend: Previous 12 Months (dark grey), Current 12 Months (blue)Chart Title: Avg. Per Day (kWh) by MonthY-axis: Avg. Per Day (kWh) with values from 10000 to 25000X-axis: Months from Jul to JunData:Jul: Previous 12 Months: ~22700 kWh, Current 12 Months: ~20200 kWhAug: Previous 12 Months: ~24000 kWh, Current 12 Months: ~23500 kWhSep: Previous 12 Months: ~23000 kWh, Current 12 Months: ~22800 kWhOct: Previous 12 Months: ~20500 kWh, Current 12 Months: ~20200 kWhNov: Previous 12 Months: ~17500 kWh, Current 12 Months: ~17800 kWhDec: Previous 12 Months: ~16500 kWh, Current 12 Months: ~15500 kWhJan: Previous 12 Months: ~17000 kWh, Current 12 Months: ~16000 kWhFeb: Previous 12 Months: ~16000 kWh, Current 12 Months: ~15000 kWhMar: Previous 12 Months: ~17000 kWh, Current 12 Months: ~16500 kWhApr: Previous 12 Months: ~17500 kWh, Current 12 Months: ~18000 kWhMay: Previous 12 Months: ~18500 kWh, Current 12 Months: ~18200 kWhJun: Previous 12 Months: ~18000 kWh, Current 12 Months: ~18800 kWh (highlighted)For usage and billing details, visit us online at pplelectric.comJune<::data summary table::>| Metric | Change | 2023 Value | 2024 Value ||---|---|---|---|| Electricity Usage (kWh) | +8% | 553200 | 598800 || Demand (KW) | -10% | 1223 | 1095 || Avg. Temperature | +3° | 62° | 65°::<

<a id='683ac1b0-25b6-4d10-af71-9f0a1ba00840'></a>

Questions/concerns? Contact us by 6/19/24

1-888-220-9991

Visit pplelectric.com for hours of operation.

ppl
PPL Electric Utilities

Correspondence to:
PPL Customer Service
827 Hausman Road
Allentown, PA 18104-9392

<a id='501b1ba0-f530-4fa2-be32-675260273652'></a>

<table id="0-8">
<tr><td id="0-9" colspan="3">Sign back of bill stub to enroll in auto bill pay.</td></tr>
<tr><td id="0-a">Account Number</td><td id="0-b">Due Date</td><td id="0-c">Amount Due</td></tr>
<tr><td id="0-d">00001-00001</td><td id="0-e">6/19/24</td><td id="0-f">$3,133.19</td></tr>
</table>

<a id='98770486-4a3b-4af4-8dd6-bfba3c5d3ff1'></a>

Amount Enclosed:
[ ] [ ] [ ] , [ ] [ ] [ ] . [ ] [ ]

<a id='f0b14c7d-1d8a-436e-b53d-3837ea192740'></a>

JOHN DOE
123 SERVICE RD
ALLENTOWN PA 18100

<a id='3bdf7c74-0e34-43ff-bbdc-faf031c2b7d3'></a>

Please make check payable to: PPL ELECTRIC UTILITIES
PO BOX 419054
ST LOUIS, MO 63141-9054

<a id='d3e8ac1d-dca0-4d2b-9571-688924464217'></a>

1 8600031331960003133193 0000100001

<!-- PAGE BREAK -->

<a id='1e1a014d-82c9-4848-9e5f-db4e8bbb402f'></a>

Account 00001-00001

<a id='de22f067-4ad1-424f-bfec-f4480e513949'></a>

Page 2

<a id='38310904-3306-4b66-8fe3-be671740e89b'></a>

<table id="1-1">
<tr><td id="1-2" colspan="6">kWh Delivered (to Customer)</td></tr>
<tr><td id="1-3">Meter Number</td><td id="1-4">Reading Dates</td><td id="1-5">Meter Reading</td><td id="1-6">kWh Difference</td><td id="1-7">Meter Constant</td><td id="1-8">Kilowatt-Hours</td></tr>
<tr><td id="1-9" rowspan="2">300000000</td><td id="1-a">Jun 3</td><td id="1-b">37014</td><td id="1-c" rowspan="2">00499</td><td id="1-d" rowspan="2">1200</td><td id="1-e" rowspan="2">598800</td></tr>
<tr><td id="1-f">May 2</td><td id="1-g">36515</td></tr>
<tr><td id="1-h" colspan="6">Days Billed: 32 Avg. kWh/Day: 18713 Total Delivered: 598800</td></tr>
</table>

<a id='872936af-9e6a-4bb5-9410-5835e6f5d01f'></a>

Next meter reading on or about: Jul 2, 2024.
State taxes this bill: About $30.39. PA Gross Receipts Tax: About $184.85.

<a id='00cc546f-840c-4ecc-b902-e3a59ea39fe8'></a>

Supply Details

Generation & Transmission Charges for May 2-Jun 3

Your supplier will bill you separately for these generation & transmission charges.

<a id='6fffb6ed-62c8-4a9b-96ba-606dccd7834a'></a>

For questions on these charges, please contact this supplier at:

<::transcription of the content
: phone icon::> 1-800-111-1111 <::transcription of the content
: email icon::>

<a id='b7f82245-703a-4357-97aa-c0f90ce3a207'></a>

General information: Generation prices and charges are set by the electric generation supplier you have chosen. The Public Utility Commission regulates distribution rates and services. The Federal Energy Regulatory Commission regulates transmission prices and services.

<a id='845345e3-a9e9-48bb-851e-5f4ff19cd7a3'></a>

<table id="1-i">
<tr><td id="1-j" colspan="2">Billing Summary</td></tr>
<tr><td id="1-k">Previous Balance</td><td id="1-l">$3,179.22</td></tr>
<tr><td id="1-m">Payment Received May 13, 2024 - Thank You!</td><td id="1-n">-$3,179.22</td></tr>
<tr><td id="1-o">Balance as of Jun 3, 2024</td><td id="1-p">$0.00</td></tr>
<tr><td id="1-q">Total Supply Charges</td><td id="1-r">$0.00</td></tr>
<tr><td id="1-s">Total Delivery Charges</td><td id="1-t">$3,133.19</td></tr>
<tr><td id="1-u">Amount Due By 6/19/24</td><td id="1-v">$3,133.19 (orange button)</td></tr>
<tr><td id="1-w">Account Balance</td><td id="1-x">$3,133.19</td></tr>
</table>

<a id='bb0a0ea1-10e9-4e45-ac8e-1db32ca9bfdc'></a>

<table id="1-y">
<tr><td id="1-z" colspan="3">Delivery Details</td></tr>
<tr><td id="1-A" rowspan="10">ppl PPL Electric Utilities (logo)</td><td id="1-B">Distribution Charges Rate: for May 2 - Jun 3 Customer Charge 1,095.0 kW at $2.54701 per kW</td><td id="1-C">169.80</td></tr>
<tr><td id="1-D">Tax Cut and Jobs Act Credit at -7.67% Smart</td><td id="1-E">2,788.97</td></tr>
<tr><td id="1-F">Meter Rider - Phase 1</td><td id="1-G">-226.94</td></tr>
<tr><td id="1-H">Competitive Enhancement Rider</td><td id="1-I">70.00</td></tr>
<tr><td id="1-J">Storm Damage Expense Rider / Customer</td><td id="1-K">0.05</td></tr>
<tr><td id="1-L">System Improvement Charge at 5.00%</td><td id="1-M">9.13</td></tr>
<tr><td id="1-N">Act 129 Compliance Rider</td><td id="1-O">149.51</td></tr>
<tr><td id="1-P">PA Tax Adj Surcharge at -0.208%</td><td id="1-Q">179.20</td></tr>
<tr><td id="1-R"></td><td id="1-S">-6.53</td></tr>
<tr><td id="1-T">Total Delivery Charges</td><td id="1-U">$3,133.19</td></tr>
</table>

<a id='79354dac-c1fc-4adb-b456-87a181ecc05b'></a>

# Understanding Your Bill

**Act 129 Compliance Rider** - Monthly charge to recover costs for energy efficiency and conservation programs approved by the PUC.

**Competitive Enhancement Rider** - Monthly charge to recover costs to support shopping for retail electricity supply.

**Customer Charge** - The basic service charge to partially cover costs for billing, meter reading, equipment and service line maintenance. If you select a new supplier, the name, address and telephone number for both your distribution and supplier company will appear on your bill.

**Distribution Charge (Delivery)** - Part of the basic service charges on every customer's bill for delivering electricity from the electric distribution company to your home or business. The distribution charge is regulated by the Public Utility Commission. This charge will vary according to how much electricity you use.

**Kilowatt-hour (kWh)** - The basic unit of electric energy for which most customers are charged in cents per kilowatt-hour. A kilowatt-hour is the equivalent of using ten 100-watt light bulbs for one hour.

**kWh Delivered** - The amount of electricity we delivered to you for your use.

**Storm Damage Expense Rider** - Monthly charge to recover certain costs to make repairs after major storms.

**System Improvement Charge** - Monthly charge to recover costs for improving, repairing and replacing equipment that delivers electricity to your home or business.

<a id='5df42bae-98f7-45a2-b6f7-b7c9ec6053d5'></a>

Enroll in Automatic Bill Pay

Enroll in Automatic Bill Pay (ABP) and your monthly electric payment will be automatically deducted from your bank checking account. To enroll, sign and date this form and return your check payment (voided check not required). Money orders, cashier and foreign checks do not qualify for enrollment.

<a id='6d958e0c-9a4b-4885-ade8-8daa467a08be'></a>

I authorize PPL Electric Utilities to automatically deduct from the checking account as shown on my enclosed check, all future payments for the PPL Electric Utility bill account number listed on this payment stub. I will notify PPL Electric Utilities if I decide to cancel this authorization.

<a id='a52541fd-f7a1-4577-a4d7-fb30f85fee51'></a>

To enroll in automatic bill payment,
Checking Account holder sign here

<::attestation: Signature line
Signature: illegible
Readable Text: Date
Short description of visual elements and positioning: A long blank line for signature followed by the word 'Date' and another blank line for the date, positioned horizontally.::>

<a id='4e437a5d-9c73-480b-b2cf-3c1e1c5c1199'></a>

**Note**: To enroll a savings account in automatic bill pay visit pplelectric.com/autopay.

<a id='d879794a-5e4e-4ba6-ba75-504e85d71483'></a>

$3,133.19

<!-- PAGE BREAK -->

<a id='61a5a671-8438-4eac-b78a-c0f1a8278e35'></a>

<::logo: PPL
PPL Electric Utilities
The logo features the company name "ppl" in bold blue text, with a stylized sunburst graphic composed of blue dashed lines radiating from behind the text, and "PPL Electric Utilities" written below in a smaller font.::>

<a id='9ad18ccb-9138-4b5e-a7a0-5735ee284f08'></a>

Page 3

<a id='601050cb-9ce3-436c-911c-32320b3c01fb'></a>

<table id="2-1">
<tr><td id="2-2">Account Number</td><td id="2-3">Due Date</td><td id="2-4">Amount Due</td></tr>
<tr><td id="2-5">00001-00001</td><td id="2-6">6/19/24</td><td id="2-7">$3,133.19</td></tr>
</table>

<a id='ad10f995-218a-44ab-b2ba-692b5f3c9474'></a>

## Understanding Your Bill - Continued

**Smart Meter Rider** - Monthly charge to recover costs associated with the smart meter programs approved by the PUC.
**State Tax Adjustment Surcharge** - Monthly charge or credit to reflect changes in various state taxes. The surcharge may vary by bill component.
**Tax Cut and Jobs Act Credit** - Monthly adjustment for federal tax changes.
**Type(s) of Meter Readings:**
**Actual** - Measures your monthly electricity use based on an actual reading.
*Federal I.D. 23-0959590