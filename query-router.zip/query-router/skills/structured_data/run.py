#!/usr/bin/env python3
"""Structured data chatbot skill runner.

Reads JSON from stdin, calls the structured-data chatbot API,
writes JSON to stdout.

TODO: Replace the stub with your actual API call.
"""

import json
import os
import sys

# import httpx  # uncomment when wiring to real API


def main() -> None:
    payload = json.load(sys.stdin)
    query = payload.get("query", "")
    # upstream = payload.get("upstream", {})  # results from prior steps

    # ── Replace this block with your actual API call ──
    # api_url = os.environ.get("STRUCTURED_API_URL", "http://localhost:9001/chat")
    # api_key = os.environ.get("STRUCTURED_API_KEY", "")
    # headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
    # resp = httpx.post(api_url, json={"question": query}, headers=headers, timeout=60)
    # resp.raise_for_status()
    # result = resp.json()

    result = {
        "answer": f"[STUB] Structured data response for: {query}",
        "source": "structured_data",
    }

    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
