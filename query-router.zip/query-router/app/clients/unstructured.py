"""Client for the unstructured-document chatbot API."""

from __future__ import annotations

import logging
from typing import Any

import httpx

from app.config import settings

logger = logging.getLogger(__name__)


class UnstructuredClient:
    """Thin async wrapper around the unstructured-document chatbot endpoint.

    Adapt the `query` method to match your actual API contract.
    """

    def __init__(self) -> None:
        self._base_url = settings.unstructured_api_url
        self._headers: dict[str, str] = {}
        if settings.unstructured_api_key:
            self._headers["Authorization"] = f"Bearer {settings.unstructured_api_key}"

    async def query(self, question: str, context: dict[str, Any] | None = None) -> str:
        payload: dict[str, Any] = {"question": question}
        if context:
            payload["context"] = context

        async with httpx.AsyncClient(timeout=settings.executor_timeout_seconds) as client:
            resp = await client.post(
                self._base_url,
                json=payload,
                headers=self._headers,
            )
            resp.raise_for_status()

        data = resp.json()
        return data.get("answer", data.get("response", str(data)))
