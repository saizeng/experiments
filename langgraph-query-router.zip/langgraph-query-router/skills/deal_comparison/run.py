#!/usr/bin/env python3
"""Deal comparison skill. TODO: Replace stub."""
import json, sys

def main():
    payload = json.load(sys.stdin)
    deal_ids = payload.get("parameters", {}).get("deal_ids", [])
    json.dump({"comparison_table": [], "summary": f"Stub: {len(deal_ids)} deals.", "deals_analyzed": len(deal_ids)}, sys.stdout)

if __name__ == "__main__":
    main()
