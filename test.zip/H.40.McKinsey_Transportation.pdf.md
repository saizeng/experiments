<a id='6da15cb4-8852-4c51-83ac-db754cf025ed'></a>

<::McKinsey & Company logo
: figure::>

<a id='892c1003-b6c9-42e5-aab1-4fe86ff2a2dc'></a>

# Transportation and
# Warehousing
# Sector Analysis

Federal City Council

October 2020

<a id='fcf0f2ca-6dfa-4747-a8bc-bb7f6d6d1c42'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company
is strictly prohibited

<a id='6d2474f8-0c50-4948-8cfb-000defad4a3b'></a>

<::Two images. The top image shows a man and a woman riding bicycles, both wearing helmets. The US Capitol building is visible in the background. The woman is on the left, smiling, wearing a striped shirt and a dark jacket. The man is on the right, wearing a white shirt and a blue tie. The bottom image shows the front and side of a red tram or train. The destination sign on the front reads "2018" and "tion to Oklah". The side of the tram has a yellow stripe pattern and the "dc." logo with some text below it.: figure::>

<!-- PAGE BREAK -->

<a id='776e7e7e-c29a-4e39-a483-b1839ca2d67f'></a>

Contents

<a id='deb30c58-2568-4e55-8eaf-aa0baeee108e'></a>

Baseline Conditions

Challenges and trends

Opportunities and best practices

Appendix

<a id='e238ca58-67e7-4a42-8132-9e9e5cea01bf'></a>

McKinsey & Company

<a id='4c0f0a08-607b-486c-a36c-876b7b036440'></a>

2

<a id='68e2c1bc-27f3-427d-af41-e5df6938baa3'></a>

Last Modified: 1/13/2023 6:03 PM Eastern Standard Time

<a id='c06f2b12-98ad-437f-8a4f-624572699078'></a>

Printed

<!-- PAGE BREAK -->

<a id='14863825-6d2f-4a8c-b07f-1891c226d2d1'></a>

The transportation sector in DC has modest employment...

<a id='d5d10d47-d0ec-4147-af5b-981ec03ab5fa'></a>

<::Employment growth and specialization by industry
: chart::>

Employment CAGR (2019-24)
3.5
3.0
2.5
2.0
1.5
1.0
0.5
0
-0.5
-1.0
-1.5
-2.0
-2.5
-3.0
-3.5

Employment specialization
0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8

LQ = 1

Legend:
Light gray circle: ~50K jobs

Data points:
- Bubble at (0.3, 3.4): (unlabeled)
- Bubble at (0.4, 2.0): Construction
- Bubble at (0.3, 0.9): (unlabeled)
- Bubble at (0.7, 1.1): Finance and insurance
- Bubble at (0.9, 0.1): Admin. and support and waste management and remediation services
- Bubble at (1.5, 1.7): Other services
- Bubble at (2.2, 1.1): Professional, scientific, and technical services
- Bubble at (2.2, 0.2): Government
- Bubble at (2.7, -0.4): Educational services
- Bubble at (1.5, -0.8): Information
- Bubble at (0.8, -0.6): Real estate and rental and leasing
- Bubble at (0.7, -1.6): (unlabeled, outlined bubble)
- Bubble at (0.4, -2.8): Transportation and warehousing (blue bubble)
- Bubble at (0.1, -3.0): (unlabeled)
- Bubble at (1.1, -3.1): Accommodation and food services
- Bubble at (2.8, -2.5): (unlabeled, large arrow pointing right)
::>

<a id='5a2c805d-5178-4d6a-adbb-b81478189f0c'></a>

...but is a critical enabler of economic competitiveness

<a id='6a7ac3b2-72a2-4b83-b505-a752aaaf916d'></a>

Transit solutions are essential to **manage congestion** and support **optimal land use**:
- Reduces congestion by **25%**, saving more than **$1.5 billion** annually in wasted time and fuel
- Saves **1 million+** auto trips per day
- Frees up **200,000** more **parking spaces** in the core, equivalent of **166 blocks** of five-story garages

<a id='805d200e-cc30-4fdd-8e75-dcbadd6d50e2'></a>

DC has one of the highest rates of **transit** and **bike** usage among major cities in the US:
*   **34%** of workers commute by public transit (**3rd** highest among large US cities) and **4%** of workers commute by bicycle (**2nd** highest)³

<a id='a086e7d6-fc59-44f2-bb8a-a4f9fe29f677'></a>

Transit enhances DC's affordability for its residents:
- $342 million/year in auto expenditures saved by households using Metro due to reduced car ownership, operating, and maintenance costs
- 360,000 trips by transit dependents per day

<a id='ca56156c-c7e0-477a-a2ab-e71484522eb3'></a>

* Transportation and warehousing sector is ~2% of DC employment
* 3% decline in jobs forecasted between 2019-24, largely due to COVID-19
* Low specialization relative to the US as a whole (LQ = 0.4)

<a id='fd5f8340-d712-4e24-97eb-33e5aa662d0e'></a>

1 Mining, quarrying, and oil and gas extraction not included; Forecast from Moody's Analytics;
2 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole;
3 With working populations greater than 250K

<a id='0ea7b0ef-eb1e-4caa-9c3e-6c7787ea6a59'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics; WMATA "Why Metro Matters"; US Census

<a id='cf729735-ba89-49e4-b714-efb1d3321a18'></a>

McKinsey & Company

<a id='e4d76f04-4279-4601-9483-1dbc3f8656a9'></a>

3

<!-- PAGE BREAK -->

<a id='bac98204-b997-4bdc-9ad1-0fe4cc530f74'></a>

## Transportation and warehousing is a relatively small sector in DC with low specialization relative to US average
---
Employment, growth, and specialization by major industry

<a id='505a5278-d624-4d4c-b349-90f097d41289'></a>

option Focus of this document: [x] option Analyses by other firms: [ ]
<table><thead><tr><th>Sector</th><th>Included in sector analysis</th><th>Size<br>Jobs, 2019¹</th><th>Growth<br>CAGR, 2014-19, %</th><th>Growth<br>CAGR, 2019-24, %²</th><th>Specialization<br>Jobs LQ³</th></tr></thead><tbody><tr><td>Government and government enterprises</td><td>✓</td><td>248,311</td><td>0%</td><td>0%</td><td>2.2</td></tr><tr><td>Professional, scientific, and technical services</td><td>✓</td><td>147,712</td><td>3%</td><td>2%</td><td>2.2</td></tr><tr><td>Other services (except government and government enterprises)⁴</td><td>✓</td><td>86,662</td><td>2%</td><td>1%</td><td>1.6</td></tr><tr><td>Health care and social assistance</td><td></td><td>76,211</td><td>1%</td><td>-2%</td><td>0.7</td></tr><tr><td>Accommodation and food services</td><td>✓</td><td>75,933</td><td>3%</td><td>-3%</td><td>1.1</td></tr><tr><td>Educational services</td><td>✓</td><td>59,427</td><td>-1%</td><td>0%</td><td>2.7</td></tr><tr><td>Admin. and support and waste management and remediation services</td><td></td><td>52,751</td><td>0%</td><td>-1%</td><td>0.9</td></tr><tr><td>Real estate and rental and leasing</td><td>✓</td><td>32,102</td><td>3%</td><td>-2%</td><td>0.7</td></tr><tr><td>Finance and insurance</td><td></td><td>27,956</td><td>3%</td><td>1%</td><td>0.6</td></tr><tr><td>Retail trade</td><td>✓</td><td>26,806</td><td>2%</td><td>0%</td><td>0.3</td></tr><tr><td>Information</td><td></td><td>22,510</td><td>3%</td><td>-1%</td><td>1.4</td></tr><tr><td>Arts, entertainment, and recreation</td><td>✓</td><td>19,640</td><td>6%</td><td>0%</td><td>0.9</td></tr><tr><td>Construction</td><td>✓</td><td>17,961</td><td>1%</td><td>2%</td><td>0.4</td></tr><tr><td>Transportation and warehousing</td><td>✓</td><td>15,145</td><td>13%</td><td>-3%</td><td>0.4</td></tr><tr><td>Wholesale trade</td><td></td><td>5,782</td><td>0%</td><td>1%</td><td>0.2</td></tr><tr><td>Management of companies and enterprises</td><td></td><td>3,489</td><td>6%</td><td>3%</td><td>0.3</td></tr><tr><td>Manufacturing</td><td></td><td>2,154</td><td>4%</td><td>-3%</td><td>0.0</td></tr><tr><td>Utilities</td><td></td><td>2,116</td><td>1%</td><td>-3%</td><td>0.8</td></tr><tr><td>Mining, quarrying, and oil and gas extraction</td><td></td><td>252</td><td>-10%</td><td>-1%</td><td>0.0</td></tr><tr><td>Total</td><td></td><td>923,009</td><td>1%</td><td>0%</td><td>1.0</td></tr></tbody></table>

<a id='1a958bb9-240a-4185-ba51-c6fa87779339'></a>

Transportation and warehousing represents <2% of total DC employment

1 Full-time and part-time; Includes Wage and salary employment and Proprietors employment;
2 Forecasts from Moody's Analytics;
3 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole;
4 Other services is an especially large sector in DC as it includes NGOs and other institutions

<a id='87371461-3c67-498f-9dc9-b54347773ec0'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics

<a id='31bc2ad5-6ee5-4de2-b423-de947bf39590'></a>

McKinsey & Company

<a id='d989f589-0cb8-424a-8cb3-2b96157007fc'></a>

4

<!-- PAGE BREAK -->

<a id='fb21c3f8-2fba-41f7-be89-cdbaacf9e7cb'></a>

Transit and ground passenger transportation is by far the largest
employer within this sector in DC
Employment, growth, and specialization by subsector

<a id='31776306-bc36-43e6-8a35-40d7d121e5ca'></a>

<::table::>| Subsector | Size Jobs, 2019¹ | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %² | Specialization Jobs LQ³ ||---|---|---|---|---|| Transit and ground passenger transportation⁴ | 10,156 | 18% | -4% | 1.0 || Couriers and messengers | 1,635⁵ | NA⁶ | 1% | 0.3 || Rail transportation | 1,580 | -2% | -4% | 2.0 || Scenic and sightseeing transportation | 662 | 9% | -4% | 2.8 || Support activities for transportation | 394 | 18% | -1% | 0.1 || Truck transportation | 375 | 5% | -1% | 0.0 || Air transportation | 91 | -2% | -3% | 0.0 || Warehousing and storage | 69 | NA⁶ | 2% | 0.0 || Water transportation | 30 | NA⁶ | -3% | 0.1 || Transportation and warehousing (total) | 15,145 | 13% | -3% | 0.4 <::/table::>

<a id='9ade44b2-61c0-4e96-8c8d-bb86515f2dbe'></a>

1. Full-time and part-time; Includes Wage and salary employment and Proprietors employment; Subsector jobs may not add up 100% to total due to data suppression
2. Forecasts from Moody's Analytics
3. Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole
4. Includes transit networks such as WMATA and rideshare such as Uber and Lyft, etc.
5. 2018 data (2019 data suppressed)
6. Historical data points suppressed

<a id='ab54b72b-496f-485f-af82-ad26af15965f'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics

<a id='71861d8a-7036-44d9-828d-dc3532021b6b'></a>

McKinsey & Company

<a id='bebd367d-d64a-4a26-b782-e596da1f4cb8'></a>

5

<!-- PAGE BREAK -->

<a id='6ad8aa1b-7379-4ddc-abb1-5359ea32b7cc'></a>

Top Transportation occupations employ a majority of Black workers, and are at highest risk of displacement from automation

<a id='f6ee4ad9-039b-47c2-8abc-9593fbde4991'></a>

White Black or African American Latinx Other¹
Top 10 Transportation and warehousing occupations
by number of jobs within industry in DC¹
Thousand, 2019

Median annual
earnings
$

Automation
potential
%²

Employment share by race
%

Passenger Vehicle Drivers, Except Bus Drivers, Transit and Intercity
2.1
31,998
76%³
<::chart: Employment share by race breakdown: White 10%, Black or African American 82%, Latinx 7%, Other 1%::>
Passenger Attendants
0.4
39,499
80%⁴
<::chart: Employment share by race breakdown: White 11%, Black or African American 77%, Latinx 9%, Other 3%::>
Light Truck Drivers
0.3
38,616
78%
<::chart: Employment share by race breakdown: White 30%, Black or African American 53%, Latinx 12%, Other 5%::>
Heavy and Tractor-Trailer Truck Drivers
0.3
52,467
81%
<::chart: Employment share by race breakdown: White 33%, Black or African American 49%, Latinx 14%, Other 4%::>
Bus Drivers, Transit and Intercity
0.2
33,495
85%
<::chart: Employment share by race breakdown: White 14%, Black or African American 78%, Latinx 5%, Other 3%::>
Laborers and Freight, Stock, and Material Movers, Hand
0.1
39,251
7%
<::chart: Employment share by race breakdown: White 29%, Black or African American 53%, Latinx 13%, Other 5%::>
Couriers and Messengers
0.1
34,172
39%
<::chart: Employment share by race breakdown: White 36%, Black or African American 46%, Latinx 11%, Other 7%::>
Dispatchers, Except Police, Fire, and Ambulance
0.1
51,693
40%
<::chart: Employment share by race breakdown: White 36%, Black or African American 49%, Latinx 11%, Other 4%::>
General and Operations Managers
0.1
143,716
23%
<::chart: Employment share by race breakdown: White 61%, Black or African American 22%, Latinx 8%, Other 9%::>
Railroad Conductors and Yardmasters
0.1
71,353
46%
<::chart: Employment share by race breakdown: White 17%, Black or African American 79%, Latinx 3%, Other 1%::>

* All top roles (except operations managers) have a higher share of Black workers than DC as a whole, which is 44% Black and 37% White (both non-Latinx)
* These jobs all require a high school diploma, except for heavy truck drivers (certificate) and operations managers (Bachelor's)
* In the medium term, the District can work towards upskilling workers from high automation jobs to those with less risk and higher wages

<a id='df166a17-77a6-4f1f-b08f-70018a1d469a'></a>

1. Asian, American Indian or Alaska Native, Native Hawaiian or Other Pacific Islander, Two or More Races; does not include all "Proprietors employment", which includes many small business owners and contractors
2. Dark = lowest risk of automation; preliminary analysis
3. Taxi drivers and chauffeurs used for automation analysis
4. Transportation attendants used for automation analysis

<a id='75a11247-e81b-438f-a1ec-7cb7f4443143'></a>

Source: EMSI; Bureau of Labor Statistics (BLS); McKinsey Global Institute (MGI)

<a id='9066a2b9-d4b8-4ae4-8129-c9ce16375e54'></a>

McKinsey & Company

<a id='55689562-10c2-49dc-82dc-12bfacb813f6'></a>

6

<!-- PAGE BREAK -->

<a id='aa0400ad-be95-4273-ab53-d284a9fabf26'></a>

Contents

<a id='0ea4ab70-e1f4-4f23-a441-879c2fbbba91'></a>

Baseline Conditions
Challenges and trends
Opportunities and best practices
Appendix

<a id='cf33b675-7fa8-4ad2-963e-9fde622d0b95'></a>

McKinsey & Company

<a id='60cb389d-ea25-42a1-bc4f-9bb6ba676d24'></a>

7

<a id='739322ef-2a4c-4493-ba50-ab96ba6da3b4'></a>

Last Modified 7/13/2020 6:00 PM Eastern Standard Time

<a id='f3560952-2b7d-4aff-8b15-a0bf869d87ce'></a>

Printed

<!-- PAGE BREAK -->

<a id='9e9335df-8a47-4c0a-91df-b4049210b369'></a>

Preliminary, proprietary, pre-decisional Non-exhaustive

<a id='9fc2fe0f-6961-440c-9a56-477460cef528'></a>

Mobility in DC: Five core challenges will shape the future of the sector and its ability to support broader economic competitiveness

<a id='508dc466-4533-45fe-a892-fbdd6ea9fa7e'></a>

<table><thead><tr><th>Challenge</th><th>A – Pre-COVID-19 trends</th><th>B – Impacts of COVID-19</th></tr></thead><tbody><tr><td>1<br>$<br>Health and<br>viability of transit</td><td>Strong existing transit base with declining ridership levels<ul><li>34% of workers commute by public transit (3rd highest among large US cities) and 4% of workers commute by bicycle (2nd highest)</li><li>15% and 20% decline in rail and bus ridership from 2011-19</li></ul></td><td>Significant transit ridership drop and funding gaps<ul><li>38% and 13% Metrobus and Metrorail ridership compared to pre-COVID levels as of end of Summer</li><li>~$250 million budget gap forecasted by WMATA through end of FY</li><li>5% decline in Trade, transportation, and utilities jobs (Aug '19-20)</li></ul></td></tr><tr><td>2<br>/\<br>Mitigating<br>Congestion and<br>its impacts on<br>productivity</td><td>Congestion, long commute times and increased TNCs<ul><li>3rd in yearly delays per auto commuter among large metros (~$2K annual cost of congestion per commuter)</li><li>3/4 of public transit riders and 1/2 of drivers face daily commutes over 30 minutes</li></ul></td><td>Short-term congestion decline, rebound expected; rise of telework<ul><li>3% increase in driving demand since the start of the pandemic</li><li>55% of executives said most (60-100%) office employees will work remotely at least one day a week post-COVID-19<sup>1</sup></li></ul></td></tr><tr><td>3<br>Managing the<br>curbside</td><td>Pressure on curb from TNCs, e-commerce and curbside delivery<ul><li>10,000 new rideshare drivers added annually (2014-17) in the D.C. metro area</li><li>98% increase in e-commerce sales from 2014 to 2019<sup>1</sup></li></ul></td><td>Continued rise of e-commerce, with new uses for the curb<ul><li>32% increase in e-commerce sales from 2020 Q1 to Q2<sup>1</sup></li><li>81% of 685 poll respondents support "streeteries" post-COVID</li></ul></td></tr><tr><td>4<br>Ensuring equity<br>in transportation<br>and transit access</td><td>Unequal transit access among communities of color<ul><li>39% of Black residents in low-income neighborhoods lack access to high frequency transit</li><li>33.7 minutes is the average commute time for Black workers, longest among racial groups</li></ul></td><td>Unequal transit access for essential workers<ul><li>62% of jobs requiring less formal training, such as drivers and clerks, can be reached by residents with applicable skills (compared to 72% for high-skill jobs and residents)</li><li>50% of Health technologists (example occupation) in low-income neighborhoods lack access to high frequency transit</li></ul></td></tr><tr><td>5<br>Ensuring safety</td><td>Lagging safety outcomes, most notably for cyclists<ul><li>4.3 bicycling fatalities per 1M population, higher than San Francisco, Seattle, Chicago, New York, Boston, and others</li><li>2nd highest share of bicycle commuters yet 15th and 27th city in number of miles of protected and unprotected bike lanes</li></ul></td><td>Increased demand for walking and biking: safety critical<ul><li>5% increase in biking and walking and 1% increase in shared micromobility expected immediately in the "new normal"<sup>1</sup></li></ul></td></tr></tbody><tfoot><tr><td colspan="3">1. US statistic</td></tr></tfoot></table>

<a id='29ade109-4ccc-45c2-95f6-8c7573f6f59b'></a>

Source: US Census; WMATA, Regional Reopening Plans; PwC "US Remote Work Survey"; Texas A&M, 2019 Urban Mobility Report; Apple Mobility Trends Report; WUSA9; NHTSA Traffic Safety Facts; McKinsey Center for Future Mobility; Metropolitan Policy Program at Brookings; Barred in DC Twitter poll, accessed through WUSA9; BLS-Current Employment Statistics (CES); DCist

<a id='2f5561c2-f967-4b01-a90c-86eb55c2f86d'></a>

McKinsey & Company

<a id='3590aca6-4966-4e6e-9521-5246a6a2845a'></a>

8

<!-- PAGE BREAK -->

<a id='27742c72-6e49-48e7-b3ea-eac311f0c41d'></a>

1b: WMATA has seen record low ridership that is just beginning to

<a id='db0d7a48-c170-46fe-a3f2-89238edeb33f'></a>

recover
WMATA monthly ridership during COVID-19,
% of 2019 ridership, Jan-Jul 2020
<::Line chart showing WMATA monthly ridership during COVID-19 as a percentage of 2019 ridership from January to August 2020.
The x-axis represents months: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug.
The y-axis represents the percentage of 2019 ridership.

Legend:
- Metrobus (black line)
- Metrorail (blue line)

Data points for Metrobus:
- Jan: ~105%
- Feb: 110%
- Mar: 33%
- Apr: 17%
- May: ~18%
- Jun: 19%
- Jul: 33%
- Aug: 38%

Data points for Metrorail:
- Jan: ~100%
- Feb: 112%
- Mar: 49%
- Apr: 5%
- May: ~8%
- Jun: 9%
- Jul: 10%
- Aug: 13%

Vertical dashed lines indicate key events:
- Between Mar and Apr: "Initial regional lockdown"
- Between May and Jun: "Phase 1 reopening (DC)"
- Between Jun and Jul: "Phase 2 reopening (DC)"
: chart::>

<a id='37b22c47-a610-4e8a-92ad-639f6c36c728'></a>

Source: WMATA, Regional Reopening Plans

<a id='23d16285-dcf4-4cdf-8bd4-bc68e08c8c8a'></a>

McKinsey & Company

<!-- PAGE BREAK -->

<a id='89f75986-d234-46c7-adb3-302f35cb3c41'></a>

1b: Employment in Trade, transportation, and utilities declined by 5%, which was not as steep a decline as DC overall

<a id='7dac4d95-270e-40b6-80fc-ff2224a35df6'></a>

Change in employment by major industry from August 2019 to August 2020¹
% change

<a id='ced71fff-9a2f-48fc-8117-57c2be932984'></a>

<::Bar chart showing changes in various economic sectors for DC and US. The chart displays categories on the y-axis and numerical values on the x-axis, with separate bars and values for DC and US for each category.

| Category                                 | DC    | US    |
|:-----------------------------------------|:------|:------|
| Leisure and hospitality                  | -47   | -23   |
| Manufacturing                            | -8    | -6    |
| Total                                    | -7    | -7    |
| Financial activities                     | -6    | -1    |
| Education and health services            | -6    | -5    |
| Trade, transportation, and utilities     | -5    | -4    |
| Professional and business services       | -4    | -6    |
| Construction                             | 1     | -4    |
| Government                               | 2     | -3    |
: bar chart::>

<a id='316bde91-9065-4cd2-a41c-b3dffbe05678'></a>

1. Available sectors with data shown here

<a id='f1ce44c4-0217-42d5-9031-82fa4b15c32e'></a>

Source: Bureau of Labor Statistics (BLS) Current Employment Statistics (CES)

<a id='678d0798-56c2-43ab-9805-5f28e002aa95'></a>

McKinsey & Company

<a id='b9003cf6-2778-4364-a4da-8889940182f4'></a>

10

<!-- PAGE BREAK -->

<a id='5858a0be-82c8-4eef-8c21-cf2a207502bb'></a>

2a: DC faces relatively high congestion delays and costs
National Congestion Table – What congestion means to you, 2017

<a id='78ca6e64-2800-46b4-a557-8f62f9afa5ab'></a>

<table id="10-1">
<tr><td id="10-2"></td><td id="10-3" colspan="2">Yearly Delay per Auto Commuter</td><td id="10-4" colspan="2">Travel Time Index</td><td id="10-5" colspan="2">Excess Fuel per Auto Commuter</td><td id="10-6" colspan="2">Congestion Cost per Auto Commuter</td></tr>
<tr><td id="10-7">Urban Area</td><td id="10-8">Hours</td><td id="10-9">Rank</td><td id="10-a">Value</td><td id="10-b">Rank</td><td id="10-c">Gallons</td><td id="10-d">Rank</td><td id="10-e">Dollars</td><td id="10-f">Rank</td></tr>
<tr><td id="10-g">Very Large Average (15 areas)</td><td id="10-h">83</td><td id="10-i"></td><td id="10-j">1.35</td><td id="10-k"></td><td id="10-l">32</td><td id="10-m"></td><td id="10-n">1,730</td><td id="10-o"></td></tr>
<tr><td id="10-p">Los Angeles-Long Beach-Anaheim CA</td><td id="10-q">119</td><td id="10-r">1</td><td id="10-s">1.51</td><td id="10-t">1</td><td id="10-u">35</td><td id="10-v">4</td><td id="10-w">2,676</td><td id="10-x">1</td></tr>
<tr><td id="10-y">San Francisco-Oakland CA</td><td id="10-z">103</td><td id="10-A">2</td><td id="10-B">1.50</td><td id="10-C">2</td><td id="10-D">39</td><td id="10-E">1</td><td id="10-F">2,619</td><td id="10-G">2</td></tr>
<tr><td id="10-H">Washington DC-VA-MD</td><td id="10-I">102</td><td id="10-J">3</td><td id="10-K">1.35</td><td id="10-L">7</td><td id="10-M">38</td><td id="10-N">2</td><td id="10-O">2,015</td><td id="10-P">3</td></tr>
<tr><td id="10-Q">New York-Newark NY-NJ-CT</td><td id="10-R">92</td><td id="10-S">4</td><td id="10-T">1.35</td><td id="10-U">7</td><td id="10-V">38</td><td id="10-W">2</td><td id="10-X">1,947</td><td id="10-Y">4</td></tr>
<tr><td id="10-Z">Boston MA-NH-RI</td><td id="10-10">80</td><td id="10-11">6</td><td id="10-12">1.30</td><td id="10-13">19</td><td id="10-14">31</td><td id="10-15">7</td><td id="10-16">1,580</td><td id="10-17">8</td></tr>
<tr><td id="10-18">Seattle WA</td><td id="10-19">78</td><td id="10-1a">7</td><td id="10-1b">1.37</td><td id="10-1c">5</td><td id="10-1d">31</td><td id="10-1e">7</td><td id="10-1f">1,541</td><td id="10-1g">9</td></tr>
<tr><td id="10-1h">Atlanta GA</td><td id="10-1i">77</td><td id="10-1j">8</td><td id="10-1k">1.30</td><td id="10-1l">19</td><td id="10-1m">31</td><td id="10-1n">7</td><td id="10-1o">1,653</td><td id="10-1p">5</td></tr>
<tr><td id="10-1q">Houston TX</td><td id="10-1r">75</td><td id="10-1s">9</td><td id="10-1t">1.34</td><td id="10-1u">11</td><td id="10-1v">31</td><td id="10-1w">7</td><td id="10-1x">1,508</td><td id="10-1y">10</td></tr>
<tr><td id="10-1z">Chicago IL-IN</td><td id="10-1A">73</td><td id="10-1B">10</td><td id="10-1C">1.32</td><td id="10-1D">16</td><td id="10-1E">30</td><td id="10-1F">12</td><td id="10-1G">1,431</td><td id="10-1H">11</td></tr>
<tr><td id="10-1I">Miami FL</td><td id="10-1J">69</td><td id="10-1K">12</td><td id="10-1L">1.31</td><td id="10-1M">17</td><td id="10-1N">34</td><td id="10-1O">5</td><td id="10-1P">1,412</td><td id="10-1Q">12</td></tr>
<tr><td id="10-1R">Dallas-Fort Worth-Arlington TX</td><td id="10-1S">67</td><td id="10-1T">13</td><td id="10-1U">1.26</td><td id="10-1V">23</td><td id="10-1W">25</td><td id="10-1X">20</td><td id="10-1Y">1,272</td><td id="10-1Z">18</td></tr>
<tr><td id="10-20">San Diego CA</td><td id="10-21">64</td><td id="10-22">16</td><td id="10-23">1.35</td><td id="10-24">7</td><td id="10-25">24</td><td id="10-26">27</td><td id="10-27">1,584</td><td id="10-28">7</td></tr>
<tr><td id="10-29">Philadelphia PA-NJ-DE-MD</td><td id="10-2a">62</td><td id="10-2b">18</td><td id="10-2c">1.25</td><td id="10-2d">25</td><td id="10-2e">26</td><td id="10-2f">15</td><td id="10-2g">1,203</td><td id="10-2h">22</td></tr>
<tr><td id="10-2i">Phoenix-Mesa AZ</td><td id="10-2j">62</td><td id="10-2k">18</td><td id="10-2l">1.27</td><td id="10-2m">22</td><td id="10-2n">26</td><td id="10-2o">15</td><td id="10-2p">1,089</td><td id="10-2q">30</td></tr>
<tr><td id="10-2r">Detroit MI</td><td id="10-2s">61</td><td id="10-2t">20</td><td id="10-2u">1.24</td><td id="10-2v">28</td><td id="10-2w">25</td><td id="10-2x">20</td><td id="10-2y">1,129</td><td id="10-2z">25</td></tr>
</table>

<a id='c0bc2e16-e38b-4fef-adce-c3c83b8fd90c'></a>

Source: Texas A&M, 2019 Urban Mobility Report

<a id='69618aa7-22e3-4cb5-965e-37e1d92cd48e'></a>

McKinsey & Company

<a id='c93d150c-ff2f-4d40-8187-b5a0b606be62'></a>

11

<!-- PAGE BREAK -->

<a id='77b0b5b5-998d-43ab-bf38-f31ec40bfdfd'></a>

**2a: Three-quarters of public transit riders and half of drivers face daily commutes over 30 minutes**---

<a id='c16dbb17-aa4f-4433-a1f2-86a463f9df82'></a>

51% of DC automobile commuters have trips longer than 30min<::bar chart: Commute time by automobile, 2017. Percent of automobile commuters by commute time: <15 mins (12%), 15-29 mins (38%), 30-44 mins (32%), >45 mins (19%). Commute time by public transportation, 2017. Percent of public transit commuters by commute time: <15 mins (2%), 15-29 mins (22%), 30-44 mins (41%), >45 mins (35%).::>76% of public transportation users have commutes over 30 minutes Travel time

<a id='0dbffae7-88a9-426b-9239-0f66457af220'></a>

Walking and biking are most common for commutes less than 30min<::Bar chart showing commute time by walking, 2017. The y-axis represents the % of walking commuters. The x-axis represents Travel time. Data: <15 mins: 36%, 15-29: 44%, 30-44: 14%, >45 mins: 6%. Bar chart showing commute time by other methods, 2017. The y-axis represents the % of other transit commuters. The x-axis represents Travel time. Data: <15 mins: 23%, 15-29: 51%, 30-44: 21%, >45 mins: 5%.: chart::>

<a id='9f57ef5a-61d8-460c-8864-4a3c51014f16'></a>

1. Other includes commuters using bicycles, motorcycles, taxicabs, etc.

<a id='2a34c933-01e6-4477-a7a6-7753536b14cc'></a>

Source: US Census - American Community Survey; WalletHub

<a id='a2bd1cad-0745-4597-bb0c-25b34979bfde'></a>

Metro DC commuters mode of transit, % of commuters using specific mode of transit, 2016<::Metro DC commuters mode of transit pie chart, 2016: Automobile 80%, Public transit 14%, Walk 4%, Other 2%: chart::>• DC ranked **86th of 100** cities in WalletHub's “**Best & Worst Cities to Drive in**” in 2020• **14% of DC metro commuters use public transit, which is significantly lower than automobile usage, but still one of the highest rates of public transit usage** among metro areas• As a city, Washington, DC has the **3rd highest public transit usage** in the US (34%), after New York and San Francisco

<a id='64e03221-3234-4ece-a9bc-d211d0e46bf6'></a>

McKinsey & Company

<a id='29f37d5f-a4a7-437f-bb91-657c2a5e6e10'></a>

12

<!-- PAGE BREAK -->

<a id='36adaa9d-5fbb-40b6-9906-7160c671d924'></a>

2b: Transit demand is down significantly but driving is up since the start of the pandemic

<a id='0a5a1445-767a-470c-a2c1-985cc620f4ec'></a>

<::line chart::>Mobility trends, Change in routing requests since January 13, 2020. The chart displays three lines representing different modes of transport: Driving (red, +3%), Walking (orange, -15%), and Transit (purple, -55%). The y-axis ranges from -80% to +60%, indicating the percentage change. The x-axis shows months from January to October. All three lines show high volatility in Jan-Feb, then a sharp drop in March, indicating a significant decrease in mobility. Driving and Walking then show a gradual recovery from April to October, with Driving generally returning to pre-March levels and Walking remaining below. Transit remains significantly suppressed throughout the entire period after March, hovering around -60% to -50%::>

<a id='81dcee47-61a4-45d7-9612-497523d25634'></a>

Source: Apple Mobility Trends Report

<a id='04c2c376-6ec5-49ca-88e9-2e4f0a07deaa'></a>

McKinsey & Company

<a id='71a89258-485a-4c59-a854-30c4e3f0f0a5'></a>

13

<!-- PAGE BREAK -->

<a id='070fd5cc-e647-4632-8ab0-015e94987845'></a>

**2b: ~50% of white collar workers are teleworking, and many will continue to work remotely post-COVID part-time**
Teleworking is a challenge and opportunity for transportation systems
---


<a id='e318d2b1-3f87-495f-98b6-ca79dd36b0fe'></a>

Share of teleworkers by industry in the United States, May 2020 to September 2020¹
% of workers within industry

<a id='d29975e9-a5a9-4c46-a82a-98864ef27a17'></a>

Educational services
Finance and insurance
Professional and technical services
Information
Public administration
Real estate and rental and leasing
Arts, entertainment, and recreation
Utilities
Mining, quarrying, and oil and gas extraction
Wholesale trade
Manufacturing
Other services
Health care and social assistance
Management, administrative, and waste services
Retail trade
Construction
Transportation and warehousing
Accommodation and food services

<a id='012dc2df-2748-4473-b86f-2f77451a36fc'></a>

<::Horizontal bar chart titled "May 2020" showing 18 bars with the following values (from top to bottom): 76, 67, 64, 61, 46, 42, 38, 37, 32, 31, 30, 28, 25, 24, 17, 15, 12, 8.

Horizontal bar chart titled "September 2020" showing 18 bars with the following values (from top to bottom): 41, 53, 50, 45, 33, 26, 21, 27, 22, 22, 20, 15, 16, 14, 9, 8, 8, 5.
: bar chart::>

<a id='c31a5bd7-b35b-43b1-8895-068ee6d71e6f'></a>

According to PwC's US Remote Work Survey:
*   55% of executives said most (60-100%) of office employees will work remotely at least one day a week post-COVID-19
*   72% of surveyed office workers would like to work remotely at least two days per week
According to Upwork's The Future of Remote Work
*   ~20% of the workforce is likely to continue working remotely on a full-time basis
*   ~33% will continue doing so part-time

<a id='70bd587d-c94b-4d93-bfdc-55b3a7654299'></a>

The rise in telework presents challenges and opportunities for transit, as people may decide to live further from their employer's offices (swapping a longer, occasional commute for more space), commute to work less times per week, and take more local trips throughout the day during "off-peak" hours

<a id='20d47daa-5d70-4f61-a2ed-0cc0e0ef0000'></a>

1. Data from BLS - CPS; Full description: Employed persons who teleworked or worked at home for pay at any time in the last 4 weeks because of the coronavirus pandemic

<a id='4f2cb520-2ab6-45e1-aebb-26fd6493d529'></a>

Source: Bureau of Labor Statistics (BLS) - Current Population Survey (CPS); PwC - US Remote Work Survey; Upwork - The Future of Remote Work; government technology magazine

<a id='a4610786-5596-47eb-a83f-d1928a0aa95d'></a>

McKinsey & Company

<a id='41d77411-56ce-44f3-bbca-22c9c8a6ad26'></a>

14

<!-- PAGE BREAK -->

<a id='608daffd-b414-4f9c-8b81-a707bdd1eb2f'></a>

4a: Transit commutes correlate with income and race, though many workers in low-income neighborhoods work outside DC<::figure: A series of four choropleth maps of Washington D.C. are displayed side-by-side, each showing different demographic or commute-related data by neighborhood.

Map 1: Commute time to work via public transportation
Sub-title: % commuters traveling >45 mins
Legend:
- <20%
- 20-40%
- 40-60%
- 60-80%
- >80%
- No data (gray)
This map shows areas with higher percentages of commuters traveling over 45 minutes by public transportation concentrated in the eastern and southeastern parts of the city.

Map 2: Race
Sub-title: % Black population
Legend:
- <20%
- 20-40%
- 40-60%
- 60-80%
- >80%
- No data (gray)
This map indicates a high percentage of Black population (darkest red) in the eastern and southeastern regions of DC, aligning with areas of longer commute times. An accompanying text box states: "0.6 correlation between Black population and commute time".

Map 3: Household income
Sub-title: % income <$35K
Legend:
- <20%
- 20-40%
- 40-60%
- 60-80%
- >80%
- No data (gray)
This map illustrates areas with a high percentage of households earning less than $35K (darkest red) predominantly in the eastern and southeastern parts of the city.

Map 4: Place of work
Sub-title: % work in DC
Legend:
- <60%
- 60-70%
- 70-80%
- 80-90%
- >90%
This map shows that a higher percentage of residents work within DC (darker red) in the central and northwestern areas, while lower percentages (lighter red) are observed in some eastern and southern neighborhoods.::>

<a id='643187df-95e5-45e9-8bda-5e80d02ccd42'></a>

Source: US Census

<a id='e375b666-cf79-4389-8ea0-c90f9f844ba6'></a>

McKinsey & Company

<a id='9d47e25d-6410-4b4d-9887-9821745db45a'></a>

15

<!-- PAGE BREAK -->

<a id='390324fe-c08e-471e-b243-150b6244c16f'></a>

**4a: Swathes of low income districts are under-served by high-frequency transit**

<a id='07675f1b-a1b6-4641-a846-5d1ec748add4'></a>

Population by household income% income <$35K<::map: The map displays population by household income, specifically the percentage of income less than $35,000, across different areas of a city. Overlaid on the map are high-frequency bus lines and metro stops. The legend on the left indicates:  High-frequency bus lines²: [Light blue, elongated shapes] Metro stops³: [Yellow, circular points]  The income distribution is color-coded by area: <20%: [Lightest orange/peach] 20-40%: [Light orange] 40-60%: [Medium orange] 60-80%: [Darker orange/red] >80%: [Darkest red/maroon] No data: [Gray]  The map shows a varying distribution of income levels across the city, with concentrations of lower-income households (redder areas) and the locations of public transit infrastructure.  1. Neighborhoods where >40% of households earn <$35K per year; assumption that population in Block Groups is dispersed evenly 2. Defined as bus lines with service ~4+ times every hour (~16% of routes); this was estimated by averaging the number of buses on all DC-based routes during 3 sample hours in the day: 8-9 AM, 2-3 PM, and 5-6 PM using WMATA timetables; walking distance of ¼ mile created around bus lines 3. Walking distance of ½ mile created around metro stations::>

<a id='18710e0e-79e0-4d2e-bfff-a765653ec97f'></a>

Source: US Census; Open Data DC; WMATA District of Columbia Timetables

<a id='6c97b8a2-6930-462d-81fd-e730013999e0'></a>

Share of residents more than  mile from high-frequency buses and  mile from metro stations in low-income neighborhoods
% by selected characteristics

<a id='a7a35f9c-02df-4cd8-ab43-fa79de6aecb4'></a>

<::Race
: bar chart::>
- Latinx: 21
- Asian: 15
- Black: 39
- White: 18


<a id='bd46c041-5ae9-4f3a-801c-54b60634d94d'></a>

Occupation<::Health technologists and technicians: 50Protective service occupations: 44Installation maintenance and repair occupations: 39Community and social service occupations: 38Healthcare support occupations: 38Construction and extraction occupations: 36Personal care and service occupations: 36: bar chart::>

<a id='3f840b77-9a24-45f8-9a3b-0ab7cb9f6668'></a>

McKinsey & Company

<a id='f1edd23f-bece-49c0-a007-e6d5d32f2f7f'></a>

16

<!-- PAGE BREAK -->

<a id='7675b5e8-ebd9-4955-b1d7-4af2efdcfc4c'></a>

**4b: Southeast DC has a disproportionate share of essential workers**

<a id='296886b8-0f4e-4975-8d77-338af932466e'></a>

Neighborhoods where essential workers live¹
% share of workers
in essential industries
<::map: The map displays an area divided into numerous neighborhoods, each colored according to the percentage share of workers in essential industries. A legend indicates the color-coding for these percentages:
<30% (lightest shade of red)
30-40% (light red)
40-50% (medium red)
50-60% (dark red)
>60% (darkest shade of red)
The map shows a general trend where some central and northern areas have lower percentages, while southern and eastern areas show higher concentrations of essential workers.::>
1. Essential industries include: Construction, Educational services, Finance and insurance, Information, Health care and social assistance, Public administration, Transportation and warehousing, Utilities

<a id='6dce5b8d-04ec-4f7c-ac6e-cc854bf69681'></a>

Source: US Census; Government of the District of Columbia

<a id='99b8350e-b7a5-4fe7-af2c-89d9c77a3467'></a>

<::Neighborhoods where Healthcare support workers live¹: choropleth map::> % share of Healthcare support workers. The map displays neighborhoods colored by the percentage of healthcare support workers living there, with a legend indicating the ranges:
<3% (lightest shade)
3-6%
6-9%
9-12%
>12% (darkest shade)

An inset map highlights Southeast DC, where almost all neighborhoods are at least 80% Black (represented by dark red shades on the map).

<a id='7f8f0da3-f2dc-44d8-b4f6-8881b9fe0037'></a>

McKinsey & Company

<a id='33fb5546-9848-4ff0-b11f-a8df070eb867'></a>

17

<!-- PAGE BREAK -->

<a id='634a29dd-92a5-4af2-a71e-d7f268bd82e2'></a>

5a: Among peers, Washington DC has the highest share of cyclist fatalities

<a id='12e5c761-708a-407a-a881-3f685f9bd1c5'></a>

<::Fatalities per capita, selected large city peers, 2018. This chart displays two horizontal bar graphs side-by-side, comparing pedestrian and bicyclist fatalities per capita across several large cities in 2018. The city of Washington is highlighted in blue in both charts.

**Pedestrians, per 100K population**
| City          | Fatalities |
| :------------ | :--------- |
| Chicago       | 1.7        |
| San Francisco | 1.6        |
| Washington    | 1.6        |
| Baltimore     | 1.5        |
| New York      | 1.3        |
| Boston        | 1.3        |
| Seattle       | 1.1        |

**Bicyclists, per 1M population**
| City          | Fatalities |
| :------------ | :--------- |
| Washington    | 4.3        |
| San Francisco | 3.4        |
| Seattle       | 2.7        |
| Chicago       | 2.2        |
| New York      | 1.1        |
| Baltimore     | 0          |
| Boston        | 0          |
: bar chart::>

<a id='1d5b5c5f-6725-4c76-ba60-721c652d498b'></a>

1. Map from WUSA9 report: "These are DC, Maryland & Virginia's most dangerous roads for cyclists & pedestrians"

<a id='807fc875-7261-409f-955d-8945da388628'></a>

Source: NHTSA Traffic Safety Facts; WUSA9

<a id='c1981619-0511-405e-8a5c-b8e287a8e45c'></a>

Bicycle collisions, 2016-19¹<::A map of Washington D.C. showing bicycle collision hotspots from 2016-2019. A color legend at the top indicates collision density, ranging from 2 (lightest red) to 16 (darkest red). Major streets highlighted with collision hotspots include 22nd Street Northwest, 16th Street Northwest, 15th Street Northwest, 14th Street Northwest, 13th Street Northwest, 9th Street Northwest, 6th Street Northwest, U Street Northwest, I Street Northwest, and E Street Northwest. Some of the most dangerous roadways in DC for cyclists are along U Street NW, 14th Street NW, and Dupont Circle: map::>

<a id='f54817dd-c2b4-41f1-881b-f77c48ad24e1'></a>

McKinsey & Company

<a id='d8699734-4749-4371-9122-c41c277c8ff1'></a>

18

<!-- PAGE BREAK -->

<a id='29076ee5-3807-4adc-942e-f18134061d42'></a>

5a: While DC has one of the highest shares of bicycle commuters, it has less bike lanes than many peers
US cities by share of bike commuters (%) and bike lanes in number of miles

<a id='303345c0-219c-496f-ae20-cf59ba1b75a7'></a>

<::Table: Cities with working population >250K, their share of bicycle commuters, miles of paved public paths, miles of protected bike lanes, miles of unprotected bike lanes, miles of bike infrastructure per square mile, and state passing law. Also includes a note about Washington, DC.|||Cities with working population >250K|Share of bicycle commuters, %¹|Miles of paved public paths²|Miles of protected bike lanes²|Miles of unprotected bike lanes²|Miles of bike infrastructure per square mile²|State passing law³|||Portland|5.2|94|29|208|2.5|"Safe distance"⁴|||Washington|4|60|12⁶|72|2.3|3 feet|||San Francisco|3.8|70|31|153|5.4|3 feet|||Seattle|3.7|48|10|98|1.9|3 feet + change lanes⁴|||Boston|2.5|53|7|102|3.4|"Safe distance"⁵|||Denver|2.4|65|12|330|2.7|3 feet|||Tucson|2.3|132|6|330|2.1|3 feet|||Philadelphia|2.1|Not Reported|24|237|1.9|4 feet|||Chicago|1.5|42|86|99|1.0|3 feet|||Atlanta|1.3|42|9|47|0.7|3 feet|||Note: Washington, DC has the **2nd** highest share of bicycle commuters yet is the **15th** and **27th** city in number of miles of protected and unprotected bike lanes (of 50 large US cities)::>

<a id='70133f87-ac1b-4c80-8b59-2e9a04f47b42'></a>

1. Data from the US Census, Commuting Characteristics by Sex, by Place, 2019 ACS 1-Year Estimate
2. Data from The League of American Bicyclists, "Bicycling and Walking in the United States, 2018 Benchmarking Report"
3. Data from the National Conference of State Legislatures (NCSL) "Safely Passing Bicyclists Chart", 2020
4. Require motorist to completely change lanes when passing a bicycle if there is more than one lane in the same direction
5. A speed less than 35 mph and a "safe distance" means a distance that is sufficient to prevent contact with the person operating the bicycle if the person were to fall into the driver's lane of traffic.
6. Updated from DDOT

<a id='7e4262fc-5982-40aa-8802-c47f39360f89'></a>

Source: US Census; The League of American Bicyclists, "Bicycling and Walking in the United States, 2018 Benchmarking Report"; National Conference of State Legislatures (NCSL)

<a id='6cce7c91-4b65-4f34-9e03-8881d570ead3'></a>

McKinsey & Company

<a id='d4d58e24-c768-4af4-9f85-9c9c07d0c53f'></a>

19

<!-- PAGE BREAK -->

<a id='c519bc08-4e62-488a-bc90-2e34a0311545'></a>

5b: Walking and biking expected to increase 5% in the US post- COVID-19, and micromobility set to rise as well

<a id='84ac7d7c-2ac0-4576-a221-e139bfd46aa6'></a>

Results of wave 1 (May 9-18), wave 2 (May 27-29), wave 3 (June 16-18), wave 4 (July 15-17), and wave 5 (Sep 2-4)

<a id='c5e6089f-fa74-4c24-a1e7-2a3f84fb066b'></a>

Change of transportation modes when returning to "next normal" vs. before COVID-19¹,²
Delta of responses for return to "next normal" vs. before COVID-19 outbreak, in percent points

<a id='210e96f1-113f-451a-927a-f13a348de2be'></a>

<::Table: Bar chart showing values for different transport modes across various regions/countries.

| | Private car | Public transport | Walking or biking with private bike | Shared micromobility (e.g., e-scooter, e-bike) | Car sharing (e.g., ShareNow) | Ride hailing (e.g., Uber, Lyft, taxis) |
|---|---|---|---|---|---|---|
| Global³ | 0.5 | 0.2 | 5.2 | 1.6 | 1.4 | 1.1 |
| <img src="image_placeholder_USA_flag" alt="USA flag"> | 0.9 | -0.7 | 5.0 | 0.6 | 0.2 | 0.1 |
| <img src="image_placeholder_UK_flag" alt="UK flag"> | 0.5 | -2.7 | 8.4 | 0.9 | 0.6 | 0 |
| <img src="image_placeholder_Germany_flag" alt="Germany flag"> | -0.1 | 1.3 | 5.5 | 1.4 | 1.0 | 0.8 |
| <img src="image_placeholder_Italy_flag" alt="Italy flag"> | 0.9 | 0.3 | 6.1 | 4.1 | 2.8 | 2.9 |
| <img src="image_placeholder_France_flag" alt="France flag"> | 0.3 | 1.1 | 5.9 | 1.2 | 1.2 | 0.9 |
| <img src="image_placeholder_China_flag" alt="China flag"> | 0.7 | 2.3 | 2.1 | 4.1 | 4.0 | 3.8 |
| <img src="image_placeholder_Japan_flag" alt="Japan flag"> | 0.2 | -0.2 | 2.7 | -0.6 | -0.1 | -0.2 |
::>

<a id='65d8a220-3115-4b04-8ed4-3dcd97c9fecf'></a>

1 Q: Before/today/when you return to "next normal", how often did/do you/do you expect to use the following modes of transportation?
2. Mode usage once or more than once per week
3. US, UK, Germany, Italy, France, China, Japan

<a id='45447a32-37a8-40a0-9ca1-2eb183d0cf98'></a>

Source: McKinsey Center for Future Mobility

<a id='9c583b34-dcb1-42b5-ac60-5a4ac3f9fb52'></a>

McKinsey & Company

<a id='888d4c24-d9de-4166-8843-73daf0cb08b3'></a>

20

<!-- PAGE BREAK -->

<a id='b1513f88-e0ba-4e8f-909f-17fcd2cbe48f'></a>

Contents

<a id='92e126cc-1a21-4119-8932-868ae06d1122'></a>

Baseline Conditions

<a id='9876113a-9a4a-4d7e-8ae1-0e8e18378c91'></a>

Challenges and trends

<a id='6d5dfde4-c11c-403f-b5dc-03a3af560654'></a>

Opportunities and best practices

<a id='558a5a7e-7c7a-4f36-b2d6-1ab2f26060df'></a>

Appendix

<a id='8e513150-4065-4c09-b5c9-0b6375f68407'></a>

McKinsey & Company

<a id='7067c955-1f00-476d-9557-0638f6be34c7'></a>

21

<a id='d861dfbe-b2e2-4c1c-ac29-3f1263916fcf'></a>

Last Modified 11/3/2020 6:00 PM Eastern Standard Time

<a id='27d0b650-52ba-4e95-9fdf-44b2935a7031'></a>

Printed

<!-- PAGE BREAK -->

<a id='2e420f6a-7d83-4c03-898e-cee31193f375'></a>

Preliminary, proprietary, pre-decisional Non-exhaustive

<a id='2c9a8042-89fe-439f-b862-71f427802011'></a>

Mobility in DC: opportunities to enhance transportation and economic outcomes across DC

<a id='ae314779-3e85-40b3-a421-f3e6aa7bf24d'></a>

Deep dive in Appendix

<a id='411a0837-41c6-49ab-9046-1b721934e041'></a>

Challenge Opportunities Details Best practices
1
<::Icon: A dollar sign within a circle.
: figure::> Reaffirm commitment to transit solutions and
robust mix of mobility options A Increase **integration** and **agility** of existing networks for long-term
sustainability and financial viability
B View long-term transit health as integrated with **land use solutions** that
increase density, affordability, and access to transit <::Logos:
- BVG Jelbi logo
- minneapolis | 2040 logo
: figure::>
2
<::Icon: A road with dashed lines in the middle, represented by two parallel lines converging upwards.
: figure::> Increase **supply of mobility solutions** in connection
with **managing congestion and demand** through
pricing C Adopt mobility solutions based on **dynamic pricing**
D Invest in streetscape to support **walking, cycling-, and micro-mobility**
E Develop **employer-back** transit solutions <::Logos:
- MINISTRY OF TRANSPORT CONNECTING SINGAPORE logo
- PARIS logo
- Seattle Office of Labor Standards logo
: figure::>
3
<::Icon: Three stacked boxes or buildings.
: figure::> Adopt new **regulations, uses,** and **pricing** scheme F Dynamically **price** on-street parking to reduce congestion and raise
revenues
G Facilitate **technological** solutions to improve **delivery management** <::Logos:
- LA Express Park logo
- STARSHIP logo
: figure::>
4
<::Icon: Two stylized human figures, one larger and one smaller, representing a family or community.
: figure::> Close **equity gaps** through **new mobility options**
(e.g., microtransit) and target traditional fixed-route
**high-frequency routes** targeting transit “deserts” H Provide **subsidies** for low-income residents for transit usage
I Leverage **microtransit** or **ride-sharing partnerships** for new routes
J Review and redesign traditional **fixed-route high-frequency** routes
targeting **underserved communities** <::Logos:
- orca LIFT logo
- VIA logo
- GO BOSTON 2030 logo
: figure::>
5
<::Icon: A bicycle.
: figure::> Adopt comprehensive **Vision Zero** goals to enhance
safety outcomes K Fastrack **Vision Zero** initiatives (e.g., District-wide reduction of speed
limits, streetscape redesigns) <::Logos:
- Stockholms stad logo
: figure::> 

<a id='97efce53-e502-4138-8e34-18eb9b82dca3'></a>

McKinsey & Company

<a id='af5c21de-acc6-45a9-a572-6c3741967a42'></a>

22

<!-- PAGE BREAK -->

<a id='6f3ba2f2-c805-4d4a-a980-68e99a0a3673'></a>

<::logo: Jelbi
BVG Jelbi
The logo features a yellow heart with "BVG" inside, next to the word "Jelbi" in black sans-serif font.::>

<a id='d7feb6ad-6478-42d3-955d-89a3dac82fd3'></a>

1a: Increase integration and agility of existing networks for long-term sustainability and financial viability
---


<a id='72d4535e-56f0-427f-a685-90dfd26110b4'></a>

Description

* Develop multimodal system that integrates public transit, rideshare, micromobility
* Streamline multimodal transit usage through one-app booking and payments (e.g. Denver residents can use Uber's app to purchase tickets for the local bus and train transit system, RTD)
* Call on regional transit providers (WMATA, MARC, VRE, Circulator) to improve regional integration (e.g., coordinated schedules, increased Union Station capacity and frequency, fare integration, free transfers) and expand nights / weekend service for key residential and employment zones

<a id='66f993bd-6e62-426c-a334-6aca80c23add'></a>

<::logo: RTD and Uber
RTD
Uber
Two logos are displayed, one with white text "RTD" on a red background and another with white text "Uber" on a black background, set against a blurred cityscape at night::>

<a id='0a0d6422-fcbb-4f7c-aa05-3ab3a0d1bddf'></a>

Case example

Berlin

*   In 2019, Berlin introduced a Mobility as a Service (MaaS) app called Jelbi, in partnership with mobility platform Trafi
*   Goal of Berlin public transport authority BVG's smart mobility strategy to connect every shared mobility offer in the German capital into a single marketplace for its residents to provide an attractive alternative to private cars
*   Jelbi integrates all public and shared mobility options, including bike sharing, taxis, carpooling, and public transportation
*   Allows Berliners to register one time for all existing and to-be-integrated mobility services, receive messages from transit (e.g. regarding closures or safety), plan intermodal trips (lowest time, cost), receive real time public transport information, and buy any type of ticket (no need to switch between apps)
*   Employers can provide employee travel allowances on the app

Impact:

*   In the first year of Jelbi:
    *   ~5% of Berliners have used Jelbi
    *   15,500+ vehicles available
    *   51% public transport
    *   49% share mobility

<::Mobile phone screen showing the Jelbi app interface.

Top bar with back arrow and 'Where to?' title.

Input fields for 'Potsdamer Platz' and 'Alexander Platz' with an up/down arrow icon between them.

'Leave now?' with a clock icon.

Below this, a list of mobility options with travel times and prices:

*   Icon with 'U U2' and a star: 18 min, €2.90 (09:41-10:01)
*   Icon with a star: 21 min, €4.99 (09:41-10:02)
*   Icon with 'M 1' and a star: 23 min, €1.00 (09:41-10:03)
*   Icon with a star: 23 min, €4.80 (09:41-10:04)
*   Icon with 'M 1' and a star: 19 min, €2.30 (09:41-10:00)
*   Icon with 'VW Polo' and a star: 22 min, €4.12 (09:41-10:03)
: figure::>

<a id='78cf0119-128f-43a1-be06-d1c1bde9a51b'></a>

Source: The Verge; Unsense; BVG Jelbi website

<a id='f56aebb6-b15c-41d2-8765-38009844655b'></a>

McKinsey & Company
McKinsey & Company

<a id='8a859f90-7882-4343-86b7-1bcc7cedf85f'></a>

23

<!-- PAGE BREAK -->

<a id='ef1c625e-a08b-49a0-9a69-50c78c1d67d3'></a>

1b: View long-term transit health as integrated with land use solutions that increase density, affordability, and access to transit

<a id='9bdf4d3a-d864-453f-87f1-5efbe7bd3974'></a>

<::minneapolis | 2040
: figure::>

<a id='b8b09dea-0439-4eac-880f-3bc960b8fc4c'></a>

# Description
*   Cities and states such as Minneapolis, Austin, Seattle, Montgomery County MD, Oregon, and more have recently begun implementing changes to land use policy to encourage housing affordability
*   20% of the District's surface area is occupied by single-family units, which increases to 48% of all land not occupied by the federal government (or National Park Service)
*   The District could consider targeted land-use measures near transit to incentivize more housing density and affordability

<a id='abe19385-6345-4a25-bd3b-93e04b3ab8e6'></a>

## Case example

### Minneapolis

- In October 2019, Minneapolis became the first city in the U.S. to eliminate single-family zoning

<::Minneapolis skyline at dusk, showing city buildings, a river, and bridges with illuminated lights
: figure::>

- As part of the Minneapolis 2040 comprehensive plan for the city, a package of further reforms includes:
  - Encouraging further density near transit stops
  - Eliminating off-street minimum parking requirements
  - Requiring new developments set aside units for low- and moderate-income households ("inclusionary zoning")
  - Increasing funding for affordable housing
- Before the 2040 Plan, Minneapolis made incremental steps to increasing housing affordability, such as in 2014 expanding the availability of "Accessory Dwelling Units" (ADUs)

<::A color-coded map of Minneapolis showing primary zoning districts, with a legend on the right side indicating different zoning types like R1, R1A, R2, R2B, OR1, OR2, OR3, C1, C2, C3A, C3, C4, C5, C6, I1, I2, I3, B1, B2, B3, BAC-1, BAC-2, BAC-3, S-1, U1, U2, N, O, and W. The map displays a dense urban core with various colors, surrounded by less dense areas.
: figure::>

### Impact:

- Region-wide goal of 37,900 newly constructed affordable housing units between 2021 and 2030
- ~$10M per year from the City budget to an Affordable Housing Trust Fund providing competitive low/no interest deferred loans
- ~$50M per year in Low Income Housing Tax Credits

<a id='0b16670c-f62c-4302-bdda-d46a91069265'></a>

Source: Minneapolis 2040; The Century Foundation; D.C. Policy Center

<a id='4edbf54c-9a67-4e0e-9197-324142c1081c'></a>

McKinsey & Company
McKinsey & Company

<a id='fc0fa456-a134-4fdf-a55d-6c7980e8f914'></a>

24

<!-- PAGE BREAK -->

<a id='db86799b-fdf3-4dfc-90fb-410db80219be'></a>

**2c: Adopt mobility solutions based on dynamic pricing (e.g., congestion pricing)**---

<a id='32aad0fa-a675-4121-be01-7136fde615dc'></a>

<::logo: Ministry of Transport
MINISTRY OF TRANSPORT
CONNECTING SINGAPORE
This logo features an abstract, intertwined loop design in shades of blue and green.::>

<a id='bf8fb6f2-65d6-4308-b112-562fab7430b1'></a>

## Description
*   Charging for use of roads in an effort to reduce congestion and carbon emissions, increase safety, and generate revenue that can be reinvested into transit infrastructure

## Congestion pricing:
*   System can be cordon fee (e.g., charge to pass a cordon line around city center), area-wide, or corridor/facility specific
*   May include a variable pricing scheme to respond to congestion (using algorithms to determine optimal price and time and transmitting this information to road screens or apps)
*   Requires similar infrastructure as current road tolling (cameras, sensors, and electronic transponder devices for vehicles)

## Revenue generation:
*   Potential to endow the city with a sustainable infrastructure bank
*   Net annual revenue is USD $182M in London, $155M in Stockholm, and $100M in Singapore

<a id='d7bdef96-9bb6-4b40-a121-0e46a48ec72f'></a>

Case example

**Singapore Electronic Road Pricing (ERP)**
*   Singapore launched ERP in 1998 to reduce congestion and improve journey time reliability for car users
*   It is an electronic toll collection system with open road tolling, now (as of 2020) using satellite technology instead of cameras and gantries to charge vehicles

<::A road gantry with a "4.5m" height limit sign and "ERP" written on it.
: figure::>

*   It uses variable pricing designed to respond to congestion in real-time (charges depend on type of vehicle, congestion, time, and distance travelled)
*   In conjunction with ERP, Singapore doubled parking fees within the restriction zone, established park-and-ride facilities outside the zone, increased bus frequency, and established HOV lanes
*   Hours are 7 AM-8 PM Monday to Saturday
*   Initial investment: $110M USD
*   Annual operating cost: $18.5M USD
*   Annual net revenue: $100M USD

**Impact:**
*   Reduced traffic in the inner city by 24% and increased average speeds from 18-22 to 24-28 MPH
*   Public transit improvements (expanded bus, rail, biking and pedestrian network), and bus and train ridership has increased by 15%
*   Levels of CO2 and other greenhouse gas emissions have been reduced by 10-15%

<a id='71bd76ab-8c21-4937-8f71-f1cbaf4a6a40'></a>

Source: The Straits Times; Tri-State Transportation Campaign, "ROAD PRICING IN LONDON, STOCKHOLM AND SINGAPORE: A WAY FORWARD FOR NEW YORK CITY"

<a id='7c1de12d-27d9-4b24-bfad-71f1f862696f'></a>

McKinsey & Company McKinsey & Company

<a id='68382b1c-86d0-4dcd-841d-5ace6ac663bf'></a>

25

<!-- PAGE BREAK -->

<a id='67d709ab-e244-431b-aac8-215e0347838b'></a>

2d: Invest in streetscape to support walking, cycling-, and micro-mobility

<a id='06ff4f11-9867-4e62-8b99-edec76144186'></a>

<::logo: PARIS
PARIS
A stylized dark blue sailboat icon is positioned to the left of the brand name "PARIS", which is also in dark blue, sans-serif font::>

<a id='9574a2e0-a4e4-4023-9d79-de7d7ce0acbe'></a>

## Description
*   Increase number and mileage of dedicated bike lanes, especially in neighborhoods and around key amenities (e.g. grocery stores)
*   Create additional mixed-use transit-and-micromobility corridors along key arteries, e.g., bus rapid transit (BRT) lanes and non-traditional vehicle "mobility corridors" for bikes, ride-sharing pools, and scooters
*   Allow for year-round, permanent parklet usage by restaurants (e.g., New York)
*   Improve walkability and neighborhood amenities through more car-free zones, plazas, and more Great Streets east of the river
*   Expand dockless bicycle and scooter parking and charging infrastructure

<a id='fa62715a-daa4-4b7c-916a-cbb81c5107fb'></a>

Case example Paris has been undergoing a transformation to make the city less congested and more walking- and cycling-friendly. The plan to make Paris a “15-minute city,” where a resident’s needs are a short walk away, includes: - Pedestrianization of the highways along the Seine’s riverbanks - Car-free first Sunday of each month in 10 congested areas of the city - Expansion of the city’s bike-share program Vélib’ - €350m (£300m) plan to create “a bike lane in every street” by 2024 - Plan to do away with 60,000 parking spaces for private cars - Free public transit for kids under eleven and senior citizens - Banned cars near schools when kids are arriving and leaving to make it safe for children to walk and bike - In response to COVID-19, temporary pedestrianized streets and 30 additional miles of dedicated bike lanes <::illustration: Diagram titled “LE PARIS DU 1/4 HEURE” (Paris in 1/4 hour) with a “PARIS EN COMMUN” logo. The diagram depicts a circular concept of a “15-minute city” with “CHEZ MOI” (My Home) at the center. Around the center, various activities are shown, each connected by arrows labeled “15mn” (15 minutes), indicating they are a short walk or bike ride away. The activities illustrated are: - BIEN MANGER (Eat Well): People at a market. - APPRENDRE (Learn): A school or library building. - TRAVAILLER (Work): People collaborating at tables. - PARTAGER ET RÉEMPLOYER (Share and Reuse): People exchanging items. - SE DÉPENSER (Exercise): People running and cycling. - CIRCULER (Move around): People walking and biking. - SE SOIGNER (Care for oneself): A medical clinic. - SE CULTIVER, S'ENGAGER (Cultivate oneself, Get involved): People reading and discussing. - S'AÉRER (Get fresh air): People in a park with trees. - S'APPROVISIONNER (Stock up): A shop. The diagram visually represents the idea that all essential needs and activities are accessible within a 15-minute radius from one's home.::>

<a id='10824cb8-0fa1-49fb-b5c8-8b6288b54800'></a>

**Impact:**
* Vehicular traffic has decreased by 20 percent in the last five years
* The number of cyclists has grown 54% in 2019
* City has reached 620 total miles of cycle paths in 2019, nearing its goal of 870 miles

<a id='f21cc9ef-de30-491a-b214-d268207942db'></a>

<::A photo shows people on a bridge in Paris with the Eiffel Tower in the background. In the foreground, a person on a red scooter, wearing a white helmet and face mask, is blurred due to motion. Behind them, another person, also wearing a mask, is partially visible. To the right, a woman in a white shirt and yellow pants, wearing a face mask, rides a green bicycle. The bridge railing is ornate and green with golden accents. The Eiffel Tower is clearly visible in the distance under a partly cloudy sky.: figure::>

<a id='a1f2dc41-bdc6-4007-a4f3-665f3dca82d8'></a>

Source: World Economic Forum; BBC; Ubique; Fast Company

<a id='eafa41be-b865-46cc-b472-b9c3606a58a0'></a>

McKinsey & Company
McKinsey & Company

<a id='a49a5a9a-0a76-4e13-9dd3-507b9cb4f822'></a>

26

<!-- PAGE BREAK -->

<a id='b75c5fc9-aa91-40d0-b4c0-b0a52f59068d'></a>

3f: Dynamically price on-street parking to reduce congestion and raise revenues

<a id='b7c39ff6-3d77-4b64-aa42-dd08000755dc'></a>

<::logo: LA Express Park
LA Express Park™
save time, park smarter.™
This logo features a stylized blue and white 'p' within a circular element, accompanied by the brand name and a tagline.::>

<a id='71a6b4f8-acdd-45ce-8716-3fee3ddd644b'></a>

## Description

*What is it?*

A system of sensors that detect open parking spaces and make them visible to citizens looking for parking spaces via mobile applications or vehicle navigation systems, reducing time spent looking for parking; dynamic pricing helps shape demand to meet occupancy goals. Systems may also use analytics to predict future parking availability

<a id='e10176fb-c1dd-4203-8b88-7de54be11f13'></a>

_What is the city's role?_
Buy and implement (or partner with third party to implement) smart parking sensors, meters, and applications; encourage privately owned garages and lots to implement parking guidance systems through subsidies or regulation; offer parking availability and pricing data for third parties to leverage

<a id='399b8ee3-b7e3-4093-a0ff-cd1438e0cd8c'></a>

## Case example
**Los Angeles:** The Los Angeles smart parking program leveraged multiple sensors to provide real-time parking spaces through a mobile app. The smart parking application started as a pilot around 4.5 square miles on the downtown area in 2012

<a id='80a2cd5a-0392-41a8-84fb-9681f8bb6a49'></a>

**Features and approach:**The application uses parking sensors, dynamic pricing that reacts to demand, a parking guidance system and a mobile app that supplies real-time information about parking availability

<a id='f2da5bb2-57e8-4bb0-8e06-90ad2e2845aa'></a>

The app provides support for mobile payments, current rate, payment methods, voice guidance to
parking spots and spaces available with the option to filter parking searches by permit type

<a id='8c2cdf11-b63f-4a71-b24a-e355ef0d5676'></a>

Reservations can be made on a daily or monthly basis

<a id='9de0fd17-6717-45b0-a125-c352704e50e6'></a>

The information helps LA DOT to set enforcement priorities to ensure compliance. All transactions are recorded and then used to optimize operations

AT&T LTE 9:56 AM 75%

<a id='54ba1b5a-e1eb-439a-b7c0-0fbe8250fbfc'></a>

**Operations and cost:**
LA Express Park was founded by grants from the US DOT and the city (~$18M in total). The LA DOT manages the program. The smart parking application uses the parking sensors from Street Line company, and Xerox has helped develop a highly integrated advanced pricing engine

<a id='15aed2ec-404f-49cb-abba-8c1169cf9472'></a>

••••• AT&T LTE 9:56 AM 75%
Q Current Map Area
<::Map interface displaying a street map with various businesses and parking availability. A search bar at the top reads "Current Map Area". A navigation pop-up is visible on the map, centered, displaying "1000 S WESTWOOD..." with a "Navigate" button to its left and an info icon to its right. The map shows streets like Gayley Ave, Westwood Blvd, and Lindbrook Dr. Numerous "$2" parking icons are scattered across the map, some associated with green lines (available parking), and some with red or orange lines (potentially restricted or paid parking). Businesses visible include Chipotle Mexican Grill, Fatburger, Native Foods Cafe, TLT Food, 800 Degrees Neapolitan Pizzer, The Boiling Cr, Victoria's, Urban Cloth. At the bottom of the screen, a control panel is present:
1 Hour. Starting Now
A slider control allows selection between "DAILY", "RESERVE", "MONTHLY", and "STREET". The "STREET" option is currently selected, indicated by a shopping cart/parking meter icon.
: map interface::>


<a id='4dc292b3-f609-441b-accf-a16d395bd057'></a>

<::A silver and black parking meter is shown, featuring a large 'P' logo in a blue circle on the side. Various payment card logos (Visa, Mastercard, Discover, American Express) are visible near a card slot. The meter has a digital display and buttons on the top panel, and a slot for tickets or receipts. Text on the meter includes "www.passportparking.com" and "Apple Pay, Google Pay, and more!" It is positioned on a sidewalk next to a street, with a car and a wall in the background.
: photo::>

<a id='5e4ddd29-e407-4056-9993-dfd1810e99b0'></a>

<::logo: LADOT, Park Smarter
PAY BY APP
LADOT
PARK SMARTER
A rectangular logo with an orange background on the left and a teal background on the right, featuring a QR code, a smartphone icon, and text in white.::>

<a id='d96f40c7-063f-4c3f-af26-e5e09fd11b0d'></a>

Source: Laexpresspark.org; McKinsey Global Institute team analysis

<a id='66108eb0-3446-4e2d-9d7a-206d3064d9ad'></a>

McKinsey & Company McKinsey & Company

<a id='b06d3726-66cc-43fa-93da-1bad0f385b32'></a>

27

<!-- PAGE BREAK -->

<a id='c4f10bc7-72e0-440d-bfba-4da0665a4ea3'></a>

4h: Provide subsidies for low-income residents for transit

<a id='11ceaeed-0fde-4a9e-8e5c-9efb7a40e8d9'></a>

<::logo: Seattle
Seattle
The logo features a blue circular icon with a stylized profile of a face facing left, accompanied by the bold black text "Seattle".::>

<a id='8bbba1ae-2e24-47e2-8774-2e31faf28ab6'></a>

**usage**

<a id='6d504a2b-ad56-40ad-a521-d847e1ab0157'></a>

# Description
The District already provides some transit subsidies through a number of sources:

The "Kids Ride Free" program allows students to ride MetroBus, Metrorail, and the DC Circulator for free within the District

SmartBenefits allows employers to offer tax-free commuting to employees – with no fee to employees

The Transportation Benefits Equity Amendment requires companies in the District that offer employees free or subsidized parking to also offer subsidized

<a id='b49db410-2db8-4b99-8621-df2c5ce4dca0'></a>

The District could consider addressing equity concerns by expanding existing subsidies and providing additional subsidies for low-income residents¹

<a id='741caada-2566-465d-aa75-7d42f532333f'></a>

Revenue sources for this program could come from other initiatives, such as dynamic pricing on certain roads or a cordon fee

<a id='66e6f393-fe0f-4e0f-b00c-abb493218a67'></a>

## Case example
Seattle: "King County Metro has long offered discounted fares to make transit service more affordable and accessible. In addition to existing programs for youth, seniors, and disabled riders, Metro recently expanded the Human Services Ticket Program and introduced the ORCA LIFT low-income fare in 2015."

<a id='ea15a9c2-bcaa-4575-aeca-5fc2dd90e798'></a>

According to King Country Metro, "The ORCA LIFT program offers a reduced transit fare for people with incomes at or below 200% of the federal poverty level. Enrollment is available at locations across King County and partner agencies like King County Public Health verify income of participants through existing benefits programs like Apple Health, Social Security and Employment Security.

<a id='bde187c9-df45-4ced-9408-fcf10a950205'></a>

Metro reached out to the public in spring 2017 to develop recommendations for simplifying fares. We created a stakeholder advisory group, briefed and interviewed interested groups, and gathered two rounds of public feedback. This led the Executive to propose a simplified fare structure of a flat fare of $2.75 at all times, regardless of time or distance, which was adopted by King County Council and took effect in summer 2017."

<a id='0090b636-dcf3-4d1d-bdb1-f52fd0506d51'></a>

<::An image showing two distinct parts. On the left, a blue ORCA card is displayed with the text "orca one regional card for all" and numbers "12345678" and "321". The card has colorful wavy lines across it. From the card, an arrow diagram extends to the right, listing various transportation methods it can be used for: STREET CAR (with a streetcar icon), BUS (with a bus icon), LINK LIGHT RAIL (with a light rail icon), SOUNDER TRAIN (with a train icon), WATER TAXI (with a water taxi icon), STATE FERRY (with a ferry icon), and FAST FERRY (with a fast ferry icon). On the right, a photograph shows a person, partially visible and in motion, wearing a red and black jacket, tapping or swiping a card on a fare reader device inside what appears to be a bus or similar vehicle. The driver's seat and dashboard controls are visible in the foreground.: figure::>

<a id='08dd1695-e8b6-45c9-bb95-a038f46550b7'></a>

<::logo: ORCA LIFT
orca LIFT
Reduced Fare.
Increased Possibilities.
A blue circular logo with a white stylized orca whale above the word "orca" and a bus image in the background.::>

<a id='235d04ba-5c10-44ac-b80d-0d7117ba8bdc'></a>

1. Proposals for such a program do exist, such as Councilmember Allen's proposal to provide a $100 monthly transit subsidy to every DC resident

<a id='1dfdff02-8789-4da7-b9c2-d973e06297a2'></a>

Source: DDOT; WMATA; DC Council; King County

<a id='111e2395-abf4-49ab-b02a-3a3f8677a160'></a>

McKinsey & Company
McKinsey & Company

<a id='c0375852-296c-41b3-8fed-3c2db2af264e'></a>

28

<a id='c0667497-15c4-448c-941e-c914edc6365c'></a>

--- --- --- --- --- ---
transit fare

<!-- PAGE BREAK -->

<a id='213af6f4-933b-46ef-a6ca-71f995dd8c10'></a>

<::logo: Stockholms stad
Stockholms stad
The logo features a black shield with a stylized head wearing a crown, next to the words "Stockholms stad" in black text.::>

<a id='07eb8ec0-b742-4264-8f9f-651b22830038'></a>

**5k: Fastrack Vision Zero initiatives**

<a id='e16e977e-248d-4c57-9b78-7b4f59f0ec15'></a>

## Description

* Fastrack DC Vision Zero safety efforts by redesigning streets and sidewalks to prioritize and protect pedestrians and cyclists
* Develop connected network of cycling and pedestrian infrastructure, and prioritize junctions with high numbers of accidents (through visibility, predictability and speed reduction)
* Entice more residents to cycle, which is proven to increase safety (e.g., survey bike commuters and DC residents to determine what would encourage them to cycle more, such as additional protected bike lanes, more bike parking infrastructure, slower driving speeds, etc.)
* Strengthen enforcement for 20 mph speed limit on DC roads (e.g., traffic enforcement cameras as in NYC)
* Reduce the volume of motorized traffic, especially during peak times (e.g., through use of congestion charge)

<a id='6699b9dc-5ab7-4ee9-995b-427752eeac92'></a>

Case example

**Stockholm Vision Zero Project**
*   Systems approach to safety: core responsibility for accidents on the overall system design (rather than only faulting drivers)
*   Transport infrastructure redesign to eliminate fatalities and serious injuries
*   The project includes multiple sub-initiatives such as:
    *   Rebuilt intersections: built tighter roundabout focused in slowing speeds which reduced death rate by 90%
    *   Road design: safer cross-walks: Bumps, road narrowing, chicanes, etc. mainly in urban areas

<::A group of people cycling and walking on a pedestrian crossing in an urban area with buildings in the background.
: figure::>

*   Vision Zero 2.0: integrate health benefits of more people walking and cycling

**Impact:**
*   56% of Stockholm residents commute via public transport, cycling, or walking

<::A tree-lined avenue with people walking, suggesting a park or green space.
: figure::>

*   Sweden has one of the lowest annual rates of road deaths in the world (3 out of 100,000 as compared to 12.3 in the United States)
*   Fatalities involving pedestrians have fallen almost 50% in the last five years

<a id='c3d9cfed-9a6e-42c6-a736-e2b273952b77'></a>

Source: Stockholm Civitas Database; Center for Active Design; DDOT; International Transport Forum

<a id='b8d84c42-7f89-4bee-b730-0529c1287f38'></a>

McKinsey & Company McKinsey & Company

<a id='f7000f6c-64f2-4190-8c2c-231d25f177e9'></a>

29

<!-- PAGE BREAK -->

<a id='7d53f808-0646-4451-92b5-497a00c34d70'></a>

Contents

<a id='6d5b94e7-25d9-43da-acca-4769fabea333'></a>

Baseline Conditions

<a id='d7f6a4ab-5a86-4e35-9364-1a192471dabd'></a>

Challenges and trends

<a id='384cbc0f-6f7f-4872-96bb-7b1066693d24'></a>

Opportunities and best practices

<a id='f0790eb7-fde4-4780-941e-345ab2fdb02e'></a>

Appendix

<a id='ef4faee9-4e61-4c0c-80ea-bc5ee35f835c'></a>

McKinsey & Company

<a id='cd6d79c8-a395-49a6-ba93-43c5959f77b1'></a>

30

<a id='e6e1de11-d285-4911-9655-34fc0a691e87'></a>

Last Modified: 9/13/2020 6:20 PM Eastern Standard Time

<a id='3098d83c-f975-4b8d-a3fc-019051b86e8f'></a>

Printed

<!-- PAGE BREAK -->

<a id='2c73c0e2-5721-49d6-a0c5-4ac126714c83'></a>

Transportation and warehousing is a relatively small sector with low specialization
GDP, growth, and specialization by major industry

<a id='4a528d2a-ccc8-4aba-8dbc-10cad980104f'></a>

option Focus of this document: [x]
option Analyses by other firms: [ ]

<::
: table::
| Sector                                                      | Included in sector analysis | Size               | Growth                     | Specialization |
|:------------------------------------------------------------|:----------------------------|:-------------------|:---------------------------|:---------------|
|                                                             |                             | GDP, Mil., 2019¹   | CAGR, 2014-19, %   | CAGR, 2019-24, %² | GDP LQ³        |
| Government and government enterprises                       | option : [x]                | 40,721             | 1%                 | 2%                  | 2.8            |
| Professional, scientific, and technical services            | option : [x]                | 26,407             | 2%                 | 3%                  | 2.7            |
| Real estate and rental and leasing                          | option : [x]                | 9,623              | -1%                | 2%                  | 0.6            |
| Information                                                 |                             | 9,246              | 9%                 | 3%                  | 1.1            |
| Other services (except government and government enterprises)⁴ |                             | 8,479              | 2%                 | 0%                  | 3.5            |
| Health care and social assistance                           | option : [x]                | 5,916              | 2%                 | 0%                  | 0.6            |
| Finance and insurance                                       |                             | 4,520              | 2%                 | 1%                  | 0.6            |
| Accommodation and food services                             | option : [x]                | 4,193              | 2%                 | 0%                  | 1.2            |
| Educational services                                        | option : [x]                | 4,086              | 0%                 | 3%                  | 2.8            |
| Admin. and support and waste management and remediation services |                             | 3,140              | 0%                 | 0%                  | 0.8            |
| Retail trade                                                | option : [x]                | 1,645              | 4%                 | 4%                  | 0.2            |
| Wholesale trade                                             |                             | 1,254              | 2%                 | 4%                  | 0.2            |
| Construction                                                |                             | 1,248              | -1%                | 1%                  | 0.3            |
| Utilities                                                   |                             | 1,222              | 3%                 | 1%                  | 0.7            |
| Arts, entertainment, and recreation                         | option : [x]                | 1,164              | 4%                 | 3%                  | 0.9            |
| Management of companies and enterprises                     |                             | 930                | 7%                 | 7%                  | 0.3            |
| Transportation and warehousing                              | option : [x]                | 341                | -2%                | 3%                  | 0.1            |
| Manufacturing                                               |                             | 273                | 6%                 | 2%                  | 0.0            |
| Total                                                       |                             | 123,929            | 2%                 | 2%                  | 1.0            |
::>

<a id='c34ba94e-6099-4d01-8f65-521810c5a295'></a>

1 Full-time and part-time; Real GDP chained to 2012 USD; Removed Mining, quarrying, and oil and gas extraction sector due to lack of data; Sector GDP may not add up 100% due to data suppression and real GDP calculations;
2 Forecasts from Moody's Analytics; 3 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole; 4 Other services is an especially large sector in DC as it includes NGOs and other institutions

<a id='89ff4f25-4315-45b2-aef7-de5b9812f6ca'></a>

Source: Bureau of Economic Analysis (BEA), SAGDP9N Real GDP by state by NAICS industry; Moody's Analytics

<a id='56c5f93d-db3f-402a-8241-59fd3dc84f78'></a>

McKinsey & Company

<a id='7b5ebb73-dfdc-4b38-b36f-d85db1e8df81'></a>

31

<!-- PAGE BREAK -->

<a id='58f665d4-ad4a-4dd7-b15d-a955d2a04c2c'></a>

Transit and ground passenger transportation is the largest contributor to output in DC
GDP, growth, and specialization by subsector

<a id='6b3d307c-eae8-47eb-bc5d-6b4c434f60d6'></a>

<::
| Subsector | Size GDP, Mil., 2019^1 | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %^2 | Specialization GDP LQ^3 |
|---|---|---|---|---|
| Transit and ground passenger transportation^4 | 165 | 4% | 1% | 0.5 |
| Other transportation and support activities^5 | 103 | 3% | 7% | 0.2 |
| Rail transportation | 36 | -18% | 1% | 0.1 |
| Air transportation | 20 | -14% | 3% | 0.0 |
| Truck transportation | 10 | -4% | 5% | 0.0 |
| Water transportation | 3 | 1% | 5% | 0.0 |
| Warehousing and storage | 3 | 0% | 11% | 0.0 |
| Pipeline transportation | 3 | -23% | 8% | 0.0 |
| Transportation and warehousing (total) | 341 | -2% | 3% | 0.1 |
: table::>

<a id='6a1e7e60-462b-445e-98ce-816915054cac'></a>

1. Full-time and part-time; Real GDP chained to 2012 USD; Subsector GDP may not add up 100% due to data suppression and real GDP calculations
2. Forecasts from Moody's Analytics
3. Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole
4. Includes transit networks such as WMATA and rideshare such as Uber and Lyft, etc.
5. Other Transportation and Support Activities includes scenic and sightseeing transportation, couriers and messengers, and support activities for transportation (BEA does not have separate data for them)

<a id='80c1c9a4-aa4b-415d-ab00-f7ffda6cd92f'></a>

Source: Bureau of Economic Analysis (BEA), SAGDP9N Real GDP by state by NAICS industry; Moody's Analytics

<a id='411f9483-8f1c-42cb-8596-ab9dacf54bbd'></a>

McKinsey & Company

<a id='d5750a09-a1dc-435e-b423-9a7e42c37549'></a>

32

<!-- PAGE BREAK -->

<a id='c5d6070a-1ecc-4534-a7ad-15a7b544f4e9'></a>

Current as of August 5, 2020

<a id='c58875c3-b0b2-479c-b9e4-8ba093f85eb3'></a>

1: DC's most vulnerable jobs are concentrated in sectors with the
lowest wages and lowest educational attainment
Number of vulnerable jobs in DC

<a id='0ff6c5d7-009f-4ba5-ab10-bc717623e89f'></a>

Preliminary, proprietary, pre-decisional
<::A bubble chart titled "Median earnings in industry, '000" displays various industries. The y-axis ranges from 10 to 100, representing median earnings in thousands. The x-axis ranges from 0 to 65. Each bubble represents an industry, with its size indicating the number of employees in thousands (K) and its vertical position indicating median earnings.

Data points are as follows:
- Professional services: 29K employees, median earnings around 95K (x-pos ~30)
- Government: 11K employees, median earnings around 87K (x-pos ~7)
- Information: 4K employees, median earnings around 80K (x-pos ~20)
- Finance: 5K employees, median earnings around 80K (x-pos ~27)
- Management: 1K employees, median earnings around 80K (x-pos ~32)
- Utilities: 1K employees, median earnings around 78K (x-pos ~30)
- Religious & Civic: 23K employees, median earnings around 75K (x-pos ~37)
- Mining: 0K employees, median earnings around 75K (x-pos ~57)
- Education: 21K employees, median earnings around 70K (x-pos ~37)
- Wholesale: 2K employees, median earnings around 68K (x-pos ~40)
- Construction: 7K employees, median earnings around 67K (x-pos ~47)
- Real Estate: 5K employees, median earnings around 58K (x-pos ~48)
- Healthcare: 12K employees, median earnings around 55K (x-pos ~18)
- Manufacturing: 0K employees, median earnings around 55K (x-pos ~30)
- Repair & maintenance: 0K employees, median earnings around 47K (x-pos ~28)
- Administrative: 17K employees, median earnings around 45K (x-pos ~38)
- Forestry and Logging: 0K employees, median earnings around 40K (x-pos ~28)
- Transportation: 2K employees, median earnings around 50K (x-pos ~57, highlighted in red)
- Retail: 11K employees, median earnings around 35K (x-pos ~55)
: bubble chart::>

<a id='eda112d2-5f54-43d3-bf21-725f247318d7'></a>

<::bubble chart: Total jobs at risk in DC 52.6K. The chart includes a legend for 'Number of jobs vulnerable' where circle size indicates quantity (e.g., a grey circle represents 10K). Another legend indicates '% of jobs in industry requiring a bachelors degree' by color: black for >40%, dark blue for 20-40%, and light blue for <20%. The chart displays: personal services with a light blue circle representing 6K jobs; Arts, entertainment, & rec with a dark blue circle representing 8K jobs; and Accomm. & food service with a large light blue circle representing 62K jobs.::>

<a id='07a60dbc-15cc-4d9e-a547-aed3314220d5'></a>

<::85 90 95 100
% of jobs in industry vulnerable
: chart::>

<a id='d49f2c37-e3fb-4b5a-ab7c-c9e888f9944f'></a>

Note: Vulnerable jobs are those predicted to be furloughed, laid-off, or otherwise unproductive (e.g., kept on payroll but not working) during periods of high social distancing

<a id='eb2a27da-3e64-4e76-8eaf-4e2e968dcb9a'></a>

Source: MGI Economics analysis based on scenarios generated by McKinsey in partnership with Oxford Economics, input from Moody's Analytics data

<a id='fee9373e-83dc-425e-8257-c5ce44926edc'></a>

McKinsey & Company

<a id='7bf11aa9-4444-46d5-bfc8-1510943cc404'></a>

33

<a id='11e2aaa8-d054-4b71-a7cf-d1b28f5315ce'></a>

<::
70   75   80
: figure::>

<!-- PAGE BREAK -->

<a id='a869f284-c177-4d41-8057-57e78e6dc27c'></a>

**DC's GDP can be expected to decline by 6.4% in 2020**
Real GDP, indexed to 2019 Q4

<a id='ee6978a8-fdbc-45a8-a76a-4d4274fe8720'></a>

Preliminary, proprietary, pre-decisional
Real GDP Impacts of COVID-19 Crisis
Indexed to 2019 Q4 = 100
<::A line chart titled "Real GDP Impacts of COVID-19 Crisis", indexed to 2019 Q4 = 100.
Legend:
- History (light gray line)
- Pessimistic scenario (dark blue line)

The y-axis ranges from 85 to 110, with major ticks at 85, 90, 95, 100, 105, 110.
The x-axis shows quarters from 2019Q4 to 2023Q4.

The "History" line starts around 98 in early 2019Q4, rises to 100 by late 2019Q4, and then remains flat at 100.
The "Pessimistic scenario" line starts at 100 in 2019Q4, drops sharply to approximately 91 by 2020Q4, then gradually recovers, crossing the 100 mark around 2022Q2, and continues to rise to nearly 105 by 2023Q4.
: chart::>

<a id='46f3388b-38e4-40d0-8956-593b4aea4b85'></a>

The pessimistic scenario (A1) assumes there is a virus resurgence and a muted recovery through 2022 globally
1.Average annual percent change

<a id='32dbd423-9f35-4309-a4c2-d4c9f30ca8d3'></a>

Source: MGI Economics analysis based on scenarios generated by McKinsey in partnership with Oxford Economics, input from Moody's Analytics data

<a id='a30eaa56-0b88-4ddf-92dc-abe408b41203'></a>

Current as of October, 2020

<a id='37d5b590-d88f-46e0-9999-caa9d22f5629'></a>

2020 GDP
change²
% Change

-6.4%

GDP return
to pre-crisis
Quarter

2022Q3

<a id='207b440f-5c54-438f-a567-6aff1df3550e'></a>

McKinsey & Company

<a id='0ba64627-2f32-46be-8d04-2df431d97584'></a>

34

<!-- PAGE BREAK -->

<a id='26b918e0-f119-4230-b395-c0f32330311a'></a>

Current as of October, 2020

<a id='2846b1eb-2a90-496d-b71e-93a1c1a6b279'></a>

Vulnerable jobs and businesses are concentrated disproportionately among Hispanic and Black DC residents

<a id='1bc19d6d-dd91-4716-b74f-c674a690c826'></a>

Preliminary, proprietary, pre-decisionalShare of vulnerability of workers and businesses, by race/ethnicity¹ (%)
<::Bar chart showing the share of vulnerability of workers and businesses, by race/ethnicity.

Vulnerable jobs:
- Hispanic: 47% share, 0.05M jobs
- Black: 31% share, 0.06M jobs
- Asian: 31% share, 0.02M jobs
- White: 26% share, 0.09M jobs

Revenue in most vulnerable sectors:
- Hispanic: 26% share, $3.2B revenue
- Black: 47% share, $1.3B revenue
- Asian: 37% share, $53.5B revenue
- White: 19% share, $2.8B revenue
: chart::>

<a id='2b88cb33-43b1-4ea0-9a51-cdf5ec227d94'></a>

Source: LaborCUBE, BLS Occupational Employment Statistics, Moody's Analytics, McKinsey Global Institute analysis
Mc
1. Vulnerability of minority-owned businesses is measured by share of revenue in five sectors with most vulnerable jobs: Accommodation & Food Service, Retail, Construction, Healthcare, and Professional services

<a id='ed8324f0-352a-45e4-a5e9-5bcadc829a73'></a>

McKinsey & Company

<a id='45cb454d-6995-40ec-ad76-46e6d417869c'></a>

35

<!-- PAGE BREAK -->

<a id='3fd205d5-9732-4025-87ea-b353021069f3'></a>

Vulnerable jobs analysis: Traditional unemployment does not fully capture the economic risk facing American families

<a id='479355d1-3f8c-4bf8-8e0e-2ff58ba8ec88'></a>

In addition to traditional unemployment¹, the “vulnerable jobs” metric attempts to capture the **income risk** facing a larger set of American families by reflecting—

<a id='df30f37a-6510-4e7b-988e-3e4eb8ab5f87'></a>

Workers placed on **unpaid leave**
Workers facing **cuts to either hourly wages or hours worked**
Workers that **exit the labor force**
Workers that held multiple jobs and **reduced the number of jobs worked** as a result of Covid-19

<a id='007b63b0-11ed-41eb-b32f-09be0ad4a9b3'></a>

1. The BLS measure of U3 unemployment includes all jobless persons who are available to take a job and have actively sought work in the past four weeks

<a id='493892fa-d665-44e5-ab1c-f68e7075d67a'></a>

Source: Pitchbook

<a id='1d4d168e-f167-4f46-8ebd-b5fe84e77344'></a>

36

<a id='546cda72-f7dd-4a62-ad27-df40ebe7981f'></a>

Last Modified 11/3/2020 6:03 PM Eastern Standard Time

<a id='8063e1c6-a4cb-40ed-99ef-36a6174ba876'></a>

Printed

<!-- PAGE BREAK -->

<a id='28868de8-e04c-49ac-b9f0-0791ebfb3d1d'></a>

Current as of October, 2020

<a id='48bd61a8-ecc8-4e1a-8ae8-18aa932a09a6'></a>

Assessing small and medium business vulnerability leads to four
segments that may require different interventions

<a id='d3fc8723-17ca-4a95-b742-5327f389987d'></a>

**Preliminary, proprietary, pre-decisional**

<a id='f0d22f76-f4e3-4aee-a0fb-fc0252492dc4'></a>

<::Quadrant chart titled "Financial Risk (as indicator of resilience)" on the Y-axis and "Degree affected by COVID-19" on the X-axis.

Y-axis labels: Higher (top), Lower (bottom).
X-axis labels: Lower (left), Higher (right).

Quadrant 1 (Top-Left: Higher Financial Risk, Lower Degree affected by COVID-19):
SMBs with higher financial risk and lower initial COVID-19 effects. Increasing concern with potentially broader and longer economic impacts, given underlying fragility.

Quadrant 2 (Top-Right: Higher Financial Risk, Higher Degree affected by COVID-19):
SMBs with higher financial risk and higher COVID-19 immediate effects. This group is most likely to experience widespread potential vulnerability to closure in the near term.

Quadrant 3 (Bottom-Left: Lower Financial Risk, Lower Degree affected by COVID-19):
SMBs with lower financial risk and lower initial COVID-19 effects. May still need help, and risk may increase as crisis continues.

Quadrant 4 (Bottom-Right: Lower Financial Risk, Higher Degree affected by COVID-19):
SMBs with higher financial risk but also higher COVID-19 immediate effects. Individuals/workers in need of immediate help, though businesses may bounce back more quickly.
: chart::>

<a id='3d8d26eb-118d-4636-b59a-ffcca4d2fe41'></a>

Note: Financial risk as indicator of resilience is based on adapting a Federal Reserve methodology using profitability, credit score, and use of retained earnings. COVID-19 affectedness is based on the US Census Bureau's Small Business Pulse Survey, where business owners indicated the level of effect they are seeing from COVID-19

<a id='c2aee0c0-3835-4b08-bb7f-f618ae40bdf9'></a>

McKinsey & Company

<a id='c4630fc0-8039-432a-ab7e-9568a1edc2b7'></a>

37

<a id='3c8599ad-0019-481e-9720-3f34c0100d81'></a>

Fin
risk
ind
res

<!-- PAGE BREAK -->

<a id='f31f3a5f-c81f-45d7-82fa-f32dbce7cb24'></a>

Current as of October, 2020

<a id='0276214a-1d46-4624-acbb-048695e1c2bb'></a>

**Across sectors, DC has ~4K small-medium businesses with both higher financial risk and COVID-19 immediate impacts**
These SMBs employ ~69K workers, and their workers earn the lowest average income

<a id='c55219a8-0b2d-4c04-aa54-22de8f4ebbea'></a>

**Preliminary, proprietary, pre-decisional**

<a id='dbcc8f54-43f2-4a3f-859f-9f0658e47635'></a>

<::This image displays a 2x2 matrix comparing Small and Medium Businesses (SMBs) based on "Financial risk as indicator of resilience" (Y-axis: Higher, Lower) and "Degree affected by COVID-19" (X-axis: Lower, Higher). Each quadrant contains a bar chart showing data for Firms, Employment, and Average Income.Financial risk as indicator of resilience: Higher, Degree affected by COVID-19: LowerSMBs with higher financial risk and lower initial COVID-19 effects. Examples: Smaller apparel factories, local construction companies- Firms, thousands: 3- Employment, thousands: 45- Average income, USD thousands: 55Financial risk as indicator of resilience: Higher, Degree affected by COVID-19: HigherSMBs with higher financial risk and higher COVID-19 immediate effects. Examples: Restaurants, barber shops, bed and breakfasts- Firms, thousands: 4- Employment, thousands: 69- Average income, USD thousands: 44Financial risk as indicator of resilience: Lower, Degree affected by COVID-19: LowerSMBs with lower financial risk and lower initial COVID-19 effects. Examples: Law firms, financial advisors, lessors of residential buildings- Firms, thousands: 6- Employment, thousands: 61- Average income, USD thousands: 89Financial risk as indicator of resilience: Lower, Degree affected by COVID-19: HigherSMBs with lower financial risk but also higher COVID-19 immediate effects. Examples: Dentist offices, child care centers- Firms, thousands: 2- Employment, thousands: 27- Average income, USD thousands: 57: bar chart::>

<a id='3e64e025-10be-4cf7-a540-a974c81d3eae'></a>

Note: Financial risk as indicator of resilience is based on adapting a Federal Reserve methodology using profitability, credit score, and use of retained earnings. COVID-19 affectedness is based on the US Census Bureau's Small Business Pulse Survey, where business owners indicated the level of effect they are seeing from COVID-19

<a id='c2fa7457-d2c6-43d5-b5d7-96f6816e4894'></a>

McKinsey & Company

<a id='ad35e22b-3350-4ae3-947d-6c3a256a5d0c'></a>

38

<!-- PAGE BREAK -->

<a id='8c5af4bc-2e9c-412f-80e5-121c69ae9923'></a>

Other: Raleigh Commute Smart Consultants

<a id='41197f03-e04b-4e09-85e0-9f49c248450b'></a>

<::logo: Raleigh
Raleigh
A stylized green leaf is formed from multiple small squares and rectangles, giving it a pixelated or digital appearance.::>

<a id='bcebc302-2ca8-480e-86db-1f3d4b1a5ab8'></a>

# Description

* Call on employers to offer paid mobility programs and cash out programs (e.g., providing cash or transit subsidies to employees who do not park at work)

* Pilot employer-centered mobility programs and evaluate the effectiveness, such as through the LAB @ DC

* Launch a dedicated team within the District government focused on assisting employers with commuting programs

* Convene various transit- and commuter-centric organizations to establish an integrated strategy for enhancing commuting in the District

<a id='305f8cc2-6097-48b8-9a64-a39b076fcb07'></a>

## Case example
**Raleigh:** The City of Raleigh has created a dedicated team of "Commute Smart Consultants." This team can assist employers to implement a "Commute Smart Program" for employees, making it easy for companies to support employees in alleviating traffic congestion and commuting stress.

The program offers easy solutions for employers by providing advice and assistance on how to increase the use of transportation options such as walking, biking, transit, carpooling, vanpooling, teleworking, creative work schedules, and parking cash-out.

The City states that "Implementing a Commute Smart Program can:
*   Increase employee satisfaction
*   Reduce the demand for parking
*   Reduce tardiness and absenteeism
*   Reduce employee stress
*   Enhance recruitment and retention
*   Enhance your public image

<::A red and silver city bus with "2 FALLS OF NEUSE" displayed, stopped at a crosswalk with people crossing. : figure::>

<::A person on a bicycle on a dirt path, with other people walking in the background, surrounded by trees. : figure::>

<a id='99b08f30-65c9-4090-8d17-acbc5b33fc14'></a>

For example, one program the City offers for employers to implement is "Emergency Ride Home" which provides employees a free ride home if an emergency ever strikes. This service is available specifically to those who commuted to work by a method other than driving alone. Employers can register their organization at no cost so that all employees get six free emergency rides home per year.

<a id='4c98e8b0-c6ba-424a-a832-9e8ad36fc4f8'></a>

Source: Commute Smart Raleigh; The LAB @ DC

<a id='ae5d08d2-e9d9-4452-8dfb-a7f892598172'></a>

McKinsey & Company
McKinsey & Company

<a id='d975b4d4-035d-4b25-9cb2-fb5d5c9147de'></a>

39

<!-- PAGE BREAK -->

<a id='042d98c3-c954-4cff-bc81-405ef9008f62'></a>

DollarVan.nyc

<a id='edfdb73b-31d9-4000-b296-dd0852fa8f93'></a>

Other: New York City's Dollar Vans

<a id='1273a65a-28d5-4592-b98f-12436be5f9ec'></a>

## Description
* Provide subsidized microtransit (e.g., shuttles, mini-buses) in underserved communities
* City or transit agency can run the service or regulate private player(s) who run operations (e.g., NYC Dollar Vans, Via, etc.)
* Cross between legacy bus and ridesharing (e.g., Uber Pool)
* Can have fixed routes, fixed stops, or use algorithms to determine routes, vehicle size, and trip frequency
* Can supplement existing bus route capacity along with providing services to under-served areas
* Potential to generate employment and increase business ownership among underserved communities

<a id='c799437a-0fbe-4b17-9f68-2bed8c04aa69'></a>

Case example New York City's Dollar Vans
▪ Dollar Vans first appeared in New York City during a transit strike, and currently serve ~120K riders per day in areas of the city with transit gaps, primarily in Queens and Brooklyn
▪ Initially unregulated, the TLC (NYC Taxi & Limousine Commission) provides licenses to van owners, running background checks on all drivers, vehicle safety checks, and checking for proper insurance and licensing
  ▪ Note that the strict requirements and high cost of insurance means that many vans continue to operate without permits
▪ Follow fixed routes linking key hubs and under-served areas, such as Sunset Park, Flushing, Flatbush, and Eastern Queens
▪ Dollaride, an app, allows users to locate licensed vans, determine their arrival time, and pay the fare
▪ Cost for riders:
  ▪ Queens, Flatbush: $2
  ▪ Chinatown, Flushing, Sunset Park: $3-4
<::A map of New York City showing various dollar van routes in different colors (orange, red, blue, green) connecting key hubs and under-served areas. Locations visible include Fort Lee, George Washington Bridge, North Bergen, Fort Authority Bus Terminal, Newport Square, Chinatown Flushing, Jamaica Center Parsons Blvd, Atlantic Ave Barclays Ctr, Fulton Hall, Church Ave & 48th Street, Flatbush, Eastern Queens, 33rd St, Green Acres Hall, Rockaway, Beach 98. Below the map, a smartphone screen displays the 'dollaride' app. The app shows a green dollar van icon with a dollar sign and the text 'Ease your daily commute with NYC's network of dollar vans.': figure::>
Impact:
▪ 120K riders daily
▪ 2K drivers

<a id='2c4c6b1d-21ae-40b4-8f12-743db0d7030e'></a>

Source: DollarVan.nyc; Dollaride; New York Times; The New Yorker

<a id='20ecb53e-1c88-41b5-929e-b884d53ad541'></a>

McKinsey & Company
McKinsey & Company

<a id='6593f7f4-d75d-4e06-9b1d-21921bd85ce9'></a>

40