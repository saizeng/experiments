#!/usr/bin/env python3
"""Unstructured document chatbot skill runner.

TODO: Replace the stub with your actual API call.
"""

import json
import sys


def main() -> None:
    payload = json.load(sys.stdin)
    query = payload.get("query", "")

    # ── Replace with your actual API call ──
    result = {
        "answer": f"[STUB] Document search response for: {query}",
        "sources": [],
        "source": "unstructured_docs",
    }

    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
