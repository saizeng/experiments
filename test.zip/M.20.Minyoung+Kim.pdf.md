<a id='02c4cf07-c02f-45a9-b231-295ea7ce73c1'></a>

<::A digital illustration featuring a blue wireframe model of a human body, with a partial view of its skeletal structure. In the background, several hexagonal icons are visible, representing concepts such as an eye, lungs, and a smartphone, suggesting themes of health, technology, and human interface. A glowing circular interface element is at the bottom.: figure::>
l
i
i
ñ
F

<a id='72991b91-8667-4c81-843d-26133522282c'></a>

McKinsey&Company

<a id='4c24b568-bfd8-4ac7-a969-1470d763feca'></a>

Current perspectives on Medical Affairs
in Japan

<::JAPAN MEDICAL AFFAIRS SUMMIT logo with a red circle and an ECG line illustration.
: figure::>

February 8, 2018

<a id='bd5ab4a7-959c-434d-b66a-80de31364c98'></a>

<::A logo with a red circle containing a white ECG line. Partial text overlaid reads: "AN", "DICAL AFF", and "SUM".: figure::>

<a id='cf676455-423e-459a-8d6b-f388b98806df'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is
strictly prohibited

<a id='d374f948-32d6-49e4-bb4b-fc80053721f5'></a>

<::A close-up photograph shows a person's hands holding a dark blue smartphone. The person is wearing a white long-sleeved shirt. Abstract blue and white digital graphic overlays are visible on the image.: photograph::>CONFIDENTIAL AND PROPRIETARYAny use of this material without specific permission of McKinsey & Company isstrictly prohibited

<!-- PAGE BREAK -->

<a id='313541cf-1e07-4327-9436-38b3d745116b'></a>

Five+ years ago, Medical Affairs played primarily a support role

<a id='dd680402-22ee-4e77-bc42-88fcaf3be4e2'></a>

<::A blue banner with "R&D" in white text overlays an image of two women working in a laboratory. The woman in the foreground wears a white lab coat with grey sleeves and safety glasses, mixing a red liquid in a conical flask on a white lab bench. Various lab equipment, including beakers with yellow and orange liquids, are visible. In the background, another woman in a lab coat is seated, working with lab equipment at a white counter.: figure::>

<a id='2a21432b-fd47-44b6-8fc7-ae8c3c006b31'></a>

<::A blue banner with the text "Commercial" is at the top. Below the banner, a woman in a grey pinstripe suit and a man in a white lab coat and blue tie are shaking hands over a white counter. The background features green plants. A dark blue arrow points upwards from the bottom of the image.: figure::>

<a id='5ef9b352-e0b1-41b6-9fd1-e393365268d1'></a>

<::A group of medical professionals, with a man and a woman in the foreground looking at a clipboard. The man is wearing a white lab coat and a tie, smiling, and holding a pen. The woman is also wearing a white lab coat with a stethoscope around her neck, gesturing with her hand. Other medical staff are blurred in the background. A blue banner across the top reads "Medical Affairs".: photo::>

<a id='06de6ef6-dc1d-4237-aa4c-4994ee3bc1a7'></a>

"Commercial roles matter, Medical Affairs is there to support"

<a id='9934cfaa-e88f-4f81-912b-0d152bff52dd'></a>

McKinsey & Company

<a id='65a48a96-e364-46db-a175-084cd423fdda'></a>

2

<!-- PAGE BREAK -->

<a id='0ec04641-b5d2-4bdf-a6b9-c8f62800b075'></a>

Today, the demands on Medical Affairs are rapidly growing globally

<a id='ac1929b6-26b3-4c8b-bbad-f097860a6657'></a>

New decision-makers

<a id='96f12bbf-cacf-47a8-83dd-16a7b1666036'></a>

<::figure: A diagram illustrating "Emerging demands" at its center, surrounded by six circular images each representing a contributing factor. The central circle contains the text "Emerging demands" and three upward-pointing arrows. The surrounding circles are:
1. Top-left: A stethoscope on an American flag, labeled "Changing regulatory environment."
2. Middle-left: Two people in business attire seated in a modern building, labeled "Evolving commercial model."
3. Bottom-left: A person in a white coat (doctor) using a laptop, labeled "Wide-spread adoption of technology."
4. Bottom-right: A blue bar and line graph, labeled "More data and transparency."
5. Middle-right: A hand pointing at a computer screen displaying chemical structures, labeled "Increasingly complex science."
6. Top-right: A document with the word "VALUE" highlighted in green, next to a green marker. The text visible on the document includes "VALUATION," "1. estimate," "2. act," and "VALUE worth of a thing that will have." This is labeled "Broader definition of value."::>

<a id='598ff021-9faf-4847-a513-b15024230d3b'></a>

which a prom
It includes n
grant, and
love and a
ALUATIO
1. esti
2. act
wor
stimati
ALUE worth of
thing that will h

<a id='767223d4-e0e4-4300-8025-7dcb2ed11eb0'></a>

SOURCE: Medical Affairs Leader Forum

<a id='ad42accc-f4cd-41c5-9ef1-de04b5507ab1'></a>

McKinsey & Company

<a id='56653db8-993c-4104-9097-c84e7227cbe0'></a>

3

<!-- PAGE BREAK -->

<a id='dfca0a70-106f-4f17-ba26-da6463da8c67'></a>

Similar changes and demands are arising in Japan

<a id='5f78bbd3-ef93-48d3-8705-7708c57cd247'></a>

<::logo: [Japan] [No readable text] A red circle with a white outline is centered on a white background.::>

<a id='84b1d322-7c55-4240-9ec0-6fd349762262'></a>

New decision-makers
* Increasing use of clinical guidelines by the government

Increasingly complex science
* New technology such as CAR-T and gene therapy in pipeline

Wide-spread adoption of technology
* Increasing adoption of digital channel by HCPs

<a id='b7b91b3c-a62a-4b81-a61c-9831c8ef70eb'></a>

<::A close-up image of a dictionary page with the word "VALUE" highlighted in green by a marker.: image::>Broader definition of value- Ongoing HTA pilot and futureintegration into price revisionscheme<::A blue-toned bar chart with an overlaid line graph and a grid background, symbolizing data and transparency.: chart::>More data and transparency- Full launch of MID-NET fromFY 2018

<a id='b74e438e-8d3f-4a12-9354-9573ec9ee5fc'></a>

ALUABLE
which a prom
It includes 2
grant, and
love and a

ALUATIO
1. estiv
2. act
WOL
stimat
ALUE worth of a

<a id='6c85bad8-c056-47b7-a644-32961591727f'></a>

<::A photograph showing three business people seated in a modern, brightly lit building lobby or atrium, with large windows and multiple levels. The people are engaged in conversation.: figure::>

**Evolving commercial model**

* MR visit restrictions
* Rise of multi-channel

<a id='e4e441b2-4cbc-4cb2-8962-51efa72f9b81'></a>

<::A stethoscope rests on an American flag. To the right of the image, text reads: Increasingly stringent regulatory environment. Below that, a bullet point says: Recent pricing reform.
: figure::>

<a id='d2c63668-17af-4559-9ac3-dd7dbe4adb0e'></a>

SOURCE: Medical Affairs Leader Forum

<a id='02a1c66d-1a54-4fe4-a420-4a2b2be702ba'></a>

McKinsey & Company

<a id='669b5267-17b9-4806-ae8f-7fcb536a2c46'></a>

4

<!-- PAGE BREAK -->

<a id='f41167ac-01a1-479d-be8e-0912fd2ea264'></a>

The scope of medical activities continues to increase

<a id='125b4e6b-9457-41a6-9756-d592e86fd65d'></a>

<::list of services with icons
: icon: Two overlapping speech bubbles.
: text: Relationship management and communication of product information
: icon: A person presenting in front of a whiteboard.
: text: Medical education
: icon: A circle with an 'i' inside, representing information.
: text: Medical information services
: icon: A megaphone.
: text: Medical communications, including publications::>

<a id='f3819dc0-579f-4cc2-a4a1-4d0853e431c3'></a>

<::Legend: Gray box: Historical focus. Blue box: Growing focus. Dark blue box: New focus. List of focus areas with icons: - Icon (digital watch with a line graph): Post-launch clinical trials (e.g., Phase IIIb/IV trials, IIS and observational studies). - Icon (plus sign with three vertical dots connected by lines): Medical strategy. - Icon (clipboard with a plus sign): Health Economics and Outcomes Research (HEOR). - Icon (document with gears and binary code 01 0110 0001 01101): Real world evidence.: figure::>

<a id='57250de3-7123-4bf9-b5cb-1f5453303075'></a>

McKinsey & Company

<a id='5e6733fa-727d-4204-b218-ff0cf261fb75'></a>

5

<!-- PAGE BREAK -->

<a id='4788ec1c-e5a3-4e04-a8e8-ab7a7438e1b4'></a>

We see medical taking more prominent role as the "Third Pillar" of the
business in Japan

<a id='33e722eb-f7f7-4a52-8a10-dc5038bd5cbd'></a>

<::The image displays a diagram titled "The third pillar" at the top, depicted as a gray arrow pointing upwards. Below this, there are three main sections arranged horizontally, each featuring a blue banner, an image, and an associated descriptive text in a circle below. Blue arrows connect the sections, indicating a flow from left to right. The sections are:1.  **R&D**: Under a blue banner labeled "R&D", an image shows two scientists in a laboratory, wearing lab coats and safety glasses, working with beakers and chemicals. Below this, a circle contains the text "Highly strategic". A blue arrow points from this section to the "Medical Affairs" section.2.  **Medical Affairs**: Under a blue banner labeled "Medical Affairs", an image shows a group of medical professionals (doctors and nurses) in scrubs and lab coats, gathered and discussing, with some looking at a clipboard. Below this, a circle contains the text "In-market data generation". A blue arrow points from this section to the "Commercial" section.3.  **Commercial**: Under a blue banner labeled "Commercial", an image shows a man in a lab coat shaking hands with a woman in a business suit across a desk. Below this, a circle contains the text "In-market monitoring".::>

<a id='10dbff03-7978-4edf-aae5-8c34449144e3'></a>

SOURCE: Medical Affairs Leader Forum

<a id='c20f72ae-da3a-4fd9-ab05-3662726c4229'></a>

McKinsey & Company

<a id='f4d94eb6-2112-4145-85f3-7565c9989f92'></a>

6

<!-- PAGE BREAK -->

<a id='e17eefb4-d935-484c-80bb-de2e6bba3591'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='470da1de-cc0b-449f-aef2-2f89f2161e80'></a>

<::icon: A blue circle with a white silhouette of a doctor wearing a headlamp and a stethoscope.::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<a id='08187de4-39f1-432f-b88e-db43896ebdc6'></a>

<::Blue circle with a white caduceus symbol in the center, surrounded by six white arrows pointing outwards in different directions: icon::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<a id='35278f4e-fa73-4a03-8594-88c8b1f9c9a4'></a>

<::An icon depicting a blue circle with a white magnifying glass. Inside the magnifying glass, there are white pill and tablet icons.
: figure::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<a id='db7853ec-e51c-48e1-a672-31c5dabba25c'></a>

<::An icon depicting three stylized white human figures within a blue circle, representing a group or team. Below the icon, the letter "D" is present. The accompanying text reads: Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies: icon::>

<a id='cfd39c95-b2fc-4a93-bc62-4f35fd47224a'></a>

McKinsey & Company

<a id='726b3212-7503-449a-b52a-11aa475ebd31'></a>

7

<!-- PAGE BREAK -->

<a id='19e3dadf-c9f0-4704-bd00-4970ef254034'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='9e89412c-f72f-40e8-a8fb-ef9417c49b67'></a>

<::logo: [Medical Professional/Healthcare]A white silhouette of a medical professional with a stethoscope is set against a circular blue background with a long shadow.::>

<a id='013a0701-694e-43b2-aa49-d64b61966464'></a>

*Deeper*
*understanding of*
*the customers* to
better target the
different needs of
physicians and be
able to provide
tangible value

<a id='04b13c45-9250-451c-a221-feed9815f3e1'></a>

<::A light blue circle with a white caduceus symbol at its center, surrounded by six white arrows pointing outwards in different directions: diagram::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge 

<a id='22096a15-d6f8-45a6-adf6-768bdd634147'></a>

<::An icon of a magnifying glass over several pills and capsules, all enclosed within a circle.
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment
: icon::>

<a id='7175a4c3-8edb-4a78-a27d-2e059090e363'></a>

<::icon of three people silhouettes in a circle, labeled 'D' : figure::>Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies

<a id='e234cfe9-53e5-4648-a288-37cb5cba10c5'></a>

McKinsey & Company

<a id='f40dbcde-575b-407b-8521-7a3060e77f23'></a>

8

<!-- PAGE BREAK -->

<a id='1f82a9af-e912-4248-8082-5c39c3a925b2'></a>

Quality of MSL interaction have clear correlation with the satisfaction and scientific influence of the company

<a id='80eaef58-48ac-4381-bf5c-c8aba51493cb'></a>

<::logo: [Medical Professional/Healthcare] [None] A blue circular icon with a white silhouette of a doctor wearing a stethoscope, and a white circular icon with a red circle in the center, representing the flag of Japan.::>

<a id='0ec8bf11-4015-4af3-95cf-3cf83fb3036b'></a>

Correlation between quality and quantity of the MSL activities and overall impact of a pharma company Percentage of respondents per case; n =460 <::chart: A grouped horizontal bar chart titled "Correlation between quality and quantity of the MSL activities and overall impact of a pharma company" displays data for Quality and Quantity categories, broken down by specific MSL activity aspects, against three impact measures: "Level of satisfaction with the company", ""Scientific influence" of the company", and "Likelihood of recommendation to peers". The values represent correlation coefficients. The chart data is as follows:  Quality:  - Process management skills of MSL:    - Level of satisfaction with the company: 0.66    - "Scientific influence" of the company: 0.47    - Likelihood of recommendation to peers: 0.49  - Level of scientific and medical knowledge of MSL:    - Level of satisfaction with the company: 0.64    - "Scientific influence" of the company: 0.44    - Likelihood of recommendation to peers: 0.49  - Interpersonal communication skills of MSL:    - Level of satisfaction with the company: 0.60    - "Scientific influence" of the company: 0.45    - Likelihood of recommendation to peers: 0.46  Quantity:  - Number of MSL visits:    - Level of satisfaction with the company: 0.33    - "Scientific influence" of the company: 0.25    - Likelihood of recommendation to peers: 0.28  - Number of MSL related activities:    - Level of satisfaction with the company: 0.27    - "Scientific influence" of the company: 0.17    - Likelihood of recommendation to peers: 0.35  - Average duration of MSL visits:    - Level of satisfaction with the company: 0.10    - "Scientific influence" of the company: 0.10    - Likelihood of recommendation to peers: 0.15::>

<a id='9bd98a0f-5422-4d52-b49d-bada1a645f19'></a>

SOURCE: Japan MAPES 2016

<a id='077867ff-2bb7-43fc-9a7b-d2f4b7018db4'></a>

McKinsey & Company

<a id='8b3fbce9-8666-4bb7-ac27-1dd1e723a873'></a>

9

<!-- PAGE BREAK -->

<a id='8eb1e2ee-6224-44f7-96af-02e7dc85f87e'></a>

Yet, most companies are measuring quantity metrics of MSL activities
than quality or impact metrics

<a id='c8cc3eec-1b59-4755-84ee-59f32d7a6eda'></a>

<::logo: [Medical Professional/Healthcare Service]A white icon of a doctor with a stethoscope is set against a circular blue background with a long shadow.::>

<a id='1a8bd00b-b5ca-4b3c-a436-8dcdf768dbbe'></a>

Performance management & metrics, 2015
<::transcription of the content: chart
Title: Percentage of respondents gathering the metrics¹

- Quantify of activity: 78%
- Quality of activity: 40%
- Impact of interaction: 20%
::>
- What are the quality and impact metrics that are representative of Medical performance in Japan?
- How can we find more practical and objective ways to measure these metrics? More real time?
- How can we build a better feedback mechanism for continuous performance improvement?

<a id='303e0d15-2f93-45e5-8c96-13fe78d2d4c4'></a>

1 N=13

<a id='f8e56395-1c59-4690-9522-38456a8a8d34'></a>

McKinsey & Company

<a id='876bf329-41d7-43a6-9c4a-ba75198ee6ba'></a>

10

<!-- PAGE BREAK -->

<a id='74f20736-47ab-43bd-bf94-570c83773a1f'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='4cc88943-ad84-4abe-90fc-506f283042ff'></a>

<::visual content: light blue circle with a white icon of a doctor (head, shoulders, stethoscope)::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::visual content: dark blue circle with a white icon of a caduceus symbol (staff with two snakes and wings) at the center, surrounded by five arrows pointing outwards in different directions::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::visual content: light blue circle with a white icon of a magnifying glass over various pills/capsules::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<a id='a1d678e2-c06e-4883-9024-3c99310112a5'></a>

<::A light blue circular icon containing three white silhouettes of people (busts), representing a group or team. Below the icon, the letter "D" is prominently displayed.: figure::>Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies

<a id='fad2f318-0934-422c-a94e-274391e43fb3'></a>

McKinsey & Company

<a id='267626e4-8100-4ebe-9347-b50ec9737fcf'></a>

11

<!-- PAGE BREAK -->

<a id='7e577f7b-cbe6-4d2b-b9bd-26e41ce97e96'></a>

Pharma players in Japan generally lag behind digital leaders across most elements of digital enablement

<a id='a26c3fd0-be16-4d18-8596-9918f9525c14'></a>

<::logo: [Unidentifiable]
[No readable text]
A blue circular logo with a white six-pointed star and a blue medical caduceus symbol in the center, featuring a subtle shadow effect.:>

<a id='3c88b3e1-8d85-4fdc-9556-5146a6390962'></a>

Rating on 5 point scale by 40 digital leaders across industry in Japan
<::chart: Bar chart showing ratings on a 5-point scale for various digital transformation aspects, comparing 'Digital leaders' (grey bars) and 'Japan PMP' (blue bars).

**Strategy**
- How aligned are your digital and corporate strategies?
  - Digital leaders: 4.1
  - Japan PMP: 2.6
- How customer-centric is your digital strategy?
  - Digital leaders: 3.8
  - Japan PMP: 2.5

**Organization**
- What share of your digital talent has experience from outside?
  - Digital leaders: 3.2
  - Japan PMP: 3.0
- Can your senior managers articulate their digital KPIs?
  - Digital leaders: 3.6
  - Japan PMP: 2.4

**Culture**
- What is your company's comfort level in taking risks regarding digital initiatives?
  - Digital leaders: 3.9
  - Japan PMP: 3.0
- To what extent do you use external partners to build digital capabilities?
  - Digital leaders: 3.5
  - Japan PMP: 3.3

**Capabilities**
- How well does your company leverage the data you collect to generate insights?
  - Digital leaders: 3.7
  - Japan PMP: 2.7
- Are your core back-office processes digitized?
  - Digital leaders: 4.0
  - Japan PMP: 3.5

Results from Google McKinsey&Company Digital round-table in Japan
Participants:
- AbbVie
- Bayer
- GSK GlaxoSmithKline
- Lilly
- Novartis
- Daiichi-Sankyo
- Janssen
- Shionogi
- Pfizer
- Omron
- MSD
- Philips
- Terumo
:chart:>


<a id='aa195781-c633-415f-ba39-60b19d4a4c0f'></a>

SOURCE: McKinsey DQ - Digital Benchmarking Survey

<a id='80f468f4-b440-467b-87de-bb6ef899cd66'></a>

McKinsey & Company

<a id='301c7f68-0a32-4f4f-b768-f77508b70b69'></a>

12

<!-- PAGE BREAK -->

<a id='be70b8c9-07c4-4cb7-9b09-46ad76dda244'></a>

Digital has potential to change ways of working across whole Medical Affairs value chain

<a id='bc5d22b1-73e2-4bed-9cd8-8b0ab0840fb5'></a>

<::logo: [Unknown] No readable text. A white six-pointed star with a medical caduceus symbol inside is set against a blue circular background.::>

<a id='b6fcca47-c081-428c-a35d-c876a7105d74'></a>

NOT EXHAUSTIVE

<a id='3a7f46b3-ea01-447e-a1b2-c8095e9a1686'></a>

Medical strategy

*   How advanced is my organization in digital Medical versus other Pharmacos?
*   What are customer preferences and potential future disruptors?
*   How to measure effectiveness of digital approaches?
*   How to evolve engagement model over Lifecycle using digital?

<a id='41b59477-83e1-438d-aac8-b98b0b16f9a5'></a>

## Field Medical/Engagement

*   What are the most effective ways to engage Medical KOLs in the digital world?
*   How to build optimal continuum of Medical engagement using mix of digital and physical interactions?
*   How to bring our content to places where HCPs and patients normally search for content (e.g. search engine optimization)

<a id='6da97156-66fe-4bec-969a-724d1c55ab34'></a>

Medical support

* Can we use digital to make compliance more efficient and simple?
* Can we digitize our support (e.g. Medical Information processes) to make them more efficient and user friendly?
* How to run Medical Communication campaigns in digital world (e.g. which channels, what is calendar)?

<a id='f3c2f304-87d4-48ef-bbd6-f8ae8a9ef85e'></a>

Data generation & HEOR

* How to leverage digital and analytics to collect more granular data and better insights about patient's?
* Can we use digital to source new ideas for data generation?
* Are digital tools a potential threat to our current approach while enabling payors and other stake-holders to have granular data about our patients? How to respond?

<a id='479a0e43-fd84-4428-b3a6-352f7e19a2e6'></a>

McKinsey & Company

<a id='bdb416c7-45a9-417a-99b8-15cf8b18d93f'></a>

13

<!-- PAGE BREAK -->

<a id='4692dfe3-5027-405f-b91f-eec3db6728fc'></a>

There are already numerous sources of data available in Japan

<a id='a4bc59ce-ab04-4ad1-9bb0-4b1eb1c7bcc6'></a>

<::logo: [Unidentifiable]
[No readable text]
A blue circular logo with a white six-pointed star and a blue medical caduceus symbol in the center, featuring a subtle shadow effect.:>

<a id='a193b365-4da1-412a-bf2b-e58830ffec3e'></a>

Treatment data
<::logo: HCEI logo::>
医療統計情報プラットフォーム
Platform for Clinical Information Statistical Analysis
<::logo: MDV medical.data.vision logo::>
藤田保健衛生大学
FUJITA HEALTH UNIVERSITY
Medical
claims data
株式会社日本医療データセンター
Japan Medical Data Center.
株式会社医療情報総合研究所
JMIRI Japan Medical Information Research Institute, Inc (JMIRI)
患者中心の保健医療を支える、地方情報分析のリーディングカンパニー
厚生労働省
Ministry of Health, Labour and Welfare
NDB open data by
prefecture
(National database)
Health
checkup data
<::logo: HCEI logo::>
株式会社日本医療データセンター
Japan Medical Data Center
<::image: A red and white logo with abstract shapes, possibly representing a medical cross and data flow.::>
Wholesale sales
data
<::logo: IQVIA logo::>
CRECON
RESEARCH & CONSULTING
Available
now
Pharma can
use by 2020
<::logo: Pmda logo with text MID-NET::>
MID-NET
May open-
up going
forward
厚生労働省
Ministry of Health, Labour and Welfare
DPC database
<::logo: NCD National Clinical Database logo::>
NCD
National
Clinical
Database
厚生労働省
Ministry of Health, Labour and Welfare
NDB
(National database)
社会保険診療報酬支払基金
Health Insurance Claims Review & Reimbursement Services
厚生労働省
Ministry of Health, Labour and Welfare
社会保険診療報酬支払基金
Health Insurance Claims Review & Reimbursement Services
<::logo: Japan Gastroenterological Endoscopy Society logo with text "JAPAN GASTROENTEROLOGICAL ENDOSCOPY SOCIETY 一般社団法人 日本消化器内視鏡学会"::>
JAPAN GASTROENTEROLOGICAL
ENDOSCOPY SOCIETY
一般社団法人
日本消化器内視鏡学会

<a id='2cd589ae-0703-4eb1-89c0-69ae84d1f574'></a>

SOURCE: International pharmaceutical intelligence; McKinsey

<a id='7c5f719b-37fb-4362-b1ee-0eba8a2f3e9f'></a>

McKinsey & Company

<a id='2a0bdcaf-d5a1-4bb1-afcf-032db6eee830'></a>

14

<!-- PAGE BREAK -->

<a id='e83dccf7-8d1e-4bec-acc4-78f40c1fe9db'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='84b380a0-9e73-49eb-812d-aacc3aad4a09'></a>

<::icon of a doctor (person with a stethoscope and head mirror) in a light blue circle. Below the circle is the letter "A".: figure::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value
<::icon of a caduceus symbol with arrows pointing outwards in multiple directions, all within a light blue circle. Below the circle is the letter "B".: figure::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge
<::icon of a magnifying glass over several pills (capsules and a tablet) in a dark blue circle. Below the circle is the letter "C".: figure::>

C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment
<::icon of three stylized people (a team) in a light blue circle. Below the circle is the letter "D".: figure::>

D
Develop and acquire
talent to cultivate and
to build a strong,
multi-faceted Medical
Affairs organization
that encompasses the
new set of
competencies

<a id='21b12cb0-38bc-4c0b-b0b6-e6f585054686'></a>

McKinsey & Company

<a id='0dbf88e0-79a5-4350-9fdd-eab01da872ac'></a>

15

<!-- PAGE BREAK -->

<a id='e3134d2f-302b-4c5f-8034-45d6eca33b6c'></a>

Coordination with other functions is critical in creating Medical impact

<a id='c5eff735-6ced-4fba-8607-b558d0dd2242'></a>

<::logo: [Medical/Pharmaceutical]A blue circle contains a white magnifying glass examining various pills and capsules, with a long shadow extending to the right::>

<a id='23267f1b-726e-47e8-8fc0-abc626212cee'></a>

Typical company interaction with a KOL <::radial diagram: The diagram features a central circular image of a smiling male doctor in a light purple shirt and tie, wearing glasses, with his chin resting on his hand, appearing to be in a medical office. Surrounding this central image are segments of a circle, each associated with a label representing different points of interaction. Clockwise from the top, these labels are: MSL, Conference website, R&D, Company website, e-Detailing, Marketing, MR, and Area Manager.::>

<a id='2b71dc00-bd96-496e-ad6c-d19609f0cafd'></a>

**What we often hear from KOLs**

"I meet at least 4-5 different people from one company. But they don't seem to talk to each other."

"What I hear from one person is sometimes different from what I hear from another. It is quite confusing"

"Sometimes it takes weeks to get an answer to my questions. I don't know why. By then I am wrestling with another problem"

<a id='97344a4d-b453-4747-bb59-60a6bbf0434f'></a>

McKinsey & Company

<a id='7f1048c8-86c4-4947-84c1-0b3395718516'></a>

16

<!-- PAGE BREAK -->

<a id='471ba54d-fcd2-4f3b-93ab-f30e82d47c47'></a>

Role as a true 3rd pillar will require close collaboration with other functions

<a id='1e47704b-39ec-44a8-8999-9beea0e3d8d1'></a>

<::logo: [Medical/Pharmaceutical]A blue circle contains a white magnifying glass examining various pills and capsules, with a long shadow extending to the right::>

<a id='a5a5ff45-07bd-4690-909a-ec950e56c0d2'></a>

<::A diagram titled "The third pillar" at the top, represented by a grey upward-pointing arrow. Below it, three columns represent different functions, each with a blue header and an image. From left to right:1.  **R&D**: Image of a woman in a lab coat and safety glasses stirring a red liquid in a beaker in a laboratory.2.  **Medical Affairs**: Image of a group of medical professionals in white coats and scrubs, looking at a clipboard and interacting. This column is connected to the R&D column by a blue circular arrow icon, and to the Commercial column by another blue circular arrow icon.3.  **Commercial**: Image of a woman in a business suit shaking hands with a man in a lab coat.: figure::>

<a id='51b42652-08d3-4e22-812a-25e853cb194e'></a>

*   *Where can we find the largest opportunity for impact? What are customers expecting?*
*   *Where can Medical take immediate leadership in these collaborations? And how?*
*   *What are current barriers in realizing better collaboration with others? Internal policy? Cultural?*

<a id='7bceb53f-888c-4132-949a-d4db9ddf67c8'></a>

McKinsey & Company

<a id='ab88b235-0d41-4aea-8a4f-14633877ec29'></a>

17

<!-- PAGE BREAK -->

<a id='9695013a-6b68-43f0-940d-8113e6b82044'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='6c312ce3-16b5-4a15-8f72-8d64cbd5828e'></a>

<::Light blue circle with a white icon of a doctor (head, torso, stethoscope) with a long shadow.: figure::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::Light blue circle with a white icon of a caduceus symbol with arrows pointing outwards in eight directions, with a long shadow.: figure::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::Light blue circle with a white icon of a magnifying glass over pills and capsules, with a long shadow.: figure::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<::Darker blue circle with a white icon of three stylized human figures (busts with collars and ties), representing a team, with a long shadow.: figure::>
D
Develop and acquire
talent to cultivate and
to build a strong,
multi-faceted Medical
Affairs organization
that encompasses the
new set of
competencies

<a id='5aa8f963-2b78-407a-9b5d-eb541cb361d0'></a>

McKinsey & Company

<a id='4dc03048-ea92-4f9d-b31e-4a2b9b4b0402'></a>

18

<!-- PAGE BREAK -->

<a id='557423d3-64cf-4a6f-b40d-8e2d5a146b8b'></a>

A strength-based approach to Medical Affairs talent

<a id='d60815bd-bf3e-4846-ac4b-0be657c0f204'></a>

<::logo: [Unknown]No readable text.A blue circle contains three white stylized figures of people with long shadows, suggesting a team or group.:>

<a id='4c98a6f6-3cd8-4175-9395-803a819a8437'></a>

<::A circular diagram titled "Medical Affairs capabilities" shows a central text "Medical Affairs capabilities" connected to five surrounding circles, each representing a key capability. The capabilities are:
- Learning agility, depicted by an icon of a running person.
- Business leadership, depicted by an icon of a group of people with one person raising their hand.
- Strategic vision, depicted by icons of a chess knight and pawn.
- Emotional intelligence, depicted by an icon of a brain with light rays.
- Deep understanding of compliance, depicted by an icon of balance scales.
- Scientific and technological thought leadership, depicted by an icon of a microscope.
: diagram::>

<a id='502a9364-f664-4418-8fa0-53fc2304c894'></a>

# A strength-based approach

*   **Skills and competencies** examined at level of the group, e.g.,
    *   Cultivate individual's strengths for the benefit of the group
    *   Seek candidates that fill gaps in the group, not the "perfect" candidate
*   **Comprehensive talent strategy** supports and builds skills and capabilities of group
*   "**Field and Forum**" approach integrates learning modules and real work experiences (as reinforcement)

<a id='824d4598-d031-41dc-9383-89bb9736a4d5'></a>

SOURCE: Managing talent in the Medical Affairs function: Creating value through strengths-based approach

<a id='34ea6631-a72e-4e73-9094-1e9cb12c8010'></a>

McKinsey & Company

<a id='1a1ee0e0-1794-4345-9f23-1ba828901730'></a>

19

<!-- PAGE BREAK -->

<a id='181aff9a-3d77-480f-8473-1dcf5cddacb2'></a>

Medical *is* the "Third Pillar" of pharmaceutical business

<a id='c93a546e-fb6b-43d6-847e-23da397bb0e0'></a>

<::R&D. Two women in lab coats and safety glasses working in a laboratory. One woman is in the foreground, mixing a red liquid in a flask with her hands. On the counter, there are various beakers and flasks containing colorful liquids (yellow, red, orange) and lab equipment, including a mixer with a yellow liquid. Another woman is visible in the background, seated and working at a lab bench. The lab has white cabinets and counters.: figure::>

<a id='d15f19d9-b4a7-4364-bc04-3db8c4108027'></a>

<::icon: A white silhouette of a person wearing a doctor's head mirror and a stethoscope, inside a blue circle with a long shadow.::>

Deeper understanding of
the customers

<a id='48a7810e-adb4-4504-bdcb-363275a26a04'></a>

<::An infographic titled "The third pillar" at the top, presented within a grey house-shaped graphic. Below this, there are two main sections side-by-side, separated by a large blue plus sign. The left section is labeled "Medical Affairs" and features an image of several medical professionals (doctors and nurses) in a discussion, looking at documents. The right section is labeled "Commercial" and shows a man in a white lab coat shaking hands with a woman in a business suit. Below these two sections, a large blue downward-pointing arrow indicates progression to three circular blue icons arranged horizontally. Each icon has a corresponding text description below it: 1. A circular icon with a white caduceus-like symbol surrounded by arrows pointing outwards, with the text "Getting ahead in digital leadership". 2. A circular icon with a white magnifying glass over various pills and capsules, with the text "Integrated working model with internal partners". 3. A circular icon with three white stylized human figures (representing people), with the text "Develop and acquire talent".: figure::>

<a id='f2d45b0f-8f71-417b-9f68-0ee28b2f4125'></a>

McKinsey & Company

<a id='92f8c1f6-bdb9-4ae8-987b-fb2b42691c61'></a>

20