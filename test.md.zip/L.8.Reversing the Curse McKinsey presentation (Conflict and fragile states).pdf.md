<a id='cb54544e-ad14-4301-bfff-b167ce0a2faf'></a>

## Attracting Responsible Mining
## Investment in Fragile and Conflict
## Affected Settings

Fraser Thompson
Senior Fellow
McKinsey Global Institute (MGI)

<a id='a1705881-49dd-4b5e-81e4-4bf6b6b9ac0b'></a>

Reversing the curse presentation
February 6, 2014

<a id='813d75b2-9a6b-47e5-a90a-91668da82c96'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='7a60d2d3-d83a-4867-98c2-bbd2f48e8d80'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='4c7c5eb2-f414-408e-a0f1-02f56f63a5b9'></a>

This presentation draws upon material in our “Reverse the curse” report -
available for download at www.mckinsey.com/mgi

<a id='fc255fe5-b3fa-4454-bfe3-3889fdc31207'></a>

McKinsey&Company

<a id='2c38c009-27d5-474d-a1ec-0b9e37fddb83'></a>

Prepublication Version — Embargoed — for Release December 5, 2013

<a id='5f8b9e4d-8dea-4802-aaac-fc5f716147ce'></a>

McKinsey Global Institute McKinsey Global Energy & Materials Practice McKinsey Sustainability & Resource Productivity Practice <::Four images depicting different industrial and resource-related activities: 1. A person in a hard hat and high-visibility vest operating surveying equipment in a rocky, barren landscape. 2. An offshore oil rig silhouetted against a vibrant sunset over the ocean. 3. Two workers in hard hats and blue coveralls performing tasks on what appears to be drilling or pipeline equipment. 4. A curving railroad track running parallel to a dirt road through a grassy area.: set of images::> December 2013

<a id='c82a1033-67ef-42e4-9a1f-11d6c157cef2'></a>

Reverse the curse:
Maximizing the potential of
resource-driven economies

<a id='08297a3d-bea0-4b58-9ed5-22bd3cfb3f5d'></a>

<::A world map, represented by a pattern of small gray dots on a white background. The map shows the continents of North America, South America, Europe, Africa, Asia, and Australia, outlined by these dots. The dots are uniformly distributed to form the landmasses.: map::>

<a id='dee61e00-f88c-428d-b4df-85ef3a6cb746'></a>

## Central questions
1 How is the resource supply
landscape changing?
2 What are the implications for
resource-driven economies?
3 What are the implications for
extractive companies operating
in these countries?

<a id='1705b5ac-f0b1-45a3-8f87-ea81f8f3feb7'></a>

McKinsey & Company

<a id='77cf2f8d-5bcc-4253-9a2b-b31c331ff7f6'></a>

1

<!-- PAGE BREAK -->

<a id='59418cb4-43e3-4074-9f89-d7aa3d2b1096'></a>

The number of resource-driven countries has increased by almost 40% since 1995 and most newcomers have low average incomes

<a id='bcf1546e-c592-4c3c-b1e8-7afa7889a758'></a>

Number of resource-driven countries over time, by income class
<::stacked bar chart::>
**Stacked Bar Chart: Number of resource-driven countries by income class**

**1995 (Total: 58 countries)**
*   Low income: 22
*   Lower middle income: 19
*   Upper middle income: 8
*   High income: 9

**2011 (Total: 81 countries, +40% increase from 1995)**
*   Low income: 17
*   Lower middle income: 21
*   Upper middle income: 27
*   High income: 16

**Additional Data:**
| Category              | 1995 | 2011 |
|:----------------------|:-----|:-----|
| % of world GDP        | 18   | 26   |
| % of world population | 18   | 49   |
<::chart::>

<a id='8ed64f9f-16d4-4159-afdd-dba46390a920'></a>

Income class at time of becoming resource-driven%, 1995–2011<::Pie chart showing income class at time of becoming resource-driven, percentages from 1995–2011. The breakdown is as follows: Low: 54%, Upper middle: 25%, High: 11%, Lower middle: 11%.: chart::>

<a id='ab56c1b2-fd60-4288-b1f3-292c61892e75'></a>

McKinsey & Company

<a id='bcf17769-3825-4c9e-964e-3adccce17803'></a>

2

<!-- PAGE BREAK -->

<a id='cef61b4a-1fab-4e79-9fff-afb4eac31162'></a>

Annual investment in oil and gas and minerals could need to more than double to meet new demand and replace existing supply

<a id='1ff4914a-5402-4caa-b958-7546c548ad37'></a>

2012 $ billion

<a id='7d51d868-d389-4642-949f-9c7fd3659039'></a>

Annual investment requirements
Minerals
<::Bar chart showing annual investment requirements broken down by Replacement capex (blue) and Growth capex (light blue).

**Legend:**
Replacement capex: Blue
Growth capex: Light blue

**Minerals:**
- 2003-2012:
  - Replacement capex: 41
  - Growth capex: 57
  - Total: 98
- 2013-2030:
  - Replacement capex: 110
  - Growth capex: 105
  - Total: 215
- Increase from 2003-2012 to 2013-2030: +119%

**Oil and gas:**
- 1995-2012:
  - Replacement capex: 121
  - Growth capex: 165
  - Total: 286
- 2013-2030:
  - Replacement capex: 299
  - Growth capex: 451
  - Total: 749
- Increase from 1995-2012 to 2013-2030: +162%
: chart::>
$17 trillion by 2030 (~3.8 trillion for minerals alone)

<a id='c6b2f6e2-2719-4766-b3e2-40d5b5ca5c59'></a>

Resource investment in low and lower-middle income countries<::chart: Bar chart showing resource investment in low and lower-middle income countries.
Legend:
- Potential upside: Dotted outline box
- Base case: Solid blue box

Data:
- 1995-2012:
  - Base case: 835
- 2013-2030:
  - Base case: 1,245
  - Potential upside: 1,770
  - Total (Base case + Potential upside): 3,015

Annotation:
- An arrow points from the top of the 1995-2012 bar to the top of the 2013-2030 potential upside. Next to the arrow is a green oval with "3.6x" inside, and the text: "Resource extraction investment in lower income countries could potentially more than triple from historical levels".:chart::>

<a id='33015890-e70f-44bd-8154-24d9d7a3a6f6'></a>

McKinsey & Company

<a id='7af8efbc-0802-4340-b049-331434aba9a6'></a>

3

<!-- PAGE BREAK -->

<a id='f728a82f-caa9-4fed-acd9-ecfc5f685847'></a>

**However historically resource-driven countries have not performed well economically**

<a id='77a928a7-3ede-4f71-8d86-cf13f012d98a'></a>

<::Scatter plot titled "Per capita GDP, 2011" with the subtitle "Real 2005 $". The plot shows data points representing % of RDCs, as indicated by the legend (a blue circle). The x-axis is labeled "Per capita GDP compound annual growth rate, 1995–2011 %" and ranges from -4 to 19. The y-axis is labeled "Per capita GDP, 2011 Real 2005 $" and ranges from 0 to 70,000. A horizontal dashed line at approximately 10,900 on the y-axis is labeled "Average country per capita GDP: $10,900". A vertical dashed line at 2.5% on the x-axis is labeled "Average country growth: 2.5%". These lines divide the plot into four quadrants: The top-left quadrant is labeled "16% Slowing", the top-right is labeled "5% Stars", the bottom-left is labeled "40% Falling behind", and the bottom-right is labeled "37% Catching up". Multiple blue circular data points are scattered across the plot within these quadrants.: chart::>

<a id='911d8f6d-20ad-4a83-965f-e4001df08db0'></a>

McKinsey & Company

<a id='1608c85f-7136-4d19-a8e0-298952456a2a'></a>

4

<!-- PAGE BREAK -->

<a id='b98abf8b-5f24-494a-9fb8-2adf6a5377f1'></a>

Our research suggests governments must consider six important
dimensions to transform sub-soil wealth into long-term prosperity

<a id='505e8016-f9fc-4238-9d96-6e0bf73a9d8b'></a>

<::objectives and topics: diagram::>Objectives Topics
Produce resources efficiently 1 Institutions and governance
                               2 Infrastructure

Capture value from resources   3 Fiscal policy/competitiveness
                               4 Local content

Transform value into long-term 5 Spending the windfall
development                    6 Economic diversification

<a id='a92f89bb-cb2d-4b7a-a654-e35c63501c32'></a>

McKinsey & Company

<a id='fed6e2b9-65d9-4eb9-96c3-82baba8fa8cf'></a>

5

<!-- PAGE BREAK -->

<a id='c0e94dbc-bdfc-476d-a25e-835b0c5ac457'></a>

Three factors are putting pressure on the social contract between
extractive companies and resource-driven countries

<a id='f85982b7-06a5-48c7-9064-656b63004e04'></a>

<::logo: [Unknown]RISKRed cubes stacked vertically, spelling out "RISK" in white letters::>

<a id='3b949d76-b273-4569-b0cc-88cac848f515'></a>

1. **High and volatile resource prices.** Volatile resource prices have led to significant choppiness in resource rents and increased the likelihood that governments feel "cheated" and seek to renegotiate terms.

<a id='ce0cc0c8-fee7-46be-905b-60725bf9f25b'></a>

2. New projects are **bigger** and **more complex**. Exploration and production are increasingly moving toward deposits which are environmentally and logistically challenging and geologically complex. This is driving up project costs and increasing the risk of delays.

<a id='a8cd4a3d-b877-4f95-8623-d42eeefad181'></a>

3. Projects are a large share of the economies. Historically, petroleum projects have been on a huge scale relative to their host economies, but today some mining projects are on a similar relative scale.

<a id='a02c9269-4941-4200-ade6-9be1873572cb'></a>

McKinsey & Company

<a id='92192288-6c17-4456-8ef8-d5923f683710'></a>

6

<!-- PAGE BREAK -->

<a id='8223c5f3-d0a6-4336-934f-218ec7df5b8d'></a>

Companies need to shift their approach in managing these risks – moving it from "art" to "science"

<a id='26dc6e06-cbfb-4549-939c-37ee5647f68d'></a>

Develop a detailed understanding of the country context
1 10 dimensions matter, which go beyond simple political risk considerations

<::Circular diagram with a central dark blue circle, surrounded by a light blue ring divided into segments, each containing an icon. Icons include: euro symbol, wrench, building, group of people, handshake, and recycle symbol.
: figure::>

<a id='7e993b35-08c6-449a-a670-6528aaf5d806'></a>

**Properly understand the risk (and upside)**

2. What type of risks does under-performance create?
   Which are possible consequences and what is the magnitude/impact if risk materializes?

<a id='22d431a2-0c0e-4d5d-b443-cc4e1cfcba7e'></a>

<::A risk matrix chart with 'Risk impact' on the vertical axis (ranging from Low to High) and 'Risk likelihood' on the horizontal axis (ranging from Low to High). The chart is divided into four quadrants. The top-left quadrant contains the letters B and K. The bottom-left quadrant contains A, E, and J. The top-right quadrant is shaded blue and contains C and G. The bottom-right quadrant contains D, F, L, I, and H. A legend in the top-right corner indicates that the blue shaded area represents 'Focus of risk avoidance'.
: figure::>

<a id='80d2d358-b6eb-4b63-89ac-de9e564c61a6'></a>

## Understand performance versus expectations
3 To what degree are company priorities aligned with key stakeholder priorities?
How is the company performing vis-à-vis those expectations?

<a id='943ee9ae-488c-40f6-9d76-7de76d7475f6'></a>

2. In depth, qualitative assessment of action ROI
Project-specific cost curve
<::A bar chart titled "Project-specific cost curve".
The Y-axis is labeled "Short-term value to company", with "High" at the top and "Low" at the bottom.
The X-axis represents different actions/initiatives, implicitly ordered by "Value to society".
A note states: "Width of bar = total value impact".

The bars, from left to right, represent the following actions/initiatives and their short-term value to the company:
- Transport infrastructure (negative value)
- Healthcare (negative value)
- Education (negative value)
- Water preservation (negative value)
- Air pollution remediation (negative value)
- Land preservation & rehabilitation (negative value)
- Biodiversity preservation (negative value)
- Energy infrastructure (negative value)
- Other infrastructure (slightly negative value)
- Housing & homelessness (slightly positive value)
- National tax transparency & anti-corruption (positive value)
- Workforce development (positive value)
- Supplier development (positive value)
- Downstream sector development (positive value)
- Vocational training & job matching (positive value)
- Water infrastructure (positive value)
- Waste management (positive value)
- Tracking impact (positive value)
- Engaging in public relations (positive value)
- Local tax transparency & anti-corruption (positive value)
- Building strong relationships (positive value)
- Safety (positive value)
- Clarifying needs & expectations (positive value)
- Forming a joint vision (positive value, highest)
: chart::>

<a id='583fe2b1-2e33-4cbf-83cf-992a0cd10f1a'></a>

### Explore bold moves that create a symbiotic relationship

4. Don't optimize for the short-term

*   Understand network of decision-makers and influencers
*   Make clear to government what is at stake
*   Link the company's operations to the country vision

<a id='8113e9ba-c8a4-4a93-8646-175e4ae34c0e'></a>

<::Flowchart:A multi-phase process is outlined, moving from left to right.

Phase 0: Preparation
* Understand CSR work done to date, e.g., align with strategic framing and specific deep dives conducted
* Prepare reference case contacts

Phase 1: Diagnostic
* Tailor asset specific CSR assessment (SE version of Compass)
* Conduct diagnosis on site, interviews with management, workforce and external stakeholders
* Prepare joint SE and McK team, e.g., joint 'boot camp'

Phase 2: Risk assessment
* Conduct local workshops with stakeholders to identify and evaluate risks
* Leverage McK risk database to categorize and estimate risks
* Rank risks, highlight any high-impact, high likelihood
* Calculate NPV for all important risks

Phase 3: Develop portfolio of initiatives
* Leverage McK CSR database to generate ideas for initiatives
* Conduct local workshops do develop adequate initiatives
* Iterate initiatives with stakeholders to ensure buy-in, feasibility and efficiency
* Rank initiatives based on ROI
* Select mix of initiatives

Phase 4: Action planning
* Develop detailed action plan for implementation of each initiative
* Include local stakeholders (internal and external) in planning
* Launch implementation teams
: flowchart::>

<a id='915fe53f-95af-4419-8105-da51ddc77883'></a>

McKinsey & Company

<a id='b43e1dd6-ba77-4dc4-82b2-e8fd03009104'></a>

7