"""Discovers SKILL.md manifests and loads Python run modules directly."""

from __future__ import annotations

import importlib.util
import logging
from pathlib import Path
from typing import Any, Callable, Coroutine

import yaml
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

_FRONTMATTER_DELIMITER = "---"


class SkillParameter(BaseModel):
    name: str
    type: str = "string"
    required: bool = False
    default: object = None
    description: str = ""


class SkillManifest(BaseModel):
    name: str
    description: str
    trigger: str = ""
    category: str = ""
    parameters: list[SkillParameter] = Field(default_factory=list)
    folder_path: str = ""
    skill_md_raw: str = ""


# Type for the skill's async run function
SkillRunFn = Callable[..., Coroutine[Any, Any, dict]]


def _parse_skill_md(path: Path) -> SkillManifest | None:
    try:
        text = path.read_text(encoding="utf-8")
    except Exception as exc:
        logger.warning("Could not read %s: %s", path, exc)
        return None

    parts = text.split(_FRONTMATTER_DELIMITER, maxsplit=2)
    if len(parts) < 3:
        return None

    try:
        meta = yaml.safe_load(parts[1].strip())
    except yaml.YAMLError:
        return None

    if not isinstance(meta, dict) or "name" not in meta or "description" not in meta:
        return None

    params = [SkillParameter(**p) for p in meta.get("parameters", []) if isinstance(p, dict)]
    return SkillManifest(
        name=meta["name"],
        description=meta["description"],
        trigger=meta.get("trigger", ""),
        category=meta.get("category", ""),
        parameters=params,
        folder_path=str(path.parent),
        skill_md_raw=parts[2].strip(),
    )


def _load_run_module(folder: Path, skill_name: str) -> SkillRunFn | None:
    """Import run.py from the skill folder and return its `run` function."""
    run_path = folder / "run.py"
    if not run_path.exists():
        logger.warning("No run.py found for skill '%s' at %s", skill_name, folder)
        return None

    spec = importlib.util.spec_from_file_location(
        f"skill_{skill_name}", str(run_path)
    )
    if spec is None or spec.loader is None:
        logger.warning("Could not create module spec for %s", run_path)
        return None

    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        logger.error("Failed to load %s: %s", run_path, exc)
        return None

    run_fn = getattr(module, "run", None)
    if run_fn is None:
        logger.warning("run.py for skill '%s' has no `run` function", skill_name)
        return None

    if not callable(run_fn):
        logger.warning("`run` in skill '%s' is not callable", skill_name)
        return None

    return run_fn


class SkillRegistry:
    def __init__(self) -> None:
        self._skills: dict[str, SkillManifest] = {}
        self._runners: dict[str, SkillRunFn] = {}

    def load_from_directory(self, root: str | Path) -> None:
        root_path = Path(root)
        if not root_path.is_dir():
            logger.warning("Skills directory does not exist: %s", root_path)
            return

        for skill_path in root_path.rglob("SKILL.md"):
            manifest = _parse_skill_md(skill_path)
            if not manifest:
                continue

            run_fn = _load_run_module(skill_path.parent, manifest.name)
            if run_fn is None:
                logger.warning("Skipping skill '%s' — no valid run function", manifest.name)
                continue

            self._skills[manifest.name] = manifest
            self._runners[manifest.name] = run_fn
            logger.info(
                "Registered skill: %s [%s] (%s)",
                manifest.name, manifest.category, skill_path.parent,
            )

    def get(self, name: str) -> SkillManifest | None:
        return self._skills.get(name)

    def get_runner(self, name: str) -> SkillRunFn | None:
        return self._runners.get(name)

    def list_all(self) -> list[SkillManifest]:
        return list(self._skills.values())

    def summary_for_planner(self) -> str:
        if not self._skills:
            return "No skills are registered."
        by_cat: dict[str, list[SkillManifest]] = {}
        for s in self._skills.values():
            by_cat.setdefault(s.category or "other", []).append(s)
        lines: list[str] = []
        for cat, skills in sorted(by_cat.items()):
            lines.append(f"\n### {cat}")
            for s in skills:
                param_desc = ", ".join(
                    f"{p.name}: {p.type}{'*' if p.required else ''}" for p in s.parameters
                )
                lines.append(f"- **{s.name}** — {s.description}")
                if s.trigger:
                    lines.append(f"  Trigger: {s.trigger}")
                if param_desc:
                    lines.append(f"  Params: ({param_desc})")
        return "\n".join(lines)


registry = SkillRegistry()
