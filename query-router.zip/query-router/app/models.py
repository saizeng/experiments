"""Domain models for the query router."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"


# ---------------------------------------------------------------------------
# Skill manifest (parsed from SKILL.md frontmatter)
# ---------------------------------------------------------------------------

class SkillParameter(BaseModel):
    name: str
    type: str = "string"
    required: bool = False
    default: Any = None
    description: str = ""


class SkillManifest(BaseModel):
    """Parsed representation of a SKILL.md file."""
    name: str
    description: str
    trigger: str = ""
    category: str = ""              # e.g. data_source, search, analysis, generation
    parameters: list[SkillParameter] = Field(default_factory=list)
    folder_path: str = ""           # absolute path to skill folder
    skill_md_raw: str = ""          # full markdown body (below frontmatter)


# ---------------------------------------------------------------------------
# Execution plan produced by the Planner
# ---------------------------------------------------------------------------

class PlanStep(BaseModel):
    """A single step in the execution plan."""
    step_id: int
    description: str                # human-readable intent of this step
    skill_name: str                 # which skill to invoke
    query: str                      # the sub-question or command for this skill
    depends_on: list[int] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(default_factory=dict)


class ExecutionPlan(BaseModel):
    """Full plan emitted by the Planner."""
    original_question: str
    reasoning: str = ""
    steps: list[PlanStep]


# ---------------------------------------------------------------------------
# Execution results
# ---------------------------------------------------------------------------

class StepResult(BaseModel):
    step_id: int
    skill_name: str = ""
    status: StepStatus = StepStatus.PENDING
    data: Any = None
    error: str | None = None


class QueryResult(BaseModel):
    question: str
    plan: ExecutionPlan
    step_results: list[StepResult] = Field(default_factory=list)
    answer: str = ""


# ---------------------------------------------------------------------------
# API request / response
# ---------------------------------------------------------------------------

class QueryRequest(BaseModel):
    question: str
    context: dict[str, Any] = Field(default_factory=dict)


class QueryResponse(BaseModel):
    answer: str
    plan: ExecutionPlan
    step_results: list[StepResult]
