"""LLM-based query planner.

Sends the user question + the full skill registry to an LLM and gets back
a structured ExecutionPlan routing to specific skills.
"""

from __future__ import annotations

import json
import logging

import anthropic

from app.config import settings
from app.models import ExecutionPlan
from app.skill_registry import registry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

PLANNER_SYSTEM_PROMPT = """\
You are a query planner for a financial services platform.

You have access to a set of **skills** — executable scripts that each do one
thing well. Every data source, search engine, and tool is wrapped as a skill.
Your job is to decompose the user's question into steps and route each step
to the right skill.

## Available Skills
{skills_block}

## Your Task

Given a user question, produce a JSON execution plan.

### Rules
- Decompose compound questions into the smallest independent sub-questions.
- Route each sub-question to exactly one skill by its `name`.
- If a step needs output from a prior step, set `depends_on` to that step's
  `step_id`. The executor will inject the upstream result into the query
  via the placeholder {{step_N_results}}.
- Independent steps should have empty `depends_on` — they run in parallel.
- When unsure which skill to use, pick the most relevant one. If two skills
  could answer the same sub-question, pick the one whose description is the
  closest match.
- If the question needs external/real-time information not covered by any
  data-source skill, use the web search skill.
- If no skill can answer a sub-question, omit that step and note the gap
  in your reasoning.
- Step IDs are sequential integers starting at 1.
- Include any required parameters for the skill in the `parameters` object.

### Output Format (JSON only, no markdown fences)
{{
  "reasoning": "brief chain-of-thought explaining your routing decisions",
  "steps": [
    {{
      "step_id": 1,
      "description": "what this step answers",
      "skill_name": "name_of_skill",
      "query": "the sub-question or command to send to this skill",
      "depends_on": [],
      "parameters": {{}}
    }}
  ]
}}
"""

# ---------------------------------------------------------------------------
# Few-shot examples
# ---------------------------------------------------------------------------

FEW_SHOT_EXAMPLES = [
    # 1 — Single skill: structured data
    {
        "role": "user",
        "content": "What is Acme Corp's total revenue for Q3 2025?",
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "reasoning": "Quantitative revenue question → structured_data skill.",
            "steps": [{
                "step_id": 1,
                "description": "Look up Acme Corp Q3 2025 revenue",
                "skill_name": "structured_data",
                "query": "What is Acme Corp's total revenue for Q3 2025?",
                "depends_on": [],
                "parameters": {},
            }],
        }),
    },
    # 2 — Single skill: unstructured docs
    {
        "role": "user",
        "content": "What does the Acme Corp merger agreement say about earnout provisions?",
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "reasoning": "Document content question → unstructured_docs skill.",
            "steps": [{
                "step_id": 1,
                "description": "Find earnout provisions in Acme merger agreement",
                "skill_name": "unstructured_docs",
                "query": "What does the Acme Corp merger agreement say about the earnout provisions?",
                "depends_on": [],
                "parameters": {},
            }],
        }),
    },
    # 3 — Parallel: two skills, independent
    {
        "role": "user",
        "content": "What was Acme Corp revenue last quarter and what does their merger agreement say about earnouts?",
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "reasoning": "Two independent sub-questions: revenue (structured_data) and merger clause (unstructured_docs). Run in parallel.",
            "steps": [
                {
                    "step_id": 1,
                    "description": "Look up Acme Corp revenue last quarter",
                    "skill_name": "structured_data",
                    "query": "What was Acme Corp's revenue last quarter?",
                    "depends_on": [],
                    "parameters": {},
                },
                {
                    "step_id": 2,
                    "description": "Find earnout provisions in Acme merger agreement",
                    "skill_name": "unstructured_docs",
                    "query": "What does the Acme Corp merger agreement say about earnouts?",
                    "depends_on": [],
                    "parameters": {},
                },
            ],
        }),
    },
    # 4 — Sequential: structured → unstructured (dependency)
    {
        "role": "user",
        "content": "Show me all deals over $50M where the merger agreement had a material adverse change clause.",
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "reasoning": "First filter deals by size (structured_data), then inspect each deal's merger agreement for MAC clause (unstructured_docs). Step 2 depends on step 1.",
            "steps": [
                {
                    "step_id": 1,
                    "description": "Find all deals with value over $50M",
                    "skill_name": "structured_data",
                    "query": "List all deals with deal value over $50M. Return deal IDs and names.",
                    "depends_on": [],
                    "parameters": {},
                },
                {
                    "step_id": 2,
                    "description": "Check merger agreements for MAC clauses",
                    "skill_name": "unstructured_docs",
                    "query": "For the following deals: {step_1_results}, check each merger agreement for material adverse change (MAC) clauses. Summarize findings per deal.",
                    "depends_on": [1],
                    "parameters": {},
                },
            ],
        }),
    },
    # 5 — Web search + data source
    {
        "role": "user",
        "content": "How does our Acme deal compare to recent similar acquisitions in the market?",
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "reasoning": "Need internal deal data (structured_data) and external market comps (web_search). Independent, run in parallel.",
            "steps": [
                {
                    "step_id": 1,
                    "description": "Get Acme deal details",
                    "skill_name": "structured_data",
                    "query": "Get full deal details for the Acme acquisition deal including valuation, structure, and timeline.",
                    "depends_on": [],
                    "parameters": {},
                },
                {
                    "step_id": 2,
                    "description": "Find comparable recent acquisitions",
                    "skill_name": "web_search",
                    "query": "Recent comparable acquisitions similar to Acme deal size and sector",
                    "depends_on": [],
                    "parameters": {},
                },
            ],
        }),
    },
    # 6 — Three skills: data + docs + generation
    {
        "role": "user",
        "content": "Generate a PDF report for the Globex acquisition deal including risk factors from the merger agreement.",
    },
    {
        "role": "assistant",
        "content": json.dumps({
            "reasoning": "Need deal data (structured_data), risk factors from docs (unstructured_docs), then generate the report (generate_report). Sequential chain.",
            "steps": [
                {
                    "step_id": 1,
                    "description": "Fetch Globex acquisition deal data",
                    "skill_name": "structured_data",
                    "query": "Get full deal details for the Globex acquisition deal.",
                    "depends_on": [],
                    "parameters": {},
                },
                {
                    "step_id": 2,
                    "description": "Extract risk factors from merger agreement",
                    "skill_name": "unstructured_docs",
                    "query": "What are the risk factors listed in the Globex merger agreement?",
                    "depends_on": [],
                    "parameters": {},
                },
                {
                    "step_id": 3,
                    "description": "Generate PDF report combining deal data and risk factors",
                    "skill_name": "generate_report",
                    "query": "Generate a PDF report for the Globex acquisition using deal data from {step_1_results} and risk factors from {step_2_results}.",
                    "depends_on": [1, 2],
                    "parameters": {"format": "pdf"},
                },
            ],
        }),
    },
]


# ---------------------------------------------------------------------------
# Planner class
# ---------------------------------------------------------------------------

class Planner:
    def __init__(self) -> None:
        self._client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)

    async def plan(self, question: str) -> ExecutionPlan:
        """Decompose *question* into an ExecutionPlan routed to skills."""

        skills_block = registry.summary_for_planner()
        system = PLANNER_SYSTEM_PROMPT.format(skills_block=skills_block)

        messages = [
            *FEW_SHOT_EXAMPLES,
            {"role": "user", "content": question},
        ]

        response = await self._client.messages.create(
            model=settings.planner_model,
            max_tokens=2048,
            system=system,
            messages=messages,
            temperature=0,
        )

        raw = response.content[0].text.strip()
        # Strip markdown fences if the model adds them
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1]
        if raw.endswith("```"):
            raw = raw.rsplit("```", 1)[0]

        try:
            plan_data = json.loads(raw)
        except json.JSONDecodeError:
            logger.error("Planner returned invalid JSON: %s", raw)
            raise ValueError(f"Planner produced invalid JSON:\n{raw}")

        # Validate that every step references a known skill
        known = {s.name for s in registry.list_all()}
        for step in plan_data["steps"]:
            if step["skill_name"] not in known:
                logger.warning(
                    "Planner referenced unknown skill '%s' — available: %s",
                    step["skill_name"],
                    sorted(known),
                )

        return ExecutionPlan(
            original_question=question,
            reasoning=plan_data.get("reasoning", ""),
            steps=plan_data["steps"],
        )
