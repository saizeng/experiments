<a id='1a794441-2860-4f75-9971-f5ec99d03ece'></a>

<::logo: [Unknown Brand]
RR-1
The logo features bold, black sans-serif text "RR-1" on a white background.::>

<a id='e125494c-7c89-4ffc-9605-c91e2d61f581'></a>

<::logo: City of Vancouver
CITY OF VANCOUVER
A stylized black lotus flower symbol is positioned to the left of the text.::>

<a id='d63b1825-f42e-4ff5-bef3-b74703af1761'></a>

ADMINISTRATIVE REPORT

<a id='9fb236cf-e06b-469a-97c8-24dc9e68d4ea'></a>

Report Date: October 24, 2017
Contact: Anne Nickerson
Contact No.: 604.873.7776
RTS No.: 11780
VanRIMS No.: 08-2000-20
Meeting Date: January 16, 2018

<a id='6210980b-5294-4f8a-9914-47032869b7f6'></a>

TO: Vancouver City Council

FROM: Chief Human Resources Officer

SUBJECT: Gender Equality Update

<a id='fd33bfb1-c9cf-4a19-acb2-b5388073fa77'></a>

_**RECOMMENDATION**_
A. THAT Council receive the review of the City's 2005 Gender Equality Strategy (attached as Appendix A).
B. THAT Council approve the updated strategy entitled, "Vancouver: A City for All Women, Women's Equity Strategy 2018-2028" with a focus on Phase 1 Actions (attached as Appendix B).
C. THAT Council direct staff to provide a progress report in 2019 and outline next phase actions, in consultation with the Women's Advisory Committee.
D. THAT Council refer the report to the Vancouver Public Library Board and the Vancouver Police Department Board for information and to request their support of the updated strategy.

<a id='94c9cae9-27a9-4d49-a43a-c5f727139898'></a>

**REPORT SUMMARY**

This report provides both a review and update of the City's 2005 Gender Equality Strategy (GES), in response to Council's April 2016 motion "Because It's 2016: Action on Gender Equality". The motion included direction to staff to work with the Women's Advisory Committee to review the 2005 Gender Equality Strategy and update it, with consideration of successful approaches and national/ provincial context, and integration of more recently adopted policy, such as that in Healthy City.

<a id='efea08fe-b9c2-4b87-97ea-cbe169200e88'></a>

The 2005 GES provided a comprehensive snapshot of women's lives in Vancouver, followed by the City's vision, principles, aims and actions assigned to lead departments. In conducting the review, staff consulted with each lead department identified in the strategy and compiled updates. Of the total 28 actions, the majority or over 80% were completed, ongoing and/or integrated into existing work (see Appendix A). Accomplishments from the 2005 strategy are

<!-- PAGE BREAK -->

<a id='9a75cf29-8fdf-4563-b22b-7f6bd16d89a5'></a>

Gender Equality Update - 11780

<a id='c44f0942-6535-4674-96f6-4920d11ea3ca'></a>

2

<a id='d9b87971-96f3-4cb0-9e29-8cb78dd6ce5c'></a>

many, including the establishment of the Women's Advisory Committee and annual International Women's Day events hosted by the City which highlight the contributions of diverse women in our community.

<a id='9215f73e-e338-4721-8880-8baaa98b048e'></a>

In conducting the update to the 2005 GES, staff conducted best practice research and broad consultations with the Women's Advisory Committee, the public, staff, subject matter experts and other key stakeholders, including community organizations. Five prominent themes were identified, initially by the Women's Advisory Committee and then confirmed through input from the public. These include: Safety, Childcare, Housing, Leadership/ Representation (within the City of Vancouver as an employer) and Intersectional Lens, a foundational approach to strengthen City processes and inform decision-making to better mitigate the impacts of interacting social contexts such as gender, race, class and ability. In addition to best practice research and consultations with a variety of stakeholders, staff also conducted meetings internally with departmental teams whose work directly relates to these five themes in order to gain further input and ensure alignment with related work priorities. The primary orientation with the City's vision of a Healthy City for All allows for best practice alignment within the framework of City's Healthy City Strategy, building on the World Health Organization's emphasis on international health promotion through a 'social determinants of health' framework.

<a id='e8574dfa-0497-4225-9f83-3b353a275831'></a>

Based on all of the input received, and given the City's mandate, staff are recommending a number of Phase 1 Actions (2018-2019) related to the above five priority themes for implementation by an Action Team within the first two years of a ten year strategy. Priority goals and objectives parallel the City's Healthy City Strategy 'determinants of health' approach and include indicators and targets that have been designed to address inequalities at a municipal level. The Healthy City Strategy is guided by a vision of A Healthy City for All, ensuring we collectively pursue a strong and inclusive focus on inequity, including gender inequity. These principles also emphasize the importance of including meaningful involvement in the broader public, private and civic sectors.

<a id='11454c25-8ec1-435e-87b7-ca7c42bee3c3'></a>

We will measure our progress and report out regularly. It is recommended that staff provide Council with a progress report on Phase 1 Actions in 2019 and outline next phase actions, in consultation with the Women's Advisory Committee and with consideration of current context, related work priorities and existing opportunities. This approach takes into account the evolving landscape, allowing the City to be responsive to emerging opportunities and changing priorities both internally and externally. Each priority theme includes an overarching goal and specific objective, and incorporates at least one of four strategies: education and awareness, partnerships and collaboration, policy and/or data. Each theme is outlined below by goal, objective, strategies and recommended Phase 1 Actions by Department Lead (Table 1).

<a id='0a8fe5a9-c8d6-492a-aacf-c651a5318551'></a>

TABLE 1

<a id='7c4a6ff1-e52a-4a47-aac0-e15c55c08bf5'></a>

Phase 1 Actions
SAFETY
<table id="1-1">
<tr><td id="1-2">GOAL</td><td id="1-3">Vancouver is a safe city in which all women are secure and free from crime and violence, including sexual assault.</td></tr>
<tr><td id="1-4">OBJECTIVE</td><td id="1-5">By 2025, women&#x27;s sense of safety will be increased by 10%.</td></tr>
<tr><td id="1-6">STRATEGIES</td><td id="1-7">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="1-8">PHASE 1</td><td id="1-9">1. Join UN Women&#x27;s Global Flagship Initiative “Safe Cities and</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='a0f4dd8b-c551-4609-a90a-de04e793b5b2'></a>

Gender Equality Update - 11780

<a id='879fe02a-bdc0-4617-8bc7-041eccd0898a'></a>

3

<a id='af818114-7abf-4d4b-8281-28ff6f5544a4'></a>

<table id="2-1">
<tr><td id="2-2">ACTIONS (2018-2019)</td><td id="2-3">Safe Public Spaces&quot; and conduct a scoping study on women&#x27;s safety. (Lead: Community Services) 2. Identify community partners to collaborate on an annual public campaign to raise awareness on violence against women. (Lead: Communications, Human Resources) 3. Update WAC annually on progress in ensuring women&#x27;s safety/ needs in the neighbourhood planning &amp; development process. (Lead: Engineering, Planning, Urban Design &amp; Sustainability) 4. Formalize senior staff coordination and oversight of inter- departmental response to critical issues in the Downtown Eastside, including women&#x27;s safety and related issues. (Lead: City Manager&#x27;s Office)</td></tr>
</table>

<a id='b7befc77-75e0-4d9b-9f02-9c6e8b49e992'></a>

CHILDCARE
<table id="2-4">
<tr><td id="2-5">GOAL</td><td id="2-6">Women&#x27;s full participation in the workforce and engagement in public life is supported by affordable and accessible quality childcare for children.</td></tr>
<tr><td id="2-7">OBJECTIVE</td><td id="2-8">By the end of 2018, 1,000 new childcare spaces will be added from the 2015 baseline. (Aligns with current childcare target identified in the Healthy City Action Plan, 2015-2018)</td></tr>
<tr><td id="2-9">STRATEGIES</td><td id="2-a">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy</td></tr>
<tr><td id="2-b">PHASE 1 ACTIONS (2018-2019)</td><td id="2-c">1. Share input from the strategy consultations for consideration in the City&#x27;s updated childcare strategy. (Lead: Human Resources) 2. Partner with senior levels of government to significantly increase affordable, quality childcare through creating new childcare spaces, and replacing aging centres. (Lead: Community Services) 3. Identify child-friendly provisions to accommodate participation by families with children at Council and Public Hearings at City Hall. (Lead: City Clerk&#x27;s)</td></tr>
</table>

<a id='2dd10032-032b-4566-8617-bf5baa760ffd'></a>

HOUSING
<table id="2-d">
<tr><td id="2-e">GOAL</td><td id="2-f">A range of affordable housing choices is available for women of diverse backgrounds and circumstances, including single parents, seniors, newcomers, and those facing vulnerable conditions.</td></tr>
<tr><td id="2-g">OBJECTIVE</td><td id="2-h">72,000 new homes for renters, families and vulnerable residents over the next ten years. (Aligns with current Housing Vancouver Strategy targets)</td></tr>
<tr><td id="2-i">STRATEGIES</td><td id="2-j">Education &amp; Awareness, Data, Partnerships &amp; Collaboration</td></tr>
<tr><td id="2-k">PHASE 1 ACTIONS (2018-2019)</td><td id="2-l">1. Identify how to determine extent of women&#x27;s hidden homelessness to better understand its full scope. (Lead: Community Services) 2. Research integration of outreach role within Coordinated Access Centre to liaise with women-serving organizations and identify women in need of priority housing. (Lead: Community Services) 3. Share input from the strategy consultations for consideration in the implementation of the Housing Vancouver Strategy. (Lead: Human Resources)</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='7cc19367-ec86-420f-9424-ff595121db28'></a>

Gender Equality Update - 11780

<a id='b34b58ab-2050-424b-b48a-8bb3227a37bb'></a>

4

<a id='b1a77262-d46c-4c41-9ad4-342e41d2a54c'></a>

LEADERSHIP & REPRESENTATION
<table id="3-1">
<tr><td id="3-2">GOAL</td><td id="3-3">The City will elevate the visibility, influence, representation and contribution of all women in the organization by providing equitable access to work opportunities, including leadership roles and other historically under-represented occupations and by creating and implementing initiatives to specifically enhance their development and leadership.</td></tr>
<tr><td id="3-4">OBJECTIVE</td><td id="3-5">Increase new hire ratios: • The City will increase new hires for Senior Management roles to 50 per cent women. • By 2020, the proportion of female new hires in under-represented occupations* will be increased by at least 5% over the 2017 baseline.</td></tr>
<tr><td id="3-6">STRATEGIES</td><td id="3-7">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="3-8">PHASE 1 ACTIONS (2018-2019)</td><td id="3-9">1. Sign Minerva BC&#x27;s Face of Leadership™ Diversity Pledge, making a public commitment to support women&#x27;s advancement in leadership in our workforce and in our community. (Lead: Human Resources) 2. Develop and implement a Breastfeeding Policy for City staff. (Lead: Human Resources) 3. Conduct focus groups with female staff in leadership and under-represented positions.(Lead: Human Resources) 4. Measure and report annually on the City&#x27;s workforce composition including positions and compensation. (Lead: Human Resources) 5. Address potential bias in the hiring process by training recruitment staff to recognize and mitigate unconscious bias. (Lead: Human Resources)</td></tr>
</table>
* Examples of under-represented occupations include Information Technology (technical
positions), Firefighting, Trades & Operations, Engineers and Engineers-in-Training.

<a id='e0e02c28-8837-452a-8ad3-7e6a1c5f2d9c'></a>

INTERSECTIONAL LENS
<table id="3-a">
<tr><td id="3-b">GOAL</td><td id="3-c">The City&#x27;s decisions, programs and plans are informed by an intersectional lens to ensure that all citizens have equitable access, inclusion and participation in community life.</td></tr>
<tr><td id="3-d">OBJECTIVE</td><td id="3-e">In 2018, an intersectional framework will be established for City departments.</td></tr>
<tr><td id="3-f">STRATEGIES</td><td id="3-g">Education &amp; Awareness, Policy</td></tr>
<tr><td id="3-h">PHASE 1 ACTIONS (2018-2019)</td><td id="3-i">1. Pilot intersectional framework. (Lead: Community Services) 2. Introduce the application of an intersectional lens to senior staff through training in Gender-Based Analysis Plus (GBA+), offered through Status of Women Canada. (Lead: Human Resources) 3. Bring forward to Council revised Civic Assets Naming Guidelines that include gender diversity. (Lead: City Clerk&#x27;s)</td></tr>
</table>

<a id='3000b4e0-2bf6-4b71-8c73-5efd8230a8bb'></a>

While the 2005 strategy is named "Gender Equality", staff are recommending changing the strategy name to "Women's Equity". The reasons for this are twofold: 1) 'gender' is a

<!-- PAGE BREAK -->

<a id='9ee9afe4-2057-4663-82ab-ed17fff6859c'></a>

Gender Equality Update - 11780

<a id='c4a744d3-e7bc-49f1-87fb-2e1d58b02d0c'></a>

5

<a id='2fc53c6c-a76e-4c12-b38c-79d5b87d553d'></a>

spectrum which includes more than women and the strategy's sole focus is on women and those who identify as women, and 2) 'equality' promotes fairness by treating everyone the same, assuming that everyone starts from the same place and needs the same help, whereas 'equity' promotes fairness by taking respective needs and differences into account. Equity aims to give everyone what they need to be successful with equality as the outcome. The recommended update to the 2005 GES is titled Vancouver: A City for All Women, Women's Equity Strategy 2018 - 2028.

<a id='af9cf141-aac9-4468-80f6-1327f483ebcd'></a>

**COUNCIL AUTHORITY/PREVIOUS DECISIONS**

**Empowering Citizen Voices on Citizen Advisory Committees:** In February 2009, Council passed a motion to create a number of citizen advisory committees, including the Women's Advisory Committee.

<a id='b8a718ed-da0f-4423-b687-507fa9b835dc'></a>

Health and Safety of Sex Workers: In July 2009, Council passed a motion directing staff to report back on a strategy for the City to address negative impacts of the survival street sex trade on sex workers and Vancouver neighbourhoods.

<a id='14aa12d9-8914-4c66-8f59-47842b92f785'></a>

"Preventing Sexual Exploitation and Protecting Vulnerable Adults and Neighbourhoods Affected by Sex Work: A Comprehensive Approach and Action Plan": In September 2011, Council adopted the report and directed staff to form a city-wide Task Force on Sex Work and Sexual Exploitation to implement the action plan. The Task Force was created in 2011 and worked towards implementing actions from the report.

<a id='c1d01075-4cc3-4cb7-aa59-b9468d6c23ad'></a>

Missing Women Commission of Inquiry: In January 2013, Council committed to implementing the recommendations directed to the City in the Inquiry's report, *Forsaken*.

<a id='072505ee-d2d5-485f-997e-4cb9dfff447f'></a>

"**Report back on Missing Women Commission of Inquiry and City Task Force on Sex Work and Sexual Exploitation**": In December 2013, Council adopted the report that included a direction to finalize the City's Sex Work Response Guidelines. These guidelines promote consistent, non-discriminatory, and respectful treatment of anyone engaged in sex work when accessing City services or interacting with City employees.

<a id='69338e78-6a72-45e9-9457-631cf7523e47'></a>

Mayor's Task Force on Mental Health and Addictions: In 2014, the Mayor's Task Force on Mental Health and Addictions committed to developing a Strategic Gender Framework for the inclusion of women, girls and gender variant communities to inform future City efforts.

<a id='617aa9de-a6f7-42ee-beff-4e1bdc140b7b'></a>

**"Caring for All" Phase I Report of the Mayor's Task Force on Mental Health and Addictions:** In September 2014, Council adopted the report and directed staff to work with partners to implement priority actions and develop a gender/ intersectional policy framework to address health and social inequities of women, girls and gender variant communities.

<a id='0d8f72a9-3ec6-4826-80d6-067f53cbd74c'></a>

Canadian Coalition of Municipalities Against Racism and Discrimination (CCMARD): In 2010,
the City of Vancouver joined CCMARD as a municipal partner in combating racism and
discrimination and fostering equality and respect for all citizens.

<a id='695d5393-a316-4360-9210-a576d9dc42b6'></a>

$10-a-Day Plan (Community Plan for a Public System of Integrated Early Care and
Learning): In 2011, City Council passed a motion to support the Plan to create a universal

<!-- PAGE BREAK -->

<a id='3e2e7471-3735-4bb9-a3c1-8d2f1159df24'></a>

Gender Equality Update - 11780

<a id='8c8b2cad-d390-42d3-95b2-e9afef524179'></a>

6

<a id='e65d19d6-13e5-46e6-88f7-a5249d447be0'></a>

public childcare system in British Columbia. The Plan was developed by the Early Childhood
Educators of BC and Coalition of Childcare Advocates of BC.

<a id='704bddfa-0879-4ccc-b3e8-8aa7129463ed'></a>

**Engaged City Taskforce:** In 2012, Council established the Engaged City Taskforce whose final report highlights the engagement of community members in the decisions that affect their lives, including specific strategies for engaging under-represented groups.
**Joint Childcare Council (JCC):** Established in 2012, the JCC is an initiative of the City of Vancouver, the Vancouver Board of Education and the Park Board. The JCC provides leadership in childcare and child development in Vancouver, working to support and deliver accessible, affordable, quality childcare spaces in the city.

<a id='75d31356-ebf7-40f8-b338-4262aceb0d04'></a>

Healthy City Strategy: In 2014, the City adopted the Healthy City Strategy which sets out as one of its guiding principles a "for all" intersectional lens. This ensures we pursue initiatives that are both universal for all residents and focused on specific populations most vulnerable to inequities, including women. The strategy sets out goals reflecting social determinants of health that enable people to flourish and reach their full potential, as well as targets, including housing, ability to make ends meet, safety & inclusion and a good start for children. The 2015-2018 Healthy City Action Plan includes a number of actions on child care, safety, housing and others.

<a id='cfb8efd5-86ec-453f-b162-3085af2e293c'></a>

Framework for City of Reconciliation: In 2014, Council approved the Framework for City of Reconciliation with three foundational components of mutual respect, strengthened partnerships and economic empowerment to guide the work of the City to best serve First Nations and urban Aboriginal communities, with the ultimate goal of broader inclusion of all communities.

<a id='3a699934-81a3-4e8d-86e3-992960a1f27e'></a>

Remarkable Women: From 2008 to 2014, the Remarkable Women poster series honoured local women who made significant contributions to arts, culture, sports, and community.

<a id='66cdb061-4fab-463e-b9d7-875ab1ffbfb3'></a>

International Women's Day, March 8: Each year, the City celebrates this day by highlighting issues of importance to local women, and by highlighting the important roles women in our communities play.

<a id='a26cca41-511f-4280-9e96-af225d56a4b4'></a>

Vancouver Poverty Reduction Plan: The June 2017 Council motion states that "poverty disproportionately affects women, people of colour, Aboriginal people, people dealing with disabilities and those with chronic illnesses - including mental illness..." and directs staff to report back with an update on the Vancouver Poverty Reduction Plan including opportunities for expanded action as a result of new provincial and federal commitments.

<a id='a948d4dd-dd7a-447f-a453-aec2dd434e98'></a>

Vancouver Capital Plan: The Capital Plan for 2015-2018 allocates investment for childcare to support Council-approved targets of adding 500 licensed childcare spaces for children ages 0-4, and 500 for school age child care.

<a id='bba75e5c-0d49-477c-b48e-16a4dda67a0b'></a>

Award of Excellence - Diversity and Inclusion: This annual civic award honours outstanding leadership to foster inclusion across diverse communities.

<a id='e4b279ae-4f0f-41d4-9088-fcd216d4d333'></a>

**Official Celebrations and Observances:** Council and staff recognize and value the contributions of Vancouver's diverse communities by observing internationally recognized days and significant events in our history. These include International Women's Day, Black History

<!-- PAGE BREAK -->

<a id='ebac5ebd-a55d-40ca-ba63-6f7b727ec9f7'></a>

Gender Equality Update - 11780

<a id='3744dfc9-1e3f-43bd-be5e-6aa7a1707841'></a>

7

<a id='168cf5e1-0588-4dd1-877c-d6ab31a40f0d'></a>

Month, International Day for the Elimination of Racism, National Aboriginal Day, and International Day of Persons with Disabilities.

<a id='9adbd26c-2c7a-494f-a8a7-53d59adbb7b4'></a>

**Access to City Services Without Fear (ACSWF)**: In April 2016, Council passed this policy to enable Vancouver residents with uncertain or no immigration status to access City services without the fear that the City will ask for and provide information on the immigration status of individuals to other public institutions or orders of government, unless required by law.
**Ensuring Trans Equality and an Inclusive Vancouver**: The July 2015 Council motion supported the passage of federal and provincial legislation ensuring Gender Identity and Gender Expression are protected under legislation. The motion also directed staff to consult with the LGBTQ2+ Advisory Committee and Parks related Steering Committee and report back on how the City could make civic facilities, operations and programs safe and inclusion spaces for Trans and Gender Variant communities. After consultations with these and other stakeholders, staff reported back to Council in July 2016 with recommended actions which were unanimously approved. Progress Reports are provided to Council annually.

<a id='fd871550-615f-4cea-84e1-f9a7cb7b447f'></a>

Downtown Eastside Women's Centre Association Capital Grant: In October 2017, Council approved a one-time Capital Grant of up to $250,000 towards renovations for the Downtown Eastside Women's Centre Association 24/7 Shelter in partnership with BC Housing.

<a id='859e678b-a88c-4761-b49a-86bd5e88cde1'></a>

***CITY MANAGER'S/GENERAL MANAGER'S COMMENTS***
The City Manager and Chief Human Resources Officer recommend approval of the foregoing as it will advance women's equality in our community and municipal workplace, and further strengthen the City of Vancouver's leadership role in the areas of equity, diversity and inclusion.

<a id='6242a417-7de9-4f27-aef4-f8442269e457'></a>

***REPORT***

***Background/Context***

On April 6, 2016, Council passed the motion "Because it's 2016: Action on Gender Equality" which outlined three directives. This report addresses the directive to staff "to work with the Women's Advisory Committee to establish a process to review the 2005 Gender Equality Strategy and update it, with an eye to successful approaches, integrating more recently adopted policy such as that in Healthy City and the Mental Health and Addictions Task Force, and taking into account a change in national and provincial context."

<a id='6f4173cd-c328-4f9b-afb2-9607e5e9b128'></a>

The review of the 2005 GES is attached as Appendix A, "Review of the 2005 Gender Equality Strategy for the City of Vancouver" and includes the status of action items. The vast majority of the 2005 actions were implemented and many are ongoing, including the Women's Advisory Committee and annual International Women's Day events. The review also provided key learnings, which have been taken into account in conducting the update to the strategy. These include:
* Appointing a responsible department for oversight and coordination of actions, including regular progress reports
* Aligning strategy and leverage actions, wherever possible, with existing City priorities and initiatives

<!-- PAGE BREAK -->

<a id='1f07ec05-5a17-4435-8b96-812eea5bf428'></a>

Gender Equality Update - 11780

<a id='942f3554-7002-4ef8-aca5-e77486670ed5'></a>

8

<a id='187fe47a-1a70-4a7c-9a72-8661d4a89627'></a>

• Ensuring actions are within the City's jurisdiction and have specific, measurable, achievable, relevant goals that can be measured over time.

<a id='fb50f619-2365-4fe3-bbb6-cad93f12b47c'></a>

The City of Vancouver has seen a great deal of change and growth since it adopted the 2005 GES. The current economic, housing, and childcare pressures facing the city are being felt more acutely by women. As Council's 2016 motion states, "Women and girls comprise a majority of residents (51 per cent) in Vancouver but on average have lower incomes, less housing security, more unpaid work, experience far greater rates of poverty and gender based violence, and in general have fewer opportunities than men and boys". The following are some of the ways in which women have been disproportionally impacted in recent years:

<a id='fc492865-74ba-4438-b9f4-a1f6a202c4c6'></a>

Women continue to be economically disadvantaged
Women make up 51 per cent of Vancouver's population¹ and continue to experience deeper economic and social disadvantages than their male counterparts (see below). A specific focus on improving the lived experiences of women is essential to achieving the City's Healthy City Strategy targets, in particular the goals of Making Ends Meet and Working Well

<a id='71c5000f-63eb-48c6-8af9-4acd0eb2755c'></a>

Women in Vancouver continue to earn less employment income than men. In 2015,
women's median after-tax employment income was $29,800/year compared with
men's $36,900/year.2 The Canadian Centre for Policy Alternatives estimates
$37,528/year as a minimum annual living wage for Vancouver.3

<a id='6ca0fcda-f556-49d2-8031-a291aa129bc5'></a>

This earnings gap is due to a number of factors:4

* Entrenched patterns of jobs segregated by gender, with jobs traditionally performed by women paying less than jobs traditionally performed by men. In 2015, 56.1 per cent of Canadian women were employed in teaching, nursing and related health occupations, social work, clerical or other administrative positions, or sales and services.5
* The majority of unpaid caregiving work is performed by women.6 Women reported spending an average of 50 hours per week on child care, more than double the time spent by men.7
* Inaccessible and unaffordable childcare. Vancouver has the third worst employment gap between men and women in Canada (11.8 per cent). The employment gap is greater in cities with high childcare costs.8
* A predominance of women in part-time and casual work. Across Canada approximately 76 per cent of those working part-time are women. Childcare was

<a id='34f7967b-45a8-4da8-a04a-984b11373134'></a>

1 Statistics Canada, Census 2016
2 Statistics Canada, Census 2016
3 Canadian Centre for Policy Alternatives, [Working for a Living Wage 2017](Working for a Living Wage 2017)
4 BC CEDAW Group, Women's Rights in British Columbia, Submission to the Committee on the Elimination of Discrimination against Women, 2016
5 Statistics Canada, Women in Canada: A Gender-Based Statistical Analysis, Women and Paid Work, Released: March 8, 2017, Corrected: March 9, 2017.
6 Statistics Canada, Portrait of caregivers, 2012, [http://www.statcan.gc.ca/pub/89-652-x/89-652-x2013001-eng.htm#a9](http://www.statcan.gc.ca/pub/89-652-x/89-652-x2013001-eng.htm#a9)
7 Statistics Canada, Families, Living Arrangements and Unpaid Work, December 2011, Catalogue no 899-503-X
8 Statistics Canada, Women in Canada: A Gender-Based Statistical Analysis, Women and Paid Work, Released: March 8, 2017, Corrected: March 9, 2017.

<!-- PAGE BREAK -->

<a id='6d3f8a42-c7c2-4b03-8368-87fa99f07d9c'></a>

Gender Equality Update - 11780

<a id='f67e22a0-7cb7-4645-9713-be62d3d8d7aa'></a>

9

<a id='68bde122-c1ec-4dd7-ad39-5b90c12950e7'></a>

cited by 25 per cent of women and 3.3 per cent of men as the reason for working part-time.⁹
* A low minimum wage which provides less than a poverty level income to full-time workers. Among BC's minimum wage workers aged 25-54, 70 per cent are women.¹⁰
* In addition, of those in Vancouver who rely on employment insurance, 60 per cent are women¹¹, and 53 per cent of social assistance recipients are women.¹² 90 per cent of single parents on income and disability assistance are female.¹³

<a id='90099320-cd00-4510-a145-656ddd3dd55e'></a>

Women's caregiving roles also have an impact on their earnings over their lifetime and impact their availability to work. A 2009 study found women with children earn 12 per cent less than women without children. This gap increases with the number of children, up to 20 per cent for women with three or more children. 14 The earnings can be partly explained by breaks in women's employment for maternity and parental leaves. Approximately 47 per cent of women take at least one maternity or parental leave over their careers, compared to 3.8 per cent of men. The average duration of a woman's combined parental and maternal leave is 1.3 years. 15

<a id='d5b8cc25-c0fa-4120-bbca-e5bca91f00c8'></a>

Women experience life in the City differently than men

The Healthy City Strategy includes the goal of Being and Feeling Safe and Included.
While 65 per cent of residents agree or strongly agree that they "feel safe walking
after dark in the City" 16, this statistic is very different for women than men. Only 57
per cent of women compared to 73 per cent of men reported feeling safe walking
after dark. Senior women (75+ years) and young women (18-24) reported feeling the
least safe, at only 47 per cent and 41 per cent, respectively. Similarly, only 44 per
cent of Aboriginal women and 41 per cent of Chinese women reported feeling safe
walking after dark. 17

<a id='df3cffe9-3b98-477c-a098-7cda43269e0c'></a>

_Violence against women exacerbates women's economic situation and experience of life in the city_

<a id='63031b6d-b631-46f9-956e-4f03c17830b8'></a>

Women's economic vulnerability places them at greater risk of intimate partner violence, and violence against women compound the inequalities women already face in society. ^18 Intimate partner violence, including both spousal and dating violence,

<a id='dec7609c-ac5e-46f8-8e7b-a07f53c9b2c7'></a>

9. Statistics Canada, Women in Canada: A Gender-Based Statistical Analysis, Women and Paid Work, Released: March 8, 2017, Corrected: March 9, 2017.
10. BC Federation of Labour. BC Minimum Wage and Women: The Facts. http://bcfed.ca/sites/default/files/attachments/BCFED%20minimum%20wage%20fact%20sheet%20-%20women.pdf
11. Statistics Canada. Table 111-0019 - Characteristics of individuals, tax filers and dependents 15 years of age and over receiving employment insurance by age groups and sex, annual (number) (accessed September 28, 2017)
12. Statistics Canada. Table 111-0025 - Characteristics of individuals, economic dependency profile of individuals, annual (accessed: September 28, 2017)
13. Ministry of Social Development and Poverty Reduction, BC Government, https://news.gov.bc.ca/releases/2015SDSI0043-001405
14. Statistics Canada, Earnings of women with and without children, March 2009 Perspectives, Catalogue no. 75-001-X
15. Statistics Canada, Women in Canada: A Gender-based Statistical Report, Women and Paid Work, March 9, 2017, Catalogue no. 89-503-X
16. Vancouver Coast Health, My Health My Community, 2014
17. IBID.
18. BC CEDAW Group, Women's Rights in British Columbia, Submission to the Committee on the Elimination of Discrimination against Women, 2016

<!-- PAGE BREAK -->

<a id='0d0dfd30-8866-4887-81c0-596e4cbae0e1'></a>

Gender Equality Update - 11780

<a id='106e3454-6002-45d7-86ac-54547d95bfda'></a>

10

<a id='f338f1e1-2d68-448f-8023-ce744b68120e'></a>

accounts for one in every four violent crimes reported to police and 80 per cent of victims were women. ^19

<a id='1874cec9-09a2-47a8-9adf-873ecbc139b8'></a>

Between 2004 - 2014, violent victimization rates declined for all crimes except sexual assault. Rates of sexual assault have remained stable. 20 Aboriginal women are three times more likely to be sexually assaulted than non-Aboriginal women. 21
Violence against women impacts their economic situation. Women who left abusive domestic partners relied on food banks at nearly 20 times the rate of average Canadians and for up to three years after leaving the abusive situation. Victims of sexual assault, the majority of which are women, report both immediate injuries and long term mental health impacts resulting in lost education, work and income. 22 One study found that 60 per cent of victims of intimate partner violence had either quit their jobs or were terminated as a result of the abuse. 23

<a id='60546425-27f2-4ec4-9609-a702d4ba9d56'></a>

Women continue to be under-represented in leadership and other occupations within the workforce

Increasing the representation of women in leadership and historically under-represented occupations is widely recognized as a persistent issue both locally and globally. It requires intentional measures on a wide ranging scale from employers, educational institutions, governments, Boards, media and others. As a municipal employer, the City of Vancouver plays a leadership role in committing to actions aimed at increasing the number of women in leadership and under-represented roles, such as firefighting and trades. The following table provides a snapshot of the representation of women as City employees (Table 2).24

<a id='268549c8-09a4-4db0-926f-97121841311f'></a>

19 Family violence in Canada: A Statistical Profile, 2011, http://www.statcan.gc.ca/pub/85-002-x/2013001/article/11805/11805-3-eng.htm#a1
20 Vancouver Police Department Crime Incident and Crime Rate Statistics, 2011-2016; Statistics Canada, Criminal Victimization in Canada, 2014
21 Statistics Canada, Criminal Victimization in Canada, 2014
22 Canadian Centre for Policy Alternatives, The Gap in the Gender Gap: Violence Against Women in Canada, Kate Mclnturff, July 2013
23 Institute for Women's Policy Research, The Economic Cost of Intimate Partner Violence, Sexual Assault, and Stalking, Fact Sheet, August 2017
24 Chart represents figures at November 14, 2017 and excludes the Vancouver Police Department and Vancouver Public Library.
Senior Management: Includes all positions Pay Band 10 and above. Information Technology (IT) Positions: Include all positions in technical information technology roles across all City departments, excluding Senior Management. Trades and Operations: Includes all trades and operations (e.g., construction, traffic, parks, maintenance) positions, across all City departments. Firefighting Positions: Includes all firefighters, inspectors, captains, investigators, and managers excluding Senior Management Engineers, Technicians and Engineering Assistants: Include all professional and technical engineering positions across all City departments, excluding senior management.

<!-- PAGE BREAK -->

<a id='1ab76de6-2504-4c83-8907-eb11d2375f2a'></a>

Gender Equality Update - 11780

<a id='953fb686-05f1-4691-bcf8-9fb520f2a870'></a>

11

<a id='16e59be1-9d0d-4963-b5e2-aafa2d275024'></a>

TABLE 2
Examples of under-represented positions
<::Bar chart showing the percentage of Female and Male representation in different positions:
- Senior Management: Female 37%, Male 63%
- Trades and Operations: Female 15%, Male 85%
- Firefighting: Female 4%, Male 96%
- Information Technology (IT) Related: Female 34%, Male 66%
- Engineers, Technicians and Engineering Assistants: Female 30%, Male 70%
: bar chart::>

<a id='66625df7-ad76-4448-b255-65c18088efa6'></a>

All of this data provides important context for the strategy's update and underscores the need for a renewed commitment by many, including the City. Research into the current state and local to global best practices, including interviews with a number of subject matter experts, provided a strong foundation from which to start gathering stakeholder input on the strategy update.

<a id='15fb8c17-5fff-40d6-a35f-1f40b40989a5'></a>

Starting in October 2016, we began those consultations with the Women's Advisory Committee through a member questionnaire and working session. A public survey was launched on March 8, 2017, International Women's Day, with a total of 1,640 responses received by the survey's closing date, April 26, 2017. A public forum was also held during the month of April. Both the survey link and public forum details were sent directly to 84 community agencies and each of the Type 'A' Council Advisory Committees, encouraging them to provide their input. The diagram below provides an overview of all inputs considered in development of the updated strategy (Table 3).

<!-- PAGE BREAK -->

<a id='56b9e217-acc6-4987-807b-ff96293af6b7'></a>

Gender Equality Update - 11780

<a id='24c7c809-242f-4803-9275-f759439355a0'></a>

12

<a id='f9fdd3f3-533b-4823-9c73-4b7fa4b5b9e9'></a>

TABLE 2

<a id='e0c9cdbe-ba60-45d3-aab7-c4866d55cb54'></a>

<::Diagram: A central box labeled "Women's Equity Strategy 2018-2028" is connected to six surrounding oval-shaped boxes, each representing a consultation or research method.The surrounding boxes are:Internal Consultations:Ongoing consultations with internal experts and impacted Departments.Public Consultations:Survey (1,640 responses)Forum (45 attendees)Community organizations 84 contacted/invitedWomen's Advisory Committee:Updated and consulted regularly.Provided guidance and advice on process and plan.Subject Matter Experts:21 contacted16 interviewed/consultedBest Practices Research:35+ papers reviewedStatistical researchAdvisory Committees:Council Advisory Committees contacted and invited to participate: diagram::>

<a id='1d5bd3cf-f9f2-4a49-a764-afcff907b12f'></a>

The initial five themes identified by the Women's Advisory Committee in the Fall 2016 were confirmed during the public consultation process. These include:
* Safety
* Childcare
* Housing
* Leadership & Representation (within the City of Vancouver as an employer)
* Intersectional Lens

<a id='9c79e2b3-2ad9-4034-8c61-56023b43eb1e'></a>

The Women's Equity Strategy for the City of Vancouver 2018-2028 is attached with actions organized by these five priority themes (Appendix B). The updated strategy links directly with focus areas in the Healthy City Strategy and, as such, the latter provides a natural framework in which to organize actions in the Women's Equity Strategy. In addition to the Healthy City Strategy, there are a number of current and upcoming City initiatives which connect to priority themes in the updated strategy, including the Housing Strategy, Childcare Strategy and Poverty Reduction Strategy. These are all high priorities for each level of government and new partnership opportunities are continuously emerging that could amplify the impact of the City's work in each of these areas. Other emerging opportunities include the Women Deliver 2019 global conference in Vancouver and a three-year research project titled "Action on Systemic Barriers to Women's Participation in Local Government" conducted in partnership between Women Transforming Cities and the Canadian Research Institute for the Advancement of Women (CRIAW).

<a id='7f896746-a26d-470e-9cad-b1087784d78d'></a>

TABLE 3

<a id='e7fc2033-4d18-4109-8896-2333cd07808c'></a>

**Sources of Input**

<!-- PAGE BREAK -->

<a id='a5ead533-2f4e-461e-8614-14a36930a40f'></a>

Gender Equality Update - 11780

<a id='d7c95983-f510-4508-a092-12d8081c5f31'></a>

13

<a id='9e0ab1a7-56ef-4829-bdee-9d934d4adb35'></a>

Given the evolving context, the Strategy identifies specific Phase 1 Actions for completion within the initial two years of the ten year strategy related to each of the five priorities (Table 1). This approach allows flexibility to dovetail with related City initiatives and emerging opportunities to advance the goals of the Women's Equity Strategy. In addition to these actions, each priority outlines an overarching goal, specific objective(s) and strategies for how to get the work done. The first regular progress report to Council is recommended in 2019 along with next phase actions, after consideration of stakeholder input and best practices contained in the strategy, as well as related City priorities and current context.

<a id='dca72319-6545-4d62-97b3-26329d881104'></a>

*Strategic Analysis*

A comprehensive City Strategy on gender equality was first introduced in 2005. The document provided a snapshot of women's lives in Vancouver, followed by the City's vision, principles, aims and actions assigned to lead departments. The pioneering strategy led to the completion or integration of the majority of actions and demonstrated the City's commitment to improve the lives of women in Vancouver (see Appendix A).

<a id='3384ce74-6373-4a66-9152-6027ec6a4bad'></a>

Over the past 12 years, the city has seen a great deal of change and growth in both exciting and challenging ways. Unfortunately, many of the same issues that disproportionally impacted women in the past still exist today, including lower incomes, less housing security, more unpaid work, and greater rates of poverty and gender based violence. Council's motion "Because It's 2016: Action on Gender Equality" underscores this reality and renews the City's commitment to improve the lives of women in Vancouver.

<a id='70b39437-a7a3-4c9d-b778-04c60740b1d6'></a>

As with the 2005 strategy, the Women's Equity Strategy 2018-2028 has been developed within the current local, national and international context, and built upon existing City policies and priorities (see Appendix B). Initial Phase 1 Actions are recommended over the first two years of the 10 year strategy (Table 1). This approach is purposeful, allowing the City flexibility to respond to emerging opportunities, changing priorities and shifting provincial and federal context. Working with the Women's Advisory Committee, the updated strategy is the result of best practice research and consultations with committee members, the public, subject matter experts and staff (Table 3). The strategy aligns with current work, including poverty reduction, housing and childcare, and is supported by the overarching framework of Healthy City (http://vancouver.ca/people-programs/healthy-city-strategy.aspx). The Women's Equity Strategy 2018-2028 continues the innovative work first started in 2005 and strives to make Vancouver: A City for All Women.

**Public/Civic Agency Input**

<a id='8535e1c5-7c6e-4f44-8c83-bd2fc2504e03'></a>

1. Women's Advisory Committee
    a. Regular meetings: Staff from the Human Resources Department met with the Women's Advisory Committee (WAC) on the following dates: October 25, 2016, and January 31, February 28, March 21, May 11, June 20, July 18, August 15, September 26, and November 21, 2017.
    b. Meetings with WAC Chair and Chairs of the WAC Subcommittees: In September 2017, staff held three separate meetings with the Chairs of the WAC sub-committees, including Leadership, Representation and Participation, Economic Equality and Opportunity, Safety and Gender Mainstreaming.

<!-- PAGE BREAK -->

<a id='8009ab87-b5ad-4377-8a1b-31ef581dfc39'></a>

Gender Equality Update - 11780

<a id='54ce7a53-5f68-4b48-a14b-ab15c7070e0a'></a>

14

<a id='830169ac-d82a-494d-a726-481b40998bae'></a>

2. Public Input
a. Online Survey: The online Talk Vancouver survey "Action for Women" was live from March 6 - April 26, 2017, and received 1,640 responses.
b. Public Forum: Approximately 45 people attended the public forum held on April 19, 2017.
c. Community organizations: 84 community organizations were specifically invited to respond to the survey and attend the public forum.
d. Citizen Advisory Committees: All Type 'A' Council Advisory Committees were invited to respond to the online survey, attend the public form and provide input on the update of the 2005 GES.
3. Subject Matter Expert Consultations: 21 organizations were contacted and 16 of these met with staff to provide their expert input.

<a id='7cacfbe6-0180-41af-91f0-e23e9bf40639'></a>

_Implications/Related Issues/Risk (if applicable)_

_Financial_

There are no financial implications at this time.

<a id='02103517-e711-43bb-8a48-48cf6836396e'></a>

*Human Resources/Labour Relations*

The City will work with the unions with regards to the implementation of any employment-related actions.

<a id='79022006-bf8e-4966-b78c-80fb361ebf1d'></a>

_CONCLUSION_

The persistence of women's inequality is an issue that affects all of us, locally, nationally and globally. Addressing this issue requires all social agents - including individuals, organizations and governments - to take proactive measures to eradicate it. Council's direction to review the 2005 Gender Equality Strategy and _update_ it underscores the reality that there is much more to be done to improve the quality of lives for women, and those who identify as women, in Vancouver. As part of the City's collaborative approach, staff will be proactive in sharing the updated strategy with community organizations and other partners such as TransLink and Vancouver School Board.

<a id='3eab678f-2ca2-41ad-875a-8ac59b91be25'></a>

The City's commitment to equity, diversity and inclusion is long-standing and its leadership continues with the Women's Equity Strategy 2018-2028. It highlights the work that the City is currently doing in safety, housing and childcare, as well as leadership and representation within its workplace. The Strategy also emphasizes that in the context of this work, an intersectional lens is an essential foundation. This will help ensure that the City reflects and responds to the needs of all Vancouverites, including women.

<a id='8b30a740-f069-4914-bd6c-5f7ec4467b29'></a>

The Strategy explicitly recognizes the issues faced by women, creates a solid case for change,
and provides goals, objectives and recommendations that will, over time, make measurable
differences. And these differences will benefit far more than only women. As one survey
participant wrote, "It is important that [the City] send a clear and decisive message to
women that we matter. Women who know they matter will engage in civic affairs and

<!-- PAGE BREAK -->

<a id='216ee0da-e3e4-4186-bbaa-8f7cf488b59d'></a>

Gender Equality Update - 11780

<a id='69565992-b80a-4f3b-b9f6-0a161d40a832'></a>

15

<a id='a44ec4f4-b083-40ec-88d8-abbc96ec25eb'></a>

contribute to improving our neighborhoods and communities; hence an investment in gender equity is an investment that benefits all of us." Vancouver: A City for All Women is the Women's Equity Strategy for the City of Vancouver 2018 - 2028.

<a id='b013cdb2-04cc-4943-a819-a95501babf44'></a>

* * * * *

<!-- PAGE BREAK -->

<a id='ff73c6b1-db69-4895-a848-e7f75d93b525'></a>

APPENDIX A
PAGE 1 OF 6

<a id='1e158d04-c30e-46df-858a-7601ca11eaa0'></a>

*Review of the 2005 Gender Equality Strategy for the City of Vancouver*

To conduct the review of the 2005 Gender Equality Strategy, staff consulted lead departments assigned to each action. It was quickly determined that the action outcomes fell into one or more of the following categories:

<a id='f9458541-1057-4f86-926c-c9645d3c6e82'></a>

Completed                               Action completed or integrated into existing work
Ongoing                                 Work related to action continues as stated
Not Completed                           Action not completed or status undetermined due to staff
                                        turnover, length of time

<a id='394fbe6c-bd9d-41e7-9846-b865eddf244b'></a>

# ACTIONS

**Action 1.1 Community Services**
Provide financial and other types of resources dedicated to initiatives that support the safety, inclusion and well-being of women, including childcare services, family services, neighbourhood houses, women's shelters and centres, and specific services for immigrant women, young women and girls, and Aboriginal women throughout the City.

<a id='aafdfa09-01e4-4ddc-a61d-06a2940274f3'></a>

STATUS: Ongoing

➤ Community Services tracks grants for their impact on women and other groups. In 2016, $8M of social grants supported all categories set out in this action item and $1M in grants went to programs that serve over 85% women and girls.

<a id='06bee786-0df4-4e4a-b600-86edf750bcb0'></a>

Action 1.2 Community Services
Provide support for the key strategies of the Vancouver Agreement's Women's Task Team.

<a id='70a6384f-ae79-4910-adce-f747c283f314'></a>

STATUS: Completed

- The Vancouver Agreement's work wrapped up in 2009-2010. The Women's Task Team worked with a number of community organizations representing women in relation to several projects. Projects such as Bad Date Reporting became part of the ongoing work of Prostitution Alternatives Counselling and Education (PACE) and the Women's Information Safe House (WISH). The Mobile Access Program is still being operated by PACE and WISH and continues to receive funding from the City of Vancouver.

<a id='315d9fd2-6700-433b-b8b9-26fa65ba7226'></a>

**Action 1.3 Equal Employment Opportunity**
Continue to:
* ensure equal employment opportunities for women through the effective implementation of our Equal Employment Opportunity policy
* protect employees' human rights through the effective implementation of our Harassment policy
* promote and support the employment of women, including specific initiatives for women in non-traditional jobs, by partnering with educational institutions and community agencies, work practicums, career fairs, the Aboriginal Employment Partnership Initiative, and related outreach activities
* provide staff training in a variety of formats on the City's Workplace Harassment and Equal Employment Opportunity policies, including training on preventing harassment,

<!-- PAGE BREAK -->

<a id='4ff2865e-e41a-4094-9316-829d196ba7ca'></a>

APPENDIX A PAGE 2 OF 6

<a id='fd3b8ab8-a6e1-49f0-9cac-27897fe9d869'></a>

building respectful workplaces, conflict resolution and building and supporting a diverse workplace
* act as a neutral and impartial resource for all City staff on issues relating to harassment and human rights; and
* provide mediation, intervention and investigation services related to harassment complaints and issues.

<a id='619d74aa-f1f4-40ba-8a44-c9abb1d1bb9d'></a>

STATUS: Ongoing

<a id='575b0cfd-e6ea-4b50-9cbd-cf1462fc9c00'></a>

Action 1.4 City Clerk's
Establish an Advisory Committee on Women's Issues to provide advice and further develop actions in this plan, with liaison positions from the VSB, VPB, VPL and VPD.

<a id='d6337a1e-da1a-4ef7-99d2-911e9ece771c'></a>

STATUS: Ongoing

> The Women's Advisory Committee was established in February of 2009. The February
2009 motion established non-voting liaison positions for VSB and VPB only.

<a id='fe3381ee-96ec-4596-af07-1b78b0511e5b'></a>

Action 1.5 City Clerk's
Create a page on the City's website that increases the visibility of women's civic engagement.

<a id='719c7d8c-893c-450c-9e94-fe9d1db778b9'></a>

STATUS: Completed

  In 2007, City Clerk's Department reported that it established a website link to various materials and a toolkit to increase women's participation in municipal decision-making under the then-header "Get Involved with Your Community".

<a id='6e8b03d4-33d8-4746-8e9d-78ae2c6e1e8c'></a>

Action 1.6 City Clerk's
Create a new compulsory category in the City Council report template called "Sustainability
Implications," combining the current "Environmental" and "Social" Implications. This category
will direct that Council Reports address social, economic and environmental sustainability,
including different implications for women and men, girls and boys.

<a id='275c783f-0083-492a-a873-f5272eb45eb6'></a>

STATUS: Not completed
* The new category was not established. Implications are currently captured under "Environmental" and "Other" Implications.

<a id='807daaaf-c75f-41a5-bcd1-d23fbdb34152'></a>

Action 1.7 Sustainability Office, City Clerk's
Add a training module on using the Sustainability Implications lens to the Committee
Orientation for all Committees at City Hall.

<a id='1777ccb1-625d-4ef7-a465-0586577d0304'></a>

STATUS: Not completed
▸ This Action Item was linked to the creation of the "Sustainability Implications" (Action
1.6).

<a id='5c941b8f-24d6-4d19-ba71-9485eafda2c9'></a>

Action 1.8 Community Services Group
Develop, pilot and implement a gender impact assessment tool for use by City programs, which includes guidance on collecting and using gender disaggregated information.

<a id='dc8bb2d5-ff8c-423f-a35c-8705ade87476'></a>

STATUS: Ongoing

<!-- PAGE BREAK -->

<a id='1679b364-8142-4369-ae8a-e608052cf224'></a>

APPENDIX A
PAGE 3 OF 6

<a id='c029ed84-2ff5-4d53-bd5e-7519bbb441f4'></a>

➤ This was initially not undertaken due to resource constraints. However, in 2017, Community Services initiated work to develop an intersectional lens, one of the guiding principles as part of the Healthy City Strategy. Completion is expected in 2018.

<a id='66cdc24b-ae9a-4e51-b93a-3fae1df89334'></a>

Action 1.9 Public Involvement, City Clerk's
Develop and add a module on increasing women's participation to the Public Involvement
training course offered to staff.

<a id='342c2892-d28b-4097-8430-1e84d7971a51'></a>

STATUS: Completed
- In 2005, increasing women's participation was part of the training to familiarize staff
with the "Get Involved with Your Community" website. The website included a toolkit
to increase women's participation in municipal decision-making.

<a id='56831473-eef5-4451-9f7e-0608880d404e'></a>

Action 1.10 Planning, Community Services
Work with the Urban Design and Development Planning Centre to find ways to apply a gender lens to CPTED (Crime Prevention through Environmental Design) guidelines and review processes.

<a id='92b6c981-39fe-40c0-8334-5e26c18b2980'></a>

STATUS: Ongoing

* Planning applies CPTED guidelines to development. The Guidelines reflect gender equality principles, including addressing women's safety by creating safer environments.

<a id='89a3bc5c-df59-4b5a-b658-4c652940ade6'></a>

Action 1.11 Community Services
Continue to work with DTES (Downtown Eastside) Women's Centre to develop a Street Banners project as requested.

<a id='15e1ac58-01cf-4ff5-90a0-e3fb4e4e62ab'></a>

STATUS: Not completed

- Funding is currently provided to the DTES Women's Centre and the DTES Women's Market.

<a id='8d82a1fb-4cba-4879-9deb-cd6f02ffc0cd'></a>

Action 1.12 Vancouver Police Department (VPD)
Promote "inclusion with influence" of Aboriginal women and girls in the community
consultation process on the re-instatement of the VPD Native Liaison Unit.

<a id='85ca25bc-de2c-40ab-b887-22d008ec2b41'></a>

STATUS: Ongoing
➤ The VPD consulted with Aboriginal elders and youth (both female and male) to create the Aboriginal Community Police Center. The work is ongoing with the VPD Diversity & Indigenous Relations Section.

<a id='01874ccb-d68a-45f2-9101-8069fd8f2b7c'></a>

Action 1.13 Mayor's Office
Host a civic engagement event at City Hall on International Women's Day 2006 highlighting women's involvement in the Community Visions (City Plan) process and reaching out to those women who have not historically been involved in those processes.

<a id='b342e7b1-25fb-40cd-826a-3439776f9de5'></a>

STATUS: Completed
- An event was held on International Women's Day 2006. The event included women who spoke about their experiences as Aboriginal women, women with disabilities, youth and other communities.

<!-- PAGE BREAK -->

<a id='d9dbe5f0-810c-442b-be38-f8b7d9b8173c'></a>

APPENDIX A
PAGE 4 OF 6

<a id='68741997-1222-4759-b03a-0b34f149a521'></a>

> An event was also held in 2007 that involved collaboration between the City and other municipalities. The event focused on women's involvement in political and civic life.

<a id='0112f43c-b499-4039-b234-a66947f7fbdc'></a>

Action 1.14 City Council
Request that TransLink engage in a public education campaign for transit users to promote safety features within the transit systems (such as the "request stop" program).

<a id='3666a5c9-a830-4523-9a89-e7c6a8ed861b'></a>

STATUS: Not completed (The 'request stop" program currently exists with TransLink.)

<a id='349524fd-b941-4344-a43f-a2bbb442560a'></a>

Action 1.15 City Council
Request that TransLink develop a policy to involve women in the design of bus and sky train stops, routes and shelters including a program of women's safety audits of current transit system and routes.

<a id='e7950b48-2353-4716-a39a-10fbc42741b2'></a>

STATUS: Completed
➠ In May 2005, Council referred recommendations to TransLink to prioritize women's
safety in the transit system; to involve transit-dependent women in the planning
process; to increase service in off-peak hours; and to create more bus priority
measures rather than reducing the number of stops.

<a id='174e0b78-e69f-4afd-9f38-44832d848bc9'></a>

Action 1.16 Communications, City Clerk's
Ensure all images used in City publications and promotional materials promote positive and
varied images of women and men, girls and boys of diverse backgrounds.

<a id='0d764802-864f-4dc2-8be7-99554ab82269'></a>

STATUS: Ongoing
➤ Images used in City communications promote positive and varied images of diverse individuals, including women and men, and girls and boys.

<a id='e898f424-6043-4a6b-81ec-88867ae4a286'></a>

Action 2.1a Community Services
Create a coordinating body focused on issues of well-being of Aboriginal women and girls, with an initial membership of elected and staff representatives from the City, the Parks Board, the School Board and the community, and an initial mandate of

a) identifying current VSB, VPB and City initiatives focused on Aboriginal women and girls;
b) identifying opportunities for coordination amongst these, and
c) ensuring "inclusion with influence" of Aboriginal women and girls in these initiatives.

<a id='17681293-2d24-4deb-b08c-8b930f2f91a2'></a>

STATUS: Ongoing
* In 2012, Council created the Urban Aboriginal People's Advisory Committee (UAPAC) to advise the City on "enhancing access and inclusion for urban Aboriginal Peoples to fully participate in City services and civic life." The Committee has up to 15 members, including women, and has two Council Liaisons and a Park Board Liaison.

<a id='c833492f-28c7-402f-9e22-320b5b19a888'></a>

Action 2.1b Community Services
Develop a pilot project that brings the VSB, VPB and City together to develop a supportive program in two schools for Aboriginal girls, focusing on grades 7/8/9, to help this age group stay in school and be successful in the high school grades.

<!-- PAGE BREAK -->

<a id='6fd65480-4d0b-472f-9a2a-4ad2e5e0f15e'></a>

APPENDIX A
PAGE 5 OF 6

<a id='aac9391c-dfd2-474d-bfa5-338fa98e0831'></a>

STATUS: Not completed (The Vancouver School Board is not within the City's jurisdiction.)

<a id='8c6ada86-fdc0-4c5a-af7c-aa8d4b0b2dc9'></a>

Action 2.1c Community Services
Work through the Vancouver Agreement to explore the feasibility of providing an after-hours safe place for Aboriginal women and girls in the DTES (including the possibility of expanding hours of operation of the DTES Women's Centre).

<a id='8722b071-1101-445a-a3ea-9396ac789356'></a>

**STATUS:** Ongoing
* The DTES Women's Centre hours have been extended and additional funding has been provided to expand staffing and services. In October 2017, Council approved a one-time Capital Grant of up to $250,000 towards renovations for the Downtown Eastside Women's Centre Association 24/7 Shelter in partnership with BC Housing.

<a id='dc517864-2cc7-4e6e-a57a-a465de5c775e'></a>

**Action 2.2 Community Services**
Develop a pilot project that would result in the creation of practical gender mainstreaming tools for the neighbourhood visioning and planning process - a partnership project between a team of interested planners and a women-serving organization in a neighbourhood scheduled for "re-planning." The model developed to include tools for engaging those women who have not historically been involved in the community visioning process, as well as tools for neighbourhood planning through a gender lens.

<a id='ede071ea-2d0c-4cdf-bb82-8b5e62afb9c5'></a>

STATUS: Ongoing

- An inclusive approach to engaging neighbourhoods in planning was adopted, including efforts to reach out to all members of the community. This practice continues to be used and it has been updated to include outreach and engagement using social media and targeted outreach.

<a id='274ec8af-f167-408c-acd4-d7413598e526'></a>

Action 2.3 Planning, Community Services
Develop a pilot project that would result in the creation of practical gender mainstreaming tools for the development process - through a partnership project with a developer interested in creating a "women-friendly" development.

<a id='fcb84ff9-4b87-4b31-8ba7-0153781eaa52'></a>

STATUS: Ongoing
* In 2016, staff worked with East 33rd Ave Co-Housing as a pilot project for specifically engaging with young mothers in the design process of this new housing typology. The learnings from this pilot are being integrated in updated Family Housing Guidelines.

<a id='2736da1f-9d6c-4d48-b9c9-394ed84e20a9'></a>

Action 2.4 Mayor's Office
Celebrate the contributions of women and girls through an annual International Women's Day event at City Hall.

<a id='704c4114-9157-4876-826c-5433da986c47'></a>

STATUS: Ongoing
* The City hosts an annual event celebrating International Women's Day.

<a id='7e13ab8c-0de3-428c-9665-589d2b93d422'></a>

Action 2.5 Community Services
Monitor developments, review progress and deliver an annual report on gender equality measures on March 8th each year, at an International Women's Day Event at City Hall.

<a id='ea280eed-6d22-4e50-99ff-06b9e7a32c9a'></a>

<::attestation: Status indicator
Status: Completed
Short description of visual elements and positioning::>

<!-- PAGE BREAK -->

<a id='11caac71-0791-46b7-a2e1-a1a14b417310'></a>

APPENDIX A
PAGE 6 OF 6

<a id='2f097977-62f6-4240-8d03-e5da3117ea9f'></a>

> The Equal Employment Opportunity Office previously compiled and presented a summary of departmental work related to diversity and inclusion in March of every year.

<!-- PAGE BREAK -->

<a id='091688e6-ad2e-477d-baf1-df2636ad42d9'></a>

VANCOUVER:
A CITY FOR
ALL WOMEN

<a id='f1d944c3-f69b-4a8a-a917-56f6c584c53d'></a>

<::A group of six diverse women, ranging in age and ethnicity, stand together, smiling and laughing. They are all wearing various shades of pink tops, suggesting a common cause or theme, possibly related to breast cancer awareness. Their arms are around each other's shoulders, indicating camaraderie and support. The background is plain white.: photograph::>

<a id='8ab54952-74e2-4a66-b479-671e356f4c3f'></a>

WOMEN'S EQUITY STRATEGY
2018-2028

<a id='43b2ea12-398e-47e2-9c39-cf77eaaf89ab'></a>

<::logo: City of Vancouver
CITY OF
VANCOUVER
A white stylized lotus flower is positioned to the left of the text, all against a red background.::>

<!-- PAGE BREAK -->

<a id='37ea21f8-ec60-4afb-b0d4-b172af97f910'></a>

A MESSAGE FROM
THE CITY MANAGER

<a id='a2e8b2f2-e3bf-4394-a7c2-d4549859edbe'></a>

I'm very pleased to present Vancouver:
A City for All Women, Women's Equity
Strategy 2018-2028.

<a id='12a0c47e-c9f9-4f53-b56e-5eedc5ed97b6'></a>

Unanimously adopted by City Council,
the Strategy builds on the foundational
work started with the City's 2005 Gender
Equality plan and sheds light on many of
the barriers which continue to limit the
full participation and contributions of all
women, including those who identify as
women. The Strategy sets out specific
goals and targets to address these barriers,
recognizing that the full inclusion of all
residents is fundamental to creating
a city which is diverse, welcoming,
vibrant, economically successful, and
environmentally sustainable.

<a id='943ee849-d5d3-4ac9-a2d8-e5d1cb77adb3'></a>

Leveraging and aligning with related
City strategies such as Healthy City and
Housing Vancouver, we will specifically
take action to increase women's safety
and affordable housing, and address
the impact of the childcare shortage on
women's economic participation. We
will also lead by example within our own
workforce by removing barriers for women
and increasing the number of new hires
in leadership and in historically under-
represented occupations.

<a id='a8d0ecc8-e854-4daf-b2ae-fef55b05a5de'></a>

Finally, and underpinning it all, we will
apply an intersectional approach to our
work to ensure that all residents, including
all women, have equitable access, inclusion
and participation in the life of the city.

<a id='d0f4503d-351a-429a-84fd-5de1df561ee4'></a>

The development of this Strategy follows extensive engagement with the City's Women's Advisory Committee and City staff, as well as public input, research, and consultations with subject matter experts and other organizations, including municipalities. I wish to thank all who gave their time and shared their expertise and experiences and, in particular, the members of the Women's Advisory Committee.

<a id='66768d54-ec8b-49ae-afef-3face5334cc8'></a>

Removing barriers to full inclusion for all women will require sustained and coordinated efforts from all levels of government, community organizations, and individuals. The City of Vancouver is committed to doing its part through the implementation of this Strategy, sharing and learning from others committed to women's equity and influencing change wherever possible. We look forward to working with our stakeholders to make Vancouver a place where all women enjoy full inclusion in the political, economic, cultural and social life of the city.

<a id='4c2ce709-54c4-4349-b6c9-5e66b32eb6ee'></a>

<::attestation: Signature
Signed
Signature: legible (Sadhu A. Johnston)
Sadhu Aufochs Johnston
City Manager
A blue handwritten signature is positioned above the printed name "Sadhu Aufochs Johnston" and title "City Manager", all centered on a white background.::>

<!-- PAGE BREAK -->

<a id='30d57ef7-e82c-4f74-9523-fb79f672a825'></a>

CONTENTS

<a id='a5688cca-4e29-4690-acb8-531e409c687b'></a>

<table id="23-1">
<tr><td id="23-2">Executive Summary</td><td id="23-3">.2</td></tr>
<tr><td id="23-4">Vision</td><td id="23-5">.6</td></tr>
<tr><td id="23-6">Principles</td><td id="23-7">.6</td></tr>
<tr><td id="23-8">What we Heard</td><td id="23-9">.7</td></tr>
<tr><td id="23-a">Why it Matters</td><td id="23-b">.9</td></tr>
<tr><td id="23-c">Inequality&#x27;s Differential Impact</td><td id="23-d">13</td></tr>
<tr><td id="23-e">The Case for Change</td><td id="23-f">14</td></tr>
<tr><td id="23-g">Priorities</td><td id="23-h">15</td></tr>
<tr><td id="23-i">Strategies</td><td id="23-j">16</td></tr>
<tr><td id="23-k">Plan for Action</td><td id="23-l">17</td></tr>
<tr><td id="23-m">Priority: Intersectional Lens</td><td id="23-n">18</td></tr>
<tr><td id="23-o">Priority: Women&#x27;s Safety</td><td id="23-p">20</td></tr>
<tr><td id="23-q">Priority: Childcare</td><td id="23-r">22</td></tr>
<tr><td id="23-s">Priority: Housing</td><td id="23-t">24</td></tr>
<tr><td id="23-u">Priority: Leadership &amp; Representation</td><td id="23-v">26</td></tr>
<tr><td id="23-w">Accountability.</td><td id="23-x">28</td></tr>
<tr><td id="23-y">Acknowledgements.</td><td id="23-z">29</td></tr>
<tr><td id="23-A">Endnotes.</td><td id="23-B">32</td></tr>
<tr><td id="23-C">Snapshots of City&#x27;s Current Actions.</td><td id="23-D">34</td></tr>
<tr><td id="23-E">Inputs for Future Consideration.</td><td id="23-F">40</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='0a3f01ee-242b-4373-9d58-0b5d448f67d3'></a>

<::A woman with curly brown hair and glasses stands at a podium, looking down at papers. She is wearing a red, black, and white dress and a silver necklace. A microphone on a gooseneck stand is positioned in front of her. Behind her, a large screen displays an image of several people, likely roller derby players, with the white text "THIS GIRL CAN" in a rectangular frame prominently featured on the left side of the screen.
: figure::>

<a id='28a73f27-d41c-426c-8c69-0bf304c0d821'></a>

EXECUTIVE SUMMARY

<a id='988a396a-12d2-44b1-9b98-f17ff68e8a34'></a>

"Because It's 2016: Action on Gender
Equality" was the Vancouver City Council
motion that inspired the development of
an updated women's equity strategy and
provided the opportunity to consider our
work in light of the persistent issue of
women's inequality in our community. The
result is **Vancouver: A City for All Women**,
Women's Equity Strategy 2018-2028.

<a id='ee8e5595-a029-456d-8580-9a0d7ed1a7f3'></a>

The Strategy reflects our vision to make
Vancouver a place where all women and
self-identified women have full access to
the resources provided in the city and
opportunities to fully participate in the
political, economic, cultural and social life
of the city.

<a id='723af9bf-d8ab-4923-bc45-00be49941732'></a>

"Women and girls comprise a majority of Vancouver residents (51 per cent) but on average have lower incomes, less housing security, more unpaid work, experience far greater rates of poverty and gender based violence and in general have less opportunities than men and boys"
(Council Motion - Because It's 2016:
Action on Gender Equality).

<a id='9b3cfab9-bb20-4baa-b1a3-cb823bb6f683'></a>

Women's inequality is an issue that affects us all. We cannot reach our full potential as a city and as a community when certain segments of our population are marginalized and denied full inclusion and participation. We know that all women's full

<a id='5490ee4b-e428-4e8c-9eca-3795e080f0cc'></a>

2

<a id='518153aa-8ba7-4970-8030-c04a6b448dfc'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='82bb68a4-80c6-4976-aa17-da000aa7c26f'></a>

inclusion boosts our economy, increases
our productivity, and reduces child poverty.

<a id='c66828da-b95c-457f-93a6-1c1737120456'></a>

Addressing such a wide-ranging issue as
women's equity requires all social agents
– individuals, organizations and all levels
of government – to take intentional steps
towards this goal. As a city, we can take
positive actions within our jurisdiction
and encourage others to do the same.
The focus of this Strategy is in those areas
where the City of Vancouver can make a
difference.

<a id='de50a034-69de-4539-a22c-bd7444f71c5d'></a>

We are grateful to the many individuals and organizations that took the time to share their experiences and expertise. In particular, the City's Women's Advisory Committee spent countless hours and many meetings sharing their expertise and informing the scope and content of the Strategy. In addition, more than 1,600 residents participated in our online survey and public forum, subject matter experts and community organizations took valuable time to meet with us, and City staff were consulted for their expertise and feedback.

<a id='f2852185-ba89-4f31-9123-ac4cd25367be'></a>

Throughout our consultations, we heard recurring themes that emerged as priority areas. Addressing the issues faced by all women in each of these areas is seen as key to improving women's full inclusion in the life of the city:

* Applying an intersectional lens to the City's strategies and plans
* Addressing safety, including violence against women
* Accessible, quality childcare
* Safe and affordable housing
* Women's leadership and representation within the City's workforce

<a id='37480013-7b45-49c3-8a63-7eeb3fd4aa06'></a>

**Vancouver: A City for All Women** is a 10-year strategy that recognizes the current shifting political and social landscape. Within each priority area, a number of Phase 1 Actions have been identified for 2018-2019. A staff Action Team will coordinate implementation of the Phase 1 Actions and, in consultation with the Women's Advisory Committee, will consider all inputs received as potential actions over the next eight years of the Strategy.

<a id='ddb59209-9b31-4ec5-85a7-2d399b0ec4ff'></a>

A key success factor for this Strategy
is being accountable to our goals and
objectives. To that end, we will measure our
progress and report out regularly. In 2019,
we will provide a progress report to Council
and outline actions for implementation in
the next phase of the Strategy.

<a id='bd2aa866-fa09-41cc-a066-145e426fc9e5'></a>

Another key success factor is alignment with the City's Healthy City Strategy. The Healthy City Strategy is guided by a vision of A Healthy City for All, ensuring collectively we pursue a strong and inclusive focus on inequity, including gender inequity. These principles also emphasize the importance of including meaningful involvement in the broader public, private and civic sectors.

<a id='b0fe8c20-894d-4966-9d93-6ed074cc6d2a'></a>

3

<a id='83d5caa8-2f6d-43f2-b2f7-61aad1adea11'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='def3c629-8168-4cb4-a8dc-c0568288314c'></a>

## Summary of Priority Areas and Phase 1 Actions

The following summarizes our Phase 1 Actions by priority area. Full detail on each priority, as well as background on the City's current work in each of these areas, is included in this document.

<a id='211592fe-6bb0-40fd-9e9d-6915be975ca8'></a>

These priority goals and objectives
parallel the City's Healthy City Strategy
'determinants of health' approach and
include indicators and targets that have
been designed to address inequalities at a
municipal level.

<a id='4ee3784d-bdc9-4801-ac54-7b336acb4c55'></a>

_The City is in a position to make a difference and so should play a leadership role. Gender stereotyping and discrimination not only restricts females' and males' ability to participate fully in the world, it limits the City's economic potential._
- Public Survey "Action for Women"

<a id='acf57b55-ae74-4955-ba39-dafd7fca6d4f'></a>

INTERSECTIONAL LENS
<table id="26-1">
<tr><td id="26-2">GOAL</td><td id="26-3">The City&#x27;s decisions, programs and plans are informed by an intersectional lens to ensure that all citizens have equitable access, inclusion and participation in community life.</td></tr>
<tr><td id="26-4">OBJECTIVE</td><td id="26-5">In 2018, an intersectional framework will be established for City departments.</td></tr>
<tr><td id="26-6">STRATEGIES</td><td id="26-7">Education &amp; Awareness, Policy</td></tr>
<tr><td id="26-8">PHASE 1 ACTIONS: 2018-2019</td><td id="26-9">1. Pilot intersectional framework. 2. Introduce the application of an intersectional lens to senior staff through training in Gender-Based Analysis Plus (GBA+), offered through Status of Women Canada. 3. Bring forward to Council revised Civic Assets Naming Guidelines that include gender diversity.</td></tr>
</table>

<a id='2807174e-9b24-49e1-ae44-6b362bf1392c'></a>

SAFETY
<table id="26-a">
<tr><td id="26-b">GOAL</td><td id="26-c">Vancouver is a safe city in which all women are secure and free from crime and violence, including sexual assault.</td></tr>
<tr><td id="26-d">OBJECTIVE</td><td id="26-e">By 2025, women&#x27;s sense of safety will be increased by at least 10 per cent.</td></tr>
<tr><td id="26-f">STRATEGIES</td><td id="26-g">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="26-h">PHASE 1 ACTIONS: 2018-2019</td><td id="26-i">1. Join UN Women&#x27;s Global Flagship Initiative &quot;Safe Cities and Safe Public Spaces&quot; and conduct a scoping study on women&#x27;s safety. 2. Identify community partners and collaborate on an annual public campaign to raise awareness on violence against women. 3. Update the Women&#x27;s Advisory Committee annually on progress in ensuring women&#x27;s safety and needs in the neighbourhood planning and development process. 4. Formalize senior staff coordination and oversight of inter-departmental response to critical issues in the Downtown Eastside, including women&#x27;s safety and related issues.</td></tr>
</table>

<a id='1c5a3abf-389b-4c91-966e-836b05f627fb'></a>

4

<a id='7cfb3bfb-06a4-418b-9e8a-a80d97d0b6cd'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='bbab849d-2b1b-4fe6-9fa1-8c966a43e8cc'></a>

CHILDCARE
<table id="27-1">
<tr><td id="27-2">GOAL</td><td id="27-3">Women&#x27;s full participation in the workforce and engagement in public life is supported by affordable and accessible quality childcare for children.</td></tr>
<tr><td id="27-4">OBJECTIVE</td><td id="27-5">By the end of 2018, 1,000 new childcare spaces will be added from the 2015 baseline.</td></tr>
<tr><td id="27-6">STRATEGIES</td><td id="27-7">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy</td></tr>
<tr><td id="27-8">PHASE 1 ACTIONS: 2018-2019</td><td id="27-9">1. Share input from the Women&#x27;s Equity Strategy consultations for consideration in the City&#x27;s updated childcare strategy.
2. Partner with senior levels of government to significantly increase affordable, quality childcare through creating new childcare spaces, and replacing aging centres.
3. Identify child-friendly provisions to accommodate participation by families with children at Council and Public Hearings at City Hall.</td></tr>
</table>

<a id='10db46c0-763d-4d93-9ccb-a991a64edcfa'></a>

HOUSING
<table id="27-a">
<tr><td id="27-b">GOAL</td><td id="27-c">A range of affordable housing choices is available for women of diverse backgrounds and circumstances, including single parents, seniors, newcomers, and those facing vulnerable conditions.</td></tr>
<tr><td id="27-d">OBJECTIVE</td><td id="27-e">72,000 new homes across Vancouver in the next 10 years.</td></tr>
<tr><td id="27-f">STRATEGIES</td><td id="27-g">Education &amp; Awareness, Data, Partnerships &amp; Collaboration</td></tr>
<tr><td id="27-h">PHASE 1 ACTIONS: 2018-2019</td><td id="27-i">1. Identify how to determine the extent of women&#x27;s hidden homelessness to better understand its full scope. 2. Research integration of outreach role within Coordinated Access Centre to liaise with women-serving organizations and identify women in need of priority housing. 3. Share input from the Women&#x27;s Equity Strategy consultations for consideration in the implementation of the Housing Vancouver Strategy.</td></tr>
</table>

<a id='464569f1-664c-43bf-88e0-a29d85320405'></a>

LEADERSHIP & REPRESENTATION
<table id="27-j">
<tr><td id="27-k">GOAL</td><td id="27-l">The City will elevate the visibility, influence, representation and contribution of all women in the organization by providing equitable access to work opportunities, including leadership roles and other under-represented occupations&#x27; and by creating and implementing initiatives to specifically enhance their development and leadership.</td></tr>
<tr><td id="27-m">OBJECTIVES</td><td id="27-n">• Effective immediately, the City will increase new hires for Senior Management roles to 50 per cent women.• By 2020, the proportion of female new hires in under-represented occupations will be increased by at least five per cent over the 2017 baseline.</td></tr>
<tr><td id="27-o">STRATEGIES</td><td id="27-p">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="27-q">PHASE 1 ACTIONS: 2018-2019</td><td id="27-r">1. Become the first municipality to sign Minerva BC&#x27;s Face of Leadership™ Diversity Pledge, making a public commitment to support women&#x27;s advancement in leadership in our workforce and in our community.2. Develop and implement a Breastfeeding Policy for City staff.3. Conduct focus groups with female staff in leadership and under-represented positions.4. Measure and publicly report annually on the City&#x27;s workforce composition including positions and compensation.5. Address potential bias in the hiring process by training recruitment staff to recognize and mitigate unconscious bias.</td></tr>
</table>

<a id='d9e88a83-8530-4084-8ac3-3155f6608f6a'></a>

5

<a id='9e0ec2f6-2af6-42e6-aaf9-2566dc7ad03c'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6564af43-55d0-43fe-8c70-fdfded21b1a8'></a>

<::logo: [VISION]VISION
A bold, sans-serif font in red text is presented on a white background.::>

<a id='47ae70b9-d81c-4525-8bab-5e762fec27ab'></a>

The City is committed to making Vancouver a place where all women have full access to the resources provided in the city and have opportunities to fully participate in the political, economic, cultural and social life of Vancouver.

<a id='be0bc776-c327-4b31-9deb-e2c8874cae82'></a>

# PRINCIPLES

The implementation of the Strategy reflects the following principles:

*   ***"Nothing about us without us."*** We will be inclusive of the voices of all women and women's organizations through consultations with the Women's Advisory Committee and other stakeholders.
*   ***Intersectional lens*** For many women, the impact of gender inequality is compounded by other forms of discrimination including race, disability, language, immigration status, and prejudice against Indigenous Peoples. Applying an intersectional lens to developing programs, services and policies considers this differential impact and aims to address it.
*   ***Systemic and culture change*** The City recognizes that patterns of inequality are deeply entrenched in our social and institutional structures, and historical and cultural patterns. The City will focus on systemic changes in its approach to

<a id='ae77e8ae-d47a-41e5-bca4-78cacd7e725c'></a>

equity for all women, with the aim of shifting systems and changing attitudes.

*   **Sustainable** In order to be sustainable over the long term, the Strategy aligns with other City initiatives, such as the _Healthy City Strategy_. The Strategy is also flexible and responsive to emerging opportunities and trends, allowing us to maximize our ability to advance our vision and goals.

*   **_S.M.A.R.T._** Our goals and targets are **S**pecific, **M**easurable, **A**chievable, **R**ealistic, and **T**ime-bound.

*   **_Criteria for inclusion_** The success of the Strategy depends on setting goals and targets in those areas over which we have control and jurisdiction. The Vancouver Police Department, Vancouver School Board and Vancouver Public Library all have their own Boards and are independent of the City of Vancouver. Our Strategy does not commit to actions that fall under their mandates.

<a id='3e85dc2d-e27c-40e2-a545-b373e41fdd2b'></a>

All citizens deserve equal opportunities. Vancouver is seen as a progressive city and gender equality would be an important component of that.

- Public Survey "Action for Women"

<a id='42f281a2-d612-4f56-8d6d-94b1ee0d2cfb'></a>

6

<a id='5d3f3889-de74-4048-a8e9-a3a47e0f87ae'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='cc8cf3d2-977b-4772-a9d9-33c0d3c4dff7'></a>

WHAT WE HEARD

<a id='af72504a-7968-4d0f-ae4e-c4546912e6ee'></a>

**Vancouver: A City for all Women** has been
informed by the voices and experiences
of more than 1,600 residents, members of
the City of Vancouver's Women's Advisory
Committee, subject matter experts,
community organizations, research,
and City staff. In particular, members

<a id='bb3a1246-8e99-495c-ae3c-d8fa3b0ec2f7'></a>

of the Women's Advisory Committee
dedicated an abundance of their time
to the development of this Strategy,
both at regular meetings and specific
working sessions.

<a id='3062468f-9e88-4d0f-b5fd-efaf14eb9d83'></a>

Throughout these consultations several key themes and priority areas emerged.

<a id='da15faae-c7b0-4f5d-942b-4b1bdc1b0daf'></a>

# WOMEN'S SAFETY

We heard that women in Vancouver continue to deal with the effects of violence and that many women do not feel safe within the city.

INTERSE

<a id='05750a51-0658-40a4-af26-a5594e435826'></a>

**CHILDCARE**
Access to affordable quality childcare is an urgent issue that was cited as the number one action that could immediately and positively impact all women's lives, their economic participation and economic independence.
CTIONAL

<a id='76c7cb36-eeac-4b29-b0c9-5555a36f6e1f'></a>

not feel safe within the city.

## INTERSECTIONAL LENS
An intersectional lens is needed to ensure that actions in these priority areas benefit all women.

## HOUSING
We also heard that Vancouver's housing crisis disproportionately impacts women - in particular women leaving intimate partner violence. The combined issues of a lack of affordable housing and women's relative economic disadvantage place women at greater risk of returning to or staying in an abusive situation. The housing crisis also makes women vulnerable to exploitation.

L
REI
Finally, we show leade women's e employme and public

<a id='1a8df86c-c2f1-466d-8cbf-a716b6a410b7'></a>

all women.

# WOMEN'S LEADERSHIP & REPRESENTATION

Finally, we heard that the City should show leadership in advancing all women's equity through its own employment practices, public policies and public communications.

<a id='a8affefc-425e-4bc9-871b-118baba24945'></a>

7

<a id='22757ca1-1b84-4ffc-83be-264a579dd4a4'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='9b01c7cf-bc13-4ca1-bdc7-4fba3a722f37'></a>

<::A woman with dark hair, wearing a black coat over a red turtleneck, is holding a baby. She is smiling broadly and looking towards the viewer. The baby, with light hair and blue eyes, is wearing a light-colored, cable-knit sweater with brown buttons and speckled with small bits of green and blue. The baby is looking directly at the viewer with a neutral expression. They are outdoors with a blurred green background, suggesting grass or foliage.: figure::>

<a id='dd372ac1-500c-42e2-8e22-406a66c28b9c'></a>

**INTERNAL CONSULTATIONS**
* Ongoing consultations with internal experts and impacted Departments

<a id='d4a1cbdd-70e9-494a-91ea-e85b16ea70ed'></a>

PUBLIC CONSULTATIONS
* Survey (1,640 responses)
* Forum (45 attendees)
* Community organizations
84 contacted/invited

<a id='9bf4aff5-7039-4dcb-9cf0-1c26ae7af06e'></a>

<::transcription of the content: diagram::>WOMEN'S EQUITY STRATEGY 2018-2028 is at the center of a diagram. Four speech bubble shapes point towards the center, each containing text. The top-left speech bubble (blue) reads: WOMEN'S ADVISORY COMMITTEE. - Updated and consulted regularly. - Provided guidance and advice on process and plan. The top-right speech bubble (red) reads: SUBJECT MATTER EXPERTS. - 21 contacted. - 16 interviewed/consulted. The bottom-left speech bubble (red) reads: RESEARCH & BEST PRACTICES. - 35+ papers reviewed. - Statistical research. - 10+ cities studied. The bottom-right speech bubble (yellow) reads: ADVISORY COMMITTEES. - Council Advisory Committees contacted and invited to participate.<::>

<a id='b74910c8-4b2d-4f25-b466-3861285018cb'></a>

8

<a id='3eaf2b14-807a-40d5-a539-8aaff955b5f8'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='de500970-5562-438d-b893-4be145e9265b'></a>

WHY IT MATTERS

<a id='09bca752-9e2c-478b-b65b-a4f648b3cd8e'></a>

**Women continue to be economically disadvantaged**

Women make up 51 per cent of Vancouver's population9 and continue to be economically disadvantaged relative to men. A specific focus on improving all women's lived experiences is needed in order to achieve the City's targets in the Healthy City Strategy.

<a id='08c00bab-43ec-4928-90b8-a0c5494d48f6'></a>

*Women in Vancouver earn less than men...*

Vancouver's annual living wage: $37,500²
Men's annual median income: $36,900³
Women's annual median income: $29,800³

<a id='5cbc5d40-b06a-4da8-bfa6-4bc616307967'></a>

Because...
* Even within the same occupations, women earn 87 cents for every dollar earned by men.⁴
* 56 per cent of women are employed in traditionally female-dominated and lower paying occupations such as teaching, nursing and health-related occupations, social work, clerical, administrative, and sales and services.⁵
* Women make up:
  * 70 per cent of minimum wage workers.⁶
  * 76 per cent of part-time workers.⁷
  * 60 per cent of those collecting Employment Insurance.⁸
  * 24 per cent of workers in higher paying professional science, technology, engineering, mathematics (STEM) occupations.⁹

<a id='b6bf4c1e-f38b-4d20-b381-7e51663c8467'></a>

# The motherhood penalty
The "motherhood penalty" can be described using both an employment gap (between men and women) and an earnings gap (between mothers and non-mothers).

<a id='2f2be20b-2679-4264-860b-3955334e674c'></a>

Vancouver has the third worst employment gap between men and women in Canada (11.8 per cent). The employment gap is greater in cities with high childcare fees. ¹⁰

<a id='6ce3f340-fa92-42a0-9b50-484d736f5af0'></a>

I have been forced to sacrifice 7 years of my career to be a stay home mom, because there is insufficient adequate childcare available in this city and it's completely unaffordable to even consider working full-time and pay for childcare for two kids.
- Public Survey "Action for Women"

<a id='6358c046-2a34-41fe-a9ed-2d179add9fd1'></a>

With respect to the earnings gap, one study found women with children earn 12 per cent less than women without children. This gap increased with the number of children, up to 20 per cent for women with three or more children." The earnings gap can be partly explained by breaks in women's employment for maternity and parental leaves. Approximately 47 per cent of women take at least one maternity or parental leave over their careers, compared to 3.8 per cent of men. The average duration of women's combined parental and maternal leaves is 1.3 years.12

<a id='53344592-9f9d-42f8-ab5f-991c457a7ad1'></a>

9

<a id='560223c3-d147-48db-9ff2-60beadaef396'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='4f5f965c-da72-481f-a43f-e00209aa9468'></a>

Women spend an average of 50.1 hours per
week on childcare, more than double the
average time (24.4 hours) spent by men.
This includes women who work full-time.13
Of those who work part-time, 25 per cent
of women and 3.3 per cent of men cited
childcare as the reason.14

<a id='53c227a6-c07c-4a06-be21-2ff9d12cf6b9'></a>

Eighty per cent of single-parent families
are headed by women¹⁵ and 90 per cent
of single parents on income assistance are
female.¹⁶

<a id='4b2b0e74-b58d-4c21-93c5-a4fadd989259'></a>

The cumulative effects of extended leaves, the demands of childcare, and a lack of affordable childcare impact women's workforce availability, their earnings over the course of their careers, and their economic security over the course of their lifetimes.

<a id='6d7e1781-05c3-425a-acea-8e0342ad8d2a'></a>

# Violence against women is a persistent issue
The 1993 UN Declaration on the Elimination of Violence against Women defines violence against women as, "any act of gender-based violence that results in, or is likely to result in, physical, sexual or psychological harm or suffering to women, including threats of such acts, coercion or arbitrary deprivation of liberty, whether occurring in public or in private life."

<a id='e4802119-b728-49ef-91c2-ecf61388b3c6'></a>

Women's economic vulnerability places
them at greater risk of intimate partner
violence and exploitation. In addition,
violence against women increases women's
economic vulnerability through lost
education, work opportunities, and income
as a result of the associated physical and
psychological harms.

<a id='c48ae1ad-1e9d-4d60-a278-0bf5e118dad0'></a>

Intimate partner violence (IPV) accounts
for one in four violent crimes reported to
police. The vast majority of victims (80 per
cent) are women." One study found that

<a id='04d11e48-8485-4445-87d1-a844661b2f43'></a>

60 per cent of victims of IPV had either quit their jobs or were terminated as a result of the abuse. 18 Women who leave abusive domestic partners rely on food banks at nearly 20 times the rate of average Canadians and for up to three years after leaving the abusive situation. 19

<a id='b9b26b81-53e6-4b3c-a707-3e68a49d0469'></a>

Between 2004-2014, criminal victimization rates for all crimes fell by 28 per cent, while rates of sexual assault have remained stable (22 incidents per 1,000 people). However, only 5 per cent of sexual assaults are reported to the police.20

<a id='16a7fb26-994c-4d81-bb04-4d23fc6a028f'></a>

Up to 27 per cent of victims of gender-based violence have used medication to cope with depression, to calm them down or to help them sleep. This is significantly higher than the proportion of women who were not violently victimized (18 per cent).21

<a id='5c3f33af-3cee-48dc-847c-d9d6c8f34ed0'></a>

<::A young woman with dark, curly hair and glasses, wearing a grey and navy blue cable-knit sweater and jeans, standing with a black bag over her shoulder. She is smiling faintly and looking directly at the camera. Behind her is a brightly colored, cracked wall with graffiti patterns in blue, yellow, pink, and black.: figure::>

<a id='d2c23d2b-0821-47ed-8e28-92bc95ed2d20'></a>

10

<a id='50abbdd4-8836-43bd-b73d-5aa26aa703a0'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='0c08083a-266a-4304-96b4-133cf24786ef'></a>

<::A group of eight people, four men and four women, stand side-by-side in a room with wood-paneled walls. The woman in the center is holding a framed document with a decorative border. To her right, a woman wears a red jacket with a white and red patterned scarf. To her left, another woman wears a grey top with a long beaded necklace and glasses hanging from it. The person furthest to the left is a woman in a black and white plaid jacket. To the right of the woman holding the document, another woman wears a black dress and a pearl necklace. Next to her, a woman in a black top has a white circular pin on her chest. Next to her, a woman with dark hair and glasses is wearing a dark jacket. The person furthest to the right is a man in a dark suit jacket and a light blue collared shirt. A Canadian flag and another flag (possibly a provincial or organizational flag) are visible in the background on the far right.: figure::>

<a id='835d2608-fb4d-453d-8808-bb870360e955'></a>

> Sometimes at night I do not feel comfortable walking home... I do not want to feel unsafe in my own neighborhood. As well being sexually harassed by walking down the street, for example getting honked at and cat called.

- Public Survey "Action for Women"

<a id='916c2c0f-4123-4cc8-9fe5-fc17fb941c5c'></a>

## Many women don't feel safe in the city

The Healthy City Strategy goal of "being safe and feeling included" includes the target of "increasing Vancouver residents' sense of safety by 10 per cent". Currently, 65 per cent of all residents agree that they "feel safe walking after dark" in their neighbourhoods.²²

<a id='a7446292-5a79-4797-9583-b00d20d1d9ed'></a>

However, when broken down, the numbers
for women are different. Only 57 per cent
of women compared to 73 per cent of men
agreed that they felt safe walking after
dark. Senior women (75+ years) and young
women (18-24 years) reported feeling the

<a id='6bac40a9-e533-44e5-b198-1bb7aad63d04'></a>

least safe, at only 41 per cent and
47 per cent respectively. Similarly, only
44 per cent of Indigenous women, and
42 per cent of Chinese women reported
feeling safe walking after dark.²³

<a id='eeef5fa5-3765-47bc-b9aa-91e51096d297'></a>

In order to meet the Healthy City Strategy
target of increasing residents' sense of
safety, specific attention needs to paid to
the unique experiences of **all** women when
navigating the city.

<a id='85750601-b515-4cd8-a736-c0365efa3b88'></a>

# Women at the City of Vancouver
As a large employer and provider of public services, the City can make a positive impact within its own workforce and can demonstrate leadership in advancing all women's equity in the workplace. Through this Strategy, we will improve the representation of all women in leadership and historically under-represented occupations within the City's workforce.

<a id='7446dce2-375d-4741-9186-06e9b648c359'></a>

According to the McKinsey Global Institute,
while Canada is among the global leaders
in women's equality, progress has stalled
in the last 20 years. Persistent and
significant gaps continue in the areas of
managerial positions, STEM occupations,
unpaid care work and single parenthood,
among others. 24

<a id='5a5be58e-fb3a-44af-9cd8-864875670ed5'></a>

11

<a id='d6d87be2-efdc-4b96-b801-e81e32184841'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='9b905100-683e-4034-85ff-117d129940d3'></a>

The following chart shows the current representation of women at the City in leadership and examples of historically under-represented occupations.*

<a id='15d2495b-5f49-47c9-8e1e-0a420b2fb10f'></a>

<::Women at the City of Vancouver: chart::>   
<::horizontal bar chart::>  
<::Legend:  
Female (red)  
Male (blue)::>  
<::Categories and Percentages:  
Senior Management: Male 63%, Female 37%  
Engineers, Technicians and Engineering Assistants: Male 70%, Female 30%  
Information Technology (IT) Related: Male 66%, Female 34%  
Firefighting: Male 96%, Female 4%  
Trades and Operations: Male 85%, Female 15%::>

<a id='40024d9c-fb1e-4073-949a-f87dde265455'></a>

*Notes:
* As of November 14, 2017
* Chart excludes Vancouver Police Department and Vancouver Public Library
* *Senior Management* includes all staff pay band 10 and up.
* *IT-Related* includes all positions in technical IT roles across all departments, excluding Senior Management.

<a id='c646e6d6-76b0-4543-b756-9ad5754d091d'></a>

* _**Trades and Operations**_ includes all trades and operations positions (e.g., construction, traffic, parks, maintenance) across all City departments, excluding Senior Management
* _**Firefighting**_ include all firefighters, inspectors, captains, investigators, and managers excluding Senior Management.
* _**Engineers, Technicians and Engineering Assistants**_ include all professional and technical Engineering positions across all City departments, excluding Senior Management.

<a id='2132a2db-18dd-4f5e-8908-3751ae349123'></a>

12

<a id='66583839-5f03-4a80-a56e-694f012c50cb'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='950983d7-0285-43f8-87a5-b154e7f0af0c'></a>

INEQUALITY'S
DIFFERENTIAL IMPACT

<a id='e642dee4-8bd2-433d-82f2-0e6188d29887'></a>

For many women, the impact of inequality is compounded by other forms of discrimination related to race, disability, language, immigration status, etc. The following are just two examples of how these intersecting forms of discrimination negatively impact women.

<a id='d009e584-1a15-4ede-9141-92cc98ec0e97'></a>

# Indigenous (First Nations, Métis, Inuit) women

*   While Indigenous women represent just 4.3 per cent of Canada's female population, they represent 16 per cent of female homicide victims and 11 per cent of missing persons' cases involving women.25
*   Indigenous women are three times more likely to be sexually assaulted than non-Indigenous women.26
*   Statistically, Indigenous identity remains a significant factor for violent victimization among women, even when controlling for other risk factors.27
*   Indigenous women experience higher unemployment rates and have lower median incomes than non-Indigenous women.28
*   Indigenous women are twice as likely to head lone parent families as non-Indigenous women.29

<a id='f473a28c-8282-4e22-b98a-26506e75bef9'></a>

## Women with disabilities
* 15 per cent of Canadian women report having disabilities that limit them in their daily activities. This number increases to 22 per cent for Indigenous women.³⁰
* Women with disabilities are more likely to be lone parents (11 per cent versus 8 per cent for women without disabilities).³¹
* The workforce participation rate for women with disabilities is 61 per cent compared to 83 per cent for women without disabilities.
* The unemployment rate for women with disabilities is 13 per cent versus 6 per cent for women without disabilities.³²
* Women with disabilities earn less than women without disabilities and men with disabilities.³³
* Financial insecurity increases women's vulnerability to violence. Women with disabilities report experiencing emotional or financial abuse at a proportion that is 12 per cent higher than women without disabilities and physical and/or sexual assault at a rate that is 4.4 per cent higher than women without disabilities.³⁴

<a id='631d005a-1251-4785-b9c5-12f620fa6849'></a>

The Women's Equity Strategy recognizes
and considers this intersectionality in the
implementation of the Strategy.

<a id='e31efaa9-e2f3-4918-8021-906983ef39ae'></a>

13

<a id='ba131720-b29e-49b5-a33f-528de20ad5a0'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='8dedb5de-7014-4405-9e3c-20ab2d09cd52'></a>

THE CASE FOR CHANGE

<a id='6aa26073-cb83-4487-9726-19e1760f0595'></a>

**When women are poor,**
**children are poor**
In Vancouver, 1 in 5 children live in poverty
(20 per cent). ³⁵

<a id='113b76cd-f4df-4af0-a154-749e958efb20'></a>

A close link has been established between child poverty and women's poverty. In 2014, one in every two children of single parents in BC were poor. 36 The vast majority of single parents are women and a disproportionate number are Indigenous women and women with disabilities.

<a id='3b7c3272-7de5-4bd3-8013-4c6f235f44a4'></a>

Recommendations to improve child poverty
include measures that directly mitigate
women's poverty. These include improving
social supports for families (for example
income assistance, child benefits, maternity
and parental benefits); improving labour
force participation through flexible work
arrangements and affordable childcare;
affordable housing for families; and
improving earnings through a higher
minimum wage and living wage policies. 37

<a id='355fe7d0-9956-4ec1-bb64-223de3605a44'></a>

## Violence against women costs society

Children who witness intimate partner violence experience emotional, psychological, social and behavioural problems. In addition, there is evidence that the cycle of violence could continue with children who have witnessed family violence. 38

<a id='c18d777f-f84d-4887-b0e3-c511c36bb41e'></a>

The combined financial cost of sexual
assault and intimate partner violence is
$334 per person/year in Canada. Costs
include medical care, social supports, legal
costs, and lost productivity.39

<a id='453509e6-e5e9-4cf2-a526-450d25b45e05'></a>

<::A close-up shot of two people in industrial settings. In the foreground, a woman with curly hair wears a blue hard hat, clear safety glasses, and an orange high-visibility vest. She is looking up and to the right with a slight smile, holding a tablet in her hands. In the blurred background, a man wearing a similar blue hard hat and orange vest is pointing at a control panel with various buttons and indicators.: figure::>

<a id='5e601e00-16a1-4074-8040-e8d2d27f5f5a'></a>

**Women contribute to economic growth**
A recent study by the McKinsey Global Institute found that taking steps to address all women's full economic participation could add $150 billion to Canada's Gross Domestic Product by 2026. BC's potential growth would be $21.2 million.40

<a id='f524a115-30a2-41a0-b3aa-90802e69246b'></a>

This economic growth could be achieved
by a combination of adding more women
to high-productivity, high-paying sectors;
increasing all women's labour force
participation; closing the wage gap; access
to affordable childcare; and increasing
women's working hours by 50 minutes/
week.

<a id='3e7f4be7-139d-4f43-a93b-cf946dc88ada'></a>

**Workforce diversity improves business performance and profitability**

Studies have linked the presence of women in senior management to improved organizational and financial performance.

<a id='5e55a0bd-afac-434d-a8c9-65994a7c0452'></a>

In addition, a diverse workforce increases profitability and productivity. One study found that a 1 per cent increase in ethno-cultural diversity was associated with a 2.4 per cent increase in revenues and a .5 per cent increase in productivity.41

<a id='34b7c81b-b17d-45dd-91fd-29fcab7f1813'></a>

14

<a id='446f2772-8dfc-456a-9ab9-1e21002f712d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='2755d349-6682-4120-a271-1040f16fdb2d'></a>

<::logo: Priorities
PRIORITIES
The logo features the word "PRIORITIES" in bold, red, sans-serif capital letters.::>

<a id='45cfbdab-af35-446e-baf6-fe08a342ca6e'></a>

The Strategy focuses on five themes that were identified as priorities during our consultations.

<a id='25a23fcc-6b13-4af1-a350-4cd8e0e0f069'></a>

<:: Diagram showing a central horizontal oval labeled "INTERSECTIONAL LENS". This oval is positioned horizontally across the middle of the diagram. Four white rounded-rectangle boxes with red outlines surround the central oval, arranged in a 2x2 grid. The top-left box is labeled "SAFETY". The top-right box is labeled "CHILDCARE". The bottom-left box is labeled "HOUSING". The bottom-right box is labeled "LEADERSHIP & REPRESENTATION". All labels are in red capital letters. The central oval and the lines between the boxes suggest a connection or influence of the "INTERSECTIONAL LENS" on the four surrounding concepts.
: diagram::>

<a id='11da5c32-c594-4b82-9cdb-84513975b275'></a>

The four substantive areas (Safety, Housing, Childcare, and Leadership & Representation) are inextricably linked and work together to either enhance or harm women's full inclusion into the social and economic life of our city.

<a id='bf21f670-c034-4212-9052-2dcb907b56e8'></a>

The Intersectional Lens describes a process of ensuring that actions taken in these substantive areas reflect the diverse realities of all individuals, including women, who are impacted by various forms of discrimination.

<a id='0811c2d3-311d-4661-b7ed-338c33edad5b'></a>

This Strategy recognizes that in order
to make measurable progress, we need
coordinated action on all substantive
areas
- informed by an intersectional lens
sustained over time and carried out in
partnership with other governments and
civil society.

<a id='08f3b2a0-8b0d-40d4-8ee7-87e08e8e313a'></a>

Action on these
would be dynamite.
- Public Survey, "Action for Women"

<a id='125e65e1-e9c7-4886-9b18-10cfa3a4e981'></a>

15

<a id='736dc6d8-d768-4055-ab06-19d9a4b2dbf4'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='30183966-1d51-497a-9a5d-390abab11b99'></a>

<::A candid photograph shows two women in an indoor setting, possibly at a conference or event. The woman on the left, with blonde hair, is facing right and smiling slightly, her profile visible. The woman on the right, with dark hair, is facing left, looking at the other woman with an engaged expression. She is holding a blue pen in her right hand. Both women are wearing light blue t-shirts and lanyards around their necks. In the background, other people and blurred elements suggest a busy environment.: figure::>

<a id='15ed4d2c-68b7-4ca6-94e2-b5e4083a3cfa'></a>

# STRATEGIES

During our research and consultations, it became clear that a number of different strategies will need to be employed across all actions for a successful outcome.

<a id='c29fb8e0-4b90-48b3-ad73-c8af6edeb70d'></a>

Education and Awareness We will aim to bring awareness to the issues that impact all women with the goal of educating and influencing positive change.

<a id='e9a21b24-c34b-4fef-a032-fb7641e66e82'></a>

Policy The Strategy may require that we review, update, and align our policies to advance our objectives.

<a id='8e2034d7-dd41-4a76-b211-280ae3a34266'></a>

Data In all of the priority areas, we need to start gathering relevant disaggregated data in order to measure progress.

<a id='ecf1fd40-5622-4790-b0e9-f0d3c2b2e991'></a>

**Partnerships and Collaboration** We will seek out opportunities to partner and collaborate on initiatives to make progress in the priority areas of this Strategy.

<a id='5a7a5481-2124-4e2f-8573-66896be7790a'></a>

16

<a id='d73a533c-77f1-435e-a37d-a0517515e639'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='1dbe9473-3a9a-4d08-b032-df2fee46f5b8'></a>

PLAN FOR ACTION

<a id='f5a5ab2e-6af2-4be0-bbcd-8b84ca331223'></a>

## Long-term Vision
A 10-year plan, the Women's Equity Strategy builds upon the City's current work and initiatives to improve the lives of women in Vancouver.

<a id='3a025e7d-0d2e-4de4-816f-df094fe3e637'></a>

This Strategy is being adopted in the context of a shifting provincial and federal landscape. New opportunities for partnerships are continuously emerging that could amplify the impact of the City's work in the priority areas in this Strategy. As just one example, Women Deliver 2019 is a global conference that will be held in Vancouver on the health, rights and well-being of women and girls.

<a id='78a67b91-a75d-434c-9ba5-184e8c128e4c'></a>

In order to be responsive to these new opportunities, the Strategy focuses on a Phase 1 Actions for the first two years with stakeholder-recommended inputs for 2020-2028.

<a id='9f927ab5-c199-4181-87f3-898f51f622b2'></a>

## Phase 1: 2018-2019

During Phase 1, the City will take specific and immediate actions to begin the implementation and lay the groundwork for future actions. The Phase 1 Actions are outlined for each Priority Area on the following pages.

<a id='a8c4609d-ea62-4ec8-95d3-09d3a4ae3603'></a>

# Action Team: 2018-2028
The Action Team will be tasked with determining future actions based on the recommendations and best practice research (see ***Inputs for Future Consideration.***) The Action Team will consider the evolving provincial and federal landscape with respect to the priority themes and determine which inputs to implement on an ongoing basis. The Action Team will consult with the Women's Advisory Committee and other stakeholders as needed.

<a id='00f01474-aa70-4b8e-bc0e-2eefa0cc0102'></a>

# Key Success Factors

Accountability and sustainability are critical to the ongoing success of this Strategy. To that end:

* The Strategy is aligned under the overarching framework of the Healthy City Strategy.
* A business unit is identified to lead each Phase 1 Action.
* The Action Team will provide oversight and a coordinated approach over the life of the Strategy.
* The Strategy spans 10 years and is responsive to emerging opportunities and changes in the political and social contexts.

<a id='cfeac015-ddb2-456d-a7e2-25a4dede014f'></a>

17

<a id='704cc90e-7087-401a-a81b-987537e633d1'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='b2cc542e-71ea-4150-95bc-7b37e80a5cf6'></a>

PRIORITY:
INTERSECTIONAL LENS

<a id='1c601774-1e13-4007-8557-c3ec88db7db4'></a>

Goal
The City's decisions, programs, and plans are informed by an intersectional lens to ensure
that all citizens have equitable access, inclusion and participation in community life.

<a id='0d760a26-f2ab-4286-8592-012db974cef3'></a>

**Objective**
In 2018, an intersectional framework will be established for City departments.

<a id='22acd507-e513-4d5d-bc4d-51b1c6e46ccb'></a>

Strategies<::An icon of a lightbulb within a circle.: icon::>EDUCATION AND AWARENESS<::An icon of an open book within a circle.: icon::>POLICY

<a id='17be6465-e51c-496e-b927-ada856e0535e'></a>

## What we're doing now

*   One of the Healthy City Strategy's goals and targets is the incorporation of an intersectional lens to monitor and understand the health and well-being of individuals and communities. The City is currently developing an intersectional lens to strengthen city processes and inform decision-making to better mitigate the impacts of interacting social contexts such as gender, race, class, and ability.

<a id='0600b19c-a021-4316-9932-df1f9aadbcf9'></a>

* The Civic Assets Naming committee is committed to naming new assets after under-represented groups and individuals. The Committee recently recommended names for eight lanes in the West End, half of which honour women: Helena Gutteridge, Kathleen (Kay) Stovold, Mary See-em-ia and Rosemary Brown.
* In 2017, Vancouver Board of Parks and Recreation named the park at Yukon and 17th Avenue after Lilian To, the former CEO of S.U.C.C.E.S.S.

<a id='e70abfe0-be66-4100-9915-c290ad4eca86'></a>

18

<a id='771ea77d-14ba-40fa-bc83-98cc7b277c75'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='ea28e6cd-bb6d-4c3e-8648-b1972a2b71cd'></a>

<::A close-up side profile of a woman with a colorful hijab, smiling and clapping her hands. Her hijab features vibrant colors like pink, yellow, orange, and purple. She is wearing a dark teal or blue top. A gold ring is visible on her right hand as she claps. The background is blurred and dark.: figure::>

<a id='ffe06a44-65e1-4c6c-b80f-6cec8447f96c'></a>

Phase 1 Actions – Intersectional Lens
<table id="41-1">
<tr><td id="41-2">ACTIONS</td><td id="41-3">LEAD DEPARTMENT</td></tr>
<tr><td id="41-4">Pilot intersectional framework.</td><td id="41-5">Arts, Culture and Community Services</td></tr>
<tr><td id="41-6">Introduce the application of an intersectional lens to senior staff through training in Gender-Based Analysis Plus (GBA+) offered through Status of Women Canada.</td><td id="41-7">Human Resources</td></tr>
<tr><td id="41-8">Bring forward to Council revised Civic Assets Naming Guidelines that include gender diversity.</td><td id="41-9">City Clerk&#x27;s Department</td></tr>
</table>

<a id='8da05ace-b345-4d74-b19f-bf6bcc9d3e7f'></a>

## Inputs for Future Consideration - Intersectional Lens

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in *Inputs for Future Consideration*. The Action Team will consider these over the life of the Strategy.

<a id='a00298af-3e13-4d18-bd05-61446e8a157e'></a>

19

<a id='df8f0774-84f1-4339-a0fc-cdfca94a726e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='5325c047-ae2d-4383-8000-d32b85ba4d30'></a>

PRIORITY:
WOMEN'S SAFETY

<a id='ebd4a7a3-8f78-4d74-9653-6eb3db19baa8'></a>

Goal

Vancouver is a safe city in which women are secure and free from crime and violence, including sexual assault.

<a id='6b893b73-9430-4fd1-b5ee-66e23ca05a51'></a>

## Objective

By 2025, women's sense of safety will be increased by at least 10 per cent.

<a id='360f4467-760e-4e32-a3a1-21ba7b952820'></a>

Strategies
<::icon of two hands shaking, encircled in a blue outline, with the text "PARTNERSHIPS AND COLLABORATION" below it: figure::>

<a id='b3f9fbf4-60a4-4df8-a22a-58a4829e6f77'></a>

<::An icon of a lightbulb, with light rays emanating from it, all enclosed within a circular outline. The lightbulb is stylized with a 'Y' shape in the center, and the entire icon is rendered in blue outlines.
: figure::>
EDUCATION AND
AWARENESS

<a id='99247136-92ec-4d62-8aec-74d64d2a4da5'></a>

<::icon of an open book inside a circle::>

POLICY

<a id='61cd7ec3-a04a-4ee3-bd88-11297ceb22b5'></a>

<::An icon showing a bar chart with four bars of varying heights, enclosed within a blue circle. Below the icon, the word "DATA" is written in red capital letters.
: icon::>

<a id='fd430ef6-bd9e-45bb-bf08-a5fcf2dcba4a'></a>

## What we're doing now
The following are highlights of the city's work to address safety issues and violence against women. For a more fulsome list, please see *Snapshots of City's Current Actions*.

<a id='c2cf298b-a003-4409-ac63-a11e47d659c9'></a>

* Our *Direct Social Services Grants* include "Community Safety" as a priority. Grants are provided to outreach, support and referral services for women experiencing violence or marginalization and to programs aimed at preventing youth sexual exploitation and increasing access to sex worker safety. The City is also working with partners to expand services at the Downtown Eastside Women's Centre.
* We take a proactive approach to addressing the health and safety of sex workers and communities impacted by sex work.

<a id='2eb0c268-19e1-484d-aa23-bcc1b5c3f953'></a>

• We will provide a supportive healing space for women attending the *Missing and Murdered Indigenous Women and Girls Inquiry*.

• We consider community safety in the planning of public spaces, and use an inclusive approach to engage neighbourhoods, including efforts to reach out to women and all members of the community.

• We build awareness of women's safety within our workforce by including partner violence in our workplace safety policies and procedures, and by providing "Be More Than a Bystander" training to staff.

<a id='ff436ce5-b3fa-481f-b949-403c23625293'></a>

20

<a id='42f961f6-0ba7-43fd-bbb2-512af363b8bc'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='369f12cc-4ef9-4d5f-a687-1984c2a5f24a'></a>

<::A close-up shot of two women engaged in conversation. The woman on the left has long, light brown hair with bangs, is wearing a light blue shirt with a silver pendant necklace, and a gray cardigan. She is looking towards the right. The woman on the right has short, dark gray hair, is seen from her right profile, and is wearing a gray jacket over a dark shirt with white polka dots. The background is blurred, suggesting an indoor setting.: figure::>

<a id='65405b74-38f3-45c1-a170-86a13b29b6c6'></a>

Phase 1 Actions - Women's Safety
<table id="43-1">
<tr><td id="43-2">ACTIONS</td><td id="43-3">LEAD DEPARTMENT</td></tr>
<tr><td id="43-4">Join UN Women&#x27;s Global Flagship Initiative, &quot;Safe Cities and Safe Public Spaces&quot; and conduct a scoping study on women&#x27;s safety.</td><td id="43-5">Arts, Culture and Community Services</td></tr>
<tr><td id="43-6">Identify community partners and collaborate on an annual public campaign to raise awareness on violence against women.</td><td id="43-7">Corporate Communications and Human Resources</td></tr>
<tr><td id="43-8">Update the Women&#x27;s Advisory Committee annually on progress in ensuring women&#x27;s safety and needs in the neighbourhood planning and development process.</td><td id="43-9">Planning, Urban Design &amp; Sustainability, and Engineering Services</td></tr>
<tr><td id="43-a">Formalize senior staff coordination and oversight of inter-departmental response to critical issues in the Downtown Eastside, including women&#x27;s safety and related issues.</td><td id="43-b">City Manager&#x27;s Office</td></tr>
</table>

<a id='5437b202-4cef-4486-8cfe-f660fe528cb8'></a>

## Inputs for Future Consideration – Women's Safety

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in _Inputs for Future Consideration_. The Action Team will consider these over the life of the Strategy.

<a id='582782ba-336a-436a-8d1f-3996757a0dac'></a>

21

<a id='100b4253-6dba-407c-934f-07249cfab71d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6439ad07-d7e9-404e-a794-f36d572c3fae'></a>

PRIORITY: CHILDCARE

<a id='fa516db1-e21e-4fb3-9753-e3682301a076'></a>

Goal
Women's full participation in the workforce and engagement in public life is supported by affordable and accessible quality childcare for children.

<a id='d4a1dc61-4480-46ab-b5ff-95a8b9ded8dc'></a>

Objective
By the end of 2018, 1,000 new childcare spaces will be added from the 2015 baseline.
(Aligns with current childcare target identified in the Healthy City Action Plan, 2015-2018)

<a id='ec40606c-8218-4e03-b59b-6fabfec1e5a2'></a>

<::logo: [Unknown]Strategies
PARTNERSHIPS AND COLLABORATION
This logo features a blue outline of two hands shaking, encircled by a blue outline.::>

<a id='b80a6524-d714-42a1-8b06-9d34186c14e6'></a>

<::logo: [Unidentifiable]EDUCATION AND AWARENESSA blue outline of a lightbulb is centered above the text, enclosed within a blue circular outline.::>

<a id='b1ab3680-addc-4834-bcb7-21c8773af323'></a>

<::An icon showing an open book within a circle, labeled below as "POLICY".: figure::>

<a id='84f71ebc-184a-4172-a8ce-c64960f6699f'></a>

## What we're doing now

The following are examples of some of the programs and investments aimed at maintaining existing childcare facilities and increasing the supply of childcare. For a more fulsome list, please see **Snapshots of City's Current Actions**.

*   The Capital Plan for 2015-2018 includes an investment of $30 million for childcare.
*   In 2017 the allocation of revenue from Development Cost Levies towards childcare has been increased from 5 per cent to 13 per cent.
*   The City charges nominal rents to 57 non-profit childcare centres located in City and Park Board facilities, supporting over 2,400 childcare spaces.
*   Several City grants support, enhance, and help to create new quality affordable childcare spaces.
*   We are currently developing an updated childcare strategy. The strategy will:
    *   Refresh policies, principles and goals to reflect current contexts.
    *   Review operator selection criteria for City-owned childcare facilities, to be offered to non-profit operators at nominal rents.
    *   Explore the hub model of integrated child and family services.
*   City Council passed a motion in support of the Community Plan for a Public System of Integrated Early Care and Learning (the $10/day Child Care Plan).
*   We partnered with the Vancouver Board of Education to help create 466 school-age childcare spaces in existing school space.

<a id='df4825da-0b28-47c2-843d-34abac38494d'></a>

22

<a id='d652cc8f-3cbc-47f1-9f67-9dc479dde79e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='dd604471-5583-4edd-bb67-b465a1dd0b34'></a>

<::A young girl with curly hair and an adult woman with curly, lighter-colored hair are giving each other a high-five. The girl is smiling broadly and appears happy. In the foreground, there are colorful building blocks, suggesting a playful or educational setting.: figure::>

<a id='e3d21e91-b44c-4f41-939f-2a78ab8700ce'></a>

Phase 1 Actions - Childcare

<table id="45-1">
<tr><td id="45-2">ACTIONS</td><td id="45-3">LEAD DEPARTMENT</td></tr>
<tr><td id="45-4">Share input from the Women&#x27;s Equity Strategy consultations for consideration in the City&#x27;s updated childcare strategy.</td><td id="45-5">Human Resources</td></tr>
<tr><td id="45-6">Partner with senior levels of government to significantly increase affordable, quality childcare through creating new childcare spaces, and replacing aging centres.</td><td id="45-7">Arts, Culture and Community Services</td></tr>
<tr><td id="45-8">Identify child-friendly provisions to accommodate participation by families with children at Council and Public Hearings at City Hall.</td><td id="45-9">City Clerk&#x27;s Department</td></tr>
</table>

<a id='c577cd02-35b6-4607-922e-064fd554368f'></a>

## Inputs for Future Consideration – Childcare
All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in _Inputs for Future Consideration_. The Action Team will consider these over the life of the Strategy.

<a id='21507133-805b-4ae6-84c3-467d895eb77d'></a>

23

<a id='e770f48e-b9fb-41e1-b055-11e68787a779'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='34a54bf5-2e8b-43e6-b802-653a3beabba0'></a>

# PRIORITY: HOUSING

## Goal

A range of affordable housing choices is available for women of diverse backgrounds and circumstances, including single parents, seniors, newcomers, and those facing vulnerable conditions.

<a id='c086b44b-4f20-4608-a21f-110179028f5d'></a>

## Objective
72,000 new homes across Vancouver in the next 10 years.

<a id='8d61a42d-ac8f-485b-a187-c6eb791dbfe3'></a>

Strategies

<::line art icon of two hands shaking, labeled "PARTNERSHIPS AND COLLABORATION": icon::>

<a id='638e0568-5d55-473f-a513-ae35d7685795'></a>

<::A blue outline icon of a lightbulb with rays emanating from it, all enclosed within a blue outline circle. Below the icon, in bold red capital letters, is the text "EDUCATION AND AWARENESS".: figure::>

<a id='79a9d838-ffab-4d57-9157-cf338be38919'></a>

<::A blue icon showing a bar chart within a circle.: figure::>

DATA 

<a id='1be359e1-ca19-481d-8dca-864307f8fda1'></a>

**What we're doing now**
The following are examples of efforts we're making to address housing affordability and availability in Vancouver. For a more fulsome list, please see *Snapshots of City's Current Actions*.

<a id='c5c0019a-5952-4eb5-8b5b-8be6bb5cddd0'></a>

Through the **Housing Vancouver Strategy** we have set goals to create 12,000 social, supportive and non-profit co-operative homes, including 6,800 new homes for households with incomes below $30,000 per year. At least half of all new housing in the next 10 years will be for renters and 40 per cent of new homes will be large enough for families.

<a id='4c706d8f-a86a-4ccb-b710-b2d208560e7d'></a>

We have a variety of programs to support renters and affordable rentals, including
_<u>Rental 100</u>_, _<u>Empty Homes Tax</u>_, _<u>Rental Housing Stock Official Development Plan</u>_, _<u>Rental Standards Database</u>_, _<u>Laneway Housing</u>_, and the _<u>Vancouver Rent Bank</u>_.

<a id='13d56a01-4871-4057-9af1-801c038d3c20'></a>

We have created a requirement that all
rezoning development applications include
a minimum of 35 per cent family units (two
and three bedroom units).

<a id='6a80f5f1-c631-4891-a9fe-c9ff6f5160b6'></a>

We work collaboratively with provincial and non-profit housing partners to support the delivery of housing for women and families through grants and provision of land for social housing.

<a id='d4f538f7-e0d8-42c3-bbc3-2a6e741a6136'></a>

Through grants, partnerships, and direct
outreach, we provide homeless and
under-housed residents with shelter, free
or low-cost food, and other services and
resources.

<a id='03169518-5925-4724-8f7f-7ea36fc96bec'></a>

24

<a id='942ca73a-6664-4cc6-b4ab-4aacace81f88'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='674baa52-84ba-4305-ada3-ec745976ae91'></a>

<::Two elderly women are seated at a table, smiling and eating soup and salad. The woman on the left has curly brown hair and is wearing a patterned blue and green top. The woman on the right has white hair, glasses, and is wearing a purple jacket over a pink top. They both appear to be enjoying their meal. In the background, other tables with red tablecloths and chairs are visible, along with another person in the far background.: figure::>

<a id='69885c26-b943-4d3e-bf73-30aa2cd00bca'></a>

Phase 1 Actions - Housing
<table id="47-1">
<tr><td id="47-2">ACTIONS</td><td id="47-3">LEAD DEPARTMENT</td></tr>
<tr><td id="47-4">Identify how to determine the extent of women&#x27;s hidden homelessness to better understand its full scope.</td><td id="47-5">Arts, Culture and Community Services</td></tr>
<tr><td id="47-6">Research integration of outreach role within Coordinated Access Centre to liaise with women-serving organizations and identify women in need of priority housing.</td><td id="47-7">Arts, Culture and Community Services</td></tr>
<tr><td id="47-8">Share input from the Women&#x27;s Equity Strategy consultations for consideration in the implementation of the Housing Vancouver Strategy.</td><td id="47-9">Human Resources</td></tr>
</table>

<a id='bb3e7708-10b8-4c1b-bcf3-26250d5bb7d5'></a>

## Inputs for Future Consideration – Housing

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in **Inputs for Future Consideration**. The Action Team will consider these over the life of the Strategy.

<a id='1fba889e-a452-4f7e-82f2-4782544f4f7e'></a>

25

<a id='a3774a70-0dde-42de-bc7a-b13ba98b52b7'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='f83e9e4c-76ff-40cc-8e88-433dfaf75d80'></a>

PRIORITY: LEADERSHIP &
REPRESENTATION

<a id='9588d13e-db88-48c1-9270-7120d4449765'></a>

# Goal
The City will elevate the visibility, influence, representation and contribution of all women in the organization by providing equitable access to work opportunities, including leadership roles and other under-represented occupations* and by creating and implementing initiatives to specifically enhance their development and leadership.

<a id='f0ddfb55-be01-4deb-9bd5-831d46c44fc7'></a>

# Objectives

*   Effective immediately, the City will increase new hires for Senior Management roles to 50 per cent women.
*   By 2020, the proportion of female new hires in under-represented occupations will be increased by at least 5 per cent over the 2017 baseline.

<a id='c62cd0c6-8036-4240-9f80-63562d0e1469'></a>

Strategies<::An icon of two hands shaking, enclosed within a circle.: icon::>PARTNERSHIPS ANDCOLLABORATION

<a id='afc47657-3e15-4e45-b4ac-486abcd183b7'></a>

<::lightbulb icon : figure::>
EDUCATION AND
AWARENESS

<a id='cd43496a-730e-4c5c-9746-d30792e10ff4'></a>

<::Two icons. The first icon shows an open book inside a blue circle, with the label POLICY below it. The second icon shows a bar chart inside a blue circle, with the label DATA below it.: figure::>

<a id='10d98587-e6e6-4f82-a341-df4beb4124c6'></a>

**What we're doing now**

The following are examples of some of the programs and initiatives aimed at improving the diversity and inclusion of the City's workforce. For a more fulsome list, please see *Snapshots of City's Current Actions*.

<a id='1f19bd2b-24af-4020-b0c2-bb793a437bb9'></a>

• We are proud to be a certified Living Wage Employer.
• Departments are actively working towards increasing workforce diversity, including the representation of women. A few examples of this include:

<a id='284bdafb-aa62-40b4-9f24-c6d25e72b1db'></a>

- Engineering Services has a Diversity
& Inclusion Working Group tasked
with increasing the representation
and retention of a diverse staff
that represents our community.
Engineering Services increased the
representation of women on its Senior
Executive team from 0% in 2010 to
50% in 2017.

<a id='d39da816-8af3-4744-9798-3e5574e156f9'></a>

* Examples of under-represented occupations include Information Technology (technical positions), Firefighting, Trades and Operations, Engineers and Engineers-in-Training.

<a id='a11b1b8b-fe5e-4f9c-a984-5d7ca3804131'></a>

26

<a id='40c779c8-4505-447d-825c-7d4f63bab7cf'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='47fc3360-7216-4c02-9313-8beadb1ef6de'></a>

- Vancouver Fire and Rescue Services conducts targeted recruitment drives and runs Camp Ignite, a youth mentorship program for girls in grades 11 and 12.
- Human Resources develops and delivers programs that address barriers to women's full inclusion such as a tele-mobility pilot, leadership development opportunities, and one-on-one leadership coaching. We proactively address human rights issues, workplace harassment and support respectful workplaces.

<a id='0a17573a-68ef-4769-8f38-054fde11a426'></a>

- Vancouver Board of Parks and Recreation is leading focus groups with female staff in leadership and operations in order to make improvements in the workplace.
- We work with partners to advance women's leadership and representation including:
    - Participating in research projects with partners like McKinsey Global Institute and the Conference Board of Canada.
    - We are in discussions with Women Transforming Cities about participating in a three-year study, "Action on Systemic Barriers to Women's Participation in Local Government".

<a id='efba1b44-af7b-4364-a45e-3960ca5252d6'></a>

Phase 1 Actions - Leadership & Representation
<table id="49-1">
<tr><td id="49-2">ACTIONS</td><td id="49-3">LEAD DEPARTMENT</td></tr>
<tr><td id="49-4">Sign Minerva BC&#x27;s Face of Leadership™ Diversity Pledge, making a public commitment to support women&#x27;s advancement in leadership in our workforce and in our community.</td><td id="49-5">Human Resources</td></tr>
<tr><td id="49-6">Develop and implement a Breastfeeding Policy for City staff.</td><td id="49-7">Human Resources</td></tr>
<tr><td id="49-8">Conduct focus groups with female staff in leadership and under-represented positions.</td><td id="49-9">Human Resources</td></tr>
<tr><td id="49-a">Measure and publicly report annually on the City&#x27;s workforce composition including positions and compensation.</td><td id="49-b">Human Resources</td></tr>
<tr><td id="49-c">Address potential bias in hiring process by training recruitment staff to recognize and mitigate unconscious bias.</td><td id="49-d">Human Resources</td></tr>
</table>

<a id='2b7fb11e-01b9-4466-8634-efe3983bd3be'></a>

## Inputs for Future Consideration – Leadership & Representation

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in _Inputs for Future Consideration_. The Action Team will consider these over the life of the Strategy.

<a id='e2befae3-99e6-43bd-9c06-2372d123c35f'></a>

27

<a id='6003d56a-3d08-4119-a2d0-5281ae17398c'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='baac1f24-d1a8-4b4a-b7de-b44921acf484'></a>

<::A woman with dark hair styled in a braid and wearing glasses, a grey long-sleeved top, and a patterned tunic top is speaking into a microphone, holding it with her right hand and gesturing with her left hand. She is standing in what appears to be a conference or workshop room. In the background, several people are seated at tables, some looking towards the speaker, and various items like water bottles, papers, and what look like presentation boards or posters are visible. The overall setting suggests an interactive discussion or presentation.: photo::>

<a id='fe969bde-d154-4a6e-a73e-78f272ec2530'></a>

ACCOUNTABILITY

<a id='fdd9cb5f-5a1d-4b6e-ac90-4e1b7f0b6d2c'></a>

All of the priority actions have an identified lead department responsible for the implementation of that action.

<a id='b78ae3b6-1e10-4943-9e82-e0e4405888f7'></a>

The Action Team has overall responsibility for the Strategy and for ensuring that actions are completed and progress towards goals is measured over time.

<a id='b7c3b13a-96f5-4a15-b3b0-a307fd20dd8c'></a>

The Action Team will continue to consult with the Women's Advisory Committee and, as needed, with stakeholders throughout the life of this Strategy.

<a id='64d0ae79-60d6-4d85-8456-cb641e9105a1'></a>

A progress report will be provided to Council in 2019, outlining achievements to date and next steps.

<a id='34a8cb63-f240-44eb-a306-154c9ee067c5'></a>

28

<a id='6b6621f8-e018-4892-9590-150644462245'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='adf6c925-e523-462b-8224-15696e44f214'></a>

# ACKNOWLEDGEMENTS

The development of this Strategy took place on the unceded traditional territories of the Musqueam, Squamish and Tsleil-Waututh Nations.

<a id='a78d70c3-854c-4e0e-b8ea-dfe92eff9557'></a>

We are grateful to all of the members of the Women's Advisory Committee, including
Liaisons and recent past members, for their hard work and input throughout the
development of this Strategy.

<a id='8d9222b6-fecf-4f82-be75-0952355d5c97'></a>

## Women's Advisory Committee
* Miranda Mandarino, Chair
* Erin Arnold
* Terran Bell, Chair, Sub-Committee - Young Women
* Mebrat Beyene
* Desaraigh Byers
* Andrea Canales Figueroa
* Lindsay Clark, Chair, Sub-Committee Economic Equality and Opportunity for Women and Girls
* Missy Johnson
* Sharon Lau
* Fiona McFarlane
* Rebecca McNeil, Chair, Sub-Committee Awareness, Accessibility, Inclusivity, and Diversity
* Najmah Mohammed
* Christine O'Fallon, Chair, Sub-Committees - Ending Violence Against Women and Girls and Equity Strategy Implementation and Intersectionality/Gender Mainstreaming
* Miriam Palacios
* Paola Quiros
* Shirley Ross
* Margot Sangster
* Niki Sharma
* Rhonda Sherwood, Chair, Sub-Committee - Leadership & Representation
* Andrea Thompson
* Julie Wong
* Deb Gale, Staff Liaison
* Councillor Andrea Reimer, Council Liaison
* Councillor Elizabeth Ball, Council Liaison
* Commissioner Catherine Evans, Park Board Liaison

<a id='84bda8ca-f223-4f19-a15e-7e89414fdbb3'></a>

Special acknowledgment goes to former City Councillors Ellen Woodsworth and Anne Roberts who championed the City's 2005 Gender Equality Strategy. Ellen Woodsworth, founder of Women Transforming Cities, has been a consistent, persistent and powerful advocate on the full inclusion of women and girls in our cities. We are grateful for the time, expertise, and input that both Ellen and her team have provided during the development of this Strategy.

<a id='4574ff4b-5fe0-4069-988d-edb4a7917fa6'></a>

We are also grateful to the following individuals and organizations, whose expertise and experiences informed the development of this Strategy.

* BC Non-Profit Housing Association
* BC Society of Transition Houses
* Battered Women's Support Services
* City for All Women Initiative
* City of Ottawa
* City of Edmonton
* City of Calgary
* Downtown Eastside Women's Centre
* Ending Violence Association (EVA BC)
* Living in Community

<a id='473c7438-7f6d-45c2-8aa2-da218a865af6'></a>

29

<a id='2f5539cb-a2e3-4864-acd4-0f8f0bbf7ba2'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='c9ece2ff-0652-4e4d-b70c-8c4a141fe5fd'></a>

* Manitoba Status of Women
* Margot Young, Professor, Allard School of Law, University of British Columbia
* RainCity Housing and Support Society
* The Minerva Foundation for BC Women

<a id='feaef4e3-223c-40a9-9619-96e983b86a8d'></a>

* WISH Drop-In Centre Society
* Women Against Violence Against Women (WAVAW)
* Women Transforming Cities
* YWCA Metro Vancouver

<a id='eb4c44f3-a413-45fd-b908-0a0468ca7a38'></a>

We also acknowledge the contributions of the City Leadership Team and our staff, who provided assistance and input during the development of the Strategy:

<a id='c159686a-f4e0-4df6-a89c-e859da8ae951'></a>

City Leadership Team:
Sadhu Johnston, City Manager
Paul Mochrie, Deputy City Manager
Bill Aujla, General Manager, Real Estate and Facilities Management
Malcolm Bromley, General Manager, Park Board
Francie Connell, Director of Legal Services and City Solicitor
Jerry Dobrovolny, General Manager, Engineering Services
Patrice Impey, General Manager, Finance, Risk and Supply Chain Management
Gil Kelley, General Manager, Planning, Urban Design and Sustainability
Rena Kendall-Craden, Director, Corporate Communications
Kaye Krishna, General Manager, Development, Buildings and Licensing
Kathleen Llewellyn-Thomas, General Manager, Arts, Culture and Community Services
Andrew Naklicki, Chief Human Resources Officer
Adam Palmer, Chief Constable, Vancouver Police Department
Darrel Reid, Fire Chief and General Manager, Vancouver Fire & Rescue Services
Sandra Singh, City Librarian, Vancouver Public Library

<a id='05c2bd32-05dc-4167-bc06-47fdcf3b4eb9'></a>

Staff:
Therese Boullard, Superintendent Martin Bruce, Cathy Buckham, Heather Burpee,
Brian Butt, Lesley Campbell, Edna Cho, Deputy Sergeant Howard Chow, Gracen Chungath,
Keltie Craig, Alison Dunnet, Superintendent Marcie Flamand, Sue Goddard,
Heather Gordon, Ginger Gosnell-Myers, Yvonne Hii, Kathryn Holm, Dianna Hurford,
Kira Hutchinson, Vanessa Kay, Katrina Leckovic, Janice Mackenzie, Drazen Manojlovic,
Kiran Marohn, Christina Medland, Ty Mistry, Inspector Suzanne Muir, Cheryl Nelms,
Anne Nickerson, Howard Normann, Kelly Oehlschlager, Michele Pankratz, Randy Pecarski,
Lisa Prescott, Staff Sergeant Dawn Richards, Taryn Scollard, Rena Soutar, Art Stuivenberg,
Cheryl Williams, Shauna Wilton, Carol Ann Young, MaryClare Zak, Shannen Zaturecky

<a id='aaefeb16-f01a-4c9c-8aad-56faffdb92df'></a>

In addition to the organizations and individuals listed above, we reached out to the City's Advisory Committees (Type 'A') and the following organizations, inviting them to provide input through the survey, the public forum, and through direct contact with City staff.

<a id='982dda48-500f-448e-a61c-a496d666f977'></a>

30

<a id='e90e558b-3887-4cd2-8210-806cee02a948'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='be9edad8-cd70-4c9b-80bf-45227404d955'></a>

<table id="53-1">
<tr><td id="53-2">Aboriginal Mother Centre Society</td><td id="53-3">Philippine Women Centre of BC</td></tr>
<tr><td id="53-4">Association of Neighbourhood Houses BC</td><td id="53-5">Positive Women&#x27;s Network</td></tr>
<tr><td id="53-6">Atira Women&#x27;s Resource Society</td><td id="53-7">ProMotion Plus</td></tr>
<tr><td id="53-8">Aunt Leah&#x27;s Independent Lifeskills Society</td><td id="53-9">Providing Alternatives, Counselling &amp; Education (PACE) Society</td></tr>
<tr><td id="53-a">BC Federation of Labour</td><td id="53-b">Qmunity</td></tr>
<tr><td id="53-c">BC Housing</td><td id="53-d">UBC Centre for Race, Autobiography, Gender and Age studies (RAGA)</td></tr>
<tr><td id="53-e">BC Poverty Reduction Coalition</td><td id="53-f">Ray-Cam Cooperative</td></tr>
<tr><td id="53-g">BC Public Interest Advocacy Centre</td><td id="53-h">Rise Women&#x27;s Legal Centre</td></tr>
<tr><td id="53-i">Big Sisters of BC Lower Mainland</td><td id="53-j">Simon Fraser University Women&#x27;s Centre</td></tr>
<tr><td id="53-k">Black Lives Matter Vancouver</td><td id="53-l">Single Mothers Alliance</td></tr>
<tr><td id="53-m">Boys and Girls Clubs of South Coast BC</td><td id="53-n">Society for Canadian Women in Science and Technology</td></tr>
<tr><td id="53-o">Canadian Centre for Policy Alternatives - BC Office</td><td id="53-p">The Society for Children and Youth BC</td></tr>
<tr><td id="53-q">Canadian Federation of University Women BC Council</td><td id="53-r">South Vancouver Neighbourhood Housing</td></tr>
<tr><td id="53-s">CityReach Care Society</td><td id="53-t">Squamish Nation</td></tr>
<tr><td id="53-u">Coalition of Child Care Advocates of BC</td><td id="53-v">S.U.C.C.E.S.S.</td></tr>
<tr><td id="53-w">Cooperative Housing Federation of BC</td><td id="53-x">Supporting Women&#x27;s Alternatives Network (SWAN) Vancouver Society</td></tr>
<tr><td id="53-y">Disability Alliance BC</td><td id="53-z">The Kettle Society</td></tr>
<tr><td id="53-A">DTES Sex Workers United Against Violence Society (SWUAV)</td><td id="53-B">The University Women&#x27;s Club of Vancouver at Hycroft</td></tr>
<tr><td id="53-C">Elizabeth Fry Society of Greater Vancouver</td><td id="53-D">Tradeworks Training Society</td></tr>
<tr><td id="53-E">Entre Nous Femmes Housing Society</td><td id="53-F">Tsleil-Waututh Nation</td></tr>
<tr><td id="53-G">Feminist Research Education Development Action (FREDA) Centre for Research on Violence Against Women and Children</td><td id="53-H">UBC Women&#x27;s Centre</td></tr>
<tr><td id="53-I">First Call: BC Child and Youth Advocacy Coalition</td><td id="53-J">Urban Native Youth Association</td></tr>
<tr><td id="53-K">Immigrant Services Society</td><td id="53-L">Vancouver Aboriginal Community Policing Centre Society</td></tr>
<tr><td id="53-M">Jewish Family Services Agency</td><td id="53-N">Vancouver Aboriginal Friendship Society</td></tr>
<tr><td id="53-O">Justice for Girls</td><td id="53-P">Vancouver Native Health Society</td></tr>
<tr><td id="53-Q">Kiwassa Neighbourhood House</td><td id="53-R">Vancouver Native Housing Society</td></tr>
<tr><td id="53-S">Mavis McMullen Housing Society</td><td id="53-T">Vancouver Status of Women</td></tr>
<tr><td id="53-U">Mom2Mom Child Poverty Initiative Society</td><td id="53-V">Vancouver Women&#x27;s Health Collective</td></tr>
<tr><td id="53-W">MOSAIC BC</td><td id="53-X">VAST</td></tr>
<tr><td id="53-Y">Mount Pleasant Neighbourhood House</td><td id="53-Z">West Coast LEAF (Legal Education and Action Fund)</td></tr>
<tr><td id="53-10">Musqueam Nation</td><td id="53-11">West Coast Mental Health Network Society</td></tr>
<tr><td id="53-12">Pacific Community Resource Society (Broadway Youth Resource Centre)</td><td id="53-13">Westcoast Child Care Resource Centre</td></tr>
<tr><td id="53-14">Pacific Immigrant Resource Society</td><td id="53-15">Women&#x27;s Enterprise Centre</td></tr>
</table>

<a id='b79e4266-6f18-441f-84e0-05fe3e00e9a6'></a>

31

<a id='327f9222-75cd-4a17-a943-0062cbd8560e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='db73ec32-6dae-4a2c-b837-9c74dde5d9fe'></a>

<::logo: ENDNOTES
ENDNOTES
Bold, red, sans-serif text on a white background::>

<a id='87e96274-af37-4a9f-80e2-beb53f9c2057'></a>

1 Statistics Canada, Census Profile 2016 Catalogue no. 98-316-X2016001, Ottawa, Released August 2, 2017
2 Ivanova, Iglika and Klein, Seth, Working for a Living Wage, Canadian Centre for Policy Alternatives, April 2016
3 Statistics Canada Census Profile 2016 Catalogue no. 98-316-X2016001, Ottawa, Released August 2, 2017
4 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
5 Ibid.
6 Fact Sheet, BC Minimum Wage and Women, BC Federation of Labour, (online) http://bcfed.ca/sites/ default/files/attachments/BCFED%20minimum%20 wage%20fact%20sheet%20-%20women.pdf
7 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
8 Statistics Canada, Table 111-0019, Characteristics of individuals, taxfilers and dependents 15 years of age and over receiving employment insurance by age groups and sex, annual (number) (accessed: September 28, 2017)
9 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
10 Ibid.
11 Zhang, Xuelin, Statistics Canada, Catalogue no. 75-001-X, Perspectives, March 2009
12 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
13 Milan et al, Families, Living Arrangements and Unpaid Work, Component of Statistics Canada Catalogue no. 89-503-X, Women in Canada: A Gender-based Statistical Report, December 2011
14 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
15 Statistics Canada. Census Profile 2016 Catalogue no. 98-316-X2016001. Ottawa. Released August 2, 2017
16 Ministry of Social Development and Poverty Reduction, BC Government, News Release, September 1, 2015, (online) https://news.gov.bc.ca/releases/2015SDS10043-001405
17 Sinha, Maire, Family violence in Canada: A Statistical Profile, 2011, Component of Statistics Canada catalogue no 85-002-x, Juristat, XCanadian Centre for Justice Statistics, June 25, 2011
18 McLean, Gladys and Gonzalez Bocinski, Sarah, The Economic Cost of Intimate Partner Violence, Sexual Assault, and Stalking, Institute for Women's Policy Research, August 2017
19 McInturff, Kate, The Gap in the Gender Gap: Violence against women in Canada, Canadian Centre for Policy Alternatives, July 2013

<a id='ea4cf7b8-6686-453e-a769-211b96af0a74'></a>

20 Samuel Perreault, Criminal Victimization in Canada, Statistics Canada Catalogue, no. 85-002-X, Juristat, Canadian Centre for Justice Statistics, November 23, 2015
21 Hutchins, Hope, and Sinha, Maire, Measuring Violence Against Women: Statistical Trends, Statistics Canada, Catalogue 85-002-X, Juristat, February 25, 2013
22 My Health My Community Survey. Data as of August 14, 2014. Prepared by: Vancouver Coastal Health, Public Health Surveillance Unit, July 2017
23 Ibid.
24 The Power of Parity: Advancing Women's Equality in Canada, McKinsey Global Institute, June 2017
25 Perreault, Samuel, Criminal victimization in Canada 2014, Statistics Canada Catalogue no. 85-002-X, November 23, 2015
26 Ibid.
27 Ibid.
28 Arriagada, Paula, Women in Canada: A Gender-based Statistical report, First Nations, Métis and Inuit Women, Statistics Canada, Catalogue no 89-503-X, February 23, 2016
29 Ibid.
30 Burlock, Amanda, Women in Canada: A Gender-Based Statistical Report, Women with Disabilities, Catalogue no. 89-503-X, May 29, 2017
31 Ibid.
32 Ibid.
33 Ibid.
34 Women with Disabilities in Canada, Report to the Committee on the Rights of Persons with Disabilities on the Occasion of the Committee's Initial Review of Canada, Canadian Feminist Alliance for International Action (FAFIA) and Disabled Women's Action Network (DAWN Canada), February 2017
35 "Still 1 in 5: BC Child Poverty Report Card Executive Summary", First Call BC, 2016.
36 Ibid.
37 Ibid.
38 Sinha, Maire, Family violence in Canada: A statistical profile, 2010, Statistics Canada, Juristat, Catalogue no. 85-002-X, May 22, 2012
39 McInturff, Kate, The Gap in the Gender Gap, Violence Against Women, Canadian Centre for Policy Alternatives, July 2013
40 The Power of Parity: Advancing Women's Equality in Canada, McKinsey Global Institute, June 2017
41 Momani, Bessma and Stirk, Jillian, Diversity Dividend: Canada's Global Advantage, Special Report, Centre for International Governance Innovation and Fondation Pierre Elliot Trudeau Foundation, 2017

<a id='19324f2d-d932-4512-a434-959dc1fd8f7c'></a>

32

<a id='cac63fc0-e427-49c8-aa98-febd0ed6d500'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='e36e656c-00ef-4cfd-b1e4-0b1b0d416b06'></a>

<::A photo shows three young women standing together and smiling. The woman in the center, with light brown hair, is wearing a red t-shirt with the text "CITY VANCOUVER LIFEGUARD PARKS AND RECREATION" in a circular logo. She has a silver necklace with a small pendant. Her right arm is around the shoulder of the woman to her left, who has dark hair with reddish streaks and is wearing a white turtleneck sweater with a black strap across her chest, featuring a small circular badge. The center woman's left arm is around the shoulder of the woman to her right, who has dark hair and is wearing a black hooded sweatshirt with "POLO SE CO." printed in white on the front. The background is slightly out of focus, showing green trees and some buildings under a light sky.: figure::>

<a id='af0879b7-41c3-4f4b-a230-476aaa04ecb2'></a>

<::A circular black logo on a red t-shirt. The logo contains:
- Top arc text: CITY VANCOUVER
- Central large text: LIFEGUARD
- Bottom arc text: PARKS AND RECREATION
- A crest/shield graphic above "LIFEGUARD"
- A lifebuoy and crossed oars graphic below "LIFEGUARD"
: figure::>

<a id='b1142eac-6500-4bf9-bace-726a2d4d3e53'></a>

POLO SE
CO.

<a id='0c85c3a7-535f-4191-a71e-caa5f4165dd3'></a>

33

<a id='9ecc9672-badd-4955-b4bb-38ff4f055410'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='09694987-ce27-4ed3-999c-f88f4f26a936'></a>

SNAPSHOTS OF CITY'S
CURRENT ACTIONS

<a id='d142e103-21c3-485f-a3a4-085d10a5d6b6'></a>

<u>**PRIORITY: WOMEN'S SAFETY**</u>

<a id='5266acc0-bd36-46d2-add5-ab64b860f646'></a>

Arts, Culture and Community Services

**Healthy City Strategy** The Strategy includes the goal of "being and feeling safe and included" with targets to increase Vancouver residents' sense of safety by 10 per cent, and make Vancouver the safest major city in Canada by reducing violent crime, including sexual assault and domestic violence.

*   Action 9 in the 2015-2018 Action Plan includes development and delivery of broad-based training to enhance capacity when addressing conditions particularly trauma, that create vulnerability (including gendered violence and sex work).

<a id='cab1c3f3-7798-43a3-b9f0-865f79450770'></a>

***Direct Social Services Grants*** The grants include "Community Safety" as a priority and grant applicants are requested to specify how their programs ensure gender equity. The grants fund projects and programs to increase community safety including:
* outreach, supports and referrals to services for women experiencing violence or marginalization;
* projects aimed at preventing youth sexual exploitation;
* programs that increase access to safety and supports for sex workers; and,
* initiatives that create a safe city in which residents feel secure.

<a id='7759594d-9b02-4b90-a2aa-5312843f2cc9'></a>

**Sex Work Response Guidelines**
The Guidelines promote consistent,
nondiscriminatory, and respectful treatment
of anyone engaged in sex work when
accessing City services or interacting with
City employees.

<a id='ee1fbc3e-7d5e-45eb-b951-9306e85582cf'></a>

_Missing and Murdered Indigenous Women_
_and Girls Inquiry_ The City will provide
supportive healing space for women
attending and participating in the Inquiry.

<a id='276db279-695d-4df2-9ffb-5f990de78e2b'></a>

**_Downtown Eastside Women's Centre_**
**(DEWC) - _24 hour drop-in_** The City has
been working collaboratively with funding
partners to expand DEWC's operating
hours to fill a gap in daytime services,
including housing outreach, counselling,
women-centred health care and prepared
meals. In October 2017, Council approved a
one-time Capital Grant of up to $250,000
towards renovations for the shelter in
partnership with BC Housing.

<a id='a81de95b-4858-4f72-b361-e1a94cc43e9a'></a>

### Planning, Urban Design and Sustainability
Ensures safety is a key consideration in community planning:

*   Applies Crime Prevention Through Environmental Design (CPTED) principles in public spaces.
*   Ensures well-lit bus stops and sidewalks.
*   Builds welcoming mixed use public spaces to encourage residents to use public spaces and keep the streets busy and safe.

<a id='b1042f53-92a7-46cd-b7c4-b7f98f64c5c6'></a>

34

<a id='6c5fd399-464e-4c5b-aa6c-7b24d0ae9f41'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='bd564276-580f-4a32-b556-b0bde3f381f3'></a>

* Takes steps to ensure that women are included in the planning and development process by using an inclusive approach to engage

<a id='465abe40-656c-4a0a-a975-5e35c2fc66b5'></a>

neighbourhoods in planning and
development, including efforts to reach
out to all members of the community.

<a id='486653f2-61ae-49e0-bc3a-c4d08d997aad'></a>

## PRIORITY: CHILDCARE

### Investments and Grants

*   **_City of Vancouver Capital Plan_**
    The Capital Plan for 2015-2018 includes an investment of $30 million for childcare, which is expected to leverage an additional $50 million in partner contributions. This investment will add 500 spaces for children aged 0-4 years old, and 500 spaces for school age care.
*   **_Childcare Enhancement Grant_** The Grant supports licensed childcare programs serving high need families.
*   **_Childcare Program Development Grant_** The Grant supports non-profit organizations to open a new childcare program, or expand a program already in operation.
*   **_Childcare Program Stabilization Grant_**
    This is a one-time Grant to support non-profit childcare organizations facing a financial crisis that might jeopardize the continuity of their services.
*   **_Childcare Research, Policy Development, and Innovation Grant_**
    The Grant supports non-profit organizations involved in research, policy development, or related projects focused on improving childcare in Vancouver.
*   **_School-age Care Expansion Projects Grant_** The Grant funds non-profit organizations to create new licensed school-age childcare programs. Funds are for capital-related costs in Vancouver School Board facilities.

<a id='d0e8ec4e-07b6-491b-9a18-891c921ca376'></a>

* ***Nominal Rent*** Nominal rent is charged to 57 non-profit childcare centres in City and Park Board-owned or leased facilities, supporting over 2,400 childcare spaces.
* ***Neighbourhood Access Grant Pilot*** This pilot provides $45,000 per year to offer 19 childcare spaces at zero cost to vulnerable families in a Downtown Eastside childcare facility.
* ***Other Childcare Grants*** Recent examples include support for the Vancouver Aboriginal Early Years Network and for Indigenous cultural competency training for Early Childhood Educators.

<a id='4021247b-d9d8-4f85-9ff8-7fba8614349f'></a>

# Strategy and Policy
* ***Healthy City Strategy*** The Strategy includes commitments to high quality childcare design that supports healthy child development.
* ***Updated Childcare Strategy*** The updated Strategy is currently under development. It will:
  - Refresh policies, principles and goals to reflect current contexts.
  - Review operator selection criteria for City-owned childcare facilities, to be offered to non-profit operators at nominal rents.
  - Explore the hub model of integrated child and family services.

<a id='ff9b8499-60a0-414d-a352-6e326e13d717'></a>

35

<a id='12fba054-7034-4b91-b3ef-da106d423c91'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='7919a148-8c5e-4e9c-9f66-176b282913a7'></a>

* **Development Cost Levies (DCLs)**
DCLs are revenue sources used to fund the development of childcare facilities and other community amenities. Most new development in the City is subject to DCLs. Council recently increased the allocation of DCL revenue to childcare from 5 per cent to 13 per cent.
* **Joint Childcare Council** The City along with the Vancouver Board of Parks and Recreation and the Vancouver Board of Education work to support and deliver accessible, affordable, quality childcare spaces across the City.

<a id='1d0db91d-29ec-4e9a-85a7-9b59a4917be3'></a>

• **_ $10/day Child Care Plan_** City Council passed a motion in support of the Community Plan for a Public System of Integrated Early Care and Learning.

• **_Partnership with the Vancouver Board of Education_** City-funded retrofits have created 466 school-age childcare spaces in existing schools and four planned childcare centres serving ages 0-4 will be co-located with seismically upgraded elementary schools, creating 275 new childcare spaces.

<a id='fefec6dc-5b08-44b0-b9b9-cd2cd3814dcc'></a>

# PRIORITY: HOUSING

## Affordable, Social and Supportive Housing

*   **Housing Vancouver Strategy (2018-2027)** The City's new 10-year strategy will address housing affordability and the supply of 72,000 homes that our residents need.
*   **Healthy City Strategy (2012-2021)** This Strategy included targets from the City's previous Housing and Homelessness Strategy. The City made significant progress towards enabling new social housing units and supportive housing units. New targets have been established in the Housing Vancouver Strategy. The City's overall goal remains "a home for everyone."
*   **Housing Development on City Land** Twenty (20) City-owned sites have been offered to the provincial and federal governments to build affordable housing.

<a id='1cab61cf-3931-43e5-8ab1-86831905a9cd'></a>

* **Development Cost Levies (DCLs)** DCLs are revenue sources used to fund the development of housing, childcare facilities and other community amenities. Most new development in the City is subject to DCLs. Council recently increased DCL revenue allocations for replacement housing from 32 per cent to 36 per cent.
* **Homelessness Outreach Program** The program is a partnership with BC Housing aimed at providing income, housing and health supports to homeless people and those at risk of homelessness.
* **Homelessness Action Week Grants** These grants are provided to non-profit organizations to host events and organize projects to help homeless residents; create awareness of homelessness; and, engage citizens on solutions to homelessness.

<a id='444678b1-8765-4e16-b4e7-3da1f9c67df8'></a>

36

<a id='fe3469ad-f5f3-4d7f-a716-961ffd8d8b3e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='4d3b565f-5be5-4878-abb5-2d5bf358dd58'></a>

* *Housing Infrastructure Grants* These capital grants support non-profit led projects aimed at achieving viability or increasing affordability of new units, and for SRO upgrades. The 2015-18 Capital Budget includes $10 million in capital grants for new units, and $4 million for SRO upgrades.
* *Community Amenity Contributions (CAC)* CAC negotiations on developer-led projects provide the City with turn-key housing units. The City's standard process is to enter into long-term operating agreements with a non-profit to operate these developments.

<a id='c91bf9e6-94da-4b48-baaa-b1b817900d1a'></a>

## Family Housing

*   ***Housing Mix Policy for Rezoning Projects*** This policy requires that a minimum supply of family units be included in all new rezoning projects, specifically 35 per cent of units having two or more bedrooms.

<a id='3699222e-b11a-46f3-b22e-b971f56fde2b'></a>

# Rental Housing

*   ***Rental 100*** The Secured Market Rental Housing Policy encourages the development of projects where 100 per cent of the residential units are rental.
*   ***Empty Homes Tax*** The tax aims to bring thousands of rental homes back into the market.
*   ***Rental Housing Stock Official Development Plan*** The Plan requires that redevelopment projects with six or more dwelling units replace every demolished rental unit.
*   ***Rental Standards Database*** The Database allows renters to look up residential rental buildings with health,

<a id='221bd89e-1e39-4414-8d6e-3e94ef836f1a'></a>

safety, maintenance, tidiness, and other
issues.

<a id='0adabe0d-5d60-4474-8208-449f3112fa0c'></a>

• **Laneway housing zoning** This zoning was introduced to increase rental and family housing in single-family areas.
• **Vancouver Rent Bank** The City funds the Bank, which provides one-time interest-free loans to low-income people in temporary financial crisis as well as advocacy and referral services.

<a id='53a0b2f3-bd5b-48dc-b59c-d6e01fbebe70'></a>

## Partnerships and Collaborations
* The City continues to work with provincial and non-profit housing partners to:
  - Support delivery of housing targeted to women and families through grants and provision of land for social housing.
  - Support programs and services targeting women fleeing domestic violence or in need of emergency shelter, social and supportive housing.

<a id='20430d08-ccca-4490-b349-88ccbf4d1fae'></a>

* ***Metro Vancouver Regional Homelessness Task Force*** The Task Force was struck in November 2016 in response to historic levels of homelessness throughout the region, and the need for systemic improvements from all levels of government and the non-profit sector to manage the crisis.
* ***Renters Advisory Committee*** The Committee advises Council on City priorities relating to renters; monitors and responds to the impacts of provincial and federal legislation affecting tenants; and, advises Council on enhancing access and inclusion for renters in developing City policy and civic life.

<a id='273d9062-233f-4228-a50d-8e5c8b560e2d'></a>

37

<a id='adf6b4c5-c509-4d62-b901-c469d6e65927'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='3391812a-fbe7-45f3-bbae-a514ee51d58e'></a>

PRIORITY: LEADERSHIP & REPRESENTATION

<a id='d6e36825-ee54-49ca-b223-a1322d6f4bb0'></a>

# Programs and Initiatives

*   **_Living Wage Employer_** As a certified living wage employer, the City is committed to paying its employees and contracted service employees a living wage. Metro Vancouver's living wage rate for 2017 is $20.62 per hour.
*   **_Engineering Services_**
    *   Has a Diversity & Inclusion Working Group with the goal of increasing the representation and retention of a diverse staff that represents our community.
    *   Has increased the representation of women on its Senior Executive team from 0% to 50%, between 2010 and 2017.
    *   Wellness rooms for staff have been created at two locations for prayer, breast feeding, and general wellness.
*   **_Vancouver Fire and Rescue Services_**
    *   Developed a pregnancy policy for women firefighters (2016).
    *   Maternity uniform is offered to female firefighters (instead of uniforms in larger sizes).
    *   Dual gender washrooms are being built in all replacement fire halls in addition to making modifications to existing washrooms in fire halls where possible.
    *   Unofficial mentoring by female firefighters to young girls through the '_Camp Ignite_' and '_Youth Academy_' program.

<a id='3019d280-d45d-453f-b2b8-e137dc3eb6c9'></a>

- Recruitment and Outreach division conducts recruitment drives, actively participates in community events, and attends career fairs in efforts to reach under-represented groups.
- **Human Resources**
  - Currently piloting tele-mobility program for exempt staff.
  - The Equal Employment Opportunity Office leads work related to equity, diversity and inclusion, including:
    - Assists departments with targeted outreach and assistance on hiring and retaining a diverse workforce that reflects the community.
    - Acts as resource to all City staff regarding human rights issues, workplace harassment prevention and sustaining respectful workplaces.
    - Provides training to staff on human rights, workplace harassment, cultural competency, diversity and inclusion.
  - One-on-one leadership coaching and leadership development courses and events are made available to City leaders, including women leaders. The coaching and courses aim to enhance performance in leadership roles and to support transition to higher levels of leadership.
- **Vancouver Board of Parks and Recreation** is leading focus groups with female staff in leadership and Park Operations. A follow-up strategy and action plans are in development.

<a id='256e06ae-c690-4497-8c9e-43add22d0abc'></a>

38

<a id='d2b77fbe-d11d-489c-bf53-67dea9bcb33d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='c98582d5-fc6b-4075-86db-3996cb6b7f6d'></a>

## Related Policies and Procedures
* Human Rights and Harassment Policy
* Respectful Workplace Policy
* Multicultural Policy
* Employment Equity
* Occupational Health and Safety Policy
* Maternity and Parental Leaves
* Job-Sharing
* Job Evaluation and Compensation

<a id='e5930884-c2f0-4a5f-bd29-2e2f006431d3'></a>

Collaborations and Partnerships

*   The City participates in **research projects** such as McKinsey Global Institute's "The Power of Parity: Advancing Women's Equality in Canada" and the Conference Board of Canada's research on diversity and inclusion.
*   **Greenest City Action Team Scholars**
    The program was established in 2010 with a City of Vancouver - UBC Partnership Agreement. The program engages UBC graduate students to work on sustainability projects in support of the Greenest City 2020 Action Plan. To date, over 100 students have gone through the program and over half of the students have been female.

<a id='169cb63a-5563-4e1c-8913-6882722ec877'></a>

• **<u>CityStudio Vancouver</u>** CityStudio engages students and faculty from six post-secondary institutions to contribute to projects on the City's <u>Greenest City Action Plan</u>, <u>Healthy City Strategy</u> and <u>Engaged City Strategy</u>. With 195 projects to date, CityStudio has engaged 3,500 students, 163 faculty and 75 City staff since its inception. To date, half of the students have been female.
• **Mentorship Program for New Immigrant Professionals** The Program is offered in partnership with the Immigrant Employment Council of BC (IEC-BC). The Program matches City staff with new immigrants of similar professional backgrounds. Now in its sixth year, over 200 immigrant professionals have benefited. In 2017, 59 per cent of our mentors were female.
• **Indigenous Internship Program** The Program is offered in partnership with the Aboriginal Community Career Employment Services Society (ACCESS). This capacity-building, 20-month long internship program assists Indigenous applicants to further develop their knowledge, skills and experience. The current program has five interns, three of which are female.

<a id='e179a85b-13c0-46ec-906d-5d9794e9b58f'></a>

39

<a id='cf6cec97-05b4-4cbe-a8cf-9c0b43340457'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='b94faf5b-3381-4c71-bbfb-48de2b9e3828'></a>

INPUTS FOR FUTURE
CONSIDERATION

<a id='0ce93016-f55c-4a8a-afdb-dd9a8355609d'></a>

The following are ideas and inputs received during stakeholder consultations and research.
These will be considered by the Action Team over the life of the Strategy.

<a id='89ce9385-ea9a-4c6a-a508-f25974afaa37'></a>

INTERSECTIONAL LENS
<table id="62-1">
<tr><td id="62-2">INPUTS</td><td id="62-3">SOURCE(S)</td></tr>
<tr><td id="62-4">Become a City for CEDAW (Convention on the Elimination of all forms of Discrimination Against Women) and take follow up actions further to Mayor&#x27;s Guide: Accelerating Gender Equality, including: • Establish a Department/Position on the Status of Women. • Fund a report on the status of women in the city. Publicize data to identify areas of improvement. • Develop a public education campaign on the status of women.</td><td id="62-5">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="62-6">Adopt a Charter of Rights and Freedoms for the City and create an Ombudsperson Office that reports to the City Manager to oversee complaints under the Charter and all public complaints against the City (see City of Montreal, as example).</td><td id="62-7">• Internal Subject Matter Expert • External Subject Matter Expert</td></tr>
<tr><td id="62-8">Ensure that all internal and external communication is accessible and available in multiple formats and languages.</td><td id="62-9">• Best Practice</td></tr>
<tr><td id="62-a">Involve stakeholders in developing goals and measuring performance.</td><td id="62-b">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • Best practice</td></tr>
<tr><td id="62-c">Establish permanent City advisory committee on the Status of Women.</td><td id="62-d">• Women&#x27;s Advisory Committee • Public Survey • Best Practice</td></tr>
<tr><td id="62-e">Gather disaggregated data to support implementation of intersectional framework that aligns with best practices.</td><td id="62-f">• Women&#x27;s Advisory Committee • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
</table>

<a id='9111c55f-bca2-401f-b783-7a0e53982ebd'></a>

40

<a id='d02a83be-fb96-458e-aba2-0701b50f0a25'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='1bf8126d-50d6-4d05-a819-fad476727ffa'></a>

<table id="63-1">
<tr><td id="63-2">INPUTS</td><td id="63-3">SOURCE(S)</td></tr>
<tr><td id="63-4">Apply a gender equity/intersectional lens to the City budget.</td><td id="63-5">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • Best Practice</td></tr>
<tr><td id="63-6">Adopt a participatory budgeting process.</td><td id="63-7">• Public Forum • Best Practice</td></tr>
<tr><td id="63-8">Hold leaders accountable for diversity and inclusion goals (internal, external), results, and being role models.</td><td id="63-9">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="63-a">Implement and report out on Advancing Equity and Inclusion: A Guide for Municipalities.</td><td id="63-b">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="63-c">Implement gender budgeting and GBA+ across all City activities.</td><td id="63-d">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="63-e">Report out annually on progress in reaching gender equity/ diversity goals.</td><td id="63-f">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="63-g">Apply intersectional approach to a participatory planning process to ensure full inclusion of all citizens.</td><td id="63-h">• Public Forum</td></tr>
<tr><td id="63-i">Create Community Leaders&#x27; Group to advise on the implementation of the Women&#x27;s Equity Strategy.</td><td id="63-j">• External Subject Matter Expert</td></tr>
</table>

<a id='a6283828-f8d3-4bf3-8833-cb4112991dd3'></a>

WOMEN'S SAFETY
<table id="63-k">
<tr><td id="63-l">INPUTS</td><td id="63-m">SOURCE(S)</td></tr>
<tr><td id="63-n">Consider women&#x27;s needs in neighbourhood planning and development, including women&#x27;s safety. Apply a gender lens to CPTED (Crime Prevention through Environmental Design) Guidelines.</td><td id="63-o">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="63-p">Create a centralized women&#x27;s hub to locate all violence-related services in one accessible location.</td><td id="63-q">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="63-r">Develop partnership agreements with community partners to do comprehensive prevention work.</td><td id="63-s">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='e0821794-6dd2-450a-a523-087b9499a44e'></a>

41

<a id='e1c62962-1514-45bf-b167-733e5908b74a'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='8c2be517-03a6-4d70-abd0-9c668d395ed8'></a>

<table id="64-1">
<tr><td id="64-2">INPUTS</td><td id="64-3">SOURCE(S)</td></tr>
<tr><td id="64-4">Create and/or increase assertiveness and self-defense training classes at community centres.</td><td id="64-5">• Public Survey • Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-6">Conduct public campaign to raise awareness of violence against women. Create page on City website as part of public campaign.</td><td id="64-7">• Women&#x27;s Advisory Committee • External Subject Matter Experts</td></tr>
<tr><td id="64-8">Develop and implement a comprehensive civic action plan to end violence against women. Include annual report on current status, such as how long the wait list for counseling, and use of shelter space.</td><td id="64-9">• Women&#x27;s Advisory Committee • Public Forum • External Subject Matter Experts</td></tr>
<tr><td id="64-a">Include in City communications opportunities for City leaders to speak out against violence against women, misogyny and systemic oppression.</td><td id="64-b">• Women&#x27;s Advisory Committee • External Subject Matter Experts</td></tr>
<tr><td id="64-c">Establish an integrated interagency service team on violence against women, including intimate partner violence.</td><td id="64-d">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-e">Fund employment training programs for women leaving violence.</td><td id="64-f">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-g">Fund non-profit organizations working to stop violence against women.</td><td id="64-h">• Public Forum
• Public Survey
• External Subject Matter Experts</td></tr>
<tr><td id="64-i">Increase well-lit public parking near SkyTrain stations.</td><td id="64-j">• Public Survey</td></tr>
<tr><td id="64-k">Install security measures (e.g. CCTV-type cameras and panic buttons) in locations identified with higher crimes and assaults against women.</td><td id="64-l">• Public Survey
• Best Practice</td></tr>
<tr><td id="64-m">Ensure access to mechanisms that will guarantee women&#x27;s rights in the event they are subjected to violence.</td><td id="64-n">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-o">Implement mandatory violence against women training for City of Vancouver staff.</td><td id="64-p">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-q">Provide free city space to non-profit organizations working to stop violence.</td><td id="64-r">• Best Practice</td></tr>
<tr><td id="64-s">Develop and distribute publication (online and print) with information and resources on women&#x27;s safety. Make it available in all City public locations (community centres, libraries, etc.) in multiple languages.</td><td id="64-t">• Women&#x27;s Advisory Committee • External Subject Matter Expert</td></tr>
<tr><td id="64-u">Work with and support community groups that deal with and respond to harassment/violence against women in the night life industry and at music festivals.</td><td id="64-v">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='8272deb5-271a-42d3-ba60-d9587eeb2f28'></a>

42

<a id='bcf1c675-f78f-4560-95dd-d3ba5c2febe5'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6499f808-7ace-4e92-a0ea-5ab0e506048c'></a>

<table id="65-1">
<tr><td id="65-2">INPUTS</td><td id="65-3">SOURCE(S)</td></tr>
<tr><td id="65-4">Support efforts to improve women&#x27;s safety on campuses within Vancouver.</td><td id="65-5">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="65-6">Address sexualization of women and girls by banning sexualized images and ads in public spaces (transit, billboards, etc). For example, see YWCA advocacy on issue: https://ywcavan.org/advocacy/sexualization-women-and-girls</td><td id="65-7">• Public Forum • Public Survey</td></tr>
<tr><td id="65-8">Advocate/use leverage on TransLink Board to encourage TransLink to: • increase safety measures in SkyTrain stations and on buses and SkyTrains; • increase awareness of current safety measures (e.g. request stop); • address privacy and safety concerns with COMPASS card tracking; and, • involve/consult women in development of new routes, bus stops and stations.</td><td id="65-9">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • Best Practice</td></tr>
<tr><td id="65-a">Recommendations for the Vancouver Police Department • Provide officers with training in cultural competency, trauma-informed approaches, and how to deal with domestic and other violence against women. Training should be delivered by local experts and people with lived experience. • Decriminalize the behaviours of women with mental health issues. • Apply improved language around violence against women - do not use victim-blaming language. • Provide increased funding and other resources to Aboriginal Policing Centre. • Recruit more female police officers. • Create multilingual/multicultural teams to support immigrant and refugee women. • Ensure access to mechanisms that will guarantee women&#x27;s rights in the event they are subjected to violence.</td><td id="65-b">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="65-c">Recommendation for the Vancouver Public Library • Promote ending violence against women through book buying, use of space, resources, programming, signage, communications.</td><td id="65-d">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='0f551106-658a-4468-b547-2377fbffbc60'></a>

43

<a id='7940b5bc-a4e6-4db6-9e13-040acb52378e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='be3637c2-c898-47ce-a46b-e46ecb5766c8'></a>

CHILDCARE
<table id="66-1">
<tr><td id="66-2">INPUTS</td><td id="66-3">SOURCE(S)</td></tr>
<tr><td id="66-4">Take actions to increase civic participation of families, for example: • Reimbursement for childcare expenses for members of civic advisory committees (e.g., living wage x 3 hours/ month); • Provide childcare or child-minding corner on site at public events; • Provide childcare reimbursement for speakers at events; and, • Facilitate participation of parents at events by offering speakers with young children the option of presenting early on an evening agenda.</td><td id="66-5">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="66-6">Continue to encourage the development of quality childcare facilities.</td><td id="66-7">• Women&#x27;s Advisory Committee • Public Survey • Public Forum</td></tr>
<tr><td id="66-8">Encourage addition of family rooms in all public spaces.</td><td id="66-9">• Public Survey</td></tr>
<tr><td id="66-a">Expand the existing supply of quality childcare facilities and programs.</td><td id="66-b">• Internal Subject Matter Expert • Public Forum • Public Survey</td></tr>
<tr><td id="66-c">Advocate and promote a living wage for childcare providers.</td><td id="66-d">• Public Survey</td></tr>
<tr><td id="66-e">Provide property tax relief to childcare providers.</td><td id="66-f">• Public Forum</td></tr>
<tr><td id="66-g">Support trans girls in childcare facilities.</td><td id="66-h">• Public Forum</td></tr>
<tr><td id="66-i">Look for innovative development opportunities to locate new childcare facilities where they can best serve families, including through co-location with schools and community serving organizations.</td><td id="66-j">• Public Survey • Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='426faed8-7ec0-4d90-b98b-f5c1804007bb'></a>

HOUSING
<table id="66-k">
<tr><td id="66-l">INPUTS</td><td id="66-m">SOURCE(S)</td></tr>
<tr><td id="66-n">Adopt UN Definition of &quot;Adequate Housing&quot;.</td><td id="66-o">• External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="66-p">Advocate for housing strategies at the provincial and federal levels that support the diverse housing needs of women.</td><td id="66-q">• Public Forum • Public Survey • External Subject Matter Experts</td></tr>
</table>

<a id='2c4ddaef-94ee-4467-8e9e-9b21721e3cbc'></a>

44

<a id='ed711af1-0aa9-4932-8f8a-74e5e1ba4db6'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='57ba5f12-0d4a-4534-922f-21f87da26030'></a>

<table id="67-1">
<tr><td id="67-2">INPUTS</td><td id="67-3">SOURCE(S)</td></tr>
<tr><td id="67-4">Apply a gender/intersectional lens to the implementation of the Housing Vancouver Strategy.</td><td id="67-5">• Public Forum • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="67-6">Carry out research to better understand women&#x27;s homelessness and to deepen our understanding of homelessness (and hidden homelessness) for all women (including Indigenous women). Integrate findings into implementation of Housing Vancouver Strategy.</td><td id="67-7">• Women&#x27;s Advisory Committee • Internal Subject Matter Expert • Public Forum • External Subject Matter Experts</td></tr>
<tr><td id="67-8">Support effective models of &#x27;housing first&#x27; for women.</td><td id="67-9">• External Subject Matter Experts</td></tr>
<tr><td id="67-a">Coordinate and streamline City housing grants to simplify applications.</td><td id="67-b">• External Subject Matter Expert</td></tr>
<tr><td id="67-c">Measure and report out on the impact of City housing grants, including data gathering/ indicators for success in gender responsive programs and services.</td><td id="67-d">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="67-e">Continue to apply inclusionary zoning to increase the supply of affordable housing.</td><td id="67-f">• Public Survey • External Subject Matter Experts • Best Practices</td></tr>
<tr><td id="67-g">Develop affordable housing targeted to women and women-led families, in particular women who are leaving intimate partner violence, in partnership with women&#x27;s anti-violence organizations.</td><td id="67-h">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • External Subject Matter Experts • Best Practices</td></tr>
<tr><td id="67-i">Continue to ensure new housing is accessible and meets the needs of families through Enhanced Accessibility Guidelines and the High-Density Housing for Families with Children Guidelines (in the process of being updated).</td><td id="67-j">• Internal Subject Matter Expert</td></tr>
<tr><td id="67-k">Continue to work with provincial and non-profit housing partners to: • support delivery of housing targeted to women and families through grants and provision of land for social housing; and, • support programs and services targeting women fleeing domestic violence or in need of emergency shelter, social and supportive housing.</td><td id="67-l">• Internal Subject Matter Expert</td></tr>
</table>

<a id='48164353-896a-44cc-bdff-2f59dd2b0858'></a>

45

<a id='d9fc4946-3ccc-468f-9e65-233df1a83014'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='56d7eae5-91c7-4100-9676-9253f9f316bd'></a>

<table id="68-1">
<tr><td id="68-2">INPUTS</td><td id="68-3">SOURCE(S)</td></tr>
<tr><td id="68-4">Create liaison/outreach role within Coordinated Access Centre to work with women-serving organizations to identify women in need of priority housing.</td><td id="68-5">• Internal Subject Matter Expert</td></tr>
<tr><td id="68-6">Develop and deliver anti-discrimination training initiatives for landlords.</td><td id="68-7">• Public Forum • External Subject Matter Experts</td></tr>
<tr><td id="68-8">Create anti-discrimination regulations, enforcement, and education to address landlord discrimination against families, single mothers, women fleeing violence.</td><td id="68-9">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="68-a">Generate a housing strategy that addresses the distinctive and diverse housing and homeless circumstances of women, such as vulnerability to violence, income inequality and family responsibilities. and Identify and implement opportunities within new non-market/social housing to reserve spaces for women in priority need, including women leaving intimate partner violence.</td><td id="68-b">• Women&#x27;s Advisory Committee • External Subject Matter Experts</td></tr>
<tr><td id="68-c">Increase range of alternative housing tenures, family-oriented and culturally diverse design solutions across the housing continuum - co-housing, intergenerational housing, childcare space integrated in housing, etc.</td><td id="68-d">• Public Forum • Public Survey • External Subject Matter Experts • Best Practices</td></tr>
<tr><td id="68-e">Ensure that neighbourhood planning and development considers women&#x27;s and families&#x27; needs.</td><td id="68-f">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practices</td></tr>
<tr><td id="68-g">Develop specific actions within the City&#x27;s housing strategy to address homelessness of Indigenous women.</td><td id="68-h">• External Subject Matter Expert</td></tr>
<tr><td id="68-i">Advocate for regulations requiring increased overnight staff at women&#x27;s transition houses/shelters.</td><td id="68-j">• Public Forum</td></tr>
<tr><td id="68-k">Support efforts to centralize housing waitlists and use coordinated approaches to tenant selection. Include clause in City of Vancouver operating agreements with non-profit housing agencies that they register all of their housing with BC Housing registry.</td><td id="68-l">• External Subject Matter Expert • Internal Subject Matter Expert</td></tr>
<tr><td id="68-m">Fund workforce development programs in transitional housing for women coming home from prison.</td><td id="68-n">• Public Forum</td></tr>
</table>

<a id='44e0e657-6d67-4bef-ae15-1cbbdc0aa09b'></a>

46

<a id='542fb0d6-6dba-46b3-802f-cdf50bd142b3'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='5db3f577-64c3-45dd-8b23-99a26d4f0824'></a>

LEADERSHIP & REPRESENTATION

<a id='dcaf2f1b-6361-4089-afb3-a82fa706b2c6'></a>

<table id="69-1">
<tr><td id="69-2">INPUTS</td><td id="69-3">SOURCE(S)</td></tr>
<tr><td id="69-4">Develop and implement an Equity and Inclusion Strategy for the City&#x27;s workplace.</td><td id="69-5">• Women&#x27;s Advisory Committee • Public Survey • Internal Subject Matter Expert • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-6">Audit human resources&#x27; processes for bias (including job descriptions and job advertisements) and implement improvements.</td><td id="69-7">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-8">Conduct an employee engagement survey to assess current employees&#x27; views on opportunities for advancement, and sense of inclusion in the workplace.</td><td id="69-9">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="69-a">Create an internal employee resource group on women in leadership.</td><td id="69-b">• Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-c">Create mentorship and sponsorship opportunities for women in leadership and in historically under-represented occupations.</td><td id="69-d">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-e">Create opportunities for paid internships for women in historically under-represented occupations.</td><td id="69-f">• Women&#x27;s Advisory Committee • Public Forum • Public Survey</td></tr>
<tr><td id="69-g">Provide information sessions, job shadowing, and/or worksite tours to encourage recruitment of women in historically under-represented occupations.</td><td id="69-h">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="69-i">Create an initial applicant screening that is gender-blind.</td><td id="69-j">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="69-k">Educate recruitment staff on intercultural communication and unconscious bias</td><td id="69-l">• Women&#x27;s Advisory Committee • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="69-m">Ensure that hiring panels reflect diversity.</td><td id="69-n">• Public Survey • Best Practice</td></tr>
</table>

<a id='f0433eb7-a329-45f1-94d0-6b7cbf512f8b'></a>

47

<a id='c05e3dd3-8e4f-4a2d-8f71-6b1e47d722b7'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='62008722-d92d-4bb6-8bb3-7d5c3faea02b'></a>

<table id="70-1">
<tr><td id="70-2">INPUTS</td><td id="70-3">SOURCE(S)</td></tr>
<tr><td id="70-4">Gather disaggregated data to support implementation of intersectional framework that aligns with best practices. Include pay equity monitoring in data gathering.</td><td id="70-5">• Women&#x27;s Advisory Committee • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="70-6">Conduct a statistical gender analysis of the recruitment and selection processes to determine whether women are being disproportionately screened out at any stage.</td><td id="70-7">• Best Practice</td></tr>
<tr><td id="70-8">Host roundtable of female municipal leaders.</td><td id="70-9">• Internal Subject Matter Expert</td></tr>
<tr><td id="70-a">Implement formal return to work programs for staff returning from extended care leaves.</td><td id="70-b">• Public Survey • Best Practice</td></tr>
<tr><td id="70-c">Implement new leadership competencies and training on managing diversity.</td><td id="70-d">• Women&#x27;s Advisory Committee • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="70-e">Increase options for flexible work schedules and job sharing.</td><td id="70-f">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="70-g">Monitor leadership training and development programs to ensure women&#x27;s leadership training needs are appropriately identified and met. Gather data track participation of women in leadership development programs.</td><td id="70-h">• Women&#x27;s Advisory Committee • Internal Subject Matter Expert</td></tr>
<tr><td id="70-i">Conduct outreach to school-aged girls (grades 4-6) to promote historically under-represented occupations and occupations in science, technology, engineering and mathematics (STEM).</td><td id="70-j">• Internal Subject Matter Expert • Public Survey • Best Practice</td></tr>
<tr><td id="70-k">Participate in Women Transforming Cities research &quot;Taking Action on Systemic Barriers to Women&#x27;s Participation in Local Government.&quot;</td><td id="70-l">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="70-m">Report out annually on staff pay and workforce composition in an easy-to-find place on the website.</td><td id="70-n">• Public Survey • Women&#x27;s Advisory Committee</td></tr>
<tr><td id="70-o">Pay Equity - Review data collection practices for pay equity monitoring purposes.</td><td id="70-p">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
</table>

<a id='d021e44c-6d0e-46a2-9108-670ae6f988e8'></a>

48

<a id='0f94bf37-aa98-448b-949d-42d76afd3d8d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='c23b2078-daeb-4e05-95c5-4356448a8e76'></a>

<table id="71-1">
<tr><td id="71-2">INPUTS</td><td id="71-3">SOURCE(S)</td></tr>
<tr><td id="71-4">Develop options for providing childcare to City workers.</td><td id="71-5">• Public Survey • Best Practice</td></tr>
<tr><td id="71-6">Report out on annually on progress of diversity and inclusion initiatives.</td><td id="71-7">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="71-8">Examine procurement process (contracting) to either require or award extra points for bidders who demonstrate: • Anti-discrimination/harassment policies • Pay equity • Diversity and inclusion initiatives</td><td id="71-9">• Women&#x27;s Advisory Committee • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="71-a">Target recruitment initiatives to women in historically under-represented occupations.</td><td id="71-b">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="71-c">Target recruitment ads to diverse communities.</td><td id="71-d">• Public Survey
• Best Practice</td></tr>
<tr><td id="71-e">Work with Vancouver School Board to highlight women throughout the school curriculum.</td><td id="71-f">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="71-g">Provide training to City staff in:
• Anti-racism
• Anti-oppression
• Intersectionality</td><td id="71-h">• Public Survey
• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="71-i">Create internships and skills-based training opportunities for single mothers to acquire new skills and improve their quality of life.</td><td id="71-j">• Public Survey</td></tr>
<tr><td id="71-k">Use the Harvard Implicit Bias test to measure bias and take steps to mitigate bias.</td><td id="71-l">• Public Forum
• Public Survey</td></tr>
<tr><td id="71-m">Name 50 per cent of public spaces and places after the full diversity of women (e.g. Angie Todd Denis) and women&#x27;s history in Vancouver.</td><td id="71-n">• Public Survey • Public Forum • Women&#x27;s Advisory Committee</td></tr>
<tr><td id="71-o">Reinstate the &quot;Remarkable Women&quot; poster series.</td><td id="71-p">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='b825c5d1-d3d6-408f-a146-e611a9981f21'></a>

49

<a id='8ea65a7b-367a-4fbc-b5cb-58a506bbbe77'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='c8d0908d-0a72-4ab1-80e3-d5f44c184e80'></a>

<::A woman with brown hair, wearing a black blazer and a green skirt, smiles at the camera while presenting a framed certificate to another woman. The second woman, with brown hair and a leopard print headband, wears a brown corduroy jacket and a black turtleneck, smiling while holding the certificate. The certificate reads: "CERTIFICATE OF APPRECIATION Marlene Abbott-Peter Team BC Coach 2015 CANADA WINTER GAMES - WHEELCHAIR BASKETBALL". The left side of the certificate holder displays an image of a structure with fire, possibly an Olympic cauldron. In the background, national and provincial flags are visible, including the Canadian flag and the flag of British Columbia.: figure::>

<a id='1a5b0582-6420-4894-89a0-8c9b74484e3d'></a>

50

<a id='76331eab-c106-4f72-b6fd-7ebe81b735fa'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='e882a64e-e6b4-49cc-ac87-ca0933ed2f0a'></a>

<::logo: City of Vancouver
CITY OF
VANCOUVER
This logo features a stylized blue and green leaf or petal design.::>

<a id='323edba7-e76a-4e0a-945d-cf034aed49b8'></a>

453 West 12th Avenue
Vancouver, British Columbia
Canada V5Y 1V4

<a id='c170aeff-adcd-4b81-94f3-77ce6ef57154'></a>

website: vancouver.ca

@CityofVancouver

/CityofVancouver

phone: 3-1-1

<a id='084fc72e-deed-4286-ae0c-6950ed10cb6c'></a>

18-025