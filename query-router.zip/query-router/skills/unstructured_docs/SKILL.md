---
name: unstructured_docs
description: >
  Chatbot API for unstructured deal documents. Answers questions about
  the content of IPO prospectuses, M&A merger agreements, BizDev proposals,
  Debt term sheets, board decks, and other deal-related filings. Use for
  clause interpretation, risk factor extraction, disclosure language,
  document summarization, or any question that requires reading and
  interpreting prose from deal documents.
trigger: >
  when user asks what a document says, about specific clauses, risk
  factors, disclosures, terms, conditions, or any content that lives
  in deal documents (IPO, M&A, BizDev, Debt filings)
category: data_source
parameters:
  - name: query
    type: string
    required: true
    description: Natural-language question to send to the document chatbot
---

# Unstructured Documents Skill

Wraps the unstructured-document chatbot API that has access to:
- **IPO** — prospectuses, S-1 filings, pricing supplements
- **M&A** — merger agreements, definitive agreements, proxy statements
- **BizDev** — partnership proposals, LOIs, term sheets
- **Debt** — credit agreements, indentures, offering memoranda
- **General** — board decks, fairness opinions, engagement letters

## run.py contract

- Reads JSON from stdin: `{"query": "...", "parameters": {}, "upstream": {}}`
- Calls the document chatbot API endpoint
- Writes JSON to stdout: `{"answer": "...", "sources": [...]}`
