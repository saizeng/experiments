<a id='c285881c-3b6b-44d6-8ac3-c4d87418f75e'></a>

<::logo: SlicedInvoices
SlicedInvoices
A pie chart symbol in dark blue and light blue, with the text "SlicedInvoices" next to it in a flowing script font, transitioning from light blue to dark blue.::>

<a id='d335d661-59b2-482b-9479-9d62ce1e07aa'></a>

Invoice

<a id='5d208622-2b53-4415-b188-73e5433113bc'></a>

From:
DEMO - Sliced Invoices
Suite 5A-1204
123 Somewhere Street
Your City AZ 12345
admin@slicedinvoices.com

<a id='ccbd39b6-79e1-4e79-a8c8-44772f91450b'></a>

<table id="0-1">
<tr><td id="0-2">Invoice Number</td><td id="0-3">INV-3337</td></tr>
<tr><td id="0-4">Order Number</td><td id="0-5">12345</td></tr>
<tr><td id="0-6">Invoice Date</td><td id="0-7">January 25, 2016</td></tr>
<tr><td id="0-8">Due Date</td><td id="0-9">January 31, 2016</td></tr>
<tr><td id="0-a">Total Due</td><td id="0-b">$93.50</td></tr>
</table>

<a id='4ef6f6a9-8579-4588-ab8b-de4203fc6370'></a>

To:
Test Business
123 Somewhere St
Melbourne, VIC 3000
test@test.com

<a id='da768df2-49dc-4b2b-80ab-6343dd3bd751'></a>

<table id="0-c">
<tr><td id="0-d">Hrs/Qty</td><td id="0-e">Service</td><td id="0-f">Rate/Price</td><td id="0-g">Adjust</td><td id="0-h">Sub Total</td></tr>
<tr><td id="0-i">1.00</td><td id="0-j">Web Design This is a sample description...</td><td id="0-k">$85.00</td><td id="0-l">0.00%</td><td id="0-m">$85.00</td></tr>
</table>

<a id='c24fcebd-b7fd-4c2b-a554-ae229da84856'></a>

<table id="0-n">
<tr><td id="0-o">Sub Total</td><td id="0-p">$85.00</td></tr>
<tr><td id="0-q">Tax</td><td id="0-r">$8.50</td></tr>
<tr><td id="0-s">Total</td><td id="0-t">$93.50</td></tr>
</table>

<a id='e703522a-044c-4136-81ab-bc243daa69ee'></a>

ANZ Bank
ACC # 1234 1234
BSB # 4321 432

<a id='0932ffb8-6381-4b6d-8d4b-9106d806f32a'></a>

Payment is due within 30 days from date of invoice. Late payment is subject to fees of 5% per month.
Thanks for choosing DEMO - Sliced Invoices I admin@slicedinvoices.com
Page 1/1