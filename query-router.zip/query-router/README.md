# Query Router & Planner

An intelligent query routing system that classifies user questions, plans execution
across multiple data sources and skills, and orchestrates results.

## Architecture

```
User Query
    │
    ▼
┌──────────────┐
│   Planner    │  LLM-based: decomposes query, classifies sub-questions,
│  (LLM call)  │  decides routing + execution order
└──────┬───────┘
       │  Execution Plan (JSON)
       ▼
┌──────────────┐
│  Executor    │  Runs plan steps: parallel when independent,
│              │  sequential when dependent
└──┬───┬───┬───┘
   │   │   │
   ▼   ▼   ▼
┌────┐┌────┐┌────────┐
│ S  ││ U  ││ Skills │   S = Structured API (deals, revenue, clients)
│ D  ││ D  ││        │   U = Unstructured API (documents, filings)
│ S  ││ S  ││        │   Skills = registered scripts with SKILL.md
└────┘└────┘└────────┘
       │
       ▼
┌──────────────┐
│ Synthesizer  │  Merges results from all steps into a coherent answer
└──────────────┘
```

## Data Sources

| Source         | Type         | Handles                                          |
|----------------|-------------|--------------------------------------------------|
| `structured`   | API chatbot | Deals, clients, interactions, revenue, expenses   |
| `unstructured` | API chatbot | IPO docs, M&A filings, BizDev docs, Debt docs    |
| `skill:<name>` | Local script| Registered skills with SKILL.md manifests         |

## Project Structure

```
query-router/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI entry point
│   ├── config.py             # Settings & env vars
│   ├── models.py             # Pydantic models for plans, results
│   ├── planner.py            # LLM-based query planner
│   ├── executor.py           # Orchestrates plan execution
│   ├── synthesizer.py        # Merges multi-source results
│   ├── skill_registry.py     # Discovers & loads SKILL.md files
│   └── clients/
│       ├── __init__.py
│       ├── structured.py     # Client for structured data API
│       └── unstructured.py   # Client for unstructured data API
├── skills/                   # Drop SKILL.md + scripts here
│   └── example_skill/
│       └── SKILL.md
├── tests/
│   └── test_planner.py
├── pyproject.toml
├── .env.example
└── README.md
```

## Quick Start

```bash
# 1. Install
pip install -e ".[dev]"

# 2. Configure
cp .env.example .env
# Edit .env with your API keys and endpoints

# 3. Run
uvicorn app.main:app --reload

# 4. Query
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What was Acme Corp revenue last quarter and what does their merger agreement say about earnouts?"}'
```

## Adding Skills

1. Create a folder under `skills/`
2. Add a `SKILL.md` with frontmatter:

```markdown
---
name: generate_report
description: Generates a formatted PDF report from deal data
trigger: when user asks for a report, summary document, or formatted output
parameters:
  - name: deal_id
    type: string
    required: true
    description: The deal identifier
  - name: format
    type: string
    required: false
    default: pdf
    description: Output format (pdf, docx)
---

# Generate Report Skill

This skill takes deal data and produces a formatted report...
```

3. Add your script(s) in the same folder
4. The registry auto-discovers on startup
