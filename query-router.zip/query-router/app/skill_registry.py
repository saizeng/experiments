"""Discovers and loads skill manifests from SKILL.md files."""

from __future__ import annotations

import logging
from pathlib import Path

import yaml

from app.models import SkillManifest, SkillParameter

logger = logging.getLogger(__name__)

_FRONTMATTER_DELIMITER = "---"


def _parse_skill_md(path: Path) -> SkillManifest | None:
    """Parse a SKILL.md file into a SkillManifest.

    Expected format:
        ---
        name: my_skill
        description: Does something useful
        trigger: when user asks for X
        parameters:
          - name: deal_id
            type: string
            required: true
            description: The deal identifier
        ---

        # Skill Title
        Body markdown describing the skill...
    """
    try:
        text = path.read_text(encoding="utf-8")
    except Exception as exc:
        logger.warning("Could not read %s: %s", path, exc)
        return None

    # Split on frontmatter delimiters
    parts = text.split(_FRONTMATTER_DELIMITER, maxsplit=2)
    if len(parts) < 3:
        logger.warning("No YAML frontmatter found in %s", path)
        return None

    frontmatter_raw = parts[1].strip()
    body = parts[2].strip()

    try:
        meta = yaml.safe_load(frontmatter_raw)
    except yaml.YAMLError as exc:
        logger.warning("Invalid YAML in %s: %s", path, exc)
        return None

    if not isinstance(meta, dict) or "name" not in meta or "description" not in meta:
        logger.warning("SKILL.md at %s missing required 'name' or 'description'", path)
        return None

    params = [
        SkillParameter(**p) for p in meta.get("parameters", []) if isinstance(p, dict)
    ]

    return SkillManifest(
        name=meta["name"],
        description=meta["description"],
        trigger=meta.get("trigger", ""),
        parameters=params,
        folder_path=str(path.parent),
        skill_md_raw=body,
    )


class SkillRegistry:
    """Discovers SKILL.md files in a directory tree and provides lookup."""

    def __init__(self) -> None:
        self._skills: dict[str, SkillManifest] = {}

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load_from_directory(self, root: str | Path) -> None:
        """Recursively find all SKILL.md files under *root* and register them."""
        root_path = Path(root)
        if not root_path.is_dir():
            logger.warning("Skills directory does not exist: %s", root_path)
            return

        for skill_path in root_path.rglob("SKILL.md"):
            manifest = _parse_skill_md(skill_path)
            if manifest:
                self._skills[manifest.name] = manifest
                logger.info("Registered skill: %s (%s)", manifest.name, skill_path)

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    def get(self, name: str) -> SkillManifest | None:
        return self._skills.get(name)

    def list_all(self) -> list[SkillManifest]:
        return list(self._skills.values())

    def summary_for_planner(self) -> str:
        """Return a compact text block listing all skills for the planner prompt."""
        if not self._skills:
            return "No skills are registered."

        lines: list[str] = []
        for s in self._skills.values():
            param_desc = ", ".join(
                f"{p.name}: {p.type}{'*' if p.required else ''}" for p in s.parameters
            )
            lines.append(
                f"- skill:{s.name} — {s.description}"
                + (f"  Trigger: {s.trigger}" if s.trigger else "")
                + (f"  Params: ({param_desc})" if param_desc else "")
            )
        return "\n".join(lines)


# Module-level singleton
registry = SkillRegistry()
