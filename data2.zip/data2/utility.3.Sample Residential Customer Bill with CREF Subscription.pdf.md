<a id='280ae2d2-5407-465f-af72-c578f8104301'></a>

03 00000000 200008865

<a id='45cdda1f-1254-4d40-bb20-b848bfbb434c'></a>

<::logo: pepco
pepco
The logo features a black square with a white diagonal slash, accompanied by the word "pepco" in a lowercase, sans-serif font.::>

<a id='9ca47bcc-5680-4fb3-af46-11016af95e84'></a>

Your electric bill - May 2015
for the period April 4, 2015 to May 5, 2015

<a id='4cc6df2f-1d15-43a7-9849-5c548afe40f8'></a>

<::scan_code: Data Matrix

This is a small, clear Data Matrix code, well-defined against a white background, with no visible damage or obstruction.::>

<a id='1b8578b3-0b29-4aa7-99c3-ca22f072d455'></a>

<::Four black and white photographs are presented in a row. The first image shows a smiling woman wearing a hard hat. The second image depicts a hand holding a compact fluorescent light (CFL) bulb. The third image features a woman and a young child, both smiling, looking at a book together. The fourth image shows a smiling man, dressed in a chef's coat, holding a basket filled with loaves of bread.: figure::>

<a id='83112835-37cf-42fa-a8fd-d40a9f6d7b99'></a>

PEPCO CUSTOMER

Account number: 0123 4567 890

Your service address: 123 9TH ST NW
WASHINGTON DC 20012

Bill Issue date: May 11, 2015

<a id='636f1bf5-639c-4388-b59e-f8755b6730f1'></a>

<table id="0-1">
<tr><td id="0-2">Summary of your charges</td><td id="0-3"></td></tr>
<tr><td id="0-4">Balance from your last bill</td><td id="0-5">$287.32</td></tr>
<tr><td id="0-6">Your payment(s) - thank you</td><td id="0-7">$287.32-</td></tr>
<tr><td id="0-8">Balance forward as of May 11, 2015</td><td id="0-9">$0.00</td></tr>
<tr><td id="0-a">New electric distribution charges - Pepco</td><td id="0-b">$21.01</td></tr>
<tr><td id="0-c">New WGL Energy Svcs supply charges</td><td id="0-d">$155.30</td></tr>
<tr><td id="0-e">Total amount due by Jun 1, 2015</td><td id="0-f">$176.31</td></tr>
</table>

<a id='4850cfe2-8430-40d6-ae0f-75c703c50045'></a>

After Jun 01, 2015, a Late Payment Charge of $2.75 will be added, increasing the amount due to $179.06.

<a id='0de94f7c-2bc2-4aea-83d8-2d2bb4733b96'></a>

Visit pepco.com/dctariffs and click "DC Terms and Conditions" for information on how payments are applied to balances from Pepco and any competitive supplier.

<a id='ebfbd0e5-c10e-4eed-9dc6-037039b894ed'></a>

Your smart electric meter is read wirelessly. Visit My Account at pepco.com to view your daily and hourly energy usage.

<a id='e24f7e67-a2e2-457c-bce1-528bfaa9e408'></a>

If you are moving or discontinuing service, please contact Pepco at least three days in advance.

<a id='b0edeec0-ece6-4309-aa08-8caf136e6606'></a>

Information regarding rate schedules and how to verify the accuracy
of your bill will be mailed upon request.

<a id='3507bd38-b5a9-43da-9dee-5b533fb5120a'></a>

How to contact us

Customer Service (Mon-Fri, 7am - 8 pm)
202-833-7500

Hearing Impaired (TTY)
202-872-2369

¿Problemas con la factura?
202-872-4641

Electric emergencies & outages (24 hours)
1-877-737-2662

Visit pepco.com for service, billing and correspondence information.

<a id='09ba6a37-3730-41af-8baa-f1d12735f429'></a>

Pepco is regulated by - DC Public Service Commission, dcpsc.org
1333 H St NW, Washington DC 20005, 202-626-5100

<a id='6d9bee45-5622-4f3e-9e48-289660025ea7'></a>

Consumer Advocate - Office of People's Counsel, opc-dc.gov
1133 Fifteenth St NW, Washington DC 20005, 202-727-3071

<a id='85628742-f2dd-4ccd-a765-677da9c6cc2a'></a>

Your monthly Electricity use in kWh
Daily temperature averages: May 2014: 68° F May 2015: 61° F
<::Bar chart showing electricity use in kWh per month.
Y-axis (kWh): 0, 640, 1280, 1920, 2560, 3200.
X-axis (Year Month):
- Jun 13/14: 0 kWh
- Jul 13/14: 0 kWh
- Aug 13/14: 0 kWh
- Sep 13/14: 0 kWh
- Oct 13/14: 0 kWh
- Nov 13/14: 0 kWh
- Dec 13/14: 0 kWh
- Jan 14/15: Approximately 2680 kWh
- Feb 14/15: Approximately 2580 kWh
- Mar 14/15: Approximately 3200 kWh
- Apr 14/15: Approximately 2100 kWh
- May 14/15: Approximately 1350 kWh
: chart::>
Follow us on Twitter at twitter.com/PepcoConnect. Like us on
Facebook at facebook.com/PepcoConnect.

<a id='0a3e77af-13bb-4ae7-89bc-edcd3950c89a'></a>

Please tear on the dotted line below. Invoice Number: 200000088589 Page 1 of 3

<a id='45a1c89d-64bf-4258-a98b-f8dc6c53d970'></a>

Return this **coupon** with your payment
made payable to Pepco

<a id='22d60943-f070-4204-a252-d7505165cef3'></a>

Account number: 0123 4567 890

Total amount due by Jun 1, 2015: $176.31

Total amount due after Jun 1, 2015: $179.06

**Auto Pay Plan**

<a id='9d7f82a5-981a-4348-94e3-b3383ef02749'></a>

4429 1 AV 0.378

<a id='760cd8d3-0ef6-43ad-bd7f-32fe54601adf'></a>

2DR04429

<a id='18f98a4d-c57c-4b16-b59f-b8177dc71e6b'></a>

<::scan_code: Barcode
No readable text.
This is a black and white barcode with varying line heights, indicating a possible visual representation of data. The image quality is good with clear lines and no distortions or smudges.::>

<a id='a2a098aa-5310-43e5-8702-37b24a61d6ab'></a>

PEPCO CUSTOMER
123 9TH ST NW
WASHINGTON DC 20012-1604

<a id='84dc8099-b538-47c0-ab7f-543d4d5cc86d'></a>

<::scan_code: Data Matrix

This is a small, clear Data Matrix code with no apparent damage or quality issues.::>

<a id='94850075-e49f-47b5-9da4-1b3dc9abd9a8'></a>

Auto Pay Plan

Amount
Paid: $ [ ] [ ] [ ] . [ ] [ ]

PO BOX 13608
PHILADELPHIA PA 19101

<::scan_code: Barcode
Type: Unknown
Content: [unreadable]
Visual Description: A horizontal barcode consisting of varying width black and white vertical lines, positioned at the bottom of the document.::>

<a id='620a3010-323b-419a-8e34-22191752177d'></a>

700001550213317500000000000000000196560000000196561014

<!-- PAGE BREAK -->

<a id='c9a91166-0bc4-43e2-8bb1-28ba40a70d19'></a>

PEPCO CUSTOMER

Account number: 0123 4567 890

<a id='b3c75bf1-0ab0-4ef0-9164-4faf0d7e74e5'></a>

Your electric bill for the period
**April 4, 2015 to May 5, 2015**

<a id='bc176d89-fe71-4f56-b418-ef1d5df18a08'></a>

Details of your Electric Charges
Residential-R - service number 0012 3456 7890 7001 6762 64
Electricity you used this period
<table id="1-1">
<tr><td id="1-2">Meter Number Energy Type</td><td id="1-3">Current Reading</td><td id="1-4">Previous Reading</td><td id="1-5">Difference</td><td id="1-6">Multiplier</td><td id="1-7">Total Use</td></tr>
<tr><td id="1-8">1ND344415274</td><td id="1-9">May 5</td><td id="1-a">Apr 4</td><td id="1-b"></td><td id="1-c"></td><td id="1-d"></td></tr>
<tr><td id="1-e">Use (kWh)</td><td id="1-f">057043</td><td id="1-g">055628</td><td id="1-h">1415</td><td id="1-i">1</td><td id="1-j">1415</td></tr>
<tr><td id="1-k"></td><td id="1-l">(actual)</td><td id="1-m">(actual)</td><td id="1-n"></td><td id="1-o"></td><td id="1-p"></td></tr>
</table>

<a id='1c3070d9-45eb-4b33-997f-7b3195965ec8'></a>

<table id="1-q">
<tr><td id="1-r" colspan="2">Electric Distribution</td></tr>
<tr><td id="1-s">Summary - Pepco</td><td id="1-t"></td></tr>
<tr><td id="1-u">Balance from your last bill</td><td id="1-v">$60.02</td></tr>
<tr><td id="1-w">Payment Apr 30</td><td id="1-x">$60.02-</td></tr>
<tr><td id="1-y">Total Payments</td><td id="1-z">$60.02-</td></tr>
<tr><td id="1-A">Electric Charges (Residential-R)</td><td id="1-B">$21.01</td></tr>
<tr><td id="1-C">New electric charges</td><td id="1-D">$21.01</td></tr>
<tr><td id="1-E">Total amount due by Jun 1, 2015</td><td id="1-F">$21.01</td></tr>
</table>

<a id='8e9fa48e-4a19-4082-b78f-149828a07794'></a>

Your next meter reading is scheduled for June 3, 2015

**Delivery Charges:** These charges reflect the cost of bringing electricity to you.
Current charges for 32 days, **winter rates in effect.**

<a id='aade3f26-2d4c-433b-9752-2bfc768e5989'></a>

<table id="1-G">
<tr><td id="1-H">Type of charge</td><td id="1-I">How we calculate this charge</td><td id="1-J">Amount($)</td></tr>
<tr><td id="1-K">Distribution Services:</td><td id="1-L"></td><td id="1-M"></td></tr>
<tr><td id="1-N">Customer Charge</td><td id="1-O"></td><td id="1-P">13.00</td></tr>
<tr><td id="1-Q">Energy Charge</td><td id="1-R">First 400 kWh X $0.0038440 per kWh</td><td id="1-S">1.54</td></tr>
<tr><td id="1-T">Energy Charge Residential Aid Discount</td><td id="1-U">Last 1015 kWh X $0.0113740 per kWh</td><td id="1-V">11.55</td></tr>
<tr><td id="1-W">Surcharge</td><td id="1-X">1415 kWh X $0.0002940 per kWh</td><td id="1-Y">0.42</td></tr>
<tr><td id="1-Z">Administrative Credit</td><td id="1-10">1415 kWh X $0.0001855- per kWh</td><td id="1-11">0.26-</td></tr>
<tr><td id="1-12">CNM Credit: CREFA</td><td id="1-13">150- kWh X $0.0809700 per kWh</td><td id="1-14">12.15-</td></tr>
<tr><td id="1-15">CNM Credit: CREFB</td><td id="1-16">100- kWh X $0.0809700 per kWh</td><td id="1-17">8.10-</td></tr>
<tr><td id="1-18">Subtotal (Set by DC PSC)</td><td id="1-19"></td><td id="1-1a">6.00</td></tr>
<tr><td id="1-1b">Energy Assistance Trust Fund</td><td id="1-1c">1415 kWh X $0.0000607 per kWh</td><td id="1-1d">0.09</td></tr>
<tr><td id="1-1e">Sustain Energy Trust Fund Public Space Occupancy</td><td id="1-1f">1415 kWh X $0.0015000 per kWh</td><td id="1-1g">2.12</td></tr>
<tr><td id="1-1h">Surcharge</td><td id="1-1i">1415 kWh X $0.0020400 per kWh</td><td id="1-1j">2.89</td></tr>
<tr><td id="1-1k">Delivery Tax</td><td id="1-1l">1415 kWh X $0.0070000 per kWh</td><td id="1-1m">9.91</td></tr>
<tr><td id="1-1n" colspan="2">Subtotal (Not set by DC PSC)</td><td id="1-1o">15.01</td></tr>
<tr><td id="1-1p" colspan="2">Total Electric Delivery Charges</td><td id="1-1q">21.01</td></tr>
</table>

<a id='5588959d-563b-485a-85f6-d022bcbe401f'></a>

Page 2 of 3

<a id='4c9d412c-fb8e-43fa-bb21-fe30c5771631'></a>

option Check here to enroll in the Direct Debit plan: [ ]
Sign and date here

<a id='0e5fd682-db8b-424d-b876-47270c3d00ab'></a>

By signing here, you authorize Pepco to electronically deduct the amount of your monthly bill from your checking account each month. The check you send with this signed authorization will be used to set up Direct Debit. You understand that we will notify you each month of the date and amount of the debit, which will be on or after the due date stated on your monthly bill. You understand that to withdraw this authorization you must call Pepco. You understand that Pepco does not charge for this service, but that your bank may have charges for this service.

<a id='42034935-08a0-4633-9ddb-b131c0773ba1'></a>

## Customer Service Centers

Washington DC
701 Ninth St NW (Mon - Fri) 8:30am - 5:15pm
2300 Martin Luther King Jr Ave SE (Mon - Fri) 9:00am - 5:00pm

Maryland
201 West Gude Dr, Rockville (Mon - Fri) 10:00am - 2:00pm
8300 Old Marlboro Pk, Forestville (Mon, Wed, Fri) 10:00am - 2:00pm

<a id='d29e8d92-06cd-443e-92f3-4eb95dd455dc'></a>

Any inquiry or complaint about this bill should be made prior to the due date, in order to avoid late charges.

<a id='a0621f01-5f0c-4d94-82f7-ed54fbd4fddf'></a>

Electronic Check Conversion - When you provide a check as payment, you authorize us either to use information from your check to make a one-time electronic fund transfer from your account or to process the payment as a check transaction.

<a id='6f529bbb-3f22-402f-b88f-c3767e4776c7'></a>

Printed on recyclable paper.

<!-- PAGE BREAK -->

<a id='1ef198d3-15fc-4abe-975b-c62f26574a8c'></a>

03 00000000 200008866

<a id='c6e30c83-46fe-43d4-99ee-a777b2f9a64a'></a>

Your electric bill for the period
**April 4, 2015 to May 5, 2015**

<a id='0464ceb1-2627-4a6b-be8c-aa86b28b570b'></a>

PEPCO CUSTOMER
Account number: 0123 4567 890

<a id='bf77e3ef-27a9-44b8-bc07-ca8f5a9bb583'></a>

<::scan_code: Data Matrix

Small, square, black-and-white, pixelated image on a white background, appearing to be in good condition.::>

<a id='c3ed159b-bfb6-4bae-9bcf-352466986224'></a>

**Supply Charges:** These charges reflect the cost of producing electricity for you. You can compare this part of your bill to offers from competitive suppliers. Your electricity is supplied by WGL Energy Svcs - call 1-888-236-9437. Based on your average rate class use, the annual price to compare is 8.23 cents per kwh.

<a id='796daa01-2a9d-4acf-ba45-942d37932b36'></a>

Total Electric Charges - Residential-R

<a id='5e348b60-9b22-4a98-a79f-2a965ce3391f'></a>

21.01

<a id='271426e0-37cc-48f2-bf8b-964a6b44d196'></a>

<table id="2-1">
<tr><td id="2-2" colspan="14">Energy Usage History</td></tr>
<tr><td id="2-3"></td><td id="2-4">May 14</td><td id="2-5">Jun 14</td><td id="2-6">Jul 14</td><td id="2-7">Aug 14</td><td id="2-8">Sep 14</td><td id="2-9">Oct 14</td><td id="2-a">Nov 14</td><td id="2-b">Dec 14</td><td id="2-c">Jan 15</td><td id="2-d">Feb 15</td><td id="2-e">Mar 15</td><td id="2-f">Apr 15</td><td id="2-g">May 15</td></tr>
<tr><td id="2-h">Temp</td><td id="2-i">42°</td><td id="2-j">42°</td><td id="2-k">42°</td><td id="2-l">42°</td><td id="2-m">42°</td><td id="2-n">42°</td><td id="2-o">42°</td><td id="2-p">42°</td><td id="2-q">42°</td><td id="2-r">35°</td><td id="2-s">30°</td><td id="2-t">47°</td><td id="2-u">61°</td></tr>
<tr><td id="2-v">Days</td><td id="2-w">31</td><td id="2-x">30</td><td id="2-y">31</td><td id="2-z">31</td><td id="2-A">30</td><td id="2-B">31</td><td id="2-C">30</td><td id="2-D">31</td><td id="2-E">38</td><td id="2-F">28</td><td id="2-G">28</td><td id="2-H">30</td><td id="2-I">32</td></tr>
<tr><td id="2-J">kWh</td><td id="2-K">0</td><td id="2-L">0</td><td id="2-M">0</td><td id="2-N">0</td><td id="2-O">0</td><td id="2-P">0</td><td id="2-Q">0</td><td id="2-R">0</td><td id="2-S">2679</td><td id="2-T">2572</td><td id="2-U">3159</td><td id="2-V">2071</td><td id="2-W">1415</td></tr>
</table>

<a id='68564db7-6eed-4358-92f7-79167750b512'></a>

Your daily electricity use for this bill period. Visit My Account at pepco.com to see your hourly electricity use. Meter Number 1ND344415274<::bar chart: Your daily electricity use. Temp: 59 55 63 66 50 47 54 62 59 65 61 60 63 68 71 64 69 64 59 53 51 49 55 55 60 65 64 59 63 69 71 73. Y-axis (kWh) values: 0, 20, 40, 60, 80, 100. X-axis (Date) values and corresponding kWh usage: 04: ~49 kWh, 05: ~48 kWh, 06: ~46 kWh, 07: ~45 kWh, 08: ~46 kWh, 09: ~50 kWh, 10: ~55 kWh, 11: ~46 kWh, 12: ~41 kWh, 13: ~49 kWh, 14: ~41 kWh, 15: ~45 kWh, 16: ~43 kWh, 17: ~45 kWh, 18: ~42 kWh, 19: ~41 kWh, 20: ~45 kWh, 21: ~59 kWh, 22: ~46 kWh, 23: ~40 kWh, 24: ~37 kWh, 25: ~40 kWh, 26: ~38 kWh, 27: ~37 kWh, 28: ~40 kWh, 29: ~43 kWh, 30: ~45 kWh, 01: ~48 kWh, 02: ~52 kWh, 03: ~55 kWh, 04: ~59 kWh, 05: ~55 kWh.:>

<a id='0c99dcf3-802f-45f7-937c-9039e6dc64f6'></a>

**WGL Energy Svcs electric supply charges**

Service number: 0012 3456 7890 7001 6762 64

Your electricity is supplied by WGL Energy Services. If you have any questions about your electric supply charges, call WGL Energy Services at 1-888-236-9437.

Billing period: Apr 4, 2015 to May 5, 2015 (32 days)
Type of service: Residential-R
Electricity Used: 1415 kWh
Total Use: 1415 kwh at $0.086 per kwh $121.69
Wind add-on of 95.0% $33.61

**Amount($)**
**WGL Energy Svcs electric charges** 155.30

<a id='867e03d3-ba90-4c2c-960a-f7ba2809ade4'></a>

<table id="2-X">
<tr><td id="2-Y">WGL Energy Svcs</td><td id="2-Z">Electric</td></tr>
<tr><td id="2-10">Supply Summary Balance from your</td><td id="2-11"></td></tr>
<tr><td id="2-12">last bill</td><td id="2-13">$227.30</td></tr>
<tr><td id="2-14">Payment Apr 30</td><td id="2-15">$227.30-</td></tr>
<tr><td id="2-16">Total Payments</td><td id="2-17">$227.30-</td></tr>
<tr><td id="2-18">Total Current</td><td id="2-19"></td></tr>
<tr><td id="2-1a">Charges</td><td id="2-1b">$155.30</td></tr>
<tr><td id="2-1c">New WGL Energy</td><td id="2-1d"></td></tr>
<tr><td id="2-1e">Svcs electric supply charges</td><td id="2-1f">$155.30</td></tr>
<tr><td id="2-1g">Total amount due by Jun 1, 2015</td><td id="2-1h">$155.30</td></tr>
</table>

<a id='71fbbfc6-5ad0-457a-b62f-09cd04c55877'></a>

**WGL Energy Svcs electric charges** 155.30
Congratulations! You've chosen clean, local 100% WGES CleanSteps(R) WindPower.

<a id='614572b3-c22e-4e76-8a15-54cda5d743f0'></a>

Page 3 of 3