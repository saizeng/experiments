"""
Routing logic for the company intelligence skill.
"""

from typing import List


FINANCIAL_KEYWORDS: List[str] = [
    "revenue",
    "ebitda",
    "earnings",
    "market cap",
    "market capitalization",
    "valuation",
    "ownership",
    "investors",
    "shareholders",
    "comparables",
    "comparable companies",
    "m&a",
    "acquisition",
    "industry classification",
    "fundamentals",
]

WEB_KEYWORDS: List[str] = [
    "news",
    "latest",
    "recent",
    "announcement",
    "announcements",
    "product",
    "products",
    "partnership",
    "partnerships",
    "executive",
    "management change",
    "company overview",
    "what does",
]

INTERNAL_KEYWORDS: List[str] = [
    "internal",
    "proprietary",
    "crm",
    "coverage note",
    "deal record",
    "internal research",
    "internal profile",
    "internal company note",
]


def choose_source(query: str) -> str:
    """
    Choose the best retrieval source for the given query.
    """
    normalized = query.strip().lower()

    if _contains_any(normalized, INTERNAL_KEYWORDS):
        return "internal_api"

    if _contains_any(normalized, FINANCIAL_KEYWORDS):
        return "capitaliq"

    if _contains_any(normalized, WEB_KEYWORDS):
        return "web_search"

    return "web_search"


def _contains_any(text: str, keywords: List[str]) -> bool:
    return any(keyword in text for keyword in keywords)
