<a id='1b70f9b7-f13a-41c6-8cfd-f750d4a66123'></a>

<::logo: [Unknown Brand]
RR-1
The logo features bold, black sans-serif text "RR-1" on a white background.::>

<a id='0c8bf13f-cfce-4d92-a386-15df7c018beb'></a>

<::logo: City of Vancouver
CITY OF
VANCOUVER
A stylized black lotus flower symbol is placed to the left of the text.::>

<a id='a8dc55d8-d35a-4e46-b1fa-195e1d202fbf'></a>

ADMINISTRATIVE REPORT

<a id='058754e4-e918-4f96-bd4a-1978654bd64c'></a>

Report Date: October 24, 2017
Contact: Anne Nickerson
Contact No.: 604.873.7776
RTS No.: 11780
VanRIMS No.: 08-2000-20
Meeting Date: January 16, 2018

<a id='40eae982-e70e-4722-a0ba-10a7a68e2bef'></a>

TO: Vancouver City Council

FROM: Chief Human Resources Officer

SUBJECT: Gender Equality Update

<a id='ac21ecc3-5d77-4b53-9eb8-43d6f83facfd'></a>

_**RECOMMENDATION**_
A. THAT Council receive the review of the City's 2005 Gender Equality Strategy (attached as Appendix A).
B. THAT Council approve the updated strategy entitled, "Vancouver: A City for All Women, Women's Equity Strategy 2018-2028" with a focus on Phase 1 Actions (attached as Appendix B).
C. THAT Council direct staff to provide a progress report in 2019 and outline next phase actions, in consultation with the Women's Advisory Committee.
D. THAT Council refer the report to the Vancouver Public Library Board and the Vancouver Police Department Board for information and to request their support of the updated strategy.

<a id='38c468fc-e68b-47c4-9e80-28608d70291d'></a>

**REPORT SUMMARY**

This report provides both a review and update of the City's 2005 Gender Equality Strategy (GES), in response to Council's April 2016 motion "Because It's 2016: Action on Gender Equality". The motion included direction to staff to work with the Women's Advisory Committee to review the 2005 Gender Equality Strategy and update it, with consideration of successful approaches and national/ provincial context, and integration of more recently adopted policy, such as that in Healthy City.

<a id='a0d6881f-e699-4c67-9303-44879e6896b8'></a>

The 2005 GES provided a comprehensive snapshot of women's lives in Vancouver, followed by the City's vision, principles, aims and actions assigned to lead departments. In conducting the review, staff consulted with each lead department identified in the strategy and compiled updates. Of the total 28 actions, the majority or over 80% were completed, ongoing and/or integrated into existing work (see Appendix A). Accomplishments from the 2005 strategy are

<!-- PAGE BREAK -->

<a id='8a976c2c-9219-4fbb-abeb-514749a23800'></a>

Gender Equality Update - 11780

<a id='071f55ae-bfb0-4cf1-b72b-d79bb2ec25bd'></a>

2

<a id='15906901-8e76-4def-a9ac-3b1dc8ad6732'></a>

many, including the establishment of the Women's Advisory Committee and annual International Women's Day events hosted by the City which highlight the contributions of diverse women in our community.

<a id='12662365-9f9d-4db7-9dfa-b4eee16e8435'></a>

In conducting the update to the 2005 GES, staff conducted best practice research and broad consultations with the Women's Advisory Committee, the public, staff, subject matter experts and other key stakeholders, including community organizations. Five prominent themes were identified, initially by the Women's Advisory Committee and then confirmed through input from the public. These include: Safety, Childcare, Housing, Leadership/ Representation (within the City of Vancouver as an employer) and Intersectional Lens, a foundational approach to strengthen City processes and inform decision-making to better mitigate the impacts of interacting social contexts such as gender, race, class and ability. In addition to best practice research and consultations with a variety of stakeholders, staff also conducted meetings internally with departmental teams whose work directly relates to these five themes in order to gain further input and ensure alignment with related work priorities. The primary orientation with the City's vision of a Healthy City for All allows for best practice alignment within the framework of City's Healthy City Strategy, building on the World Health Organization's emphasis on international health promotion through a 'social determinants of health' framework.

<a id='ddab73fd-d354-4b15-a36f-c63febb52bc0'></a>

Based on all of the input received, and given the City's mandate, staff are recommending a number of Phase 1 Actions (2018-2019) related to the above five priority themes for implementation by an Action Team within the first two years of a ten year strategy. Priority goals and objectives parallel the City's Healthy City Strategy 'determinants of health' approach and include indicators and targets that have been designed to address inequalities at a municipal level. The Healthy City Strategy is guided by a vision of A Healthy City for All, ensuring we collectively pursue a strong and inclusive focus on inequity, including gender inequity. These principles also emphasize the importance of including meaningful involvement in the broader public, private and civic sectors.

<a id='436432a0-b7c0-44ba-8ed4-10c1d566e493'></a>

We will measure our progress and report out regularly. It is recommended that staff provide Council with a progress report on Phase 1 Actions in 2019 and outline next phase actions, in consultation with the Women's Advisory Committee and with consideration of current context, related work priorities and existing opportunities. This approach takes into account the evolving landscape, allowing the City to be responsive to emerging opportunities and changing priorities both internally and externally. Each priority theme includes an overarching goal and specific objective, and incorporates at least one of four strategies: education and awareness, partnerships and collaboration, policy and/or data. Each theme is outlined below by goal, objective, strategies and recommended Phase 1 Actions by Department Lead (Table 1).

<a id='ccfd0d69-01ae-44fd-91ad-11c9e813454a'></a>

TABLE 1

<a id='4eff4646-334b-4c69-9062-bda8049018b6'></a>

Phase 1 Actions
SAFETY
<table id="1-1">
<tr><td id="1-2">GOAL</td><td id="1-3">Vancouver is a safe city in which all women are secure and free from crime and violence, including sexual assault.</td></tr>
<tr><td id="1-4">OBJECTIVE</td><td id="1-5">By 2025, women&#x27;s sense of safety will be increased by 10%.</td></tr>
<tr><td id="1-6">STRATEGIES</td><td id="1-7">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="1-8">PHASE 1</td><td id="1-9">1. Join UN Women&#x27;s Global Flagship Initiative “Safe Cities and</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='4f41a2ac-b292-433d-8427-9c5c2c973bce'></a>

Gender Equality Update - 11780

<a id='c36cd6ae-bfef-42d8-90b3-ef8917a22a89'></a>

3

<a id='0945cb27-e703-4476-a753-2f1c5daf4e74'></a>

<table id="2-1">
<tr><td id="2-2">ACTIONS (2018-2019)</td><td id="2-3">Safe Public Spaces&quot; and conduct a scoping study on women&#x27;s safety. (Lead: Community Services) 2. Identify community partners to collaborate on an annual public campaign to raise awareness on violence against women. (Lead: Communications, Human Resources) 3. Update WAC annually on progress in ensuring women&#x27;s safety/ needs in the neighbourhood planning &amp; development process. (Lead: Engineering, Planning, Urban Design &amp; Sustainability) 4. Formalize senior staff coordination and oversight of inter- departmental response to critical issues in the Downtown Eastside, including women&#x27;s safety and related issues. (Lead: City Manager&#x27;s Office)</td></tr>
</table>

<a id='0b73679d-cd44-4855-970f-e925b95940ac'></a>

CHILDCARE
<table id="2-4">
<tr><td id="2-5">GOAL</td><td id="2-6">Women&#x27;s full participation in the workforce and engagement in public life is supported by affordable and accessible quality childcare for children.</td></tr>
<tr><td id="2-7">OBJECTIVE</td><td id="2-8">By the end of 2018, 1,000 new childcare spaces will be added from the 2015 baseline. (Aligns with current childcare target identified in the Healthy City Action Plan, 2015-2018)</td></tr>
<tr><td id="2-9">STRATEGIES</td><td id="2-a">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy</td></tr>
<tr><td id="2-b">PHASE 1 ACTIONS (2018-2019)</td><td id="2-c">1. Share input from the strategy consultations for consideration in the City&#x27;s updated childcare strategy. (Lead: Human Resources) 2. Partner with senior levels of government to significantly increase affordable, quality childcare through creating new childcare spaces, and replacing aging centres. (Lead: Community Services) 3. Identify child-friendly provisions to accommodate participation by families with children at Council and Public Hearings at City Hall. (Lead: City Clerk&#x27;s)</td></tr>
</table>

<a id='1a683a88-3d30-4391-ae4c-b2eb8a5932bf'></a>

HOUSING
<table id="2-d">
<tr><td id="2-e">GOAL</td><td id="2-f">A range of affordable housing choices is available for women of diverse backgrounds and circumstances, including single parents, seniors, newcomers, and those facing vulnerable conditions.</td></tr>
<tr><td id="2-g">OBJECTIVE</td><td id="2-h">72,000 new homes for renters, families and vulnerable residents over the next ten years. (Aligns with current Housing Vancouver Strategy targets)</td></tr>
<tr><td id="2-i">STRATEGIES</td><td id="2-j">Education &amp; Awareness, Data, Partnerships &amp; Collaboration</td></tr>
<tr><td id="2-k">PHASE 1 ACTIONS (2018-2019)</td><td id="2-l">1. Identify how to determine extent of women&#x27;s hidden homelessness to better understand its full scope. (Lead: Community Services) 2. Research integration of outreach role within Coordinated Access Centre to liaise with women-serving organizations and identify women in need of priority housing. (Lead: Community Services) 3. Share input from the strategy consultations for consideration in the implementation of the Housing Vancouver Strategy. (Lead: Human Resources)</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='071f40d7-5456-4a7b-be6b-82367564b799'></a>

Gender Equality Update - 11780

<a id='ae029044-943e-442f-b409-7b54557a6402'></a>

4

<a id='8329ae24-d520-4522-9b75-e69a1f2a7a05'></a>

LEADERSHIP & REPRESENTATION
<table id="3-1">
<tr><td id="3-2">GOAL</td><td id="3-3">The City will elevate the visibility, influence, representation and contribution of all women in the organization by providing equitable access to work opportunities, including leadership roles and other historically under-represented occupations and by creating and implementing initiatives to specifically enhance their development and leadership.</td></tr>
<tr><td id="3-4">OBJECTIVE</td><td id="3-5">Increase new hire ratios: • The City will increase new hires for Senior Management roles to 50 per cent women. • By 2020, the proportion of female new hires in under-represented occupations* will be increased by at least 5% over the 2017 baseline.</td></tr>
<tr><td id="3-6">STRATEGIES</td><td id="3-7">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="3-8">PHASE 1 ACTIONS (2018-2019)</td><td id="3-9">1. Sign Minerva BC&#x27;s Face of Leadership™ Diversity Pledge, making a public commitment to support women&#x27;s advancement in leadership in our workforce and in our community. (Lead: Human Resources) 2. Develop and implement a Breastfeeding Policy for City staff. (Lead: Human Resources) 3. Conduct focus groups with female staff in leadership and under-represented positions.(Lead: Human Resources) 4. Measure and report annually on the City&#x27;s workforce composition including positions and compensation. (Lead: Human Resources) 5. Address potential bias in the hiring process by training recruitment staff to recognize and mitigate unconscious bias. (Lead: Human Resources)</td></tr>
</table>
* Examples of under-represented occupations include Information Technology (technical
positions), Firefighting, Trades & Operations, Engineers and Engineers-in-Training.

<a id='2d6777ba-8585-4001-a01b-cd753c14f844'></a>

INTERSECTIONAL LENS
<table id="3-a">
<tr><td id="3-b">GOAL</td><td id="3-c">The City&#x27;s decisions, programs and plans are informed by an intersectional lens to ensure that all citizens have equitable access, inclusion and participation in community life.</td></tr>
<tr><td id="3-d">OBJECTIVE</td><td id="3-e">In 2018, an intersectional framework will be established for City departments.</td></tr>
<tr><td id="3-f">STRATEGIES</td><td id="3-g">Education &amp; Awareness, Policy</td></tr>
<tr><td id="3-h">PHASE 1 ACTIONS (2018-2019)</td><td id="3-i">1. Pilot intersectional framework. (Lead: Community Services) 2. Introduce the application of an intersectional lens to senior staff through training in Gender-Based Analysis Plus (GBA+), offered through Status of Women Canada. (Lead: Human Resources) 3. Bring forward to Council revised Civic Assets Naming Guidelines that include gender diversity. (Lead: City Clerk&#x27;s)</td></tr>
</table>

<a id='652444de-6d36-4137-b4c8-cdf5f1bf99d6'></a>

While the 2005 strategy is named "Gender Equality", staff are recommending changing the strategy name to "Women's Equity". The reasons for this are twofold: 1) 'gender' is a

<!-- PAGE BREAK -->

<a id='9b0b01a1-449b-4336-b3f0-5d2a5cb1606d'></a>

Gender Equality Update - 11780

<a id='407f9e9d-43af-4151-b742-08c9c63bbfa9'></a>

5

<a id='a592aba8-2a0a-4361-8ee3-9c37efa12ea8'></a>

spectrum which includes more than women and the strategy's sole focus is on women and those who identify as women, and 2) 'equality' promotes fairness by treating everyone the same, assuming that everyone starts from the same place and needs the same help, whereas 'equity' promotes fairness by taking respective needs and differences into account. Equity aims to give everyone what they need to be successful with equality as the outcome. The recommended update to the 2005 GES is titled Vancouver: A City for All Women, Women's Equity Strategy 2018 - 2028.

<a id='f94aed42-b17d-4ae7-aa25-c9b38c77acbf'></a>

**COUNCIL AUTHORITY/PREVIOUS DECISIONS**

**Empowering Citizen Voices on Citizen Advisory Committees:** In February 2009, Council passed a motion to create a number of citizen advisory committees, including the Women's Advisory Committee.

<a id='b875b70a-3232-4b84-9275-dc3ba0306656'></a>

Health and Safety of Sex Workers: In July 2009, Council passed a motion directing staff to report back on a strategy for the City to address negative impacts of the survival street sex trade on sex workers and Vancouver neighbourhoods.

<a id='c10f1421-7c2b-495e-9082-621e093e6de5'></a>

"Preventing Sexual Exploitation and Protecting Vulnerable Adults and Neighbourhoods Affected by Sex Work: A Comprehensive Approach and Action Plan": In September 2011, Council adopted the report and directed staff to form a city-wide Task Force on Sex Work and Sexual Exploitation to implement the action plan. The Task Force was created in 2011 and worked towards implementing actions from the report.

<a id='ea343826-f957-4933-8e17-ceda234858fb'></a>

Missing Women Commission of Inquiry: In January 2013, Council committed to implementing the recommendations directed to the City in the Inquiry's report, *Forsaken*.

<a id='6eda657a-bb2a-418b-b715-8fc04ae8b8b8'></a>

"**Report back on Missing Women Commission of Inquiry and City Task Force on Sex Work and Sexual Exploitation**": In December 2013, Council adopted the report that included a direction to finalize the City's Sex Work Response Guidelines. These guidelines promote consistent, non-discriminatory, and respectful treatment of anyone engaged in sex work when accessing City services or interacting with City employees.

<a id='ae2c0e39-f682-4be3-8b62-ddd5cc34a10b'></a>

Mayor's Task Force on Mental Health and Addictions: In 2014, the Mayor's Task Force on Mental Health and Addictions committed to developing a Strategic Gender Framework for the inclusion of women, girls and gender variant communities to inform future City efforts.

<a id='54798af0-eb2c-449d-ba58-3c16255a5c6c'></a>

"Caring for All" Phase I Report of the Mayor's Task Force on Mental Health and Addictions:
In September 2014, Council adopted the report and directed staff to work with partners to implement priority actions and develop a gender/ intersectional policy framework to address health and social inequities of women, girls and gender variant communities.

<a id='83e3c27e-5c53-4ea7-97ae-0c1ed7bf5c6f'></a>

Canadian Coalition of Municipalities Against Racism and Discrimination (CCMARD): In 2010,
the City of Vancouver joined CCMARD as a municipal partner in combating racism and
discrimination and fostering equality and respect for all citizens.

<a id='99cf3c6c-0a46-499f-b6d8-b0b69bbea646'></a>

$10-a-Day Plan (Community Plan for a Public System of Integrated Early Care and
Learning): In 2011, City Council passed a motion to support the Plan to create a universal

<!-- PAGE BREAK -->

<a id='ef000918-8b1f-416b-a79e-9e0f6ba4aee7'></a>

Gender Equality Update - 11780

<a id='2696e65b-53da-4ed7-bccb-dc701849b3bd'></a>

6

<a id='868b6223-0f27-4531-a963-d83dff4a9ec9'></a>

public childcare system in British Columbia. The Plan was developed by the Early Childhood Educators of BC and Coalition of Childcare Advocates of BC.

<a id='44061a5a-2533-471d-bc78-a26266cdf0ea'></a>

**Engaged City Taskforce:** In 2012, Council established the Engaged City Taskforce whose final report highlights the engagement of community members in the decisions that affect their lives, including specific strategies for engaging under-represented groups.
**Joint Childcare Council (JCC):** Established in 2012, the JCC is an initiative of the City of Vancouver, the Vancouver Board of Education and the Park Board. The JCC provides leadership in childcare and child development in Vancouver, working to support and deliver accessible, affordable, quality childcare spaces in the city.

<a id='c42dc694-5a2d-4c97-a2c2-cff91383def9'></a>

Healthy City Strategy: In 2014, the City adopted the Healthy City Strategy which sets out as one of its guiding principles a "for all" intersectional lens. This ensures we pursue initiatives that are both universal for all residents and focused on specific populations most vulnerable to inequities, including women. The strategy sets out goals reflecting social determinants of health that enable people to flourish and reach their full potential, as well as targets, including housing, ability to make ends meet, safety & inclusion and a good start for children. The 2015-2018 Healthy City Action Plan includes a number of actions on child care, safety, housing and others.

<a id='aa96dc1e-c34e-4680-a9bc-c1057df209e7'></a>

Framework for City of Reconciliation: In 2014, Council approved the Framework for City of Reconciliation with three foundational components of mutual respect, strengthened partnerships and economic empowerment to guide the work of the City to best serve First Nations and urban Aboriginal communities, with the ultimate goal of broader inclusion of all communities.

<a id='129258a7-bc41-43f8-afe0-96b304c0a99c'></a>

Remarkable Women: From 2008 to 2014, the Remarkable Women poster series honoured local women who made significant contributions to arts, culture, sports, and community.

<a id='b0aa3ab8-e8fb-4b8f-becb-46be48fc74b6'></a>

International Women's Day, March 8: Each year, the City celebrates this day by highlighting issues of importance to local women, and by highlighting the important roles women in our communities play.

<a id='c2b4e9ce-7f6a-499c-96ee-10fbe720b376'></a>

Vancouver Poverty Reduction Plan: The June 2017 Council motion states that "poverty disproportionately affects women, people of colour, Aboriginal people, people dealing with disabilities and those with chronic illnesses - including mental illness..." and directs staff to report back with an update on the Vancouver Poverty Reduction Plan including opportunities for expanded action as a result of new provincial and federal commitments.

<a id='852e2343-d729-4759-be9a-7458536b6528'></a>

**Vancouver Capital Plan:** The Capital Plan for 2015-2018 allocates investment for childcare to support Council-approved targets of adding 500 licensed childcare spaces for children ages 0-4, and 500 for school age child care.

<a id='f8fc9f9e-e5eb-4dd2-a289-9a5215d9cf5d'></a>

Award of Excellence - Diversity and Inclusion: This annual civic award honours outstanding leadership to foster inclusion across diverse communities.

<a id='321a2906-9dea-4806-9f8c-195a1bca4034'></a>

**Official Celebrations and Observances:** Council and staff recognize and value the contributions of Vancouver's diverse communities by observing internationally recognized days and significant events in our history. These include International Women's Day, Black History

<!-- PAGE BREAK -->

<a id='9cd1dd9b-5f72-4ba0-91fc-485ed3aee621'></a>

Gender Equality Update - 11780

<a id='6824c0fe-4a8c-497f-bd35-8e21dddc14bd'></a>

7

<a id='865a4493-6eb7-4d03-9d57-51a4b75ea513'></a>

Month, International Day for the Elimination of Racism, National Aboriginal Day, and International Day of Persons with Disabilities.

<a id='ef593287-1d44-401d-91b4-873a523d8242'></a>

**Access to City Services Without Fear (ACSWF)**: In April 2016, Council passed this policy to enable Vancouver residents with uncertain or no immigration status to access City services without the fear that the City will ask for and provide information on the immigration status of individuals to other public institutions or orders of government, unless required by law.
**Ensuring Trans Equality and an Inclusive Vancouver**: The July 2015 Council motion supported the passage of federal and provincial legislation ensuring Gender Identity and Gender Expression are protected under legislation. The motion also directed staff to consult with the LGBTQ2+ Advisory Committee and Parks related Steering Committee and report back on how the City could make civic facilities, operations and programs safe and inclusion spaces for Trans and Gender Variant communities. After consultations with these and other stakeholders, staff reported back to Council in July 2016 with recommended actions which were unanimously approved. Progress Reports are provided to Council annually.

<a id='a9b45e32-d4d7-464e-ba7a-7a8ac3781992'></a>

Downtown Eastside Women's Centre Association Capital Grant: In October 2017, Council approved a one-time Capital Grant of up to $250,000 towards renovations for the Downtown Eastside Women's Centre Association 24/7 Shelter in partnership with BC Housing.

<a id='58bf8903-695f-439e-8b60-7d2bfd376751'></a>

***CITY MANAGER'S/GENERAL MANAGER'S COMMENTS***
The City Manager and Chief Human Resources Officer recommend approval of the foregoing as it will advance women's equality in our community and municipal workplace, and further strengthen the City of Vancouver's leadership role in the areas of equity, diversity and inclusion.

<a id='248471af-22b5-43ea-a691-e5c6814f42b2'></a>

***REPORT***

***Background/Context***

On April 6, 2016, Council passed the motion "Because it's 2016: Action on Gender Equality" which outlined three directives. This report addresses the directive to staff "to work with the Women's Advisory Committee to establish a process to review the 2005 Gender Equality Strategy and update it, with an eye to successful approaches, integrating more recently adopted policy such as that in Healthy City and the Mental Health and Addictions Task Force, and taking into account a change in national and provincial context."

<a id='45cdd399-1764-4c68-8f92-6fb19299be7b'></a>

The review of the 2005 GES is attached as Appendix A, "Review of the 2005 Gender Equality Strategy for the City of Vancouver" and includes the status of action items. The vast majority of the 2005 actions were implemented and many are ongoing, including the Women's Advisory Committee and annual International Women's Day events. The review also provided key learnings, which have been taken into account in conducting the update to the strategy. These include:
* Appointing a responsible department for oversight and coordination of actions, including regular progress reports
* Aligning strategy and leverage actions, wherever possible, with existing City priorities and initiatives

<!-- PAGE BREAK -->

<a id='e7efeadb-ebcd-443c-a985-f325c0890b48'></a>

Gender Equality Update - 11780

<a id='f3dde156-a0a0-429f-9d05-750624d88e11'></a>

8

<a id='5ee8474d-bb51-46fc-a14d-9483d8603ae8'></a>

• Ensuring actions are within the City's jurisdiction and have specific, measurable, achievable, relevant goals that can be measured over time.

<a id='6b68a925-ed33-4f64-b82b-c41666f3ed0f'></a>

The City of Vancouver has seen a great deal of change and growth since it adopted the 2005 GES. The current economic, housing, and childcare pressures facing the city are being felt more acutely by women. As Council's 2016 motion states, "Women and girls comprise a majority of residents (51 per cent) in Vancouver but on average have lower incomes, less housing security, more unpaid work, experience far greater rates of poverty and gender based violence, and in general have fewer opportunities than men and boys". The following are some of the ways in which women have been disproportionally impacted in recent years:

<a id='5d48f079-cc1c-4547-9e37-dddeb234e96c'></a>

Women continue to be economically disadvantaged
Women make up 51 per cent of Vancouver's population¹ and continue to experience deeper economic and social disadvantages than their male counterparts (see below). A specific focus on improving the lived experiences of women is essential to achieving the City's Healthy City Strategy targets, in particular the goals of Making Ends Meet and Working Well

<a id='cc6c89b1-4466-4b50-9c81-7093e74ed243'></a>

Women in Vancouver continue to earn less employment income than men. In 2015,
women's median after-tax employment income was $29,800/year compared with
men's $36,900/year.2 The Canadian Centre for Policy Alternatives estimates
$37,528/year as a minimum annual living wage for Vancouver.3

<a id='96eb8409-0130-47de-9662-813b4623a3f3'></a>

This earnings gap is due to a number of factors:⁴

- Entrenched patterns of jobs segregated by gender, with jobs traditionally performed by women paying less than jobs traditionally performed by men. In 2015, 56.1 per cent of Canadian women were employed in teaching, nursing and related health occupations, social work, clerical or other administrative positions, or sales and services.⁵
- The majority of unpaid caregiving work is performed by women.⁶ Women reported spending an average of 50 hours per week on child care, more than double the time spent by men.⁷
- Inaccessible and unaffordable childcare. Vancouver has the third worst employment gap between men and women in Canada (11.8 per cent). The employment gap is greater in cities with high childcare costs.⁸
- A predominance of women in part-time and casual work. Across Canada approximately 76 per cent of those working part-time are women. Childcare was

<a id='f31684a0-d30c-4df8-9529-7d9cc02a54f1'></a>

1 Statistics Canada, Census 2016
2 Statistics Canada, Census 2016
3 Canadian Centre for Policy Alternatives, [Working for a Living Wage 2017](Working for a Living Wage 2017)
4 BC CEDAW Group, Women's Rights in British Columbia, Submission to the Committee on the Elimination of Discrimination against Women, 2016
5 Statistics Canada, Women in Canada: A Gender-Based Statistical Analysis, Women and Paid Work, Released: March 8, 2017, Corrected: March 9, 2017.
6 Statistics Canada, Portrait of caregivers, 2012, [http://www.statcan.gc.ca/pub/89-652-x/89-652-x2013001-eng.htm#a9](http://www.statcan.gc.ca/pub/89-652-x/89-652-x2013001-eng.htm#a9)
7 Statistics Canada, Families, Living Arrangements and Unpaid Work, December 2011, Catalogue no 899-503-X
8 Statistics Canada, Women in Canada: A Gender-Based Statistical Analysis, Women and Paid Work, Released: March 8, 2017, Corrected: March 9, 2017.

<!-- PAGE BREAK -->

<a id='79aa98b9-fa58-4d96-b45b-5637c247971d'></a>

Gender Equality Update - 11780

<a id='74b52c1b-36ef-4ffb-a298-90aeacc00e2d'></a>

9

<a id='1a974c90-a833-4f4a-8cf9-c9db6dc8aad8'></a>

cited by 25 per cent of women and 3.3 per cent of men as the reason for working part-time.⁹
* A low minimum wage which provides less than a poverty level income to full-time workers. Among BC's minimum wage workers aged 25-54, 70 per cent are women.¹⁰
* In addition, of those in Vancouver who rely on employment insurance, 60 per cent are women¹¹, and 53 per cent of social assistance recipients are women.¹² 90 per cent of single parents on income and disability assistance are female.¹³

<a id='3eb31bd2-0c1a-4e6a-8fdc-e18d9598180f'></a>

Women's caregiving roles also have an impact on their earnings over their lifetime and impact their availability to work. A 2009 study found women with children earn 12 per cent less than women without children. This gap increases with the number of children, up to 20 per cent for women with three or more children. 14 The earnings can be partly explained by breaks in women's employment for maternity and parental leaves. Approximately 47 per cent of women take at least one maternity or parental leave over their careers, compared to 3.8 per cent of men. The average duration of a woman's combined parental and maternal leave is 1.3 years. 15

<a id='8bd189b6-39c7-41f2-9082-e7e43cddc824'></a>

Women experience life in the City differently than men

The Healthy City Strategy includes the goal of Being and Feeling Safe and Included.
While 65 per cent of residents agree or strongly agree that they "feel safe walking
after dark in the City" 16, this statistic is very different for women than men. Only 57
per cent of women compared to 73 per cent of men reported feeling safe walking
after dark. Senior women (75+ years) and young women (18-24) reported feeling the
least safe, at only 47 per cent and 41 per cent, respectively. Similarly, only 44 per
cent of Aboriginal women and 41 per cent of Chinese women reported feeling safe
walking after dark. 17

<a id='8bfd97ca-8b25-48a5-8342-3b9edd4f7e79'></a>

_Violence against women exacerbates women's economic situation and experience of life in the city_

<a id='1202a47c-80e5-48d8-ab69-d2f7ab29578c'></a>

Women's economic vulnerability places them at greater risk of intimate partner
violence, and violence against women compound the inequalities women already face
in society. 18 Intimate partner violence, including both spousal and dating violence,

<a id='1821cf57-b6af-43e8-83cc-ca1143b6646b'></a>

9. Statistics Canada, Women in Canada: A Gender-Based Statistical Analysis, Women and Paid Work, Released: March 8, 2017, Corrected: March 9, 2017.
10. BC Federation of Labour. BC Minimum Wage and Women: The Facts. http://bcfed.ca/sites/default/files/attachments/BCFED%20minimum%20wage%20fact%20sheet%20-%20women.pdf
11. Statistics Canada. Table 111-0019 - Characteristics of individuals, tax filers and dependents 15 years of age and over receiving employment insurance by age groups and sex, annual (number) (accessed September 28, 2017)
12. Statistics Canada. Table 111-0025 - Characteristics of individuals, economic dependency profile of individuals, annual (accessed: September 28, 2017)
13. Ministry of Social Development and Poverty Reduction, BC Government, https://news.gov.bc.ca/releases/2015SDSI0043-001405
14. Statistics Canada, Earnings of women with and without children, March 2009 Perspectives, Catalogue no. 75-001-X
15. Statistics Canada, Women in Canada: A Gender-based Statistical Report, Women and Paid Work, March 9, 2017, Catalogue no. 89-503-X
16. Vancouver Coast Health, My Health My Community, 2014
17. IBID.
18. BC CEDAW Group, Women's Rights in British Columbia, Submission to the Committee on the Elimination of Discrimination against Women, 2016

<!-- PAGE BREAK -->

<a id='00e8ea74-5ba9-4045-8856-fbcf05cfb705'></a>

Gender Equality Update - 11780

<a id='a38968c8-5178-490b-aa53-0ba47fa45fa5'></a>

10

<a id='10546bcf-8ad0-4973-bda4-1213b8be656d'></a>

accounts for one in every four violent crimes reported to police and 80 per cent of victims were women. ^19

<a id='22fed9f3-8712-4835-8476-8b199f3005d3'></a>

Between 2004 - 2014, violent victimization rates declined for all crimes except sexual assault. Rates of sexual assault have remained stable. 20 Aboriginal women are three times more likely to be sexually assaulted than non-Aboriginal women. 21
Violence against women impacts their economic situation. Women who left abusive domestic partners relied on food banks at nearly 20 times the rate of average Canadians and for up to three years after leaving the abusive situation. Victims of sexual assault, the majority of which are women, report both immediate injuries and long term mental health impacts resulting in lost education, work and income. 22 One study found that 60 per cent of victims of intimate partner violence had either quit their jobs or were terminated as a result of the abuse. 23

<a id='5410cc76-15ad-4116-8c50-6d6613d6f40f'></a>

Women continue to be under-represented in leadership and other occupations within the workforce

Increasing the representation of women in leadership and historically under-represented occupations is widely recognized as a persistent issue both locally and globally. It requires intentional measures on a wide ranging scale from employers, educational institutions, governments, Boards, media and others. As a municipal employer, the City of Vancouver plays a leadership role in committing to actions aimed at increasing the number of women in leadership and under-represented roles, such as firefighting and trades. The following table provides a snapshot of the representation of women as City employees (Table 2).24

<a id='62ffe8f8-b223-42be-954f-c433c1e2076a'></a>

19 Family violence in Canada: A Statistical Profile, 2011, http://www.statcan.gc.ca/pub/85-002-x/2013001/article/11805/11805-3-eng.htm#a1
20 Vancouver Police Department Crime Incident and Crime Rate Statistics, 2011-2016; Statistics Canada, Criminal Victimization in Canada, 2014
21 Statistics Canada, Criminal Victimization in Canada, 2014
22 Canadian Centre for Policy Alternatives, The Gap in the Gender Gap: Violence Against Women in Canada, Kate Mclnturff, July 2013
23 Institute for Women's Policy Research, The Economic Cost of Intimate Partner Violence, Sexual Assault, and Stalking, Fact Sheet, August 2017
24 Chart represents figures at November 14, 2017 and excludes the Vancouver Police Department and Vancouver Public Library.
Senior Management: Includes all positions Pay Band 10 and above. Information Technology (IT) Positions: Include all positions in technical information technology roles across all City departments, excluding Senior Management. Trades and Operations: Includes all trades and operations (e.g., construction, traffic, parks, maintenance) positions, across all City departments. Firefighting Positions: Includes all firefighters, inspectors, captains, investigators, and managers excluding Senior Management Engineers, Technicians and Engineering Assistants: Include all professional and technical engineering positions across all City departments, excluding senior management.

<!-- PAGE BREAK -->

<a id='663bd7b8-bba4-4e53-a124-c9158db9c967'></a>

Gender Equality Update - 11780

<a id='71f5200b-0dfd-4bdb-ba17-497e3af0d68c'></a>

11

<a id='7d4199bc-1b49-4430-a6bd-1003d52fb52a'></a>

TABLE 2
Examples of under-represented positions
<::Bar chart showing the percentage of Female and Male representation in different positions:
- Senior Management: Female 37%, Male 63%
- Trades and Operations: Female 15%, Male 85%
- Firefighting: Female 4%, Male 96%
- Information Technology (IT) Related: Female 34%, Male 66%
- Engineers, Technicians and Engineering Assistants: Female 30%, Male 70%
: bar chart::>

<a id='90b08f8c-81e8-47fa-a92b-90511bf2ec23'></a>

All of this data provides important context for the strategy's update and underscores the need for a renewed commitment by many, including the City. Research into the current state and local to global best practices, including interviews with a number of subject matter experts, provided a strong foundation from which to start gathering stakeholder input on the strategy update.

<a id='624228a7-c6f5-49e1-b859-753bf560179d'></a>

Starting in October 2016, we began those consultations with the Women's Advisory Committee through a member questionnaire and working session. A public survey was launched on March 8, 2017, International Women's Day, with a total of 1,640 responses received by the survey's closing date, April 26, 2017. A public forum was also held during the month of April. Both the survey link and public forum details were sent directly to 84 community agencies and each of the Type 'A' Council Advisory Committees, encouraging them to provide their input. The diagram below provides an overview of all inputs considered in development of the updated strategy (Table 3).

<!-- PAGE BREAK -->

<a id='3a60287d-e728-437f-8d5e-2ac2194b2542'></a>

Gender Equality Update - 11780

<a id='ac9dc19e-7d28-4bba-8761-6a348bdbc5bd'></a>

12

<a id='81835931-c4fe-426c-b846-3b48fa6c5eb2'></a>

TABLE 2

<a id='bb4c95e0-29c7-4078-88cd-ddda9e5040e9'></a>

<::Women's Equity Strategy 2018-2028: flowchart::>Women's Equity Strategy 2018-2028 is the central box of the diagram, connected to six surrounding bubbles representing different consultation and research categories. The connections are as follows:1. Internal Consultations: * Ongoing consultations with internal experts and impacted Departments.2. Public Consultations: * Survey (1,640 responses) * Forum (45 attendees) * Community organizations 84 contacted/invited3. Subject Matter Experts: * 21 contacted * 16 interviewed/consulted4. Advisory Committees: * Council Advisory Committees contacted and invited to participate5. Best Practices Research: * 35+ papers reviewed * Statistical research6. Women's Advisory Committee: * Updated and consulted regularly. * Provided guidance and advice on process and plan.

<a id='0fbcafb8-df50-4747-aa76-98f4f1c0a45a'></a>

The initial five themes identified by the Women's Advisory Committee in the Fall 2016 were confirmed during the public consultation process. These include:
* Safety
* Childcare
* Housing
* Leadership & Representation (within the City of Vancouver as an employer)
* Intersectional Lens

<a id='2bc6dafc-460c-4462-a109-e1223eaa7993'></a>

The Women's Equity Strategy for the City of Vancouver 2018-2028 is attached with actions organized by these five priority themes (Appendix B). The updated strategy links directly with focus areas in the Healthy City Strategy and, as such, the latter provides a natural framework in which to organize actions in the Women's Equity Strategy. In addition to the Healthy City Strategy, there are a number of current and upcoming City initiatives which connect to priority themes in the updated strategy, including the Housing Strategy, Childcare Strategy and Poverty Reduction Strategy. These are all high priorities for each level of government and new partnership opportunities are continuously emerging that could amplify the impact of the City's work in each of these areas. Other emerging opportunities include the Women Deliver 2019 global conference in Vancouver and a three-year research project titled "Action on Systemic Barriers to Women's Participation in Local Government" conducted in partnership between Women Transforming Cities and the Canadian Research Institute for the Advancement of Women (CRIAW).

<a id='466ff676-e2f3-43fd-8c55-7e8ff7430ec2'></a>

TABLE 3

<a id='f5931bf2-8bd0-49e0-a6f8-ab57931c8b69'></a>

**Sources of Input**

<!-- PAGE BREAK -->

<a id='e9a52f8a-97ec-4f33-ad8c-9cc4b4d8bb70'></a>

Gender Equality Update - 11780

<a id='930f41d0-ca38-4f63-be89-6a9d0fb430e5'></a>

13

<a id='f9f7c29c-dd98-4564-a2d0-dd9d8195b8f5'></a>

Given the evolving context, the Strategy identifies specific Phase 1 Actions for completion within the initial two years of the ten year strategy related to each of the five priorities (Table 1). This approach allows flexibility to dovetail with related City initiatives and emerging opportunities to advance the goals of the Women's Equity Strategy. In addition to these actions, each priority outlines an overarching goal, specific objective(s) and strategies for how to get the work done. The first regular progress report to Council is recommended in 2019 along with next phase actions, after consideration of stakeholder input and best practices contained in the strategy, as well as related City priorities and current context.

<a id='eafa6469-77d0-4db1-8e1f-3d1f6900ae48'></a>

*Strategic Analysis*

A comprehensive City Strategy on gender equality was first introduced in 2005. The document provided a snapshot of women's lives in Vancouver, followed by the City's vision, principles, aims and actions assigned to lead departments. The pioneering strategy led to the completion or integration of the majority of actions and demonstrated the City's commitment to improve the lives of women in Vancouver (see Appendix A).

<a id='dc552b06-c430-4e2e-9605-af6b684c1ee1'></a>

Over the past 12 years, the city has seen a great deal of change and growth in both exciting and challenging ways. Unfortunately, many of the same issues that disproportionally impacted women in the past still exist today, including lower incomes, less housing security, more unpaid work, and greater rates of poverty and gender based violence. Council's motion "Because It's 2016: Action on Gender Equality" underscores this reality and renews the City's commitment to improve the lives of women in Vancouver.

<a id='80243bf5-50ef-49b2-b0cd-8856fffd71d3'></a>

As with the 2005 strategy, the Women's Equity Strategy 2018-2028 has been developed within the current local, national and international context, and built upon existing City policies and priorities (see Appendix B). Initial Phase 1 Actions are recommended over the first two years of the 10 year strategy (Table 1). This approach is purposeful, allowing the City flexibility to respond to emerging opportunities, changing priorities and shifting provincial and federal context. Working with the Women's Advisory Committee, the updated strategy is the result of best practice research and consultations with committee members, the public, subject matter experts and staff (Table 3). The strategy aligns with current work, including poverty reduction, housing and childcare, and is supported by the overarching framework of Healthy City (http://vancouver.ca/people-programs/healthy-city-strategy.aspx). The Women's Equity Strategy 2018-2028 continues the innovative work first started in 2005 and strives to make Vancouver: A City for All Women.

**Public/Civic Agency Input**

<a id='3bdbfa8e-2329-461e-9004-74a0ecd8e6d7'></a>

1. Women's Advisory Committee
    a. Regular meetings: Staff from the Human Resources Department met with the Women's Advisory Committee (WAC) on the following dates: October 25, 2016, and January 31, February 28, March 21, May 11, June 20, July 18, August 15, September 26, and November 21, 2017.
    b. Meetings with WAC Chair and Chairs of the WAC Subcommittees: In September 2017, staff held three separate meetings with the Chairs of the WAC sub-committees, including Leadership, Representation and Participation, Economic Equality and Opportunity, Safety and Gender Mainstreaming.

<!-- PAGE BREAK -->

<a id='452ea82e-05ca-43c1-888f-a632624c7195'></a>

Gender Equality Update - 11780

<a id='f68079ab-9122-42c3-88af-e10e5d4489cc'></a>

14

<a id='867cf797-998f-4c3c-9f2a-a298884dade9'></a>

2. Public Input
   a. Online Survey: The online Talk Vancouver survey "Action for Women" was live from March 6 - April 26, 2017, and received 1,640 responses.
   b. Public Forum: Approximately 45 people attended the public forum held on April 19, 2017.
   c. Community organizations: 84 community organizations were specifically invited to respond to the survey and attend the public forum.
   d. Citizen Advisory Committees: All Type 'A' Council Advisory Committees were invited to respond to the online survey, attend the public form and provide input on the update of the 2005 GES.
3. Subject Matter Expert Consultations: 21 organizations were contacted and 16 of these met with staff to provide their expert input.

<a id='5da6bcc4-dc7d-4863-93c3-4378e8179d12'></a>

_Implications/Related Issues/Risk (if applicable)_

_Financial_

There are no financial implications at this time.

<a id='80ad9c76-6947-428f-8854-4ab404ea0b9f'></a>

*Human Resources/Labour Relations*

The City will work with the unions with regards to the implementation of any employment-related actions.

<a id='98c22b98-2b26-4246-b8f8-2aa89df2c10a'></a>

## CONCLUSION
The persistence of women's inequality is an issue that affects all of us, locally, nationally and globally. Addressing this issue requires all social agents - including individuals, organizations and governments - to take proactive measures to eradicate it. Council's direction to review the 2005 Gender Equality Strategy and update it underscores the reality that there is much more to be done to improve the quality of lives for women, and those who identify as women, in Vancouver. As part of the City's collaborative approach, staff will be proactive in sharing the updated strategy with community organizations and other partners such as TransLink and Vancouver School Board.

<a id='e6ad3d48-fdcd-4f38-88c1-5eafd152cf7f'></a>

The City's commitment to equity, diversity and inclusion is long-standing and its leadership continues with the Women's Equity Strategy 2018-2028. It highlights the work that the City is currently doing in safety, housing and childcare, as well as leadership and representation within its workplace. The Strategy also emphasizes that in the context of this work, an intersectional lens is an essential foundation. This will help ensure that the City reflects and responds to the needs of all Vancouverites, including women.

<a id='d524b5b5-d340-41e8-a8eb-153e9a146483'></a>

The Strategy explicitly recognizes the issues faced by women, creates a solid case for change,
and provides goals, objectives and recommendations that will, over time, make measurable
differences. And these differences will benefit far more than only women. As one survey
participant wrote, "It is important that [the City] send a clear and decisive message to
women that we matter. Women who know they matter will engage in civic affairs and

<!-- PAGE BREAK -->

<a id='b786a6fc-f99d-4a8e-8a7e-b1abf63b9525'></a>

Gender Equality Update - 11780

<a id='803b2b1e-cf20-4bf6-bc4e-d41d054f57fb'></a>

15

<a id='c0b6e4f6-1fab-4403-b9b4-02dd00e2efb0'></a>

contribute to improving our neighborhoods and communities; hence an investment in gender equity is an investment that benefits all of us." Vancouver: A City for All Women is the Women's Equity Strategy for the City of Vancouver 2018 - 2028.

<a id='bf9d8cc0-8264-4bbb-8d32-43302244696b'></a>

* * * * *

<!-- PAGE BREAK -->

<a id='92a04575-0beb-4f54-9c28-9706785a248e'></a>

APPENDIX A
PAGE 1 OF 6

<a id='efd174e6-a755-4d0d-960f-038a491cf7be'></a>

*Review of the 2005 Gender Equality Strategy for the City of Vancouver*

To conduct the review of the 2005 Gender Equality Strategy, staff consulted lead departments assigned to each action. It was quickly determined that the action outcomes fell into one or more of the following categories:

<a id='ecbd12ba-90c1-495d-93d9-91ca2b5f058c'></a>

Completed: Action completed or integrated into existing work
Ongoing: Work related to action continues as stated
Not Completed: Action not completed or status undetermined due to staff turnover, length of time

<a id='25e5b1b1-179f-4ca5-b5b5-18aade95224a'></a>

# ACTIONS

**Action 1.1 Community Services**
Provide financial and other types of resources dedicated to initiatives that support the safety, inclusion and well-being of women, including childcare services, family services, neighbourhood houses, women's shelters and centres, and specific services for immigrant women, young women and girls, and Aboriginal women throughout the City.

<a id='5bb3129e-d4d3-47dd-820a-45ce67aa55f8'></a>

STATUS: Ongoing

➤ Community Services tracks grants for their impact on women and other groups. In 2016, $8M of social grants supported all categories set out in this action item and $1M in grants went to programs that serve over 85% women and girls.

<a id='380fe2b4-aa73-4621-89c9-f23afc6fdd96'></a>

Action 1.2 Community Services
Provide support for the key strategies of the Vancouver Agreement's Women's Task Team.

<a id='399a4dda-c49b-47b0-9943-a66c577eba13'></a>

STATUS: Completed

- The Vancouver Agreement's work wrapped up in 2009-2010. The Women's Task Team worked with a number of community organizations representing women in relation to several projects. Projects such as Bad Date Reporting became part of the ongoing work of Prostitution Alternatives Counselling and Education (PACE) and the Women's Information Safe House (WISH). The Mobile Access Program is still being operated by PACE and WISH and continues to receive funding from the City of Vancouver.

<a id='0aa9881c-d945-4a65-bfcc-3bf158e9c76a'></a>

Action 1.3 Equal Employment Opportunity
Continue to:
* ensure equal employment opportunities for women through the effective implementation of our Equal Employment Opportunity policy
* protect employees' human rights through the effective implementation of our Harassment policy
* promote and support the employment of women, including specific initiatives for women in non-traditional jobs, by partnering with educational institutions and community agencies, work practicums, career fairs, the Aboriginal Employment Partnership Initiative, and related outreach activities
* provide staff training in a variety of formats on the City's Workplace Harassment and Equal Employment Opportunity policies, including training on preventing harassment,

<!-- PAGE BREAK -->

<a id='fb041853-9b80-4184-b2c3-a353177a23a6'></a>

APPENDIX A PAGE 2 OF 6

<a id='cb8bd716-4772-4c30-a09e-21a26abc86e8'></a>

building respectful workplaces, conflict resolution and building and supporting a diverse workplace
* act as a neutral and impartial resource for all City staff on issues relating to harassment and human rights; and
* provide mediation, intervention and investigation services related to harassment complaints and issues.

<a id='db67d9fb-b196-4aa3-8218-61859bae7122'></a>

STATUS: Ongoing

<a id='00e11803-38a9-4c28-aaef-7d19e1f628b2'></a>

Action 1.4 City Clerk's
Establish an Advisory Committee on Women's Issues to provide advice and further develop actions in this plan, with liaison positions from the VSB, VPB, VPL and VPD.

<a id='d7f5d0a0-e982-468c-8ed1-a9f66a135f1c'></a>

STATUS: Ongoing
> The Women's Advisory Committee was established in February of 2009. The February 2009 motion established non-voting liaison positions for VSB and VPB only.

<a id='25deb5c1-7493-42e8-bf53-b98d645b3db9'></a>

Action 1.5 City Clerk's
Create a page on the City's website that increases the visibility of women's civic engagement.

<a id='a2f8accc-1e84-43b3-b2b4-37d4ad472eea'></a>

STATUS: Completed

  In 2007, City Clerk's Department reported that it established a website link to various materials and a toolkit to increase women's participation in municipal decision-making under the then-header "Get Involved with Your Community".

<a id='e3d64cdc-bd89-4ab2-9094-bb48980a2c3c'></a>

Action 1.6 City Clerk's
Create a new compulsory category in the City Council report template called "Sustainability
Implications," combining the current "Environmental" and "Social" Implications. This category
will direct that Council Reports address social, economic and environmental sustainability,
including different implications for women and men, girls and boys.

<a id='f2d4f505-987e-40b2-a9ab-ef3cf3b71ebd'></a>

STATUS: Not completed
* The new category was not established. Implications are currently captured under "Environmental" and "Other" Implications.

<a id='7f7e43fd-91e9-4a1a-a508-abee7dea0a76'></a>

Action 1.7 Sustainability Office, City Clerk's
Add a training module on using the Sustainability Implications lens to the Committee
Orientation for all Committees at City Hall.

<a id='78bd19f7-a664-43f8-99ea-65920ec953ee'></a>

STATUS: Not completed
▸ This Action Item was linked to the creation of the "Sustainability Implications" (Action
1.6).

<a id='e2e7c895-570f-45e5-849b-3b50cccbd2cb'></a>

Action 1.8 Community Services Group
Develop, pilot and implement a gender impact assessment tool for use by City programs, which includes guidance on collecting and using gender disaggregated information.

<a id='f811a505-d6d7-4087-8752-2d2b2018e619'></a>

STATUS: Ongoing

<!-- PAGE BREAK -->

<a id='53ed06f0-5a00-4d6c-a99e-992d451fdbc4'></a>

APPENDIX A
PAGE 3 OF 6

<a id='f258a0c4-4aab-49db-9a01-c4a8d7dc9fac'></a>

- This was initially not undertaken due to resource constraints. However, in 2017, Community Services initiated work to develop an intersectional lens, one of the guiding principles as part of the Healthy City Strategy. Completion is expected in 2018.

<a id='aecc7397-c6d8-47a1-8e62-c55a6dd0aaf6'></a>

Action 1.9 Public Involvement, City Clerk's
Develop and add a module on increasing women's participation to the Public Involvement
training course offered to staff.

<a id='3fe58d84-f14f-4ec9-82ef-1c06880250bf'></a>

STATUS: Completed
- In 2005, increasing women's participation was part of the training to familiarize staff
with the "Get Involved with Your Community" website. The website included a toolkit
to increase women's participation in municipal decision-making.

<a id='a67050ce-61d7-45d1-ad27-358673cb6619'></a>

Action 1.10 Planning, Community Services
Work with the Urban Design and Development Planning Centre to find ways to apply a gender lens to CPTED (Crime Prevention through Environmental Design) guidelines and review processes.

<a id='2775673e-30c9-4ceb-9b68-59b595239f08'></a>

STATUS: Ongoing

* Planning applies CPTED guidelines to development. The Guidelines reflect gender equality principles, including addressing women's safety by creating safer environments.

<a id='64a06ea3-2b62-4998-b25b-74c2a6cdf6f4'></a>

Action 1.11 Community Services
Continue to work with DTES (Downtown Eastside) Women's Centre to develop a Street Banners project as requested.

<a id='549fe1fb-e840-4eec-9b0f-2f4fd76ee455'></a>

STATUS: Not completed

- Funding is currently provided to the DTES Women's Centre and the DTES Women's Market.

<a id='d676fcbb-0810-4486-867c-2e0c819d519b'></a>

Action 1.12 Vancouver Police Department (VPD)
Promote "inclusion with influence" of Aboriginal women and girls in the community
consultation process on the re-instatement of the VPD Native Liaison Unit.

<a id='2f05bf04-8625-4ccd-ba44-0cc742c20778'></a>

STATUS: Ongoing
- The VPD consulted with Aboriginal elders and youth (both female and male) to create the Aboriginal Community Police Center. The work is ongoing with the VPD Diversity & Indigenous Relations Section.

<a id='59c17353-94d5-433e-90c5-e51540a45d3f'></a>

Action 1.13 Mayor's Office
Host a civic engagement event at City Hall on International Women's Day 2006 highlighting
women's involvement in the Community Visions (City Plan) process and reaching out to those
women who have not historically been involved in those processes.

<a id='e3692219-079f-4714-ab5e-ce5ee70da9f0'></a>

STATUS: Completed
- An event was held on International Women's Day 2006. The event included women who spoke about their experiences as Aboriginal women, women with disabilities, youth and other communities.

<!-- PAGE BREAK -->

<a id='60e44fa3-db11-4b80-bd29-737eb66bfb5b'></a>

APPENDIX A
PAGE 4 OF 6

<a id='8e4a3053-b6db-426a-980e-e6ec643771f9'></a>

> An event was also held in 2007 that involved collaboration between the City and other municipalities. The event focused on women's involvement in political and civic life.

<a id='18229322-0edb-44f1-90b6-04a50ea2b683'></a>

Action 1.14 City Council
Request that TransLink engage in a public education campaign for transit users to promote safety features within the transit systems (such as the "request stop" program).

<a id='d7eb28ea-527f-4b62-94ac-fa8c0fdc02a4'></a>

STATUS: Not completed (The 'request stop" program currently exists with TransLink.)

<a id='dc0a40a0-86eb-4164-afa9-0649766f58cb'></a>

Action 1.15 City Council
Request that TransLink develop a policy to involve women in the design of bus and sky train stops, routes and shelters including a program of women's safety audits of current transit system and routes.

<a id='38ae006c-6b95-48d8-a183-ef885d66755f'></a>

STATUS: Completed
➠ In May 2005, Council referred recommendations to TransLink to prioritize women's
safety in the transit system; to involve transit-dependent women in the planning
process; to increase service in off-peak hours; and to create more bus priority
measures rather than reducing the number of stops.

<a id='10222df6-2bec-4224-a51d-c1f30d9eac97'></a>

Action 1.16 Communications, City Clerk's
Ensure all images used in City publications and promotional materials promote positive and
varied images of women and men, girls and boys of diverse backgrounds.

<a id='ddeb83a3-4ae4-410e-a05b-7b5eb7275fa8'></a>

STATUS: Ongoing

- Images used in City communications promote positive and varied images of diverse individuals, including women and men, and girls and boys.

<a id='bcf0158e-e194-48d7-a051-13446984c52a'></a>

Action 2.1a Community Services
Create a coordinating body focused on issues of well-being of Aboriginal women and girls, with an initial membership of elected and staff representatives from the City, the Parks Board, the School Board and the community, and an initial mandate of

a) identifying current VSB, VPB and City initiatives focused on Aboriginal women and girls;
b) identifying opportunities for coordination amongst these, and
c) ensuring "inclusion with influence" of Aboriginal women and girls in these initiatives.

<a id='ab40e559-2cdb-41a6-9e1b-8d136d5a8537'></a>

STATUS: Ongoing

*   In 2012, Council created the Urban Aboriginal People's Advisory Committee (UAPAC) to advise the City on "enhancing access and inclusion for urban Aboriginal Peoples to fully participate in City services and civic life." The Committee has up to 15 members, including women, and has two Council Liaisons and a Park Board Liaison.

<a id='062d81de-4a30-4054-8021-a2ce6fa5dcd0'></a>

Action 2.1b Community Services
Develop a pilot project that brings the VSB, VPB and City together to develop a supportive program in two schools for Aboriginal girls, focusing on grades 7/8/9, to help this age group stay in school and be successful in the high school grades.

<!-- PAGE BREAK -->

<a id='fdd7affc-101e-48e3-8227-36854a42bd3e'></a>

APPENDIX A
PAGE 5 OF 6

<a id='d46df3a0-ace4-462e-bc54-7a6a51cc32f5'></a>

STATUS: Not completed (The Vancouver School Board is not within the City's jurisdiction.)

<a id='82257aa4-fcff-4d08-96d1-6b0da5bec534'></a>

Action 2.1c Community Services
Work through the Vancouver Agreement to explore the feasibility of providing an after-hours safe place for Aboriginal women and girls in the DTES (including the possibility of expanding hours of operation of the DTES Women's Centre).

<a id='7152da46-6ecf-4cdd-9311-e5a396182518'></a>

**STATUS:** Ongoing
* The DTES Women's Centre hours have been extended and additional funding has been provided to expand staffing and services. In October 2017, Council approved a one-time Capital Grant of up to $250,000 towards renovations for the Downtown Eastside Women's Centre Association 24/7 Shelter in partnership with BC Housing.

<a id='615c7d1c-799c-4ffe-8c4a-21e1c5bb0990'></a>

**Action 2.2 Community Services**
Develop a pilot project that would result in the creation of practical gender mainstreaming tools for the neighbourhood visioning and planning process - a partnership project between a team of interested planners and a women-serving organization in a neighbourhood scheduled for "re-planning." The model developed to include tools for engaging those women who have not historically been involved in the community visioning process, as well as tools for neighbourhood planning through a gender lens.

<a id='44134845-65c9-4616-9346-3680ac9ffe86'></a>

STATUS: Ongoing

- An inclusive approach to engaging neighbourhoods in planning was adopted, including efforts to reach out to all members of the community. This practice continues to be used and it has been updated to include outreach and engagement using social media and targeted outreach.

<a id='f4dafa21-0786-4eda-a97a-013359c7dc4b'></a>

Action 2.3 Planning, Community Services
Develop a pilot project that would result in the creation of practical gender mainstreaming tools for the development process - through a partnership project with a developer interested in creating a "women-friendly" development.

<a id='40758928-66e6-4747-b1d4-869739272adf'></a>

STATUS: Ongoing
* In 2016, staff worked with East 33rd Ave Co-Housing as a pilot project for specifically engaging with young mothers in the design process of this new housing typology. The learnings from this pilot are being integrated in updated Family Housing Guidelines.

<a id='8eeb87cd-331b-47ee-a289-a0bf1f330b2f'></a>

Action 2.4 Mayor's Office
Celebrate the contributions of women and girls through an annual International Women's Day event at City Hall.

<a id='a6cbf6f5-7ad6-4c49-907b-f09f1a439f9d'></a>

STATUS: Ongoing
* The City hosts an annual event celebrating International Women's Day.

<a id='6553e2f3-2c8a-4908-a433-a089952bf0d7'></a>

Action 2.5 Community Services
Monitor developments, review progress and deliver an annual report on gender equality measures on March 8th each year, at an International Women's Day Event at City Hall.

<a id='2253ff12-3a69-40fd-a7aa-ee9935ed1404'></a>

<::attestation: Status indicator
Status: Completed
Short description of visual elements and positioning::>

<!-- PAGE BREAK -->

<a id='82d5b623-cb74-4a24-a005-03c880a5e452'></a>

APPENDIX A
PAGE 6 OF 6

<a id='5793d72f-25ef-4de9-a033-5974cc47ab05'></a>

> The Equal Employment Opportunity Office previously compiled and presented a summary of departmental work related to diversity and inclusion in March of every year.

<!-- PAGE BREAK -->

<a id='47e8f28d-bff1-4958-b6d1-4abfb6fde427'></a>

VANCOUVER:
A CITY FOR
ALL WOMEN

<a id='67717ad4-5edf-4e6d-8db2-d54b385994e1'></a>

<::A group of six diverse women, ranging in age and ethnicity, stand together, smiling and laughing. They are all wearing various shades of pink clothing, with their arms around each other's shoulders, conveying a sense of camaraderie and support.
: photo::>

<a id='c6495b58-720e-4c65-9529-fc2408080a92'></a>

WOMEN'S EQUITY STRATEGY
2018-2028

<a id='87cdc501-29e0-4fef-bf5c-5e98f9f743e8'></a>

<::logo: City of Vancouver
CITY OF
VANCOUVER
A white stylized lotus flower with five petals is positioned to the left of the text, all against a red background::>

<!-- PAGE BREAK -->

<a id='dda18932-3ad5-4356-b233-7527c3f1e4bf'></a>

A MESSAGE FROM
THE CITY MANAGER

<a id='71e53813-72c1-4764-aaec-210dcf256b58'></a>

I'm very pleased to present Vancouver:
A City for All Women, Women's Equity
Strategy 2018-2028.

<a id='94e89f99-2c29-4c0f-8c70-2275fa7e6601'></a>

Unanimously adopted by City Council,
the Strategy builds on the foundational
work started with the City's 2005 Gender
Equality plan and sheds light on many of
the barriers which continue to limit the
full participation and contributions of all
women, including those who identify as
women. The Strategy sets out specific
goals and targets to address these barriers,
recognizing that the full inclusion of all
residents is fundamental to creating
a city which is diverse, welcoming,
vibrant, economically successful, and
environmentally sustainable.

<a id='7cb3dbab-2b38-4c29-9586-67c0fed21e72'></a>

Leveraging and aligning with related
City strategies such as Healthy City and
Housing Vancouver, we will specifically
take action to increase women's safety
and affordable housing, and address
the impact of the childcare shortage on
women's economic participation. We
will also lead by example within our own
workforce by removing barriers for women
and increasing the number of new hires
in leadership and in historically under-
represented occupations.

<a id='3488283d-4b3a-4ac0-8cc0-4569f97cf530'></a>

Finally, and underpinning it all, we will
apply an intersectional approach to our
work to ensure that all residents, including
all women, have equitable access, inclusion
and participation in the life of the city.

<a id='d461ae96-9a4a-4b45-a4b7-df5a53952c0f'></a>

The development of this Strategy follows extensive engagement with the City's Women's Advisory Committee and City staff, as well as public input, research, and consultations with subject matter experts and other organizations, including municipalities. I wish to thank all who gave their time and shared their expertise and experiences and, in particular, the members of the Women's Advisory Committee.

<a id='b013bbe4-22ca-4834-9f65-ae5f07d38bd2'></a>

Removing barriers to full inclusion for all women will require sustained and coordinated efforts from all levels of government, community organizations, and individuals. The City of Vancouver is committed to doing its part through the implementation of this Strategy, sharing and learning from others committed to women's equity and influencing change wherever possible. We look forward to working with our stakeholders to make Vancouver a place where all women enjoy full inclusion in the political, economic, cultural and social life of the city.

<a id='632a5323-cebb-496c-a630-b44ce7c630b7'></a>

<::attestation: Signature
Signed
Signature: legible (Sadhu A. Johnston)
Sadhu Aufochs Johnston
City Manager
A blue handwritten signature is positioned above the printed name "Sadhu Aufochs Johnston" and title "City Manager", all centered on a white background.::>

<!-- PAGE BREAK -->

<a id='c0e923ec-365f-4b51-b81c-5ca23bf50cb6'></a>

CONTENTS

<a id='f2c7cefa-3308-4edf-8c42-b97b8498ffe6'></a>

<table id="23-1">
<tr><td id="23-2">Executive Summary</td><td id="23-3">.2</td></tr>
<tr><td id="23-4">Vision</td><td id="23-5">.6</td></tr>
<tr><td id="23-6">Principles</td><td id="23-7">.6</td></tr>
<tr><td id="23-8">What we Heard</td><td id="23-9">.7</td></tr>
<tr><td id="23-a">Why it Matters</td><td id="23-b">.9</td></tr>
<tr><td id="23-c">Inequality&#x27;s Differential Impact</td><td id="23-d">13</td></tr>
<tr><td id="23-e">The Case for Change</td><td id="23-f">14</td></tr>
<tr><td id="23-g">Priorities</td><td id="23-h">15</td></tr>
<tr><td id="23-i">Strategies</td><td id="23-j">16</td></tr>
<tr><td id="23-k">Plan for Action</td><td id="23-l">17</td></tr>
<tr><td id="23-m">Priority: Intersectional Lens</td><td id="23-n">18</td></tr>
<tr><td id="23-o">Priority: Women&#x27;s Safety</td><td id="23-p">20</td></tr>
<tr><td id="23-q">Priority: Childcare</td><td id="23-r">22</td></tr>
<tr><td id="23-s">Priority: Housing</td><td id="23-t">24</td></tr>
<tr><td id="23-u">Priority: Leadership &amp; Representation</td><td id="23-v">26</td></tr>
<tr><td id="23-w">Accountability.</td><td id="23-x">28</td></tr>
<tr><td id="23-y">Acknowledgements.</td><td id="23-z">29</td></tr>
<tr><td id="23-A">Endnotes.</td><td id="23-B">32</td></tr>
<tr><td id="23-C">Snapshots of City&#x27;s Current Actions.</td><td id="23-D">34</td></tr>
<tr><td id="23-E">Inputs for Future Consideration.</td><td id="23-F">40</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='c1955f8d-ec6f-40f4-baaf-9ec5b4e52c7c'></a>

<::A woman with curly brown hair and glasses stands at a podium, looking down at papers. She is wearing a red, black, and white dress and a silver necklace. A microphone on a gooseneck stand is positioned in front of her. Behind her, a large screen displays an image of several people, likely roller derby players, with the white text "THIS GIRL CAN" in a rectangular frame prominently featured on the left side of the screen.
: figure::>

<a id='76b8c66a-4449-4356-bc79-765dca73dfc9'></a>

EXECUTIVE SUMMARY

<a id='6731f6c5-7326-4ffd-be66-aba61a521b2e'></a>

"Because It's 2016: Action on Gender
Equality" was the Vancouver City Council
motion that inspired the development of
an updated women's equity strategy and
provided the opportunity to consider our
work in light of the persistent issue of
women's inequality in our community. The
result is **Vancouver: A City for All Women**,
Women's Equity Strategy 2018-2028.

<a id='c6446262-6dfe-4029-bd6e-e983b9612d51'></a>

The Strategy reflects our vision to make
Vancouver a place where all women and
self-identified women have full access to
the resources provided in the city and
opportunities to fully participate in the
political, economic, cultural and social life
of the city.

<a id='79f2527b-732c-4eaa-9dae-b8b0af3b2b62'></a>

"Women and girls comprise a majority of Vancouver residents (51 per cent) but on average have lower incomes, less housing security, more unpaid work, experience far greater rates of poverty and gender based violence and in general have less opportunities than men and boys"
(Council Motion - Because It's 2016: Action on Gender Equality).

<a id='dcfc6977-6651-4bac-af1d-e29f0f9242c7'></a>

Women's inequality is an issue that affects
us all. We cannot reach our full potential
as a city and as a community when
certain segments of our population are
marginalized and denied full inclusion and
participation. We know that all women's full

<a id='9a50bf8c-245f-4392-8e96-a08e19e964a8'></a>

2

<a id='f10f4d22-1673-423f-a7fc-c51ea7c22364'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='aaaa41b9-ee82-4e52-9d8b-6594b309876b'></a>

inclusion boosts our economy, increases
our productivity, and reduces child poverty.

<a id='47fc0b9f-1a2b-463b-8e85-cd170c166a88'></a>

Addressing such a wide-ranging issue as
women's equity requires all social agents
– individuals, organizations and all levels
of government – to take intentional steps
towards this goal. As a city, we can take
positive actions within our jurisdiction
and encourage others to do the same.
The focus of this Strategy is in those areas
where the City of Vancouver can make a
difference.

<a id='b75ad151-4fd2-4c57-842a-d9d0fa0d5f6c'></a>

We are grateful to the many individuals and organizations that took the time to share their experiences and expertise. In particular, the City's Women's Advisory Committee spent countless hours and many meetings sharing their expertise and informing the scope and content of the Strategy. In addition, more than 1,600 residents participated in our online survey and public forum, subject matter experts and community organizations took valuable time to meet with us, and City staff were consulted for their expertise and feedback.

<a id='b17ba42d-a761-43fe-9a1f-f2e3f7c98e82'></a>

Throughout our consultations, we heard recurring themes that emerged as priority areas. Addressing the issues faced by all women in each of these areas is seen as key to improving women's full inclusion in the life of the city:

* Applying an intersectional lens to the City's strategies and plans
* Addressing safety, including violence against women
* Accessible, quality childcare
* Safe and affordable housing
* Women's leadership and representation within the City's workforce

<a id='2f7837b1-5bf6-44c7-92c9-8b0e73a33336'></a>

**Vancouver: A City for All Women** is a 10-year strategy that recognizes the current shifting political and social landscape. Within each priority area, a number of Phase 1 Actions have been identified for 2018-2019. A staff Action Team will coordinate implementation of the Phase 1 Actions and, in consultation with the Women's Advisory Committee, will consider all inputs received as potential actions over the next eight years of the Strategy.

<a id='39e9d33b-3cd3-4e3c-a12c-f59ca5071cff'></a>

A key success factor for this Strategy
is being accountable to our goals and
objectives. To that end, we will measure our
progress and report out regularly. In 2019,
we will provide a progress report to Council
and outline actions for implementation in
the next phase of the Strategy.

<a id='5a77fbf8-a0dd-41e9-88a7-b0f2dd114783'></a>

Another key success factor is alignment
with the City's Healthy City Strategy.
The Healthy City Strategy is guided by a
vision of A Healthy City for All, ensuring
collectively we pursue a strong and
inclusive focus on inequity, including
gender inequity. These principles also
emphasize the importance of including
meaningful involvement in the broader
public, private and civic sectors.

<a id='e62c3705-eeab-4bd4-9aa2-0f140beb28ab'></a>

3

<a id='ddd81bd8-a964-473f-905d-cc7dc2fb2e1d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='72f56741-0abb-49b1-b3be-f2f463865a58'></a>

## Summary of Priority Areas and Phase 1 Actions
The following summarizes our Phase 1 Actions by priority area. Full detail on each priority, as well as background on the City's current work in each of these areas, is included in this document.

<a id='27d49fac-216b-42cb-9844-24bd83c72d90'></a>

These priority goals and objectives
parallel the City's Healthy City Strategy
'determinants of health' approach and
include indicators and targets that have
been designed to address inequalities at a
municipal level.

<a id='01fb836a-83c5-4b0d-be94-cd917e5ca92c'></a>

The City is in a position to make a difference and so should play a leadership role. Gender stereotyping and discrimination not only restricts females' and males' ability to participate fully in the world, it limits the City's economic potential.

- Public Survey "Action for Women"

<a id='c6d2d33a-e2a3-421a-848f-a3b063568c4c'></a>

INTERSECTIONAL LENS
<table id="26-1">
<tr><td id="26-2">GOAL</td><td id="26-3">The City&#x27;s decisions, programs and plans are informed by an intersectional lens to ensure that all citizens have equitable access, inclusion and participation in community life.</td></tr>
<tr><td id="26-4">OBJECTIVE</td><td id="26-5">In 2018, an intersectional framework will be established for City departments.</td></tr>
<tr><td id="26-6">STRATEGIES</td><td id="26-7">Education &amp; Awareness, Policy</td></tr>
<tr><td id="26-8">PHASE 1 ACTIONS: 2018-2019</td><td id="26-9">1. Pilot intersectional framework. 2. Introduce the application of an intersectional lens to senior staff through training in Gender-Based Analysis Plus (GBA+), offered through Status of Women Canada. 3. Bring forward to Council revised Civic Assets Naming Guidelines that include gender diversity.</td></tr>
</table>

<a id='6306562d-37fd-4b2f-b2c5-8ce671d18c9e'></a>

SAFETY
<table id="26-a">
<tr><td id="26-b">GOAL</td><td id="26-c">Vancouver is a safe city in which all women are secure and free from crime and violence, including sexual assault.</td></tr>
<tr><td id="26-d">OBJECTIVE</td><td id="26-e">By 2025, women&#x27;s sense of safety will be increased by at least 10 per cent.</td></tr>
<tr><td id="26-f">STRATEGIES</td><td id="26-g">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="26-h">PHASE 1 ACTIONS: 2018-2019</td><td id="26-i">1. Join UN Women&#x27;s Global Flagship Initiative &quot;Safe Cities and Safe Public Spaces&quot; and conduct a scoping study on women&#x27;s safety. 2. Identify community partners and collaborate on an annual public campaign to raise awareness on violence against women. 3. Update the Women&#x27;s Advisory Committee annually on progress in ensuring women&#x27;s safety and needs in the neighbourhood planning and development process. 4. Formalize senior staff coordination and oversight of inter-departmental response to critical issues in the Downtown Eastside, including women&#x27;s safety and related issues.</td></tr>
</table>

<a id='a26d6806-6b73-498a-9cb3-f52f23460ed9'></a>

4

<a id='004ab8c9-f0c1-4c8f-bfd0-620090613d0f'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='240c0db6-5f35-4eaf-ba8e-fe1ce746eaf1'></a>

CHILDCARE
<table id="27-1">
<tr><td id="27-2">GOAL</td><td id="27-3">Women&#x27;s full participation in the workforce and engagement in public life is supported by affordable and accessible quality childcare for children.</td></tr>
<tr><td id="27-4">OBJECTIVE</td><td id="27-5">By the end of 2018, 1,000 new childcare spaces will be added from the 2015 baseline.</td></tr>
<tr><td id="27-6">STRATEGIES</td><td id="27-7">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy</td></tr>
<tr><td id="27-8">PHASE 1 ACTIONS: 2018-2019</td><td id="27-9">1. Share input from the Women&#x27;s Equity Strategy consultations for consideration in the City&#x27;s updated childcare strategy. 2. Partner with senior levels of government to significantly increase affordable, quality childcare through creating new childcare spaces, and replacing aging centres. 3. Identify child-friendly provisions to accommodate participation by families with children at Council and Public Hearings at City Hall.</td></tr>
</table>

<a id='e3dd4924-286a-4bf1-aae8-a1ae97f0155e'></a>

HOUSING
<table id="27-a">
<tr><td id="27-b">GOAL</td><td id="27-c">A range of affordable housing choices is available for women of diverse backgrounds and circumstances, including single parents, seniors, newcomers, and those facing vulnerable conditions.</td></tr>
<tr><td id="27-d">OBJECTIVE</td><td id="27-e">72,000 new homes across Vancouver in the next 10 years.</td></tr>
<tr><td id="27-f">STRATEGIES</td><td id="27-g">Education &amp; Awareness, Data, Partnerships &amp; Collaboration</td></tr>
<tr><td id="27-h">PHASE 1 ACTIONS: 2018-2019</td><td id="27-i">1. Identify how to determine the extent of women&#x27;s hidden homelessness to better understand its full scope. 2. Research integration of outreach role within Coordinated Access Centre to liaise with women-serving organizations and identify women in need of priority housing. 3. Share input from the Women&#x27;s Equity Strategy consultations for consideration in the implementation of the Housing Vancouver Strategy.</td></tr>
</table>

<a id='c9f75322-3928-43be-b284-b98cc7af203b'></a>

LEADERSHIP & REPRESENTATION
<table id="27-j">
<tr><td id="27-k">GOAL</td><td id="27-l">The City will elevate the visibility, influence, representation and contribution of all women in the organization by providing equitable access to work opportunities, including leadership roles and other under-represented occupations&#x27; and by creating and implementing initiatives to specifically enhance their development and leadership.</td></tr>
<tr><td id="27-m">OBJECTIVES</td><td id="27-n">• Effective immediately, the City will increase new hires for Senior Management roles to 50 per cent women.• By 2020, the proportion of female new hires in under-represented occupations will be increased by at least five per cent over the 2017 baseline.</td></tr>
<tr><td id="27-o">STRATEGIES</td><td id="27-p">Education &amp; Awareness, Partnerships &amp; Collaboration, Policy, Data</td></tr>
<tr><td id="27-q">PHASE 1 ACTIONS: 2018-2019</td><td id="27-r">1. Become the first municipality to sign Minerva BC&#x27;s Face of Leadership™ Diversity Pledge, making a public commitment to support women&#x27;s advancement in leadership in our workforce and in our community.2. Develop and implement a Breastfeeding Policy for City staff.3. Conduct focus groups with female staff in leadership and under-represented positions.4. Measure and publicly report annually on the City&#x27;s workforce composition including positions and compensation.5. Address potential bias in the hiring process by training recruitment staff to recognize and mitigate unconscious bias.</td></tr>
</table>

<a id='30a3fc08-ee49-4523-897f-369d5528dfa3'></a>

5

<a id='fbaaae0e-53b5-41ae-ac8f-040df90f8292'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='bf5dc505-c25b-40eb-a9e8-2af3aefa561b'></a>

<::logo: [VISION]VISION
A bold, sans-serif font in red text is presented on a white background.::>

<a id='64f2e904-fb00-4457-a048-d825cfa8ebcc'></a>

The City is committed to making Vancouver a place where all women have full access to the resources provided in the city and have opportunities to fully participate in the political, economic, cultural and social life of Vancouver.

<a id='6cc91624-8afb-4a8f-95ea-a1eea3f65506'></a>

# PRINCIPLES

The implementation of the Strategy reflects the following principles:

*   ***"Nothing about us without us."*** We will be inclusive of the voices of all women and women's organizations through consultations with the Women's Advisory Committee and other stakeholders.
*   ***Intersectional lens*** For many women, the impact of gender inequality is compounded by other forms of discrimination including race, disability, language, immigration status, and prejudice against Indigenous Peoples. Applying an intersectional lens to developing programs, services and policies considers this differential impact and aims to address it.
*   ***Systemic and culture change*** The City recognizes that patterns of inequality are deeply entrenched in our social and institutional structures, and historical and cultural patterns. The City will focus on systemic changes in its approach to

<a id='ec491aa4-df77-4b38-9cb3-7355a199352e'></a>

equity for all women, with the aim of shifting systems and changing attitudes.

*   **Sustainable** In order to be sustainable over the long term, the Strategy aligns with other City initiatives, such as the _Healthy City Strategy_. The Strategy is also flexible and responsive to emerging opportunities and trends, allowing us to maximize our ability to advance our vision and goals.

*   **_S.M.A.R.T._** Our goals and targets are **S**pecific, **M**easurable, **A**chievable, **R**ealistic, and **T**ime-bound.

*   **_Criteria for inclusion_** The success of the Strategy depends on setting goals and targets in those areas over which we have control and jurisdiction. The Vancouver Police Department, Vancouver School Board and Vancouver Public Library all have their own Boards and are independent of the City of Vancouver. Our Strategy does not commit to actions that fall under their mandates.

<a id='39742d50-5024-4047-b579-509de2d343cd'></a>

All citizens deserve equal opportunities. Vancouver is seen as a progressive city and gender equality would be an important component of that.

- Public Survey "Action for Women"

<a id='80c3dc88-5133-4156-8967-b98dcaf42034'></a>

6

<a id='22fedab3-9c96-4262-8ad4-28f4348e3b8d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='4cbe680a-be13-497d-b08d-499134321448'></a>

WHAT WE HEARD

<a id='a6705162-a7f0-4dbc-9ecc-71ea2934ca35'></a>

**Vancouver: A City for all Women** has been
informed by the voices and experiences
of more than 1,600 residents, members of
the City of Vancouver's Women's Advisory
Committee, subject matter experts,
community organizations, research,
and City staff. In particular, members

<a id='6e36c885-1fee-43a2-8987-9787972534fb'></a>

of the Women's Advisory Committee
dedicated an abundance of their time
to the development of this Strategy,
both at regular meetings and specific
working sessions.

<a id='d3182fd2-a4ba-433f-bbee-7ed525c06d86'></a>

Throughout these consultations several key themes and priority areas emerged.

<a id='0c7b0fcf-920a-4607-9dac-682b9c47a571'></a>

# WOMEN'S SAFETY

We heard that women in Vancouver continue to deal with the effects of violence and that many women do not feel safe within the city.

INTERSE

<a id='2a3fdd83-39ef-47af-8795-1ee39ac55e6b'></a>

**CHILDCARE**
Access to affordable quality childcare is an urgent issue that was cited as the number one action that could immediately and positively impact all women's lives, their economic participation and economic independence.
CTIONAL

<a id='3803a947-5014-4192-91f3-895a1cc74718'></a>

not feel safe within the city.

## INTERSECTIONAL LENS
An intersectional lens is needed to ensure that actions in these priority areas benefit all women.

## HOUSING
We also heard that Vancouver's housing crisis disproportionately impacts women - in particular women leaving intimate partner violence. The combined issues of a lack of affordable housing and women's relative economic disadvantage place women at greater risk of returning to or staying in an abusive situation. The housing crisis also makes women vulnerable to exploitation.

L
REI
Finally, we show leade women's e employme and public

<a id='fdfd7049-1d73-44ce-833b-e121971c00cb'></a>

all women.

# WOMEN'S LEADERSHIP & REPRESENTATION

Finally, we heard that the City should show leadership in advancing all women's equity through its own employment practices, public policies and public communications.

<a id='c35a63fe-3da9-4bf3-a578-ccbc4bc6b640'></a>

7

<a id='952d1810-80a6-4a53-a1c4-ca0c89199f81'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='ee3d12ac-f1da-4267-923a-5d9962d6e48f'></a>

<::A smiling woman with dark hair and a red turtleneck under a black coat holds a baby. The baby, wearing a light-colored, cable-knit sweater with dark buttons, looks directly at the viewer. The background is a blurred green field with hints of other colors, suggesting an outdoor setting.: figure::>

<a id='6ca39277-2de1-49bc-afcf-b01fa5eeb729'></a>

**INTERNAL CONSULTATIONS**
* Ongoing consultations with internal experts and impacted Departments

<a id='017a5217-56c6-4738-aac2-54c17b46c11d'></a>

PUBLIC CONSULTATIONS
* Survey (1,640 responses)
* Forum (45 attendees)
* Community organizations
84 contacted/invited

<a id='f29bd8e9-42e2-4740-9a54-9a026f0fcabc'></a>

<::diagram
: WOMEN'S EQUITY STRATEGY
: 2018-2028

: WOMEN'S ADVISORY COMMITTEE
: • Updated and consulted regularly
: • Provided guidance and advice on process and plan

: SUBJECT MATTER EXPERTS
: • 21 contacted
: • 16 interviewed/consulted

: RESEARCH & BEST PRACTICES
: • 35+ papers reviewed
: • Statistical research
: • 10+ cities studied

: ADVISORY COMMITTEES
: • Council Advisory Committees contacted and invited to participate::>

<a id='e60bdb8c-adb0-42dd-a683-d6387aa34239'></a>

8

<a id='ad7668c8-58f8-4da4-b123-be3cf73cd6ab'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='a581aa51-85ca-469f-aef5-092c1d3cae36'></a>

WHY IT MATTERS

<a id='70e4969d-5e8c-4909-a9b0-dcbb6ac89679'></a>

**Women continue to be economically disadvantaged**

Women make up 51 per cent of Vancouver's population9 and continue to be economically disadvantaged relative to men. A specific focus on improving all women's lived experiences is needed in order to achieve the City's targets in the Healthy City Strategy.

<a id='e24e25ba-817f-472e-aba6-f17437a4fb57'></a>

*Women in Vancouver earn less than men...*

Vancouver's annual living wage: $37,500²
Men's annual median income: $36,900³
Women's annual median income: $29,800³

<a id='27213b43-08da-450a-b1f3-f72a3d986a4a'></a>

Because...
* Even within the same occupations, women earn 87 cents for every dollar earned by men.⁴
* 56 per cent of women are employed in traditionally female-dominated and lower paying occupations such as teaching, nursing and health-related occupations, social work, clerical, administrative, and sales and services.⁵
* Women make up:
  * 70 per cent of minimum wage workers.⁶
  * 76 per cent of part-time workers.⁷
  * 60 per cent of those collecting Employment Insurance.⁸
  * 24 per cent of workers in higher paying professional science, technology, engineering, mathematics (STEM) occupations.⁹

<a id='716ec9ca-c59f-4d0e-8c62-1f4f2f2cc190'></a>

# The motherhood penalty
The "motherhood penalty" can be described using both an employment gap (between men and women) and an earnings gap (between mothers and non-mothers).

<a id='7bdebd83-1114-40fa-8911-68247c9c37bd'></a>

Vancouver has the third worst employment gap between men and women in Canada (11.8 per cent). The employment gap is greater in cities with high childcare fees. ¹⁰

<a id='55082346-2ef7-495e-967a-659c8d62dfe3'></a>

I have been forced to sacrifice 7 years of my career to be a stay home mom, because there is insufficient adequate childcare available in this city and it's completely unaffordable to even consider working full-time and pay for childcare for two kids.
- Public Survey "Action for Women"

<a id='db96c7c0-ef68-4547-9bd7-1c68346215be'></a>

With respect to the earnings gap, one study found women with children earn 12 per cent less than women without children. This gap increased with the number of children, up to 20 per cent for women with three or more children." The earnings gap can be partly explained by breaks in women's employment for maternity and parental leaves. Approximately 47 per cent of women take at least one maternity or parental leave over their careers, compared to 3.8 per cent of men. The average duration of women's combined parental and maternal leaves is 1.3 years.12

<a id='33673d38-4e42-4ea1-a9ba-a730fe7d4255'></a>

9

<a id='d9f5646a-ae59-4d81-b743-ca1cd81e7803'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='445f8b9c-3b7b-4c88-84e9-662999f8b57b'></a>

Women spend an average of 50.1 hours per week on childcare, more than double the average time (24.4 hours) spent by men. This includes women who work full-time.13
Of those who work part-time, 25 per cent of women and 3.3 per cent of men cited childcare as the reason.14

<a id='b14a87be-80c6-4a9b-9e49-dcf885c4e8b2'></a>

Eighty per cent of single-parent families
are headed by women¹⁵ and 90 per cent
of single parents on income assistance are
female.¹⁶

<a id='4c6a54b1-ab69-4f6b-8838-2fb3c1fa6868'></a>

The cumulative effects of extended leaves, the demands of childcare, and a lack of affordable childcare impact women's workforce availability, their earnings over the course of their careers, and their economic security over the course of their lifetimes.

<a id='b025e5fe-0a53-4289-ab11-d553bc3d76d7'></a>

# Violence against women is a persistent issue
The 1993 UN Declaration on the Elimination of Violence against Women defines violence against women as, "any act of gender-based violence that results in, or is likely to result in, physical, sexual or psychological harm or suffering to women, including threats of such acts, coercion or arbitrary deprivation of liberty, whether occurring in public or in private life."

<a id='baed01e0-8b72-444d-9058-2062f46dd941'></a>

Women's economic vulnerability places
them at greater risk of intimate partner
violence and exploitation. In addition,
violence against women increases women's
economic vulnerability through lost
education, work opportunities, and income
as a result of the associated physical and
psychological harms.

<a id='d8390893-6f43-462a-b5cd-850a33f98ed2'></a>

Intimate partner violence (IPV) accounts
for one in four violent crimes reported to
police. The vast majority of victims (80 per
cent) are women." One study found that

<a id='e2456bdd-6d0b-4670-9c1b-e990f6ebf158'></a>

60 per cent of victims of IPV had either quit their jobs or were terminated as a result of the abuse. 18 Women who leave abusive domestic partners rely on food banks at nearly 20 times the rate of average Canadians and for up to three years after leaving the abusive situation. 19

<a id='c6b63a43-4dcc-4813-b94e-5c352b51a868'></a>

Between 2004-2014, criminal victimization rates for all crimes fell by 28 per cent, while rates of sexual assault have remained stable (22 incidents per 1,000 people). However, only 5 per cent of sexual assaults are reported to the police.20

<a id='88981942-8b73-4225-b319-d369e139ffdd'></a>

Up to 27 per cent of victims of gender-based violence have used medication to cope with depression, to calm them down or to help them sleep. This is significantly higher than the proportion of women who were not violently victimized (18 per cent).21

<a id='1caf6543-8128-42e6-b8e2-a7731eaf169d'></a>

<::A young woman with dark, curly hair and glasses, wearing a grey and navy blue cable-knit sweater and jeans, standing with a black bag over her shoulder. She is smiling faintly and looking directly at the camera. Behind her is a brightly colored, cracked wall with graffiti patterns in blue, yellow, pink, and black.: figure::>

<a id='19eef89e-d014-433f-a168-fabdb8c412fd'></a>

10

<a id='d01fb95f-8aa6-4e75-b789-3a65b50de690'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='8cb6e9c5-3375-4b34-a54f-8af4489f37d4'></a>

<::A group of eight people, four men and four women, stand side-by-side in a room with wood-paneled walls. The woman in the center is holding a framed document with a decorative border. To her right, a woman wears a red jacket with a white and red patterned scarf. To her left, another woman wears a grey top with a long beaded necklace and glasses hanging from it. The person furthest to the left is a woman in a black and white plaid jacket. To the right of the woman holding the document, another woman wears a black dress and a pearl necklace. Next to her, a woman in a black top has a white circular pin on her chest. Next to her, a woman with dark hair and glasses is wearing a dark jacket. The person furthest to the right is a man in a dark suit jacket and a light blue collared shirt. A Canadian flag and another flag (possibly a provincial or organizational flag) are visible in the background on the far right.: figure::>

<a id='4d8b2377-2629-42c1-9462-e766bfb7b51a'></a>

> Sometimes at night I do not feel comfortable walking home... I do not want to feel unsafe in my own neighborhood. As well being sexually harassed by walking down the street, for example getting honked at and cat called.

- Public Survey "Action for Women"

<a id='d978a56d-626e-41c6-abb9-d402e87ca144'></a>

## Many women don't feel safe in the city

The Healthy City Strategy goal of "being safe and feeling included" includes the target of "increasing Vancouver residents' sense of safety by 10 per cent". Currently, 65 per cent of all residents agree that they "feel safe walking after dark" in their neighbourhoods.²²

<a id='890af80e-a42e-487b-80a8-83d1c3cc5891'></a>

However, when broken down, the numbers
for women are different. Only 57 per cent
of women compared to 73 per cent of men
agreed that they felt safe walking after
dark. Senior women (75+ years) and young
women (18-24 years) reported feeling the

<a id='e260d323-1ddb-4f80-b663-91d99ff3f4b1'></a>

least safe, at only 41 per cent and
47 per cent respectively. Similarly, only
44 per cent of Indigenous women, and
42 per cent of Chinese women reported
feeling safe walking after dark.²³

<a id='29dfd630-d734-4dd5-84da-c602c9991c90'></a>

In order to meet the Healthy City Strategy
target of increasing residents' sense of
safety, specific attention needs to paid to
the unique experiences of **all** women when
navigating the city.

<a id='2be876d2-5e77-4cdd-94cf-321db2a87e6f'></a>

# Women at the City of Vancouver
As a large employer and provider of public services, the City can make a positive impact within its own workforce and can demonstrate leadership in advancing all women's equity in the workplace. Through this Strategy, we will improve the representation of all women in leadership and historically under-represented occupations within the City's workforce.

<a id='48b4cfac-9822-41d1-8140-3925a7a5a771'></a>

According to the McKinsey Global Institute,
while Canada is among the global leaders
in women's equality, progress has stalled
in the last 20 years. Persistent and
significant gaps continue in the areas of
managerial positions, STEM occupations,
unpaid care work and single parenthood,
among others. 24

<a id='67ac2873-d3f0-48f3-b5af-3a1e8e941063'></a>

11

<a id='d0c9e525-33bf-4404-9dc3-e03a7d9aa805'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='e6257804-de1e-4cbd-a0ec-64c3e0353878'></a>

The following chart shows the current representation of women at the City in leadership and examples of historically under-represented occupations.*

<a id='539c0ce9-127f-4344-b20f-7198fe9a7156'></a>

<::Women at the City of Vancouver: chart::>   
<::horizontal bar chart::>  
<::Legend:  
Female (red)  
Male (blue)::>  
<::Categories and Percentages:  
Senior Management: Male 63%, Female 37%  
Engineers, Technicians and Engineering Assistants: Male 70%, Female 30%  
Information Technology (IT) Related: Male 66%, Female 34%  
Firefighting: Male 96%, Female 4%  
Trades and Operations: Male 85%, Female 15%::>

<a id='07fac709-5f37-4e05-91f2-c2461a1a814b'></a>

*Notes:
* As of November 14, 2017
* Chart excludes Vancouver Police Department and Vancouver Public Library
* *Senior Management* includes all staff pay band 10 and up.
* *IT-Related* includes all positions in technical IT roles across all departments, excluding Senior Management.

<a id='8e66e60c-1674-4090-b1df-22a75d19dc65'></a>

• **Trades and Operations** includes all trades and operations positions (e.g., construction, traffic, parks, maintenance) across all City departments, excluding Senior Management
• **Firefighting** include all firefighters, inspectors, captains, investigators, and managers excluding Senior Management.
• **Engineers, Technicians and Engineering Assistants** include all professional and technical Engineering positions across all City departments, excluding Senior Management.

<a id='2a4ba8a6-19bf-474e-a499-7e4a979ace87'></a>

12

<a id='4773a9de-d2a5-4ca6-b310-3102402a2522'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='c1ab508c-616e-4703-a274-499044fcbb85'></a>

INEQUALITY'S
DIFFERENTIAL IMPACT

<a id='d87167b8-ec68-4d5d-bab6-8242d844f5e0'></a>

For many women, the impact of inequality is compounded by other forms of discrimination related to race, disability, language, immigration status, etc. The following are just two examples of how these intersecting forms of discrimination negatively impact women.

<a id='dc42983c-e48e-4a0f-b780-305eb9e9b0cf'></a>

# Indigenous (First Nations, Métis, Inuit) women

*   While Indigenous women represent just 4.3 per cent of Canada's female population, they represent 16 per cent of female homicide victims and 11 per cent of missing persons' cases involving women.25
*   Indigenous women are three times more likely to be sexually assaulted than non-Indigenous women.26
*   Statistically, Indigenous identity remains a significant factor for violent victimization among women, even when controlling for other risk factors.27
*   Indigenous women experience higher unemployment rates and have lower median incomes than non-Indigenous women.28
*   Indigenous women are twice as likely to head lone parent families as non-Indigenous women.29

<a id='69bfa028-ff1d-49d0-ab29-bc6160fb8f18'></a>

## Women with disabilities
* 15 per cent of Canadian women report having disabilities that limit them in their daily activities. This number increases to 22 per cent for Indigenous women.³⁰
* Women with disabilities are more likely to be lone parents (11 per cent versus 8 per cent for women without disabilities).³¹
* The workforce participation rate for women with disabilities is 61 per cent compared to 83 per cent for women without disabilities.
* The unemployment rate for women with disabilities is 13 per cent versus 6 per cent for women without disabilities.³²
* Women with disabilities earn less than women without disabilities and men with disabilities.³³
* Financial insecurity increases women's vulnerability to violence. Women with disabilities report experiencing emotional or financial abuse at a proportion that is 12 per cent higher than women without disabilities and physical and/or sexual assault at a rate that is 4.4 per cent higher than women without disabilities.³⁴

<a id='353fca87-d3f1-4815-8b5e-f45adc471259'></a>

The Women's Equity Strategy recognizes
and considers this intersectionality in the
implementation of the Strategy.

<a id='f58166f3-1d08-444e-85bb-a9431ac4713f'></a>

13

<a id='5ea10f6c-238d-4056-a059-1a6b68cec85d'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='5fbf75bc-3214-411e-afad-0330dd9c9877'></a>

THE CASE FOR CHANGE

<a id='96781651-f5cc-4a23-ab45-d2b4b16c14e0'></a>

**When women are poor,
children are poor**

In Vancouver, 1 in 5 children live in poverty
(20 per cent). ³⁵

<a id='19b128f2-3ded-4f9f-9977-e99278bff12c'></a>

A close link has been established between child poverty and women's poverty. In 2014, one in every two children of single parents in BC were poor. 36 The vast majority of single parents are women and a disproportionate number are Indigenous women and women with disabilities.

<a id='155ebc02-9693-4605-9ce8-35396c6d257f'></a>

Recommendations to improve child poverty
include measures that directly mitigate
women's poverty. These include improving
social supports for families (for example
income assistance, child benefits, maternity
and parental benefits); improving labour
force participation through flexible work
arrangements and affordable childcare;
affordable housing for families; and
improving earnings through a higher
minimum wage and living wage policies. 37

<a id='4a0896d0-19a5-4684-bd7f-08caf73a6fa8'></a>

## Violence against women costs society

Children who witness intimate partner violence experience emotional, psychological, social and behavioural problems. In addition, there is evidence that the cycle of violence could continue with children who have witnessed family violence. 38

<a id='2aaf5573-2d47-4d0f-90f9-95bca10de120'></a>

The combined financial cost of sexual assault and intimate partner violence is $334 per person/year in Canada. Costs include medical care, social supports, legal costs, and lost productivity.39

<a id='2aedf905-2edb-4653-81fc-e367bdb1eb16'></a>

<::A close-up shot of two people in industrial settings. In the foreground, a woman with curly hair wears a blue hard hat, clear safety glasses, and an orange high-visibility vest. She is looking up and to the right with a slight smile, holding a tablet in her hands. In the blurred background, a man wearing a similar blue hard hat and orange vest is pointing at a control panel with various buttons and indicators.: figure::>

<a id='398311c1-923c-4f26-8709-6dae429a0e45'></a>

**Women contribute to economic growth**
A recent study by the McKinsey Global Institute found that taking steps to address all women's full economic participation could add $150 billion to Canada's Gross Domestic Product by 2026. BC's potential growth would be $21.2 million.40

<a id='6677d0e5-e55a-4698-883d-84599dc68a0d'></a>

This economic growth could be achieved by a combination of adding more women to high-productivity, high-paying sectors; increasing all women's labour force participation; closing the wage gap; access to affordable childcare; and increasing women's working hours by 50 minutes/ week.

<a id='2c054093-1930-426f-a99e-38737cf37bdf'></a>

**Workforce diversity improves business performance and profitability**

Studies have linked the presence of women in senior management to improved organizational and financial performance.

<a id='ead5eb76-3860-46b6-a1ee-86b98a033a38'></a>

In addition, a diverse workforce increases profitability and productivity. One study found that a 1 per cent increase in ethno-cultural diversity was associated with a 2.4 per cent increase in revenues and a .5 per cent increase in productivity.41

<a id='8ec65fe9-12fa-4b0f-9f82-b2fbdcf01f4b'></a>

14

<a id='7bd3f7b9-f8bc-43f5-b1ac-093a1f01a386'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6faa9cbb-48fe-4055-a88a-38e74bfe0d8f'></a>

<::logo: Priorities
PRIORITIES
The logo features the word "PRIORITIES" in bold, red, sans-serif capital letters.::>

<a id='76a2272f-289d-4e40-be81-6c0dedc1e8e7'></a>

The Strategy focuses on five themes that were identified as priorities during our consultations.

<a id='7b0d9912-d90f-459b-8aa0-ed78283e145c'></a>

<::A diagram with a central horizontal rectangular box labeled "INTERSECTIONAL LENS" in white text on a blue background. Four larger rectangular boxes with rounded corners and red borders surround the central box, arranged in a 2x2 grid. From top-left to bottom-right, they are labeled:
- SAFETY
- CHILDCARE
- HOUSING
- LEADERSHIP & REPRESENTATION
: diagram::>

<a id='d4517de0-712b-4768-9cd6-a27b39caaa8e'></a>

The four substantive areas (Safety, Housing, Childcare, and Leadership & Representation) are inextricably linked and work together to either enhance or harm women's full inclusion into the social and economic life of our city.

<a id='cefba766-e705-445c-9828-369157d2eabe'></a>

The Intersectional Lens describes a
process of ensuring that actions taken in
these substantive areas reflect the diverse
realities of all individuals, including women,
who are impacted by various forms of
discrimination.

<a id='86b184de-44c4-4a81-b2b9-62993bec2224'></a>

This Strategy recognizes that in order
to make measurable progress, we need
coordinated action on all substantive
areas
- informed by an intersectional lens
sustained over time and carried out in
partnership with other governments and
civil society.

<a id='1e66cb98-e668-4466-aced-a401b9e1e985'></a>

Action on these
would be dynamite.
- Public Survey, "Action for Women"

<a id='11f50557-1f22-468d-b9bc-af016578a9d0'></a>

15

<a id='8d1b1e42-7b89-40d8-9348-cd691826def7'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='8916ea51-c3cc-4159-96a1-173f5d02751b'></a>

<::A candid photograph shows two women in an indoor setting, possibly at a conference or event. The woman on the left, with blonde hair, is facing right and smiling slightly, her profile visible. The woman on the right, with dark hair, is facing left, looking at the other woman with an engaged expression. She is holding a blue pen in her right hand. Both women are wearing light blue t-shirts and lanyards around their necks. In the background, other people and blurred elements suggest a busy environment.: figure::>

<a id='f4f1326b-167f-4bc4-932b-642b5c7518f3'></a>

# STRATEGIES

During our research and consultations, it became clear that a number of different strategies will need to be employed across all actions for a successful outcome.

<a id='6a41bbf5-e387-4339-8eed-5e655cb3359d'></a>

Education and Awareness We will aim to bring awareness to the issues that impact all women with the goal of educating and influencing positive change.

<a id='48eafb4b-d3fa-4d5d-9b46-a71e715091ed'></a>

Policy The Strategy may require that we review, update, and align our policies to advance our objectives.

<a id='7493afdf-e33b-4732-9063-43672fed5cc3'></a>

Data In all of the priority areas, we need to start gathering relevant disaggregated data in order to measure progress.

<a id='974e7b93-6666-452b-b4c9-accfdacd43b5'></a>

🤝 Partnerships and Collaboration We will seek out opportunities to partner and collaborate on initiatives to make progress in the priority areas of this Strategy.

<a id='9637b34c-3b03-4bb5-9867-e27dd4bfb1fc'></a>

16

<a id='6efd4ab3-edce-4882-af51-d9e86ca3b77e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='cb33cc1f-9f4d-4780-a878-848a0c6d532f'></a>

PLAN FOR ACTION

<a id='0e587c34-a395-4cbc-a487-1659e367c436'></a>

## Long-term Vision
A 10-year plan, the Women's Equity Strategy builds upon the City's current work and initiatives to improve the lives of women in Vancouver.

<a id='3870b07d-cf3a-4acb-a4cb-0d9e14c74c28'></a>

This Strategy is being adopted in the context of a shifting provincial and federal landscape. New opportunities for partnerships are continuously emerging that could amplify the impact of the City's work in the priority areas in this Strategy. As just one example, Women Deliver 2019 is a global conference that will be held in Vancouver on the health, rights and well-being of women and girls.

<a id='011c696d-f59a-407d-b083-9d62a0b4b36a'></a>

In order to be responsive to these new opportunities, the Strategy focuses on a Phase 1 Actions for the first two years with stakeholder-recommended inputs for 2020-2028.

<a id='8dafc9f9-83f6-47b2-adef-e0cc7207435a'></a>

## Phase 1: 2018-2019

During Phase 1, the City will take specific and immediate actions to begin the implementation and lay the groundwork for future actions. The Phase 1 Actions are outlined for each Priority Area on the following pages.

<a id='3d1eb093-245e-4898-b7ee-ebb4c1db72e4'></a>

# Action Team: 2018-2028
The Action Team will be tasked with determining future actions based on the recommendations and best practice research (see ***Inputs for Future Consideration.***) The Action Team will consider the evolving provincial and federal landscape with respect to the priority themes and determine which inputs to implement on an ongoing basis. The Action Team will consult with the Women's Advisory Committee and other stakeholders as needed.

<a id='4c30c1b5-8002-4712-b4bf-5cd431d31d8d'></a>

# Key Success Factors

Accountability and sustainability are critical to the ongoing success of this Strategy. To that end:

* The Strategy is aligned under the overarching framework of the Healthy City Strategy.
* A business unit is identified to lead each Phase 1 Action.
* The Action Team will provide oversight and a coordinated approach over the life of the Strategy.
* The Strategy spans 10 years and is responsive to emerging opportunities and changes in the political and social contexts.

<a id='137b2acd-f5ab-409f-b20d-b5b451ea15c3'></a>

17

<a id='7374bd08-c8f3-4369-9b24-c8131932d487'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='14bdae04-090c-4029-846f-6ee1d557eaf7'></a>

PRIORITY:
INTERSECTIONAL LENS

<a id='c9fb14d4-83ba-4c91-b6f5-02e61971af48'></a>

## Goal
The City's decisions, programs, and plans are informed by an intersectional lens to ensure that all citizens have equitable access, inclusion and participation in community life.

<a id='cd6fbb47-6938-4df7-a9dd-8538446012e7'></a>

**Objective**
In 2018, an intersectional framework will be established for City departments.

<a id='c6432c66-d5a4-4b32-ac3a-79328030bb79'></a>

Strategies<::An icon of a lightbulb within a circle.: icon::>EDUCATION AND AWARENESS<::An icon of an open book within a circle.: icon::>POLICY

<a id='4ce581b8-c5b5-4322-9821-033e52f690a7'></a>

## What we're doing now

*   One of the Healthy City Strategy's goals and targets is the incorporation of an intersectional lens to monitor and understand the health and well-being of individuals and communities. The City is currently developing an intersectional lens to strengthen city processes and inform decision-making to better mitigate the impacts of interacting social contexts such as gender, race, class, and ability.

<a id='98f9b642-8bdc-4a51-88ba-b0b6f4dd2c0d'></a>

* The Civic Assets Naming committee is committed to naming new assets after under-represented groups and individuals. The Committee recently recommended names for eight lanes in the West End, half of which honour women: Helena Gutteridge, Kathleen (Kay) Stovold, Mary See-em-ia and Rosemary Brown.
* In 2017, Vancouver Board of Parks and Recreation named the park at Yukon and 17th Avenue after Lilian To, the former CEO of S.U.C.C.E.S.S.

<a id='e839ff46-796f-4480-b055-3e7d78206fe6'></a>

18

<a id='89156f8f-9764-4088-b1c3-c26917afcd19'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6b1408e5-a4bd-4a96-9997-7d3d01e1291c'></a>

<::A close-up side profile of a woman with a colorful hijab, smiling and clapping her hands. Her hijab features vibrant colors like pink, yellow, orange, and purple. She is wearing a dark teal or blue top. A gold ring is visible on her right hand as she claps. The background is blurred and dark.: figure::>

<a id='02aed090-6ebb-487a-9b87-a19eced78f56'></a>

Phase 1 Actions – Intersectional Lens
<table id="41-1">
<tr><td id="41-2">ACTIONS</td><td id="41-3">LEAD DEPARTMENT</td></tr>
<tr><td id="41-4">Pilot intersectional framework.</td><td id="41-5">Arts, Culture and Community Services</td></tr>
<tr><td id="41-6">Introduce the application of an intersectional lens to senior staff through training in Gender-Based Analysis Plus (GBA+) offered through Status of Women Canada.</td><td id="41-7">Human Resources</td></tr>
<tr><td id="41-8">Bring forward to Council revised Civic Assets Naming Guidelines that include gender diversity.</td><td id="41-9">City Clerk&#x27;s Department</td></tr>
</table>

<a id='3db83765-5d5e-41e8-b9a4-095076b9fe6d'></a>

**Inputs for Future Consideration – Intersectional Lens**

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in *Inputs for Future Consideration*. The Action Team will consider these over the life of the Strategy.

<a id='ee9d28f3-ea44-4114-9239-e94c3ab7262b'></a>

19

<a id='6ceb86d9-c019-4111-a917-a7352111f030'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='5c27ab7b-6bf2-4033-88c5-881b66a5e31e'></a>

PRIORITY:
WOMEN'S SAFETY

<a id='69435910-6d1d-4608-9477-e5e566d7c25a'></a>

Goal

Vancouver is a safe city in which women are secure and free from crime and violence, including sexual assault.

<a id='89ce6a18-8edd-4cea-b776-6d402c8611f3'></a>

**Objective**
By 2025, women's sense of safety will be increased by at least 10 per cent.

<a id='36d41097-109e-494d-b66b-04fca9a0d3e3'></a>

Strategies
<::icon of two hands shaking, encircled in a blue outline, with the text "PARTNERSHIPS AND COLLABORATION" below it: figure::>

<a id='8e4befa8-4d73-48be-bd87-bfb268c1d974'></a>

<::An icon of a lightbulb, with light rays emanating from it, all enclosed within a circular outline. The lightbulb is stylized with a 'Y' shape in the center, and the entire icon is rendered in blue outlines.
: figure::>
EDUCATION AND
AWARENESS

<a id='01ffdbed-bfa4-4a9c-8c9a-6aa3e4555b4f'></a>

<::icon of an open book inside a circle::>

POLICY

<a id='2e1763d0-606a-40cf-a21d-4536fad0385d'></a>

<::A blue line icon showing a bar chart inside a circle, with the word "DATA" in red capital letters below it.::>

<a id='f3f30898-8b05-42fd-9329-7de007ca755f'></a>

## What we're doing now
The following are highlights of the city's work to address safety issues and violence against women. For a more fulsome list, please see *Snapshots of City's Current Actions*.

<a id='b28029ec-a2eb-4102-9d10-442feb1b1345'></a>

* Our _Direct Social Services Grants_ include "Community Safety" as a priority. Grants are provided to outreach, support and referral services for women experiencing violence or marginalization and to programs aimed at preventing youth sexual exploitation and increasing access to sex worker safety. The City is also working with partners to expand services at the Downtown Eastside Women's Centre.
* We take a proactive approach to addressing the health and safety of sex workers and communities impacted by sex work.

<a id='f994418f-b89c-4b15-b0cf-2eb951233296'></a>

• We will provide a supportive healing space for women attending the *Missing and Murdered Indigenous Women and Girls Inquiry*.

• We consider community safety in the planning of public spaces, and use an inclusive approach to engage neighbourhoods, including efforts to reach out to women and all members of the community.

• We build awareness of women's safety within our workforce by including partner violence in our workplace safety policies and procedures, and by providing "Be More Than a Bystander" training to staff.

<a id='9a7331fc-5a80-40b7-a081-0436fd988988'></a>

20

<a id='f46e970f-6363-41c8-80c8-84a5aca3169b'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='91935716-0033-4047-a1cf-083b21c00fba'></a>

<::A close-up shot of two women engaged in conversation. The woman on the left has long, light brown hair with bangs, is wearing a light blue shirt with a silver pendant necklace, and a gray cardigan. She is looking towards the right. The woman on the right has short, dark gray hair, is seen from her right profile, and is wearing a gray jacket over a dark shirt with white polka dots. The background is blurred, suggesting an indoor setting.: figure::>

<a id='9e9545eb-e0e0-4e14-b2ec-0f81c844074e'></a>

Phase 1 Actions - Women's Safety
<table id="43-1">
<tr><td id="43-2">ACTIONS</td><td id="43-3">LEAD DEPARTMENT</td></tr>
<tr><td id="43-4">Join UN Women&#x27;s Global Flagship Initiative, &quot;Safe Cities and Safe Public Spaces&quot; and conduct a scoping study on women&#x27;s safety.</td><td id="43-5">Arts, Culture and Community Services</td></tr>
<tr><td id="43-6">Identify community partners and collaborate on an annual public campaign to raise awareness on violence against women.</td><td id="43-7">Corporate Communications and Human Resources</td></tr>
<tr><td id="43-8">Update the Women&#x27;s Advisory Committee annually on progress in ensuring women&#x27;s safety and needs in the neighbourhood planning and development process.</td><td id="43-9">Planning, Urban Design &amp; Sustainability, and Engineering Services</td></tr>
<tr><td id="43-a">Formalize senior staff coordination and oversight of inter-departmental response to critical issues in the Downtown Eastside, including women&#x27;s safety and related issues.</td><td id="43-b">City Manager&#x27;s Office</td></tr>
</table>

<a id='0e56a8b3-75a7-4562-ba14-1cb1c7109347'></a>

## Inputs for Future Consideration – Women's Safety

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in _Inputs for Future Consideration_. The Action Team will consider these over the life of the Strategy.

<a id='f0cc76b7-8cc0-42fc-97c5-a85621dbd061'></a>

21

<a id='333766c2-59ec-4230-86b1-5e989ce6876f'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='0368772d-3f85-4870-afe9-bc20325f536a'></a>

PRIORITY: CHILDCARE

<a id='0267b867-f2e0-4510-8f2e-57f3173f2fb1'></a>

Goal
Women's full participation in the workforce and engagement in public life is supported by affordable and accessible quality childcare for children.

<a id='6aa26327-2990-4bd3-b033-64967184ee5a'></a>

Objective
By the end of 2018, 1,000 new childcare spaces will be added from the 2015 baseline.
(Aligns with current childcare target identified in the Healthy City Action Plan, 2015-2018)

<a id='5c787b58-18bd-4d1d-bac1-1453f3d3b9be'></a>

<::logo: [Unknown] Strategies
PARTNERSHIPS AND
COLLABORATION
A blue circular outline encloses a stylized handshake icon.::>

<a id='fc77f498-5282-4f05-ac2a-adbb8d5f39e0'></a>

<::logo: [Unidentifiable]EDUCATION AND AWARENESSA blue outline of a lightbulb is centered above the text, enclosed within a blue circular outline.::>

<a id='da958d27-1381-4354-9fa6-80e88630076f'></a>

<::An icon showing an open book within a circle, labeled below as "POLICY".: figure::>

<a id='f05b94b8-992e-4b9e-b46c-f210ab9bee35'></a>

## What we're doing now

The following are examples of some of the programs and investments aimed at maintaining existing childcare facilities and increasing the supply of childcare. For a more fulsome list, please see **Snapshots of City's Current Actions**.

*   The Capital Plan for 2015-2018 includes an investment of $30 million for childcare.
*   In 2017 the allocation of revenue from Development Cost Levies towards childcare has been increased from 5 per cent to 13 per cent.
*   The City charges nominal rents to 57 non-profit childcare centres located in City and Park Board facilities, supporting over 2,400 childcare spaces.
*   Several City grants support, enhance, and help to create new quality affordable childcare spaces.
*   We are currently developing an updated childcare strategy. The strategy will:
    *   Refresh policies, principles and goals to reflect current contexts.
    *   Review operator selection criteria for City-owned childcare facilities, to be offered to non-profit operators at nominal rents.
    *   Explore the hub model of integrated child and family services.
*   City Council passed a motion in support of the Community Plan for a Public System of Integrated Early Care and Learning (the $10/day Child Care Plan).
*   We partnered with the Vancouver Board of Education to help create 466 school-age childcare spaces in existing school space.

<a id='75929f3a-1c35-447d-a8d5-8af48a4c6dee'></a>

22

<a id='0fef2c5b-0c64-4422-bc42-390f9617185a'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='1b83bda7-15ff-4e74-9926-8df78214a49d'></a>

<::A young girl with curly hair and an adult woman with curly, lighter-colored hair are giving each other a high-five. The girl is smiling broadly and appears happy. In the foreground, there are colorful building blocks, suggesting a playful or educational setting.: figure::>

<a id='c405ee80-81e4-46ff-a4e9-9a01bb5ed05d'></a>

Phase 1 Actions - Childcare
<table id="45-1">
<tr><td id="45-2">ACTIONS</td><td id="45-3">LEAD DEPARTMENT</td></tr>
<tr><td id="45-4">Share input from the Women&#x27;s Equity Strategy consultations for consideration in the City&#x27;s updated childcare strategy.</td><td id="45-5">Human Resources</td></tr>
<tr><td id="45-6">Partner with senior levels of government to significantly increase affordable, quality childcare through creating new childcare spaces, and replacing aging centres.</td><td id="45-7">Arts, Culture and Community Services</td></tr>
<tr><td id="45-8">Identify child-friendly provisions to accommodate participation by families with children at Council and Public Hearings at City Hall.</td><td id="45-9">City Clerk&#x27;s Department</td></tr>
</table>

<a id='ffa7afbe-7c90-438d-82f9-340f51eb2cc6'></a>

Inputs for Future Consideration – Childcare
All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in _Inputs for Future Consideration_. The Action Team will consider these over the life of the Strategy.

<a id='3897f2dd-a5c3-4340-a0ee-1d7a41edbeee'></a>

23

<a id='3b276215-1bc2-412b-84ba-203b75ea6a9f'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='55585a9f-e03b-4b65-9b43-012ea94bd641'></a>

# PRIORITY: HOUSING

## Goal

A range of affordable housing choices is available for women of diverse backgrounds and circumstances, including single parents, seniors, newcomers, and those facing vulnerable conditions.

<a id='0c4085ac-d85f-4aa1-968f-276de9594990'></a>

## Objective
72,000 new homes across Vancouver in the next 10 years.

<a id='4597571f-349f-4831-b667-c9634d78d4c7'></a>

Strategies

<::line art icon of two hands shaking, labeled "PARTNERSHIPS AND COLLABORATION": icon::>

<a id='9f0fcffb-e6f1-4a2e-9862-8709cda92f8a'></a>

<::A blue outline icon of a lightbulb with rays emanating from it, all enclosed within a blue outline circle. Below the icon, in bold red capital letters, is the text "EDUCATION AND AWARENESS".: figure::>

<a id='120849dc-2c9e-4bdd-94e0-8d856365d7f2'></a>

<::A blue icon showing a bar chart within a circle.: figure::>

DATA 

<a id='29bac778-7f51-48e2-af82-4029ca4ece26'></a>

## What we're doing now

The following are examples of efforts we're making to address housing affordability
and availability in Vancouver. For a more fulsome list, please see **Snapshots of City's
Current Actions.**

<a id='22b44f3a-2b0b-4929-8d61-a693fe2ca69b'></a>

Through the **Housing Vancouver Strategy** we have set goals to create 12,000 social, supportive and non-profit co-operative homes, including 6,800 new homes for households with incomes below $30,000 per year. At least half of all new housing in the next 10 years will be for renters and 40 per cent of new homes will be large enough for families.

<a id='69aaa5cf-1e2c-448e-bba5-ed94e880f6fa'></a>

We have a variety of programs to support renters and affordable rentals, including
_<u>Rental 100</u>_, _<u>Empty Homes Tax</u>_, _<u>Rental Housing Stock Official Development Plan</u>_, _<u>Rental Standards Database</u>_, _<u>Laneway Housing</u>_, and the _<u>Vancouver Rent Bank</u>_.

<a id='f241028e-d3c9-45f0-afe8-4c7379e94498'></a>

We have created a requirement that all
rezoning development applications include
a minimum of 35 per cent family units (two
and three bedroom units).

<a id='1726c8d0-b3a0-41e7-811a-a3501600b944'></a>

We work collaboratively with provincial and non-profit housing partners to support the delivery of housing for women and families through grants and provision of land for social housing.

<a id='feadf160-a802-4ad8-a9e4-5fee67c1f885'></a>

Through grants, partnerships, and direct
outreach, we provide homeless and
under-housed residents with shelter, free
or low-cost food, and other services and
resources.

<a id='9c178c76-be3c-4380-bfe7-2d3acbec9221'></a>

24

<a id='112eee46-745d-40f8-8788-9cbb68e2b201'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='37ce597e-d846-4881-803f-998a0638dc5c'></a>

<::Two elderly women are seated at a table, smiling and eating soup and salad. The woman on the left has curly brown hair and is wearing a patterned blue and green top. The woman on the right has white hair, glasses, and is wearing a purple jacket over a pink top. They both appear to be enjoying their meal. In the background, other tables with red tablecloths and chairs are visible, along with another person in the far background.: figure::>

<a id='7a5c003b-1bc7-4507-b45a-6710d617e738'></a>

Phase 1 Actions - Housing
<table id="47-1">
<tr><td id="47-2">ACTIONS</td><td id="47-3">LEAD DEPARTMENT</td></tr>
<tr><td id="47-4">Identify how to determine the extent of women&#x27;s hidden homelessness to better understand its full scope.</td><td id="47-5">Arts, Culture and Community Services</td></tr>
<tr><td id="47-6">Research integration of outreach role within Coordinated Access Centre to liaise with women-serving organizations and identify women in need of priority housing.</td><td id="47-7">Arts, Culture and Community Services</td></tr>
<tr><td id="47-8">Share input from the Women&#x27;s Equity Strategy consultations for consideration in the implementation of the Housing Vancouver Strategy.</td><td id="47-9">Human Resources</td></tr>
</table>

<a id='9b8deb57-8ab5-4ae2-b5be-e809e3bbbb87'></a>

## Inputs for Future Consideration – Housing

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in **Inputs for Future Consideration**. The Action Team will consider these over the life of the Strategy.

<a id='a940aeb6-fed2-4916-8b97-9755135f93ae'></a>

25

<a id='fc03bc15-3e33-4010-804b-c34633a1fb85'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='09b93af0-6a78-4ce9-8da1-6b26f73ef9a3'></a>

PRIORITY: LEADERSHIP &
REPRESENTATION

<a id='ffa05b78-693d-4e0c-baee-ddfc0d571ffd'></a>

# Goal
The City will elevate the visibility, influence, representation and contribution of all women in the organization by providing equitable access to work opportunities, including leadership roles and other under-represented occupations* and by creating and implementing initiatives to specifically enhance their development and leadership.

<a id='d919bf22-6307-41b8-9bba-a8bb20ee4f71'></a>

# Objectives

*   Effective immediately, the City will increase new hires for Senior Management roles to 50 per cent women.
*   By 2020, the proportion of female new hires in under-represented occupations will be increased by at least 5 per cent over the 2017 baseline.

<a id='00dbd475-db34-4b5e-a1a7-a8927f83d588'></a>

Strategies<::An icon of two hands shaking, enclosed within a circle.: icon::>PARTNERSHIPS ANDCOLLABORATION

<a id='04570b4c-9409-4de3-87d0-af523752aa4f'></a>

<::lightbulb icon : figure::>
EDUCATION AND
AWARENESS

<a id='ce8cb0b0-1c7c-4181-8871-1e251b80b173'></a>

<::Two icons. The first icon shows an open book inside a blue circle, with the label POLICY below it. The second icon shows a bar chart inside a blue circle, with the label DATA below it.: figure::>

<a id='3f56f1c3-f2ff-486c-9455-ec6cfc29051c'></a>

**What we're doing now**

The following are examples of some of the programs and initiatives aimed at improving the diversity and inclusion of the City's workforce. For a more fulsome list, please see *Snapshots of City's Current Actions*.

<a id='0217fa21-1261-48c2-b263-8ee695bf216e'></a>

- We are proud to be a certified Living Wage Employer.
- Departments are actively working towards increasing workforce diversity, including the representation of women. A few examples of this include:

<a id='475379d5-2b07-46b8-9a9e-7c5b44156f16'></a>

- Engineering Services has a Diversity& Inclusion Working Group taskedwith increasing the representationand retention of a diverse staffthat represents our community.Engineering Services increased therepresentation of women on its SeniorExecutive team from 0% in 2010 to50% in 2017.

<a id='1f45669d-30af-45ed-8429-12a2fd942a8a'></a>

* Examples of under-represented occupations include Information Technology (technical positions), Firefighting, Trades and Operations, Engineers and Engineers-in-Training.

<a id='d41be6e3-3f9f-4ef9-83cd-48807b380ab9'></a>

26

<a id='518b6a7e-4da2-4743-b26f-1cbdeeff5b51'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='04c606f0-b8b7-4265-b66e-bb83655a0501'></a>

- Vancouver Fire and Rescue Services conducts targeted recruitment drives and runs Camp Ignite, a youth mentorship program for girls in grades 11 and 12.
- Human Resources develops and delivers programs that address barriers to women's full inclusion such as a tele-mobility pilot, leadership development opportunities, and one-on-one leadership coaching. We proactively address human rights issues, workplace harassment and support respectful workplaces.

<a id='96d134fe-09e6-4075-98ba-350962d3dd23'></a>

- Vancouver Board of Parks and Recreation is leading focus groups with female staff in leadership and operations in order to make improvements in the workplace.
* We work with partners to advance women's leadership and representation including:
  - Participating in research projects with partners like McKinsey Global Institute and the Conference Board of Canada.
  - We are in discussions with Women Transforming Cities about participating in a three-year study, "Action on Systemic Barriers to Women's Participation in Local Government".

<a id='3e139c79-f546-4c36-9833-1fdb1c84ea43'></a>

Phase 1 Actions - Leadership & Representation
<table id="49-1">
<tr><td id="49-2">ACTIONS</td><td id="49-3">LEAD DEPARTMENT</td></tr>
<tr><td id="49-4">Sign Minerva BC&#x27;s Face of Leadership™ Diversity Pledge, making a public commitment to support women&#x27;s advancement in leadership in our workforce and in our community.</td><td id="49-5">Human Resources</td></tr>
<tr><td id="49-6">Develop and implement a Breastfeeding Policy for City staff.</td><td id="49-7">Human Resources</td></tr>
<tr><td id="49-8">Conduct focus groups with female staff in leadership and under-represented positions.</td><td id="49-9">Human Resources</td></tr>
<tr><td id="49-a">Measure and publicly report annually on the City&#x27;s workforce composition including positions and compensation.</td><td id="49-b">Human Resources</td></tr>
<tr><td id="49-c">Address potential bias in hiring process by training recruitment staff to recognize and mitigate unconscious bias.</td><td id="49-d">Human Resources</td></tr>
</table>

<a id='9058b974-0a0f-46f0-853e-7ef05be7177d'></a>

## Inputs for Future Consideration – Leadership & Representation

All of the stakeholder input that is within the jurisdiction of the City of Vancouver to carry out, or to influence, has been included in *Inputs for Future Consideration*. The Action Team will consider these over the life of the Strategy.

<a id='5784e34d-008c-4915-89e1-08d21ffbef10'></a>

27

<a id='35fc0a0b-ad45-4898-b91d-eb5ced3bf77f'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='42e21668-ea81-4159-885c-a98bd387f7d5'></a>

<::A woman with dark hair styled in a braid and wearing glasses, a grey long-sleeved top, and a patterned tunic top is speaking into a microphone, holding it with her right hand and gesturing with her left hand. She is standing in what appears to be a conference or workshop room. In the background, several people are seated at tables, some looking towards the speaker, and various items like water bottles, papers, and what look like presentation boards or posters are visible. The overall setting suggests an interactive discussion or presentation.: photo::>

<a id='84cbf00c-1081-4d33-832b-0345fc3231d3'></a>

ACCOUNTABILITY

<a id='349a4e6a-af0a-48f7-a9d3-d438da3cc123'></a>

All of the priority actions have an identified lead department responsible for the implementation of that action.

<a id='0eed19e9-65ed-4b8c-bbbf-67b888208022'></a>

The Action Team has overall responsibility for the Strategy and for ensuring that actions are completed and progress towards goals is measured over time.

<a id='1ea6e6e2-d8b0-449f-b4ca-de1523def8b1'></a>

The Action Team will continue to consult with the Women's Advisory Committee and, as needed, with stakeholders throughout the life of this Strategy.

<a id='89cfb96f-de29-4cfc-a20f-6309bea9f2e8'></a>

A progress report will be provided to Council in 2019, outlining achievements to date and next steps.

<a id='52a42651-8ee1-46d1-aeac-a23e9c78ed48'></a>

28

<a id='26813f5f-5b12-4f5a-8872-1e175e0b89d0'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='4cfa04bc-921c-43b4-b8ca-927584363013'></a>

# ACKNOWLEDGEMENTS
The development of this Strategy took place on the unceded traditional territories of the Musqueam, Squamish and Tsleil-Waututh Nations.

<a id='2dbb42e6-c1c7-4109-8448-4d216e86aac5'></a>

We are grateful to all of the members of the Women's Advisory Committee, including
Liaisons and recent past members, for their hard work and input throughout the
development of this Strategy.

<a id='796fbf8d-7968-4b77-9b91-6d023bb39c91'></a>

_Women's Advisory Committee_
* Miranda Mandarino, Chair
* Erin Arnold
* Terran Bell, Chair,
  Sub-Committee - Young Women
* Mebrat Beyene
* Desaraigh Byers
* Andrea Canales Figueroa
* Lindsay Clark, Chair, Sub-Committee
  Economic Equality and Opportunity for
  Women and Girls
* Missy Johnson
* Sharon Lau
* Fiona McFarlane
* Rebecca McNeil, Chair, Sub-Committee
  Awareness, Accessibility, Inclusivity, and
  Diversity
* Najmah Mohammed
* Christine O'Fallon, Chair,
  Sub-Committees - Ending Violence
  Against Women and Girls and
  Equity Strategy Implementation and
  Intersectionality/Gender Mainstreaming
* Miriam Palacios
* Paola Quiros
* Shirley Ross
* Margot Sangster
* Niki Sharma
* Rhonda Sherwood, Chair,
  Sub-Committee -
  Leadership & Representation
* Andrea Thompson
* Julie Wong
* Deb Gale, Staff Liaison
* Councillor Andrea Reimer,
  Council Liaison
* Councillor Elizabeth Ball, Council Liaison
* Commissioner Catherine Evans,
  Park Board Liaison

<a id='8d93f704-80db-441f-a547-0a34447b316e'></a>

Special acknowledgment goes to former City Councillors Ellen Woodsworth and Anne Roberts who championed the City's 2005 Gender Equality Strategy. Ellen Woodsworth, founder of Women Transforming Cities, has been a consistent, persistent and powerful advocate on the full inclusion of women and girls in our cities. We are grateful for the time, expertise, and input that both Ellen and her team have provided during the development of this Strategy.

<a id='3484048d-f5aa-4ae3-9146-6757ebfb03e5'></a>

We are also grateful to the following individuals and organizations, whose expertise and experiences informed the development of this Strategy.

* BC Non-Profit Housing Association
* BC Society of Transition Houses
* Battered Women's Support Services
* City for All Women Initiative
* City of Ottawa
* City of Edmonton
* City of Calgary
* Downtown Eastside Women's Centre
* Ending Violence Association (EVA BC)
* Living in Community

<a id='1694c194-9580-4ff8-9028-1aefc74f6521'></a>

29

<a id='a15004f3-677e-4abb-9bfc-53f7d3fd1d58'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='44268179-124c-4c53-93d0-dafd37b9ed1e'></a>

* Manitoba Status of Women
* Margot Young, Professor, Allard School of Law, University of British Columbia
* RainCity Housing and Support Society
* The Minerva Foundation for BC Women

<a id='9b163626-1a58-4901-a6db-f7ae36a53ac1'></a>

* WISH Drop-In Centre Society
* Women Against Violence Against Women (WAVAW)
* Women Transforming Cities
* YWCA Metro Vancouver

<a id='d1202d5e-db70-463a-a3e8-a7e6fd59d3b8'></a>

We also acknowledge the contributions of the City Leadership Team and our staff, who provided assistance and input during the development of the Strategy:

<a id='2afd13b3-2e41-482e-b259-6762c758b04e'></a>

City Leadership Team:
Sadhu Johnston, City Manager
Paul Mochrie, Deputy City Manager
Bill Aujla, General Manager, Real Estate and Facilities Management
Malcolm Bromley, General Manager, Park Board
Francie Connell, Director of Legal Services and City Solicitor
Jerry Dobrovolny, General Manager, Engineering Services
Patrice Impey, General Manager, Finance, Risk and Supply Chain Management
Gil Kelley, General Manager, Planning, Urban Design and Sustainability
Rena Kendall-Craden, Director, Corporate Communications
Kaye Krishna, General Manager, Development, Buildings and Licensing
Kathleen Llewellyn-Thomas, General Manager, Arts, Culture and Community Services
Andrew Naklicki, Chief Human Resources Officer
Adam Palmer, Chief Constable, Vancouver Police Department
Darrel Reid, Fire Chief and General Manager, Vancouver Fire & Rescue Services
Sandra Singh, City Librarian, Vancouver Public Library

<a id='f374965f-8bce-45f0-96f8-5fb469795417'></a>

Staff:
Therese Boullard, Superintendent Martin Bruce, Cathy Buckham, Heather Burpee,
Brian Butt, Lesley Campbell, Edna Cho, Deputy Sergeant Howard Chow, Gracen Chungath,
Keltie Craig, Alison Dunnet, Superintendent Marcie Flamand, Sue Goddard,
Heather Gordon, Ginger Gosnell-Myers, Yvonne Hii, Kathryn Holm, Dianna Hurford,
Kira Hutchinson, Vanessa Kay, Katrina Leckovic, Janice Mackenzie, Drazen Manojlovic,
Kiran Marohn, Christina Medland, Ty Mistry, Inspector Suzanne Muir, Cheryl Nelms,
Anne Nickerson, Howard Normann, Kelly Oehlschlager, Michele Pankratz, Randy Pecarski,
Lisa Prescott, Staff Sergeant Dawn Richards, Taryn Scollard, Rena Soutar, Art Stuivenberg,
Cheryl Williams, Shauna Wilton, Carol Ann Young, MaryClare Zak, Shannen Zaturecky

<a id='2663344a-3485-4344-a633-76828d760cbe'></a>

In addition to the organizations and individuals listed above, we reached out to the City's Advisory Committees (Type 'A') and the following organizations, inviting them to provide input through the survey, the public forum, and through direct contact with City staff.

<a id='3a8002dd-179d-4d87-9040-2c97bc36dcfa'></a>

30

<a id='ce6468ef-b0dc-4fec-ad52-6608ba42a250'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='3a97b99d-4931-499a-b25b-14c47104a985'></a>

<table id="53-1">
<tr><td id="53-2">Aboriginal Mother Centre Society</td><td id="53-3">Philippine Women Centre of BC</td></tr>
<tr><td id="53-4">Association of Neighbourhood Houses BC</td><td id="53-5">Positive Women&#x27;s Network</td></tr>
<tr><td id="53-6">Atira Women&#x27;s Resource Society</td><td id="53-7">ProMotion Plus</td></tr>
<tr><td id="53-8">Aunt Leah&#x27;s Independent Lifeskills Society</td><td id="53-9">Providing Alternatives, Counselling &amp; Education (PACE) Society</td></tr>
<tr><td id="53-a">BC Federation of Labour</td><td id="53-b">Qmunity</td></tr>
<tr><td id="53-c">BC Housing</td><td id="53-d">UBC Centre for Race, Autobiography, Gender and Age studies (RAGA)</td></tr>
<tr><td id="53-e">BC Poverty Reduction Coalition</td><td id="53-f">Ray-Cam Cooperative</td></tr>
<tr><td id="53-g">BC Public Interest Advocacy Centre</td><td id="53-h">Rise Women&#x27;s Legal Centre</td></tr>
<tr><td id="53-i">Big Sisters of BC Lower Mainland</td><td id="53-j">Simon Fraser University Women&#x27;s Centre</td></tr>
<tr><td id="53-k">Black Lives Matter Vancouver</td><td id="53-l">Single Mothers Alliance</td></tr>
<tr><td id="53-m">Boys and Girls Clubs of South Coast BC</td><td id="53-n">Society for Canadian Women in Science and Technology</td></tr>
<tr><td id="53-o">Canadian Centre for Policy Alternatives - BC Office</td><td id="53-p">The Society for Children and Youth BC</td></tr>
<tr><td id="53-q">Canadian Federation of University Women BC Council</td><td id="53-r">South Vancouver Neighbourhood Housing</td></tr>
<tr><td id="53-s">CityReach Care Society</td><td id="53-t">Squamish Nation</td></tr>
<tr><td id="53-u">Coalition of Child Care Advocates of BC</td><td id="53-v">S.U.C.C.E.S.S.</td></tr>
<tr><td id="53-w">Cooperative Housing Federation of BC</td><td id="53-x">Supporting Women&#x27;s Alternatives Network (SWAN) Vancouver Society</td></tr>
<tr><td id="53-y">Disability Alliance BC</td><td id="53-z">The Kettle Society</td></tr>
<tr><td id="53-A">DTES Sex Workers United Against Violence Society (SWUAV)</td><td id="53-B">The University Women&#x27;s Club of Vancouver at Hycroft</td></tr>
<tr><td id="53-C">Elizabeth Fry Society of Greater Vancouver</td><td id="53-D">Tradeworks Training Society</td></tr>
<tr><td id="53-E">Entre Nous Femmes Housing Society</td><td id="53-F">Tsleil-Waututh Nation</td></tr>
<tr><td id="53-G">Feminist Research Education Development Action (FREDA) Centre for Research on Violence Against Women and Children</td><td id="53-H">UBC Women&#x27;s Centre</td></tr>
<tr><td id="53-I">First Call: BC Child and Youth Advocacy Coalition</td><td id="53-J">Urban Native Youth Association</td></tr>
<tr><td id="53-K">Immigrant Services Society</td><td id="53-L">Vancouver Aboriginal Community Policing Centre Society</td></tr>
<tr><td id="53-M">Jewish Family Services Agency</td><td id="53-N">Vancouver Aboriginal Friendship Society</td></tr>
<tr><td id="53-O">Justice for Girls</td><td id="53-P">Vancouver Native Health Society</td></tr>
<tr><td id="53-Q">Kiwassa Neighbourhood House</td><td id="53-R">Vancouver Native Housing Society</td></tr>
<tr><td id="53-S">Mavis McMullen Housing Society</td><td id="53-T">Vancouver Status of Women</td></tr>
<tr><td id="53-U">Mom2Mom Child Poverty Initiative Society</td><td id="53-V">Vancouver Women&#x27;s Health Collective</td></tr>
<tr><td id="53-W">MOSAIC BC</td><td id="53-X">VAST</td></tr>
<tr><td id="53-Y">Mount Pleasant Neighbourhood House</td><td id="53-Z">West Coast LEAF (Legal Education and Action Fund)</td></tr>
<tr><td id="53-10">Musqueam Nation</td><td id="53-11">West Coast Mental Health Network Society</td></tr>
<tr><td id="53-12">Pacific Community Resource Society (Broadway Youth Resource Centre)</td><td id="53-13">Westcoast Child Care Resource Centre</td></tr>
<tr><td id="53-14">Pacific Immigrant Resource Society</td><td id="53-15">Women&#x27;s Enterprise Centre</td></tr>
</table>

<a id='dcdd44e4-e3ad-4495-b9a8-340369891e57'></a>

31

<a id='5d26e2ce-e927-4042-b136-dbc2b3c9c2b8'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='723177bf-2df4-47b0-8f4e-27e9e2e00437'></a>

<::logo: [ENDNOTES]
ENDNOTES
The logo features the word "ENDNOTES" in bold, red, sans-serif capital letters.::>

<a id='82ca1bb7-68bb-46a0-b19f-144f099e65d2'></a>

1 Statistics Canada, Census Profile 2016 Catalogue no. 98-316-X2016001, Ottawa, Released August 2, 2017
2 Ivanova, Iglika and Klein, Seth, Working for a Living Wage, Canadian Centre for Policy Alternatives, April 2016
3 Statistics Canada Census Profile 2016 Catalogue no. 98-316-X2016001, Ottawa, Released August 2, 2017
4 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
5 Ibid.
6 Fact Sheet, BC Minimum Wage and Women, BC Federation of Labour, (online) http://bcfed.ca/sites/ default/files/attachments/BCFED%20minimum%20 wage%20fact%20sheet%20-%20women.pdf
7 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
8 Statistics Canada, Table 111-0019, Characteristics of individuals, taxfilers and dependents 15 years of age and over receiving employment insurance by age groups and sex, annual (number) (accessed: September 28, 2017)
9 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
10 Ibid.
11 Zhang, Xuelin, Statistics Canada, Catalogue no. 75-001-X, Perspectives, March 2009
12 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
13 Milan et al, Families, Living Arrangements and Unpaid Work, Component of Statistics Canada Catalogue no. 89-503-X, Women in Canada: A Gender-based Statistical Report, December 2011
14 Moyser, Melissa, Women and Paid Work, Women in Canada: A Gender-based Statistical Report, Statistics Canada, March 2017
15 Statistics Canada. Census Profile 2016 Catalogue no. 98-316-X2016001. Ottawa. Released August 2, 2017
16 Ministry of Social Development and Poverty Reduction, BC Government, News Release, September 1, 2015, (online) https://news.gov.bc.ca/releases/2015SDS10043-001405
17 Sinha, Maire, Family violence in Canada: A Statistical Profile, 2011, Component of Statistics Canada catalogue no 85-002-x, Juristat, XCanadian Centre for Justice Statistics, June 25, 2011
18 McLean, Gladys and Gonzalez Bocinski, Sarah, The Economic Cost of Intimate Partner Violence, Sexual Assault, and Stalking, Institute for Women's Policy Research, August 2017
19 McInturff, Kate, The Gap in the Gender Gap: Violence against women in Canada, Canadian Centre for Policy Alternatives, July 2013

<a id='666818d1-d5a8-4be1-843d-91b5fd3c7b56'></a>

20 Samuel Perreault, Criminal Victimization in Canada, Statistics Canada Catalogue, no. 85-002-X, Juristat, Canadian Centre for Justice Statistics, November 23, 2015
21 Hutchins, Hope, and Sinha, Maire, Measuring Violence Against Women: Statistical Trends, Statistics Canada, Catalogue 85-002-X, Juristat, February 25, 2013
22 My Health My Community Survey. Data as of August 14, 2014. Prepared by: Vancouver Coastal Health, Public Health Surveillance Unit, July 2017
23 Ibid.
24 The Power of Parity: Advancing Women's Equality in Canada, McKinsey Global Institute, June 2017
25 Perreault, Samuel, Criminal victimization in Canada 2014, Statistics Canada Catalogue no. 85-002-X, November 23, 2015
26 Ibid.
27 Ibid.
28 Arriagada, Paula, Women in Canada: A Gender-based Statistical report, First Nations, Métis and Inuit Women, Statistics Canada, Catalogue no 89-503-X, February 23, 2016
29 Ibid.
30 Burlock, Amanda, Women in Canada: A Gender-Based Statistical Report, Women with Disabilities, Catalogue no. 89-503-X, May 29, 2017
31 Ibid.
32 Ibid.
33 Ibid.
34 Women with Disabilities in Canada, Report to the Committee on the Rights of Persons with Disabilities on the Occasion of the Committee's Initial Review of Canada, Canadian Feminist Alliance for International Action (FAFIA) and Disabled Women's Action Network (DAWN Canada), February 2017
35 "Still 1 in 5: BC Child Poverty Report Card Executive Summary", First Call BC, 2016.
36 Ibid.
37 Ibid.
38 Sinha, Maire, Family violence in Canada: A statistical profile, 2010, Statistics Canada, Juristat, Catalogue no. 85-002-X, May 22, 2012
39 McInturff, Kate, The Gap in the Gender Gap, Violence Against Women, Canadian Centre for Policy Alternatives, July 2013
40 The Power of Parity: Advancing Women's Equality in Canada, McKinsey Global Institute, June 2017
41 Momani, Bessma and Stirk, Jillian, Diversity Dividend: Canada's Global Advantage, Special Report, Centre for International Governance Innovation and Fondation Pierre Elliot Trudeau Foundation, 2017

<a id='5d89d6da-e851-4a48-8f7d-82a5407ece17'></a>

32

<a id='bc77eda0-6a9a-4bcc-9732-563f1c2ac986'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='455655c6-441f-43eb-aaa0-41e246f7f76e'></a>

<::A photo shows three young women standing together and smiling. The woman in the center, with light brown hair, is wearing a red t-shirt with the text "CITY VANCOUVER LIFEGUARD PARKS AND RECREATION" in a circular logo. She has a silver necklace with a small pendant. Her right arm is around the shoulder of the woman to her left, who has dark hair with reddish streaks and is wearing a white turtleneck sweater with a black strap across her chest, featuring a small circular badge. The center woman's left arm is around the shoulder of the woman to her right, who has dark hair and is wearing a black hooded sweatshirt with "POLO SE CO." printed in white on the front. The background is slightly out of focus, showing green trees and some buildings under a light sky.: figure::>

<a id='99eaa09e-f87d-46d8-8115-8ceb6a8ebe2d'></a>

<::A circular black logo on a red t-shirt. The logo contains:
- Top arc text: CITY VANCOUVER
- Central large text: LIFEGUARD
- Bottom arc text: PARKS AND RECREATION
- A crest/shield graphic above "LIFEGUARD"
- A lifebuoy and crossed oars graphic below "LIFEGUARD"
: figure::>

<a id='2960af5d-7062-44b8-a0bc-87de9727cc62'></a>

POLO SE
CO.

<a id='c204d5cf-2d6d-439e-a850-417b2c83aebe'></a>

33

<a id='ee943f42-6668-49ba-a127-7210ed8e4a00'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='2d5af8fb-8b40-4e13-877c-14d73794bd2b'></a>

SNAPSHOTS OF CITY'S
CURRENT ACTIONS

<a id='eb367068-7502-421f-b933-129bc2697b2e'></a>

<u>**PRIORITY: WOMEN'S SAFETY**</u>

<a id='4d93e3a9-771a-4aac-8c05-c1e32403043d'></a>

Arts, Culture and Community Services

**Healthy City Strategy** The Strategy includes the goal of "being and feeling safe and included" with targets to increase Vancouver residents' sense of safety by 10 per cent, and make Vancouver the safest major city in Canada by reducing violent crime, including sexual assault and domestic violence.

*   Action 9 in the 2015-2018 Action Plan includes development and delivery of broad-based training to enhance capacity when addressing conditions particularly trauma, that create vulnerability (including gendered violence and sex work).

<a id='a5f0e8ec-4fe2-454e-bb42-a45f31f64002'></a>

***Direct Social Services Grants*** The grants include "Community Safety" as a priority and grant applicants are requested to specify how their programs ensure gender equity. The grants fund projects and programs to increase community safety including:
* outreach, supports and referrals to services for women experiencing violence or marginalization;
* projects aimed at preventing youth sexual exploitation;
* programs that increase access to safety and supports for sex workers; and,
* initiatives that create a safe city in which residents feel secure.

<a id='7bdfd6ca-51da-49a4-9796-395108c134fd'></a>

_Sex Work Response Guidelines_
The Guidelines promote consistent,
nondiscriminatory, and respectful treatment
of anyone engaged in sex work when
accessing City services or interacting with
City employees.

<a id='5c27d9fb-c09f-4460-9b02-8fecce162de9'></a>

_Missing and Murdered Indigenous Women_
_and Girls Inquiry_ The City will provide
supportive healing space for women
attending and participating in the Inquiry.

<a id='9c2d305e-9386-464f-a5a2-e1381329b3d3'></a>

**Downtown Eastside Women's Centre (DEWC) – 24 hour drop-in** The City has been working collaboratively with funding partners to expand DEWC's operating hours to fill a gap in daytime services, including housing outreach, counselling, women-centred health care and prepared meals. In October 2017, Council approved a one-time Capital Grant of up to $250,000 towards renovations for the shelter in partnership with BC Housing.

<a id='fe6b180c-59bc-41b6-b469-731b1c5c0a8e'></a>

### Planning, Urban Design and Sustainability
Ensures safety is a key consideration in community planning:

*   Applies Crime Prevention Through Environmental Design (CPTED) principles in public spaces.
*   Ensures well-lit bus stops and sidewalks.
*   Builds welcoming mixed use public spaces to encourage residents to use public spaces and keep the streets busy and safe.

<a id='465b7fcc-d510-453a-984e-86dd041e0c61'></a>

34

<a id='0e6cf320-7b9e-4c1e-b059-b7f630e7fef7'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='7b5ade63-9f02-43de-9622-7e4283cfb86d'></a>

* Takes steps to ensure that women are included in the planning and development process by using an inclusive approach to engage

<a id='0834f7d0-b609-4722-9625-99aac059c54d'></a>

neighbourhoods in planning and
development, including efforts to reach
out to all members of the community.

<a id='cd385e63-3288-4076-8469-53d83d277d53'></a>

## PRIORITY: CHILDCARE

### Investments and Grants

*   ***City of Vancouver Capital Plan***
    The Capital Plan for 2015-2018 includes an investment of $30 million for childcare, which is expected to leverage an additional $50 million in partner contributions. This investment will add 500 spaces for children aged 0-4 years old, and 500 spaces for school age care.
*   ***Childcare Enhancement Grant*** The Grant supports licensed childcare programs serving high need families.
*   ***Childcare Program Development Grant*** The Grant supports non-profit organizations to open a new childcare program, or expand a program already in operation.
*   ***Childcare Program Stabilization Grant***
    This is a one-time Grant to support non-profit childcare organizations facing a financial crisis that might jeopardize the continuity of their services.
*   ***Childcare Research, Policy Development, and Innovation Grant***
    The Grant supports non-profit organizations involved in research, policy development, or related projects focused on improving childcare in Vancouver.
*   ***School-age Care Expansion Projects Grant*** The Grant funds non-profit organizations to create new licensed school-age childcare programs. Funds are for capital-related costs in Vancouver School Board facilities.

<a id='2d4dd871-9a1e-49e6-8400-a274b6504b47'></a>

* ***Nominal Rent*** Nominal rent is charged to 57 non-profit childcare centres in City and Park Board-owned or leased facilities, supporting over 2,400 childcare spaces.
* ***Neighbourhood Access Grant Pilot*** This pilot provides $45,000 per year to offer 19 childcare spaces at zero cost to vulnerable families in a Downtown Eastside childcare facility.
* ***Other Childcare Grants*** Recent examples include support for the Vancouver Aboriginal Early Years Network and for Indigenous cultural competency training for Early Childhood Educators.

<a id='39539ff6-eac3-4959-a77a-c58411a3eab1'></a>

# Strategy and Policy
* ***Healthy City Strategy*** The Strategy includes commitments to high quality childcare design that supports healthy child development.
* ***Updated Childcare Strategy*** The updated Strategy is currently under development. It will:
  - Refresh policies, principles and goals to reflect current contexts.
  - Review operator selection criteria for City-owned childcare facilities, to be offered to non-profit operators at nominal rents.
  - Explore the hub model of integrated child and family services.

<a id='8c071219-0f01-4aa0-9ef6-3a664077eed8'></a>

35

<a id='86f4168d-a3da-4109-872f-f34c146c63e3'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='08cf44b0-4f14-4cab-89a2-26074ce030fe'></a>

* **Development Cost Levies (DCLs)**
DCLs are revenue sources used to fund the development of childcare facilities and other community amenities. Most new development in the City is subject to DCLs. Council recently increased the allocation of DCL revenue to childcare from 5 per cent to 13 per cent.
* **Joint Childcare Council** The City along with the Vancouver Board of Parks and Recreation and the Vancouver Board of Education work to support and deliver accessible, affordable, quality childcare spaces across the City.

<a id='61740abd-56c1-493b-a614-8f04aab0608b'></a>

• **_ $10/day Child Care Plan_** City Council passed a motion in support of the Community Plan for a Public System of Integrated Early Care and Learning.
• **_Partnership with the Vancouver Board of Education_** City-funded retrofits have created 466 school-age childcare spaces in existing schools and four planned childcare centres serving ages 0-4 will be co-located with seismically upgraded elementary schools, creating 275 new childcare spaces.

<a id='6907f985-7bf5-4b6a-8c74-641bdfd3b47b'></a>

# PRIORITY: HOUSING

## Affordable, Social and Supportive Housing

*   **Housing Vancouver Strategy (2018-2027)** The City's new 10-year strategy will address housing affordability and the supply of 72,000 homes that our residents need.
*   **Healthy City Strategy (2012-2021)** This Strategy included targets from the City's previous Housing and Homelessness Strategy. The City made significant progress towards enabling new social housing units and supportive housing units. New targets have been established in the Housing Vancouver Strategy. The City's overall goal remains "a home for everyone."
*   **Housing Development on City Land** Twenty (20) City-owned sites have been offered to the provincial and federal governments to build affordable housing.

<a id='799dd14a-05e1-4e7f-82a4-b82ff7eec27f'></a>

* **Development Cost Levies (DCLs)** DCLs are revenue sources used to fund the development of housing, childcare facilities and other community amenities. Most new development in the City is subject to DCLs. Council recently increased DCL revenue allocations for replacement housing from 32 per cent to 36 per cent.
* **Homelessness Outreach Program** The program is a partnership with BC Housing aimed at providing income, housing and health supports to homeless people and those at risk of homelessness.
* **Homelessness Action Week Grants** These grants are provided to non-profit organizations to host events and organize projects to help homeless residents; create awareness of homelessness; and, engage citizens on solutions to homelessness.

<a id='61387afb-afa7-41fe-abbc-530d7975e611'></a>

36

<a id='80c0a194-daf5-463a-9f44-17ef9bbe40fa'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6bc886ff-fc98-473b-b583-0d5147fdb1dd'></a>

* *Housing Infrastructure Grants* These capital grants support non-profit led projects aimed at achieving viability or increasing affordability of new units, and for SRO upgrades. The 2015-18 Capital Budget includes $10 million in capital grants for new units, and $4 million for SRO upgrades.
* *Community Amenity Contributions (CAC)* CAC negotiations on developer-led projects provide the City with turn-key housing units. The City's standard process is to enter into long-term operating agreements with a non-profit to operate these developments.

<a id='6ce4812a-b4ec-4848-9262-1efb4ba8ec70'></a>

## Family Housing

*   ***Housing Mix Policy for Rezoning Projects*** This policy requires that a minimum supply of family units be included in all new rezoning projects, specifically 35 per cent of units having two or more bedrooms.

<a id='d6d22e5e-5e84-44fe-b135-9699193de819'></a>

# Rental Housing

*   ***Rental 100*** The Secured Market Rental Housing Policy encourages the development of projects where 100 per cent of the residential units are rental.
*   ***Empty Homes Tax*** The tax aims to bring thousands of rental homes back into the market.
*   ***Rental Housing Stock Official Development Plan*** The Plan requires that redevelopment projects with six or more dwelling units replace every demolished rental unit.
*   ***Rental Standards Database*** The Database allows renters to look up residential rental buildings with health,

<a id='8e566415-e764-4d84-9c4f-e5653d4ec627'></a>

safety, maintenance, tidiness, and other
issues.

<a id='d89966d8-f8ad-45bf-b4fb-3d7b6d70f2c1'></a>

• **Laneway housing zoning** This zoning was introduced to increase rental and family housing in single-family areas.
• **Vancouver Rent Bank** The City funds the Bank, which provides one-time interest-free loans to low-income people in temporary financial crisis as well as advocacy and referral services.

<a id='fe21733c-42b8-48f5-a356-5aa416ca47d5'></a>

## Partnerships and Collaborations
* The City continues to work with provincial and non-profit housing partners to:
  - Support delivery of housing targeted to women and families through grants and provision of land for social housing.
  - Support programs and services targeting women fleeing domestic violence or in need of emergency shelter, social and supportive housing.

<a id='411dfb8a-a433-4fcd-b45b-1a7d2c0bde52'></a>

* ***Metro Vancouver Regional Homelessness Task Force*** The Task Force was struck in November 2016 in response to historic levels of homelessness throughout the region, and the need for systemic improvements from all levels of government and the non-profit sector to manage the crisis.
* ***Renters Advisory Committee*** The Committee advises Council on City priorities relating to renters; monitors and responds to the impacts of provincial and federal legislation affecting tenants; and, advises Council on enhancing access and inclusion for renters in developing City policy and civic life.

<a id='0a9790ff-60b4-46ae-905f-ee98e175450c'></a>

37

<a id='6cf8bc6e-059c-4521-9f7f-a6aad6f05085'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='5cd7ec62-33c0-4fbd-9510-1ae45550f41a'></a>

PRIORITY: LEADERSHIP & REPRESENTATION

<a id='ec8b6e24-0b26-4ffe-b070-508410001362'></a>

# Programs and Initiatives

*   **_Living Wage Employer_** As a certified living wage employer, the City is committed to paying its employees and contracted service employees a living wage. Metro Vancouver's living wage rate for 2017 is $20.62 per hour.
*   **_Engineering Services_**
    *   Has a Diversity & Inclusion Working Group with the goal of increasing the representation and retention of a diverse staff that represents our community.
    *   Has increased the representation of women on its Senior Executive team from 0% to 50%, between 2010 and 2017.
    *   Wellness rooms for staff have been created at two locations for prayer, breast feeding, and general wellness.
*   **_Vancouver Fire and Rescue Services_**
    *   Developed a pregnancy policy for women firefighters (2016).
    *   Maternity uniform is offered to female firefighters (instead of uniforms in larger sizes).
    *   Dual gender washrooms are being built in all replacement fire halls in addition to making modifications to existing washrooms in fire halls where possible.
    *   Unofficial mentoring by female firefighters to young girls through the '_Camp Ignite_' and '_Youth Academy_' program.

<a id='bf5033f0-58eb-45a7-a4c8-6a4dc1454893'></a>

- Recruitment and Outreach division conducts recruitment drives, actively participates in community events, and attends career fairs in efforts to reach under-represented groups.
- **Human Resources**
  - Currently piloting tele-mobility program for exempt staff.
  - The Equal Employment Opportunity Office leads work related to equity, diversity and inclusion, including:
    - Assists departments with targeted outreach and assistance on hiring and retaining a diverse workforce that reflects the community.
    - Acts as resource to all City staff regarding human rights issues, workplace harassment prevention and sustaining respectful workplaces.
    - Provides training to staff on human rights, workplace harassment, cultural competency, diversity and inclusion.
  - One-on-one leadership coaching and leadership development courses and events are made available to City leaders, including women leaders. The coaching and courses aim to enhance performance in leadership roles and to support transition to higher levels of leadership.
- **Vancouver Board of Parks and Recreation** is leading focus groups with female staff in leadership and Park Operations. A follow-up strategy and action plans are in development.

<a id='083ec46a-6953-49d4-9a8a-d6322c12a632'></a>

38

<a id='abcc26d5-d246-4794-a426-29103e5fbfdb'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='633252ed-2fa3-405c-aa08-4f07d4930451'></a>

## Related Policies and Procedures
* Human Rights and Harassment Policy
* Respectful Workplace Policy
* Multicultural Policy
* Employment Equity
* Occupational Health and Safety Policy
* Maternity and Parental Leaves
* Job-Sharing
* Job Evaluation and Compensation

<a id='76e48350-63b3-4204-bb82-abdbaf247983'></a>

## Collaborations and Partnerships

*   The City participates in **research projects** such as McKinsey Global Institute's "_The Power of Parity: Advancing Women's Equality in Canada_" and the Conference Board of Canada's research on diversity and inclusion.
*   **Greenest City Action Team Scholars**
    The program was established in 2010 with a City of Vancouver - UBC Partnership Agreement. The program engages UBC graduate students to work on sustainability projects in support of the _Greenest City 2020 Action Plan_.
    To date, over 100 students have gone through the program and over half of the students have been female.

<a id='26185626-c1ca-4170-af19-0c9605abcb53'></a>

* **CityStudio Vancouver** CityStudio engages students and faculty from six post-secondary institutions to contribute to projects on the City's Greenest City Action Plan, Healthy City Strategy and Engaged City Strategy. With 195 projects to date, CityStudio has engaged 3,500 students, 163 faculty and 75 City staff since its inception. To date, half of the students have been female.
* **Mentorship Program for New Immigrant Professionals** The Program is offered in partnership with the Immigrant Employment Council of BC (IEC-BC). The Program matches City staff with new immigrants of similar professional backgrounds. Now in its sixth year, over 200 immigrant professionals have benefited. In 2017, 59 per cent of our mentors were female.
* **Indigenous Internship Program** The Program is offered in partnership with the Aboriginal Community Career Employment Services Society (ACCESS). This capacity-building, 20-month long internship program assists Indigenous applicants to further develop their knowledge, skills and experience. The current program has five interns, three of which are female.

<a id='84bc9540-d820-4bb7-ad94-5a3a7fcae5bc'></a>

39

<a id='79fa5a62-0d54-41a9-8ab9-25de7759bfd5'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='42f7886b-cae4-469a-b6bf-2ca4c888e676'></a>

INPUTS FOR FUTURE
CONSIDERATION

<a id='d14fde9c-41d6-4469-ac1d-bf306e1b54e7'></a>

The following are ideas and inputs received during stakeholder consultations and research.
These will be considered by the Action Team over the life of the Strategy.

<a id='d2a2791b-ad0e-41c4-95f8-3ab9e201eae6'></a>

INTERSECTIONAL LENS
<table id="62-1">
<tr><td id="62-2">INPUTS</td><td id="62-3">SOURCE(S)</td></tr>
<tr><td id="62-4">Become a City for CEDAW (Convention on the Elimination of all forms of Discrimination Against Women) and take follow up actions further to Mayor&#x27;s Guide: Accelerating Gender Equality, including: • Establish a Department/Position on the Status of Women. • Fund a report on the status of women in the city. Publicize data to identify areas of improvement. • Develop a public education campaign on the status of women.</td><td id="62-5">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="62-6">Adopt a Charter of Rights and Freedoms for the City and create an Ombudsperson Office that reports to the City Manager to oversee complaints under the Charter and all public complaints against the City (see City of Montreal, as example).</td><td id="62-7">• Internal Subject Matter Expert • External Subject Matter Expert</td></tr>
<tr><td id="62-8">Ensure that all internal and external communication is accessible and available in multiple formats and languages.</td><td id="62-9">• Best Practice</td></tr>
<tr><td id="62-a">Involve stakeholders in developing goals and measuring performance.</td><td id="62-b">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • Best practice</td></tr>
<tr><td id="62-c">Establish permanent City advisory committee on the Status of Women.</td><td id="62-d">• Women&#x27;s Advisory Committee • Public Survey • Best Practice</td></tr>
<tr><td id="62-e">Gather disaggregated data to support implementation of intersectional framework that aligns with best practices.</td><td id="62-f">• Women&#x27;s Advisory Committee • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
</table>

<a id='dc33800a-613c-44ad-b76b-53f32a92e1f4'></a>

40

<a id='5ea487da-6ee1-497b-bf36-32fd7e110f5f'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='9a8c44e7-f930-49a2-81e4-118a6462e1a0'></a>

<table id="63-1">
<tr><td id="63-2">INPUTS</td><td id="63-3">SOURCE(S)</td></tr>
<tr><td id="63-4">Apply a gender equity/intersectional lens to the City budget.</td><td id="63-5">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • Best Practice</td></tr>
<tr><td id="63-6">Adopt a participatory budgeting process.</td><td id="63-7">• Public Forum • Best Practice</td></tr>
<tr><td id="63-8">Hold leaders accountable for diversity and inclusion goals (internal, external), results, and being role models.</td><td id="63-9">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="63-a">Implement and report out on Advancing Equity and Inclusion: A Guide for Municipalities.</td><td id="63-b">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="63-c">Implement gender budgeting and GBA+ across all City activities.</td><td id="63-d">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="63-e">Report out annually on progress in reaching gender equity/ diversity goals.</td><td id="63-f">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="63-g">Apply intersectional approach to a participatory planning process to ensure full inclusion of all citizens.</td><td id="63-h">• Public Forum</td></tr>
<tr><td id="63-i">Create Community Leaders&#x27; Group to advise on the implementation of the Women&#x27;s Equity Strategy.</td><td id="63-j">• External Subject Matter Expert</td></tr>
</table>

<a id='676d718a-cd88-4be5-b2a4-2f663498e465'></a>

WOMEN'S SAFETY
<table id="63-k">
<tr><td id="63-l">INPUTS</td><td id="63-m">SOURCE(S)</td></tr>
<tr><td id="63-n">Consider women&#x27;s needs in neighbourhood planning and development, including women&#x27;s safety. Apply a gender lens to CPTED (Crime Prevention through Environmental Design) Guidelines.</td><td id="63-o">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="63-p">Create a centralized women&#x27;s hub to locate all violence-related services in one accessible location.</td><td id="63-q">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="63-r">Develop partnership agreements with community partners to do comprehensive prevention work.</td><td id="63-s">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='7e199ce5-1d36-42d6-ab2a-aa7063b4109c'></a>

41

<a id='610310ef-ae6b-43a9-8e4b-428746c7165e'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='2158099b-e1e7-4aa5-be49-2bc09a37fae9'></a>

<table id="64-1">
<tr><td id="64-2">INPUTS</td><td id="64-3">SOURCE(S)</td></tr>
<tr><td id="64-4">Create and/or increase assertiveness and self-defense training classes at community centres.</td><td id="64-5">• Public Survey • Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-6">Conduct public campaign to raise awareness of violence against women. Create page on City website as part of public campaign.</td><td id="64-7">• Women&#x27;s Advisory Committee • External Subject Matter Experts</td></tr>
<tr><td id="64-8">Develop and implement a comprehensive civic action plan to end violence against women. Include annual report on current status, such as how long the wait list for counseling, and use of shelter space.</td><td id="64-9">• Women&#x27;s Advisory Committee • Public Forum • External Subject Matter Experts</td></tr>
<tr><td id="64-a">Include in City communications opportunities for City leaders to speak out against violence against women, misogyny and systemic oppression.</td><td id="64-b">• Women&#x27;s Advisory Committee • External Subject Matter Experts</td></tr>
<tr><td id="64-c">Establish an integrated interagency service team on violence against women, including intimate partner violence.</td><td id="64-d">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-e">Fund employment training programs for women leaving violence.</td><td id="64-f">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-g">Fund non-profit organizations working to stop violence against women.</td><td id="64-h">• Public Forum
• Public Survey
• External Subject Matter Experts</td></tr>
<tr><td id="64-i">Increase well-lit public parking near SkyTrain stations.</td><td id="64-j">• Public Survey</td></tr>
<tr><td id="64-k">Install security measures (e.g. CCTV-type cameras and panic buttons) in locations identified with higher crimes and assaults against women.</td><td id="64-l">• Public Survey
• Best Practice</td></tr>
<tr><td id="64-m">Ensure access to mechanisms that will guarantee women&#x27;s rights in the event they are subjected to violence.</td><td id="64-n">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-o">Implement mandatory violence against women training for City of Vancouver staff.</td><td id="64-p">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="64-q">Provide free city space to non-profit organizations working to stop violence.</td><td id="64-r">• Best Practice</td></tr>
<tr><td id="64-s">Develop and distribute publication (online and print) with information and resources on women&#x27;s safety. Make it available in all City public locations (community centres, libraries, etc.) in multiple languages.</td><td id="64-t">• Women&#x27;s Advisory Committee • External Subject Matter Expert</td></tr>
<tr><td id="64-u">Work with and support community groups that deal with and respond to harassment/violence against women in the night life industry and at music festivals.</td><td id="64-v">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='a5452d53-878a-4e52-aea3-102146d4b2e2'></a>

42

<a id='3e568872-4bbe-45d1-8c24-8d616c8a0677'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='4846cb22-443b-4049-9f42-8c8348a77ffd'></a>

<table id="65-1">
<tr><td id="65-2">INPUTS</td><td id="65-3">SOURCE(S)</td></tr>
<tr><td id="65-4">Support efforts to improve women&#x27;s safety on campuses within Vancouver.</td><td id="65-5">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="65-6">Address sexualization of women and girls by banning sexualized images and ads in public spaces (transit, billboards, etc). For example, see YWCA advocacy on issue: https://ywcavan.org/advocacy/sexualization-women-and-girls</td><td id="65-7">• Public Forum • Public Survey</td></tr>
<tr><td id="65-8">Advocate/use leverage on TransLink Board to encourage TransLink to: • increase safety measures in SkyTrain stations and on buses and SkyTrains; • increase awareness of current safety measures (e.g. request stop); • address privacy and safety concerns with COMPASS card tracking; and, • involve/consult women in development of new routes, bus stops and stations.</td><td id="65-9">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • Best Practice</td></tr>
<tr><td id="65-a">Recommendations for the Vancouver Police Department • Provide officers with training in cultural competency, trauma-informed approaches, and how to deal with domestic and other violence against women. Training should be delivered by local experts and people with lived experience. • Decriminalize the behaviours of women with mental health issues. • Apply improved language around violence against women - do not use victim-blaming language. • Provide increased funding and other resources to Aboriginal Policing Centre. • Recruit more female police officers. • Create multilingual/multicultural teams to support immigrant and refugee women. • Ensure access to mechanisms that will guarantee women&#x27;s rights in the event they are subjected to violence.</td><td id="65-b">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="65-c">Recommendation for the Vancouver Public Library • Promote ending violence against women through book buying, use of space, resources, programming, signage, communications.</td><td id="65-d">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='383ecc5a-b185-474d-bef7-898df4a3feeb'></a>

43

<a id='969e01f3-4cd0-49ee-b21b-b96f5a0d6c89'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='52f1bb6b-97a5-4055-a9be-bd94f0a44bd5'></a>

CHILDCARE
<table id="66-1">
<tr><td id="66-2">INPUTS</td><td id="66-3">SOURCE(S)</td></tr>
<tr><td id="66-4">Take actions to increase civic participation of families, for example: • Reimbursement for childcare expenses for members of civic advisory committees (e.g., living wage x 3 hours/ month); • Provide childcare or child-minding corner on site at public events; • Provide childcare reimbursement for speakers at events; and, • Facilitate participation of parents at events by offering speakers with young children the option of presenting early on an evening agenda.</td><td id="66-5">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="66-6">Continue to encourage the development of quality childcare facilities.</td><td id="66-7">• Women&#x27;s Advisory Committee • Public Survey • Public Forum</td></tr>
<tr><td id="66-8">Encourage addition of family rooms in all public spaces.</td><td id="66-9">• Public Survey</td></tr>
<tr><td id="66-a">Expand the existing supply of quality childcare facilities and programs.</td><td id="66-b">• Internal Subject Matter Expert • Public Forum • Public Survey</td></tr>
<tr><td id="66-c">Advocate and promote a living wage for childcare providers.</td><td id="66-d">• Public Survey</td></tr>
<tr><td id="66-e">Provide property tax relief to childcare providers.</td><td id="66-f">• Public Forum</td></tr>
<tr><td id="66-g">Support trans girls in childcare facilities.</td><td id="66-h">• Public Forum</td></tr>
<tr><td id="66-i">Look for innovative development opportunities to locate new childcare facilities where they can best serve families, including through co-location with schools and community serving organizations.</td><td id="66-j">• Public Survey • Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='7321fbee-9c14-4c8b-b8aa-7aea188bebe2'></a>

HOUSING
<table id="66-k">
<tr><td id="66-l">INPUTS</td><td id="66-m">SOURCE(S)</td></tr>
<tr><td id="66-n">Adopt UN Definition of &quot;Adequate Housing&quot;.</td><td id="66-o">• External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="66-p">Advocate for housing strategies at the provincial and federal levels that support the diverse housing needs of women.</td><td id="66-q">• Public Forum • Public Survey • External Subject Matter Experts</td></tr>
</table>

<a id='09b84cc6-9ec9-4bbf-b006-f55fa557d221'></a>

44

<a id='b363e205-0bb0-4b3b-b72e-688009fed0e0'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='a99f3beb-1ccf-43d6-a861-510b9b4e45e6'></a>

<table id="67-1">
<tr><td id="67-2">INPUTS</td><td id="67-3">SOURCE(S)</td></tr>
<tr><td id="67-4">Apply a gender/intersectional lens to the implementation of the Housing Vancouver Strategy.</td><td id="67-5">• Public Forum • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="67-6">Carry out research to better understand women&#x27;s homelessness and to deepen our understanding of homelessness (and hidden homelessness) for all women (including Indigenous women). Integrate findings into implementation of Housing Vancouver Strategy.</td><td id="67-7">• Women&#x27;s Advisory Committee • Internal Subject Matter Expert • Public Forum • External Subject Matter Experts</td></tr>
<tr><td id="67-8">Support effective models of &#x27;housing first&#x27; for women.</td><td id="67-9">• External Subject Matter Experts</td></tr>
<tr><td id="67-a">Coordinate and streamline City housing grants to simplify applications.</td><td id="67-b">• External Subject Matter Expert</td></tr>
<tr><td id="67-c">Measure and report out on the impact of City housing grants, including data gathering/ indicators for success in gender responsive programs and services.</td><td id="67-d">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="67-e">Continue to apply inclusionary zoning to increase the supply of affordable housing.</td><td id="67-f">• Public Survey • External Subject Matter Experts • Best Practices</td></tr>
<tr><td id="67-g">Develop affordable housing targeted to women and women-led families, in particular women who are leaving intimate partner violence, in partnership with women&#x27;s anti-violence organizations.</td><td id="67-h">• Women&#x27;s Advisory Committee • Public Survey • Public Forum • External Subject Matter Experts • Best Practices</td></tr>
<tr><td id="67-i">Continue to ensure new housing is accessible and meets the needs of families through Enhanced Accessibility Guidelines and the High-Density Housing for Families with Children Guidelines (in the process of being updated).</td><td id="67-j">• Internal Subject Matter Expert</td></tr>
<tr><td id="67-k">Continue to work with provincial and non-profit housing partners to: • support delivery of housing targeted to women and families through grants and provision of land for social housing; and, • support programs and services targeting women fleeing domestic violence or in need of emergency shelter, social and supportive housing.</td><td id="67-l">• Internal Subject Matter Expert</td></tr>
</table>

<a id='ee9f60b0-cb79-4a10-a49b-f92677775cab'></a>

45

<a id='2e541924-2fba-4707-8bc7-58b63de21696'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='56c6749a-657b-4744-8971-3e973f6c826b'></a>

<table id="68-1">
<tr><td id="68-2">INPUTS</td><td id="68-3">SOURCE(S)</td></tr>
<tr><td id="68-4">Create liaison/outreach role within Coordinated Access Centre to work with women-serving organizations to identify women in need of priority housing.</td><td id="68-5">• Internal Subject Matter Expert</td></tr>
<tr><td id="68-6">Develop and deliver anti-discrimination training initiatives for landlords.</td><td id="68-7">• Public Forum • External Subject Matter Experts</td></tr>
<tr><td id="68-8">Create anti-discrimination regulations, enforcement, and education to address landlord discrimination against families, single mothers, women fleeing violence.</td><td id="68-9">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="68-a">Generate a housing strategy that addresses the distinctive and diverse housing and homeless circumstances of women, such as vulnerability to violence, income inequality and family responsibilities. and Identify and implement opportunities within new non-market/social housing to reserve spaces for women in priority need, including women leaving intimate partner violence.</td><td id="68-b">• Women&#x27;s Advisory Committee • External Subject Matter Experts</td></tr>
<tr><td id="68-c">Increase range of alternative housing tenures, family-oriented and culturally diverse design solutions across the housing continuum - co-housing, intergenerational housing, childcare space integrated in housing, etc.</td><td id="68-d">• Public Forum • Public Survey • External Subject Matter Experts • Best Practices</td></tr>
<tr><td id="68-e">Ensure that neighbourhood planning and development considers women&#x27;s and families&#x27; needs.</td><td id="68-f">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practices</td></tr>
<tr><td id="68-g">Develop specific actions within the City&#x27;s housing strategy to address homelessness of Indigenous women.</td><td id="68-h">• External Subject Matter Expert</td></tr>
<tr><td id="68-i">Advocate for regulations requiring increased overnight staff at women&#x27;s transition houses/shelters.</td><td id="68-j">• Public Forum</td></tr>
<tr><td id="68-k">Support efforts to centralize housing waitlists and use coordinated approaches to tenant selection. Include clause in City of Vancouver operating agreements with non-profit housing agencies that they register all of their housing with BC Housing registry.</td><td id="68-l">• External Subject Matter Expert • Internal Subject Matter Expert</td></tr>
<tr><td id="68-m">Fund workforce development programs in transitional housing for women coming home from prison.</td><td id="68-n">• Public Forum</td></tr>
</table>

<a id='9ca91a3f-ea62-4c03-ac75-ecd6ff6b651e'></a>

46

<a id='2c3c4f73-57e2-40dc-930e-eb7db6567822'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='cc198ab1-3aaa-454e-9838-4cf280884d44'></a>

LEADERSHIP & REPRESENTATION

<a id='f0f2ea03-534a-4892-ab0c-feea817ab49f'></a>

<table id="69-1">
<tr><td id="69-2">INPUTS</td><td id="69-3">SOURCE(S)</td></tr>
<tr><td id="69-4">Develop and implement an Equity and Inclusion Strategy for the City&#x27;s workplace.</td><td id="69-5">• Women&#x27;s Advisory Committee • Public Survey • Internal Subject Matter Expert • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-6">Audit human resources&#x27; processes for bias (including job descriptions and job advertisements) and implement improvements.</td><td id="69-7">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-8">Conduct an employee engagement survey to assess current employees&#x27; views on opportunities for advancement, and sense of inclusion in the workplace.</td><td id="69-9">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="69-a">Create an internal employee resource group on women in leadership.</td><td id="69-b">• Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-c">Create mentorship and sponsorship opportunities for women in leadership and in historically under-represented occupations.</td><td id="69-d">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="69-e">Create opportunities for paid internships for women in historically under-represented occupations.</td><td id="69-f">• Women&#x27;s Advisory Committee • Public Forum • Public Survey</td></tr>
<tr><td id="69-g">Provide information sessions, job shadowing, and/or worksite tours to encourage recruitment of women in historically under-represented occupations.</td><td id="69-h">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="69-i">Create an initial applicant screening that is gender-blind.</td><td id="69-j">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="69-k">Educate recruitment staff on intercultural communication and unconscious bias</td><td id="69-l">• Women&#x27;s Advisory Committee • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="69-m">Ensure that hiring panels reflect diversity.</td><td id="69-n">• Public Survey • Best Practice</td></tr>
</table>

<a id='cf0e113d-6a7e-4f84-8bc5-e15bf41dfee7'></a>

47

<a id='78d4e767-6ce9-4307-81a8-1c706811393b'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='4846c288-956b-4477-84f2-1b6c590f66f1'></a>

<table id="70-1">
<tr><td id="70-2">INPUTS</td><td id="70-3">SOURCE(S)</td></tr>
<tr><td id="70-4">Gather disaggregated data to support implementation of intersectional framework that aligns with best practices. Include pay equity monitoring in data gathering.</td><td id="70-5">• Women&#x27;s Advisory Committee • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="70-6">Conduct a statistical gender analysis of the recruitment and selection processes to determine whether women are being disproportionately screened out at any stage.</td><td id="70-7">• Best Practice</td></tr>
<tr><td id="70-8">Host roundtable of female municipal leaders.</td><td id="70-9">• Internal Subject Matter Expert</td></tr>
<tr><td id="70-a">Implement formal return to work programs for staff returning from extended care leaves.</td><td id="70-b">• Public Survey • Best Practice</td></tr>
<tr><td id="70-c">Implement new leadership competencies and training on managing diversity.</td><td id="70-d">• Women&#x27;s Advisory Committee • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="70-e">Increase options for flexible work schedules and job sharing.</td><td id="70-f">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Expert • Best Practice</td></tr>
<tr><td id="70-g">Monitor leadership training and development programs to ensure women&#x27;s leadership training needs are appropriately identified and met. Gather data track participation of women in leadership development programs.</td><td id="70-h">• Women&#x27;s Advisory Committee • Internal Subject Matter Expert</td></tr>
<tr><td id="70-i">Conduct outreach to school-aged girls (grades 4-6) to promote historically under-represented occupations and occupations in science, technology, engineering and mathematics (STEM).</td><td id="70-j">• Internal Subject Matter Expert • Public Survey • Best Practice</td></tr>
<tr><td id="70-k">Participate in Women Transforming Cities research &quot;Taking Action on Systemic Barriers to Women&#x27;s Participation in Local Government.&quot;</td><td id="70-l">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="70-m">Report out annually on staff pay and workforce composition in an easy-to-find place on the website.</td><td id="70-n">• Public Survey • Women&#x27;s Advisory Committee</td></tr>
<tr><td id="70-o">Pay Equity - Review data collection practices for pay equity monitoring purposes.</td><td id="70-p">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
</table>

<a id='17842a96-310f-47ed-9e4a-62eab2ec7dd8'></a>

48

<a id='aa4bc307-d276-4a55-b7cd-593d33d3b497'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='be6ed6dd-51dd-4e30-b112-3eb39c4a9540'></a>

<table id="71-1">
<tr><td id="71-2">INPUTS</td><td id="71-3">SOURCE(S)</td></tr>
<tr><td id="71-4">Develop options for providing childcare to City workers.</td><td id="71-5">• Public Survey • Best Practice</td></tr>
<tr><td id="71-6">Report out on annually on progress of diversity and inclusion initiatives.</td><td id="71-7">• Women&#x27;s Advisory Committee • Best Practice</td></tr>
<tr><td id="71-8">Examine procurement process (contracting) to either require or award extra points for bidders who demonstrate: • Anti-discrimination/harassment policies • Pay equity • Diversity and inclusion initiatives</td><td id="71-9">• Women&#x27;s Advisory Committee • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="71-a">Target recruitment initiatives to women in historically under-represented occupations.</td><td id="71-b">• Women&#x27;s Advisory Committee • Public Forum • Public Survey • External Subject Matter Experts • Best Practice</td></tr>
<tr><td id="71-c">Target recruitment ads to diverse communities.</td><td id="71-d">• Public Survey
• Best Practice</td></tr>
<tr><td id="71-e">Work with Vancouver School Board to highlight women throughout the school curriculum.</td><td id="71-f">• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="71-g">Provide training to City staff in:
• Anti-racism
• Anti-oppression
• Intersectionality</td><td id="71-h">• Public Survey
• Women&#x27;s Advisory Committee</td></tr>
<tr><td id="71-i">Create internships and skills-based training opportunities for single mothers to acquire new skills and improve their quality of life.</td><td id="71-j">• Public Survey</td></tr>
<tr><td id="71-k">Use the Harvard Implicit Bias test to measure bias and take steps to mitigate bias.</td><td id="71-l">• Public Forum
• Public Survey</td></tr>
<tr><td id="71-m">Name 50 per cent of public spaces and places after the full diversity of women (e.g. Angie Todd Denis) and women&#x27;s history in Vancouver.</td><td id="71-n">• Public Survey • Public Forum • Women&#x27;s Advisory Committee</td></tr>
<tr><td id="71-o">Reinstate the &quot;Remarkable Women&quot; poster series.</td><td id="71-p">• Women&#x27;s Advisory Committee</td></tr>
</table>

<a id='c2f5ece5-1e3e-4c08-8579-bc0ef4277ced'></a>

49

<a id='1a707c0a-3ef3-4fd8-b9c9-5c6434847961'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='6d939afe-8403-4b95-b4ea-5dcf423944a5'></a>

<::A woman with brown hair, wearing a black blazer and a green skirt, smiles at the camera while presenting a framed certificate to another woman. The second woman, with brown hair and a leopard print headband, wears a brown corduroy jacket and a black turtleneck, smiling while holding the certificate. The certificate reads: "CERTIFICATE OF APPRECIATION Marlene Abbott-Peter Team BC Coach 2015 CANADA WINTER GAMES - WHEELCHAIR BASKETBALL". The left side of the certificate holder displays an image of a structure with fire, possibly an Olympic cauldron. In the background, national and provincial flags are visible, including the Canadian flag and the flag of British Columbia.: figure::>

<a id='d2c5dd24-80c6-42e5-bc50-783f513caf3f'></a>

50

<a id='45543f96-4fbe-4b3f-ad1a-6b7e8b537289'></a>

VANCOUVER: A CITY FOR ALL WOMEN | WOMEN'S EQUITY STRATEGY 2018-2028

<!-- PAGE BREAK -->

<a id='347f909d-323c-493d-a43b-35f9ff53746c'></a>

<::logo: City of Vancouver
CITY OF
VANCOUVER
This logo features a stylized blue and green leaf or petal design.::>

<a id='f0effaa7-54ea-4ac8-b338-db0fd1f6dfc5'></a>

453 West 12th Avenue
Vancouver, British Columbia
Canada V5Y 1V4

<a id='875ace9b-5869-4ddf-b33a-36b51be1d95b'></a>

website: vancouver.ca

@CityofVancouver

/CityofVancouver

phone: 3-1-1

<a id='80662ebb-5b42-4f08-87e8-5727ae6dd5a1'></a>

18-025