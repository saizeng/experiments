"""
Stub implementation for internal API retrieval.
Replace this with real internal API integration.
"""

from typing import Dict, Optional


def run_internal_api(query: str, company_name: Optional[str] = None) -> Dict:
    return {
        "company": company_name or "Example Company",
        "confidence": "medium",
        "data": {
            "note": "Replace this stub with internal API logic.",
            "query_received": query,
        },
        "references": [
            {
                "source": "Internal API",
                "id": "internal-example-id",
                "title": "Example internal record",
            }
        ],
    }
