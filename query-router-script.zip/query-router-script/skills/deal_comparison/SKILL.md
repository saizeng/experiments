---
name: deal_comparison
description: >
  Compares two or more deals side-by-side across key dimensions like
  valuation, timeline, structure, and risk factors.
trigger: when user asks to compare deals, benchmark, or side-by-side analysis
category: analysis
parameters:
  - name: query
    type: string
    required: true
    description: The comparison question
  - name: deal_ids
    type: list
    required: false
    description: Deal identifiers to compare
---

# Deal Comparison Skill
