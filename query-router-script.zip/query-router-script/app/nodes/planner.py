"""Planner node: LLM query decomposition with conversation context."""

from __future__ import annotations

import json
import logging

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from app.config import settings
from app.skill_registry import registry
from app.state import PlanStep, RouterState

logger = logging.getLogger(__name__)

PLANNER_SYSTEM = """\
You are a query planner for a financial services platform.

You have access to **skills** — Python functions that each do one thing well.
Every data source, search engine, and tool is a skill.

## Available Skills
{skills_block}

## Conversation History
The user may refer to prior messages. Use the conversation history to
resolve references like "that deal", "the same client", "compare those",
etc. The history is provided as prior messages in this conversation.

## Rules
- Decompose compound questions into the smallest independent sub-questions.
- Route each sub-question to exactly one skill by its `name`.
- If a step needs output from a prior step, set `depends_on` to that
  step's `step_id`. Use {{step_N_results}} as placeholder in the query.
- Independent steps have empty `depends_on` — they run in parallel.
- If no skill fits, omit the step and note the gap.
- Step IDs start at 1.

## Output (JSON only, no markdown fences)
{{
  "reasoning": "brief chain-of-thought",
  "steps": [
    {{
      "step_id": 1,
      "description": "what this step answers",
      "skill_name": "name_of_skill",
      "query": "sub-question for this skill",
      "depends_on": [],
      "parameters": {{}}
    }}
  ]
}}
"""

FEW_SHOT: list[dict] = [
    {"role": "user", "content": "What is Acme Corp's total revenue for Q3 2025?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Quantitative → structured_data.",
        "steps": [{"step_id": 1, "description": "Acme Q3 revenue",
                    "skill_name": "structured_data", "query": "What is Acme Corp's total revenue for Q3 2025?",
                    "depends_on": [], "parameters": {}}],
    })},
    {"role": "user", "content": "What was Acme revenue last quarter and what does their merger agreement say about earnouts?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Two independent sub-questions. Parallel.",
        "steps": [
            {"step_id": 1, "description": "Acme revenue", "skill_name": "structured_data",
             "query": "What was Acme Corp's revenue last quarter?", "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Earnout clause", "skill_name": "unstructured_docs",
             "query": "What does the Acme Corp merger agreement say about earnouts?", "depends_on": [], "parameters": {}},
        ],
    })},
    {"role": "user", "content": "Show me deals over $50M where the merger agreement had a MAC clause."},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Filter deals (structured_data) then inspect docs (unstructured_docs). Sequential.",
        "steps": [
            {"step_id": 1, "description": "Deals over $50M", "skill_name": "structured_data",
             "query": "List all deals with value over $50M. Return deal IDs and names.", "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Check for MAC clauses", "skill_name": "unstructured_docs",
             "query": "For deals: {step_1_results}, check merger agreements for MAC clauses.", "depends_on": [1], "parameters": {}},
        ],
    })},
    {"role": "user", "content": "How does our Acme deal compare to recent market acquisitions?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Internal data + external search. Parallel.",
        "steps": [
            {"step_id": 1, "description": "Acme deal details", "skill_name": "structured_data",
             "query": "Get full deal details for Acme acquisition.", "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Market comps", "skill_name": "web_search",
             "query": "Recent comparable acquisitions similar to Acme deal", "depends_on": [], "parameters": {}},
        ],
    })},
]


async def plan_node(state: RouterState) -> dict:
    """Decompose the question into skill-routed plan steps."""

    llm = ChatAnthropic(
        model=settings.planner_model,
        api_key=settings.anthropic_api_key,
        temperature=0,
        max_tokens=2048,
    )

    skills_block = registry.summary_for_planner()
    system = PLANNER_SYSTEM.format(skills_block=skills_block)

    messages: list = [SystemMessage(content=system)]

    # Inject few-shot examples
    for msg in FEW_SHOT:
        cls = HumanMessage if msg["role"] == "user" else AIMessage
        messages.append(cls(content=msg["content"]))

    # Inject conversation history for context
    for msg in state.get("chat_history", []):
        cls = HumanMessage if msg.role == "user" else AIMessage
        messages.append(cls(content=msg.content))

    # Current question
    messages.append(HumanMessage(content=state["question"]))

    response = await llm.ainvoke(messages)

    raw = response.content.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1]
    if raw.endswith("```"):
        raw = raw.rsplit("```", 1)[0]

    try:
        plan_data = json.loads(raw)
    except json.JSONDecodeError:
        logger.error("Planner returned invalid JSON: %s", raw)
        return {"error": f"Planner produced invalid JSON:\n{raw}"}

    known = {s.name for s in registry.list_all()}
    steps = []
    for s in plan_data.get("steps", []):
        if s["skill_name"] not in known:
            logger.warning("Unknown skill '%s' — skipping", s["skill_name"])
            continue
        steps.append(PlanStep(**s))

    if not steps:
        return {"error": "Planner produced no valid steps."}

    return {
        "reasoning": plan_data.get("reasoning", ""),
        "plan_steps": steps,
        "step_results": [],
        "completed_ids": set(),
    }
