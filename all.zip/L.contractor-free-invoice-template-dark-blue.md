<a id='d92e1130-6481-447f-bbbe-f3a02b7d99df'></a>

<::logo: Placeholder Logo
YOUR LOGO
A circular outline enclosing the bold text "YOUR LOGO" in black.::>

<a id='3b395b21-7857-40e1-95cc-57b324a8dd07'></a>

<Your Company Name>
<Your Company Address>
<Your Contact Details>

<a id='59b60a56-87a1-4451-969a-1126089d984e'></a>

ISSUE DATE
DUE DATE
INVOICE NUMBER
PO NUMBER

<a id='4a07c705-d538-4046-9b24-fe13b2b998c1'></a>

BILL TO
<Contact Name>
<Client Company Name>
<Address>
<Phone>
<Email>

<a id='79e94291-4e69-4826-a869-e1d635f63d42'></a>

SHIP TO
<Name / Dept>
<Client Company Name>
<Address>
<Phone>

<a id='98531d8c-b123-4c25-bcb5-a256d687ff1d'></a>

SHIPMENT INFORMATION
P.O. #
P.O. Date
Letter of Credit #
Currency
Payment Terms
Est. Ship Date

<a id='1a1ccd35-06c0-4aa4-9916-ca9df7520444'></a>

Mode of Transportation
Transportation Terms
Number of Packages
Est. Gross Weight
Est. Net Weight
Carrier

<a id='71290ce1-b34c-4536-a81e-9248e7cf9da6'></a>

<table id="0-1">
<tr><td id="0-2">ITEM</td><td id="0-3">QUANTITY</td><td id="0-4">PRICE</td><td id="0-5">TOTAL</td></tr>
<tr><td id="0-6"></td><td id="0-7"></td><td id="0-8"></td><td id="0-9"></td></tr>
<tr><td id="0-a"></td><td id="0-b"></td><td id="0-c"></td><td id="0-d"></td></tr>
<tr><td id="0-e"></td><td id="0-f"></td><td id="0-g"></td><td id="0-h"></td></tr>
<tr><td id="0-i"></td><td id="0-j"></td><td id="0-k"></td><td id="0-l"></td></tr>
<tr><td id="0-m"></td><td id="0-n"></td><td id="0-o"></td><td id="0-p"></td></tr>
<tr><td id="0-q"></td><td id="0-r"></td><td id="0-s"></td><td id="0-t"></td></tr>
</table>

<a id='f1fd01f5-fe1e-498f-9f8a-d85047b0dbe3'></a>

SPECIAL NOTES, TERMS OF SALE

<a id='fc669a2b-5993-44d8-bb84-5881edec82a7'></a>

SUBTOTAL LESS DISCOUNT
0.00

SUBJECT TO SALES TAX
0.00

TAX RATE
0.00%

TOTAL TAX
0.00

SHIPPING/HANDLING
0.00

<a id='0ccfcd69-8339-4c23-a56e-0c462dd913a5'></a>

SUBTOTAL

0.00

<a id='19a2dedb-91e4-47ae-95dc-c073331fc27a'></a>

<::attestation: Declaration
Status: unsigned
Signature: illegible
Readable Text: I declare that the above information is true and correct to the best of my knowledge.
Short description: A declaration sentence followed by a signature line and a date line, horizontally aligned.::>

<a id='0b052c15-494a-493e-bf65-41f0426455ea'></a>

Powered by Invoice Fly

<a id='c9f920c6-2f91-4455-9d94-11f8423a66bd'></a>

This invoice was generated with the help of Invoice Fly. To learn more, and create your own free account visit invoicefly.com