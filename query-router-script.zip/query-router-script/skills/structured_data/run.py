"""Structured data skill.

TODO: Replace the stub with your actual chatbot API call.
"""


async def run(query: str, parameters: dict, upstream: dict) -> dict:
    """Query the structured data chatbot.

    Args:
        query: Natural-language question about deals, revenue, clients, etc.
        parameters: Extra params from the planner (unused here).
        upstream: Results from prior dependent steps.

    Returns:
        dict with "answer" key.
    """
    # ── Replace this with your actual implementation ──
    # Example using httpx:
    #
    # import httpx
    # async with httpx.AsyncClient() as client:
    #     resp = await client.post(
    #         "http://your-structured-api/chat",
    #         json={"question": query, "context": upstream},
    #     )
    #     resp.raise_for_status()
    #     return resp.json()

    return {
        "answer": f"[STUB] Structured data response for: {query}",
        "source": "structured_data",
    }
