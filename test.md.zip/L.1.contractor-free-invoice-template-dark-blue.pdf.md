<a id='af91bac5-3ebf-496d-9602-07be575867f7'></a>

<::logo: [YOUR LOGO]Your LogoA circular outline contains the bold text "YOUR LOGO" in a stacked arrangement.::>

<a id='7c0d414c-ac95-48ee-805a-1d1ce3903915'></a>

<Your Company Name>
<Your Company Address>
<Your Contact Details>

<a id='9c87a677-f968-4626-b514-25f902b82379'></a>

ISSUE DATE
DUE DATE
INVOICE NUMBER
PO NUMBER

<a id='9db997fd-e76d-4c4a-bf71-ef2db45cd8ae'></a>

BILL TO

<Contact Name>
<Client Company Name>
<Address>
<Phone>
<Email>

<a id='37aeeb04-178e-499f-80c7-0477d5b482ec'></a>

SHIP TO
<Name / Dept>
<Client Company Name>
<Address>
<Phone>

<a id='599c115c-282c-41a9-8452-0c5d07d0968a'></a>

SHIPMENT INFORMATION
P.O. #
P.O. Date
Letter of Credit #
Currency
Payment Terms
Est. Ship Date

<a id='e2dcf8d2-0bff-48b0-928a-41c66320634f'></a>

Mode of Transportation
Transportation Terms
Number of Packages
Est. Gross Weight
Est. Net Weight
Carrier

<a id='bbd8b245-c23f-4172-a594-15a27e28f065'></a>

<table id="0-1">
<tr><td id="0-2">ITEM</td><td id="0-3">QUANTITY</td><td id="0-4">PRICE</td><td id="0-5">TOTAL</td></tr>
<tr><td id="0-6"></td><td id="0-7"></td><td id="0-8"></td><td id="0-9"></td></tr>
<tr><td id="0-a"></td><td id="0-b"></td><td id="0-c"></td><td id="0-d"></td></tr>
<tr><td id="0-e"></td><td id="0-f"></td><td id="0-g"></td><td id="0-h"></td></tr>
<tr><td id="0-i"></td><td id="0-j"></td><td id="0-k"></td><td id="0-l"></td></tr>
<tr><td id="0-m"></td><td id="0-n"></td><td id="0-o"></td><td id="0-p"></td></tr>
<tr><td id="0-q"></td><td id="0-r"></td><td id="0-s"></td><td id="0-t"></td></tr>
</table>

<a id='1ea40639-08ed-43aa-8f15-1630d3117601'></a>

SPECIAL NOTES, TERMS OF SALE

<a id='c36a58c1-b6e4-4cb2-98ba-29486378cd0a'></a>

SUBTOTAL LESS DISCOUNT
0.00

SUBJECT TO SALES TAX
0.00

TAX RATE
0.00%

TOTAL TAX
0.00

SHIPPING/HANDLING
0.00

<a id='132defb5-43c2-487c-98d7-224917348dea'></a>

SUBTOTAL

0.00

<a id='ec2f8e8f-0d76-4dfe-9b17-32c7b1310c4b'></a>

<::attestation: Declaration
Status: unsigned
Signature: illegible
Readable Text: I declare that the above information is true and correct to the best of my knowledge.
Short description: A declaration sentence followed by a signature line and a date line, horizontally aligned.::>

<a id='e56a17bc-0406-4df5-86b2-2ee8084e6b2d'></a>

Powered by Invoice Fly

<a id='346fb128-4ece-42c1-9bba-4bba398f4175'></a>

This invoice was generated with the help of Invoice Fly. To learn more, and create your own free account visit invoicefly.com