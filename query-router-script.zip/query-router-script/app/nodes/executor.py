"""Executor node: invokes skill Python functions directly.

Each skill's run.py exports:
    async def run(query: str, parameters: dict, upstream: dict) -> dict

No subprocess, no stdin/stdout — direct async function call.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from typing import Any

from app.config import settings
from app.skill_registry import registry
from app.state import PlanStep, RouterState, StepResult, StepStatus

logger = logging.getLogger(__name__)


async def _invoke_skill(step: PlanStep, upstream: dict[str, Any]) -> StepResult:
    """Call a skill's run() function directly."""

    run_fn = registry.get_runner(step.skill_name)
    if run_fn is None:
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=f"No runner loaded for skill: {step.skill_name}",
        )

    try:
        # Support both async and sync run functions
        if inspect.iscoroutinefunction(run_fn):
            data = await asyncio.wait_for(
                run_fn(
                    query=step.query,
                    parameters=step.parameters,
                    upstream=upstream,
                ),
                timeout=settings.skill_timeout_seconds,
            )
        else:
            # Wrap sync function in executor
            loop = asyncio.get_running_loop()
            data = await asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    lambda: run_fn(
                        query=step.query,
                        parameters=step.parameters,
                        upstream=upstream,
                    ),
                ),
                timeout=settings.skill_timeout_seconds,
            )
    except asyncio.TimeoutError:
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=f"Skill '{step.skill_name}' timed out after {settings.skill_timeout_seconds}s",
        )
    except Exception as exc:
        logger.exception("Skill '%s' raised an exception", step.skill_name)
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=str(exc),
        )

    return StepResult(
        step_id=step.step_id,
        skill_name=step.skill_name,
        status=StepStatus.SUCCESS,
        data=data,
    )


def _resolve_query(step: PlanStep, results_map: dict[int, StepResult]) -> PlanStep:
    """Replace {step_N_results} placeholders with actual upstream data."""
    query = step.query
    for dep_id in step.depends_on:
        placeholder = "{" + f"step_{dep_id}_results" + "}"
        if placeholder in query:
            dep_data = results_map.get(dep_id)
            replacement = json.dumps(dep_data.data, default=str) if dep_data else "(unavailable)"
            query = query.replace(placeholder, replacement)
    return step.model_copy(update={"query": query})


async def execute_node(state: RouterState) -> dict:
    """Run all steps whose dependencies are satisfied."""

    completed = state.get("completed_ids", set())
    existing_results = state.get("step_results", [])
    results_map = {r.step_id: r for r in existing_results}

    # Find ready steps
    ready: list[PlanStep] = []
    for step in state["plan_steps"]:
        if step.step_id in completed:
            continue
        if all(dep_id in completed for dep_id in step.depends_on):
            ready.append(step)

    if not ready:
        return {}

    # Resolve templates and run in parallel
    tasks = []
    for step in ready:
        resolved = _resolve_query(step, results_map)
        upstream = {
            f"step_{dep_id}_results": results_map[dep_id].data
            for dep_id in step.depends_on
            if dep_id in results_map
        }
        tasks.append(_invoke_skill(resolved, upstream))

    new_results = await asyncio.gather(*tasks)

    return {
        "step_results": list(existing_results) + list(new_results),
        "completed_ids": completed | {r.step_id for r in new_results},
    }
