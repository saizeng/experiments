<a id='79f3e544-c494-4bf0-a5ac-57ba635bef1a'></a>

<::logo: Alpha Automation Pvt. Ltd.
Alpha Automation Pvt. Ltd. Tally
104 - The Grand Apurva, Nr. Hotel Fortune Palace, Digjam Circle, Airport Road, Jamnagar - 361006. (Gujarat) Certified Partner Ph. 0288-2713956/57/58 M. 98250 98442 E-mail: kapil@aaplautomation.com www.aaplautomation.com Sales & Solutions
The logo features a red outlined triangle with a red lowercase alpha symbol inside, alongside the company name in green text and the Tally logo in red.::>

<a id='4b6737c6-d88e-40f1-b129-3898ca89cf11'></a>

<table id="0-1">
<tr><td id="0-2" colspan="3">Debit Memo                                                               TAX INVOICE</td></tr>
<tr><td id="0-3" rowspan="2">GAJENDRA STEEL NEAR PRABHAT MILL, PANCHASAR ROAD, MORBI GST No.: 24AAIFG0955A1ZW PAN No.: AAIFG 0955A</td><td id="0-4">Invoice No: TI/BVN/1953 Invoice Date: 23-Jan-21 PO No. : BY PHONE PO No. : 23-Jan-21</td><td id="0-5" rowspan="3">Passing Date : 22-Jan-21 Due Date : 1-Feb-21 Station : Mumbai Quality : A1 Press Mark : GH12 Broker : HSN Code : 3258596 Payment Terms in Days : 10 DAY</td></tr>
<tr><td id="0-6" rowspan="2">Transport Details: Vehicle No. : GJ04V7232 LR No. : LR-123345 Transporter : Local Transport Driver Mob. No. : 9023726215 Driver Lic. No. : GJ-78-Ettt</td></tr>
<tr><td id="0-7">Delivery Details GAJENDRA STEEL NEAR PRABHAT MILL, PANCHASAR ROAD, MORBI</td></tr>
</table>

<a id='042d7a1b-8388-4c03-813e-ad79153ad828'></a>

<table id="0-8">
<tr><td id="0-9">Description</td><td id="0-a">Qty.</td><td id="0-b">Rate</td><td id="0-c">Amount</td></tr>
<tr><td id="0-d">Cotton Yarn 32 / 1 KW 100% Lot &amp; Press Number Details</td><td id="0-e">1,340.000 KGS (1,34,000 NOS )</td><td id="0-f">99.60</td><td id="0-g">1,33,469.16</td></tr>
<tr><td id="0-h">Lot No. Bales Press No.</td><td id="0-i"></td><td id="0-j"></td><td id="0-k"></td></tr>
<tr><td id="0-l">101 31 3621</td><td id="0-m"></td><td id="0-n"></td><td id="0-o"></td></tr>
<tr><td id="0-p">102 33 3622</td><td id="0-q"></td><td id="0-r"></td><td id="0-s"></td></tr>
<tr><td id="0-t">Gross Wt. : 1,500</td><td id="0-u"></td><td id="0-v"></td><td id="0-w"></td></tr>
<tr><td id="0-x">Tare Wt. : 150</td><td id="0-y"></td><td id="0-z"></td><td id="0-A"></td></tr>
<tr><td id="0-B">Sample Wt.: 10</td><td id="0-C"></td><td id="0-D"></td><td id="0-E"></td></tr>
<tr><td id="0-F">Candy Rate: 35,421</td><td id="0-G"></td><td id="0-H"></td><td id="0-I"></td></tr>
</table>

<a id='7605c0a0-8dfe-4f6c-bfcf-559ae2455be2'></a>

Amount in Words: One Lakh Fifty Seven Thousand Five Hundred Seventeen INR Only

: First Bank Details:

Bank Name: ICICI
Bank Account No.: 023568974110
Bank IFS Code: IC10235614
Bank Branch Name: Lal Bunglow

: Second Bank Details:

Bank Name: State Bank of India
Bank Account No.: 0369857415151
Bank IFS Code: SBI02356565
Bank Branch Name: Digjam Circle

<a id='564f4522-f1c8-4a7c-a43f-6024d5b82934'></a>

<table id="0-J">
<tr><td id="0-K">Sub Total</td><td id="0-L">1,33,469.16</td></tr>
<tr><td id="0-M">CGST</td><td id="0-N">12,012.00</td></tr>
<tr><td id="0-O">SGST</td><td id="0-P">12,012.00</td></tr>
<tr><td id="0-Q">TCS 0.075 %</td><td id="0-R">24.00</td></tr>
<tr><td id="0-S">ROUND OFF +/-</td><td id="0-T">(-)0.16</td></tr>
<tr><td id="0-U">Grand Total</td><td id="0-V">1,57,517.00 ₹</td></tr>
<tr><td id="0-W"></td><td id="0-X"></td></tr>
</table>

<a id='03809291-2a60-4e08-9385-beefd1284294'></a>

<table id="0-Y">
<tr><td id="0-Z" rowspan="2">HSN/SAC</td><td id="0-10" rowspan="2">Taxable Value</td><td id="0-11" colspan="2">Central Tax</td><td id="0-12" colspan="2">State Tax</td><td id="0-13" rowspan="2">Total Tax Amount</td></tr>
<tr><td id="0-14">Rate</td><td id="0-15">Amount</td><td id="0-16">Rate</td><td id="0-17">Amount</td></tr>
<tr><td id="0-18">3258596</td><td id="0-19">1,33,469.16</td><td id="0-1a">9%</td><td id="0-1b">12,012.00</td><td id="0-1c">9%</td><td id="0-1d">12,012.00</td><td id="0-1e">24,024.00</td></tr>
<tr><td id="0-1f">Total</td><td id="0-1g">1,33,469.16</td><td id="0-1h"></td><td id="0-1i">12,012.00</td><td id="0-1j"></td><td id="0-1k">12,012.00</td><td id="0-1l">24,024.00</td></tr>
<tr><td id="0-1m" colspan="7">Terms &amp; Conditions: We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct. Terms and conditions: Subject to Bhavnagar Jurisdiction. This is a Computer Generated Invoice.</td></tr>
</table>

<a id='71619cb3-cf40-499c-a2b6-cbfbdf19a507'></a>

<table id="0-1n">
<tr><td id="0-1o">Company&#x27;s CIN: U51900G J2009PTCO56258 Company&#x27;s GST : 24AAMCS8473N1ZI</td><td id="0-1p">For, Alpha Cotton</td></tr>
<tr><td id="0-1q">Company&#x27;s PAN : AAMCS8473N</td><td id="0-1r">Authorised Signatory</td></tr>
</table>

<a id='994679dc-a6cf-4e60-905f-7120905afb11'></a>

IRN: d3e97bb23242ff072f7fdaef9ec8be2-eb78c983f3b917b44152c39c57b 16 dfd5
Ack No.: 162110310147375
Ack Date: 23-Jan-21

e-Invoice
<::transcription of the content
: QR Code::>