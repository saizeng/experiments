<a id='16219e5b-27a5-45b7-83be-a78182ac9f2f'></a>

<::logo: Undetermined
α
A red lowercase alpha symbol is enclosed within a red triangular shape.::>

<a id='31d7a260-6949-4f5b-9190-065da9b289d3'></a>

ALPHA AUTOMATION PVT. LTD.

104, The Grand Apurva, Nr. Hotel Fortune Palace
Nr. Digjam Circle, Aerodrome Road Jamnagar - 361 006

Phone: 0288-2713956/57/58
Mobile: 90237 26216/17/18

E-Mail: bhavin@aaplautomation.com
Website: www.tallytdl.com

GSTIN: 24AAMCS8473N1ZI
PAN No: AAMCS8473N

<a id='9dad74da-e66c-4cf7-885f-50272829c847'></a>

<::scan_code: QR code
This is a standard QR code, well-defined with clear contrast and no visible defects.::>

<a id='aa54f41f-c7c3-48d2-bb0f-ff4af9ab4b88'></a>

Tax Invoice
<table id="0-1">
<tr><td id="0-2">Invoice No</td><td id="0-3">TI/BVN/1975</td><td id="0-4">Date : 1-Mar-21</td><td id="0-5">Transporter</td><td id="0-6" colspan="2">: KARAN ROADWAY</td></tr>
<tr><td id="0-7">ChallanNo</td><td id="0-8"></td><td id="0-9">Date :</td><td id="0-a">LR. No.</td><td id="0-b">TI/SRT/346</td><td id="0-c">Date : 19-Jan-21</td></tr>
<tr><td id="0-d">OrderNo</td><td id="0-e">BY PHONE</td><td id="0-f">Date : 19-Jan-21</td><td id="0-g">Vehicle No.</td><td id="0-h">:GJ10Z 5873</td><td id="0-i"></td></tr>
<tr><td id="0-j">Payment Term</td><td id="0-k">PAID</td><td id="0-l">Due on: 30 DAYS</td><td id="0-m">Place of Supply</td><td id="0-n">VERAVAL GIR</td><td id="0-o"></td></tr>
<tr><td id="0-p">E Way Bill</td><td id="0-q"></td><td id="0-r"></td><td id="0-s">Booking Point</td><td id="0-t">JIGNESHBHAI</td><td id="0-u">Paid: To Pay:</td></tr>
</table>

<a id='dc73cc59-f416-44c0-b360-526568b24d06'></a>

IRN: 3d9a1ef679026f1b3960f5b680d070c1b8e415d92e6eb85aa722d8ec1c698563
Date: 19-Jan-21
Ack No: 16211028979298

<a id='cf1c94f9-14b6-436e-95eb-85fac5d61e92'></a>

<table id="0-v">
<tr><td id="0-w">Bill To :</td><td id="0-x"></td><td id="0-y">Ship To :</td><td id="0-z"></td></tr>
<tr><td id="0-A">Alpha Enterprise</td><td id="0-B"></td><td id="0-C">Alpha Enterprise</td><td id="0-D"></td></tr>
<tr><td id="0-E" colspan="2">807, Dhan Rajni Complex</td><td id="0-F" colspan="2">807, Dhan Rajni Complex</td></tr>
<tr><td id="0-G">Nr.Hotel Imperial Palace</td><td id="0-H"></td><td id="0-I">N.Hotel Imperial Palace</td><td id="0-J"></td></tr>
<tr><td id="0-K">Dr.Yagnik Road</td><td id="0-L"></td><td id="0-M">Dr.Yagnik Road</td><td id="0-N"></td></tr>
<tr><td id="0-O">Rajkot</td><td id="0-P"></td><td id="0-Q">Rajkot</td><td id="0-R"></td></tr>
<tr><td id="0-S">Pin Code : 361001</td><td id="0-T">Contact No: 9023726216</td><td id="0-U">Pin Code : 361001</td><td id="0-V">Contact No : 9023726217</td></tr>
<tr><td id="0-W">State : Gujarat</td><td id="0-X">State Code: 24</td><td id="0-Y">State : Gujarat</td><td id="0-Z">State Code : 24</td></tr>
<tr><td id="0-10">GSTN: 24AAAG3242A</td><td id="0-11">PAN: AAAG3242A</td><td id="0-12">GSTN: 24AAAG3242A</td><td id="0-13">PAN : AAAG3242A</td></tr>
</table>

<a id='a4f9ef89-dd27-4ef9-89d3-490cc55421c5'></a>

<table id="0-14">
<tr><td id="0-15">S No</td><td id="0-16" colspan="2">Particulars</td><td id="0-17">HSN/SAC</td><td id="0-18">Quantity</td><td id="0-19">Rate</td><td id="0-1a">per</td><td id="0-1b">Disc. %</td><td id="0-1c">Amount</td></tr>
<tr><td id="0-1d">1</td><td id="0-1e">HR COIL - 72083840 ( MIX SIZE )</td><td id="0-1f"></td><td id="0-1g">72083840</td><td id="0-1h">23.700 MTS.</td><td id="0-1i">61,500.00</td><td id="0-1j">MTS.</td><td id="0-1k"></td><td id="0-1l">14,57,550.00</td></tr>
<tr><td id="0-1m"></td><td id="0-1n">5MM X 1250 X 5000@ 82 NOS</td><td id="0-1o"></td><td id="0-1p"></td><td id="0-1q"></td><td id="0-1r"></td><td id="0-1s"></td><td id="0-1t"></td><td id="0-1u"></td></tr>
<tr><td id="0-1v"></td><td id="0-1w">5MM X 1250 X 6300@4 NOS</td><td id="0-1x"></td><td id="0-1y"></td><td id="0-1z"></td><td id="0-1A"></td><td id="0-1B"></td><td id="0-1C"></td><td id="0-1D"></td></tr>
<tr><td id="0-1E"></td><td id="0-1F">5MM X 1250 X 6300@ 24 NOS</td><td id="0-1G"></td><td id="0-1H"></td><td id="0-1I"></td><td id="0-1J"></td><td id="0-1K"></td><td id="0-1L"></td><td id="0-1M"></td></tr>
<tr><td id="0-1N"></td><td id="0-1O"></td><td id="0-1P">CGST</td><td id="0-1Q"></td><td id="0-1R"></td><td id="0-1S"></td><td id="0-1T"></td><td id="0-1U"></td><td id="0-1V">1,31,180.00</td></tr>
<tr><td id="0-1W"></td><td id="0-1X"></td><td id="0-1Y">SGST</td><td id="0-1Z"></td><td id="0-20"></td><td id="0-21"></td><td id="0-22"></td><td id="0-23"></td><td id="0-24">1,31,180.00</td></tr>
<tr><td id="0-25"></td><td id="0-26"></td><td id="0-27">TCS 0.075 %</td><td id="0-28"></td><td id="0-29"></td><td id="0-2a"></td><td id="0-2b"></td><td id="0-2c"></td><td id="0-2d">1,290.00</td></tr>
<tr><td id="0-2e"></td><td id="0-2f"></td><td id="0-2g"></td><td id="0-2h"></td><td id="0-2i"></td><td id="0-2j"></td><td id="0-2k"></td><td id="0-2l"></td><td id="0-2m">17,21,200.00</td></tr>
<tr><td id="0-2n"></td><td id="0-2o" colspan="7">Grand Total</td><td id="0-2p">17,21,200.00 Rs</td></tr>
</table>

<a id='4ae3005b-fbbf-4311-9d16-029f93a03809'></a>

<table id="0-2q">
<tr><td id="0-2r" colspan="7">Seventeen Lakh Twenty One Thousand Two Hundred INR Only</td></tr>
<tr><td id="0-2s" rowspan="2">HSN/SAC</td><td id="0-2t" rowspan="2">Taxable Value</td><td id="0-2u" colspan="2">Central Tax</td><td id="0-2v" colspan="2">State Tax</td><td id="0-2w" rowspan="2">Total Tax Amount</td></tr>
<tr><td id="0-2x">Rate</td><td id="0-2y">Amount</td><td id="0-2z">Rate</td><td id="0-2A">Amount</td></tr>
<tr><td id="0-2B">72083840</td><td id="0-2C">14,57,550.00</td><td id="0-2D">9%</td><td id="0-2E">1,31,180.00</td><td id="0-2F">9%</td><td id="0-2G">1,31,180.00</td><td id="0-2H">2,62,360.00</td></tr>
<tr><td id="0-2I">Total</td><td id="0-2J">14,57,550.00</td><td id="0-2K"></td><td id="0-2L">1,31,180.00</td><td id="0-2M"></td><td id="0-2N">1,31,180.00</td><td id="0-2O">2,62,360.00</td></tr>
</table>

<a id='488a0c6b-cbf9-4b5d-819a-36959a03d525'></a>

<table id="0-2P">
<tr><td id="0-2Q" colspan="2">Tax Amount (in words): Two Lakh Sixty Two Thousand Three Hundred Sixty INR Only</td></tr>
<tr><td id="0-2R">Terms and Condition : we declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</td><td id="0-2S">For, ALPHA AUTOMATION PVT. LTD.</td></tr>
<tr><td id="0-2T">DECLARATION: We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</td><td id="0-2U">Authorised Signatory</td></tr>
</table>