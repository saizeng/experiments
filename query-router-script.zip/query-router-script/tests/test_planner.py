"""Tests for skill registry, state, graph routing, and skill invocation."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from app.state import PlanStep, StepResult, StepStatus, RouterState, ChatMessage
from app.skill_registry import SkillRegistry, _parse_skill_md
from app.graph import _route_after_execute


# ---------------------------------------------------------------------------
# Skill registry
# ---------------------------------------------------------------------------

SAMPLE_SKILL_MD = """\
---
name: test_skill
description: A test skill
trigger: when user says test
category: data_source
parameters:
  - name: query
    type: string
    required: true
---

# Test Skill
"""

SAMPLE_RUN_PY = '''\
async def run(query: str, parameters: dict, upstream: dict) -> dict:
    return {"answer": f"test response for: {query}"}
'''


def test_parse_skill_md(tmp_path: Path):
    (tmp_path / "SKILL.md").write_text(SAMPLE_SKILL_MD)
    m = _parse_skill_md(tmp_path / "SKILL.md")
    assert m is not None
    assert m.name == "test_skill"
    assert m.category == "data_source"


def test_parse_missing_frontmatter(tmp_path: Path):
    (tmp_path / "SKILL.md").write_text("# No frontmatter")
    assert _parse_skill_md(tmp_path / "SKILL.md") is None


def test_registry_loads_runner(tmp_path: Path):
    """Registry discovers SKILL.md and imports run() from run.py."""
    d = tmp_path / "my_skill"
    d.mkdir()
    (d / "SKILL.md").write_text(SAMPLE_SKILL_MD)
    (d / "run.py").write_text(SAMPLE_RUN_PY)

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)

    assert reg.get("test_skill") is not None
    runner = reg.get_runner("test_skill")
    assert runner is not None
    assert callable(runner)


def test_registry_skips_missing_run(tmp_path: Path):
    """Skill with SKILL.md but no run.py is skipped."""
    d = tmp_path / "no_runner"
    d.mkdir()
    (d / "SKILL.md").write_text(
        "---\nname: orphan\ndescription: no runner\n---\n# x\n"
    )

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    assert reg.get("orphan") is None


def test_registry_skips_missing_run_function(tmp_path: Path):
    """Skill with run.py but no `run` function is skipped."""
    d = tmp_path / "bad_runner"
    d.mkdir()
    (d / "SKILL.md").write_text(
        "---\nname: bad\ndescription: bad\n---\n# x\n"
    )
    (d / "run.py").write_text("def not_run(): pass")

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    assert reg.get("bad") is None


@pytest.mark.asyncio
async def test_runner_invocation(tmp_path: Path):
    """Directly invoke a loaded skill runner."""
    d = tmp_path / "invokable"
    d.mkdir()
    (d / "SKILL.md").write_text(SAMPLE_SKILL_MD)
    (d / "run.py").write_text(SAMPLE_RUN_PY)

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    runner = reg.get_runner("test_skill")
    result = await runner(query="hello", parameters={}, upstream={})
    assert result["answer"] == "test response for: hello"


def test_registry_summary(tmp_path: Path):
    d = tmp_path / "s"
    d.mkdir()
    (d / "SKILL.md").write_text(SAMPLE_SKILL_MD)
    (d / "run.py").write_text(SAMPLE_RUN_PY)

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    summary = reg.summary_for_planner()
    assert "test_skill" in summary
    assert "data_source" in summary


# ---------------------------------------------------------------------------
# State models
# ---------------------------------------------------------------------------

def test_chat_message():
    msg = ChatMessage(role="user", content="hello")
    assert msg.role == "user"
    assert msg.plan_steps is None


def test_plan_step():
    s = PlanStep(step_id=1, description="x", skill_name="a", query="q")
    assert s.depends_on == []


# ---------------------------------------------------------------------------
# Graph routing
# ---------------------------------------------------------------------------

def _state(**kw) -> RouterState:
    base: RouterState = {
        "question": "test", "chat_history": [], "reasoning": "",
        "plan_steps": [], "step_results": [], "completed_ids": set(),
        "answer": "", "error": "",
    }
    base.update(kw)
    return base


def test_route_empty():
    assert _route_after_execute(_state()) == "synthesize"


def test_route_error():
    assert _route_after_execute(_state(error="broke")) == "synthesize"


def test_route_all_done():
    steps = [PlanStep(step_id=1, description="x", skill_name="a", query="q")]
    assert _route_after_execute(_state(plan_steps=steps, completed_ids={1})) == "synthesize"


def test_route_ready():
    steps = [PlanStep(step_id=1, description="x", skill_name="a", query="q")]
    assert _route_after_execute(_state(plan_steps=steps)) == "execute"


def test_route_second_wave():
    steps = [
        PlanStep(step_id=1, description="x", skill_name="a", query="q"),
        PlanStep(step_id=2, description="y", skill_name="b", query="q", depends_on=[1]),
    ]
    assert _route_after_execute(_state(plan_steps=steps, completed_ids={1})) == "execute"
    assert _route_after_execute(_state(plan_steps=steps, completed_ids={1, 2})) == "synthesize"
