#!/usr/bin/env python3
"""Unstructured docs skill. TODO: Replace stub with your API call."""
import json, sys

def main():
    payload = json.load(sys.stdin)
    query = payload.get("query", "")
    json.dump({"answer": f"[STUB] Document search for: {query}", "sources": [], "source": "unstructured_docs"}, sys.stdout)

if __name__ == "__main__":
    main()
