<a id='ce5da3b3-8066-40b6-a8d5-5321679c9d09'></a>

<::An image showing stacks of white bags or boxes, each with "UNITED STATES" printed on it multiple times, next to stacks of blue plastic crates.: figure::>

<a id='be694db0-9294-4050-8aea-018a5d8a1b52'></a>

Envisioning America's
Future Postal Service

Options for a Changing Environment

<a id='367e5a7d-a62d-4a6a-be9a-1e4e16d462d2'></a>

March 2, 2010

<a id='3974d2c4-d9c0-4648-aa23-368be7f243ff'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='e68a8841-7237-4e1b-bc2f-6fb96229b325'></a>

<::Image of stacks of blue plastic crates and white plastic containers. The white containers are labeled with text, which includes:
INTEN
UNITED STATES
UNITED STATES
UNITED STATES
NITED STATES
IMITED STATES
UNITED STATTO
UNITED STATES
FASTER STATES
UNITED STATES
UNITED STATES
LUNITED
20
: figure::>

<a id='512c8611-b4f5-4a4d-885f-39d9d25973af'></a>

Today's discussion

<a id='5ea21098-47b6-42d4-b130-a7bf6be37b72'></a>

- Review of economic trends and financial forecast

<a id='0f7dc436-81f2-4af5-958a-7f3734eb038a'></a>

* Value of planned actions

<a id='4f40869e-d0de-4ae8-8c8d-58c70d624410'></a>

- Additional options to ensure a viable Postal Service

<a id='e79754b7-efeb-4ae1-a3ec-11e894268169'></a>

1

<a id='ac927464-5e89-4379-963e-a78c385383f3'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='80c8bc9d-dde2-4255-beac-98930d9440fe'></a>

McKinsey built an integrated forecast and set of options

<a id='fdc7c4f0-304f-4477-b6b0-699e52bd4e5e'></a>

Volume forecast

BCG
THE BOSTON CONSULTING GROUP

Prepared volume and revenue
projections of the USPS core
mailing and shipping business

<a id='1de0a044-d9a6-4d32-b0eb-f5f97f02bc33'></a>

Revenue diversification
research

accenture

Examined revenue diversification
pursued by foreign posts

<a id='4a919279-7c33-464a-8b70-83e131e7ea3b'></a>

Integrated business forecast

McKinsey&Company

Integrated the BCG and
Accenture work with
USPS data

<a id='e6f4efb9-0191-4e8a-b41c-21ccba7e634c'></a>

- Forecast baseline and scenario profitability

<a id='679deeb1-5d7b-4a08-ba05-8b313f963978'></a>

* Assessed a comprehensive list of revenue and cost options

<a id='4d79bddd-4f25-4664-8aa8-43eda5721d06'></a>

2

<a id='6688e16b-3647-4463-bc8b-1d36812cdd4f'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='876a7100-0065-4f9e-b242-8efc651c7b3f'></a>

<::transcription of the content: diagram::>Four trends are increasing pressure on USPS

| Revenue trends            | Cost trends                   |
|:--------------------------|:------------------------------|
| **Volume**                | **Universal Service Obligation** |
| Declining steadily        | Large fixed cost base         |
|                           |                               |
| <::visual content: logo: UNITED STATES POSTAL SERVICE::> |
|                           |                               |
| **Price**                 | **Workforce costs**           |
| Rising but capped         | Rising cost per hour          |
<::/transcription of the content: diagram::>

<a id='cb77a8bd-7ae2-4901-8565-c018fa242472'></a>

3

<a id='58a34272-484b-4f13-8152-b9090eb3a9e0'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='6518a693-c4e4-41eb-90f4-707ac93fe9e7'></a>

Price: Price increases combine with volume declines for flat revenue through 2020

<a id='57fae697-1050-44c3-bd69-7bedd5870784'></a>

Volumes declining
-1.5% per year from
2009-2020

X

Prices rising
with inflation
+1.9% per year from
2009-2020

<a id='82ac25fb-a5b7-4a13-9a2f-06388b0184b2'></a>

<::USPS revenue in Billions, presented as a waterfall chart.The chart starts with "2009 revenue" at $68 B. There is a decrease of $16 due to "Volume decline & mix shift", followed by an increase of $17 due to "Price impact". The chart concludes with "2020 revenue" at $69 B.
: chart::>

<a id='ce84f4ef-93db-4e26-ab07-e13941e40601'></a>

4

<a id='8bd5cdb7-d668-47b3-a051-41446cc3b5c1'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='c5d9393a-ca26-4473-a196-5ceb2879b3de'></a>

Revenue trends: Declines focused in higher contribution First-Class Mail <::chart: This bar chart displays volume trends in billion pieces for First-Class and Standard mail, comparing data from 2009 and 2020. Volume is measured in Billion pieces. For First-Class mail, the volume decreased from 84 in 2009 to 53 in 2020, representing a -37% change. For Standard mail, the volume increased from 83 in 2009 to 86 in 2020, representing a +4% change. Below the chart, the "Portion of total margin available to cover fixed costs (2009)" is shown as 71% for First-Class mail and 21% for Standard mail.::>

<a id='9ca13688-e8a0-4689-bda1-c7f2587b8656'></a>

5

<a id='d9f87811-ec99-4c13-adfc-2fe539190c75'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='925e5a99-bcfc-444a-b9cc-f9413a9b79a1'></a>

Universal Service Obligation

<a id='1004e63b-cb63-4406-b040-28c7999a928e'></a>

<::A composite image with a stylized map of the United States (including Alaska and Hawaii) in white on a dark blue background. Overlaid on the map are three photographs and text. The top photograph shows a post office building with a blue awning and the USPS logo. A sign on the building reads: UNITED STATES POST OFFICE UPTOWN STATION HOBOKEN, NEW JERSEY 070. The bottom left photograph shows an open black mailbox on a wooden post, containing several envelopes, set against a cloudy sky. The bottom right photograph depicts complex mail sorting machinery with multiple compartments. The central text reads: Network was historically built to provide high service levels to customers, regardless of volumes
: composite image::>

<a id='6759b551-a202-42ea-970f-c9ebc75e0b3a'></a>

6

<a id='da58a5a2-6252-414d-bdb7-fc9cf2f5f002'></a>

<::McKinsey&Company: figure::>

<!-- PAGE BREAK -->

<a id='20ae4305-04c3-4b76-939c-34404eab8cfb'></a>

Universal Service Obligation:
Customer service network costs are largely fixed

<a id='5198eb65-1513-4db0-894e-bccb85543839'></a>

<::A photograph of the exterior of a United States Post Office building. The building has a reddish-brown facade with horizontal siding. Above the main entrance, a blue awning with the white USPS eagle logo is visible. On the building facade, white text reads "UNITED STATES POST OFFICE UPTOWN STATION HOBOKEN, NEW JERSEY 070". Below the text and awning are large glass windows reflecting the surrounding environment.: figure::>

<a id='1ede460a-444a-4805-ad27-e58e181b6160'></a>

<::U.S. retail locations chart::>
<::Title: U.S. retail locations
Unit: Thousands

Bar chart data:
- USPS: 36.5
- McDonalds: 13.9
- Starbucks: 11.1
- Walgreens: 7.5
- Walmart: 3.6
: chart::>

<a id='e9c61d62-a000-4dd6-91e9-7e078733b857'></a>

Service network

- 600 weekly counter customers at the average Post Office, 1/10th of Walgreens
- Prohibited from closing Post Offices solely for economic reasons

<a id='84a7336b-bb6c-4aa8-b3ac-3f924cb03143'></a>

7

<a id='f144b9fe-4167-4f55-ac8b-513f9f632dfe'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='6c210eda-b2d1-4a2d-a10e-59fcbdc15964'></a>

Universal Service Obligation:
Processing overhead costs are largely fixed

<a id='a2b63a1b-3c8a-48a2-a9c1-d6ceb7f4a6d9'></a>

<::An industrial machine with multiple black compartments, some filled with papers or cards, and others containing mechanical components and wiring. A cylindrical silver object is visible near the center. The machine appears to be a sorting or processing unit.: figure::>

<a id='2b7b05e1-b7a6-41bd-98f4-6ffa6c438af5'></a>

600 processing facilities
---
~12 for every state

<a id='591f645b-f4a1-45cf-9e9e-4295599ce149'></a>

# Sortation plants

* Ensure overnight delivery of local mail
* Network largely fixed
* Volume declines are rapidly reducing economies of scale

<a id='42ff6084-65ef-4ae8-8f49-0347ee100add'></a>

8

<a id='b24de151-b16a-4357-b3b4-c5044bcaa0e1'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='2efc94c6-15f0-4d86-bf03-466466c93906'></a>

Universal Service Obligation:
Delivery requirements are growing

<a id='d83b815d-9760-4d07-a5ef-a763e3e66f04'></a>

<::A photograph of a black mailbox with its door open, revealing several colorful envelopes inside. The mailbox is mounted on a wooden post against a sky with white clouds. To the right is a bar chart titled "Addresses Millions". The chart shows two bars: one for 2009 with a value of 150, and one for 2020 with a value of 162. An arrow with a circular orange label indicates a "+8%" increase from 2009 to 2020.
: figure::>

<a id='7d065dcd-0c11-4fc6-8b97-5a964098f426'></a>

Delivery network
* Deliver to every address in America
* 6-day delivery
* Corresponding high fixed delivery cost

<a id='46ecd14a-8b92-4277-a965-34f37cbc7cf6'></a>

9

<a id='2d6b5206-ae89-4d98-b9fe-e40eaad4d85b'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='962e24ec-1c0e-4a45-b752-d59dd26b1a6b'></a>

Workforce costs:
Continue to rise faster than inflation

<a id='0e95424a-32e8-442a-98ba-74cf892a57db'></a>

<::bar chart::>Workforce annual rate increases, 2010-2020
Percent

Bar 1:
Label: Wages
Value: 1.3-2.5

Bar 2:
Label: Workers' compensation
Value: 2.0-4.0

Bar 3:
Label: Health benefits
Value: 4.7-5.2

Inflation line (dotted yellow):
Value: 1.9%
Label: Inflation (CPI at 1.9%)::>

<a id='f19b54ab-e586-4a85-8c06-fa4c3b6bfba5'></a>

10

<a id='0cf6510f-7785-40ce-a734-185f1bb80828'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='d05e2969-3136-4942-8415-1dd8f242a200'></a>

Workforce costs: Required Retiree Health Benefit funding is substantial from 2010-2016

<a id='ec579a58-d436-47cd-babc-82f0456ba255'></a>

<::A large modern building with a sign that reads "Medical Center" on the side. The building has multiple stories, with the upper section featuring large blue-tinted windows and the lower sections constructed with light brown brick or stone. A covered entrance area with large pillars is visible in the foreground, leading into the building. The sky is clear blue. There are some trees without leaves and a mountain range in the background on the left. The foreground shows a paved area, possibly a parking lot or driveway, with yellow bollards and red markings.: figure::>

<a id='433823fc-3289-49c8-b635-c01e99d75aa4'></a>

<::A smiling male doctor wearing a white lab coat, a light blue collared shirt, and a red patterned tie, with a stethoscope draped around his neck. He has short dark hair and a light beard. The background is a solid dark blue with a subtle lighter blue curved shape visible behind his head.: figure::>

<a id='52173f4d-0a8f-45fc-a0ee-b75a92807a5d'></a>

# Required Annual Retiree Health Benefit (RHB) funding

2005: $1.5 billion

2010-16: $9.0 billion average

# Percent of total revenues 2010-16

12-16%

<a id='dd89817b-18f8-42e6-8b7c-976bd8e17862'></a>

11

<a id='a85285e5-f414-4c04-a6cc-182e226b32bf'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='5f44072b-d51e-469f-8b63-a8d121378ed6'></a>

Recent losses are forecast to grow without changes <::Net profit/loss line chart showing $ Billions on the Y-axis (from -30 to 10) and years on the X-axis (from 2000 to 2020). The chart is divided into 'Actual' (2000-2009) and 'Forecast' (2009-2020) sections by a vertical dotted line at 2009. The line graph shows actual profit/loss fluctuating, going below zero around 2002-2003 and again around 2008-2009. The forecast section shows a continuous decline into negative territory. A shaded area under the forecast line indicates a 'Cumulative loss 2010-2020 $238 billion'. A small yellow square with the number '33' is at the bottom right corner of the shaded forecast area, near the year 2020.: chart::>

<a id='92fc542e-62bf-416b-8858-51455603238b'></a>

12

<a id='a7ed7779-fb3f-496e-b922-fa57d2c99a24'></a>

<::McKinsey&Company
: figure::>

<!-- PAGE BREAK -->

<a id='b2e22d24-968c-4986-b9b9-3e14c777cb7e'></a>

<::
Actions within Postal Service control: Four sets of actions could reduce the 2020 gap by $18 B

| Actions | Net profit benefit in 2020 ($ Billions) |
| :----------------------------------- | :------------------------------------- |
| 1 Product and service actions | ~2 |
| 2 Productivity improvements | ~10 |
| 3 Workforce flexibility improvements | ~0.5 |
| 4 Purchasing savings | ~0.5 |
| Avoided interest due to reduced debt | ~5 |
| Total | ~18 |
| Cumulative impact 2010-2020 | ~123 |
: table::>

<a id='336a2f83-9c56-410e-bfc0-223e05e8dc83'></a>

13

<a id='a4815973-4a9e-4c12-aa2c-d17499ef822e'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='9be1f535-9643-407e-a395-2c8c9b1f80d3'></a>

Actions within Postal Service control will improve long-term sustainability, but a gap will remain
<::chart: Line graph titled "Actions within Postal Service control will improve long-term sustainability, but a gap will remain" showing Net income in $ Billions over time.

Y-axis (Net income, $ Billions) ranges from -35 to 10, with major ticks at -35, -30, -25, -20, -15, -10, -5, 0, 5, 10.
X-axis shows years 2005, 2009, 2020.

The graph is divided into two sections by a dotted vertical line at 2009.

Left section (before 2009) is labeled "Actual". The net income line starts near 0 in 2005, dips to around -5, then rises slightly before dipping again towards -5 by 2009.

Right section (after 2009) is labeled "Forecast". The net income line continues to decline, showing increasing losses. The area under the forecast line is shaded, representing cumulative loss.

Text within the shaded forecast area indicates: "Cumulative loss 2010-2020 $115 billion".

Two callouts with arrows point to different levels of loss in the forecast period:
1. An arrow points to a level around -15 to -20 on the Y-axis, labeled "($15B)". Associated text reads: "Actions within the Postal Service control will reduce annual loss to $15 billion, cumulative loss to $115 billion".
2. Another arrow points to a lower level around -33 on the Y-axis, labeled "($33B)". Associated text reads: "Base case without product, service or productivity actions".
: figure::>

<a id='3641a810-258e-49dd-9390-ccfe0db5c67a'></a>

14

<a id='04fd4aee-c8bd-4e58-be57-14fea15b0c51'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='0b5e665c-fde4-4de8-a2f2-a5eed6507a28'></a>

McKinsey examined an extensive range of options

<a id='db37d081-f225-438c-b68a-2f4a3650f17e'></a>

50+ options considered

*   Aggressive internal cost improvement options across the organization
*   Products and services options from:
    *   Foreign posts (banking, logistics)
    *   Private sector firms
    *   Other government entities
    *   The Postal Service
*   Other product and service extensions from existing assets
*   Pricing actions
*   Privatization

<a id='89382c78-f1a4-4056-9255-bf69a70b6e06'></a>

Filtered on criteria

- Overall profit impact
- Impact on customers and mailers
- U.S. specific-industry dynamics
- Time and capital investment required
- Feasibility

<a id='db0ff6e8-6176-468a-8fa2-65bf8f48b33f'></a>

15

<a id='8706aede-8798-4913-a55d-678347656800'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='a3501c27-ef75-45e7-a729-18b96351c190'></a>

Privatization: An unlikely option for USPS

<a id='21ebb2e4-c4fa-4d5f-9024-da4ad03a21a3'></a>

<::A line chart with a y-axis labeled 20, 40, 60, 80, 100 and an x-axis labeled 1 through 12. Multiple colored lines plot data points. A magnifying glass is positioned over the upper right portion of the chart. A partial table of values is visible next to the chart, including 63,04, 52,30, 97,54, 87,45, 99,32, 90,59.: chart::> Investors require a clear path to profitability before acquisition. Changes USPS requires to become attractive to investors are more extensive than those required to ensure a viable government entity.

<a id='18db99d2-3e39-4474-a8e9-78d134f6cf89'></a>

- The scale and associated risk further limit investor interest in the business

<a id='3eb00c5f-fec6-4be9-93b3-b2d58d449e39'></a>

* Even after a privatization, U.S. Government would need to maintain implicit or explicit support for the Postal Service

<a id='caaf0bc3-0eb8-4556-91df-c0aca303d315'></a>

16

<a id='9abde588-8521-46b9-8a37-f0f34f573e21'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='832c1e11-a14b-4a91-abf9-c175f895183c'></a>

Fundamental change: Options exist across five areas to address the remaining $15 billion gap

<a id='71858b2f-19c7-4aef-97e4-e3162edab62b'></a>

<::The image displays a blue background with several elements. On the left, a white cardboard box with "PRIORITY MAIL" branding is shown, next to which the text "Products and services" is displayed in white font. In the upper right, a postage stamp featuring the American flag and the text "USA44" is visible, with the word "Pricing" in white font next to it. In the lower right, a large blue oval shape contains the text "Remaining FY 2020 gap = $15 billion" in yellow font.: figure::>

<a id='4fc3bfd9-3e0e-41d4-908d-48b6854f82c0'></a>

<::A map of the United States is shown, filled with the pattern of the American flag (red and white stripes, blue field with white stars). The text "Service levels" is overlaid in white text on the upper right side of the map.
: figure::>

<a id='e3b1c503-ce51-415a-b61d-b2ffd1bd68fd'></a>

<:: Public policy considerations. A night-time image of the US Capitol building, illuminated with lights, against a dark blue sky.: figure::>

<a id='ec4dd2a3-a446-4f2d-87e9-b78539bbc666'></a>

<::A photograph of a female postal worker in a blue uniform holding a stack of mail and magazines. An American flag is visible in the background. To the right, a dark blue panel has the word "Workforce" in large white letters.
: photo::>

<a id='71b8ed3a-77ce-43cb-a198-dfda11eb889a'></a>

17

<a id='db277ab5-5c9e-4806-bfd6-62908f75a9a3'></a>

<::McKinsey&Company
: figure::>

<!-- PAGE BREAK -->

<a id='b35c1275-4b32-4084-99b9-505924d6e826'></a>

Fundamental change options:
Products and services

<a id='c09032bf-672c-41cf-8cbe-bd9cb84c6b60'></a>

Create new products and services
consistent with USPS mission

<a id='139a6616-2708-4d08-be64-8ccb6fa53c8b'></a>

<::A conceptual graphic depicts a white laptop computer with a blue screen. On the screen, a stack of various mail items, including white envelopes and brown padded envelopes, is visible. A red mailbox flag extends from the top left corner of the laptop, suggesting mail delivery or integration. The text, "Develop a suite of hybrid mail products that integrate electronic and physical mail," is displayed alongside this graphic on a dark blue background, forming a cohesive visual element.
: figure::>

<a id='7e225326-3641-4213-9bf7-a421d81f5e0a'></a>

freshFX

$150 off
Any Service

914-232-4405

REMOVE & PREVENT
MOLD & INFECTIOUS GERMS
In Your Home or Business.

PROTECT

<::transcription of the content
: figure::>

For Our Best Price... [illegible]

* All Natural Products • 99.9% Effective
* Certified Mold Professionals [illegible]
* Safe, Non-Toxic, Non-Caustic
* Protects against future germs • Fast & friendly application
* Fights against allergens, [illegible] odors,
  [illegible], MRSA, [illegible], [illegible] & [illegible], mildew & [illegible]

The first
PREVENTATIVE
MOLD & GERM SOLUTION

CALL NOW FOR WINTER PRICING

INTEX

FREE ESTIMATION
[illegible]

[illegible] owned & operated • www.freshfx.org

[illegible] services with organically clean
and disinfected critical areas of your home
AND [illegible] and PROTECT them
with a SAFE & ALL NATURAL [illegible]
Over [illegible] as 200% of all germs [illegible]
[illegible] 914-232-4405

<a id='70126822-66c2-4e35-b9be-5d5f40c0515f'></a>

Simplify advertising products

<a id='22f311c0-abba-4e20-a9a6-fe47cdccc414'></a>

18

<a id='bba8184f-c196-4f2f-98bd-a6f8c9995fe3'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='6c0a05b3-9461-4f4e-a0fb-2bcf7c26c44a'></a>

Fundamental change options: Pricing

<a id='b67660e0-674d-4db6-8b77-b6f87d489134'></a>

Modify price cap to apply across all market dominant products rather than by class

Apply exigent price increase

Increase prices on select products to cover costs:
* Periodicals
* Nonprofit mail
* Media and Library mail

<a id='d2d84012-0d7f-4700-ac7b-96d88f0ed63b'></a>

19

<a id='a05a4f9c-6dce-45be-90c5-bd51c5f8c5f8'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='22dbbb47-c6ce-4a73-9f10-0879a713ceb4'></a>

Fundamental change options: Service levels

<a id='3c8ccc23-a817-4c6a-9363-398353580790'></a>

<::transcription of the content
: figure::>

Change service levels from 1-3 day
to 2-5 day delivery for First Class Mail

<a id='a40c30a6-abf1-470f-ba42-156eeaf589dc'></a>

<::A mail carrier in a blue jacket is standing next to a white mail truck. The text next to the mail carrier reads: Reduce delivery frequency to 3 days or 5 days per week. Change delivery location to curb or cluster boxes.
: figure::>

<a id='3c52ae5f-bb73-41d2-adaa-c98bd10f3d17'></a>

<::screenshot: The Postal Store website showing various stamp products for sale. The header includes navigation links: Quick Order, My Account, FAQs, Stamps, For Mailing, Shipping, For Fun, For Collecting. Below the header, there's a "Shop our Sale" link. Featured items include: "p.s. I Love You" themed stamps, "Buy a Coil of 100 Stamps" for $44.00, and "Vancouver 2010 Olympic Winter Games" stamps for $8.30. Below the "p.s. I Love You" section, there's a button that says "View our Collection". Below the "Vancouver 2010 Olympic Winter Games" stamps, there's a "BUY" button.:.>
Expand access through
alternative channels
* Private sector retail partnerships
* Kiosks
* Direct (e.g., online, mobile) 

<a id='9bc65c9b-d7c0-490f-aa8f-39677908edda'></a>

20

<a id='a1463cb8-bef3-4d2d-a2a1-6df8461b18fb'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='dcffe53d-a482-45b8-b26a-ca65f0ccf6db'></a>

Fundamental change options: Workforce

<a id='e3751800-0c84-4799-93fe-8ab5bbd1dea3'></a>

<::A woman in a light-colored sleeveless top over a brown long-sleeved shirt is working in what appears to be a mail or package sorting facility. She is looking down, focused on handling a stack of white envelopes or flat packages on a conveyor belt or sorting table. To her left, there's an open cardboard box and other items on the table. In the background, there are automated sorting machines or conveyor systems with various packages and boxes, and shelves filled with bins or mail slots. The overall impression is of an industrial or postal work environment.: figure::>

<a id='e747fc7a-a4aa-4806-b1a7-2e3bd74a30b0'></a>

Improve workforce flexibility
by changing the employee mix and taking
advantage of over 300,000 voluntary
separations over the next 10 years

<a id='98c484c3-176e-4223-9b07-a321a02c0859'></a>

<::A 3D bar chart with red and white bars showing an increasing trend, overlaid with a green line graph also showing an upward trend. Faint numbers are visible in the background.: chart::>

<a id='dc394c15-6127-4e20-97ac-bd334397ad94'></a>

Align workforce costs with overall
market trends and inflation

<a id='41f6d525-0a11-4ca9-b62c-dd81e327b2ca'></a>

21

<a id='bd9d7130-4786-4437-9c22-c2ad185772c1'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='f1165f7b-4e66-4ada-b894-ef8d53bdb2b5'></a>

Fundamental change: Public policy considerations

<a id='5486c02b-5efb-4b87-b9f4-e44a428ec0c5'></a>

Restructure RHB pre-funding

* Defer payments
* Shift to a "pay-as-you-go" system comparable to other federal agencies and private companies

<a id='d70f23fd-e935-4f65-8648-03461c577e4b'></a>

<::Image of the US Capitol building at dusk, with its dome illuminated.: image::>Receive Universal Service Obligation subsidies through Federal appropriations

<a id='92f5a2f7-e401-4ed6-ad52-e8fa2f06289a'></a>

<::An image of an eagle flying, set against a light blue sky, on the left. On the right, against a dark blue background with lighter blue diagonal stripes, is the text: "Streamline oversight model to improve flexibility and timeliness". The words "Streamline oversight model" are in yellow, and "to improve flexibility and timeliness" are in white.: figure::>

<a id='2e4c6e85-72aa-422c-8d76-88da962b4ee7'></a>

22

<a id='e231ea10-9d5a-483f-bb99-68d20dac3b71'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='b537ef02-3c1b-42d0-a2b1-6cd8481e8aee'></a>

Closing perspective

<a id='be1c8fe3-04e4-475a-8db7-44b731291e83'></a>

Even undertaking all opportunities within Postal Service
control, USPS is facing a cumulative $115 billion loss

<a id='a336deee-e4f2-4dae-96ee-5cd3a99896ed'></a>

Actions in any one area will not be enough to close this gap

<a id='f76f9f28-2e3c-4255-af28-67fa3719b1c8'></a>

Pursuing multiple actions can result in enhanced customer service and a financially viable operating model

<a id='275e4471-798b-42e7-b392-ea8cb935b4db'></a>

Legislative and regulatory changes are necessary and will require cooperation from multiple stakeholders

<a id='ce6d3947-90c3-431f-bcdd-43d00a79acda'></a>

23

<a id='f5e98590-37cd-405f-b4ac-c89b2d8ba8cf'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='3ade394a-20f8-4d69-83e3-9664d1fc52ab'></a>

<::An image showing stacks of white containers with the text "UNITED STATES" repeatedly printed on them. To the left, there are stacks of blue plastic crates, with a few brown crates interspersed. The white containers appear to be flat or folded, creating multiple layers, each bearing the text. The visible text on the white containers includes:
INTEN
UNITED STATES
UNITED STATES
UNITED STATES
NITED STATES
IMITED STATES
UNITED STATTO
UNITED STATES
FASTER STATES
UNITED STATES
UNITED STATES
LUNITED
20
: image::>

<a id='9d91bced-4a5f-46cd-83b5-b4f5929b453f'></a>

Envisioning America's
Future Postal Service
Options for a Changing Environment

<a id='2548dce6-3553-45d9-9504-cae4a716d6e3'></a>

March 2, 2010

<a id='60e34201-9a40-4dd3-94cf-e667a4fc4b15'></a>

24

<a id='f17d7c02-8660-4e5c-b161-0dc17ee7c48d'></a>

McKinsey&Company