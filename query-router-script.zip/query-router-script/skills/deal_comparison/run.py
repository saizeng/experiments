"""Deal comparison skill. TODO: Replace stub."""


async def run(query: str, parameters: dict, upstream: dict) -> dict:
    deal_ids = parameters.get("deal_ids", [])
    return {
        "comparison_table": [],
        "summary": f"Stub comparison of {len(deal_ids)} deals.",
        "deals_analyzed": len(deal_ids),
    }
