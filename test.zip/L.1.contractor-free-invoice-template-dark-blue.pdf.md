<a id='4b15a303-3b18-43bb-af7e-68d3a4ec1145'></a>

<::logo: [YOUR LOGO]Your LogoA circular outline contains the bold text "YOUR LOGO" in a stacked arrangement.::>

<a id='644a00b0-209f-49ad-8b7b-61d8aee27d34'></a>

<Your Company Name>
<Your Company Address>
<Your Contact Details>

<a id='2d0ce8c2-817c-41f0-84df-2794bd57fcc2'></a>

ISSUE DATE
DUE DATE
INVOICE NUMBER
PO NUMBER

<a id='791813d1-fad8-4212-bbcb-1de35bfcbd88'></a>

BILL TO

<Contact Name>
<Client Company Name>
<Address>
<Phone>
<Email>

<a id='b8ca07a5-c427-4a5d-b7a2-6672a20762b7'></a>

SHIP TO
<Name / Dept>
<Client Company Name>
<Address>
<Phone>

<a id='745de6c6-cb30-4edb-9a57-80bf0e8c9bd3'></a>

SHIPMENT INFORMATION
P.O. #
P.O. Date
Letter of Credit #
Currency
Payment Terms
Est. Ship Date

<a id='3b59ef9f-9947-4e61-973e-1cb5ea950ebc'></a>

Mode of Transportation
Transportation Terms
Number of Packages
Est. Gross Weight
Est. Net Weight
Carrier

<a id='23bf44f6-e060-405f-9568-13b2359eacfd'></a>

<table id="0-1">
<tr><td id="0-2">ITEM</td><td id="0-3">QUANTITY</td><td id="0-4">PRICE</td><td id="0-5">TOTAL</td></tr>
<tr><td id="0-6"></td><td id="0-7"></td><td id="0-8"></td><td id="0-9"></td></tr>
<tr><td id="0-a"></td><td id="0-b"></td><td id="0-c"></td><td id="0-d"></td></tr>
<tr><td id="0-e"></td><td id="0-f"></td><td id="0-g"></td><td id="0-h"></td></tr>
<tr><td id="0-i"></td><td id="0-j"></td><td id="0-k"></td><td id="0-l"></td></tr>
<tr><td id="0-m"></td><td id="0-n"></td><td id="0-o"></td><td id="0-p"></td></tr>
<tr><td id="0-q"></td><td id="0-r"></td><td id="0-s"></td><td id="0-t"></td></tr>
</table>

<a id='2c2368e4-c2cf-4521-b0ba-a0ced6aaa4ba'></a>

SPECIAL NOTES, TERMS OF SALE

<a id='f13fae15-64f8-4a8b-a949-2279814eb7c6'></a>

SUBTOTAL LESS DISCOUNT
0.00

SUBJECT TO SALES TAX
0.00

TAX RATE
0.00%

TOTAL TAX
0.00

SHIPPING/HANDLING
0.00

<a id='b23ba55d-c10f-4d6e-a171-129431da94f5'></a>

SUBTOTAL

0.00

<a id='a69ae411-2fb5-45ea-9b9a-9d465c4523dc'></a>

<::attestation: Declaration and Signature
Signature: illegible
Readable Text: I declare that the above information is true and correct to the best of my knowledge.
Signature _______________
Date _______________
Short description of visual elements and positioning: A declaration statement is followed by a blank line labeled 'Signature' and another blank line labeled 'Date', placed side-by-side below the declaration.::>

<a id='c26d5955-aba9-42ac-b3c4-280bf5d1f533'></a>

Powered by Invoice Fly

<a id='924620fd-6040-4c35-b4cb-68ad2a40b76b'></a>

This invoice was generated with the help of Invoice Fly. To learn more, and create your own free account visit invoicefly.com