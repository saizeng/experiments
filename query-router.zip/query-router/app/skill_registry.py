"""Discovers and loads skill manifests from SKILL.md files."""

from __future__ import annotations

import logging
from pathlib import Path

import yaml

from app.models import SkillManifest, SkillParameter

logger = logging.getLogger(__name__)

_FRONTMATTER_DELIMITER = "---"


def _parse_skill_md(path: Path) -> SkillManifest | None:
    """Parse a SKILL.md file into a SkillManifest.

    Expected format:
        ---
        name: my_skill
        description: Does something useful
        trigger: when user asks for X
        category: data_source
        parameters:
          - name: query
            type: string
            required: true
        ---

        # Skill Title
        Body markdown...
    """
    try:
        text = path.read_text(encoding="utf-8")
    except Exception as exc:
        logger.warning("Could not read %s: %s", path, exc)
        return None

    parts = text.split(_FRONTMATTER_DELIMITER, maxsplit=2)
    if len(parts) < 3:
        logger.warning("No YAML frontmatter found in %s", path)
        return None

    frontmatter_raw = parts[1].strip()
    body = parts[2].strip()

    try:
        meta = yaml.safe_load(frontmatter_raw)
    except yaml.YAMLError as exc:
        logger.warning("Invalid YAML in %s: %s", path, exc)
        return None

    if not isinstance(meta, dict) or "name" not in meta or "description" not in meta:
        logger.warning("SKILL.md at %s missing required 'name' or 'description'", path)
        return None

    params = [
        SkillParameter(**p) for p in meta.get("parameters", []) if isinstance(p, dict)
    ]

    return SkillManifest(
        name=meta["name"],
        description=meta["description"],
        trigger=meta.get("trigger", ""),
        category=meta.get("category", ""),
        parameters=params,
        folder_path=str(path.parent),
        skill_md_raw=body,
    )


class SkillRegistry:
    """Discovers SKILL.md files in a directory tree and provides lookup."""

    def __init__(self) -> None:
        self._skills: dict[str, SkillManifest] = {}

    def load_from_directory(self, root: str | Path) -> None:
        root_path = Path(root)
        if not root_path.is_dir():
            logger.warning("Skills directory does not exist: %s", root_path)
            return

        for skill_path in root_path.rglob("SKILL.md"):
            manifest = _parse_skill_md(skill_path)
            if manifest:
                self._skills[manifest.name] = manifest
                logger.info(
                    "Registered skill: %s [%s] (%s)",
                    manifest.name,
                    manifest.category or "uncategorized",
                    skill_path,
                )

    def get(self, name: str) -> SkillManifest | None:
        return self._skills.get(name)

    def list_all(self) -> list[SkillManifest]:
        return list(self._skills.values())

    def summary_for_planner(self) -> str:
        """Return a compact text block listing all skills for the planner prompt.

        Groups skills by category for clarity.
        """
        if not self._skills:
            return "No skills are registered."

        # Group by category
        by_cat: dict[str, list[SkillManifest]] = {}
        for s in self._skills.values():
            cat = s.category or "other"
            by_cat.setdefault(cat, []).append(s)

        lines: list[str] = []
        for cat, skills in sorted(by_cat.items()):
            lines.append(f"\n### {cat}")
            for s in skills:
                param_desc = ", ".join(
                    f"{p.name}: {p.type}{'*' if p.required else ''}"
                    for p in s.parameters
                )
                lines.append(f"- **{s.name}** — {s.description}")
                if s.trigger:
                    lines.append(f"  Trigger: {s.trigger}")
                if param_desc:
                    lines.append(f"  Params: ({param_desc})")
        return "\n".join(lines)


# Module-level singleton
registry = SkillRegistry()
