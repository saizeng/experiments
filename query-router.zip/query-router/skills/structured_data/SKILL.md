---
name: structured_data
description: >
  Chatbot API for structured deal data. Answers questions about deals,
  clients, interactions, revenue, expenses, and wallet. Use for any
  quantitative lookup, metric, aggregation, entity search, or timeline
  query that can be answered from structured records.
trigger: >
  when user asks about deal metrics, revenue, expenses, client info,
  interaction history, wallet data, pipeline numbers, or any
  quantitative / entity-level question
category: data_source
parameters:
  - name: query
    type: string
    required: true
    description: Natural-language question to send to the structured data chatbot
---

# Structured Data Skill

Wraps the structured-data chatbot API that has access to:
- **Deals** — deal ID, name, value, stage, type (IPO/M&A/BizDev/Debt), dates
- **Clients** — client ID, name, sector, region, relationship tier
- **Interactions** — meeting notes, call logs, emails (metadata + summaries)
- **Revenue** — booked revenue by deal, client, period
- **Expenses** — cost allocations by deal, client, period
- **Wallet** — share-of-wallet estimates per client

## run.py contract

- Reads JSON from stdin: `{"query": "...", "parameters": {}, "upstream": {}}`
- Calls the chatbot API endpoint
- Writes JSON to stdout: `{"answer": "..."}`
