<a id='0ed277ff-3b0c-4b30-81bf-51e7d1da9a88'></a>

<::Logo: A white rounded rectangle with a blue cube icon on the left. To the right of the cube, the text "WORLD MATERIALS FORUM" is displayed in a light gray, sans-serif font. "WORLD" is on the top line, with "MATERIALS" below it in a larger, bold blue font, and "FORUM" below that in a light gray font. The background of the image features a faded blue industrial-looking structure and a wavy texture at the bottom.: figure::>

<a id='7482aedc-d700-4b12-ae27-3b1cf2d3d4a3'></a>

Challenges in Mining:
Scarcity or Opportunity?

<a id='64ab312a-306a-49a2-ad1f-6c6e8949098f'></a>

Contribution of Advanced Technologies

<a id='c719d1fc-55ab-48fb-af40-d71f16c69c81'></a>

World Materials Forum
June 23, 2015

<a id='cfe5ae5a-d7a1-47dc-9757-167d4af02bca'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='c49643fa-c81b-41b6-be97-02234e70b088'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='3823c235-ab42-488d-8fa6-85a21a6f516f'></a>

**Mining productivity globally has declined ~30% over the past decade**

<a id='ba4a2cf6-3240-4f9a-99ae-c2c026c6b4c2'></a>

McKinsey Mining Productivity Index, 2004 = 100<::chart: A line chart titled "McKinsey Mining Productivity Index, 2004 = 100" shows two lines representing productivity trends from 2004 to 2013. The Y-axis ranges from 65 to 110 in increments of 5. The X-axis shows years from 2004 to 2013. The first line starts at 105 in 2004, decreases to around 90 by 2006, then fluctuates, reaching approximately 77 in 2013. The second line starts at 100 in 2004, decreases to around 78 by 2007, then fluctuates, reaching approximately 72 in 2012 and rising slightly to around 73 in 2013. Annotations indicate average annual percentage changes: "-6.0% p.a." is shown for the initial decline of the lower line (approx. 2004-2007), "-3.5% p.a." for the initial decline of the upper line (approx. 2004-2009), and "-0.4% p.a." for a later segment of the upper line (approx. 2009-2013). The background features a faint, stylized image of mining equipment.::>

<a id='5df5e188-0704-4831-8520-5ee143812ec4'></a>

* Between 2004 and
2013, global mining
productivity has
fallen ~30%, or
3.5% p.a., even
after accounting for
geological
degradation

<a id='b8cfc91d-71c6-4c5d-8a84-c616205c8c47'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='1c828da2-5a82-4b35-8ebf-222198a2aa31'></a>

McKinsey & Company

<a id='8411f2fa-b7c7-4175-af2e-379b7aef5426'></a>

1

<!-- PAGE BREAK -->

<a id='41c040e3-0a8e-4077-8600-98327e70cb1a'></a>

The decline prevails across most commodities as well as across all major mining geographies

<a id='b5cad0af-bee9-496a-9948-f5be79581324'></a>

McKinsey Mine Productivity Index
CAGR, 2009 - 2013

<a id='016b11f9-4271-4d6b-a68d-c37e9d2452f8'></a>

McKinsey Mine Productivity Index
CAGR²

<a id='9e9d4972-0619-4d95-9cc3-ac954c535365'></a>

<::Bar chart with four vertical bars against a background image of large mining machinery. Each bar represents a different material and shows a negative value. Below each bar is the name of the material and an image of the raw material. The bars are all light blue.

Bar 1:
- Value: -1.5
- Material: Copper
- Image: A cluster of reddish-brown copper ore.

Bar 2:
- Value: -1.6
- Material: Iron ore
- Image: A dark, metallic-looking piece of iron ore with some green discoloration.

Bar 3:
- Value: -1.7
- Material: Coal
- Image: A small pile of black, irregularly shaped coal lumps.

Bar 4:
- Value: -4.5
- Material: PGMs¹ (Platinum Group Metals)
- Image: A shiny, grayish-silver nugget of platinum group metals.
: chart::>

<a id='8378aa63-3a5a-4f4d-8802-87e88488cbb7'></a>

* Almost all commodities registered declines in mining productivity - the trend is apparent across precious commodities as well as bulk minerals, indicating a more systemic shift that cuts across different mining methods or processing techniques

<a id='87aaff86-70ef-4d69-b841-24dc2b89f310'></a>

<::Bar chart showing four vertical blue bars extending downwards from a horizontal line. Below each bar is a numerical value and a geographical region label with a faint map outline.
- Bar 1: Value -4.1, Label: Latin America (with map of South and Central America)
- Bar 2: Value -4.2, Label: Australia (with map of Australia)
- Bar 3: Value -4.8, Label: North America (with map of North America)
- Bar 4: Value -4.8, Label: Sub-Saharan Africa (with map of Africa)
: bar chart::>

<a id='e087fb34-3f77-4479-b04e-345ca7894334'></a>

* North America and Sub-Saharan Africa experienced the biggest declines in productivity over the period

<a id='96930075-d63a-4eb8-892c-1c47d7cfd7a1'></a>

1 Platinum group metals
2 For Latin America CAGR is for 2005 to 2012, for Australia and Subsaharan Africa CAGR is for 2004 to 2013 and for North America CAGR is for 2006 to 2013

<a id='7d852b13-80bc-451a-8337-ce7ad5d72103'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='157e6fd9-bef4-4341-b52d-f79bdfc653ab'></a>

McKinsey & Company

<a id='914a7f93-81d0-4882-b0d9-a8dba3c876c1'></a>

2

<!-- PAGE BREAK -->

<a id='22bde9d9-63cf-4036-a955-8fd059147d84'></a>

The industry also faces dramatic capital and operating costs escalations

<a id='608c38c0-6bf9-4278-9cc7-0d0751418324'></a>

MineLens Productivity Index
indexed, 2004 = 100
CAGR,¹ 2004-13
%
<::chart: The chart displays the MineLens Productivity Index and several contributing factors, all indexed to 2004 = 100, showing changes from 2004 to 2013, along with their Compound Annual Growth Rates (CAGR).

Left section: MineLens Productivity Index
- A bar chart shows the index at 100 in 2004 and 72 in 2013.
- An arrow indicates a decrease of -3.5% p.a. from 2004 to 2013.

Right section: Factors influencing productivity, each with a bar chart and CAGR.
1. Production, mined volume
   - indexed, 2004 = 100
   - Bars show 100 in 2004 and 345 in 2013.
   - CAGR: 14.8% (green oval).
2. Employment, number of workers
   - indexed, 2004 = 100
   - Bars show 100 in 2004 and 178 in 2013.
   - CAGR: 6.6% (yellow oval).
3. Capital expenditures, asset value
   - indexed, 2004 = 100 in real terms²
   - Bars show 100 in 2004 and 1,681 in 2013 (with a wavy line at the top of the 2013 bar indicating a break or large value).
   - CAGR: 36.8% (red oval).
4. Operating expenditures, excluding labor cost
   - indexed, 2004 = 100 in real terms²
   - Bars show 100 in 2004 and 446 in 2013 (with a wavy line at the top of the 2013 bar indicating a break or large value).
   - CAGR: 18.1% (red oval).
::>

<a id='1a8c1484-b97e-4f6d-94f9-ca14b4b0e122'></a>

1 Compound annual growth rate
2 Capital expenditures and operating expenditures adjusted for mine cost inflation

<a id='4e30f86f-427f-408d-91ea-172c6559ef20'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='8d40de5c-dc06-4789-a33e-d110719316c7'></a>

McKinsey & Company

<a id='e81bdee4-12f3-4e60-985c-eec2b10d7dfa'></a>

3

<!-- PAGE BREAK -->

<a id='e7d36883-807f-4768-babb-6e492065e003'></a>

Mining companies can pursue 4 levers to thrive in
tomorrow's challenging and uncertain mining environment

<a id='67e440ee-2b0a-4326-b0d8-ef1c135a628e'></a>

Focus of this document

<a id='2e611245-4fe3-4cc9-b791-5b5b3bccac15'></a>

<::Diagram titled "Levers for unlocking value": The diagram consists of a central box with the title, surrounded by four other boxes, each detailing a specific lever. The levers are: Embed effective Management Operating systems Free people and resources to prioritize productivity and operational excellence, drive robust performance management, working across silos and data-driven decision making; Focus on innovation Adopt fresh mindset to innovation, including technology adoption, advanced analytics and use of big data; Operations excellence Relentless focus on eliminating waste and variability, and improving productivity of assets through advanced reliability and maintenance approaches.; Capability building Upgrade individual and organizational capabilities to deliver the above.::>

<a id='9c12ccb6-18c9-48fb-b40d-935ea52cca6e'></a>

SOURCE: McKinsey Basic Materials Practice

<a id='339973a0-fb68-4436-afd4-d78c3f884f06'></a>

McKinsey & Company

<a id='b6c3cdd2-2520-4765-a07b-6e1593d9d35b'></a>

4

<!-- PAGE BREAK -->

<a id='e3396224-b80e-464a-999b-beab5a766cfb'></a>

Mining companies are increasingly looking at technological innovations to address the declining productivity trends

<a id='7aa9964f-a120-400d-95f5-52aecd11e431'></a>

"Now we need to protect our operating margins, we have to improve our working practices",. "**The company is moving towards full automation at it's mines,** "something we have been slow to progress in the past"
– *Diego Hernandez, CEO Antofagasta*

<a id='2e529547-361f-409a-a504-31476a2d3165'></a>

<::logo: Antofagasta PLC
ANTOFAGASTA PLC
The logo features an orange circle containing a stylized white triangle and wavy lines, resembling a mountain over water.::>

<a id='e5dac415-9577-4fda-be8e-1ee3362099a5'></a>

<::SANDVIK
[Solid blue rectangle]
: figure::>

<a id='60ca6681-fc97-4d24-b993-99bff3cef470'></a>

"Progressive mining companies are beginning to implement automated systems, with the rest of the industry expected to follow suit"

"Autonomous technologies represent a class of innovation that will profoundly change how minerals are mined and processed"

– *Ken Stapylton, Vice President surface drilling, Sandvik*

<a id='4592d7d5-9a44-4876-ac51-b93ae5982a1b'></a>

SOURCE: Press search

<a id='ec133680-8321-49d9-ad6c-0668cf106d20'></a>

McKinsey & Company

<a id='d0a0d306-3952-4324-be33-eebac89070b9'></a>

5

<!-- PAGE BREAK -->

<a id='70626627-73a9-4d1c-955c-5bfbb78687c9'></a>

NOT EXHAUSTIVE
Focus of this documen

Advanced technologies are being developed and implemented
across all stages of the mining value chain
Commercially available
In testing
In developmer

<a id='4f73b4f4-aeee-4825-9446-027beb6551f2'></a>

OEMs Status Expected commercial availability

<a id='29f017c2-a162-4238-bcb9-ff369b70a142'></a>

Exploration
<::image of two people in mining gear looking at a tablet/device in an outdoor setting; logos: GEOSOFT; progress indicator: dark blue solid circle; icon: compass-like icon::>
- Computer algorithm automatically
  detects patterns in exploration data
  indicative of mineralisation
Drilling
<::image of a drilling rig in an open-pit mine; logos: SANDVIK, CAT, Atlas Copco, FLANDERS; progress indicator: dark blue solid circle; icon: drilling machine icon::>
- All major OEMs offer products with
  various level of automation
- Other firms specialize in retrofitting
  existing drills for automation
Blasting
<::image of an explosion/blasting in a mine; logos: AEL Mining Services; progress indicator: circle with about 25% dark blue (quarter filled); icon: explosion cloud icon::>
- The charging process can be
  automated, with the required amount of
  explosive being entered beforehand
Loading
<::image of a large excavator/shovel loading material; logos: HITACHI, CSIRO; progress indicator: circle with about 50% dark blue (half filled); icon: excavator/shovel icon::>
- OEMs developing autonomous shovels
Hauling
<::image of a large mining haul truck with '131' on the side; logos: HITACHI, CAT, KOMATSU; progress indicator: dark blue solid circle; icon: mining haul truck icon::>
- Komatsu and Caterpillar have
  commercial offerings
- Hitachi running field trials
Other
support
equipment
<::image of a large yellow bulldozer; logos: HITACHI, KOMATSU, CAT; progress indicator: circle with about 50% dark blue (half filled); icon: bulldozer icon with a superscript '1'::>
- All major OEMs developing are
  developing autonomous solutions for
  support equipment like dozers,
  shearers, etc.
2008
2020
2025
1 Tele-remote dozers are already in quite extensive use; autonomous will take longer due to their irregular usage cycles

<a id='05f4e1bc-399f-4d67-99f4-f8428a2c74d4'></a>

SOURCE: Expert interviews; Press search

<a id='8b9a7347-c23b-47df-b918-1df6e73f2146'></a>

McKinsey & Company

<a id='067fa6df-0cc5-4df6-9a46-9175ea724466'></a>

6

<a id='cfb06ab9-87b0-44a4-8708-73847dbf1ed5'></a>

Examples

<!-- PAGE BREAK -->

<a id='dadd347a-aa67-4ace-a980-0981f0bae8e8'></a>

**Multiple categories of advanced mining technologies are reaching commercialization and deployment stages**

<a id='b335bd65-47ac-4443-9070-58754288dfbd'></a>

<::Legend: square color codes and their meanings
- Light blue square: Ideas and prototypes
- Medium blue square: Field testing and early adoption
- Dark blue square: Full scale commercialization
: legend::>

<a id='7681f132-cfb0-4bd4-8692-6168ec894373'></a>

<::Timeline chart: The chart shows the evolution of autonomous mining technologies, divided into two main sections: A) Autonomous drills and B) Autonomous Haulage, over a timeline from 1970 to 2015. The x-axis represents years from 1970 to 2015.

A) Autonomous drills:
-   Late 1990s (implied before 2000): Atlas Copco demonstrates prototype at Mini Expo 2000 (with Atlas Copco logo).
-   Early 2000s: Atlas Copco partners with Rio Tinto to prepare drills for testing.
-   Mid 2000s: Sandvik and Atlas Copco developing drills in tandem for UG & OP applications.
-   Late 2000s/Early 2010s: Operational testing of Atlas Copco Pit Vipers (autonomous) by Boliden.
-   Mid 2010s: Rio Tinto tests fully autonomous bench drilling (with Rio Tinto logo).

B) Autonomous Haulage:
-   Early 1990s: CAT begins tests in USA (with CAT logo).
-   Mid 1990s: Komatsu begins tests in Australia (with Komatsu logo).
-   Early 2000s: First major commercialization: 11 trucks at Gaby mine (Codelco) (with Codelco logo).
-   Late 2000s/Early 2010s: Immersive technologies opens AH simulation training school (with Immersive Technologies logo).
: chart::>

<a id='cb6ae1d2-bd9d-4427-9a80-4ac9c059be96'></a>

<table id="7-1">
<tr><td id="7-2">What next?</td></tr>
<tr><td id="7-3">Hitachi is expected to make a number of autonomous solutions commercially available soon: AH trucks (2015), Shovels (2017), Graders and Dozers (2018)Many drills currently being operated semi-autonomously/tele-remotely (e.g., by Barrick, Codelco, Anglo American) but have capacity to be fully autonomous pending labor agreements and/or changes to operations</td></tr>
</table>

<a id='340f912f-3405-427a-afc7-cf41cdb5d605'></a>

SOURCE: Expert interviews; Press search; McKinsey analysis

<a id='0b9daeb0-7f15-4851-9554-b2be688f2205'></a>

McKinsey & Company

<a id='ebd72ad2-cb97-4611-bc41-8b3ac0df1ffa'></a>

7

<!-- PAGE BREAK -->

<a id='86fe20ea-c03e-42f4-b08f-3d0414fe50f1'></a>

A Automated drilling is the latest step in the long evolution of drill and blast technology

<a id='0ca9f47a-9bf8-48b9-a558-a5ef95d931ec'></a>

Rio Tinto and Atlas Copco formed an alliance to work together to develop autonomous drilling solutions for surface mining <::A large yellow drilling rig with a tall mast is operating in an open-pit mine, surrounded by grey rock formations and dust.: photo::>

<a id='eed6595d-5468-4223-a31a-e49eeeccb34f'></a>

Atlas Copco and Rio Tinto successfully automated surface drilling, completing a computer-generated drill pattern

<::transcription of the content
: photograph of a sandy field with some sparse vegetation and hills in the background under a clear sky::>

<a id='dcaaae66-8ca4-474e-b26e-a5b0b1c2c008'></a>

<::timeline:
- 2006:
  - Description: Rio Tinto began to explore autonomous drilling rigs at Australia's Pilbara iron ore region
  - Image: An aerial view of a large drilling rig operating on a reddish-brown, open-pit mining landscape, with a series of small, circular drill holes visible on the ground.
- 2008:
  - Description: (Marker on timeline, no associated text or image)
- 2011:
  - Description: Sandvik and Flanders formed a formal partnership to automate surface mining drill rigs and provide autonomous operation
  - Image: A ground-level view of a large yellow and gray drilling rig positioned on a flat, gravelly surface in an open-pit mining environment, with distant hills under a light sky.
::>

<a id='3e934fbf-75e1-4f78-aa34-02271b29f68f'></a>

Rio Tinto became the first to achieve **fully automated** production bench **drilling** without human intervention at a test site in Australia <::A person is shown from behind, sitting at a desk and looking at multiple computer monitors. One monitor prominently displays four smaller screens, possibly showing live feeds or data. A laptop is also on the desk to the right of the person. This setup appears to be a control station for automated operations.: photograph::>

<a id='c813c66f-3f47-4310-a160-025cde433993'></a>

SOURCE: Press search; Company brochures

<a id='a5b26bd4-38a0-4d6b-b143-cab631575d5b'></a>

McKinsey & Company

<a id='3a308751-888c-4387-8e01-b4ad251c0672'></a>

8

<a id='650b2b1b-5ee8-4983-a1c5-1adaa97d8162'></a>

<::Timeline chart showing two points: 2013 and 2014. The timeline is represented by a dark blue arrow pointing to the right. Each year is marked by a blue circular node with a grey dot above or below it.::>

<!-- PAGE BREAK -->

<a id='8a171dce-4f5e-4fb4-947d-d9f204f9a2c3'></a>

B Autonomous haulage has three key components

<a id='2648f24f-c58a-426c-9d74-e58e15bf939d'></a>

Description

<a id='93dbbb77-580b-4117-a5d0-bbe67ae352fd'></a>

1 Base vehicle & automa- tion kit

<::A large yellow mining truck.
: figure::>

2 Critical mine site infra- structure

<::A word cloud with "INFRASTRUCTURE" prominently displayed. Other words include: SUPERSTRUCTURE, ENVIRONMENTAL, MAINTENANCE, DEVELOPMENT, INSTALLATION, SYSTEM, MILITARY, TRANSPORTATION, SNOWBLOWERS, WATER, FINANCING, LAND, STANDARD, TENDERING, BREAKWATERS, GOVERNMENT, PIPELINE, SEWERS, SIGNALLING, ELECTRIC WORK, BUILDINGS, FACILITIES, LICENSING, IRRIGATION, ELECTRICAL, COMMUNICATIONS.
: figure::>

<a id='e4e96d16-de7e-4abd-8b70-f0e28689b657'></a>

- Standard **truck body**
- Onboard embedded systems and real-time **operating software** informing and controlling the truck's activities (e.g., **sensors**, computers, video system, traction control, **GPS tracking**, and **radio receptivity for remote inputs**)

<a id='27fc8d0b-d23e-4d77-a8bd-dbe81a29a360'></a>

<:: - High-capacity communications network - GPS locators for all vehicles within the orbit of AH trucks : bulleted list with a faint radar-like background graphic::>

<a id='b31581fa-2f74-4263-a021-9d1bd39efcda'></a>

3 Command and control centre <::A photograph of a modern command and control centre. The room features a large, curved white desk equipped with numerous computer monitors displaying blue screens. Several black office chairs are positioned around the desk. In the background, there are larger screens or windows also displaying blue. : photo::>

<a id='0e11f841-e20a-42f7-b501-d082b7709818'></a>

- **Headquarters** from which trucks monitored/remotely controlled
- Can be **on-site or off-site** (e.g., Rio Tinto is experimenting with controlling autonomous equipment from 1500km away)
- Operator ensures **adherence of vehicles to loading, dumping, and traffic management** plans, makes **adjustments** to vehicles' trajectories where necessary, and **restarts** the trucks in case of automatic shutdown triggered by trucks' safety protocols
- 1 operator can track the progress of **numerous vehicles**

<a id='7d5cbf85-2e33-408d-a746-b718e0c10965'></a>

SOURCE: Expert Interviews; McKinsey Analysis

<a id='d4736fc0-69d7-48e3-91c1-bcbdcada7d43'></a>

McKinsey & Company | 9

<!-- PAGE BREAK -->

<a id='48fea48a-41a2-40a3-9f59-76f37a419d71'></a>

Innovation is key to overcome scarcity
issues in rare raw materials

<a id='9d82e4b1-8d46-4c76-b194-b9bb5d2a5320'></a>

NON-EXHAUSTIVE

<a id='066563d3-7bd5-4283-9d70-e69d14f2d42f'></a>

<::
Solid blue circle: Heavy" 
Outlined blue circle: Light
Icon with circular arrows: Size of the bubble indicates resource size
: chart::>

<a id='8aa0f670-e98c-4fb5-8d99-c947da0edddd'></a>

Levers to drive change
* Effective management
systmens
* Operational excellence
* Innovation across the
whole supply chain
* Capacity building
<::A 3D white figure holding a large red wrench.: image::>

<a id='43ee0a4d-71a7-4b74-83d1-a26c4c681d9e'></a>

<::Bubble chart titled "Ore grade % TREO" on the y-axis (ranging from 0 to 10) versus "Minimum lead time Years" on the x-axis (ranging from 1 to 13). The x-axis also shows project stages: Ramp-up (1 year), Construction (2-5 years), Feasibility (6-7 years), Pre-feasibility (8-10 years), and Drilling (11-13 years). Each bubble represents a project, with its size possibly indicating project scale or resource size. Projects shown include:
- Mount Weld: High ore grade (around 9.5% TREO), 1 year lead time (Ramp-up).
- Mountain Pass: High ore grade (around 6.5% TREO), 1 year lead time (Ramp-up).
- Mount Weld Duncan: Around 5% TREO, 6 years lead time (Feasibility).
- Araxá: Around 4.5% TREO, 10 years lead time (Pre-feasibility).
- Strange Lake: Around 3% TREO, 5-6 years lead time (Construction/Feasibility).
- Ngualla: Around 2% TREO, 10 years lead time (Pre-feasibility).
- Nechalacho: Around 1-2% TREO, 9 years lead time (Pre-feasibility).
- Niobec: Around 1-2% TREO, 7-8 years lead time (Feasibility).
- Dubo: Around 1% TREO, 3-4 years lead time (Construction).

A callout box points to Mount Weld and Mountain Pass, stating: "Two large projects close to production, focused on light rare earths."

Below the chart, there is a caption: "Long term industry sustainability requires additional projects at later stages of the project pipeline.": chart::>

<a id='8e5f3a92-e64e-4718-b02c-b4af3e87b7be'></a>

1 Heavy rare earths projects are the ones with more than 15% of total rare earth content of heavy elements

<a id='e36d3eab-917d-406e-95d0-ac9f90835c2a'></a>

SOURCE: Technology Metals Research, expert interviews

<a id='3e951f01-f3c9-45cd-83b2-8611deb77bec'></a>

McKinsey & Company

<a id='2ad2108f-62b7-4ebd-9587-b2c44888ff08'></a>

10

<!-- PAGE BREAK -->

<a id='8c0e34a7-a449-4a40-8d63-065b353061ee'></a>

BACKUP (Presented on ad-hoc basis if there are questions)

<a id='19191290-c4f5-42bc-914f-e557c0d57080'></a>

McKinsey & Company

<a id='b1eeb183-446b-442a-8183-2cb877c09f5f'></a>

11

<!-- PAGE BREAK -->

<a id='d3b966d9-14fb-4c50-bf90-823ea28fd03d'></a>

Executive summary

<a id='acebd77e-b8e8-484f-8da1-4a343c2da630'></a>

▪ Multiple forces at work, such as labour scarcity, rising costs of inputs, increased health and safety standards, and declining productivity, have been putting **significant pressure on the mining industry** in the last decade, e.g.,

	– Average copper mine input costs have risen ~150% in the past 15 years
	– In 10 years, productivity in some of the world's major mining hubs has declined by up to 50%
▪ Mining companies are **increasingly looking at technological innovations** to address these trends, with a view to reducing costs and increasing productivity
▪ Development, testing and implementation of high-tech solutions in mining have **exploded in the past 15 years**, with advanced technologies being developed and implemented across all stages of the mining value chain, from exploration to hauling and dozing
▪ There is an increasing sense among all sizes of mining companies that “**the future is now**”, and that the best-performing companies in the next decades will be the one willing to assume the costs of implementing advanced technologies during this challenging period
▪ Examples of the most promising and most developed advanced technologies include

	– **Autonomous haulage**, which has been implemented at ~25 sites and can **reduce overall haulage costs 10-40%**
	– **Autonomous or tele-remote drilling**, which has been trialled at nearly 20 sites, with demonstrated increase of both available drilling time per shift and **drilling/blasting accuracy**, leading to a **knock-on impact on downstream processes**

<a id='fc5cef98-bc96-4fda-b8d7-543b073aaffc'></a>

nging period
dvanced tech
ed at ~25 site:

<a id='34d4c019-92d3-4fd7-86d4-5e2cb1197a59'></a>

McKinsey & Company

<a id='29447cdf-5ab1-42ed-894c-b7ab3f6a999e'></a>

12

<!-- PAGE BREAK -->

<a id='90163254-5da1-4f1b-bbab-b741c7bf4ed1'></a>

The mining industry faces multiple forces which will adversely impact industry economics going forward

<a id='441199f8-0139-4e3b-ab20-f43206781024'></a>

<::figure: This is a diagram showing a central image of an open-pit mine, surrounded by eight octagonal shapes, each representing a force influencing the future of mining. From top to bottom, clockwise, these forces are:  Continuously increasing safety, health and environment standards (represented by a light blue octagonal shape with light blue wavy lines). Rising cost of production inputs (represented by a light blue octagonal shape with light blue arrows pointing upwards). Demand growth fueled by population growth and socio-economic changes (represented by a light blue octagonal shape with light blue abstract figures and an upward arrow). Declining productivity (represented by a dark blue octagonal shape with a red downward arrow and a grid pattern). Labor scarcity (represented by a grey octagonal shape with light grey human figures). Increasing price volatility (by-product credits) (represented by a light blue octagonal shape with a magnifying glass over a red wavy line graph). Increasingly challenging geologies (represented by a light blue octagonal shape with a light blue maze pattern). Global sourcing changing equipment industry structure (represented by a dark grey octagonal shape with light blue abstract gear-like shapes).::>

These forces will have determine how mines are set up and run in the future

<a id='507340c5-5d03-4078-9f76-ec398cb72167'></a>

SOURCE: McKinsey Basic Materials Practice

<a id='c6ed854e-75c4-4c9f-9e4a-188a0a5b7dd3'></a>

McKinsey & Company

<a id='05bdc7e6-551a-4d1d-9c16-3ceb275e5bc0'></a>

13

<!-- PAGE BREAK -->

<a id='df2837fa-fd67-4c64-a0a3-d4a3cd1c0ba7'></a>

The McKinsey Mining Productivity Index reveals that mining productivity
globally has declined 3.5% p.a. over the past decade

<a id='9dc0de32-2dfe-469b-8b71-0a07ccddef88'></a>

McKinsey Mining Productivity
Index, 2004 = 100

<a id='e1958418-aa66-4ce0-9c58-3a6b51fdf772'></a>

Approach
<::line chart: Index, 2004 = 100
Y-axis: Index values from 65 to 110
X-axis: Years from 2004 to 2013

Two lines are plotted:
1. Light blue line: Represents an index starting at 100 in 2004 and fluctuating downwards, ending around 72 in 2013.
2. Dark blue line: Represents an index starting at approximately 105 in 2004 and generally declining.
   - From 2004 to approximately 2008, the average annual decline is indicated as "-6.0% p.a.".
   - From approximately 2008 to 2013, the average annual decline is indicated as "-0.4% p.a.".
   - An overall average annual decline for the period 2004-2013 is indicated as "-3.5% p.a." associated with this dark blue line.::>

*   McKinsey Mining Productivity Index computed using global data set comprising
    *   Detailed data at mine-site level for ~50 mines from all major mining jurisdictions
    *   10 years of performance data
*   All values indexed to 2004 = 100

*   Between 2004 and 2013, global mining productivity has fallen ~30%, or 3.5% p.a., even after accounting for geological degradation

<a id='63641f24-aa79-4bfc-9a55-4a5a8f41b49c'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='931fe76c-805c-4b75-9b40-a88d64d34e31'></a>

McKinsey & Company

<a id='ed9688cb-a4a9-4966-8583-8fdad3621a16'></a>

14

<!-- PAGE BREAK -->

<a id='44727ac2-dd2e-4edc-955e-1db93d58de44'></a>

Mining companies are increasingly looking at technological innovations to address the declining productivity trends

<a id='86ef62d8-9668-43cd-882d-2f090f880088'></a>

<table id="15-1">
<tr><td id="15-2">&quot;Where we&#x27;re really behind, shamefully behind, is in the issue of productivity&quot; – Thomas Keller, CEO Codelco; April 2014, CRU World Copper Conference, Santiago</td><td id="15-3">&quot;With our Southdowns project (Western Australia), we are able to vastly improve the economics by steepening the walls and improving the strip ratio because we have proven methods and [remote control drill, rock-breaker and explosives loader] technology to manage those steeper walls&quot; – Matthew Andersson, Mining Manager, Grange Resources</td></tr>
<tr><td id="15-4">&quot;Declining productivity is now a problem we share&quot; - Paul Dowd, Director OZ Minerals</td><td id="15-5">&quot;Progressive mining companies are beginning to implement automated systems, with the rest of the industry expected to follow suit&quot; &quot;Autonomous technologies represent a class of innovation that will profoundly change how minerals are mined and processed&quot; – Ken Stapylton, Vice President surface drilling, Sandvik</td></tr>
</table>

<a id='0123d9db-3825-4cec-a30b-606c5e931d4d'></a>

"Now we need to protect our operating margins, we have to improve our working practices",. "The company is moving towards full automation at it's mines, "something we have been slow to progress in the past"

– *Diego Hernandez, CEO Antofagasta*

<a id='53a6dfd0-1bf2-410e-a122-d3bf4c7dc71e'></a>

SOURCE: Press search

<a id='7e996b3b-cf0b-4cd7-9212-10925ef5d1c1'></a>

McKinsey & Company

<a id='5af15a6b-92d2-4b64-9d3c-103d3381ecaa'></a>

15

<!-- PAGE BREAK -->

<a id='6c28fc3d-55c5-441c-9ea2-16e4e3a267cf'></a>

Autonomous equipment-enabled open-pit mines rely on the careful and coordinated interplay of the mine-wide control systems and equipment

<a id='219ef1ec-ac28-425a-9039-902bc7b535cf'></a>

<::The image is a detailed diagram illustrating a smart mining operation within an open-pit mine. The background shows an aerial view of a large, terraced open-pit mine. Various components of the smart mining system are depicted as icons with accompanying text labels, connected by yellow wavy lines representing wireless communication and data flow. The components are:

- **Control centre**: Located at the top left, an icon shows a control room with multiple monitors, a desk, and a chair, with a person operating it. The text associated is: "Control centre On-site and/or remote. Includes autonomous fleet management software and live monitoring/feedback". Wireless signals emanate from the control centre towards the mine.
- **Mine LAN and radio communications**: A text box in the upper middle of the mine reads: "Mine LAN and radio communications". Yellow wavy lines radiate from this box, indicating network coverage across the mine.
- **Conveyors**: At the top right, an icon displays a conveyor belt system used for transporting materials. The text label is: "Conveyors".
- **Rock breaker**: An icon of a tracked excavator with a breaking attachment is shown on the left side of the mine. The text label is: "Rock breaker".
- **Loaders**: An icon of a front-end loader is depicted in the upper middle left. The text label is: "Loaders".
- **Drills**: An icon of a drilling rig is positioned in the middle right of the mine. The text label is: "Drills".
- **Smart equipment**: This is a general label located in the lower middle, referring to the various pieces of automated mining machinery.
- **Haul trucks**: An icon of two large mining haul trucks is shown in the lower left. The text label is: "Haul trucks".
- **Dozers**: An icon of a bulldozer is located in the bottom middle. The text label is: "Dozers".
- **Ore tagging**: On the right side, an icon depicts an RFID tag with a wireless signal radiating from it. The text associated is: "Ore tagging RFID Tag RFID signal".
- **Blast charging**: At the bottom right, an icon represents an explosion, indicating blasting activities. The text label is: "Blast charging".

All these elements are interconnected by the yellow wavy lines, symbolizing a comprehensive, wirelessly connected smart mining environment.: figure::>

<a id='cc2379c9-915d-483a-9648-8461f67d75e6'></a>

Control centre
On-site and/or remote.
Includes autonomous fleet
management software
and live
monitoring/feedback

<a id='2237c657-32e2-4b7a-b483-cda0e75b26bb'></a>

<::On a textured grey background, partially visible on the top left are two grey wheels with blue centers. Below them, a dark blue rectangular label reads "Haul trucks". On the right, a stylized blue illustration of a tracked vehicle, resembling a bulldozer, is depicted. Partially visible dark blue rectangular shapes are present above and below the bulldozer illustration.: figure::>

<a id='af8dc351-4b01-4bfb-8847-dc12799cbd2d'></a>

<::logo: [Unknown]Blast chargingA blue cloud-like shape with a dark blue outline is centered over a dark rectangular background with text.::>

<a id='cd5f5a21-db99-4c4f-aecb-7481cf885d7a'></a>

SOURCE: Expert Interviews; Sandvik webpage; Caterpillar webpage; Metso webpage; Transmin webpage

<a id='2aa2ffd8-4a61-49f2-bf3a-774db8e6452b'></a>

McKinsey & Company

<a id='fe53015d-379d-45e0-b42b-f14e103dad9e'></a>

16

<!-- PAGE BREAK -->

<a id='9c323f3a-380c-4d97-8440-b5dd1c962a71'></a>

Different degrees of autonomy in haul trucks

<a id='6aad37d6-11db-4fe2-a86d-37373955d5e2'></a>

Semi-autonomous trucks

<a id='9444077f-bafa-409f-a09f-fb26a8be7ae0'></a>

Fully autonomous trucks

<a id='59234407-0fe8-4f7f-8663-d1ad301a1341'></a>

<::Image of car steering wheel buttons. The buttons are silver-grey. From top to bottom, left to right:
- Top left: "CRUISE" button.
- Top right: A rocker switch with "RES+" on the upper part and "SET-" on the lower part.
- Bottom left: A button with a steering wheel icon that has a heating symbol (three wavy lines) above it, indicating a heated steering wheel function.
- Bottom right: "CANCEL" button.
The image also shows a reflection of these buttons below them.
: figure::>

<a id='1a2b7514-f49b-4f62-88e8-fb18cf3a1fd1'></a>

<::A large yellow Caterpillar (CAT) mining dump truck, seen from a rear-three-quarter angle, with "CATERPILLAR" visible on the top of the bed and "CAT" on the side near the cab. The truck has massive wheels and is on a dirt or gravel road, with a reflection of the truck below it.: figure::>

<a id='d7411e3a-cdac-4186-b75c-a4efea904b82'></a>

* Driver still present in vehicle
* Vehicle has a form of "cruise control" for the length of the haul route
* Driver tends to reassume control for loading and dumping, and whenever an obstacle presents itself (e.g., manned vehicle, obstruction in the road)

<a id='664c7727-cb94-48a0-8033-9b588424f023'></a>

- All stages of haul cycle are autonomous
- No operator is required in vehicle
  - One operator can oversee multiple trucks simultaneously from a remote control centre
  - Command centre can be on- or off-site
- There are currently 3 archetypes of fully autonomous trucks (_detailed next page_)

<a id='008db0c7-454d-4797-99a4-b0e85c749147'></a>

SOURCE: Expert interviews

<a id='44e05cbc-366f-4b5d-b1e7-3c6c3ba68bc1'></a>

McKinsey & Company

<a id='8eb42488-f034-442a-a144-22b80e82eece'></a>

17

<!-- PAGE BREAK -->

<a id='a27c6ba6-e7b5-4898-8e06-8b16b1fa423a'></a>

BASE VEHICLE AND AUTOMATION KIT
Key on-board components of autonomous haul trucks

<a id='4f94f9ae-a4ae-44cf-ba29-2474214ca99f'></a>

Autonomous Control Cabinet
Sealed hydraulic and electronic
controls

GPS
GPS technology is
combined with a
tracking system to
accurately monitor
location of vehicles

Autonomous
Status Lights
Mounted on all
sides of the truck to
safely display truck
operating status

Road Edge
Guidance (REG)
A mounted laser
guidance system
measures the dis-
tance to the road
berm to provide
additional naviga-
tion accuracy

<a id='ca2b7082-25b0-4883-ad57-78273a85bedb'></a>

<::A photograph of a large yellow Komatsu HD985 mining dump truck, with the number '259' visible on its side. The truck is annotated with blue lines and circles pointing to various locations, and a white oval highlights a sensor near the front left wheel. The background shows trees.: figure::>
<::A diagram illustrating an optical fiber gyro, depicted as a coiled optical fiber with an arrow indicating rotational movement. Accompanying text: Optical fiber gyro Senses changes in orientation using interference from light: diagram::>

<a id='d5cd22e0-9247-4ecc-b81f-7e0b54a5ccc0'></a>

<::image: A yellow autonomous vehicle or piece of machinery, possibly a mining vehicle, equipped with multiple sensors and cameras on its front and top. The sensors appear to be radars and LIDAR units.::>
- **Object avoidance** (e.g., radar with 80m range, LIDAR with 20m range at sides and rear)
- These sensor technologies are still in their infancy
  - Overall they have been working effectively in dry, clear climates such as in Australia or the Atacama desert
  - They have much lower reliability in fog or rain, which has impeded adoption of AH technology in more temperate climates
  - In the next few years, some AH sensor manufacturers will likely turn to military sensors to improve availability and reliability; however, doing so is currently cost-prohibitive

<a id='09d457dd-525a-4707-a504-0d64a14b9382'></a>

SOURCE: Expert Interviews; University of British Columbia; Caterpillar; Komatsu

<a id='0aa1cd85-8524-47a3-b4a6-51ed37c7f672'></a>

McKinsey & Company

<a id='cd9ef3c7-dd48-4d8f-9047-34e850a8f8a4'></a>

18

<!-- PAGE BREAK -->

<a id='ecf008f8-a2fa-439d-a500-ed699574dc91'></a>

Communications technology is vital for relaying commands from the control centre to the vehicles, and for managing vehicle interactions

<a id='5f015c72-2cf0-42db-a874-b0171ed25b56'></a>

Communications technology

*   Open-pit communications tend to rely on **satellite/GPS**, **wi-fi** and/ or **RFID**
    *   This requires antennas / **boosters** around the site
    *   Each individual vehicle, and possibly personnel, must also be **tagged** (tele-remote and manned) with **positional trackers**, in order to minimize interactions with operational tele-remote vehicles (for reasons of safety and productivity)
*   System must have enough **bandwidth** to
    *   Relay **live video** feeds to the central control room
    *   Provide up-to-date tracking of all **vehicle locations**
    *   Convey **real-time commands** from the command centre to the tele-remote or autonomous systems

<a id='4c11cb66-f2b8-4b7d-bbda-06e2c4b66e14'></a>

McKinsey & Company

<a id='572c3473-12f7-442b-a93d-21b64e682a59'></a>

19

<!-- PAGE BREAK -->

<a id='be77d456-5ed9-49c7-b141-3d832c9550fa'></a>

**Autonomous haulage has multiple safety and efficiency benefits**

<a id='27a09883-4fa8-4aa6-ac2e-042fb20b5b04'></a>

- Favourable impact on economics
- Adverse impact on economics

<a id='260c3ce5-96fe-440e-9bf5-518842daab89'></a>

<table><thead><tr><th>Category</th><th>Lever</th><th>Impact range</th><th>Rationale for impact</th></tr></thead><tbody><tr><td>Safety</td><td>Safety</td><td>(Green dot)</td><td><ul><li>Fewer people in dangerous areas</li></ul></td></tr><tr><td>Mine design</td><td>Strip ratio</td><td>(Green dot) - 0-5%</td><td><ul><li>Fewer people in pit enables steeper pit walls and thus ability to reduce strip ratio</li></ul></td></tr><tr><td rowspan="3">OEE<sup>1</sup></td><td>Utilization</td><td>(Green dot) - 10-30%</td><td><ul><li>Eliminate shift-change delays; reduce delays due to traffic congestion</li></ul></td></tr><tr><td>Availability</td><td>(Green dot) - 10-30%</td><td><ul><li>Reduced unscheduled downtime from more consistent usage cycles and reduced damage</li></ul></td></tr><tr><td>Truck speeds</td><td>(Green dot) TBD</td><td><ul><li>Higher truck speeds as fewer people in mine areas; truck speeds more consistent</li></ul></td></tr><tr><td rowspan="4">Operating and mainten-ance costs</td><td>Labor</td><td>(Green dot) Up to -95%</td><td><ul><li>Fewer (or zero) operators</li></ul></td></tr><tr><td>Fuel</td><td>(Green dot) - 5-10%</td><td><ul><li>Lower fuel consumption from more consistent driving cycles</li></ul></td></tr><tr><td>Tires</td><td>(Green dot) - 5-10%</td><td><ul><li>Improved tire life due to more consistent speeds and driving patterns</li></ul></td></tr><tr><td>Maintena-nce</td><td>(Green dot) - 10-20%</td><td><ul><li>Lower maintenance parts and labour costs from reduced wear and accident damage</li></ul></td></tr><tr><td rowspan="2">Capex</td><td>Truck capex</td><td>(Red dot) ~500k autonomy kit</td><td><ul><li>Higher truck cost due to additional equipment and sensors on trucks</li></ul></td></tr><tr><td>Infrastruc-ture capex</td><td>(Red dot)<ul><li>Hub ~$1m</li><li>Communica-tions upgrade ~$15k</li></ul></td><td><ul><li>Infrastructure costs for communications infrastructure, refueling system</li></ul></td></tr></tbody></table>"The main benefits are in operating labour costs (down about 2/3) and optimized productivity (avoiding downtime and operating at a faster and safer cycle time)"
- AH electrical systems specialist

"During our first trials, we were already able to reduce exposure of our workers to danger areas by ~70%"
- Mine manager

"Capex costs are high, though of course they also depend on the pre-existing level of infrastructure, like for communications. That said, the upside of AH is significant"
- AH developer

<a id='b3466c86-22c7-484f-a7b0-2e8446ada88d'></a>

1 OEE: Overall Equipment Effectiveness

<a id='53e4a6b4-c23f-4361-ab70-7f361ef3a387'></a>

SOURCE: Expert interviews; Press search

<a id='d82fefe3-5317-4934-97f7-5bb1171f34e8'></a>

McKinsey & Company

<a id='138bfa7e-e9bc-4595-a474-849a3dc3e6fc'></a>

20

<!-- PAGE BREAK -->

<a id='28b3ae7f-2b0c-48ab-8180-a6114644ae9f'></a>

AUTONOMOUS HAULAGE

<a id='d9520918-b148-4547-9b86-e54484219332'></a>

Autonomous haulage can be a game changer in mining
productivity: 10% to 40% reduction in haulage costs
Hauling costs – USD c/ton

<a id='078eb02f-1e63-4044-a0f7-0c681bcd5ade'></a>

PRELIMINARY

<a id='f65c4edd-45bb-4cd1-827d-f3d181f99ab2'></a>

High labor cost locations, e.g. remote
Australian mines, Canadian oil sands
$350K fully loaded, operator cost

<a id='9cf4d099-f931-4f16-8c8c-68eb9c8170fa'></a>

Low labor cost locations, e.g. Africa, Asia
$35K fully loaded, operator cost

<a id='579eb873-9adb-4611-afab-3519454fbd8b'></a>

<::Bar chart comparing cost components across two scenarios, likely representing different levels of autonomy in mining operations. The chart is divided into four main categories: Mine design, OEE¹, Operating and maintenance costs, and Capex. Each category has sub-items and associated numerical values, shown for two distinct columns, referred to as Scenario 1 (left) and Scenario 2 (right). The values appear to be in percentages or a relative unit. Scenario 1 is on the left, and Scenario 2 is on the right.Mine design:  - Manual Fleet: 67.47 (Scenario 1), 45.41 (Scenario 2)  - Strip ratio: 0 (Scenario 1), 0 (Scenario 2)  - Total Mine design: 67.47 (Scenario 1), 45.41 (Scenario 2)OEE¹:  - Availability: -0.72 (Scenario 1), -0.27 (Scenario 2)  - Utilization: -3.82 (Scenario 1), -1.41 (Scenario 2)  - Truck speeds: 0 (Scenario 1), 0 (Scenario 2)  - Total OEE¹: 62.93 (Scenario 1), 43.74 (Scenario 2)Operating and maintenance costs:  - Labor: -20.37 (Scenario 1), -2.04 (Scenario 2)  - Fuel: -1.72 (Scenario 1), -1.72 (Scenario 2)  - Tires: -0.50 (Scenario 1), -0.50 (Scenario 2)  - Maintenance: -0.64 (Scenario 1), -0.64 (Scenario 2)  - Total Operating and maintenance costs: 39.69 (Scenario 1), 38.83 (Scenario 2)Capex:  - Truck: 0.96 (Scenario 1), 0.96 (Scenario 2)  - Infrastructure: 0.08 (Scenario 1), 0.08 (Scenario 2)  - Total Capex: 40.74 (Scenario 1), 39.88 (Scenario 2)Below the chart, the text "Autonomous fleet" is associated with the totals for Capex, which are 40.74 (Scenario 1) and 39.88 (Scenario 2). There are also two arrows indicating percentage changes: one pointing left with "-40%" and another pointing right with "-12%". The overall caption at the bottom reads: "Autonomous trucks can reduce surface haulage costs by up to 40%".: bar chart::>

<a id='61086c53-f39e-4e9e-bae8-f587c00bc736'></a>

1 OEE: Overall Equipment Effectiveness

<a id='6b07470d-827f-4182-b33b-cb1d8d30cbc9'></a>

SOURCE: Team analysis; based on client mine plan

<a id='41faf00e-ab92-4785-81a2-92495f632bf8'></a>

McKinsey & Company | 21

<!-- PAGE BREAK -->

<a id='e7b6de12-08f6-4ebd-9d93-7a59e5367714'></a>

To date, there have been ~25 autonomous haul truck
trials, most of which have taken place in Australia

<a id='cccf9a36-8a42-4a33-8619-fa272b0fce05'></a>

<::diagramDescription: A flag-shaped graphic containing two rectangular fields. The top field is labeled "Mine site". The bottom field contains "..." and is labeled "Year tests began".::>

<a id='70099319-e3a2-40f4-9310-5de2797ec86b'></a>

Current trial and/or implementation locations

<a id='c9aa7f01-8bf6-4504-a8b3-9feeaf4a272a'></a>

<::Logos:
- Orange dot: SANDVIK
- Blue dot: HITACHI Inspire the Next
- Light blue dot: CATERPILLAR
- Dark blue dot: KOMATSU
- Green dot: ASI
- Yellow dot: NB logo::>

<a id='05485435-2a94-4e4d-9119-26be50d2a333'></a>

<::A world map with North America and Europe visible. North America is mostly gray, but the contiguous United States and Alaska are highlighted in blue. In the southwestern USA, a green flag is labeled "Navajo Coal" with the year "2006". Below it, a logo reads "F-M". In the southeastern USA, a light blue flag is labeled "..." with the year "2006". Below it, a logo reads "bhpbilliton". In Europe, the map is gray, but Sweden is highlighted in blue. In northern Sweden, an orange flag is labeled "Kiruna" with the year "2010". Below it, a logo reads "LKAB".
: map::>

<a id='c94d4a1a-1e5c-465f-8b8a-de26159a836a'></a>

<::A world map displaying various mining locations and their associated companies and years. The map is light grey, with Australia highlighted in dark blue. Mining locations are marked by flags of different colors connected to points on the map. The flags include: Kiruna (orange flag) in Northern Europe, 2010, with the LKAB logo. Finsch (orange flag) in Southern Africa, 2005, with the Petra Diamonds logo. In Australia, locations include: Yandi-coogina (dark blue flag), 2012, Rio Tinto. West Angelas (dark blue flag), 2010, Rio Tinto. Nam-muldi (dark blue flag), 2012, Rio Tinto. Hope Downs (dark blue flag), 2013, Rio Tinto. Meandu (dark blue flag), 2014, with the stanwell logo. Solomon (light blue flag), 2013, with the FMG Fortescue logo. Jimblebar (light blue flag), 2013, with the bhpbillitan logo. Two TBD (yellow flags), both 2015, with the bhpbillitan logo. These Australian locations are predominantly in Western Australia, with Meandu and one TBD location in Eastern Australia.: map::>

<a id='891e5beb-d4d8-4cba-ab91-a42db84659d9'></a>

<::Timeline visual on a map of South America. The map is light grey, with parts of Peru, Bolivia, Chile, and Argentina highlighted in blue. A vertical line connects two flag-shaped markers. The top marker, positioned over Peru/Bolivia, is dark blue and reads "Gabriela Mistral" with the year "2009" in a grey box. Below this text is a brown logo resembling a stylized 'C' or a mining cart, with the word "CODELCO" underneath. The bottom marker, positioned over Chile/Argentina, is also dark blue and reads "Radomiro Tomic" with the year "2005" in a grey box. Below this text is the same brown CODELCO logo and text.: figure::>

<a id='43f3ed79-9627-462d-83a6-19f9133c690b'></a>

SOURCE: Press search

<a id='516a17d2-6f91-4e91-a25a-3c8697c0bc80'></a>

McKinsey & Company

<a id='cec5b38f-83e0-4641-ac23-3579ed8ab262'></a>

22

<!-- PAGE BREAK -->

<a id='1ff261e6-8f43-41ea-8b03-13a1506604b7'></a>

Automated drilling is the latest step in the long evolution of drill and blast technology

<a id='f4d63494-f0fa-4c77-a19b-578f493d4c67'></a>

<table id="23-1">
<tr><td id="23-2">Manual drilling and blasting</td><td id="23-3">The beginnings of mechanization</td><td id="23-4">Towards current-day drills</td><td id="23-5">Drill-assist and autonomous drills</td></tr>
<tr><td id="23-6">Gunpowder invented ~1000AD, but are no references to applications to mining until 16th century One man drilling (using a steel drill and sledgehammer) most common approach into the 20th century</td><td id="23-7">First steam driven percussion rock drills were invented in early- 1800s, but adoption slow Alfred Nobel invented the blasting cap and safer dynamite explosives through the 1860s However, mechanized drill productivity still low. In 1870, at a US drilling competition, John Henry hammered through 14 ft of rock in 35 minutes His steam drill &quot;competitor&quot; only managed 9 ft</td><td id="23-8">Late 1800s-early 1900s: steam replaced by compressed air, and invention of the jackhammer 1945: Sandvik, Atlas and Fagersta designed a cemented tungsten carbide drill bit as economical to use as the conventional steel bits Post-war, drill rig mechanization sped up, with a strong emphasis on increasing mobility Hydraulic technology for rotary and downhole drilling also became available in the 1960s</td><td id="23-9">Drive towards automated drills picked up momentum with unveiling of the Atlas Copco Pit Viper 351 with CAN-bus control and 7 on-board computers at MineEXPO 2000 Sandvik and Atlas Copco lead the pack, with automated drills (with various degrees of automation) being tested and implemented around the world</td></tr>
</table>

<a id='6f4d4eea-5e9f-4211-859f-381260e90e28'></a>

SOURCE: Atlas Copco Blasthole Reference Book 2013, Sandvik

<a id='0ecf14f9-06ef-47a3-9483-4ef8247e91bb'></a>

McKinsey & Company

<a id='9cf3a8ff-35cd-4931-aeee-0b84890dba0b'></a>

23

<!-- PAGE BREAK -->

<a id='d5895f53-395c-4f87-a1ef-f8ed1b10b060'></a>

Tele-Remote/Autonomous Drill

<a id='934be5c2-c165-4198-be37-e9d4a53071b7'></a>

<::image of a hazard avoidance camera mounted on a yellow/orange structure against a blue sky. Hazard avoidance cameras See depths details and determine hidden range of obstacles::>

<a id='8ce4612f-f235-427a-b13d-5cec8be134f7'></a>

## High-resolution video
Transmit video back to the command center
* Enhance visibility
* No blind spot

<a id='06e238e6-e811-4cb7-81dd-4c642550ab45'></a>

<::A large white and orange/yellow drilling rig, marked with "EDD0165", is positioned on a dirt or gravel surface under a clear blue sky. The rig has large tracks for mobility and an elevated operator cabin, which is highlighted by a white oval overlay. The drilling mast extends upwards from the main body of the rig.: figure::>

<a id='58c94862-3afd-4905-9fb0-3fcf98147ea9'></a>

<::An illustration of a drilling rig on a sandy, barren landscape. Red lines crisscross the ground, forming a geo-fenced area, with numerous small red markers scattered within. Two light blue circular highlights are visible on the red lines. The drilling rig is positioned centrally within this geo-fenced zone. The associated text states: Geo-fencing sensors Prevent tramming into hazards: illustration::>

<a id='6ef15bf4-2842-41b1-9f29-99e2840132d4'></a>

High-speed on-board computer control
*   Geological information
*   Drilling times
*   Penetration rates
*   Navigation & traffic
*   Machine diagnostics
<::An illustration of a drilling rig, viewed from a slightly elevated angle. The rig is a large, complex piece of machinery with a tall mast, various platforms, and mechanical components. It appears to be situated on a barren, dark ground surface. Overlaid on the rig are glowing blue lines and a prominent glowing blue cube, suggesting digital monitoring, data flow, or sensor points on the equipment.
: illustration::>

<a id='8c35e28f-b28e-4ab9-bc60-590558294b0b'></a>

SOURCE: Sandvik

<a id='90867b43-5416-4c5f-be8b-c97ef49fa02b'></a>

McKinsey & Company

<a id='7cd29ad8-77c2-4a62-809e-8a22b4c44a3d'></a>

24

<!-- PAGE BREAK -->

<a id='f348b7af-9027-45d4-96b9-e85a21f4dad6'></a>

Tele-Remote and Autonomous drilling have significant potential

<a id='01bd51f0-5346-40ec-b8a4-2519b9929a8e'></a>

<::transcription of the content
: Favorable (thumbs up icon)
Adverse (thumbs down icon)::>

<a id='d784b521-26b7-4b30-ad99-e6a6b8c2e652'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3"></td><td id="25-4"></td><td id="25-5" colspan="2">Impact range</td><td id="25-6">(image of a gauge)</td></tr>
<tr><td id="25-7">Category</td><td id="25-8">Lever</td><td id="25-9">Impact</td><td id="25-a">Tele-remote</td><td id="25-b">Autonomous</td><td id="25-c">Rationale for impact</td></tr>
<tr><td id="25-d">Safety</td><td id="25-e">Safety</td><td id="25-f">(image of a thumbs up)</td><td id="25-g"></td><td id="25-h"></td><td id="25-i">▪ Fewer people in dangerous areas</td></tr>
<tr><td id="25-j" rowspan="4">OEE¹ (blue square)</td><td id="25-k">Availability</td><td id="25-l">(image of a thumbs up)</td><td id="25-m">0-10%</td><td id="25-n">0-15%</td><td id="25-o">▪ Reduced unscheduled downtime from more consistent usage cycles and reduced damage</td></tr>
<tr><td id="25-p">Utilization</td><td id="25-q">(image of a thumbs up)</td><td id="25-r">0-10%</td><td id="25-s">0-15%</td><td id="25-t">▪ Eliminate shift-change delays; reduce time lost to blast cycle</td></tr>
<tr><td id="25-u">Drill speeds</td><td id="25-v">(image of a thumbs up)</td><td id="25-w">0-3%</td><td id="25-x">0-3%</td><td id="25-y">▪ Algorithm reduces variation across fleet</td></tr>
<tr><td id="25-z">Redrilling and over-drilling</td><td id="25-A">(image of a thumbs up)</td><td id="25-B">50%</td><td id="25-C">75%</td><td id="25-D">▪ Algorithm controls drilling reduces chances of error</td></tr>
<tr><td id="25-E" rowspan="6">Operating and maintenance costs</td><td id="25-F">Drill rig labor</td><td id="25-G">(image of a thumbs up)</td><td id="25-H">Up to 75%</td><td id="25-I">Up to 95%</td><td id="25-J">▪ Operator:Machine ratio reduced to 1:3 for Tele-remote and 1:5 for autonomous</td></tr>
<tr><td id="25-K">Surveying labor</td><td id="25-L">(image of a thumbs up)</td><td id="25-M">100%</td><td id="25-N">100%</td><td id="25-O">▪ GPS positioning system eliminates need for floor demarcation tasks</td></tr>
<tr><td id="25-P">Fuel</td><td id="25-Q">(image of a thumbs up)</td><td id="25-R">0-5%</td><td id="25-S">0-10%</td><td id="25-T">▪ Lower consumption from more consistent operation</td></tr>
<tr><td id="25-U">Lubricants</td><td id="25-V">(Image of a green thumbs-up icon)</td><td id="25-W">0-5%</td><td id="25-X">0-10%</td><td id="25-Y">Lower consumption from more consistent operation</td></tr>
<tr><td id="25-Z">Drilling consumables</td><td id="25-10">(Image of a green thumbs-up icon)</td><td id="25-11">0-10%</td><td id="25-12">0-10%</td><td id="25-13">Lower consumption due to algorithm controlled, more consistent drilling operation</td></tr>
<tr><td id="25-14">Maintenance</td><td id="25-15">(Image of a green thumbs-up icon)</td><td id="25-16">0-10%</td><td id="25-17">0-20%</td><td id="25-18">Lower maintenance parts and labour costs from reduced wear due to more consistent operation</td></tr>
<tr><td id="25-19" rowspan="2">Capex (white text on blue background)</td><td id="25-1a">Drill rig capex</td><td id="25-1b">(Image of a red thumbs-down icon)</td><td id="25-1c">5-10%</td><td id="25-1d">15-20%</td><td id="25-1e">Higher drill costs due to additional equipment and sensors on drill</td></tr>
<tr><td id="25-1f">Infrastructure capex</td><td id="25-1g">(Image of a red thumbs-down icon)</td><td id="25-1h">~$0.5M</td><td id="25-1i">~$1M</td><td id="25-1j">Infrastructure costs for communications infrastructure, refueling system</td></tr>
</table>

<a id='3e9103e6-b3d4-463a-934f-5f4f8cbe92f4'></a>

1 OEE: Overall Equipment Effectiveness

<a id='ecd323a8-c38a-4f41-903d-b62542815765'></a>

SOURCE: Expert interviews; Press search

<a id='59f59097-bc50-4249-ad09-7b564694c9d8'></a>

McKinsey & Company

<a id='c7c7c893-c9ec-4596-840f-9e05eea0f848'></a>

25

<!-- PAGE BREAK -->

<a id='4cdea8f8-1b70-41f8-8972-f7294a051a00'></a>

OEE improvements account for more than 50% of the productivity
gains with labor savings being the next largest contributor
Drilling costs – USD $/m

<a id='b3b9493d-23fb-4cf3-acb7-3ae8988c0de0'></a>

PRELIMINARY

<a id='44a97b28-ed58-4e78-9d3b-32462300c24e'></a>

## Tele-Remote Drilling Total Cost of Ownership
3 drilling rigs per operator

<a id='999e6f61-b70e-460a-b386-5dc4282579b9'></a>

**Autonomous drilling Total Cost of Ownership**
5 drilling rigs per operator

<a id='5c716209-4cc0-4cf4-bfbb-e685dacb5368'></a>

<::transcription of the content: chart::>Waterfall chart showing cost reductions from autonomous drills. The chart compares two scenarios, likely 'Current' (left) and 'Autonomous' (right) based on the reductions.

**Left Scenario (labeled -13% overall reduction):**
- **OEE¹**
  - Manual drilling: 9.76
  - Availability: -0.16
  - Utilization: -0.18
  - Drilling speed: -0.22
  - Redrilling and over-drilling: -0.20
  - Subtotal for OEE¹: 9.00
- **Operating and maintenance costs**
  - Drill rig labor: -0.41
  - Surveying labor: -0.24
  - Fuel: -0.05
  - Lubricant: -0.02
  - Drilling consumables: -0.08
  - Maintenance: -0.01
  - Subtotal for Operating and maintenance costs: 8.19
- **Capex**
  - Drill rig capex: 0.17
  - Infrastructure capex: 0.15
  - Subtotal for Capex: 8.52
- Overall Reduction: -13%

**Right Scenario (labeled -16% overall reduction):**
- **OEE¹**
  - Manual drilling: 9.76
  - Availability: -0.33
  - Utilization: -0.38
  - Drilling speed: -0.22
  - Redrilling and over-drilling: -0.30
  - Subtotal for OEE¹: 8.54
- **Operating and maintenance costs**
  - Drill rig labor: -0.49
  - Surveying labor: -0.24
  - Fuel: -0.10
  - Lubricant: -0.03
  - Drilling consumables: -0.08
  - Maintenance: -0.11
  - Subtotal for Operating and maintenance costs: 7.47
- **Capex**
  - Drill rig capex: 0.41
  - Infrastructure capex: 0.30
  - Subtotal for Capex: 8.18
- Overall Reduction: -16%
::>

In addition to increasing safety by removing personnel from dangerous locations, autonomous drills can reduce drilling costs by up to 15%

<a id='fbffd2e5-857a-49a3-94a9-b836b81de3f2'></a>

1 OEE: Overall Equipment Effectiveness

<a id='abaaf4f9-b259-421c-acc4-1618887456df'></a>

SOURCE: Team analysis; based on client mine plan

<a id='89aa6a8c-34e1-4968-9ed2-5c1dece5d3d4'></a>

McKinsey & Company | 26

<!-- PAGE BREAK -->

<a id='31fd8503-e82b-4226-9c2f-bb1ee0b71e75'></a>

ADVANCED TECHNOLOGIES EXAMPLE – TELE REMOTE AND AUTONOMOUS EQUIPMENT

**Tele-Remote and autonomous drilling scenario assumptions**

<a id='40c81ea5-d33f-4f1d-ac29-b532d309427a'></a>

<table id="27-1">
<tr><td id="27-2">Category</td><td id="27-3">Lever</td><td id="27-4">Units</td><td id="27-5">Manual</td><td id="27-6">Tele-remote</td><td id="27-7">Autonomous</td></tr>
<tr><td id="27-8" rowspan="5">OEE¹</td><td id="27-9">Availability</td><td id="27-a">%</td><td id="27-b">80%</td><td id="27-c">85%</td><td id="27-d">90%</td></tr>
<tr><td id="27-e">Utilization</td><td id="27-f">%</td><td id="27-g">77%</td><td id="27-h">82%</td><td id="27-i">87%</td></tr>
<tr><td id="27-j">Drill speed</td><td id="27-k">m/hr</td><td id="27-l">40</td><td id="27-m">41</td><td id="27-n">41</td></tr>
<tr><td id="27-o">Redrilling (short holes)</td><td id="27-p">%</td><td id="27-q">3%</td><td id="27-r">1.5%</td><td id="27-s">0.8%</td></tr>
<tr><td id="27-t">Over drilling (refill long holes)</td><td id="27-u">%</td><td id="27-v">4%</td><td id="27-w">2%</td><td id="27-x">1%</td></tr>
<tr><td id="27-y" rowspan="12">Operating and maintenance costs</td><td id="27-z">Drill rig operator</td><td id="27-A">FTE / shift</td><td id="27-B">1</td><td id="27-C">33%</td><td id="27-D">20%</td></tr>
<tr><td id="27-E">Drill rig operator salary</td><td id="27-F">$/yr</td><td id="27-G">50,000</td><td id="27-H">50,000</td><td id="27-I">50,000</td></tr>
<tr><td id="27-J">Number of shifts</td><td id="27-K">Shifts / day</td><td id="27-L">4</td><td id="27-M">4</td><td id="27-N">4</td></tr>
<tr><td id="27-O">Survey hours</td><td id="27-P">Hr/yr</td><td id="27-Q">4,000</td><td id="27-R">0</td><td id="27-S">0</td></tr>
<tr><td id="27-T">Surveyor rate</td><td id="27-U">$/hr</td><td id="27-V">20</td><td id="27-W">20</td><td id="27-X">20</td></tr>
<tr><td id="27-Y">Drilling consumables</td><td id="27-Z">$/meter</td><td id="27-10">2.5</td><td id="27-11">2.4</td><td id="27-12">2.4</td></tr>
<tr><td id="27-13">Fuel</td><td id="27-14">$/hr of operation</td><td id="27-15">118</td><td id="27-16">115</td><td id="27-17">112</td></tr>
<tr><td id="27-18">Lubricants</td><td id="27-19">$/hr of operation</td><td id="27-1a">41</td><td id="27-1b">40</td><td id="27-1c">39</td></tr>
<tr><td id="27-1d">Over drilled (long hole) fill cost</td><td id="27-1e">$/meter</td><td id="27-1f">5</td><td id="27-1g">5</td><td id="27-1h">5</td></tr>
<tr><td id="27-1i">Maintenance and overhaul parts</td><td id="27-1j">$/hr</td><td id="27-1k">72</td><td id="27-1l">68</td><td id="27-1m">61</td></tr>
<tr><td id="27-1n">Maintenance and overhaul labor</td><td id="27-1o">$/hr</td><td id="27-1p">50</td><td id="27-1q">48</td><td id="27-1r">43</td></tr>
<tr><td id="27-1s">Infrastructure/drill rig IT maintenance</td><td id="27-1t">$/yr</td><td id="27-1u"></td><td id="27-1v">31,000</td><td id="27-1w">62,000</td></tr>
<tr><td id="27-1x" rowspan="2">Capex</td><td id="27-1y">Drill rig initial cost</td><td id="27-1z">$</td><td id="27-1A">5.2m</td><td id="27-1B">5.5m</td><td id="27-1C">6.0m</td></tr>
<tr><td id="27-1D">Infrastructure initial cost</td><td id="27-1E">$ (symbol)</td><td id="27-1F"></td><td id="27-1G">310,000</td><td id="27-1H">620,000</td></tr>
</table>
1 OEE: Overall Equipment Effectiveness

<a id='1de622f7-7360-4cfa-b9c9-f468cad66351'></a>

SOURCE: Expert interviews; Client Latin American Copper Mine parameters; Press search

<a id='8602ac83-190a-422f-936b-b1c829a8af74'></a>

McKinsey & Company

<a id='b592405b-f747-48ac-943f-f5f9e04e026d'></a>

27

<!-- PAGE BREAK -->

<a id='55a7a6c5-9772-4ac8-aadd-0645f5972be2'></a>

Companies are planning for the future with technology
in mind and expect revenues to keep growing at ~4%p.a.

Revenues & EBITDA of the global mining industry
USD billion, real terms 2013

Revenues
EBITDA
Revenue CAGR (%)
Average industry
EBITDA margin (%)

<a id='7c3f07d0-12ce-4786-8e62-106065609f44'></a>

<::Line chart: The chart displays values on the Y-axis ranging from 0 to 1,500 and years on the X-axis from '95 to '25. There are three lines and several percentage annotations. The background features a semi-transparent image of a hand pointing at a keyboard. A dark blue solid line starts around 400 in '95, with a 0.8% p.a. growth until around 2000. It then shows a sharp increase of 24.5% p.a. until around 2008, followed by a decrease of -5.1% p.a. until around 2012. From 2012 to 2025, it shows a growth of 3.9% p.a., reaching above 1,500. A light blue solid line starts around 150 in '95 and steadily increases to approximately 1,400 by 2025, with a segment showing 3.4% p.a. growth from around 2015 to 2025. A light blue dashed line starts around 50 in '95, fluctuates, and ends around 400 in 2025. Below the X-axis, specific year markers have associated values: under '95 is ~25, under '05 is ~25, under '10 is ~40, under '15 is ~30, and under '20 is ~30.::>

<a id='cec423d7-a6be-44cf-b58a-a87414ef3902'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='ccc19542-5d31-4746-a4f9-cbee14a09732'></a>

McKinsey & Company

<a id='efbed24f-82cb-45f4-b0dd-205d409902e9'></a>

28

<!-- PAGE BREAK -->

<a id='f0ad3864-411c-4017-a2f6-58459d23c0cd'></a>

How are you positioning yourself for the future?

<a id='15367d16-8e17-4e64-9bae-0d8392e5df38'></a>

> "I believe we need to hit the reset button in terms of how we think about innovation and mining in the future"

– *Mark Cutifani, CEO Anglo American*

<a id='354d39ac-0238-4d30-8321-b43456458716'></a>

<::logo: Anglo American
AngloAmerican
The logo features a stylized, abstract triangular shape composed of concentric blue and red outlines, resembling a layered or spiraling design.::>

<a id='bfb3f6d8-18ac-4a82-8b51-4770de5e9180'></a>

SOURCE: Press search

<a id='5172e3c4-8928-4345-9bee-09204e082127'></a>

McKinsey & Company

<a id='a8410b17-722e-4d51-9185-f4de766bfff2'></a>

29

<!-- PAGE BREAK -->

<a id='4d1c4794-eadc-4e76-bad8-49f12469ee1c'></a>

Summary of the rare earth market outlook

<a id='29ca9873-ad00-4437-a7d3-88dfcbd4fcfd'></a>

* Rare earths are a group of 17 elements, which are divided into light and heavy rare earths. They are used in a wide range of applications, such as **permanent magnets, metal alloys, catalysts and polishing powders**
* The market is large and growing ($8B and ~113 ktons of demand after separation of individual oxides, growing at a 7% CAGR), with heavy rare earths representing <15% of the volume, but ~50% of revenues
* China holds most of the production along the value chain (~80-100%), as well as most of the known reserves, letting it control prices through management of **export quotas**
* Outside of China, most projects are **focused on light rare earths**
  * Rare earths expected to be critical are mainly heavies (Dysprosium, Yttrium, Terbium and Europium), together with the light element neodymium
  * The pipeline of heavy rare earth projects is limited to less than 10k tons and they are at **very early stages of development**
* If China continues to act rationally (and from expert interviews it seems that it will maintain quotas for heavy rare earths at present levels) **prices should continue at greenfield incentive levels**, allowing some penetration from the rest of the world
* Based on this, a mine that is “heavy on heavies” would find itself in a privileged position

<a id='29ed0b3d-902d-4c92-acc2-163018cd4a09'></a>

McKinsey & Company

<a id='d2e19c89-a46d-4a3f-88f2-caf40f36c454'></a>

30

<!-- PAGE BREAK -->

<a id='03b9e267-2360-4f95-8b2c-6fef06de1a4d'></a>

RE are essential in the manufacturing of several products, used every day,which has led to a rapid increase in their demand

<a id='221e1c8a-9a33-470a-9dec-aac163086d1f'></a>

NOT EXHAUSTIVE

<a id='f9c9d9d8-9529-4a3f-ba7d-b84f9b0b33d1'></a>

# Applications of Light RE Elements

<::transcription of the content
: figure::>

## Lanthanum
*   Used in electric and hybrid vehicles, laptop computers, cameras, high-end camera lenses, telescopes, binoculars – as lanthanum improves visual clarity;
*   Used to reduce the level of phosphates in patients with kidney disease

<a id='3b1de919-d221-4fb2-86f9-b80e5b3b4362'></a>

<::image of a bar magnet with magnetic field lines around it, showing the field originating from one end (red) and curving around to the other end (silver) with arrows indicating direction: diagram::>
Samarium
- Primary use is in the production of permanent magnets but also in X-ray lasers
- Precision guided weapons and white-noise production in stealth technology

<a id='33f6e68e-0087-4670-be83-e3fc1d6add47'></a>

<::photo of two stacks of circular, metallic neodymium magnets: photo::>Neodymium * The principal use is in the manufacture of the strongest magnets in the world. These magnets are so strong that one the size of a coin cannot be removed from a refrigerator by hand * Other important applications include laser range finders and guidance systems

<a id='bbcbae6c-797b-454c-9acc-1c0c96284c69'></a>

<::transcription of the content
: The image shows a colorful, iridescent sphere, possibly a polished gemstone or a marble, with swirling patterns of blue, green, purple, and red.
: figure::>

# Cerium

* Used to polish glass, metal and gemstones, computer chips, transistors and other electronic components
* Automotive catalytic converters to reduce pollution
* Added in glass making process to decolorize it, gives compact fluorescent bulbs the green part of the light spectrum

<a id='ea18e9c1-269c-4e72-8332-ff84c90e1e2b'></a>

Applications of Heavy RE Elements

<a id='74352bbd-dee4-44a7-9a5a-a2963826e1f8'></a>

<::transcription of the content
iPod nano
: figure::>

# Dysprosium

* Most commonly used in the manufacture of neodymium-iron-boron high strength permanent magnets
* Injected into joints to treat rheumatoid arthritis
* Used in radiation badges to detect and monitor radiation exposure

<a id='38c41b1b-a6f4-4c05-8ebe-2c28e06ac497'></a>

Yttrium
<::Image of a rocket launching with fire and smoke
: figure::>
* Used in energy efficient fluorescent lamps and bulbs
* Used in high temperature applications, such as thermal barrier coating to protect aerospace high temperature surfaces
* Can increase the strength of metallic alloys

<a id='5b41ce83-ce8f-4a35-99fa-2e8794da3c3d'></a>

<::transcription of the content
: illustration::>

## Gadolinium

*   Used to enhance the clarity of MRI scans by injecting Gadolinium contrast agents into the patient
*   Used in nuclear reactor control rods to control the fission process

<a id='aae64328-49f3-4067-93d8-cb4ee6632d62'></a>

## Europium

*   Primarily used in phosphors used in pilot display screens, televisions and energy efficient fluorescent lights

<a id='6c99749b-575f-47ae-b89f-d722fa811fda'></a>

SOURCE: IAMGOLD Report, General Web, team

<a id='1410010a-334e-45df-9c6e-58a57d72325f'></a>

McKinsey & Company

<a id='8f5bfd4b-38e6-4b17-86ba-8e4e01364ee4'></a>

31

<!-- PAGE BREAK -->

<a id='7d54938f-3ed3-450d-ad75-c322ce167fae'></a>

Increasing demand for RE has led to other countries looking for potential reserves to reduce their dependency on China
Million metric tons

<a id='fb887586-69c6-42bc-b92f-d292be3cb1a8'></a>

Rare Earth Reserves¹<::World map illustrating rare earth reserves by region:
- USA & Canada: 14
  - Associated text for USA:
    - Was self-reliant
    - Currently imports 100%
    - Mainly due to lower costs
    - Molycorp owns biggest deposit in USA
- China: 55
  - Associated text for China:
    - Holds 50% of reserves
    - Controls 90% of the supply
- India: 3.1
- Australia: 1.6
- RoW (Rest of World): 22
- Japan:
  - Associated text for Japan:
    - 100% importer
    - Have recently found 80-100 mn metric tons of REE in the Pacific seabed
: map::>

<a id='b7a51b82-c00c-4ebb-a68e-a6ddcd68d304'></a>

a
1
<::A map showing parts of Asia and Australia. A blue circle is placed over India.
: map::>

<a id='c6a726d4-35d1-42ed-a426-052a7860a8ab'></a>

With the development of new projects, it is expected that this
scenario, with China being the dominant player, will also change

<a id='a49ae3f3-4bff-4cd0-aacd-61dd855c8cc9'></a>

1 Referring only to the identified RE reserves

<a id='e9360a2a-a2a2-46c7-8f0c-f0c7e8c01be5'></a>

SOURCE: USGS, General web and press

<a id='3c8e74ff-87cd-4784-8a90-2259cd1ea64d'></a>

McKinsey & Company

<a id='22cb75b8-359b-4c0c-9b53-a12e4c22c852'></a>

32

<!-- PAGE BREAK -->

<a id='8fcc4bd1-cf14-4dd6-8a29-b70838d26301'></a>

SUPPLY

There is a number of projects in the pipeline,
but most focus on light rare earths

<a id='a46ebbb2-7f37-471d-ab63-c9a23f4a319d'></a>

<::legend
- Green square: HRE
- Red square: LRE
- Dark blue circle: High
- Light blue circle: Low
: legend::>

<a id='e3b1cbc6-a436-4d24-a297-6a7f79e13af1'></a>

NOT EXHAUSTIVE

<a id='b85a24f0-4476-477e-a1f1-094cf9aa1db3'></a>

Company Project Resource TREO Mt Capacity TREO tpa HRE share % Status Likelihood
<::Canadian flag: flag::> IAMGOLD Niobec 7.70 139,597 1.76 Scoping <::Likelihood indicator: a light blue circle with a small dark blue segment: chart::>
<::Greenland flag: flag::> Greenland Minerals and Energy Kvanefjeld 6.55 51,900 11.80 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Avalon Rare Metals Nechalacho 5.64 8,504 13.84 Feasibility <::Likelihood indicator: a light blue circle with a dark blue half: chart::>
<::Canadian flag: flag::> Commerce Resources Eldor 4.69 50,743 4.04 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Tanzanian flag: flag::> Peak Resources Ngualla 3.82 93,519 1.99 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Geomega Resources Montviel 3.65 105,903 1.71 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Greenland flag: flag::> Greenland Minerals and Energy Sørensen 2.66 N/A 11.72 TBD <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Quest Rare Minerals Strange Lake 2.10 10,652 39.03 Pre-feasibility <::Likelihood indicator: a light blue circle with a dark blue segment: chart::>
<::USA flag: flag::> Molycorp Mountain Pass 2.07 40,301 0.60 Pre-production <::Likelihood indicator: a dark blue circle: chart::>
<::Australian flag: flag::> Lynas Corporation Mount Weld CLD 1.45 22,165 2.85 Pre-production <::Likelihood indicator: a dark blue circle: chart::>
<::Australian flag: flag::> Arafura Resources Nolans Bore 1.24 19,298 3.34 Pre-feasibility <::Likelihood indicator: a light blue circle with a dark blue segment: chart::>
<::Brazilian flag: flag::> MBAC Fertilizer Araxá 1.19 13,154 2.67 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>

<a id='3e7cff4f-864f-4b79-99b8-113fa581d9ac'></a>

SOURCE: Technology Metals research, expert interviews, companies' reports, press

<a id='2b231da3-b4f3-451f-9e4f-d4fc18170326'></a>

McKinsey & Company

<a id='8f328f5b-3b2c-4d15-bf94-cef067ecf7e7'></a>

33

<!-- PAGE BREAK -->

<a id='3f3b0275-9743-4adb-8e3e-6aaf3a56ba8a'></a>

However, exploration successes are becoming expensive and scarce
10 year period 2003-12

<a id='94e39bf1-03c2-4ef7-9b40-81f1c9de7393'></a>

<::chart::>Spending, USD Billions | World-class/Other Discoveries
---|---
Lat America | 28 | 15 | 103 | 118
Canada | 22 | 49 | 16 | 65
China + CIS | 22 | 66 | 11 | 77
Africa | 17 | 19 | 97 | 116
Australia | 12 | 13 | 70 | 83
USA | 9 | 9 | 11 | 20
SE Asia/Pacific | 6 | 2 | 21 | 23
W Europe | 3 | 1 | 21 | 22
GLOBAL | 116 | 86 | 438 | 524
NEEDED | 140 | 125 | 625 | 750

- Across all major regions, world-class discoveries cost over 1 billion USD
- Africa and the USA were the most "effective" regions
- Gold deposits still account for nearly half of all discoveries
- .. But only finding 2/3 of the deposits we need<::>


<a id='64544b1a-e8a9-4b6a-81b2-4f0e3848ceac'></a>

SOURCE: McKinsey BMI; MinEx Consulting

<a id='04f19d79-839f-4527-872b-16f978ef9c1b'></a>

McKinsey & Company | 34

<!-- PAGE BREAK -->

<a id='ae542250-6d46-4c9a-90f5-37a193d684c8'></a>

New and current mining projects will be face strong market forces, which
will have significant impact on the industry over coming decades

<a id='5da53cc7-3126-4e1f-be84-5dabfc54b144'></a>

1. Continuously increasing safety, health and environment standards
2. High demand and prices but significant volatility
3. Increasingly challenging geologies
4. Polarization of scale creates new challenges
5. Increasingly challenging supply chains
6. Rising energy costs
7. Rising water costs
8. Scarcity of talent
9. Global sourcing

<a id='dba0bb9a-0c68-4647-afc8-051808a53479'></a>

SOURCE: McKinsey analysis

<a id='66ed9760-4477-47d8-80aa-d2d9a1f7e63c'></a>

McKinsey & Company

<a id='cda96141-08a5-43d2-b3b1-987e9f5827bf'></a>

35

<!-- PAGE BREAK -->

<a id='23df75f7-6d54-41bd-b3cc-26565206856a'></a>

PRICING

<a id='d1f06578-02b7-4a14-b862-f702cb77d028'></a>

Going forward, a greenfield incentive price scheme is expected for heavy elements and neodymium1

--- Deutsche Bank | ESTIMATES

<a id='667215a0-3c09-4017-87e5-592662836737'></a>

Historical and future price estimates
Dollars per kg

<::chart: Line charts showing historical and future price estimates for five rare earth elements from 2002 to 2017. The y-axis for all charts is labeled "Dollars per kg". The x-axis for all charts represents years from 2002 to 2017.

Legend:
- CIBC: Dashed line
- McKinsey greenfield incentive: Solid line

Panel 1: Yttrium
- Y-axis: 0 to 150
- Chart shows prices were low and stable until around 2010, spiked significantly around 2011, then declined. Future estimates show a CIBC price of 67 and a McKinsey greenfield incentive price of 89 by 2017.
- Associated text:
  - Should be in a greenfield incentive regime in the short-medium term, until some of the new capacity eases the supply/demand tightness

Panel 2: Dysprosium
- Y-axis: 0 to 1500
- Chart shows prices were low and stable until around 2010, spiked significantly around 2011, then declined. Future estimates show a CIBC price of 605 and a McKinsey greenfield incentive price of 688 by 2017. An earlier McKinsey estimate is 1019.
- Associated text:
  - Expected to remain in greenfield incentive for the foreseeable future, with eventual fly-ups depending on China's export policies

Panel 3: Terbium
- Y-axis: 0 to 3000
- Chart shows prices were low and stable until around 2010, spiked significantly around 2011, then declined. Future estimates show a CIBC price of 865 and a McKinsey greenfield incentive price of 1056 by 2017. An earlier McKinsey estimate is 1144.
- Associated text:
  - Should be in a greenfield incentive regime in the short-medium term, until some of the new capacity eases the supply/demand tightness

Panel 4: Neodymium
- Y-axis: 0 to 300
- Chart shows prices were low and stable until around 2010, spiked significantly around 2011, then declined. Future estimates show a CIBC price of 67 and a McKinsey greenfield incentive price of 77 by 2017. An earlier McKinsey estimate is 93.
- Associated text:
  - Tightness to be eased with volumes from Lynas and Molycorp
  - Should be back to greenfield/fly-up in longer term

Panel 5: Europium
- Y-axis: 0 to 3000
- Chart shows prices were low and stable until around 2010, spiked significantly around 2011, then declined. Future estimates show a CIBC price of 1022 and a McKinsey greenfield incentive price of 1269 by 2017. An earlier McKinsey estimate is 1393.
- Associated text:
  - Expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
::>

1 Assuming that China will put maximum 

<a id='b27f0eb5-52a6-4f64-9ade-fb0b10f7dc48'></a>

SOURCE: Analyst reports, team analysis

<a id='5af79d11-38a9-4eac-9d8d-fb0c9c570166'></a>

McKinsey & Company | 36

<!-- PAGE BREAK -->

<a id='61141c4d-c899-4d08-9fcc-7f3589f43589'></a>

GLOBAL SUPPLY-DEMAND BALANCE

<a id='136b464d-ef4f-4874-bc4f-e9f07b1eb0f3'></a>

Mines holding considerable quantities of these five elements will be in a good position in the future

<a id='03be36c7-0101-4356-baa9-fabec516b6d7'></a>

**Y**
* Yttrium is expected to be in shortage in the short term, with most of the new supply only coming online through the end of the decade
* Expert opinions: "I don't see relevant new capacity outside of China coming online in the next few years"

**Dy**
* Dysprosium is expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
* Severe shortage could trigger investments in magnet recycling technology or even partial substitution/decrease in intensities

**Tb**
* Slower demand growth for Terbium when compared to Dysprosium and Yttrium could lead to a balanced market already in the short term
* Given the relatively low volume of the global terbium market, small amounts as by-product from large light-focused projects such as Mountain Pass and Mount Weld could ease the tightness

**Nd**
* Relevant volumes of Neodymium coming from Mountain Pass and Mount Weld in the short term should ease the tight supply-demand balance
* In the longer term, new projects will probably be needed to meet Nd demand

**Eu**
* Europium is expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
* Severe shortage could trigger investments in phosphors recycling, such as the research conducted by Rhodia in France in the last few years

<a id='6ae1de5b-0dd9-4731-a008-934de460d3ba'></a>

SOURCE: Expert interviews, McKinsey

<a id='6576732d-eab5-48a1-90f0-85efe1852141'></a>

McKinsey & Company

<a id='9793cb89-ef35-496a-a8ce-fb9cfbbb08ca'></a>

37

<!-- PAGE BREAK -->

<a id='81de3105-df8f-42ba-a8ae-af9337d6c5bc'></a>

SUPPLY
With this relevant position, China controls the current price dynamic

<a id='1ecdb270-c7ef-4539-a517-f352dd398b08'></a>

<::Bar chart showing Export quota evolution of rare earth in China. The y-axis is labeled "Thousand tons" and the x-axis represents years from 2006 to 2012. The bar heights for each year are: 2006: 62, 2007: 60, 2008: 47, 2009: 50, 2010: 30, 2011: 30, 2012: 31. An arrow indicates a -40% decrease from the 2009 level (50 thousand tons) to the 2010/2011 levels (30 thousand tons).
: chart::>
<::Line chart showing Prices of dysprosium oxide in China. The y-axis is labeled "$/kg" and ranges from 0 to 2000. The x-axis represents years from 2006 to 2012. The line shows prices gradually increasing from 2006 to 2010, then a sharp increase to a peak near 2000 $/kg around 2011, followed by a sharp decrease and then a slight rise, ending at 800 $/kg in 2012. Two annotations are present:
- "Peak of prices caused by export quotas reduction" pointing to the peak around 2011.
- "Drop in 2012 as a result of demand decrease due to unsustainably high prices, but still significantly higher than historical levels" pointing to the price drop and the 2012 value.
: chart::>

<a id='1a8f4253-eea9-4f77-88da-ea4ddf09e2af'></a>

- In 2010, China tightened export quotas for heavy and light rare earths; in the future:
  - Light quotas could be eliminated as new light REO sources are coming online
  - Heavy quotas should remain as China does not have enough reserves and few new heavy rare earth sources are coming online in the future
- If China acts rationally, it will look to maximize profits which would maintain prices at higher than historical levels letting smaller players into the market. However they hold the power to avoid the entry of other players if they wanted to.

<a id='5dfab38f-469e-49c0-86eb-ceeb164c1f68'></a>

SOURCE: MOFCOM, Press search

<a id='0fa198d7-135c-4abe-b27a-d27fb1af0360'></a>

McKinsey & Company

<a id='d8e5e46d-ae40-4e3b-8d87-dbaeebdb7d6a'></a>

38

<!-- PAGE BREAK -->

<a id='6dfec1a7-8707-4946-a162-f7d8ee6376d2'></a>

This has resulted in companies looking for different
avenues to meet their growing requirements;
for which substitution seems best suited

<a id='cb6f3b8b-d470-4711-a35a-1cb356f7a00e'></a>

<::logo: Unknown
Fuller the moon, more viable
A blue and light blue circle is partially shaded, resembling a moon phase.::>

<a id='f79b41e1-2fea-4be9-8dc2-04c802313489'></a>

Best way forward

<a id='b46ba6cb-b9dd-49a8-93ed-6497e09acc37'></a>

3 best measures to adopt to avoid falling into supply shortage problems

Reduction in the usage of RE is a process that is not yet economically tested by many companies

Some areas where this has come useful is in LED television sets, which require lesser RE than LCD sets

Recently, generator manufacturers have reduced RE content and have used other metals like nickel, which provides similar levels of performance

RE used in fluorescent lighting and computer hard drives, can be recycled

Extract RE from used hybrid motors and lithium-ion batteries in addition to nickel-metal hydride batteries

Benefits of recycling RE from batteries is that a supply of recycled lanthanum should be more reliable than relying on new Chinese sources

Recycling also uses less energy and emits less carbon di than mining

<a id='7363a71d-e83f-4b96-adbc-3c8eab436bab'></a>

Motor companies are looking towards creating new techniques to substitute RE, like induction motors and nickel-hydride batteries
Some companies have also substituted RE with iron based amorphous core for motors which is 5% more efficient
Companies who are taking the initiative towards substitution are Hitachi, Ford, Continental AG and Honda

<a id='9f3b3594-41a7-4cd7-a232-51a6c5577ff1'></a>

SOURCE: General web and press, team

<a id='f2f81a9c-1f58-4451-b97c-56b81bca9250'></a>

McKinsey & Company

<a id='93e238be-7213-4232-85aa-a5fae2c71352'></a>

39

<!-- PAGE BREAK -->

<a id='5c5282bb-e173-49ea-9c70-989e062da58b'></a>

SUPPLY
In the rest of the world the pipeline of heavy projects is limited to less than
10k tons

<a id='4afe8de5-87f5-45eb-a8bd-0e10e34c801b'></a>

<::Projects in the pipeline by type. Percent, number of projects, TREO ktpa. The chart displays two stacked bar charts. The first bar, labeled "# of projects," represents 45 total projects (100%). It is divided into "Heavy¹" at 33% and "Light" at 67%. The second bar, labeled "Projected production," represents 112 thousand tons. It is divided into a heavy-focused portion at 7% and a light-focused portion at 93%. A callout box states: "Total production from heavy-focused projects expected to account for only ~7k tons of additional production (55% of current supply)".: chart::>

<a id='a935371d-bdc4-4100-9b7a-03c4ee9c4dcf'></a>

1 Heavy rare earths projects are the ones with more than 15% of total rare earth content of heavy elements

<a id='5ac45079-21b8-4280-b76a-4d8ee21afa2a'></a>

SOURCE: Technology Metals Research, expert interviews, companies' reports, press

<a id='70749017-1a72-4405-b7a1-8a641ec66362'></a>

McKinsey & Company

<a id='e25f7e62-bc7c-4ee2-a204-9c4d9c9e8bd0'></a>

40