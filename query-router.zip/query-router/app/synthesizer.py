"""Synthesizer: merges results from multiple execution steps into one answer."""

from __future__ import annotations

import json
import logging

import anthropic

from app.config import settings
from app.models import ExecutionPlan, StepResult, StepStatus

logger = logging.getLogger(__name__)

SYNTHESIZER_SYSTEM = """\
You are a financial services assistant synthesizing information from
multiple data sources to answer a user's question.

You will receive:
- The original user question
- The execution plan (which sources were queried and why)
- The results from each step

Your job:
1. Merge and reconcile all step results into a single, coherent answer.
2. If any step failed, note what information is missing and answer with
   what you have.
3. Be precise with numbers and cite which source provided which fact.
4. If results conflict, flag the discrepancy to the user.
5. Keep the answer concise and well-structured.
"""


class Synthesizer:
    def __init__(self) -> None:
        self._client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)

    async def synthesize(
        self,
        question: str,
        plan: ExecutionPlan,
        results: list[StepResult],
    ) -> str:
        """Produce a final answer by merging *results*."""

        # Fast path: single successful step → just return its data
        successful = [r for r in results if r.status == StepStatus.SUCCESS]
        if len(results) == 1 and len(successful) == 1:
            return str(successful[0].data)

        # Build context block for the LLM
        step_summaries: list[str] = []
        for step, result in zip(plan.steps, results):
            status_str = result.status.value
            data_str = (
                json.dumps(result.data, indent=2, default=str)
                if result.data is not None
                else "(no data)"
            )
            error_str = f"  Error: {result.error}" if result.error else ""
            step_summaries.append(
                f"### Step {step.step_id}: {step.description}\n"
                f"Source: {step.source.value}\n"
                f"Status: {status_str}{error_str}\n"
                f"Result:\n{data_str}"
            )

        user_message = (
            f"## Original Question\n{question}\n\n"
            f"## Plan Reasoning\n{plan.reasoning}\n\n"
            f"## Step Results\n\n" + "\n\n".join(step_summaries)
        )

        response = await self._client.messages.create(
            model=settings.synthesizer_model,
            max_tokens=4096,
            system=SYNTHESIZER_SYSTEM,
            messages=[{"role": "user", "content": user_message}],
            temperature=0,
        )

        return response.content[0].text.strip()
