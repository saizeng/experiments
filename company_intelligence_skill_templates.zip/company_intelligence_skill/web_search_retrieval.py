"""
Stub implementation for web search retrieval.
Replace this with real web search integration.
"""

from typing import Dict, Optional


def run_web_search(query: str, company_name: Optional[str] = None) -> Dict:
    return {
        "company": company_name or "Example Company",
        "confidence": "medium",
        "data": {
            "note": "Replace this stub with web search logic.",
            "query_received": query,
        },
        "references": [
            {
                "source": "Web",
                "url": "https://example.com",
                "title": "Example web result",
            }
        ],
    }
