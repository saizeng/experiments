<a id='f2ce6dee-0bf3-462c-b16a-fe667cd3dc54'></a>

<::An image showing stacks of white bags or boxes, each with "UNITED STATES" printed on it multiple times, next to stacks of blue plastic crates.: figure::>

<a id='741afd9b-a9e5-487f-9e89-bbfb037ba67b'></a>

Envisioning America's
Future Postal Service
Options for a Changing Environment

<a id='e1329f52-2ea7-44da-8e7a-041e8f70d55d'></a>

March 2, 2010

<a id='32de7fea-57df-457b-8f1a-8d8e8785ee61'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='6056b28d-6b62-4934-94d4-97dcc0034f67'></a>

<::Image of stacks of blue plastic crates and white plastic containers. The white containers are labeled with text, which includes:
INTEN
UNITED STATES
UNITED STATES
UNITED STATES
NITED STATES
IMITED STATES
UNITED STATTO
UNITED STATES
FASTER STATES
UNITED STATES
UNITED STATES
LUNITED
20
: figure::>

<a id='39dca25d-e08c-4176-a241-85e1ead219d5'></a>

Today's discussion

<a id='12709600-a44c-4025-a7f0-6f34d9983616'></a>

- Review of economic trends and financial forecast

<a id='c74b5f2a-ffed-4378-bf64-9da01e7a8296'></a>

▪ Value of planned actions

<a id='076c6868-2535-4565-865b-b820d7ad6011'></a>

- Additional options to ensure a viable Postal Service

<a id='e11a47af-581c-4c4b-8e35-129e87172631'></a>

1

<a id='91b7953f-3b07-41f8-937e-447a96fbf5c4'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='a3dcdfab-f1e5-4e1e-8dd7-0f765b0ee4ba'></a>

McKinsey built an integrated forecast and set of options

<a id='b1707760-0358-4d2b-b3bb-ffac60520a50'></a>

Volume forecast

BCG
THE BOSTON CONSULTING GROUP

Prepared volume and revenue
projections of the USPS core
mailing and shipping business

<a id='66b65bd5-b852-436c-9ae4-6c6165b5faae'></a>

Revenue diversification
research

accenture

Examined revenue diversification
pursued by foreign posts

<a id='2d27ebef-25dc-4862-ad70-96dc63e36b06'></a>

Integrated business forecast

McKinsey&Company

Integrated the BCG and
Accenture work with
USPS data

<a id='ffb083ed-3355-42fb-8ade-3d81788bc5e4'></a>

- Forecast baseline and scenario profitability

<a id='df688af1-3478-442c-9568-f64b9753e285'></a>

* Assessed a comprehensive list of revenue and cost options

<a id='7d42348a-cf89-4c20-9b4d-9a8086f358ff'></a>

2

<a id='4ea6a349-261c-4165-951b-010aa2089ece'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='d63a66f2-d2c0-4adf-8fae-1344a3b5eeba'></a>

Four trends are increasing pressure on USPS

<::transcription of the content
: Revenue trends
Volume
Declining steadily

Price
Rising but capped

Cost trends
Universal Service
Obligation
Large fixed cost base

Workforce costs
Rising cost per hour

UNITED STATES
POSTAL SERVICE
: infographic::>

<a id='3389a8e4-5917-4e20-9c4a-1d38e9c21a6f'></a>

3

<a id='785f2930-846e-4ead-befd-ac892972bbb4'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='eb52001c-10ef-4b95-a95c-c4780c45fd0c'></a>

Price: Price increases combine with volume declines for flat revenue through 2020

<a id='666c1a03-e0b3-4315-a27d-bd2500be769c'></a>

Volumes declining
-1.5% per year from
2009-2020

X

Prices rising
with inflation
+1.9% per year from
2009-2020

<a id='47df3f6e-49c4-46bc-8c1d-8660150c91ea'></a>

<::USPS revenue in Billions, presented as a waterfall chart.The chart starts with "2009 revenue" at $68 B. There is a decrease of $16 due to "Volume decline & mix shift", followed by an increase of $17 due to "Price impact". The chart concludes with "2020 revenue" at $69 B.
: chart::>

<a id='bb3edaf0-8660-4714-a1b6-bd9ace881bef'></a>

4

<a id='820fcb1a-09a7-4617-a26d-aaea277a51a8'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='560696e9-64cb-4b75-8b3d-0e133dc37323'></a>

Revenue trends: Declines focused in higher contribution First-Class Mail <::chart: This bar chart displays volume trends in billion pieces for First-Class and Standard mail, comparing data from 2009 and 2020. Volume is measured in Billion pieces. For First-Class mail, the volume decreased from 84 in 2009 to 53 in 2020, representing a -37% change. For Standard mail, the volume increased from 83 in 2009 to 86 in 2020, representing a +4% change. Below the chart, the "Portion of total margin available to cover fixed costs (2009)" is shown as 71% for First-Class mail and 21% for Standard mail.::>

<a id='c2ffd7ed-0159-44fb-90bf-8c1e72c43c9c'></a>

5

<a id='4469bb31-3ab3-43f7-9c6a-c2fe4be61251'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='02cfb172-a9b7-415c-8f92-5e38ffd8c597'></a>

Universal Service Obligation

<a id='8800ed1f-e1b8-4de9-a008-aea5edd81926'></a>

<::A composite image with a stylized map of the United States (including Alaska and Hawaii) in white on a dark blue background. Overlaid on the map are three photographs and text. The top photograph shows a post office building with a blue awning and the USPS logo. A sign on the building reads: UNITED STATES POST OFFICE UPTOWN STATION HOBOKEN, NEW JERSEY 070. The bottom left photograph shows an open black mailbox on a wooden post, containing several envelopes, set against a cloudy sky. The bottom right photograph depicts complex mail sorting machinery with multiple compartments. The central text reads: Network was historically built to provide high service levels to customers, regardless of volumes
: composite image::>

<a id='c69bcc1f-94ea-418c-b92d-fc489aa503c4'></a>

6

<a id='bb187015-a204-465a-9fe4-95ca608620e2'></a>

<::McKinsey&Company: figure::>

<!-- PAGE BREAK -->

<a id='0f5dac47-f4bc-4ded-81b3-5729ad1b6234'></a>

Universal Service Obligation:
Customer service network costs are largely fixed

<a id='188425f4-4d49-4bab-89c9-3711cb04b428'></a>

<::A photograph of the exterior of a United States Post Office building. The building has a reddish-brown facade with horizontal siding. Above the main entrance, a blue awning with the white USPS eagle logo is visible. On the building facade, white text reads "UNITED STATES POST OFFICE UPTOWN STATION HOBOKEN, NEW JERSEY 070". Below the text and awning are large glass windows reflecting the surrounding environment.: figure::>

<a id='a94dfc70-fdae-44da-b7b7-76c85a8640c3'></a>

<::U.S. retail locations chart::>
<::Title: U.S. retail locations
Unit: Thousands

Bar chart data:
- USPS: 36.5
- McDonalds: 13.9
- Starbucks: 11.1
- Walgreens: 7.5
- Walmart: 3.6
: chart::>

<a id='d5ebdd8d-9cf6-4f5a-98d8-f89edb4b6b55'></a>

Service network
* 600 weekly counter customers at the average Post Office, 1/10th of Walgreens
* Prohibited from closing Post Offices solely for economic reasons

<a id='b2584588-e096-427b-af7a-2e15d9a1c0a3'></a>

7

<a id='3ef8e6bb-5b06-4eb0-979f-fd41443bf432'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='9ac4babb-66e1-425c-83b5-381fc3e1e15b'></a>

Universal Service Obligation:
Processing overhead costs are largely fixed

<a id='a91c55c9-024d-4395-87c0-7e15c92c8e4b'></a>

<::An industrial machine with multiple black compartments, some filled with papers or cards, and others containing mechanical components and wiring. A cylindrical silver object is visible near the center. The machine appears to be a sorting or processing unit.: figure::>

<a id='611f4c73-493c-4c52-8aa0-a0d2c95ee1e1'></a>

600 processing facilities
---
~12 for every state

<a id='cd3fe014-b8ef-42f9-b439-d98b8e7dc1e0'></a>

# Sortation plants

* Ensure overnight delivery of local mail
* Network largely fixed
* Volume declines are rapidly reducing economies of scale

<a id='10e6b068-2524-4c81-8b3f-016349f68937'></a>

8

<a id='07f6e5cf-3572-4a1f-9bdb-416314b9f44c'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='953c9fae-698a-46d2-9e89-485f722e8acb'></a>

Universal Service Obligation:
Delivery requirements are growing

<a id='4d452b07-1267-4247-8ea0-1ac89cf74a92'></a>

<::A photograph of a black mailbox with its door open, revealing several colorful envelopes inside. The mailbox is mounted on a wooden post against a sky with white clouds. To the right is a bar chart titled "Addresses Millions". The chart shows two bars: one for 2009 with a value of 150, and one for 2020 with a value of 162. An arrow with a circular orange label indicates a "+8%" increase from 2009 to 2020.
: figure::>

<a id='ba804688-06ab-4ab6-be3c-19a761ff2501'></a>

Delivery network
* Deliver to every address in America
* 6-day delivery
* Corresponding high fixed delivery cost

<a id='d365d6e9-ea8d-4ecc-a410-54ba400eda67'></a>

9

<a id='427245cb-f52d-4d21-ace2-d2039064a243'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='9428b8d6-1c0c-41ac-8633-2bf86fcfb0ad'></a>

Workforce costs:
Continue to rise faster than inflation

<a id='2e230094-9861-4508-9f6c-b43e165f87cb'></a>

<::bar chart::>Workforce annual rate increases, 2010-2020
Percent

Bar 1:
Label: Wages
Value: 1.3-2.5

Bar 2:
Label: Workers' compensation
Value: 2.0-4.0

Bar 3:
Label: Health benefits
Value: 4.7-5.2

Inflation line (dotted yellow):
Value: 1.9%
Label: Inflation (CPI at 1.9%)::>

<a id='5a07e65b-325d-46b5-8296-3a1add7f9add'></a>

10

<a id='f32c7e07-beff-42ec-a943-033edb4f9cc5'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='2439e3ac-e76c-4e66-ba31-635401781ce2'></a>

Workforce costs: Required Retiree Health Benefit funding is substantial from 2010-2016

<a id='1e917f1a-adce-48e0-a308-f2d86c3f1da2'></a>

<::A large modern building with a sign that reads "Medical Center" on the side. The building has multiple stories, with the upper section featuring large blue-tinted windows and the lower sections constructed with light brown brick or stone. A covered entrance area with large pillars is visible in the foreground, leading into the building. The sky is clear blue. There are some trees without leaves and a mountain range in the background on the left. The foreground shows a paved area, possibly a parking lot or driveway, with yellow bollards and red markings.: figure::>

<a id='1f214b4f-3942-401b-8c00-7b9e4b71e4a8'></a>

<::A smiling male doctor wearing a white lab coat, a light blue collared shirt, and a red patterned tie, with a stethoscope draped around his neck. He has short dark hair and a light beard. The background is a solid dark blue with a subtle lighter blue curved shape visible behind his head.: figure::>

<a id='61ac18c9-3aa2-48a8-9196-e98ec95e5b18'></a>

Required Annual Retiree Health
Benefit (RHB) funding

<::A list of data points, each preceded by a blue arrow:
- A blue arrow points from "2005" to "$1.5 billion"
- A blue arrow points from "2010-16" to "$9.0 billion average"
- For "Percent of total revenues 2010-16", a blue arrow points to "12-16%"
: infographic::>

<a id='71450a4f-26db-42d1-8dac-1cce6dd09d27'></a>

11

<a id='1841416a-35b4-484c-9fcd-bde5114c8d8b'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='c5dedf58-0df3-4de2-ae9d-88b6d6c2c02c'></a>

Recent losses are forecast to grow without changes <::Net profit/loss line chart showing $ Billions on the Y-axis (from -30 to 10) and years on the X-axis (from 2000 to 2020). The chart is divided into 'Actual' (2000-2009) and 'Forecast' (2009-2020) sections by a vertical dotted line at 2009. The line graph shows actual profit/loss fluctuating, going below zero around 2002-2003 and again around 2008-2009. The forecast section shows a continuous decline into negative territory. A shaded area under the forecast line indicates a 'Cumulative loss 2010-2020 $238 billion'. A small yellow square with the number '33' is at the bottom right corner of the shaded forecast area, near the year 2020.: chart::>

<a id='cf3f2b15-92b4-42e5-b6fe-943d0b38fa4d'></a>

12

<a id='039946b9-36e7-44c9-acab-67188838ad73'></a>

<::McKinsey&Company
: figure::>

<!-- PAGE BREAK -->

<a id='399ec1c2-7744-49e6-8be0-cfc1794eabac'></a>

<::
Actions within Postal Service control: Four sets of actions could reduce the 2020 gap by $18 B

| Actions | Net profit benefit in 2020 ($ Billions) |
| :----------------------------------- | :------------------------------------- |
| 1 Product and service actions | ~2 |
| 2 Productivity improvements | ~10 |
| 3 Workforce flexibility improvements | ~0.5 |
| 4 Purchasing savings | ~0.5 |
| Avoided interest due to reduced debt | ~5 |
| Total | ~18 |
| Cumulative impact 2010-2020 | ~123 |
: table::>

<a id='79e78c98-3d95-4e58-bc32-10aeaf417333'></a>

13

<a id='189c55df-8695-43ee-adc4-995dea52beb1'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='385c60de-39df-4855-9c18-adbe479a7eb4'></a>

Actions within Postal Service control will improve long-term sustainability, but a gap will remain
<::chart: Line graph titled "Actions within Postal Service control will improve long-term sustainability, but a gap will remain" showing Net income in $ Billions over time.

Y-axis (Net income, $ Billions) ranges from -35 to 10, with major ticks at -35, -30, -25, -20, -15, -10, -5, 0, 5, 10.
X-axis shows years 2005, 2009, 2020.

The graph is divided into two sections by a dotted vertical line at 2009.

Left section (before 2009) is labeled "Actual". The net income line starts near 0 in 2005, dips to around -5, then rises slightly before dipping again towards -5 by 2009.

Right section (after 2009) is labeled "Forecast". The net income line continues to decline, showing increasing losses. The area under the forecast line is shaded, representing cumulative loss.

Text within the shaded forecast area indicates: "Cumulative loss 2010-2020 $115 billion".

Two callouts with arrows point to different levels of loss in the forecast period:
1. An arrow points to a level around -15 to -20 on the Y-axis, labeled "($15B)". Associated text reads: "Actions within the Postal Service control will reduce annual loss to $15 billion, cumulative loss to $115 billion".
2. Another arrow points to a lower level around -33 on the Y-axis, labeled "($33B)". Associated text reads: "Base case without product, service or productivity actions".
: figure::>

<a id='6412a93d-24f3-49af-900c-89c557d23976'></a>

14

<a id='a7f312c0-2f62-451f-83d9-b68c0162495f'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='15686c8e-2614-4625-b36d-44e528b137b2'></a>

McKinsey examined an extensive range of options

<a id='231c076b-9db4-4592-9746-b7d26f00447c'></a>

50+ options considered

*   Aggressive internal cost improvement options across the organization
*   Products and services options from:
    *   Foreign posts (banking, logistics)
    *   Private sector firms
    *   Other government entities
    *   The Postal Service
*   Other product and service extensions from existing assets
*   Pricing actions
*   Privatization

<a id='3b0cab4d-1451-4370-bf63-18b68a152741'></a>

Filtered on criteria

- Overall profit impact
- Impact on customers and mailers
- U.S. specific-industry dynamics
- Time and capital investment required
- Feasibility

<a id='f416bb97-278c-4cc3-9d1a-bf9c6ad3ee65'></a>

15

<a id='3ba95ef5-65ec-4def-a50e-01171ff2c523'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='7fe18466-b1f1-494c-8b31-5a24f9d28ace'></a>

Privatization: An unlikely option for USPS

<a id='5d805855-f0e0-40c4-8eab-b9c93b6d5810'></a>

<::A line chart with a y-axis labeled 20, 40, 60, 80, 100 and an x-axis labeled 1 through 12. Multiple colored lines plot data points. A magnifying glass is positioned over the upper right portion of the chart. A partial table of values is visible next to the chart, including 63,04, 52,30, 97,54, 87,45, 99,32, 90,59.: chart::> Investors require a clear path to profitability before acquisition. Changes USPS requires to become attractive to investors are more extensive than those required to ensure a viable government entity.

<a id='91697e7f-c79f-4640-82d6-a325a76dde4a'></a>

- The scale and associated risk further limit investor interest in the business

<a id='6ebec0f7-8092-49f7-be1f-cb872e99fb78'></a>

* Even after a privatization, U.S. Government would need to maintain implicit or explicit support for the Postal Service

<a id='099f1c73-7284-43d7-96db-5bbeee4b2b22'></a>

16

<a id='0b6bdfb5-6f12-4586-b203-37ea610c2a2c'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='d647de13-3249-4b35-943c-c82dcb7064db'></a>

Fundamental change: Options exist across five areas to address the remaining $15 billion gap

<a id='764c10c5-67ae-43aa-b7a4-62b182cfbe4f'></a>

<::An image on a dark blue background with a lighter blue oval shape in the bottom right. On the left, a white cardboard box with "PRIORITY MAIL" and a USPS logo. In the top right, a postage stamp featuring the American flag and "USA44". Text overlaid on the image reads: Products and services. Pricing. Remaining FY 2020 gap = $15 billion.: figure::>

<a id='3a1da922-93ff-4aba-a812-95581caf5474'></a>

<::A map of the United States is shown, filled with the pattern of the American flag (red and white stripes, blue field with white stars). The text "Service levels" is overlaid in white text on the upper right side of the map.
: figure::>

<a id='46ebd703-47db-40e2-842b-a41d2fe55a85'></a>

<:: Public policy considerations. A night-time image of the US Capitol building, illuminated with lights, against a dark blue sky.: figure::>

<a id='bc38495f-b330-42e6-8400-22acdea9011b'></a>

<::A photograph of a female postal worker in a blue uniform holding a stack of mail and magazines. An American flag is visible in the background. To the right, a dark blue panel has the word "Workforce" in large white letters.
: photo::>

<a id='db9ea2ad-8e25-4783-b1dc-f8ffd3ce938a'></a>

17

<a id='7d89f979-6864-4e58-abe7-9390ca92ce22'></a>

<::McKinsey&Company
: figure::>

<!-- PAGE BREAK -->

<a id='cd4f32a1-0aa0-433c-aa45-04d1a2d05c30'></a>

Fundamental change options:
Products and services

<a id='ab55554b-8b83-4eda-a5de-c86e1feab975'></a>

Create new products and services
consistent with USPS mission

<a id='ab4125a9-872b-4ff1-b6ec-4d9385c635fe'></a>

<::A conceptual graphic depicts a white laptop computer with a blue screen. On the screen, a stack of various mail items, including white envelopes and brown padded envelopes, is visible. A red mailbox flag extends from the top left corner of the laptop, suggesting mail delivery or integration. The text, "Develop a suite of hybrid mail products that integrate electronic and physical mail," is displayed alongside this graphic on a dark blue background, forming a cohesive visual element.
: figure::>

<a id='9feb2cbd-c7c7-4981-a6e2-277b6a7e32e0'></a>

freshFX

$150 off
Any Service

914-232-4405

REMOVE & PREVENT
MOLD & INFECTIOUS GERMS
In Your Home or Business.

PROTECT

<::transcription of the content
: figure::>

For Our Best Price... [illegible]

* All Natural Products • 99.9% Effective
* Certified Mold Professionals [illegible]
* Safe, Non-Toxic, Non-Caustic
* Protects against future germs • Fast & friendly application
* Fights against allergens, [illegible] odors,
  [illegible], MRSA, [illegible], [illegible] & [illegible], mildew & [illegible]

The first
PREVENTATIVE
MOLD & GERM SOLUTION

CALL NOW FOR WINTER PRICING

INTEX

FREE ESTIMATION
[illegible]

[illegible] owned & operated • www.freshfx.org

[illegible] services with organically clean
and disinfected critical areas of your home
AND [illegible] and PROTECT them
with a SAFE & ALL NATURAL [illegible]
Over [illegible] as 200% of all germs [illegible]
[illegible] 914-232-4405

<a id='e6c06f3f-fa8d-4b61-b2bf-fa6de326d64a'></a>

Simplify advertising products

<a id='1680e64d-046b-46f0-8ee0-c502c13f437b'></a>

18

<a id='cd5e51b1-36c1-4369-9ab8-23dac16a0ff9'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='1916d02e-65f7-427b-be80-35ed076df91d'></a>

Fundamental change options: Pricing

<a id='ab9c025e-819f-4632-9dcd-173c1273212f'></a>

Modify price cap to apply across all market dominant products rather than by class

Apply exigent price increase

Increase prices on select products to cover costs:
* Periodicals
* Nonprofit mail
* Media and Library mail

<a id='1038bfe9-60c7-4bd3-8d38-b76c496c62a8'></a>

19

<a id='a0901af5-2cf7-4745-b07f-92033ff514b6'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='5bd23aed-ac4d-4d44-91e8-73c15ee4b448'></a>

Fundamental change options: Service levels

<a id='72a4b130-8a08-42ec-b046-fd04c5dca6d4'></a>

<::transcription of the content
: figure::>

Change service levels from 1-3 day
to 2-5 day delivery for First Class Mail

<a id='df1a58ec-85cd-4d41-805d-711cd3ba89b1'></a>

<::A mail carrier in a blue jacket is standing next to a white mail truck. The text next to the mail carrier reads: Reduce delivery frequency to 3 days or 5 days per week. Change delivery location to curb or cluster boxes.
: figure::>

<a id='6e117e81-8e60-43ae-b228-382b9c0fc561'></a>

THE POSTAL STORE
Quick Order My Account FAQs
Stamps For Mailing | Shipping For Fun | For Collecting | For

Shop our Sale >
Buy a Coil of 100 Stamps
$44.00 >

p.s. I love You

Stamps >
First Class Stamps,
Additional Postage,
Coils of Stamps,
Priority Mail

Vancouver 2010 Olympic
Winter Games $8.30

BUY >
View our Collection >

Expand access through
alternative channels
- Private sector retail partnerships
- Kiosks
- Direct (e.g., online, mobile)

<a id='23ea2355-8ab8-4bb5-a7bc-dd893b6aa5f7'></a>

20

<a id='f545e223-504a-4898-a602-c12dabe40770'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='4b3cb58d-69be-485b-a43e-0c54476e220d'></a>

Fundamental change options: Workforce

<a id='dea92818-d812-4d01-aec2-00e485c710fe'></a>

<::A woman in a light-colored sleeveless top over a brown long-sleeved shirt is working in what appears to be a mail or package sorting facility. She is looking down, focused on handling a stack of white envelopes or flat packages on a conveyor belt or sorting table. To her left, there's an open cardboard box and other items on the table. In the background, there are automated sorting machines or conveyor systems with various packages and boxes, and shelves filled with bins or mail slots. The overall impression is of an industrial or postal work environment.: figure::>

<a id='bf9e83a0-2242-4384-b08e-95ab07765660'></a>

Improve workforce flexibility
by changing the employee mix and taking
advantage of over 300,000 voluntary
separations over the next 10 years

<a id='9da40cae-ed3e-4472-b7f8-3df957d3bdf5'></a>

<::A 3D bar chart with red and white bars showing an increasing trend, overlaid with a green line graph also showing an upward trend. Faint numbers are visible in the background.: chart::>

<a id='78e72351-6bbc-4ea1-921b-5cc08d8e108a'></a>

Align workforce costs with overall
market trends and inflation

<a id='ca758401-258f-4520-b6a9-39da3e18b297'></a>

21

<a id='e2a440af-f6b8-44fc-aca6-8ae7e30bfc32'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='85d1947d-742b-4163-a0ac-9ad42c63b511'></a>

Fundamental change: Public policy considerations

<a id='c083ded8-1db7-4d61-bea1-4d2d3a522c9d'></a>

Restructure RHB pre-funding

* Defer payments
* Shift to a "pay-as-you-go" system comparable to other federal agencies and private companies

<a id='0925a196-7043-4766-96e5-74058f19d4a6'></a>

<::Image of the US Capitol building at dusk, with its dome illuminated.: image::>Receive Universal Service Obligation subsidies through Federal appropriations

<a id='0aea6b49-bbc3-4dbb-a96a-ff589a362e46'></a>

<::An image of an eagle flying, set against a light blue sky, on the left. On the right, against a dark blue background with lighter blue diagonal stripes, is the text: "Streamline oversight model to improve flexibility and timeliness". The words "Streamline oversight model" are in yellow, and "to improve flexibility and timeliness" are in white.: figure::>

<a id='5ff4214c-cf9a-4066-aa79-d739e44819e4'></a>

22

<a id='ca2ea858-29fd-4e9b-9343-e059cc7fcbe0'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='36e7e9f0-48a5-4521-b766-fbad1162dfe5'></a>

Closing perspective

<a id='7c44dbfb-b0c4-4feb-ad00-fbca4df31df3'></a>

Even undertaking all opportunities within Postal Service control, USPS is facing a cumulative $115 billion loss

<a id='84521e48-c64e-4dd6-8a58-7183d81bddc1'></a>

Actions in any one area will not be enough to close this gap

<a id='e19a45fd-c6c0-4904-9e6c-1310580acbb1'></a>

Pursuing multiple actions can result in enhanced customer service and a financially viable operating model

<a id='75902a2f-7b56-4ccd-b689-458f7efa16b3'></a>

Legislative and regulatory changes are necessary and will require cooperation from multiple stakeholders

<a id='6b70bd97-94f1-4f0d-a8ce-f1e59ff85f8c'></a>

23

<a id='2f72b9a7-70ab-4c2c-a87d-d1fa875f3b8b'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='c8848701-c5a2-4a74-8727-6203c4a9ef7c'></a>

<::An image showing a storage area with stacks of blue plastic crates on the left side. On the right, there are tall stacks of white materials, possibly ballots or documents, with the words "UNITED STATES" printed repeatedly in black ink on their visible edges. The text "UNITED STATES" is visible multiple times on the stacked white items.: image::>

<a id='0c7fc826-2cd3-4b04-b9cc-e29d85ea16b8'></a>

Envisioning America's
Future Postal Service
Options for a Changing Environment

<a id='83dcda29-e9ec-412f-bd55-16ca44285aa6'></a>

March 2, 2010

<a id='0f367dbf-f096-4742-be17-2219b9677f9f'></a>

24

<a id='db164991-96b0-4ee4-907a-78fcf32c4651'></a>

McKinsey&Company