<a id='5ee77b7c-9f16-4025-a0d0-d7d947bc47fa'></a>

<::logo: SlicedInvoices
SlicedInvoices
A pie chart symbol in dark blue and light blue, with the text "SlicedInvoices" next to it in a flowing script font, transitioning from light blue to dark blue.::>

<a id='eb9ac942-6f92-445b-8df9-d15d8dcb892e'></a>

Invoice

<a id='1f6a9aff-8932-404c-8259-246b655f230a'></a>

From:
DEMO - Sliced Invoices
Suite 5A-1204
123 Somewhere Street
Your City AZ 12345
admin@slicedinvoices.com

<a id='87933e0c-1ffb-4928-97f1-e9c16269cd61'></a>

<table id="0-1">
<tr><td id="0-2">Invoice Number</td><td id="0-3">INV-3337</td></tr>
<tr><td id="0-4">Order Number</td><td id="0-5">12345</td></tr>
<tr><td id="0-6">Invoice Date</td><td id="0-7">January 25, 2016</td></tr>
<tr><td id="0-8">Due Date</td><td id="0-9">January 31, 2016</td></tr>
<tr><td id="0-a">Total Due</td><td id="0-b">$93.50</td></tr>
</table>

<a id='5fcc20c3-404c-460a-aa4c-df988f2f7350'></a>

To:
Test Business
123 Somewhere St
Melbourne, VIC 3000
test@test.com

<a id='50d3d72c-52bb-41d2-ae3f-f3ac892e224d'></a>

<table id="0-c">
<tr><td id="0-d">Hrs/Qty</td><td id="0-e">Service</td><td id="0-f">Rate/Price</td><td id="0-g">Adjust</td><td id="0-h">Sub Total</td></tr>
<tr><td id="0-i">1.00</td><td id="0-j">Web Design This is a sample description...</td><td id="0-k">$85.00</td><td id="0-l">0.00%</td><td id="0-m">$85.00</td></tr>
</table>

<a id='d4dc197d-a049-420b-ab65-fe45835163a9'></a>

<table id="0-n">
<tr><td id="0-o">Sub Total</td><td id="0-p">$85.00</td></tr>
<tr><td id="0-q">Tax</td><td id="0-r">$8.50</td></tr>
<tr><td id="0-s">Total</td><td id="0-t">$93.50</td></tr>
</table>

<a id='159b3773-8b8e-4e99-a315-59f730825d39'></a>

ANZ Bank
ACC # 1234 1234
BSB # 4321 432

<a id='d73f8bed-54ad-4a21-a8d1-d1ed733c0433'></a>

Payment is due within 30 days from date of invoice. Late payment is subject to fees of 5% per month.
Thanks for choosing DEMO - Sliced Invoices I admin@slicedinvoices.com
Page 1/1