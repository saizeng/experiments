"""Report generation skill. TODO: Replace stub."""


async def run(query: str, parameters: dict, upstream: dict) -> dict:
    fmt = parameters.get("format", "pdf")
    return {
        "file_path": f"/tmp/reports/report.{fmt}",
        "title": "Generated Report",
        "pages": 1,
        "note": "Stub — implement real report generation here.",
    }
