<a id='b5e5db60-bac5-45dd-a417-efc993a8fbfe'></a>

Helping Global Health
Partnerships to increase their
impact: Stop TB Partnership –
McKinsey collaboration

<a id='6801bf9f-9ff7-4743-883a-fd493f87c485'></a>

Pre-reading for Coordinating Board presentation
Thursday, Nov 5, 2009

<a id='25fca141-8f37-4835-bc0f-91cc3c76e89b'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='00d6a054-691b-4f06-880d-7ece70b9d938'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='a11c1fee-50fa-4e40-8d8b-5e6e43888ddb'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 1

<!-- PAGE BREAK -->

<a id='c6c72402-9565-4d82-864a-50dda70a32dc'></a>

Background to this work: The performance of Global Health Partnerships (GHPs) is increasingly important and scrutinized, yet achieving high performance is proving challenging

<a id='4d87f9ef-a91a-45c4-a2a2-01a37e0f1a3d'></a>

## Increasing role of GHP performance

*   GHPs play a major role in global health
*   Performance of GHPs can have huge impact on health of world's population
*   The focus on performance is increasing, driven by
    *   Increasing donor focus on impact, effectiveness, and efficiency
    *   Increasing number of Partnerships in global health
    *   Likelihood of lower funding growth or less funding, given financial crisis

<a id='3f4c705f-8d68-4f0b-9f62-c9feabeaf0fc'></a>

## Challenging factors

Complex environment and nature of GHP organizations create challenges, e.g.

*   **Objective-setting:** distinguishing between change GHP hopes to bring about in the world vs. the goals it sets itself that will help bring about the change
*   **Accountability:** ensuring accountability and delivery in the context of loose Partnership structures, voluntary membership, and limited hierarchy
*   **Capabilities:** gaining the capacity and capabilities needed to continuously improve their performance

<a id='d94e4ce9-f590-4690-9e33-0bcaf96e85fa'></a>

McKinsey & Company | 2

<!-- PAGE BREAK -->

<a id='9e867750-556c-42db-939f-9670f27a9422'></a>

Project goals, approach, and end-products: The project will deliver practical insights on improving the performance of GHPs based on piloted improvement ideas

<a id='a90bec5a-fea4-4736-b5c0-0e6b77f02c9a'></a>

## Goals

*   Develop a joint perspective, tested and proven, on how GHPs can improve performance, by
    *   Exploring how to improve performance in a GHP, not simply to adopt existing (e.g. private sector) approaches
    *   Testing new ways of working with STB bodies that could lead to higher performance
    *   Develop a joint perspective to share with global health community

<a id='04e5e10f-4c04-4e11-8206-906689744ebf'></a>

# Approach
- Build on strengths and improvement opportunities outlined in 2008 evaluation
- Joint working, collaborative, co-creation. Not client-consultant work
- Duration: ~22 weeks: 10 weeks (diagnosis and design), 12 weeks (delivery)
- Scope: 5 Partnership bodies: GDF, MDR-TB WG, CFCS, Advocacy and CB&M teams
- External interactions with other GHPs, e.g., RBM, UNAIDS, GAVI, GF

<a id='61388a2e-cc46-4452-a449-581830eac037'></a>

3 main end-products

* Successful performance **improvement pilots** in selected Partnership bodies, with accompanying documentation to support roll-out to other bodies
* A **co-authored project report**, suitable for publication in major journals, detailing the experience, including impact of the work and lessons for other GHPs
* A "**practitioners guide**" to support McKinsey teams conducting similar work

<a id='3fc37ec9-471c-46ba-85c4-12b106968079'></a>

McKinsey & Company | 3

<!-- PAGE BREAK -->

<a id='31606e85-62ac-4f2f-a077-49a0c676f575'></a>

Project approach: This project is organized in 3 distinct phases

<a id='2d700994-2007-4ed7-a827-983e4c25c9a7'></a>

Today
<table id="4-1">
<tr><td id="4-2">Diagnose August - September</td><td id="4-3">Design September - October</td><td id="4-4">Deliver November - December</td></tr>
<tr><td id="4-5">Selection of Partnership Bodies to work with</td><td id="4-6" rowspan="2">■ Intensive work within selected Partnership Bodies to</td><td id="4-7">Implementation and refinement</td></tr>
<tr><td id="4-8">GDF</td><td id="4-9" rowspan="3">▪ Problem-solving sessions on findings, lessons learned, and implications</td></tr>
<tr><td id="4-a">Advocacy</td><td id="4-b" rowspan="6">— Develop improvement ideas on selected performance issue — Select actions to implement in next phase ▪ Development of implementation plans for Delivery phase</td></tr>
<tr><td id="4-c">Communication,</td></tr>
<tr><td id="4-d">Marketing and Branding – CFCS</td><td id="4-e" rowspan="3">Workshop to share achievements across Partnership Report and publication of results</td></tr>
<tr><td id="4-f">– MDR-TB Working Group</td></tr>
<tr><td id="4-g" rowspan="3">▪ Understanding of current performance ▪ Identification of areas of high performance</td></tr>
<tr><td id="4-h" rowspan="3">■ Presentation of results to Coordinating Board in March 2010</td></tr>
<tr><td id="4-i" rowspan="2">■ Information update to Coordinating Board in Nov 2009</td></tr>
<tr><td id="4-j">■ Selection of one performance issue to improve</td></tr>
</table>

<a id='528dd102-8477-4464-8f1e-05eb7eb333f9'></a>

McKinsey & Company | 4

<!-- PAGE BREAK -->

<a id='02db173e-c0f3-4811-b302-3c7aef66ba29'></a>

Project deliverables for December 2009

<a id='5e6187ef-4438-4dc5-b2bf-252e2ee3f0c0'></a>

<table id="5-1">
<tr><td id="5-2">End-products</td><td id="5-3">Description</td></tr>
<tr><td id="5-4">Improvement pilots</td><td id="5-5">Each participating Partnership body conducting improvement project, focusing on one relevant area, e.g. Definition of objectives/goals Development of scorecards Improvement of processes Activation of relevant &#x27;enablers&#x27;, e.g., mindsets and capabilities Pilot progress showcase/workshop (mid-December) Development of accompanying &quot;pilot playbook&quot; (how-to guide for Partnership bodies)</td></tr>
<tr><td id="5-6">Project report</td><td id="5-7">A detailed project description, including Problem definition and why it matters Why it is and remains a problem Case account of Stop TB Partnership (what it&#x27;s doing well; what can be improved) Perspective from other GPH organizations (How &quot;typical&quot; is this?) Improvement projects launched and early findings Lessons, insights, conclusions</td></tr>
<tr><td id="5-8">Practitioners Guide</td><td id="5-9">Detailed account of work conducted to improve performance management for use by consultant teams in and beyond social sector</td></tr>
</table>

<a id='d71d0e21-a8f7-4d3e-bdb5-707245c68447'></a>

McKinsey & Company | 5

<!-- PAGE BREAK -->

<a id='77a82077-b7c6-49fe-af20-6c41192a9d9a'></a>

Framework: We think about performance in terms of both processes and enablers –(1) Processes

<a id='40524487-48a8-44de-a3f1-5f203fbb69fd'></a>

<::Performance management flowchart::>Central Theme: Performance management.1. Set objectives:- Set time-bound **objectives** that contribute to fulfilling **mission** and **vision**2. Establish clear metrics:- Set **metrics** that directly measure agreed objectives- Set additional metrics that cascade down from key metric3. Set targets:- Set **quantitative targets** for the metrics- Translate these into **operational plans** and **budgets**4. Track and disseminate metrics:- Produce **progress reports**- Disseminate report to team members and stakeholders at pre-aligned intervals5. Review performance:- Use report to discuss progress in structured **review meetings**- Identify possible performance gaps and decide how to address them6. Celebrate achievements and take further action:- Celebrate successes- Take any required **corrective actions**<::

<a id='82a25618-1a7f-4f33-803a-df913ea9fb47'></a>

McKinsey & Company | 6

<!-- PAGE BREAK -->

<a id='95ce43a5-17db-4380-abdd-3bb0dd5a6956'></a>

Framework (backup): Definition of performance management terms

<a id='accf25ea-ee23-4ec2-a9d9-1162db89f750'></a>

## Vision

### Definition/description
- Articulates the aspiration or target for the future
- Describes core ideology, which may include "timeless" guiding principles and purpose

### Example
- A TB-free world

---


<a id='0e4f468c-6e86-4900-ab8d-2bf57c01f0ca'></a>

## Mission

*   Defines the organization's purpose and primary objectives
*   Supply low-cost, quality drugs to countries that need them

<a id='79a3e396-0b9c-4357-992a-52ec4d8f54a4'></a>

Objective
---
- Narrow, time-bound, quantifiable goal that
  contributes to delivering the mission
- Supply low cost, quality TB drugs at
  USD 20/treatment course for X
  number of patients in 2010

<a id='67814eeb-b249-4275-bc08-8056be745102'></a>

Metric

- Measurable variable that indicates progress towards objective

---

- E.g., funds raised, number of patient treatments supplied, number of grants and treatments approved

<a id='6e520db8-92fb-4c1e-82c7-143cd92f8489'></a>

Target

*   The target value of the metric chosen
*   E.g., 15 million patient treatments supplied by 2010

<a id='58b9a351-c210-4c9a-8fea-d3f8ffecae2c'></a>

Report

* Set of metrics and current values vs. target
* Explanation of reasons for current performance and how to get to targets
* See pages 22, 23 in this document for examples

<a id='87e4b32d-5174-486c-b9c8-606a02a95809'></a>

Performance review

---

* A sequence of meetings conducted to
  * Review performance
  * Understand root causes of performance gaps
  * Decide how to address them
  * Agree appropriate actions

<a id='1d35a42b-d47d-4777-b97f-4eb5df68a610'></a>

McKinsey & Company | 7

<!-- PAGE BREAK -->

<a id='0d108750-4f69-4472-8446-535493030fcc'></a>

Framework: We think about performance in terms of both processes and enablers –(2) Enablers

<a id='5127aa9a-96e8-4763-8eee-6d09bc907460'></a>

<::Diagram: This diagram illustrates a model centered around "Committed leadership". It shows three main interconnected components surrounding the central concept: Culture, Communications, and Capacity. Each component is further elaborated with text and an accompanying image. There is also an additional text box directly connected to "Committed leadership".

- **Central Element:**
  - **Committed leadership**

- **Surrounding Components:**
  - **Culture:**
    - Text: Developed shared cultural norms for performance (e.g., accountability, behaviors)
    - Image: Four cartoon figures, three men and one woman, sitting around a round table, engaged in a discussion.
  - **Communications:**
    - Text: Communicate both performance and the importance of discussing performance regularly to all stakeholders
    - Image: A cartoon woman with dark hair and glasses, wearing a light blue jacket and dark skirt, speaking into a microphone at a light brown podium.
  - **Capacity:**
    - Text: Ensure sufficient skills, infrastructure, and resources for performance
    - Image: A cartoon figure, wearing a colorful patterned shirt and dark pants, unrolling a large yellow scroll that has 

<a id='08ce64be-01d2-42a9-8626-30890134afee'></a>

McKinsey & Company | 8

<!-- PAGE BREAK -->

<a id='a0c24ed7-71ca-4491-adc1-b37c04778d1e'></a>

Challenges (1): Many Global Health Partnerships find some performance processes challenging given their complex environment and structure

*   Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities
*   Aligning divergent partner views on which objectives to pursue
*   Setting advocacy objectives that stay current and relevant in changing external circumstances
*   Finding and making visible tactical advocacy opportunities for partners to act on

<::Performance management processes flowchart:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements and take further action
: flowchart::>

*   Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB
*   Aligning organization structures with performance drivers and metrics to enable clear accountability

*   Committing to targets is sometimes difficult because
    *   (a) some targets are not entirely deliverable by partnership
    *   (b) voluntary nature of partnerships
    *   (c) consequences of not meeting targets (e.g., on future funding)

Committing to specific corrective actions, given loose and voluntary nature of partnership

Getting good performance data because of in-country data gathering limitations

Holding regular, trust-based performance conversations

<a id='60ed4cd6-5da3-4e01-9f9d-62061fe8025b'></a>

SOURCE: Interviews with Stop TB Partnership, Global Alliance for Vaccines and Immunization, UNAIDS McKinsey & Company | 9

<!-- PAGE BREAK -->

<a id='788e50cf-fee3-403e-afb7-48722ce6d334'></a>

Challenges (2): Many GHPs also struggle with the right enablers

<a id='5ab6d6c5-37fa-448d-8b83-fdc7f11bb24c'></a>

<::Committed leadership diagram::>Committed leadership is at the center of a larger circle divided into three sections: Culture, Capacity, and Communications.  Each section has a descriptive callout box.  
- **Callout 1 (connected to Culture):** Getting from a culture of performance measurement (e.g., extensive reporting) to performance management (including open discussion of performance outcomes)
- **Callout 2 (connected to Communications):** Ensuring that leaders regularly lead and participate in performance reviews, in spite of many other calls on their time
- **Callout 3 (connected to Capacity):** Allocating appropriate resources to performance management given limited resources for internal processes
- **Callout 4 (connected to Committed leadership, top left):** Establishing a shared understanding of accountability across the different backgrounds of partners. Ensuring partners within a loose working group arrangement are engaged and motivated to contribute
- **Callout 5 (connected to Committed leadership, bottom left):** Defining specific and ambitious goals given culture of consensus-building that tends towards more inclusive, yet abstract objectives<::

<a id='451afd50-6009-4e7d-a148-5c5c70299870'></a>

McKinsey & Company | 10

<!-- PAGE BREAK -->

<a id='1b0094da-66a2-4939-998e-6eee325fb63c'></a>

Diagnostic phase findings (1): The Stop TB Partnership displays a number of strengths across performance processes

<a id='529be4c1-eea1-45dc-98ea-7d03a8907744'></a>

Examples

*   **Setting objectives** – GDF objectives are clearly defined and distinguish "the change the GDF hopes to bring about in the world" (e.g., Millennium Development Goals – 70% TB cases diagnosed, 85% cure rate) from the internal goals it sets itself that will enable this change
*   **Establishing clear metrics and setting targets** – MDR-TB Working Group defines concrete metrics (e.g., number of patients with access to MDR-TB treatment; research projects launched for evaluation of diagnostic algorithms) and sets specific targets for these metrics (e.g. for 2009, 200000 patients, 4 projects)
*   **Tracking and disseminating metrics** – Despite limited resources for performance management, GDF manages to track and report on a wide variety of metrics to meet the different demands of donors
*   **Reviewing performance** – In response to donor demands, the Advocacy Team conducts an in-depth review of performance against objectives stated in funding proposal so as to take stock of results achieved and lessons learned

<a id='06520542-6ea4-4df4-a605-66dd4971b228'></a>

McKinsey & Company | 11

<!-- PAGE BREAK -->

<a id='603234b2-065a-443e-adcc-be815ef650da'></a>

Diagnostic phase findings (2): The Stop TB Partnership also displays a number of strengths across the enablers of performance

<a id='6e6e2072-c8b5-4fed-b522-255c5a412767'></a>

# Examples

-   **Committed leadership**
    -   GDF leaders driving performance improvement initiatives
    -   Secretariat leaders setting ambitious performance targets for teams
    -   Coordinating Board members supporting focus on performance
-   **Culture** – GDF has created a culture of performance with a focus on continuous improvement and quality management. The team is actively eliciting feedback on performance, e.g., through the Business Advisory Committee
-   **Communication** – The Advocacy Team engages in ongoing communication across the Secretariat as well as with key partners such as the Stop TB department at WHO and the TB-HIV Working Group. Thereby, performance objectives are well known among relevant stakeholders
-   **Capacity** – The Communications, Marketing and Branding Team makes efficient use of pro bono resources volunteered by partners. These resources are used to deliver some of the team's activities (e.g., production and distribution of public service announcements) as well as to assess performance against specific metrics (e.g., data received from partner on number of viewers)

<a id='8df302f8-1a75-4416-8e97-dde797d9dd43'></a>

McKinsey & Company | 12

<!-- PAGE BREAK -->

<a id='ecc0e916-ed66-4eb1-8f62-398a8197792a'></a>

Diagnostic phase findings (3): Brief overview of performance issues we have jointly agreed to address in Design and Deliver phases (more detail in following sections)

<a id='912c075c-64ce-4cb5-b383-88f22b253f0e'></a>

<::flowchart: A vertical flowchart with five connected blocks. From top to bottom, the blocks contain the following text:
1. GDF
2. Advocacy
3. Communication, Marketing and Branding
4. Challenge Facility for Civil Society
5. MDR-TB Working Group
::>

<a id='c1093fde-12a4-4a08-ac84-87b878501c8d'></a>

<table id="13-1">
<tr><td id="13-2">Central Global Health Partnership performance issue</td><td id="13-3">Specific question addressed with Partnership body</td></tr>
<tr><td id="13-4">Agreeing the right metrics for objectives that are difficult to measure</td><td id="13-5">GDF tracks 250 metrics but Not all are related to GDF Some overlap Metrics are not organized systematically/hierarchically</td></tr>
<tr><td id="13-6">Setting advocacy objectives that stay current and relevant in changing external circumstances</td><td id="13-7">Setting advocacy objectives within Stop TB Partnership that stay current and relevant in changing external circumstances</td></tr>
<tr><td id="13-8">Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB</td><td id="13-9">Determining detailed objectives for each audience group that the Communications, marketing and branding team seeks to address Define metrics for each detailed objective</td></tr>
<tr><td id="13-a">Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities</td><td id="13-b">Refine the mission based on experience and lessons learned in the first two years of the CFCS program Articulate specific objectives around the newly refined mission statement</td></tr>
<tr><td id="13-c">• Ensuring partners within a loose working group arrangement are engaged and motivated to contribute</td><td id="13-d">• Developing a simple survey-based tool to assess the level of working group engagement</td></tr>
</table>
McKinsey & Company | 13

<a id='a76881db-c1c5-4b94-8911-2d95133428f1'></a>

13

<!-- PAGE BREAK -->

<a id='be9be151-1b1b-46ad-b8ad-46e86000a6eb'></a>

# Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 14

<!-- PAGE BREAK -->

<a id='9438ae01-e144-4b73-8a82-065596381686'></a>

GDF issues and opportunities

<a id='da2af977-7c26-4aed-852d-606dea959eea'></a>

GHP performance issue
② Agreeing the right metrics for objectives that are difficult to measure
② Aligning organization structures with performance drivers and metrics to enable clear accountability
④ Getting good performance data because of in-country data gathering limitations
⑤ Holding regular, trust-based performance conversations

<::Two diagrams are presented side-by-side. On the left, a circular diagram is divided into three segments. One segment is colored dark blue and labeled "Capacity". The other two segments are light blue and unlabeled. On the right, a circular flowchart titled "Performance management" shows a 6-step cycle:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements/take further action
: figure::>

GDF performance improvement opportunity
② GDF tracks 250 metrics but
– Not all are related to GDF
– Some overlap
– Metrics are not organized systematically/hierarchically
② Limited clarity on accountability for data collection/performance against each KPI
② Difficult to assess GDF's performance against its objectives
④ Limited resources (personnel and time) to gather data and prepare reports for internal use
⑤ Limited time available for performance discussions

<a id='bd7831d7-55c2-41df-bf5d-50c78e7147c2'></a>

McKinsey & Company | 15

<!-- PAGE BREAK -->

<a id='ecd4291b-ee01-4b8d-b8e1-b8a175dcd290'></a>

While most of the 250 metrics were relevant and helpful to GDF, data collection and reporting was onerous "All together we report on over 200 KPIs that cover our numerous external reporting requirements" "Most individual KPIs are relevant and helpful" "KPIs are specific and measurable" <::Excel spreadsheet: GDF KPI list. Columns: Source, KPI Name. Rows (partial view): 208 UNITAID MDR-TB Plan 2008-2011, Number of treatments provided. 209 UNITAID MDR-TB Plan 2008-2011, Potential global saving from total actual treatments. 210 UNITAID MDR-TB Plan 2008-2011, Potential global saving from total treatments needed. 211 UNITAID MDR-TB Plan 2008-2011, Price decrease. 212 UNITAID MDR-TB Plan 2008-2011, Procurement for ration. 213 UNITAID MDR-TB Plan 2008-2011, Product availability - High quality 2nd line. 214 UNITAID MDR-TB Plan 2008-2011, Product availability - Prequalified 2nd line. 215 UNITAID MDR-TB Plan 2008-2011, Product dispatch performance. 216 UNITAID MDR-TB Plan 2008-2011, Product price fluctuation buffer. 217 UNITAID MDR-TB Plan 2008-2011, Product registration - High quality 2nd line. 218 UNITAID MDR-TB Plan 2008-2011, Product registration - Pre-qualified 2nd line. 219 UNITAID MDR-TB Plan 2008-2011, Product shipping performance. 220 UNITAID MDR-TB Plan 2008-2011, Stockpile management cost. 221 UNITAID MDR-TB Plan 2008-2011, Stockpile management overhead cost. 222 UNITAID MDR-TB Plan 2008-2011, Stockpile storage cost. 223 UNITAID MDR-TB Plan 2008-2011, Total appropriate products in market. 224 UNITAID MDR-TB Plan 2008-2011, Treatment cost. 225 UNITAID MDR-TB Plan 2008-2011, Treatment need. 226 UNITAID MDR-TB Progress report 2007, Patients able to start or continue treatment for MDR-TB with drugs delivered (all orders). 227 UNITAID MDR-TB Progress report 2007, Patients able to start or continue treatment for MDR-TB with drugs delivered (Global Fund orders). 228 UNITAID Pediatric Report 2007, Average number of days for manufacturing. 229 UNITAID Pediatric Report 2007, Average total cost of a delivered request. 230 UNITAID Pediatric Report 2007, Spending on procurement (four) as a percent of total order costs (all orders). 231 UNITAID Pediatric Report 2007, Spending on products as a percent of total order costs (all orders). 232 UNITAID Pediatric Report 2007, Spending on shipping, insurance and quality control as a percent of total order costs (all orders). 233 UNITAID Pediatric Reporting Template (2006 04 and 2018), Average lead time for delivery of drug per country. 234 UNITAID Pediatric Reporting Template (2006 04 and 2018), Average percentage of time that Pediatric TB drugs used in the most common treatment regimens are not available in TRC approved countries. 235 UNITAID Pediatric Reporting Template (2006 04 and 2018), Country applications reviewed and approved by TRO. 236 UNITAID Pediatric Reporting Template (2006 04 and 2018), GDF key product prices secured in 2010 compared to baseline prices. 237 UNITAID Pediatric Reporting Template (2006 04 and 2018), GDF secured cost per patient treatment in 2010 compared to baseline cost. 238 UNITAID Pediatric Reporting Template (2006 04 and 2018), GDF secured price of each pediatric TB drug compared with lowest price available from non-GDF manufacturers that meet the same quality standards. 239 UNITAID Pediatric Reporting Template (2006 04 and 2018), Increase in the number of LTs signed with manufacturers for supply of pediatric TB treatments. 240 UNITAID Pediatric Reporting Template (2006 04 and 2018), Increase in the number of manufacturers for pediatric TB products currently listed in the GDF catalogue. 241 UNITAID Pediatric Reporting Template (2006 04 and 2018), Increase in the number of manufacturers of new pediatric TB products. 242 UNITAID Pediatric Reporting Template (2006 04 and 2018), Number of pediatric TB drugs either prequalified or with complete dossiers submitted to the WHO prequalification programme for the duration of the project. 243 UNITAID Pediatric Reporting Template (2006 04 and 2018), Number of pre-qualified optimal pediatric TB drug formulations available each year for the duration of the project. 244 UNITAID Pediatric Reporting Template (2006 04 and 2018), Pediatric treatments supplied to each beneficiary country reported semi-annually. 245 UNITAID Pediatric Reporting Template (2006 04 and 2018), Percent of orders (per product) placed through pooled procurement. 246 UNITAID Pediatric Reporting Template (2006 04 and 2018), Percent of orders placed for beneficiary countries annually within the timeline recommended by TRC. 247 UNITAID Pediatric Reporting Template (2006 04 and 2018), Percent of pediatric patients completing treatment in a 6 month period. 248 UNITAID Pediatric Reporting Template (2006 04 and 2018), Percent of total budget allocated to LIC, LMIC, UMIC. 249 UNITAID Pediatric Reporting Template (2006 04 and 2018), Percent of treatments ordered by countries that match the number of treatments budgeted for in the project agreement. 250 UNITAID Pediatric Reporting Template (2006 04 and 2018), Proportion of pediatric TB cases reported out of total TB cases reported by a country. 251 UNITAID Pediatric Reporting Template (2006 04 and 2018), Total number of patient treatments approved by the TRC for each country include an additional 20% of each treatment to be held as buffer stock. Navigation tabs at bottom: Pivot T, KPI list, Unclassified KPI, Sheet3.::> "It takes too much time to collect the information and to adapt it to our 200+ KPIs" "It is difficult to define metrics for some areas so we have KPI gaps" "Some of our KPIs overlap so it is unclear what we are optimizing for" "Since the hierarchy of KPIs is not clear, it is hard to prioritize"

<a id='4b5fe8d0-0885-468c-976f-c0dae890f5db'></a>

SOURCE: Interviews                                                                                                                                                                                                                                  McKinsey & Company | 16

<!-- PAGE BREAK -->

<a id='e399fc98-75c4-4bda-839a-8c07127dbb49'></a>

The team followed an 8 step process to create streamlined and structured KPIs, dashboards, and review meetings <::The visual is a complex diagram illustrating an 8-step process for performance management, with a central cycle and surrounding detailed actions. The central cycle is labeled "Performance management" and consists of six steps:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements/take further action

Around this central cycle, there are eight detailed steps (a-h), each with a small illustrative image:
a. Collate all GDF metrics reported on in one database: sum: ~ 250 (Image: a spreadsheet view)
b. Agree on GDF objectives and cluster metrics/KPIs to objectives (Image: sticky notes on a board)
c. Develop detailed KPI tree for each objective (Image: a hierarchical diagram)
d. Streamline detailed trees, excluding activity-related or non-GDF-owned KPIs (Image: a modified hierarchical diagram)
e. Assign owners to, and define review frequency of each KPI (Image: a table with KPI, owner, frequency columns)
f. Develop clear cascade of KPIs from teams up to COO annual performance review (Image: a table showing a cascade of KPIs)
g. Create dashboards and review calendars for each team (Image: a dashboard and a calendar)
h. Hold workshop on conducting performance dialogues (Image: a smaller circular diagram with "Performance dialogue" in the center)
: flowchart::>

<a id='5d07a8f3-d9e4-46b5-9f4c-21f42ed96d8d'></a>

McKinsey & Company | 17

<!-- PAGE BREAK -->

<a id='f0fb433f-0a27-4282-942f-3e81b8a81d37'></a>

7 KPIs give a clear overview of GDF's performance against its 3 main objectives

**Objective**

1. Provide uninterrupted supply of 1st and 2nd line TB drugs and diagnostics:
   * At low-cost
   * At high quality
   * Timely
   * In a demand and customer-driven way
   * To eligible countries
2. Sustainably strengthen eligible countries' national drug management and procurement capacity, and financial self-sufficiency¹
3. Ensure appropriate and efficient staffing and funding to drive the mission

**KPI**

1a. Average cost per patient treatment
1b. Number of patient treatments delivered

2a. Number of countries that move to direct procurement

3a. Organizational health and culture index
3b. Staff capacity and capability index
3c. Funds raised vs. required for GDF administrative costs
3d. Funds raised vs. required for GDF activities

<a id='79bb3311-7fe5-41fe-be0d-12cd5011a5cd'></a>

1 Financial self-sufficiency of countries may be an objective for the Partnership as a whole

<a id='b29a4679-b6bd-44de-95da-70935a6364a8'></a>

McKinsey & Company | 18

<!-- PAGE BREAK -->

<a id='53c7aca6-78be-4412-9470-0ea2ec2a180b'></a>

The COO's annual dashboard is the output of each team's performance review

<a id='5a60367a-a0c3-4cfd-b2cf-cd4e5324db9f'></a>

Annual performance reviews

GDF COO
1a Number of patient treatments delivered
1b Average cost per patient treatment
2a Number of grantee countries that move to direct procurement
3a Staff capacity and capability index
3b Organizational health/culture index
3c Ratio of funds raised/required for GDF activities
3d Ratio of funds raised/required for GDF administrative costs

<table id="19-1">
<tr><td id="19-2">Capacity Building</td><td id="19-3">General Management and Support</td><td id="19-4">Portfolio Management</td><td id="19-5">Procurement</td><td id="19-6">Quality Management/ Assurance</td></tr>
<tr><td id="19-7">Annual</td><td id="19-8">Annual</td><td id="19-9">Annual</td><td id="19-a">Annual</td><td id="19-b">Annual</td></tr>
<tr><td id="19-c">2.1.1</td><td id="19-d">3.1.1</td><td id="19-e">1.3.1.1</td><td id="19-f">1.1.1</td><td id="19-g">1.2.1</td></tr>
<tr><td id="19-h">2.1.3</td><td id="19-i">3.1.2</td><td id="19-j">1.3.1.2</td><td id="19-k">1.2.3</td><td id="19-l">1.2.2</td></tr>
<tr><td id="19-m">3.2.1</td><td id="19-n">3.1.3</td><td id="19-o">2.1.2</td><td id="19-p">1.3.1.3</td><td id="19-q">1.4.1.1</td></tr>
<tr><td id="19-r">3.2.2</td><td id="19-s">3.2.2</td><td id="19-t">2.1.4</td><td id="19-u">1.3.1.4</td><td id="19-v">3.2.1</td></tr>
<tr><td id="19-w"></td><td id="19-x"></td><td id="19-y">3.2.1</td><td id="19-z">3.2.1</td><td id="19-A">3.2.2</td></tr>
<tr><td id="19-B"></td><td id="19-C"></td><td id="19-D">3.2.2</td><td id="19-E">3.2.2</td><td id="19-F"></td></tr>
<tr><td id="19-G">Blank (with arrow)</td><td id="19-H">Blank (with arrow)</td><td id="19-I">Blank (with arrow)</td><td id="19-J">Blank (with arrow)</td><td id="19-K">Blank (with arrow)</td></tr>
<tr><td id="19-L">Monthly Quarterly</td><td id="19-M">Semi-annual</td><td id="19-N">Monthly Quarterly</td><td id="19-O">Monthly Semi-annual</td><td id="19-P">Monthly Semi-annual</td></tr>
<tr><td id="19-Q">2.1.3.3</td><td id="19-R">3.1.1</td><td id="19-S">1.3.1.1</td><td id="19-T">1.3.1.3</td><td id="19-U">1.4.1.1</td></tr>
<tr><td id="19-V">3.2.1.1*</td><td id="19-W">3.1.2</td><td id="19-X">1.3.1.2</td><td id="19-Y">1.3.1.4</td><td id="19-Z">1.4.3</td></tr>
<tr><td id="19-10">2.1.3.1</td><td id="19-11">3.1.2.1</td><td id="19-12">2.1.2</td><td id="19-13">3.2.1.1*</td><td id="19-14">3.2.1.1*</td></tr>
<tr><td id="19-15">2.1.3.2</td><td id="19-16">3.1.2.2</td><td id="19-17">2.1.4.2</td><td id="19-18">1.3.1.3</td><td id="19-19">1.4.1.1</td></tr>
<tr><td id="19-1a">2.1.3.4**</td><td id="19-1b">3.1.2.3</td><td id="19-1c">2.1.4.3</td><td id="19-1d">1.3.1.4</td><td id="19-1e">1.4.2</td></tr>
<tr><td id="19-1f">3.1.3.1</td><td id="19-1g">3.2.2</td><td id="19-1h">3.2.1.1*</td><td id="19-1i">3.1.3.1</td><td id="19-1j">1.4.3</td></tr>
<tr><td id="19-1k">3.2.2</td><td id="19-1l"></td><td id="19-1m">2.1.4.3</td><td id="19-1n">3.2.3</td><td id="19-1o">3.1.3.1</td></tr>
<tr><td id="19-1p">3.2.3</td><td id="19-1q"></td><td id="19-1r">2.1.4.4**</td><td id="19-1s"></td><td id="19-1t">3.2.3</td></tr>
</table>

Performance reviews
throughout the year

<a id='c857084c-ae05-4a82-8d9d-ddf9e7fbc511'></a>

* May be reviewed less frequently depending upon team needs
** To be reviewed semi-annually

<a id='4abbe468-7c1e-4cf0-89f9-48940577bb4b'></a>

McKinsey & Company | 19

<!-- PAGE BREAK -->

<a id='cd7928f9-c47e-40de-8f1f-ddc7a68a8af7'></a>

KPI tree for GDF's first objective

<a id='9895d506-78a3-4b36-901e-60e393089a6c'></a>

| Objective | Category | High-level KPI | Detailed KPIs | Owner | Review frequency⁷ |
|---|---|---|---|---|---|
| | | | | | M | 3M | 6M | A |
|---|---|---|---|---|---|---|---|---|
| | 1.1 Cost | 1.1.1 Average total patient treatment or diagnostic unit cost:<ul><li>Prophylaxis (adult and pediatric)</li><li>1st line drugs (adult and pediatric)</li><li>2nd line drugs (adult and pediatric)</li><li>Diagnostics</li></ul> | | Procurement | option : [ ] | option : [ ] | option : [ ] | option : [x] |
| | | | 1.1.1.1 Average product cost per patient/unit | Procurement | option : [ ] | option : [x] | option : [ ] | option : [ ] |
| | | | 1.1.1.2 Average additional costs per patient/unit | Procurement | option : [ ] | option : [x] | option : [ ] | option : [ ] |
| Provide uninterrupted supply of 1st and 2nd line TB drugs and diagnostics<ul><li>At low cost</li><li>At high quality</li><li>On time</li><li>In a demand and customer-driven way</li><li>To eligible countries</li></ul><br>---<br>**Overarching KPIs**<br>option 1a: [ ] Number of patient treatments provided<br>option 1b: [ ] Average cost per treatment course | 1.2 Product quality and selection | 1.2.1 Percentage of GDF products that meet GDF QA standards | | Quality Assurance | option : [ ] | option : [x] | option : [ ] | option : [ ] |
| | | | 1.2.1.1 Percentage of suppliers that meet GDF QA standards | Quality Assurance | option : [ ] | option : [ ] | option : [ ] | option : [x] |
| | | 1.2.2 Percentage of TB products recommended in WHO/GLC guidelines that are available in GDF catalogue | | Quality Assurance | option : [ ] | option : [ ] | option : [ ] | option : [x] |
| | | 1.2.3 Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries (contracted/non-contracted)¹ | | Procurement | option : [ ] | option : [ ] | option : [x] | option : [ ] |
| | 1.3 Timeliness | 1.3.1 Percentage of orders delivered within the time stated on signed agreement | | Procurement and portfolio management | option : [x] | option : [ ] | option : [ ] | option : [ ] |
| | | | 1.3.1.1 Average lead time between receipt of country grant application to delivery of agreement to country for signing | Portfolio Management | option : [x] | option : [ ] | option : [ ] | option : [ ] |
| | | | 1.3.1.2 Average lead time between receipt of country-signed agreement and GDF placing order | Portfolio Management | option : [x] | option : [ ] | option : [ ] | option : [ ] |
| | | | 1.3.1.3 Average length of time from GDF placing order to date of order/shipment dispatch | Procurement | option : [x] | option : [ ] | option : [ ] | option : [ ] |
| | | | 1.3.1.4 Average length of time from order/shipment dispatch date to proof of delivery to country | Procurement | option : [x] | option : [ ] | option : [ ] | option : [ ] |
| | 1.4 Customer demand driven | 1.4.1 Percentage of patient treatments/diagnostics delivered vs. approved through grant/technical agreement | | Quality Management | option : [ ] | option : [x] | option : [ ] | option : [ ] |
| | | | 1.4.1.1 Orders delivered as percent of orders placed | Quality Management | option : [ ] | option : [x] | option : [ ] | option : [ ] |
| | | 1.4.2 Number of country-level stock-outs in countries served by GDF | | Quality Management | option : [ ] | option : [ ] | option : [x] | option : [ ] |
| | | 1.4.3 Customer satisfaction "index" (TBD) | | Quality Management | option : [x] | option : [ ] | option : [ ] | option : [ ] |

<a id='927754c7-6fa7-43f5-a9b4-9d5db5e5554e'></a>

1 Depends upon shortlist of suppliers received from Quality Assurance function
2 M = monthly; 3M = 3 monthly; 6M = 6 monthly; A = annually

<a id='506db111-ab4b-46ad-a3fa-9905de024147'></a>

SOURCE: Annual GDF report 2008; GDF strategic plan 2006 -10, Standard Operating Procedure for surveillance and measurement (SOP - 40.00); GDF Quality
Management Manual Rev 4.1 issue March 3, 2009; Team analysis

<a id='90322135-410c-4139-9ca2-d61d3cdc5863'></a>

McKinsey & Company | 20

<!-- PAGE BREAK -->

<a id='53396c5d-6577-413d-9e35-acdb1e103978'></a>

**_COO - Annual dashboard_**

<a id='e03a397f-7715-4881-ba07-23179c39b594'></a>

DUMMY NUMBERS

<a id='1dc2c672-acd2-4b58-8adb-138018cf7bb0'></a>

<::1a Number of patient treatments delivered: chart::>

Objective 1

| | Target | Actual | YoY trend (2008) | YoY trend (09) | YoY trend (2010) |
|---|---|---|---|---|---|
| **1st line** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.4 | Target: 2.3, Actual: 1.9 | Target: 2.1, Actual: 2.5 |
| **2nd line** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.2 | Target: 1.9, Actual: 1.7 | Target: 2.1, Actual: 2.1 |
| **Prophylaxis** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.2 | Target: 1.9, Actual: 1.7 | Target: 2.1, Actual: 2.1 |
| **Diagnostics** | option X: [ ] | option X: [ ] | Target: 2.0, Actual: 2.3 | Target: 3.8, Actual: 3.5 | Target: 4.0, Actual: 4.1 |

Legend:
option Target: [ ]
option Actual: [ ]
<::

<a id='931ecebd-6f18-4a76-ac87-50e8d0d296ce'></a>

1b Average cost per patient treatment or diagnostic unit ($)
<::Table: Average cost per patient treatment or diagnostic unit ($)

Legend: Target (light blue square), Actual (dark blue square)

| Category | Target | Actual | YoY trend (2008) Target | YoY trend (2008) Actual | YoY trend (2009) Target | YoY trend (2009) Actual | YoY trend (2010) Target | YoY trend (2010) Actual |
|:---------|:-------|:-------|:------------------------|:------------------------|:------------------------|:------------------------|:------------------------|:------------------------|
| 1st line | X      | X      | 4.7                     | 4.1                     | 4.5                     | 4.3                     | 4.4                     | 4.3                     |
| 2nd line | X      | X      | 13.0                    | 16.0                    | 12.0                    | 12.3                    | 12.0                    | 11.5                    |
| Prophylaxis | X      | X      | 1.6                     | 1.2                     | 1.6                     | 1.4                     | 1.5                     | 1.5                     |
| Diagnostics | X      | X      | 11.5                    | 12.0                    | 11.0                    | 11.0                    | 11.0                    | 12.0                    |
: chart::>

<a id='9f65e2fb-e529-4c43-b02e-dd010f1d6a5a'></a>

<table id="21-1">
<tr><td id="21-2"></td><td id="21-3" colspan="5">2a Number of grantee countries that moved to direct procurement this year</td></tr>
<tr><td id="21-4"></td><td id="21-5">Target</td><td id="21-6">Actual</td><td id="21-7">Countries</td><td id="21-8">Comments</td><td id="21-9"></td></tr>
<tr><td id="21-a">Objective 2</td><td id="21-b">X</td><td id="21-c">X</td><td id="21-d">bullet points</td><td id="21-e">bullet points</td><td id="21-f">... (list of asterisks)</td></tr>
</table>

<a id='aa8f5d56-81e2-4edf-9634-c0bea70023b7'></a>

Objec-
tive 3

3a Staff capacity and capability index

<::transcription of the content
: The image shows a traffic light icon with the bottom light (green) illuminated, while the top two lights (red and yellow) are unlit.::>

Comments

* ...
* ...

* ...
* ...

3c Ratio of funds raised/required for GDF activities ($M)

Funds raised Funds required Ratio

* X
* Y
* X/Y

<a id='3ce50753-8a84-45cf-a931-dd63a616efe8'></a>

3b Organizational health/culture index

<::description: A vertical traffic light icon with the middle (yellow) light illuminated.::>

Comments

*   ...
*   ...
*   ...
*   ...

<a id='6d676724-da42-428a-a791-569e9d5beada'></a>

3d Ratio of funds raised/required for GDF administrative costs ($M)

Funds raised
* X

Funds required
* Y

Ratio
* X/Y

<a id='516c5d92-701d-4e45-909b-c2c16095f22e'></a>

McKinsey & Company | 21

<!-- PAGE BREAK -->

<a id='f9296353-775b-47c8-bae7-d786c3349109'></a>

Procurement Team – *Annual dashboard*

<a id='b2be87aa-a0b6-4b89-9e3b-b152676c538f'></a>

DUMMY NUMBERS

<a id='91b82be0-4236-46ad-a033-11bb1058d31f'></a>

1.1.1: Average cost per patient treatment or diagnostic unit (USD)
<::Table and bar charts showing Average cost per patient treatment or diagnostic unit (USD).
Legend: Target (light blue square), Actual (dark blue square)

Panel 1:
| Category | Target | Actual | YoY trend (2008) | YoY trend (2009) | YoY trend (2010) |
|:---|:---|:---|:---|:---|:---|
| **1st line** |
| Adults | ▪ X | ▪ X | 1.1, 1.4 | 2.3, 1.9 | 2.1, 2.5 |
| Pediatrics | ▪ X | ▪ X | 1.1, 1.4 | 2.3, 1.9 | 2.1, 2.5 |
| **2nd line** |
| | ▪ X | ▪ X | 1.1, 1.2 | 1.9, 1.7 | 2.1, 2.1 |

Panel 2:
| Category | Target | Actual | YoY trend (2008) | YoY trend (2009) | YoY trend (2010) |
|:---|:---|:---|:---|:---|:---|
| **Prophylaxis** |
| Adults | ▪ X | ▪ X | 1.1, 1.2 | 1.9, 1.7 | 2.1, 2.1 |
| Pediatrics | ▪ X | ▪ X | 0.9, 1.1 | 1.6, 1.5 | 1.7, 1.6 |
| **Diagnostics** |
| | ▪ X | ▪ X | 2.0, 2.3 | 3.8, 3.5 | 4.0, 4.1 |
: table and bar charts::>

Objec-
tive 1

1.2.3: Percentage of products in GDF catalogue
with ≥ 2 suppliers in all eligible countries
<::Table showing Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries.

| Category | Number of products | Percentage with ≥ 2 suppliers |
|:---|:---|:---|
| **1st line** |
| Adults | X | X% |
| Pediatrics | X | X% |
| **2nd line** |
| | X | X% |
| **Prophylaxis** |
| Adults | X | X% |
| Pediatrics | X | X% |
: table::>

1.3.1.3: Average length of time from GDF placing
order to date of order/shipment dispatch (days)
<::Table and line chart showing Average length of time from GDF placing order to date of order/shipment dispatch (days).
Legend: Production (dark blue line), Average (light blue line), Stock (purple line)

| Category | Target | Actual | Deviation | Trend |
|:---|:---|:---|:---|:---|
| Average | ▪ X | ▪ X | ▪ X% | Line chart: Values range from 5 to 15, fluctuating across J F M A M J J A S O N D |
| Shipments from stock | ▪ X | ▪ X | ▪ X% | |
| Shipments from production | ▪ X | ▪ X | ▪ X% | |
: table and line chart::>

1.3.1.4: Average length of time from
order/shipment dispatch date to proof of delivery
to country (days)
<::Table and line chart showing Average length of time from order/shipment dispatch date to proof of delivery to country (days).

| Category | Target | Actual | Deviation | Trend |
|:---|:---|:---|:---|:---|
| | ▪ X | ▪ X | ▪ X% | Line chart: Values range from 10 to 30, fluctuating across J F M A M J J A S O N D |
: table and line chart::>

Objec-
tive 3

3.2.1: Staff satisfaction and motivation
<::Traffic light indicator with option Red: [ ], option Yellow: [x], option Green: [ ]
Comments
- ...
- ...
- ...
: traffic light indicator::>

3.2.2: Staff retention level/attrition rate
<::Traffic light indicator with option Red: [x], option Yellow: [ ], option Green: [ ]
Comments
- ...
- ...
- ...
: traffic light indicator::>

<a id='bd0b3a97-08f7-49e8-8319-728c5a33027e'></a>

McKinsey & Company | 22

<!-- PAGE BREAK -->

<a id='d3a316aa-1e9d-41b4-a077-26ba787a704f'></a>

Procurement Team – 1.2.3 Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries

<a id='ffeb187e-3fca-4c12-ae65-a6f6de4aca13'></a>

<::table
Legend: A blue background indicates "Does not meet target".
| | Total number of products | Percentage with ≥ 2 suppliers | Product | Number of suppliers > 4 | Number of suppliers 4 | Number of suppliers 3 | Number of suppliers 2 | Number of suppliers 1 | Number of suppliers 0 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
| 1st line | x | x | A | ✓ | | | | | |
| • Adults | | | B | | ✓ | | | | |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | ✓ | | | |
| | | | E | | | | ✓ | | |
| | | | F | ✓ | | | | | |
| | | | G | | ✓ | | | | |
| | | | H (Does not meet target) | | | | | | ✓ |
| | | | I | | | ✓ | | | |
|...|
| 1st line | x | x | A (Does not meet target) | | ✓ | | | | |
| • Paediatrics | | | B | | | ✓ | | | |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | | ✓ | | |
| | | | E | | | | | ✓ | |
|...|
| 2nd line | x | x | A (Does not meet target) | | | | | ✓ | |
| | | | B | | | | | | ✓ |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | | ✓ | | |
| | | | E (Does not meet target) | | | | | | ✓ |
::>

<a id='0dde0a9b-ebca-49a0-ab41-4e3e08bbbf29'></a>

McKinsey & Company | 23

<!-- PAGE BREAK -->

<a id='a8ff6b4e-5254-4335-8e35-9352f766f871'></a>

GDF performance review calendar



[ ] Combined meetings

<a id='e1695883-634e-455a-9b81-98a3fd4653a1'></a>

<::Table showing meeting schedules for 2010
: table::>
| Meetings | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec |
| :-------------------------------------- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| **Annual review meetings** | | | | | | | | | | | | |
| Coordinating Board | | | | | | | | | | | △ | △ |
| GDF COO | | | | | | | | | | | △ | △ |
| **Team meetings** | | | | | | | | | | | | |
| Annual¹ | | | | △ | | | | | | △ | | |
| Quarterly² | | | △△ | | | △ | | | △△ | | | △ |
| Monthly | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| **Cross-team meetings** | | | | | | | | | | | | |
| Procurement effectiveness | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| Product quality, selection, and supply | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| TA/M+E customer satisfaction | | | △△ | | | △ | | | △△ | | | △ |
| TA/M+E effectiveness | | △ | | | △△ | | | △ | | | △△ | |
| Recommendation implementation | △ | | | △△ | | | △ | | | △△ | | |
<::/Table showing meeting schedules for 2010
: table::>

<a id='4c8067fe-2a13-4758-acdf-f20eac183dd3'></a>

1. Quarterly and monthly KPIs can be discussed as necessary
2. Monthly KPIs can be discussed as necessary

McKinsey & Company | 24

<!-- PAGE BREAK -->

<a id='54bdd7da-395c-4dc3-9805-abcf09a84602'></a>

Next steps to implement and capture benefits

<a id='cdffca8e-6495-4076-b63b-701a3e57d559'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3">Description</td></tr>
<tr><td id="25-4">Share KPI trees with donors</td><td id="25-5">• Present GDF KPI tree to donors and compare with KPIs/metrics requested by donors • Discuss with donors if streamlined GDF KPIs meet their reporting requirements</td></tr>
<tr><td id="25-6"></td><td id="25-7">▪ Agree on any additional KPIs that need to be reported upon</td></tr>
<tr><td id="25-8">Integrate KPIs into MIS</td><td id="25-9">• Establish simple mechanisms within GDF&#x27;s existing MIS system to input and analyze data required for KPIs</td></tr>
<tr><td id="25-a">Complete performance dialogue workshop</td><td id="25-b">• Conduct 2 hour workshop with GDF team leads on facilitating constructive performance dialogues with teams</td></tr>
<tr><td id="25-c">Embed KPIs in team performance review</td><td id="25-d">Officially launch new performance management process; next steps are Assign data collection/reporting responsibilities within teams Schedule review meetings or add review to agendas of existing meetings Complete one round of performance reviews Refine KPIs and review process based on team feedback</td></tr>
</table>

<a id='1083dffa-82f5-4286-86cc-dcc423f1111a'></a>

McKinsey & Company | 25

<!-- PAGE BREAK -->

<a id='6e4737ab-e873-48b2-bc46-8d114cacd86a'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 26

<!-- PAGE BREAK -->

<a id='1e012048-be97-4388-bffc-55e039783cea'></a>

Advocacy Team issues and opportunities

<a id='d2cb35f6-7445-46cd-b1e8-bb274584cec6'></a>

GHP performance issue Advocacy improvement opportunities ① Setting advocacy objectives that stay current and relevant in changing external circumstances ① Setting advocacy objectives within Stop TB Partnership that stay current and relevant in changing external circumstances ① Finding and making visible tactical advocacy opportunities for partners to act ① Finding and making visible tactical advocacy opportunities for Stop TB partners to act <::cycle diagram: Performance management. The cycle has 6 steps: 1. Set objectives 2. Establish clear metrics 3. Set targets 4. Track and disseminate metrics 5. Review performance 6. Celebrate achievements and take further action::>

<a id='a316ee75-01d2-496b-85ed-cd28001eac25'></a>

McKinsey & Company | 27

<!-- PAGE BREAK -->

<a id='e88ed28c-ea7d-4d87-9692-61a76b8c04b8'></a>

3 steps ensure that emerging opportunities are incorporated in advocacy partners' plans and/or into the Framework Document

<a id='6b90d480-d694-4df6-b94d-c531c095423b'></a>

1

Get more information

- Make advocacy every partner's business and get them to increase their information sharing
- Extend the reach of TB advocacy beyond the Partnership

"Develop the sunflower"

2

Filter the information received

- To manage the flow of information collected, set up a process that allows the Advocacy Team¹ to filter the information for
  - Validity
  - Impact
  - Global relevance
  - Feasibility

"Filter the intelligence"

3

Create new or adjust current objectives and activity plans

I For tactical opportunities requiring immediate action

- Create new or adjusted objectives and activity plans based on new opportunities
- Define what success looks like, how to track progress

II For all opportunities not requiring immediate action

- Draft adjustments into the Framework Document
- Seek advice from AAC on changes drafted
- Share revised objectives and plans with partners

"Keep the framework relevant"

Review performance on new and adjusted objectives

<::transcription of the content
: The small visual shows "Stop TB Partnership" and text:
FRAMEWORK FOR ADVOCACY 2010
1. Problem: TB Burden (WHO 2009 Report)
- Globally, there were an estimated 9.27 million incident cases of TB (2007). Most of the cases were in Asia (55%), Africa (31%), and Europe (4%). Only 10% of incident cases were smear-positive. The TB incidence rate has remained stable or declined slowly in most regions of the world, except in Africa, where it has increased. The highest burden is in South-East Asia (3.3 million), followed by Africa (3.0 million), Western Pacific (1.8 million), and Europe (0.45 million), Americas (0.31 million), and Eastern Mediterranean (0.26 million).
- The total number of incident cases of TB is decreasing at the global level, but the rate of decline is not sufficient to reach the MDG target of halting and reversing the TB epidemic. The MDG target is to halt and begin to reverse the incidence of TB by 2015. The TB incidence rate declined at an average rate of 1.2% per year between 2000 and 2007.
- The global number of deaths from TB is estimated to be 1.3 million in 2007 (excluding HIV-positive cases).
- The proportion of cases that are HIV-positive is increasing, particularly in Africa.::>

1 Advocacy Team includes Secretariat advocacy and WHO STB department advocacy teams

<a id='3e00a44b-e189-4ac3-bba5-2d7aab16d26b'></a>

SOURCE: Workshops                                                     McKinsey & Company | 28

<!-- PAGE BREAK -->

<a id='aee2670f-eaf0-41c3-a086-921531846d6b'></a>

1 There are 2 steps to get more relevant information, faster

<a id='4da6e4ff-965b-4659-b9e1-8cb154066d10'></a>

Make advocacy every partner's business

<::Advocacy Network Working Groups Ambassadors STB Leadership Coordinating Board
: figure::>

A Present the advocacy framework to the Partnership
B Use recent framework developments to keep partners informed and excited about advocacy priorities
C Foster partner discussions on advocacy priorities/activities on Center for Resource Mobilization website
D Actively engage “Network Stars” within the Partnership

<a id='100ab738-d11e-42d6-84b1-dafea2fdf27e'></a>

Extend the reach of TB advocacy beyond the Partnership <::A graphic of a yellow flower-like design with multiple petals arranged in a circle around a central white space.::> E Locate, research and prioritize target Network Stars F Create opportunities to initiate contact with the Network Stars targeted G Nurture relationships with collaborative Network Stars, de-prioritize others

<a id='57270a93-0a8c-47d3-99da-abbf4c61f753'></a>

1 Network Stars are defined as the most highly connected individuals within a network through whom information flows first

SOURCE: Workshops
McKinsey & Company | 29

<!-- PAGE BREAK -->

<a id='eabecfdf-fff5-409f-87cc-7c1b75158a1c'></a>

2 The information received from an active and extended network needs to be filtered across 4 criteria

<a id='9bd7983f-2767-4cb5-a696-68ac0f5e13d6'></a>

<::logo: 
PRELIMINARY
The logo features three rectangular bars in a step-like arrangement, with the middle bar highlighted in blue against two lighter grey bars.::>

<a id='aa3db16b-94e8-499c-a24f-1a7267fa682f'></a>

<::flowchart::>This flowchart illustrates an information filtering process for an advocacy team.The process begins with an input box labeled "Advocacy Team receives unfiltered information".This input feeds into a large, horizontal funnel structure, which represents the filtering process.Along the funnel, there are four distinct filter stages, each with a corresponding label and description below it:1.  **Validity Filter**  The received information is checked for validity with a second source: "Is the information accurate and true?"2.  **Impact Filter**  Once validated, the information is filtered for work plan impact: Can the information affect  *   Policy?  *   Donors?  *   Public opinion?3.  **Global Filter**  The information is filtered for global relevance: "Does it have implications beyond local/national boundaries?"4.  **Feasibility Filter**  Determine whether the information can feasibly and realistically be translated into sufficiently impactful activitiesAt the bottom center, a final action box states: "Apply filter at start of advocacy meetings"<::

<a id='9172b8b1-fc1b-4b51-8458-4c7fa806a44a'></a>

SOURCE: Workshops                                               McKinsey & Company | 30

<!-- PAGE BREAK -->

<a id='4948df85-bedc-4356-98b8-adf8d1f63966'></a>

3 Framework document needs to be refined and revised based on information received <::process diagram: This diagram shows a three-step process depicted as ascending blocks, with an additional review step and a preliminary indicator. Above the steps, a small icon of three ascending bars is present, labeled "PRELIMINARY". The steps are:
1. Get more information
2. Set up process to filter the information received
3. Create new or adjust current objectives and work plans
An additional step, presented in an oval, is: Review performance on adjusted objectives.::>

<a id='db354b3b-bcea-4ddd-a0d7-daedc5163a4d'></a>

For tactical opportunities requiring immediate action
<table id="31-1">
<tr><td id="31-2">Analyze filtered intelligence and create new-or update current-objective</td><td id="31-3">Prompt for rapid input from AAC</td><td id="31-4">Share updates to all relevant stakeholders for immediate buy-in and action</td></tr>
<tr><td id="31-5">■ Create new objectives and plans, define success and how to measure progress
For all opportunities not requ (info icon)</td><td id="31-6">As time is limited, input gathering to happen over phone or same day email feedback loop ring immediate action</td><td id="31-7">Share new/adjusted objectives and plans Define success and how to measure/track progress (e.g., how many updates suggested? Pursued? Achieved?)</td></tr>
<tr><td id="31-8">Analyze filtered intelligence and create new-or update current-objective</td><td id="31-9">Share updates with and seek advice from AAC</td><td id="31-a">Input into Framework Document, share with Advocacy Network</td></tr>
<tr><td id="31-b">■ Secretariat Leadership and Advocacy Team jointly analyze and discuss the filtered information, drafting new or adjusted objectives</td><td id="31-c">■ Submit changes to AAC for input by next Advocacy Network call
■ More substantial adjustments to be submitted to the Coordinating Board</td><td id="31-d">Share adjusted Framework with Advocacy Network and other partners
— In monthly Advocacy Network call
— In monthly email update with link to CRM website</td></tr>
</table>

<a id='0957e3f5-6c5d-4987-bf7e-e76ceb955ad8'></a>

SOURCE: Workshops McKinsey & Company | 31

<!-- PAGE BREAK -->

<a id='7183d23a-021f-4ab7-825b-3a74230c4710'></a>

Next steps and expected impact

<a id='9a84278b-b7fd-4294-bb67-841233127e83'></a>

PRELIMINARY

<a id='ad17eba0-a6d0-46ad-8953-fd2b2202a95f'></a>

<table id="32-1">
<tr><td id="32-2"></td><td id="32-3">Description</td></tr>
<tr><td id="32-4">Engage the Partnership</td><td id="32-5">▪ Present framework document to – Coordinating Board: Nov 2009 – Advocacy Network: Dec 2009 (Cancun) – Stop TB Leadership: Nov 2009 – Core groups of the Working Groups: Nov 2009 ▪ Set up Advocacy Network calls</td></tr>
<tr><td id="32-6">Identify Network Stars, plan engagement</td><td id="32-7">▪ Map Network Stars within and beyond the Partnership ▪ Link Network Stars to objectives, prioritize outreach ▪ Plan engagement for prioritized Network Stars</td></tr>
<tr><td id="32-8">Develop CRM website section, Standard Operating Procedures</td><td id="32-9">▪ Advocacy Team to determine ideal structure and content of the CRM site section devoted to the framework ▪ Develop and disseminate Standard Operating Procedures for sharing information, updating the website (Nov 2009) ▪ Complete work on CRM website (Dec 2009)</td></tr>
</table>

<a id='85a2d987-0478-4f56-ab8f-0a7e36bdf969'></a>

## Expected impact

*   Strengthen Advocacy Network ties and increase dialogue between advocacy stakeholders
*   Improve the use and increase the sharing of relevant information
*   Stay ahead of emerging threats and opportunities
*   More efficient use of Advocacy Team's limited time - no extra resources required

<a id='264db118-21ab-4879-bf8c-538ab9ea1016'></a>

McKinsey & Company | 32

<!-- PAGE BREAK -->

<a id='e97205d1-2ac3-49d5-aed6-96a70e318269'></a>

Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 33

<!-- PAGE BREAK -->

<a id='a3bf043c-a447-4732-a605-db9aa3c95882'></a>

Communications Marketing and Branding issues and opportunities

<a id='7ec4f849-7421-48ca-8431-c47d94a513a1'></a>

GHP performance issue

① Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities

② Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB

Communications, marketing, and branding improvement opportunities

① Determining detailed objectives for each audience group that the Communications, marketing and branding team seeks to address

② Define metrics for each detailed objective

<::Performance management diagram: A circular diagram showing 6 steps.

1. Set objectives (blue arrow)
2. Establish clear metrics (blue arrow)
3. Set targets (grey arrow)
4. Track and disseminate metrics (grey arrow)
5. Review performance (grey arrow)
6. Celebrate achievements and take further action (grey arrow)

In the center of the circle: Performance management
: flowchart::>

<a id='bb3275c1-5bf1-497d-97e9-f41a518080b3'></a>

McKinsey & Company | 34

<!-- PAGE BREAK -->

<a id='139f5d06-aee8-4cbb-bc4c-951ad4fc74a2'></a>

4 steps lead to clear objectives, metrics and targets, as well as to required activities to deliver

<a id='c80e3470-78b2-43b5-bbcd-bb2188005465'></a>

1 Identify audience groups
<::
flowchart
Title: 1 Identify audience groups

High level objective: 2 Raise awareness about TB among members of the public in donor countries and selected high-burden countries / BRICS

This objective connects to the following Stakeholder group/audience:
- 2.1 High net worth individuals, DC
- 2.2 High net worth individuals, HBC, BRICS
- 2.3 Students / young adults, DC and HBC, BRICS
- 2.4 All other adults, DC
- 2.5 All other adults, HBC and BRICS
- 2.6 Children, DC and HBC, BRICS

Callout box: Identified and prioritized all audience groups per high-level objective

SOURCE: Team discussion
McKinsey & Company | 5
::>

2 Define specific objectives per audience group
<::
flowchart
Title: 2 Define specific objectives per audience group

High level objective: 2 Raise awareness about TB among members of the public in donor countries and selected high-burden countries / BRICS

This objective connects to the following Stakeholder group/audience with their respective objectives:
- 2.1 High net worth individuals, DC
  - Objective: Raise awareness about TB via traditional and innovative channels to increase private donations and penetrate influential networks
- 2.2 High net worth individuals, HBC, BRICS
  - Objective: Raise awareness about TB (focusing on the target's own context) via traditional and innovative channels in order to increase private donations and penetrate influential networks
- 2.3 Students / young adults, DC and HBC, BRICS
  - Objective: Develop and roll out a viral marketing / social media campaign
    - Stimulate commitment and action against TB from students
    - Generate student involvement for World TB Day, e.g., planning and organization of activities
- 2.4 All other adults, DC
  - Objective: Raise awareness about the prevalence and the disease via traditional and innovative channels in order to grow donations and generate additional bottom-up pressure on governments
- 2.5 All other adults, HBC and BRICS
  - Objective: Provide communications and marketing support in raising awareness and familiarity with TB so as to:
    - Support the increase in detection and treatment (e.g., educating on self-diagnosis, treatment steps), understanding of contagion risks
    - Foster additional pressure from civil society onto HBC governments
- 2.6 Children, DC and HBC, BRICS
  - Objective: Raise children's awareness for and sensitivity to TB by providing playful educational materials about the threat of TB, preventative measures, and common symptoms (in local language), e.g., using the Figo animated cartoon

Callout box: PRELIMINARY. Defined key communications/marketing objectives for each audience group/stakeholder

SOURCE: Team discussion
McKinsey & Company | 5
::>

<a id='3039746f-7eff-4889-850d-b58adea743e4'></a>

<::figure::>
# 3 Set metrics and targets

## 1B Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRICS

PRELIMINARY

| High level objective | Stakeholder group/audience | Objective per audience group | Metrics |
| :--- | :--- | :--- | :--- |
| Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRICS<br><br>**Metrics:**<br>- Website traffic from DC/BRICS)<br>- Public rating of TB as Global Health priority (in DC/BRICS) | 1B.1 HNWI¹ and highly networked individuals, DC | Raise awareness about TB via traditional and innovative channels | - Number of individuals reached<br>- Monetary and in kind contributions² (e.g., pro bono consultancy, TV placement of public service announcements) |
| | 1B.2 HNWI and highly networked individuals, HBC, BRICS | Raise awareness about TB in individual's country via traditional and innovative channels | - Number of individuals reached<br>- Percentage of people rating TB as priority health issue |
| | 1B.3 Students / young adults, DC and HBC, BRICS | Develop and roll out a viral marketing/social media campaign | - Number of people reached |
| | 1B.4 All other adults, DC | Raise awareness about the prevalence and threat of TB using traditional and innovative communication channels and marketing products | - Percentage of people rating TB as priority health issue |
| | 1B.5 All other adults, HBC and BRICS | Provide communications and marketing support in raising awareness of and familiarity with TB (special focus on women) | - Number of World TB Day campaign partners |
| | 1B.6 Children, DC and HBC, BRICS | Raise children's awareness for and sensitivity to TB by providing playful educational materials about the threat of TB | - Number of children reached through educational projects |

> Set specific metrics and S.M.A.R.T. targets for each prioritized objective

¹ High Net Worth Individuals
² Value of in kind donations to be estimated and translated in dollar amounts

SOURCE: Team discussion

# 4 Define activity plan

## 1C Raise awareness about TB among selected institutions – Business community (1/2)

| Priority stakeholder group/audience | Objectives | Metrics | Target |
| :--- | :--- | :--- | :--- |
| Business community | - Raise awareness among business people by targeting locations and venues they regularly encounter (restaurants, hotels, conference centers, rental car agencies) | - Number of business people reached through business partners (e.g., Kempinsky, Sixt)<br>- Monetary and in kind contributions¹ (e.g., pro bono consultancy, TV placement of public service announcements) | - 5M (VC to confirm Kempinsky numbers for 2009)<br>- >50%<br>- $2,000 (VC to confirm) |
| WHO DCO | | | |
| UNAIDS | | | |

> Defined activity plans required to achieve each prioritized target

¹ Value of in kind donations to be estimated and translated into dollar amount

SOURCE: Team discussion

McKinsey & Company | 5
::>

<a id='3716fc07-cfd2-4117-8450-7f263b35f008'></a>

McKinsey & Company | 35

<!-- PAGE BREAK -->

<a id='10b504e1-6cdc-440a-8652-7af6a73e3dc7'></a>

The high-level objectives are related to 3 areas – raising awareness about TB, engaging TB networks and supporting the Secretariat

<a id='adc11ef7-e5ec-46df-8689-927de2f91640'></a>

<::High-level objectives flowchart:
Mission
Inspire the world into action against tuberculosis (TB)

High-level objectives
1. Raise awareness about TB among
   A. The "fourth estate" (news media)
   B. Members of the public in donor countries and selected high-burden countries/BRIC+21
   C. Selected institutions
2. Engage, support and foster a shared sense of purpose among partners and other members of TB networks
3. Provide coordinated support for the core work of the Secretariat
: flowchart::>

<a id='55e04812-4474-4923-9965-1a977cc75aed'></a>

1 BRIC + 2 = Brazil, Russia, India, China, Indonesia and South Africa

<a id='df1aa5bc-570a-490d-8225-2ad0c5a49f90'></a>

McKinsey & Company | 36

<!-- PAGE BREAK -->

<a id='e19cbe94-cb7f-458a-b53c-236923ae754a'></a>

For each high-level objective, audience groups, objectives, metrics, and targets have been defined (1/2)

<a id='ffd3e81e-1a20-4227-97f4-74f618f8470d'></a>

<::High-level objective, Audience group, Objective, Metric, Target diagram:
- High-level objective:
  - 1B: Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRIC + 2
    - Audience group:
      - Students and adults in donor countries
        - Objective: Raise awareness about the prevalence and threat of TB using traditional and innovative communication channels and marketing products in order to grow donations and generate additional bottom-up pressure on social opinion
          - Metric: Total number of people reached through marketing channels
            - Target: Online viral campaign: 30 million
            - Target: TV Public Service Announcements (PSAs): 5 million
            - Target: Internet PSAs: 10 million
      - Students and adults in HBC¹
        - Objective:
          - Develop and roll out a viral marketing/social media campaign to:
            - Stimulate commitment and action against TB
            - Generate involvement in World TB Day, e.g. participation in and organization of activities
              - Metric: Number of high profile TB events targeting students and adults successfully planned and executed Total
              - Metric: Percentage of population 18-65 years old acknowledging TB as top 5 Global Health Priority
                - Target: Social networking tools/channels, e.g., YouTube, Facebook 5 million
      - Highly networked individuals in DC² and HBC
: figure::>

<a id='cd4e18a6-901c-4b72-9735-9133bf1712c1'></a>

1 HBC = High burden countries including BRIC +2
2 DC = Donor countries
<table id="37-1">
<tr><td id="37-2"></td><td id="37-3">McKinsey &amp; Company</td><td id="37-4">37</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='d47881e6-5cd1-4c20-a425-274aab01e9ab'></a>

For each high-level objective, audience groups, objectives, metrics,
and targets have been defined (2/2)

<a id='81f09190-535e-4f41-b656-62d9d871b476'></a>

<::High-level objective, Audience group, Objective, Metric, Target diagram
: diagram::>
## High-level objective
1A. Raise awareness about TB among the "fourth estate" (news media)

## Audience group
- Feature writers/magazine editors, DC
- Health/Science/Development journalists, DC
- Editorial page editors, DC
- Influential journalists and editors, HBC²
- Broadcast producers, DC
- Citizen journalists, DC

## Objective
- Meet with editors to encourage TB coverage (focus on women's magazines)
- Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB

## Metric
- Number of personal meetings with editors
- Number of editors engaged in ongoing dialogue following personal meeting

## Target
- 4
- 2

**Connections:**
- The high-level objective "Raise awareness about TB among the 'fourth estate' (news media)" connects to all audience groups.
- The "Feature writers/magazine editors, DC" audience group connects to the objective "Meet with editors to encourage TB coverage (focus on women's magazines)". This objective then connects to the metric "Number of personal meetings with editors" and the target "4".
- The audience groups "Health/Science/Development journalists, DC", "Editorial page editors, DC", "Influential journalists and editors, HBC²", "Broadcast producers, DC", and "Citizen journalists, DC" all connect to the objective "Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB". This objective then connects to the metric "Number of editors engaged in ongoing dialogue following personal meeting" and the target "2".

<a id='fde4417c-a938-4e7f-b9a0-c529aae57a5e'></a>

McKinsey & Company | 38

<!-- PAGE BREAK -->

<a id='763d41a5-a479-4760-8679-fbb2199dd0cb'></a>

The team will finalize execution plans and align with other teams to ensure the right activities get done

<a id='57860557-c3de-4bb1-9f2a-caee3dc8681a'></a>

Execution plans and budgets

<a id='b4f2974a-8078-46c7-99fb-10a8f8e74565'></a>

Internal and
cross-
functional
alignment

<a id='19d74252-0adc-465c-b836-0e410dd39ece'></a>

Performance review

<a id='aac1495a-6c5c-40f0-9386-bc3c59c9ffb1'></a>

## Description

- Present updated objectives to Executive Secretary
- Complete detailed execution plans with activities required to meet objectives
- Allocate budgets/resources to activities

---

- Align with Advocacy and Partnering and Social Mobilization teams to ensure
  - Responsibilities for shared objectives are clear
  - Ownership of activities is transparent
  - Interfaces on joint projects are well managed

---

- Ensure regular (e.g., quarterly) review to assess progress against objectives

<a id='0a8690bd-7156-493d-a62e-c03271b4057c'></a>

# Expected impact
- Focus within team on the high-impact activities that directly aim at delivering against objectives
- Clear ownership for deliverables, within and across teams
- Ability to measure and review performance of communication, marketing and branding – functions that are typically difficult to assess

<a id='6fe42f62-8dac-492b-8040-2491e4fb4a43'></a>

McKinsey & Company | 39

<!-- PAGE BREAK -->

<a id='931a9353-65bc-4621-b40f-11af95d317f4'></a>

Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 40

<!-- PAGE BREAK -->

<a id='5178bc2d-2ae3-42ae-9e7a-cc5f6605d0a3'></a>

CFCS issues and opportunities

<a id='5f8a5024-4b40-470e-b294-e9decb52a830'></a>

<::attestation: Status indicator
PRELIMINARY
Readable Text: PRELIMINARY
The word "PRELIMINARY" is centrally located, underlined, and has a vertical line to its left.::>

<a id='924a424e-4e0a-4e4b-a590-16573a680706'></a>

GHP performance issue
① Getting from a vision to the specific
objectives for the partnership and its bodies
rather than directly to activities

CFCS improvement opportunities
① Refine the mission based on experience
and lessons learned in the first two years
of the CFCS program
① Articulate specific objectives around the
newly refined mission statement

<::Performance management: flowchart::>
<::1 Set objectives::>
<::2 Establish clear metrics::>
<::3 Set targets::>
<::4 Track and disseminate metrics::>
<::5 Review performance::>
<::6 Celebrate achievements and take further action::>

<a id='a53fe459-e277-474a-b932-b7c20e77f97a'></a>

McKinsey & Company | 41

<!-- PAGE BREAK -->

<a id='012795ad-d4ed-499c-b11e-03a15afddeed'></a>

The team conducted 4 workshops to revise the CFCS mission, objectives, selection and evaluation criteria

<a id='a1aabaa4-5c33-444f-8272-82470ba24faf'></a>

1. Refine current mission based on the experience accumulated since program inception, reviews and lessons from field visits
2. Define objectives based on the newly revised mission
3. Determine the proper set of application selection criteria that best help achieve CFCS objectives
4. Define grant evaluation criteria and template to allow for easy and efficient assessment of individual grant performance

<a id='ff08487b-42d3-4bac-b1eb-309476415789'></a>

McKinsey & Company | 42

<!-- PAGE BREAK -->

<a id='3d25974d-af92-4abc-85cd-cdeafef4509e'></a>

As a first step, the team clarified the CFCS mission and defined objectives to deliver this mission

<a id='4aaa1548-fecc-482f-8bf9-76cb005e7171'></a>

<::flowchart
: Mission
: To provide support to community-based organizations engaged in advocacy and social mobilization activities seeking to raise awareness and empower communities to become part of the solution in the fight against TB
: Objectives
:   Assist community-based civil society organizations
:     Detail
:       Provide small grants for projects that
:       - Increase awareness and active participation of local communities
:       - Build capabilities of members of local communities
:       Provide coaching and technical assistance to grant recipients
:       Strengthen links between grant recipients and local authorities
:       Bring together different organizations and grant holders to exchange best practices in mobilizing communities and managing projects
:       Identify and stimulate the submission of high-quality/competitive applications
:   Efficiently manage CFCS resources
:     Detail
:       Develop selection criteria that
:       - Ensure the involvement of local health services and TB programs
:       - Strengthen the autonomy and responsibility of local people
:       - Demonstrate the greatest promise of project sustainability
:       Use simple project evaluation processes and criteria that:
:       - Assess project impact
:       - Extract lessons learned
:       - Integrate lessons learned in subsequent selection and evaluation
:       Hold grantees accountable to abide by project milestones
: flowchart::>

<a id='445a5b93-5c4c-49b9-96d2-b0f74c937c86'></a>

McKinsey & Company | 43

<!-- PAGE BREAK -->

<a id='a86e2378-61d7-429d-9c5d-516b0f003308'></a>

The CFCS team can use 2 simple indicators to monitor performance against the objectives

<a id='b2b689ae-94be-46bb-94c3-25bd43997fd9'></a>

<table id="44-1">
<tr><td id="44-2">Objectives</td><td id="44-3">Metrics</td></tr>
<tr><td id="44-4">Assist community-based civil society organizations</td><td id="44-5">Percentage of funded projects that have impact, defined as achieving ≥X score on evaluation criteria</td></tr>
<tr><td id="44-6">Efficiently manage CFCS resources</td><td id="44-7">Percentage of funds dispersed to projects that receive ≥Y score on selection criteria</td></tr>
</table>

<a id='ff11298f-803b-44ca-b823-54632351b017'></a>

The selection and evalua- tion criteria help to define performance standards

<a id='1a056aa7-4c80-4bf6-be7f-c98c92caa525'></a>

McKinsey & Company | 44

<!-- PAGE BREAK -->

<a id='54dc7dcb-5949-4baf-8c3a-6009cff59efb'></a>

The selection template will allow the selection committee to assess if proposals aim to deliver against CFCS objectives

<a id='d105f97c-b023-434f-acf0-4d972b8a7be9'></a>

0 Strongly disagree
4 Strongly agree

<a id='9b4b3a22-2dfc-4955-a50e-9834af3f3b97'></a>

<table id="45-1">
<tr><td id="45-2"></td><td id="45-3"></td><td id="45-4" colspan="5">Score</td></tr>
<tr><td id="45-5">Themes</td><td id="45-6">Detailed criteria</td><td id="45-7">0</td><td id="45-8">1</td><td id="45-9">2</td><td id="45-a">3</td><td id="45-b">4</td></tr>
<tr><td id="45-c" rowspan="4">Contribution of grants to CFCS objectives</td><td id="45-d">The proposal includes advocacy and social mobilization activities within the target community</td><td id="45-e">blank checkbox</td><td id="45-f">blank checkbox</td><td id="45-g">blank checkbox</td><td id="45-h">white rectangle with shadow</td><td id="45-i">white rectangle with shadow</td></tr>
<tr><td id="45-j">The proposal includes activities that build awareness and encourage participation of local community</td><td id="45-k">blank checkbox</td><td id="45-l">blank checkbox</td><td id="45-m">blank checkbox</td><td id="45-n">white rectangle with shadow</td><td id="45-o">white rectangle with shadow</td></tr>
<tr><td id="45-p">The proposal contains capability building/training activities that empower individuals within the target community with practical knowledge about their rights and responsibilities in TB care and control</td><td id="45-q">blank checkbox</td><td id="45-r">blank checkbox</td><td id="45-s">blank checkbox</td><td id="45-t">white rectangle with shadow</td><td id="45-u">white rectangle with shadow</td></tr>
<tr><td id="45-v">The proposal contains activities that strengthen the engagement of local health services and other relevant organizations with the local community</td><td id="45-w">two stacked rectangles (checkboxes)</td><td id="45-x">two stacked rectangles (checkboxes)</td><td id="45-y">two stacked rectangles (checkboxes)</td><td id="45-z">one gray rectangle (visual)</td><td id="45-A">one gray rectangle (visual)</td></tr>
<tr><td id="45-B" rowspan="4">Clarity of objectives and activities</td><td id="45-C">Grant objectives respond to a specific TB control challenge Objectives are S.M.A.R.T.¹</td><td id="45-D">two stacked rectangles (checkboxes)</td><td id="45-E">two stacked rectangles (checkboxes)</td><td id="45-F">two stacked rectangles (checkboxes)</td><td id="45-G">two gray rectangles (visual)</td><td id="45-H">two gray rectangles (visual)</td></tr>
<tr><td id="45-I">Activities are in logical and consistent relation to the objectives</td><td id="45-J">rectangle (checkbox)</td><td id="45-K">rectangle (checkbox)</td><td id="45-L">rectangle (checkbox)</td><td id="45-M">one gray rectangle (visual)</td><td id="45-N">one gray rectangle (visual)</td></tr>
<tr><td id="45-O">Each activity is appropriately budgeted</td><td id="45-P">rectangle (checkbox)</td><td id="45-Q">rectangle (checkbox)</td><td id="45-R">rectangle (checkbox)</td><td id="45-S">one gray rectangle (visual)</td><td id="45-T">one gray rectangle (visual)</td></tr>
<tr><td id="45-U">Administrative costs do not surpass 25% of the total budget</td><td id="45-V">rectangle (checkbox)</td><td id="45-W">rectangle (checkbox)</td><td id="45-X">rectangle (checkbox)</td><td id="45-Y">one gray rectangle (visual)</td><td id="45-Z">one gray rectangle (visual)</td></tr>
<tr><td id="45-10" rowspan="2">Clarity of expected outcomes</td><td id="45-11">The proposal includes metrics and targets</td><td id="45-12">single white square</td><td id="45-13">single white square</td><td id="45-14">single white square</td><td id="45-15">one grey rectangle</td><td id="45-16">one grey rectangle</td></tr>
<tr><td id="45-17">There is a clear plan to measure against metrics</td><td id="45-18">single white square</td><td id="45-19">single white square</td><td id="45-1a">single white square</td><td id="45-1b">one grey rectangle</td><td id="45-1c">one grey rectangle</td></tr>
<tr><td id="45-1d">Project sustainability</td><td id="45-1e">The outcomes generated by the activities in the proposal Can be sustained in a way that meets funding requirements Result from processes that have been institutionalized</td><td id="45-1f">two white squares</td><td id="45-1g">two white squares</td><td id="45-1h">two white squares</td><td id="45-1i">two grey rectangles</td><td id="45-1j">two grey rectangles</td></tr>
</table>

<a id='1cab08e9-3ee0-4a0e-b05a-018e9dc35198'></a>

1 SMART – Specific, measurable, actionable, realistic, time-bound

<a id='6523e3ad-1f3a-47cb-b886-0928eee94e4f'></a>

Total score = TBD
(Maximum score = 52)

McKinsey & Company | 45

<!-- PAGE BREAK -->

<a id='4bd66e92-93d6-49fc-8a52-bd9e0e091cfc'></a>

The evaluation criteria template assesses whether grants have performed against CFCS objectives

<a id='ed99ec49-3171-4302-af9a-15304a28c523'></a>

0 Strongly disagree
4 Strongly agree

<a id='d2357933-60aa-4358-9b3f-80a63237345a'></a>

Score

<::transcription of the content
: -----
: 0   1   2   3   4
::>

<a id='8feab63f-ceeb-4770-8fb9-91206733c3f9'></a>

<table id="46-1">
<tr><td id="46-2">Themes</td><td id="46-3">Detailed criteria</td><td id="46-4">0</td><td id="46-5">1</td><td id="46-6">2</td><td id="46-7">3</td><td id="46-8">4</td></tr>
<tr><td id="46-9" rowspan="3">Empower communities by increasing awareness/participation and by building capabilities</td><td id="46-a">Grant increased awareness within local community</td><td id="46-b">square icon</td><td id="46-c">square icon</td><td id="46-d">square icon</td><td id="46-e">(white rectangle with shadow)</td><td id="46-f">(white rectangle with shadow)</td></tr>
<tr><td id="46-g">Grant increased active participation within local community</td><td id="46-h">square icon</td><td id="46-i">square icon</td><td id="46-j">square icon</td><td id="46-k">(white rectangle with shadow)</td><td id="46-l">(white rectangle with shadow)</td></tr>
<tr><td id="46-m">Grant provided evidence of knowledge transfer to local community (e.g., examples of activities within local community that were enabled by training)</td><td id="46-n">square icon</td><td id="46-o">square icon</td><td id="46-p">square icon</td><td id="46-q">(white rectangle with shadow)</td><td id="46-r">(white rectangle with shadow)</td></tr>
</table>

<a id='aa8fae1f-e80f-4078-b738-f62cc85f3f2e'></a>

<table id="46-s">
<tr><td id="46-t" rowspan="3">Strengthened links with local health services/ other organizations</td><td id="46-u">Grantee has developed a collaboration mechanism with local health services</td><td id="46-v">(blank square)</td><td id="46-w">(blank square)</td><td id="46-x">(blank square)</td><td id="46-y">rectangle with shadow</td></tr>
<tr><td id="46-z">Local health services endorsed activities and outcomes</td><td id="46-A">(blank square)</td><td id="46-B">(blank square)</td><td id="46-C">(blank square)</td><td id="46-D">rectangle with shadow</td></tr>
<tr><td id="46-E">Grantee proactively engaged and interacted with other local relevant organizations</td><td id="46-F">(blank square)</td><td id="46-G">(blank square)</td><td id="46-H">(blank square)</td><td id="46-I">rectangle with shadow</td></tr>
</table>

<a id='e5d1e0d1-1a37-4cdc-84b1-7b555e6ed162'></a>

<table id="46-J">
<tr><td id="46-K">Ensured activities are sustainable</td><td id="46-L">Generated outcomes are sustainable/long-lasting (e.g., required funds are in place, processes to sustain outcomes are in place)</td><td id="46-M"></td><td id="46-N"></td><td id="46-O"></td></tr>
</table>

<a id='aaa54aac-62e4-44d2-aa40-3aafeca0bab4'></a>

Total score = TBD
(Maximum score = 28)

<a id='ed52fcab-be35-4876-8580-fce73b8736aa'></a>

McKinsey & Company | 46

<!-- PAGE BREAK -->

<a id='059055b1-0951-4b77-b968-d3d04f4b4e8b'></a>

Implementing the selection and evaluation criteria would allow CFCS to fund the right proposals and more easily assess their impact

<a id='083bbc40-0fd4-439e-8ff6-2a8b42d700d1'></a>

<table id="47-1">
<tr><td id="47-2"></td><td id="47-3">Description</td></tr>
<tr><td id="47-4">Implementation Cross-functional alignment</td><td id="47-5">▪ Receive approval to continue CFCS from Coordinating Board ▪ Define list of activities to elicit project proposals that are aligned with objectives and selection criteria ▪ Apply selection template in review of applications for next funding round in Q1 2010 ▪ Apply evaluation templates to assess awarded grants ▪ Discuss short-listed proposals with other Partnership bodies to ensure synergies between activities at local level*</td></tr>
<tr><td id="47-6">Performance review</td><td id="47-7">• Ensure regular (e.g., semi-annual) performance review to assess progress against CFCS objectives</td></tr>
</table>

<a id='abc83d2a-c575-463f-8d91-0bc9298e77f1'></a>

# Expected impact

*   Increase in number
    of high potential,
    relevant applications
*   Decrease in time
    and resources
    needed to
    *   Correctly assess
        potential of an
        application
    *   Evaluate the
        implementation of
        grants
*   Synergies captured
    across CFCS and
    other Partnership
    bodies

<a id='00e6e7bc-285a-437e-9d55-186cf69acd43'></a>

1 E.g., country X to move from GDF grant services to direct procurement; CFCS project supports activities to advocate with local government to increase TB resources

<a id='a0d1ad6b-e0d5-42af-b0df-01567fedd300'></a>

McKinsey & Company | 47

<!-- PAGE BREAK -->

<a id='f7ee9ca7-10a6-4161-8a7b-7a629e7ab83d'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 48

<!-- PAGE BREAK -->

<a id='33ed211e-2457-47a9-b7de-04ebdc4b313d'></a>

MDR-TB Working Group issues and opportunities

<a id='22da3de2-4711-4397-b8b3-7793d2dab646'></a>

GHP performance issue

Enablers
*   **Culture** – Ensuring partners within a loose working group arrangement are engaged and motivated to contribute
*   **Capacity** – Allocating significant resources to performance management given limited resources for internal processes

Processes

② Agreeing the right metrics for objectives that are difficult to measure
③ Committing to targets is difficult because of voluntary nature of partnerships

<::transcription of the content
: chart::>

<::transcription of the content
: flowchart::>

<a id='3f9a94fb-d659-4a76-a86f-6d1c75c53272'></a>

# MDR-TB Working Group improvement opportunities

## Enablers
* Developing a simple survey-based tool to assess the level of working group engagement
* The procedural operations of the WG (e.g., following-up on specific activities) are restricted by limited secretariat/ managerial resources

## Processes
2. Metrics set by the WG could be more explicitly tied to objectives of the WG and its members
3. Accountabilities and timelines for specific actions/outcomes are not always clear

<a id='46424ccb-aa41-40b3-ae21-ef35722bbac0'></a>

McKinsey & Company | 49

<!-- PAGE BREAK -->

<a id='aad7614c-91b1-4f31-ae01-a97b3d0b6b0a'></a>

Questions for MDR-TB WG team barometer

<a id='999517af-a7a5-4081-a973-7a1e385342e0'></a>

<table id="50-1">
<tr><td id="50-2"></td><td id="50-3" colspan="2">Strongly disagree (arrow pointing left)</td><td id="50-4"></td><td id="50-5" colspan="2">Strongly agree (arrow right)</td></tr>
<tr><td id="50-6"></td><td id="50-7">1</td><td id="50-8">2</td><td id="50-9">3</td><td id="50-a">4</td><td id="50-b">5 (blue arrow pointing right)</td></tr>
<tr><td id="50-c" colspan="6">Objectives and direction</td></tr>
<tr><td id="50-d">The objectives of the WG are clear and members are fully aligned on them</td><td id="50-e">empty checkbox</td><td id="50-f">empty checkbox</td><td id="50-g">empty checkbox</td><td id="50-h">empty checkbox</td><td id="50-i">rectangle with shadow</td></tr>
<tr><td id="50-j">The WG&#x27;s leaders provide clear strategic direction</td><td id="50-k">empty checkbox</td><td id="50-l">empty checkbox</td><td id="50-m">empty checkbox</td><td id="50-n">empty checkbox</td><td id="50-o">rectangle with shadow</td></tr>
<tr><td id="50-p">The Chair of my subgroup provides clear direction</td><td id="50-q">checkbox (empty)</td><td id="50-r">checkbox (empty)</td><td id="50-s">checkbox (empty)</td><td id="50-t">checkbox (empty)</td><td id="50-u">simple rectangle shape</td></tr>
<tr><td id="50-v" colspan="6">Delivery against objectives</td></tr>
<tr><td id="50-w">I believe the WG is making good progress towards achieving its objectives</td><td id="50-x">checkbox (empty)</td><td id="50-y">checkbox (empty)</td><td id="50-z">checkbox (empty)</td><td id="50-A">checkbox (empty)</td><td id="50-B">simple rectangle shape</td></tr>
<tr><td id="50-C">My subgroup meaningfully contributes to the overall objectives of the WG</td><td id="50-D">checkbox (empty)</td><td id="50-E">checkbox (empty)</td><td id="50-F">checkbox (empty)</td><td id="50-G">checkbox (empty)</td><td id="50-H">simple rectangle shape</td></tr>
<tr><td id="50-I">The WG is having a meaningful impact in the fight against MDR-TB</td><td id="50-J">checkbox (empty)</td><td id="50-K">checkbox (empty)</td><td id="50-L">checkbox (empty)</td><td id="50-M">checkbox (empty)</td><td id="50-N">simple rectangle shape</td></tr>
</table>

<a id='b864a4c2-68de-47d9-821b-d915d3c89918'></a>

<table id="50-O">
<tr><td id="50-P" colspan="6">Individual contributions</td></tr>
<tr><td id="50-Q">My role within my subgroup is clearly defined</td><td id="50-R">empty checkbox</td><td id="50-S">empty checkbox</td><td id="50-T">empty checkbox</td><td id="50-U">empty checkbox</td><td id="50-V">rectangular shape (with shadow)</td></tr>
<tr><td id="50-W">The individual contribution of each member of my subgroup meets my expectations</td><td id="50-X">empty checkbox</td><td id="50-Y">empty checkbox</td><td id="50-Z">empty checkbox</td><td id="50-10">empty checkbox</td><td id="50-11">rectangular shape (with shadow)</td></tr>
<tr><td id="50-12">After meetings, accountabilities and deadlines for specific actions are clear</td><td id="50-13">empty checkbox</td><td id="50-14">empty checkbox</td><td id="50-15">empty checkbox</td><td id="50-16">empty checkbox</td><td id="50-17">rectangular shape (with shadow)</td></tr>
<tr><td id="50-18">My contribution to the subgroup receives sufficient recognition</td><td id="50-19">empty checkbox</td><td id="50-1a">empty checkbox</td><td id="50-1b">empty checkbox</td><td id="50-1c">empty checkbox</td><td id="50-1d">rectangular shape (with shadow)</td></tr>
</table>

<a id='8664e597-81fd-4d03-a1b8-2d069f176935'></a>

Mindsets and behaviors

The culture within the WG is collaborative and constructive
option : [ ]
option : [ ]
option : [ ]
option : [ ]
option : [ ]

Members are encouraged to voice their opinions, even if they are controversial
option : [ ]
option : [ ]
option : [ ]
option : [ ]
option : [ ]

<a id='9248a043-4162-4f40-b883-a1bab4fe5434'></a>

McKinsey & Company | 50

<!-- PAGE BREAK -->

<a id='2226ea83-9404-4360-ba08-d3c51b7c993a'></a>

The collaborative work with the MDR-TB Working Group is just beginning
– overview of suggested next steps

<a id='c55b873a-099e-461b-b529-0185339aeec2'></a>

# Next steps

* Launch MDR-TB Working Group "team barometer" survey
* Develop metrics and targets that directly evaluate
  performance against WG objectives
* Develop further approaches to improve members'
  participation and accountability
* Assess the implications of MDR-TB scale-up on the WG
  and assess future capacity requirements
* Develop a "business case" for additional secretariat/
  managerial resources, if required

<a id='581fa8a7-de26-490d-917a-7e163e691260'></a>

McKinsey & Company | 51

<!-- PAGE BREAK -->

<a id='03f17ccc-353d-43b2-ae47-061afb7339eb'></a>

# Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 52

<!-- PAGE BREAK -->

<a id='f07a0511-26f4-4f4a-87e8-ee46c77cb8cb'></a>

Project outlook – the next ~ 10 weeks will focus on implementing the solutions developed

<a id='7831e05b-bf8b-43f3-bb0f-e1719101e222'></a>

<::A timeline diagram showing three sequential stages: "Diagnose" from August to September, "Design" from September to October, and "Deliver" from November to December. A marker labeled "Today" points to a position on the timeline between the "Design" and "Deliver" stages.: timeline::>

<a id='1ad9c91b-44d1-4e38-82e5-256d52b0f6e9'></a>

* Implementation within project teams begins
* Problem-solving sessions on findings, lessons learned, and implications are conducted
* Workshops to share achievements with other Partnership bodies are conducted
* Report is produced and findings are published
* Progress is presented to Coordinating Board in March 2010

<a id='25a16ac8-2738-497a-8538-f091c64ed9bc'></a>

McKinsey & Company | 53