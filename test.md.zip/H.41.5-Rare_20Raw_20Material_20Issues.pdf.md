<a id='698431f7-533f-4c72-b3a5-7d9297e14be8'></a>

<::A logo for "WORLD MATERIALS FORUM". The logo features a blue 3D cube icon on the left, with the text "WORLD MATERIALS FORUM" to its right. "WORLD" and "FORUM" are in a light gray outline font, while "MATERIALS" is in a solid blue font. The background of the image is an abstract blue pattern, possibly industrial or material-related, with a wavy light gray element at the bottom.: figure::>

<a id='84fe567c-1cf4-4c1c-a5d1-b9af4c53b710'></a>

Challenges in Mining:
Scarcity or Opportunity?

<a id='b5208dbb-f9ee-435f-a96b-c4223387eb38'></a>

Contribution of Advanced Technologies

<a id='21252f3b-52eb-4c30-956e-74d4ca948fb2'></a>

World Materials Forum
June 23, 2015

<a id='4e1a70be-e053-4066-b0f8-cc4ad9c1e8eb'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='d828e55a-e5f4-4282-aade-e8bb8715e8af'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='14b285c8-170a-4e24-acc3-438442d0f730'></a>

**Mining productivity globally has declined ~30% over the past decade**

<a id='655cac4d-c9ca-4f64-ac5a-893f70dd1826'></a>

McKinsey Mining Productivity Index, 2004 = 100<::chart: A line chart titled "McKinsey Mining Productivity Index, 2004 = 100" shows two lines representing productivity trends from 2004 to 2013. The Y-axis ranges from 65 to 110 in increments of 5. The X-axis shows years from 2004 to 2013. The first line starts at 105 in 2004, decreases to around 90 by 2006, then fluctuates, reaching approximately 77 in 2013. The second line starts at 100 in 2004, decreases to around 78 by 2007, then fluctuates, reaching approximately 72 in 2012 and rising slightly to around 73 in 2013. Annotations indicate average annual percentage changes: "-6.0% p.a." is shown for the initial decline of the lower line (approx. 2004-2007), "-3.5% p.a." for the initial decline of the upper line (approx. 2004-2009), and "-0.4% p.a." for a later segment of the upper line (approx. 2009-2013). The background features a faint, stylized image of mining equipment.::>

<a id='62d9600c-3f2c-46a5-a8d5-ab8b15e4044a'></a>

* Between 2004 and 2013, global mining productivity has fallen ~30%, or 3.5% p.a., even after accounting for geological degradation

<a id='0b748e63-c4e4-4be6-a311-47bf3681f8c5'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='0ff725a9-fb68-4d0a-88c2-d0ed657ce25f'></a>

McKinsey & Company

<a id='40ad40ed-8a34-4698-818a-8ef0d6b74a2f'></a>

1

<!-- PAGE BREAK -->

<a id='5075dd15-96db-4e69-932f-8a33978cad66'></a>

The decline prevails across most commodities as well as across all major mining geographies

<a id='7b6d5057-dffb-4d7a-a08c-748c4df6f4f9'></a>

McKinsey Mine Productivity Index
CAGR, 2009 - 2013

<a id='e9c4cd7f-ec28-4707-b831-8b5c138ede87'></a>

McKinsey Mine Productivity Index
CAGR²

<a id='a845d5fa-0318-49d4-a51b-3c4945695d1a'></a>

<::Bar chart with four vertical bars against a background image of large mining machinery. Each bar represents a different material and shows a negative value. Below each bar is the name of the material and an image of the raw material. The bars are all light blue.

Bar 1:
- Value: -1.5
- Material: Copper
- Image: A cluster of reddish-brown copper ore.

Bar 2:
- Value: -1.6
- Material: Iron ore
- Image: A dark, metallic-looking piece of iron ore with some green discoloration.

Bar 3:
- Value: -1.7
- Material: Coal
- Image: A small pile of black, irregularly shaped coal lumps.

Bar 4:
- Value: -4.5
- Material: PGMs¹ (Platinum Group Metals)
- Image: A shiny, grayish-silver nugget of platinum group metals.
: chart::>

<a id='a692308b-7a9e-44a9-9cfe-ec9206910d2e'></a>

* Almost all commodities registered declines in mining productivity - the trend is apparent across precious commodities as well as bulk minerals, indicating a more systemic shift that cuts across different mining methods or processing techniques

<a id='4833868e-645b-4786-992c-b37dd22c7f09'></a>

<::Bar chart showing four vertical blue bars extending downwards from a horizontal line. Below each bar is a numerical value and a geographical region label with a faint map outline.
- Bar 1: Value -4.1, Label: Latin America (with map of South and Central America)
- Bar 2: Value -4.2, Label: Australia (with map of Australia)
- Bar 3: Value -4.8, Label: North America (with map of North America)
- Bar 4: Value -4.8, Label: Sub-Saharan Africa (with map of Africa)
: bar chart::>

<a id='86c4bf0d-b5fe-4634-b25b-380d0447e7a5'></a>

* North America and Sub-Saharan Africa experienced the biggest declines in productivity over the period

<a id='940707b9-b91f-4528-9d1e-5f211ed426c3'></a>

1 Platinum group metals
2 For Latin America CAGR is for 2005 to 2012, for Australia and Subsaharan Africa CAGR is for 2004 to 2013 and for North America CAGR is for 2006 to 2013

<a id='84c7af56-27e4-4841-8098-398b07008753'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='949ade9e-976b-44e4-b4f0-4b4bbc5080ca'></a>

McKinsey & Company

<a id='9c8213f6-1f76-475b-848f-428f96bea6e2'></a>

2

<!-- PAGE BREAK -->

<a id='e5315dec-564b-4756-9ade-262dfcb4fae6'></a>

The industry also faces dramatic capital and operating costs escalations

<a id='8d4ca6ee-700d-46bd-b960-236ef982bdaa'></a>

MineLens Productivity Index indexed, 2004 = 100 CAGR,¹ 2004-13 %<::chart: A combined bar chart. The left section shows the "MineLens Productivity Index" with two bars: 2004 at 100 and 2013 at 72. An arrow points from 100 to 72, labeled "-3.5% p.a.". The right section displays four sets of bar charts, each comparing values for 2004 (indexed at 100) and 2013, along with their Compound Annual Growth Rate (CAGR). The categories are: 1. Production, mined volume: 2004 (100), 2013 (345), CAGR 14.8%. 2. Employment, number of workers: 2004 (100), 2013 (178), CAGR 6.6%. 3. Capital expenditures, asset value (indexed, 2004 = 100 in real terms²): 2004 (100), 2013 (1,681), CAGR 36.8%. 4. Operating expenditures, excluding labor cost (indexed, 2004 = 100 in real terms²): 2004 (100), 2013 (446), CAGR 18.1%. The x-axis for both main sections of the chart is labeled "2004" and "2013".::>

<a id='2102d823-c085-4df1-b2c1-b2c9372469ca'></a>

1 Compound annual growth rate
2 Capital expenditures and operating expenditures adjusted for mine cost inflation

<a id='aa824cc9-0bae-4783-99d9-054f677e96ae'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='ecb866e8-9569-469b-af4b-ff751d52fe5a'></a>

McKinsey & Company

<a id='373bf929-f279-47a7-a394-9d1a9a3c5e04'></a>

3

<!-- PAGE BREAK -->

<a id='c8895173-8a23-4522-a595-5837e2b9a632'></a>

Mining companies can pursue 4 levers to thrive in
tomorrow's challenging and uncertain mining environment

<a id='a896e8b9-bb8f-4d0b-97f9-32dec12be56d'></a>

Focus of this document

<a id='8a1646da-2e20-4aba-b5ce-69216761179f'></a>

<::Diagram titled "Levers for unlocking value": The diagram consists of a central box with the title, surrounded by four other boxes, each detailing a specific lever. The levers are: Embed effective Management Operating systems Free people and resources to prioritize productivity and operational excellence, drive robust performance management, working across silos and data-driven decision making; Focus on innovation Adopt fresh mindset to innovation, including technology adoption, advanced analytics and use of big data; Operations excellence Relentless focus on eliminating waste and variability, and improving productivity of assets through advanced reliability and maintenance approaches.; Capability building Upgrade individual and organizational capabilities to deliver the above.::>

<a id='03cb304f-5183-4426-9f14-d5dd6344b626'></a>

SOURCE: McKinsey Basic Materials Practice

<a id='84c52a62-d4ff-4958-9216-8112c0f5e429'></a>

McKinsey & Company

<a id='646d362d-b9d0-4c4e-afa3-d07b7712c928'></a>

4

<!-- PAGE BREAK -->

<a id='adeb2179-120c-44ed-bb95-360f846d60ec'></a>

Mining companies are increasingly looking at technological innovations to address the declining productivity trends

<a id='adf7c5b2-0b92-4a34-8308-941d9ed12f58'></a>

"Now we need to protect our operating margins, we have to improve our working practices",. "**The company is moving towards full automation at it's mines,** "something we have been slow to progress in the past"
– *Diego Hernandez, CEO Antofagasta*

<a id='e4dba20b-5977-4d98-a8f8-e1462a0a903c'></a>

<::logo: Antofagasta PLC
ANTOFAGASTA PLC
The logo features an orange circular emblem with a stylized white mountain over three wavy lines, flanked by purple text.::>

<a id='086a2255-ff00-41a1-b9a9-ae975a1f948f'></a>

<::SANDVIK
[Solid blue rectangle]
: figure::>

<a id='9ff38669-9d6e-4995-95bd-ef650da13f7c'></a>

"Progressive mining companies are beginning to implement automated systems, with the **rest of the industry expected to follow suit**"
"Autonomous technologies represent a class of innovation that will profoundly change how minerals are mined and processed"

– ***Ken Stapylton, Vice President surface drilling, Sandvik***

<a id='462999a2-bd8f-484f-adfb-1b3f368b841c'></a>

SOURCE: Press search

<a id='d0ea6e48-ca54-429a-8bd9-ddbb1a46e4d3'></a>

McKinsey & Company

<a id='11e48290-6aa8-4281-92b6-1c996779a9e8'></a>

5

<!-- PAGE BREAK -->

<a id='df1017cb-361b-4a70-ab9d-656f4a449ec6'></a>

Advanced technologies are being developed and implemented across all stages of the mining value chain

Commercially available
In testing
In developmer

NOT EXHAUSTIVE
Focus of this document

<a id='b6f413d1-1088-4dc2-b9a6-8c1484162650'></a>

<table><thead><tr><th>OEMs</th><th>Status</th><th>Expected commercial availability</th></tr></thead><tbody></tbody></table>

<a id='42664704-09d4-4afe-bd24-8fa258268b96'></a>

Exploration
<::image of two people in mining gear looking at a tablet/device in an outdoor setting; logos: GEOSOFT; progress indicator: dark blue solid circle; icon: compass-like icon::>
- Computer algorithm automatically
  detects patterns in exploration data
  indicative of mineralisation
Drilling
<::image of a drilling rig in an open-pit mine; logos: SANDVIK, CAT, Atlas Copco, FLANDERS; progress indicator: dark blue solid circle; icon: drilling machine icon::>
- All major OEMs offer products with
  various level of automation
- Other firms specialize in retrofitting
  existing drills for automation
Blasting
<::image of an explosion/blasting in a mine; logos: AEL Mining Services; progress indicator: circle with about 25% dark blue (quarter filled); icon: explosion cloud icon::>
- The charging process can be
  automated, with the required amount of
  explosive being entered beforehand
Loading
<::image of a large excavator/shovel loading material; logos: HITACHI, CSIRO; progress indicator: circle with about 50% dark blue (half filled); icon: excavator/shovel icon::>
- OEMs developing autonomous shovels
Hauling
<::image of a large mining haul truck with '131' on the side; logos: HITACHI, CAT, KOMATSU; progress indicator: dark blue solid circle; icon: mining haul truck icon::>
- Komatsu and Caterpillar have
  commercial offerings
- Hitachi running field trials
Other
support
equipment
<::image of a large yellow bulldozer; logos: HITACHI, KOMATSU, CAT; progress indicator: circle with about 50% dark blue (half filled); icon: bulldozer icon with a superscript '1'::>
- All major OEMs developing are
  developing autonomous solutions for
  support equipment like dozers,
  shearers, etc.
2008
2020
2025
1 Tele-remote dozers are already in quite extensive use; autonomous will take longer due to their irregular usage cycles

<a id='c1cbba43-d13e-4d05-b6a6-2ad6baae5208'></a>

SOURCE: Expert interviews; Press search

<a id='993d176f-f890-4a0b-8184-8fa221d3103d'></a>

McKinsey & Company

<a id='18d21204-4ba8-4c83-9647-a546f6307ccc'></a>

6

<a id='4f0bee24-cec1-4817-aefe-259b9ba8cba8'></a>

Examples

<!-- PAGE BREAK -->

<a id='4ca43110-9034-42a6-b820-988037bfc53a'></a>

**Multiple categories of advanced mining technologies are reaching commercialization and deployment stages**

<a id='824f2c63-11be-466c-ab89-f64166f036ec'></a>

<::Legend: square color codes and their meanings
- Light blue square: Ideas and prototypes
- Medium blue square: Field testing and early adoption
- Dark blue square: Full scale commercialization
: legend::>

<a id='37efa7ae-fcb8-4c69-ac2a-73bccea2a9d6'></a>

<::Timeline chart: The chart shows the evolution of autonomous mining technologies, divided into two main sections: A) Autonomous drills and B) Autonomous Haulage, over a timeline from 1970 to 2015. The x-axis represents years from 1970 to 2015.

A) Autonomous drills:
-   Late 1990s (implied before 2000): Atlas Copco demonstrates prototype at Mini Expo 2000 (with Atlas Copco logo).
-   Early 2000s: Atlas Copco partners with Rio Tinto to prepare drills for testing.
-   Mid 2000s: Sandvik and Atlas Copco developing drills in tandem for UG & OP applications.
-   Late 2000s/Early 2010s: Operational testing of Atlas Copco Pit Vipers (autonomous) by Boliden.
-   Mid 2010s: Rio Tinto tests fully autonomous bench drilling (with Rio Tinto logo).

B) Autonomous Haulage:
-   Early 1990s: CAT begins tests in USA (with CAT logo).
-   Mid 1990s: Komatsu begins tests in Australia (with Komatsu logo).
-   Early 2000s: First major commercialization: 11 trucks at Gaby mine (Codelco) (with Codelco logo).
-   Late 2000s/Early 2010s: Immersive technologies opens AH simulation training school (with Immersive Technologies logo).
: chart::>

<a id='4a7c01ec-5d0f-4a7d-bb55-2a7b06de57fe'></a>

<table id="7-1">
<tr><td id="7-2">What next?</td></tr>
<tr><td id="7-3">Hitachi is expected to make a number of autonomous solutions commercially available soon: AH trucks (2015), Shovels (2017), Graders and Dozers (2018)Many drills currently being operated semi-autonomously/tele-remotely (e.g., by Barrick, Codelco, Anglo American) but have capacity to be fully autonomous pending labor agreements and/or changes to operations</td></tr>
</table>

<a id='a7b17c0a-041b-4d40-859a-db2651770ee4'></a>

SOURCE: Expert interviews; Press search; McKinsey analysis

<a id='7704d8f3-37f5-4def-864d-2e51e7e15715'></a>

McKinsey & Company

<a id='1de1cc12-b367-45ee-ba45-51537b6c7ef0'></a>

7

<!-- PAGE BREAK -->

<a id='a15490d9-bc09-4d0c-a423-5e3dbeb77962'></a>

A Automated drilling is the latest step in the long evolution of drill and blast technology

<a id='f76eefaa-3275-4193-bc36-293bc2e37dd4'></a>

Rio Tinto and Atlas Copco formed an alliance to work together to develop autonomous drilling solutions for surface mining <::A large yellow drilling rig with a tall mast is operating in an open-pit mine, surrounded by grey rock formations and dust.: photo::>

<a id='950790f2-4ee4-4ee7-a4f1-5a51a8afc0c8'></a>

Atlas Copco and Rio Tinto successfully automated surface drilling, completing a computer-generated drill pattern

<::transcription of the content
: photograph of a sandy field with some sparse vegetation and hills in the background under a clear sky::>

<a id='43ab7a5c-f05b-40f7-9899-1e9d1bbcc62b'></a>

<::Timeline chart showing key events in the development of autonomous drilling rigs:
- **2006**:
  - Rio Tinto began to explore autonomous drilling rigs at Australia's Pilbara iron ore region.
  - Image: An aerial view of a large drilling rig operating in a reddish-brown open-pit mine, with a series of drilled holes visible on the ground.
- **2008**:
  - No event description provided. This year is marked on the timeline.
- **2011**:
  - Sandvik and Flanders formed a formal partnership to automate surface mining drill rigs and provide autonomous operation.
  - Image: A ground-level view of a yellow drilling rig with a tall mast, situated in an open-pit mine environment with hills or mountains in the background.
: timeline::>

<a id='94d8a943-7d89-49af-a3a4-527fca97a155'></a>

Rio Tinto became the first to achieve **fully automated** production bench **drilling** without human intervention at a test site in Australia <::A person is shown from behind, sitting at a desk and looking at multiple computer monitors. One monitor prominently displays four smaller screens, possibly showing live feeds or data. A laptop is also on the desk to the right of the person. This setup appears to be a control station for automated operations.: photograph::>

<a id='0a3f3048-42a2-4ef0-92b8-bc043b8288ef'></a>

SOURCE: Press search; Company brochures

<a id='7bb025b7-16bf-45e2-a26f-154867a0a597'></a>

McKinsey & Company

<a id='d25e7520-ceba-46ca-9493-ae610ae1e4dd'></a>

8

<a id='5c747d2a-eb1f-4b7d-b8e3-d8d50accbd43'></a>

<::Timeline diagram with a horizontal arrow pointing right. Two points are marked on the timeline: 2013 and 2014. Above the 2013 marker is a small gray circle. Below the 2014 marker is a small gray circle.
: diagram::>

<!-- PAGE BREAK -->

<a id='e7a3b2c5-0400-4452-ba74-74b0be4f4895'></a>

B Autonomous haulage has three key components

<a id='9bf10d42-a562-4578-9969-612d19f40161'></a>

Description

<a id='2ae6b17e-302b-4f5a-b706-926550f96e65'></a>

1 Base vehicle & automa- tion kit

<::A large yellow mining truck.
: figure::>

2 Critical mine site infra- structure

<::A word cloud with "INFRASTRUCTURE" prominently displayed. Other words include: SUPERSTRUCTURE, ENVIRONMENTAL, MAINTENANCE, DEVELOPMENT, INSTALLATION, SYSTEM, MILITARY, TRANSPORTATION, SNOWBLOWERS, WATER, FINANCING, LAND, STANDARD, TENDERING, BREAKWATERS, GOVERNMENT, PIPELINE, SEWERS, SIGNALLING, ELECTRIC WORK, BUILDINGS, FACILITIES, LICENSING, IRRIGATION, ELECTRICAL, COMMUNICATIONS.
: figure::>

<a id='55bbefdf-6584-4321-b43a-e9754855d382'></a>

* Standard **truck body**
* Onboard embedded systems and real-time **operating software** informing and controlling the truck's activities (e.g., **sensors**, computers, video system, traction control, **GPS tracking**, and **radio receptivity for remote inputs**)

<a id='e097dd7c-b404-4b6d-8df6-0b50266bbee8'></a>

- High-capacity **communications network**
- **GPS locators** for all vehicles within the orbit of AH trucks

<a id='d3c47050-c469-4a4b-8d47-3e548d88d64a'></a>

3 Command and control centre <::A photograph of a modern command and control centre. The room features a large, curved white desk equipped with numerous computer monitors displaying blue screens. Several black office chairs are positioned around the desk. In the background, there are larger screens or windows also displaying blue. : photo::>

<a id='635a40f6-18d4-45e8-818e-792e93e26542'></a>

- **Headquarters** from which trucks monitored/remotely controlled
- Can be **on-site or off-site** (e.g., Rio Tinto is experimenting with controlling autonomous equipment from 1500km away)
- Operator ensures **adherence of vehicles to loading, dumping, and traffic management** plans, makes **adjustments** to vehicles' trajectories where necessary, and **restarts** the trucks in case of automatic shutdown triggered by trucks' safety protocols
- 1 operator can track the progress of **numerous vehicles**

<a id='f001d48e-fcec-46a2-9b50-4715f972ac49'></a>

SOURCE: Expert Interviews; McKinsey Analysis

<a id='054df464-0936-41fd-8726-4d2e78479606'></a>

McKinsey & Company | 9

<!-- PAGE BREAK -->

<a id='4c309d5a-7359-479b-ae2d-fa2bb6f20f95'></a>

Innovation is key to overcome scarcity
issues in rare raw materials

<a id='94deb072-69f1-4bfb-8fab-135be5f929e1'></a>

NON-EXHAUSTIVE

<a id='1fc36804-5566-4306-a395-487ab269bf77'></a>

<::
Solid blue circle: Heavy" 
Outlined blue circle: Light
Icon with circular arrows: Size of the bubble indicates resource size
: chart::>

<a id='925dbaeb-79ef-44e0-9678-d319b952f62e'></a>

# Levers to drive change

*   Effective management systmens
*   Operational excellence
*   Innovation across the whole supply chain
*   Capacity building

<::illustration of a white humanoid figure holding a large red wrench: image::>

<a id='d3007b73-ccc0-4ef3-b0a6-39a548e034cd'></a>

<::Bubble chart titled "Ore grade % TREO" on the y-axis (ranging from 0 to 10) versus "Minimum lead time Years" on the x-axis (ranging from 1 to 13). The x-axis also shows project stages: Ramp-up (1 year), Construction (2-5 years), Feasibility (6-7 years), Pre-feasibility (8-10 years), and Drilling (11-13 years). Each bubble represents a project, with its size possibly indicating project scale or resource size. Projects shown include:
- Mount Weld: High ore grade (around 9.5% TREO), 1 year lead time (Ramp-up).
- Mountain Pass: High ore grade (around 6.5% TREO), 1 year lead time (Ramp-up).
- Mount Weld Duncan: Around 5% TREO, 6 years lead time (Feasibility).
- Araxá: Around 4.5% TREO, 10 years lead time (Pre-feasibility).
- Strange Lake: Around 3% TREO, 5-6 years lead time (Construction/Feasibility).
- Ngualla: Around 2% TREO, 10 years lead time (Pre-feasibility).
- Nechalacho: Around 1-2% TREO, 9 years lead time (Pre-feasibility).
- Niobec: Around 1-2% TREO, 7-8 years lead time (Feasibility).
- Dubo: Around 1% TREO, 3-4 years lead time (Construction).

A callout box points to Mount Weld and Mountain Pass, stating: "Two large projects close to production, focused on light rare earths."

Below the chart, there is a caption: "Long term industry sustainability requires additional projects at later stages of the project pipeline.": chart::>

<a id='02d9cec1-7549-4bdd-b060-660af03a3470'></a>

1 Heavy rare earths projects are the ones with more than 15% of total rare earth content of heavy elements

<a id='9d94232d-cf63-4b23-9c93-d1ee14df5fd7'></a>

SOURCE: Technology Metals Research, expert interviews

<a id='fc8c81fd-15ab-4f39-a49b-4f4abd5286d2'></a>

McKinsey & Company

<a id='f57d4b81-b403-4588-b78e-ba1ef829ed38'></a>

10

<!-- PAGE BREAK -->

<a id='faa33cca-d161-4982-bc15-95117820f084'></a>

BACKUP (Presented on ad-hoc basis if there are questions)

<a id='b2fe08fc-f9d6-438c-b3ea-1f0d5f4c8de4'></a>

McKinsey & Company

<a id='c6a59f1f-2aac-4305-9884-23d001f2901e'></a>

11

<!-- PAGE BREAK -->

<a id='50d5abe6-4df7-4f01-a7d5-5972d2878eed'></a>

Executive summary

<a id='42703391-c259-448c-a9b5-b474d087594d'></a>

▪ Multiple forces at work, such as labour scarcity, rising costs of inputs, increased health and safety standards, and declining productivity, have been putting **significant pressure on the mining industry** in the last decade, e.g.,

	– Average copper mine input costs have risen ~150% in the past 15 years
	– In 10 years, productivity in some of the world's major mining hubs has declined by up to 50%
▪ Mining companies are **increasingly looking at technological innovations** to address these trends, with a view to reducing costs and increasing productivity
▪ Development, testing and implementation of high-tech solutions in mining have **exploded in the past 15 years**, with advanced technologies being developed and implemented across all stages of the mining value chain, from exploration to hauling and dozing
▪ There is an increasing sense among all sizes of mining companies that “**the future is now**”, and that the best-performing companies in the next decades will be the one willing to assume the costs of implementing advanced technologies during this challenging period
▪ Examples of the most promising and most developed advanced technologies include

	– **Autonomous haulage**, which has been implemented at ~25 sites and can **reduce overall haulage costs 10-40%**
	– **Autonomous or tele-remote drilling**, which has been trialled at nearly 20 sites, with demonstrated increase of both available drilling time per shift and **drilling/blasting accuracy**, leading to a **knock-on impact on downstream processes**

<a id='66f9050b-cacb-4d87-ad8e-e0d2e01ebba9'></a>

nging period
dvanced tech
ed at ~25 site:

<a id='6e8cacb3-b38b-4b90-b67b-7abd780b4d4a'></a>

McKinsey & Company

<a id='bd5d4a7a-218d-4a2b-b7ba-4f1f0507766f'></a>

12

<!-- PAGE BREAK -->

<a id='f91b19ad-1fe5-41bd-87ef-498d5d277b81'></a>

The mining industry faces multiple forces which will adversely impact industry economics going forward

<a id='6bc24ddf-4659-4291-aeaf-e603407245bf'></a>

<::diagram
: A central image of an open-pit mine is surrounded by eight octagonal text boxes, each representing a force. Clockwise from the top, these forces are:
- Continuously increasing safety, health and environment standards
- Rising cost of production inputs
- Demand growth fueled by population growth and socio-economic changes
- Declining productivity
- Labor scarcity
- Increasing price volatility (by-product credits)
- Increasingly challenging geologies
- Global sourcing changing equipment industry structure::>

These forces will have determine how mines are set up and run in the future

<a id='d755b3b6-f7a0-465b-8959-ad39d374ca3b'></a>

SOURCE: McKinsey Basic Materials Practice

<a id='39c806d9-fff3-4ac1-9ad8-3d015847b5b7'></a>

McKinsey & Company

<a id='851f26b9-74f9-43d3-bb06-9ab061de23e4'></a>

13

<!-- PAGE BREAK -->

<a id='061fa1a1-cc80-4b60-8187-ba061ff71fec'></a>

The McKinsey Mining Productivity Index reveals that mining productivity
globally has declined 3.5% p.a. over the past decade

<a id='7b89046f-4067-45dd-ad05-36743e1327f1'></a>

McKinsey Mining Productivity
Index, 2004 = 100

<a id='a413d1a1-a8dc-407d-b267-f490d4c0987b'></a>

Approach
<::line chart: Index, 2004 = 100
Y-axis: Index values from 65 to 110
X-axis: Years from 2004 to 2013

Two lines are plotted:
1. Light blue line: Represents an index starting at 100 in 2004 and fluctuating downwards, ending around 72 in 2013.
2. Dark blue line: Represents an index starting at approximately 105 in 2004 and generally declining.
   - From 2004 to approximately 2008, the average annual decline is indicated as "-6.0% p.a.".
   - From approximately 2008 to 2013, the average annual decline is indicated as "-0.4% p.a.".
   - An overall average annual decline for the period 2004-2013 is indicated as "-3.5% p.a." associated with this dark blue line.::>

*   McKinsey Mining Productivity Index computed using global data set comprising
    *   Detailed data at mine-site level for ~50 mines from all major mining jurisdictions
    *   10 years of performance data
*   All values indexed to 2004 = 100

*   Between 2004 and 2013, global mining productivity has fallen ~30%, or 3.5% p.a., even after accounting for geological degradation

<a id='8dadb039-084f-41b3-bdfd-bc7085d18756'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='c22dcbe6-404c-459f-9277-1dc17afa5a6c'></a>

McKinsey & Company

<a id='22356f9e-f1b7-4b7f-8d22-e61ade96b825'></a>

14

<!-- PAGE BREAK -->

<a id='0b510f3e-d346-4a0b-b060-2ec4a1e135d9'></a>

Mining companies are increasingly looking at technological innovations to address the declining productivity trends

<a id='7cb60555-8e67-424c-b448-62facb87eda4'></a>

<table id="15-1">
<tr><td id="15-2">&quot;Where we&#x27;re really behind, shamefully behind, is in the issue of productivity&quot; – Thomas Keller, CEO Codelco; April 2014, CRU World Copper Conference, Santiago</td><td id="15-3">&quot;With our Southdowns project (Western Australia), we are able to vastly improve the economics by steepening the walls and improving the strip ratio because we have proven methods and [remote control diril, rock-breaker and explosives loader] technology to manage those steeper walls&quot; – Matthew Andersson, Mining Manager, Grange Resources</td></tr>
<tr><td id="15-4">&quot;Declining productivity is now a problem we share&quot; - Paul Dowd, Director OZ Minerals</td><td id="15-5">&quot;Progressive mining companies are beginning to implement automated systems, with the rest of the industry expected to follow suit&quot; “Autonomous technologies represent a class of innovation that will profoundly change how minerals are mined and processed&quot; – Ken Stapylton, Vice President surface drilling, Sandvik</td></tr>
</table>

<a id='8f6e56bf-6267-4156-8fa6-560b9995d45a'></a>

"Now we need to protect our operating margins, we have to improve our working practices",. "The company is moving towards full automation at it's mines, "something we have been slow to progress in the past"

– Diego Hernandez, CEO Antofagasta

<a id='ea3c1430-bfff-40b4-ac09-1d875a1a5ba1'></a>

SOURCE: Press search

<a id='0a75834d-906b-42cb-8a8b-061a26834d33'></a>

McKinsey & Company

<a id='307e019a-fd00-49ab-87a8-3167f95c904c'></a>

15

<!-- PAGE BREAK -->

<a id='7ca52e08-e414-4f04-b44f-4b0314c2c4a7'></a>

Autonomous equipment-enabled open-pit mines rely on the careful and coordinated interplay of the mine-wide control systems and equipment

<a id='34bc2548-da8d-48d5-a8fa-96dc614eb863'></a>

<::The image is a detailed diagram illustrating a smart mining operation within an open-pit mine. The background shows an aerial view of a large, terraced open-pit mine. Various components of the smart mining system are depicted as icons with accompanying text labels, connected by yellow wavy lines representing wireless communication and data flow. The components are:

- **Control centre**: Located at the top left, an icon shows a control room with multiple monitors, a desk, and a chair, with a person operating it. The text associated is: "Control centre On-site and/or remote. Includes autonomous fleet management software and live monitoring/feedback". Wireless signals emanate from the control centre towards the mine.
- **Mine LAN and radio communications**: A text box in the upper middle of the mine reads: "Mine LAN and radio communications". Yellow wavy lines radiate from this box, indicating network coverage across the mine.
- **Conveyors**: At the top right, an icon displays a conveyor belt system used for transporting materials. The text label is: "Conveyors".
- **Rock breaker**: An icon of a tracked excavator with a breaking attachment is shown on the left side of the mine. The text label is: "Rock breaker".
- **Loaders**: An icon of a front-end loader is depicted in the upper middle left. The text label is: "Loaders".
- **Drills**: An icon of a drilling rig is positioned in the middle right of the mine. The text label is: "Drills".
- **Smart equipment**: This is a general label located in the lower middle, referring to the various pieces of automated mining machinery.
- **Haul trucks**: An icon of two large mining haul trucks is shown in the lower left. The text label is: "Haul trucks".
- **Dozers**: An icon of a bulldozer is located in the bottom middle. The text label is: "Dozers".
- **Ore tagging**: On the right side, an icon depicts an RFID tag with a wireless signal radiating from it. The text associated is: "Ore tagging RFID Tag RFID signal".
- **Blast charging**: At the bottom right, an icon represents an explosion, indicating blasting activities. The text label is: "Blast charging".

All these elements are interconnected by the yellow wavy lines, symbolizing a comprehensive, wirelessly connected smart mining environment.: figure::>

<a id='9e889517-a837-4e25-bddd-0dc26d623279'></a>

Control centre
On-site and/or remote.
Includes autonomous fleet
management software
and live
monitoring/feedback

<a id='2354d941-039a-439e-93d9-5a32cb725e5c'></a>

<::On a textured grey background, partially visible on the top left are two grey wheels with blue centers. Below them, a dark blue rectangular label reads "Haul trucks". On the right, a stylized blue illustration of a tracked vehicle, resembling a bulldozer, is depicted. Partially visible dark blue rectangular shapes are present above and below the bulldozer illustration.: figure::>

<a id='5a0f44c2-e8d3-4690-bea4-061272a3f044'></a>

<::logo: [Unknown] Blast charging A blue cloud-like explosion graphic with a dark blue banner below it.:>

<a id='bb9d3ea8-8b8b-4e97-841b-1831d600f396'></a>

SOURCE: Expert Interviews; Sandvik webpage; Caterpillar webpage; Metso webpage; Transmin webpage

<a id='bd4c0fa8-b9bd-4a7b-b4e3-23c1f8cb816a'></a>

McKinsey & Company

<a id='df3360b7-78a8-424f-ba45-bb47b0906a9e'></a>

16

<!-- PAGE BREAK -->

<a id='01c3cfec-9d88-4bb6-a280-c0db57f7f841'></a>

Different degrees of autonomy in haul trucks

<a id='46a70e4a-4064-4f97-b955-87797b792875'></a>

Semi-autonomous trucks

<a id='ec4e1ced-b53b-4ff0-b991-ec5497254ada'></a>

Fully autonomous trucks

<a id='ff5ea091-937d-4eb3-897f-bdbf6f0efd9c'></a>

<::Image of car steering wheel controls. The controls are silver buttons. On the left, there's a large button labeled "CRUISE". To its right, there's a rocker switch with "RES+" above and "SET-" below. Below these, there are two smaller buttons: one with a steering wheel with three wavy lines above it (indicating a heated steering wheel) and another labeled "CANCEL". The bottom part of the image shows a reflection of these controls.: figure::>

<a id='fe8af327-b0c7-4289-b973-abcc537b3a41'></a>

<::A large yellow Caterpillar mining dump truck, model 790, is shown from a slightly rear-right angle. The truck has massive wheels and a large dump bed. The CAT logo is visible on the rear of the truck. The truck is on a dirt or gravel surface, with some piles of earth in the background. A reflection of the truck is visible below a horizontal line at the bottom of the image.
: figure::>

<a id='dc058cc5-0de0-458b-b800-ee3d2960a925'></a>

* Driver still present in vehicle
* Vehicle has a form of "cruise control" for the length of the haul route
* Driver tends to reassume control for loading and dumping, and whenever an obstacle presents itself (e.g., manned vehicle, obstruction in the road)

<a id='6b256a5b-9073-4b75-8158-d4c1f263a0a4'></a>

- All stages of haul cycle are autonomous
- No operator is required in vehicle
  - One operator can oversee multiple trucks simultaneously from a remote control centre
  - Command centre can be on- or off-site
- There are currently 3 archetypes of fully autonomous trucks _(detailed next page)_

<a id='beac2e69-6059-43f9-b986-02f889a85914'></a>

SOURCE: Expert interviews

<a id='740676d9-c681-40f0-a3e2-c378071cef3d'></a>

McKinsey & Company

<a id='f9c6a301-e065-41be-976a-ed62eb85c7f3'></a>

17

<!-- PAGE BREAK -->

<a id='0a071d02-f49d-49e7-9401-2797d0ea78c9'></a>

BASE VEHICLE AND AUTOMATION KIT
Key on-board components of autonomous haul trucks

<a id='724c7cd0-6dc7-43d2-b41f-83fc14fdad3f'></a>

### Autonomous Control Cabinet
Sealed hydraulic and electronic controls

### GPS
<::transcription of the content
: photo of a GPS antenna::>
GPS technology is combined with a tracking system to accurately monitor location of vehicles

### Autonomous Status Lights
<::transcription of the content
: photo of status lights on a truck::>
Mounted on all sides of the truck to safely display truck operating status

### Road Edge Guidance (REG)
<::transcription of the content
: photo of a laser guidance system on a vehicle::>
A mounted laser guidance system measures the distance to the road berm to provide additional navigation accuracy

<a id='85446940-7441-4b28-9006-21d7b7917a32'></a>

<::A photograph of a large yellow Komatsu HD985 mining dump truck, with the number '259' visible on its side. The truck is annotated with blue lines and circles pointing to various locations, and a white oval highlights a sensor near the front left wheel. The background shows trees.: figure::>
<::A diagram illustrating an optical fiber gyro, depicted as a coiled optical fiber with an arrow indicating rotational movement. Accompanying text: Optical fiber gyro Senses changes in orientation using interference from light: diagram::>

<a id='b4f71240-c8aa-4594-966d-aabbc91a5adf'></a>

<::An image showing the front and top view of a yellow autonomous vehicle equipped with multiple sensor units, including what appear to be radar or LIDAR sensors mounted on the front and on an elevated platform. The vehicle has a rugged design. This image illustrates object avoidance sensor technologies.: figure::>
- **Object avoidance** (e.g., radar with 80m range, LIDAR with 20m range at sides and rear)
- These sensor technologies are still in their infancy
  - Overall they have been working effectively in dry, clear climates such as in Australia or the Atacama desert
  - They have much lower reliability in fog or rain, which has impeded adoption of AH technology in more temperate climates
  - In the next few years, some AH sensor manufacturers will likely turn to military sensors to improve availability and reliability; however, doing so is currently cost-prohibitive 

<a id='8cc44447-e491-4507-acca-0c9abead203c'></a>

SOURCE: Expert Interviews; University of British Columbia; Caterpillar; Komatsu

<a id='cfa16bed-d851-4d92-bf85-f9c0d12f21e1'></a>

McKinsey & Company

<a id='33efe5d4-d8e0-4470-9811-625da6121a3c'></a>

18

<!-- PAGE BREAK -->

<a id='54d420d6-0db2-4fd3-a204-9e09f317873f'></a>

Communications technology is vital for relaying commands from the control centre to the vehicles, and for managing vehicle interactions

<a id='a1909a88-211a-4dcc-a5ff-9a725cfb2807'></a>

## Communications technology

-   Open-pit communications tend to rely on **satellite/GPS, wi-fi and/ or RFID**
    -   This requires antennas / **boosters** around the site
    -   Each individual vehicle, and possibly personnel, must also be **tagged** (tele-remote and manned) with **positional trackers**, in order to minimize interactions with operational tele-remote vehicles (for reasons of safety and productivity)
-   System must have enough **bandwidth** to
    -   Relay **live video** feeds to the central control room
    -   Provide up-to-date tracking of all **vehicle locations**
    -   Convey **real-time commands** from the command centre to the tele-remote or autonomous systems

<a id='649114a3-cb06-452e-a8ec-8f2ff67e37e7'></a>

McKinsey & Company

<a id='5af6e28e-1781-44ab-9cb4-5f3cc4458992'></a>

19

<!-- PAGE BREAK -->

<a id='f29f0201-707e-434a-82af-feeb3a177408'></a>

**Autonomous haulage has multiple safety and efficiency benefits**

<a id='99775c39-3a1c-4d87-9451-6f0eb4b83b73'></a>

Favourable impact on economics
Adverse impact on economics

<a id='e7924a20-f231-406f-8baf-4bf303a14c4c'></a>

<table><thead><tr><th>Category</th><th>Lever</th><th>Impact range</th><th>Rationale for impact</th></tr></thead><tbody><tr><td>Safety</td><td>Safety</td><td><br>Green circle</td><td><ul><li>Fewer people in dangerous areas</li></ul></td></tr><tr><td>Mine design</td><td>Strip ratio</td><td><br>Green circle - 0-5%</td><td><ul><li>Fewer people in pit enables steeper pit walls and thus ability to reduce strip ratio</li></ul></td></tr><tr><td>OEE<sup>1</sup></td><td>Utilization</td><td><br>Green circle - 10-30%</td><td><ul><li>Eliminate shift-change delays; reduce delays due to traffic congestion</li></ul></td></tr><tr><td></td><td>Availability</td><td><br>Green circle - 10-30%</td><td><ul><li>Reduced unscheduled downtime from more consistent usage cycles and reduced damage</li></ul></td></tr><tr><td></td><td>Truck speeds</td><td><br>Green circle TBD</td><td><ul><li>Higher truck speeds as fewer people in mine areas; truck speeds more consistent</li></ul></td></tr><tr><td>Operating and maintenance costs</td><td>Labor</td><td><br>Green circle Up to -95%</td><td><ul><li>Fewer (or zero) operators</li></ul></td></tr><tr><td></td><td>Fuel</td><td><br>Green circle - 5-10%</td><td><ul><li>Lower fuel consumption from more consistent driving cycles</li></ul></td></tr><tr><td></td><td>Tires</td><td><br>Green circle - 5-10%</td><td><ul><li>Improved tire life due to more consistent speeds and driving patterns</li></ul></td></tr><tr><td></td><td>Maintenance</td><td><br>Green circle - 10-20%</td><td><ul><li>Lower maintenance parts and labour costs from reduced wear and accident damage</li></ul></td></tr><tr><td>Capex</td><td>Truck capex</td><td><br>Red circle ~500k autonomy kit</td><td><ul><li>Higher truck cost due to additional equipment and sensors on trucks</li></ul></td></tr><tr><td></td><td>Infrastructure capex</td><td><br>Red circle<ul><li>Hub ~$1m</li><li>Communications upgrade ~$15k</li></ul></td><td><ul><li>Infrastructure costs for communications infrastructure, refueling system</li></ul></td></tr></tbody></table>

"The main benefits are in operating labour costs (down about 2/3) and optimized productivity (avoiding downtime and operating at a faster and safer cycle time)"
- AH electrical systems specialist

"During our first trials, we were already able to reduce exposure of our workers to danger areas by ~70%"
- Mine manager

"Capex costs are high, though of course they also depend on the pre-existing level of infrastructure, like for communications. That said, the upside of AH is significant"
- AH developer

<a id='6e7b2779-2463-4700-8fd5-99bda7776db9'></a>

1 OEE: Overall Equipment Effectiveness

<a id='0ab5f3e6-9bf1-4142-a5b5-4cf943031180'></a>

SOURCE: Expert interviews; Press search

<a id='658fccdb-f74d-4f73-9857-54535bdecf8c'></a>

McKinsey & Company

<a id='5506f18b-3ed6-4f22-83fa-f10fe8590e66'></a>

20

<!-- PAGE BREAK -->

<a id='fc3c0e0e-ce81-4b52-91d4-ef3e45e3956e'></a>

AUTONOMOUS HAULAGE

<a id='0f846b02-866c-4db1-8bab-e8c24407b557'></a>

Autonomous haulage can be a game changer in mining
productivity: 10% to 40% reduction in haulage costs
Hauling costs – USD c/ton

<a id='fff6041f-7393-4031-a561-157d02f011d0'></a>

PRELIMINARY

<a id='90055770-037a-48b8-ae08-eb2363bf97d5'></a>

High labor cost locations, e.g. remote
Australian mines, Canadian oil sands
$350K fully loaded, operator cost

<a id='b8049587-5602-4ef0-a679-594a233e1190'></a>

Low labor cost locations, e.g. Africa, Asia
$35K fully loaded, operator cost

<a id='47cfb3a9-b4c9-43dd-91c2-74ad6b01149b'></a>

<::Table: Comparison of costs between Manual Fleet and Autonomous Fleet::>
| Category | Manual Fleet | Autonomous Fleet |
| :------------------------------ | :----------- | :--------------- |
| **Mine design** | **67.47** | **45.41** |
| Manual Fleet | 67.47 | 45.41 |
| Strip ratio | 0 | 0 |
| **OEE¹** | **62.93** | **43.74** |
| Availability | -0.72 | -0.27 |
| Utilization | -3.82 | -1.41 |
| Truck speeds | 0 | 0 |
| **Operating and maintenance costs** | **39.69** | **38.83** |
| Labor | -20.37 | -2.04 |
| Fuel | -1.72 | -1.72 |
| Tires | -0.50 | -0.50 |
| Maintenance | -0.64 | -0.64 |
| **Capex** | **40.74** | **39.88** |
| Truck | 0.96 | 0.96 |
| Infrastructure | 0.08 | 0.08 |
| Autonomous fleet | 40.74 (-40%) | 39.88 (-12%) |
<::/Table::>

Autonomous trucks can reduce surface haulage costs by up to 40%

<a id='8d90e734-362e-4db0-a49b-773cb53a8c9f'></a>

1 OEE: Overall Equipment Effectiveness

<a id='497166d5-a70e-4fea-a9a8-d2164226d8e2'></a>

SOURCE: Team analysis; based on client mine plan

<a id='1978ec49-b6ee-4c37-851b-6a007e09b461'></a>

McKinsey & Company | 21

<!-- PAGE BREAK -->

<a id='ddb86b2c-5e4f-497f-b747-b883f03560f3'></a>

To date, there have been ~25 autonomous haul truck
trials, most of which have taken place in Australia

<a id='9270f97a-7288-4b56-83a0-c1f48e692ccd'></a>

<::diagramDescription: A flag-shaped graphic containing two rectangular fields. The top field is labeled "Mine site". The bottom field contains "..." and is labeled "Year tests began".::>

<a id='d0b23489-cc6d-47ff-b7d4-8324f7efc36f'></a>

Current trial and/or implementation locations

<a id='369cc895-a63d-454b-9948-3f461fb25fd0'></a>

<::Logos:
- Orange dot: SANDVIK
- Blue dot: HITACHI Inspire the Next
- Light blue dot: CATERPILLAR
- Dark blue dot: KOMATSU
- Green dot: ASI
- Yellow dot: NB logo::>

<a id='023f8bd4-1a72-4ad4-8d00-98ea030d889d'></a>

<::A world map with North America and Europe visible. North America is mostly gray, but the contiguous United States and Alaska are highlighted in blue. In the southwestern USA, a green flag is labeled "Navajo Coal" with the year "2006". Below it, a logo reads "F-M". In the southeastern USA, a light blue flag is labeled "..." with the year "2006". Below it, a logo reads "bhpbilliton". In Europe, the map is gray, but Sweden is highlighted in blue. In northern Sweden, an orange flag is labeled "Kiruna" with the year "2010". Below it, a logo reads "LKAB".
: map::>

<a id='3c5f17cc-243c-427c-8dab-3199c50ba11a'></a>

<::A world map displaying various mining locations and their associated companies and years. The map is light grey, with Australia highlighted in dark blue. Mining locations are marked by flags of different colors connected to points on the map. The flags include: Kiruna (orange flag) in Northern Europe, 2010, with the LKAB logo. Finsch (orange flag) in Southern Africa, 2005, with the Petra Diamonds logo. In Australia, locations include: Yandi-coogina (dark blue flag), 2012, Rio Tinto. West Angelas (dark blue flag), 2010, Rio Tinto. Nam-muldi (dark blue flag), 2012, Rio Tinto. Hope Downs (dark blue flag), 2013, Rio Tinto. Meandu (dark blue flag), 2014, with the stanwell logo. Solomon (light blue flag), 2013, with the FMG Fortescue logo. Jimblebar (light blue flag), 2013, with the bhpbillitan logo. Two TBD (yellow flags), both 2015, with the bhpbillitan logo. These Australian locations are predominantly in Western Australia, with Meandu and one TBD location in Eastern Australia.: map::>

<a id='07184a70-3826-4d68-bd61-eec86ee6642e'></a>

<::Timeline visual on a map of South America. The map is light grey, with parts of Peru, Bolivia, Chile, and Argentina highlighted in blue. A vertical line connects two flag-shaped markers. The top marker, positioned over Peru/Bolivia, is dark blue and reads "Gabriela Mistral" with the year "2009" in a grey box. Below this text is a brown logo resembling a stylized 'C' or a mining cart, with the word "CODELCO" underneath. The bottom marker, positioned over Chile/Argentina, is also dark blue and reads "Radomiro Tomic" with the year "2005" in a grey box. Below this text is the same brown CODELCO logo and text.: figure::>

<a id='bcb54963-2329-46cd-8900-ee5d7ce7a58e'></a>

SOURCE: Press search

<a id='90b884f0-0de4-486e-a12b-8462680d2892'></a>

McKinsey & Company

<a id='508111e8-cc88-431b-ba47-003af6ddee53'></a>

22

<!-- PAGE BREAK -->

<a id='6de488c9-a181-44ce-aa1f-e2d787e60766'></a>

Automated drilling is the latest step in the long evolution of drill and blast technology

<a id='f0a199d3-f43f-47d0-99e7-64428f9f713f'></a>

<table id="23-1">
<tr><td id="23-2">Manual drilling and blasting</td><td id="23-3">The beginnings of mechanization</td><td id="23-4">Towards current-day drills</td><td id="23-5">Drill-assist and autonomous drills</td></tr>
<tr><td id="23-6">Gunpowder invented ~1000AD, but are no references to applications to mining until 16th century One man drilling (using a steel drill and sledgehammer) most common approach into the 20th century</td><td id="23-7">First steam driven percussion rock drills were invented in early- 1800s, but adoption slow Alfred Nobel invented the blasting cap and safer dynamite explosives through the 1860s However, mechanized drill productivity still low. In 1870, at a US drilling competition, John Henry hammered through 14 ft of rock in 35 minutes His steam drill &quot;competitor&quot; only managed 9 ft</td><td id="23-8">Late 1800s-early 1900s: steam replaced by compressed air, and invention of the jackhammer 1945: Sandvik, Atlas and Fagersta designed a cemented tungsten carbide drill bit as economical to use as the conventional steel bits Post-war, drill rig mechanization sped up, with a strong emphasis on increasing mobility Hydraulic technology for rotary and downhole drilling also became available in the 1960s</td><td id="23-9">Drive towards automated drills picked up momentum with unveiling of the Atlas Copco Pit Viper 351 with CAN-bus control and 7 on-board computers at MineEXPO 2000 Sandvik and Atlas Copco lead the pack, with automated drills (with various degrees of automation) being tested and implemented around the world</td></tr>
</table>

<a id='76ea5804-caf8-4a1b-ab86-b07f387bdd16'></a>

SOURCE: Atlas Copco Blasthole Reference Book 2013, Sandvik

<a id='046d4f7f-f0b7-47d4-b76c-59a5de510de1'></a>

McKinsey & Company

<a id='4bcca73b-9ca3-4048-ac37-73fca4a1f22d'></a>

23

<!-- PAGE BREAK -->

<a id='14e3f1e5-c1e6-4d3d-8675-42cc37602f23'></a>

Tele-Remote/Autonomous Drill

<a id='1d02efd1-5e78-4eaf-bf0a-ccdd94003517'></a>

<::image of a hazard avoidance camera mounted on a yellow/orange structure against a blue sky. Hazard avoidance cameras See depths details and determine hidden range of obstacles::>

<a id='d062ba53-c5fa-4843-ae88-a844970c4018'></a>

**High-resolution video**
Transmit video back to the command center
* Enhance visibility
* No blind spot

<a id='ef7b3a8f-961d-49c6-9803-d13642b04334'></a>

<::A large white and orange/yellow drilling rig, marked with "EDD0165", is positioned on a dirt or gravel surface under a clear blue sky. The rig has large tracks for mobility and an elevated operator cabin, which is highlighted by a white oval overlay. The drilling mast extends upwards from the main body of the rig.: figure::>

<a id='20b2d069-797f-42bb-b4f7-fa02e700addf'></a>

<::An image depicting a drilling rig on a sandy, barren landscape. Red lines crisscross the ground, forming a geo-fence around the rig. Numerous small red markers are scattered across the terrain within the fenced area. Two white circles with light blue outlines highlight specific points along the red geo-fence lines. To the right of the image, the text reads: Geo-fencing sensors Prevent tramming into hazards: figure::>

<a id='86021e3d-19b4-4735-99d3-88836c03a93d'></a>

High-speed on-board computer control
*   Geological information
*   Drilling times
*   Penetration rates
*   Navigation & traffic
*   Machine diagnostics
<::An illustration of a drilling rig, viewed from a slightly elevated angle. The rig is a large, complex piece of machinery with a tall mast, various platforms, and mechanical components. It appears to be situated on a barren, dark ground surface. Overlaid on the rig are glowing blue lines and a prominent glowing blue cube, suggesting digital monitoring, data flow, or sensor points on the equipment.
: illustration::>

<a id='f3cbce08-e4a7-4135-95fb-bcb11d25d75a'></a>

SOURCE: Sandvik

<a id='c315ef70-b763-4d48-8e89-891d6fddee5a'></a>

McKinsey & Company

<a id='db3b3120-5ab8-49ed-b793-bfbba07e4fc7'></a>

24

<!-- PAGE BREAK -->

<a id='64edf98d-3b87-4e17-92b9-6fc55b2a17d4'></a>

Tele-Remote and Autonomous drilling have significant potential

<a id='cebb31c6-762d-44a9-80f8-14c79af4ea6a'></a>

<::transcription of the content
: Favorable (thumbs up icon)
Adverse (thumbs down icon)::>

<a id='74292875-2be7-498e-85f9-f483e2f9b625'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3"></td><td id="25-4"></td><td id="25-5" colspan="2">Impact range</td><td id="25-6">(image of a gauge)</td></tr>
<tr><td id="25-7">Category</td><td id="25-8">Lever</td><td id="25-9">Impact</td><td id="25-a">Tele-remote</td><td id="25-b">Autonomous</td><td id="25-c">Rationale for impact</td></tr>
<tr><td id="25-d">Safety</td><td id="25-e">Safety</td><td id="25-f">(image of a thumbs up)</td><td id="25-g"></td><td id="25-h"></td><td id="25-i">▪ Fewer people in dangerous areas</td></tr>
<tr><td id="25-j" rowspan="4">OEE¹</td><td id="25-k">Availability</td><td id="25-l">(image of a thumbs up)</td><td id="25-m">0-10%</td><td id="25-n">0-15%</td><td id="25-o">▪ Reduced unscheduled downtime from more consistent usage cycles and reduced damage</td></tr>
<tr><td id="25-p">Utilization</td><td id="25-q">(image of a thumbs up)</td><td id="25-r">0-10%</td><td id="25-s">0-15%</td><td id="25-t">▪ Eliminate shift-change delays; reduce time lost to blast cycle</td></tr>
<tr><td id="25-u">Drill speeds</td><td id="25-v">(image of a thumbs up)</td><td id="25-w">0-3%</td><td id="25-x">0-3%</td><td id="25-y">▪ Algorithm reduces variation across fleet</td></tr>
<tr><td id="25-z">Redrilling and over-drilling</td><td id="25-A">(image of a thumbs up)</td><td id="25-B">50%</td><td id="25-C">75%</td><td id="25-D">▪ Algorithm controls drilling reduces chances of error</td></tr>
<tr><td id="25-E" rowspan="6">Operating and maintenance costs</td><td id="25-F">Drill rig labor</td><td id="25-G">(image of a thumbs up)</td><td id="25-H">Up to 75%</td><td id="25-I">Up to 95%</td><td id="25-J">▪ Operator:Machine ratio reduced to 1:3 for Tele-remote and 1:5 for autonomous</td></tr>
<tr><td id="25-K">Surveying labor</td><td id="25-L">(image of a thumbs up)</td><td id="25-M">100%</td><td id="25-N">100%</td><td id="25-O">▪ GPS positioning system eliminates need for floor demarcation tasks</td></tr>
<tr><td id="25-P">Fuel</td><td id="25-Q">(image of a thumbs up)</td><td id="25-R">0-5%</td><td id="25-S">0-10%</td><td id="25-T">▪ Lower consumption from more consistent operation</td></tr>
<tr><td id="25-U">Lubricants</td><td id="25-V">(Image of a green thumbs-up icon)</td><td id="25-W">0-5%</td><td id="25-X">0-10%</td><td id="25-Y">Lower consumption from more consistent operation</td></tr>
<tr><td id="25-Z">Drilling consumables</td><td id="25-10">(Image of a green thumbs-up icon)</td><td id="25-11">0-10%</td><td id="25-12">0-10%</td><td id="25-13">Lower consumption due to algorithm controlled, more consistent drilling operation</td></tr>
<tr><td id="25-14">Maintenance</td><td id="25-15">(Image of a green thumbs-up icon)</td><td id="25-16">0-10%</td><td id="25-17">0-20%</td><td id="25-18">Lower maintenance parts and labour costs from reduced wear due to more consistent operation</td></tr>
<tr><td id="25-19" rowspan="2">Capex</td><td id="25-1a">Drill rig capex</td><td id="25-1b">(Image of a red thumbs-down icon)</td><td id="25-1c">5-10%</td><td id="25-1d">15-20%</td><td id="25-1e">Higher drill costs due to additional equipment and sensors on drill</td></tr>
<tr><td id="25-1f">Infrastructure capex</td><td id="25-1g">(Image of a red thumbs-down icon)</td><td id="25-1h">~$0.5M</td><td id="25-1i">~$1M</td><td id="25-1j">Infrastructure costs for communications infrastructure, refueling system</td></tr>
</table>

<a id='c7e0abcb-79ac-471e-aebc-1532265b3f55'></a>

1 OEE: Overall Equipment Effectiveness

<a id='f570198c-2f3a-477b-ac5e-699de20fe589'></a>

SOURCE: Expert interviews; Press search

<a id='e394ba41-0223-4f0c-9d23-e1ce981433f7'></a>

McKinsey & Company

<a id='5f3affcd-a1f7-44dd-bac3-d4b53d74a330'></a>

25

<!-- PAGE BREAK -->

<a id='48fda08e-c4e0-4615-8496-3d4b6b7a256d'></a>

OEE improvements account for more than 50% of the productivity
gains with labor savings being the next largest contributor
Drilling costs – USD $/m

<a id='fced2a6d-7172-43bc-b951-c6758d81269d'></a>

PRELIMINARY

<a id='8786b47a-8dd3-4dda-92fe-209213c46d1e'></a>

## Tele-Remote Drilling Total Cost of Ownership
3 drilling rigs per operator

<a id='890244d2-0cf7-486d-ae4f-cb6ae50ebba1'></a>

**Autonomous drilling Total Cost of Ownership**
5 drilling rigs per operator

<a id='fb7489f2-c466-42b8-ade2-a31b539b041d'></a>

<::transcription of the content: chart::>Waterfall chart showing cost reductions from autonomous drills. The chart compares two scenarios, likely 'Current' (left) and 'Autonomous' (right) based on the reductions.

**Left Scenario (labeled -13% overall reduction):**
- **OEE¹**
  - Manual drilling: 9.76
  - Availability: -0.16
  - Utilization: -0.18
  - Drilling speed: -0.22
  - Redrilling and over-drilling: -0.20
  - Subtotal for OEE¹: 9.00
- **Operating and maintenance costs**
  - Drill rig labor: -0.41
  - Surveying labor: -0.24
  - Fuel: -0.05
  - Lubricant: -0.02
  - Drilling consumables: -0.08
  - Maintenance: -0.01
  - Subtotal for Operating and maintenance costs: 8.19
- **Capex**
  - Drill rig capex: 0.17
  - Infrastructure capex: 0.15
  - Subtotal for Capex: 8.52
- Overall Reduction: -13%

**Right Scenario (labeled -16% overall reduction):**
- **OEE¹**
  - Manual drilling: 9.76
  - Availability: -0.33
  - Utilization: -0.38
  - Drilling speed: -0.22
  - Redrilling and over-drilling: -0.30
  - Subtotal for OEE¹: 8.54
- **Operating and maintenance costs**
  - Drill rig labor: -0.49
  - Surveying labor: -0.24
  - Fuel: -0.10
  - Lubricant: -0.03
  - Drilling consumables: -0.08
  - Maintenance: -0.11
  - Subtotal for Operating and maintenance costs: 7.47
- **Capex**
  - Drill rig capex: 0.41
  - Infrastructure capex: 0.30
  - Subtotal for Capex: 8.18
- Overall Reduction: -16%
::>

In addition to increasing safety by removing personnel from dangerous locations, autonomous drills can reduce drilling costs by up to 15%

<a id='ae7f27ef-8678-4589-91e2-3c2165f311df'></a>

1 OEE: Overall Equipment Effectiveness

<a id='ae9a2de1-a471-4940-8c2e-22c98cd5e5b5'></a>

SOURCE: Team analysis; based on client mine plan

<a id='5028a41f-e442-4e60-a293-b8a87fa72189'></a>

McKinsey & Company | 26

<!-- PAGE BREAK -->

<a id='d753f137-8e29-4d81-ae02-1d88a2325136'></a>

ADVANCED TECHNOLOGIES EXAMPLE – TELE REMOTE AND AUTONOMOUS EQUIPMENT

**Tele-Remote and autonomous drilling scenario assumptions**

<a id='8fb51b99-212a-40aa-9fa9-24b181ce941d'></a>

<table id="27-1">
<tr><td id="27-2">Category</td><td id="27-3">Lever</td><td id="27-4">Units</td><td id="27-5">Manual</td><td id="27-6">Tele-remote</td><td id="27-7">Autonomous</td></tr>
<tr><td id="27-8" rowspan="5">OEE¹</td><td id="27-9">Availability</td><td id="27-a">%</td><td id="27-b">80%</td><td id="27-c">85%</td><td id="27-d">90%</td></tr>
<tr><td id="27-e">Utilization</td><td id="27-f">%</td><td id="27-g">77%</td><td id="27-h">82%</td><td id="27-i">87%</td></tr>
<tr><td id="27-j">Drill speed</td><td id="27-k">m/hr</td><td id="27-l">40</td><td id="27-m">41</td><td id="27-n">41</td></tr>
<tr><td id="27-o">Redrilling (short holes)</td><td id="27-p">%</td><td id="27-q">3%</td><td id="27-r">1.5%</td><td id="27-s">0.8%</td></tr>
<tr><td id="27-t">Over drilling (refill long holes)</td><td id="27-u">%</td><td id="27-v">4%</td><td id="27-w">2%</td><td id="27-x">1%</td></tr>
<tr><td id="27-y" rowspan="12">Operating and maintenance costs</td><td id="27-z">Drill rig operator</td><td id="27-A">FTE / shift</td><td id="27-B">1</td><td id="27-C">33%</td><td id="27-D">20%</td></tr>
<tr><td id="27-E">Drill rig operator salary</td><td id="27-F">$/yr</td><td id="27-G">50,000</td><td id="27-H">50,000</td><td id="27-I">50,000</td></tr>
<tr><td id="27-J">Number of shifts</td><td id="27-K">Shifts / day</td><td id="27-L">4</td><td id="27-M">4</td><td id="27-N">4</td></tr>
<tr><td id="27-O">Survey hours</td><td id="27-P">Hr/yr</td><td id="27-Q">4,000</td><td id="27-R">0</td><td id="27-S">0</td></tr>
<tr><td id="27-T">Surveyor rate</td><td id="27-U">$/hr</td><td id="27-V">20</td><td id="27-W">20</td><td id="27-X">20</td></tr>
<tr><td id="27-Y">Drilling consumables</td><td id="27-Z">$/meter</td><td id="27-10">2.5</td><td id="27-11">2.4</td><td id="27-12">2.4</td></tr>
<tr><td id="27-13">Fuel</td><td id="27-14">$/hr of operation</td><td id="27-15">118</td><td id="27-16">115</td><td id="27-17">112</td></tr>
<tr><td id="27-18">Lubricants</td><td id="27-19">$/hr of operation</td><td id="27-1a">41</td><td id="27-1b">40</td><td id="27-1c">39</td></tr>
<tr><td id="27-1d">Over drilled (long hole) fill cost</td><td id="27-1e">$/meter</td><td id="27-1f">5</td><td id="27-1g">5</td><td id="27-1h">5</td></tr>
<tr><td id="27-1i">Maintenance and overhaul parts</td><td id="27-1j">$/hr</td><td id="27-1k">72</td><td id="27-1l">68</td><td id="27-1m">61</td></tr>
<tr><td id="27-1n">Maintenance and overhaul labor</td><td id="27-1o">$/hr</td><td id="27-1p">50</td><td id="27-1q">48</td><td id="27-1r">43</td></tr>
<tr><td id="27-1s">Infrastructure/drill rig IT maintenance</td><td id="27-1t">$/yr</td><td id="27-1u"></td><td id="27-1v">31,000</td><td id="27-1w">62,000</td></tr>
<tr><td id="27-1x" rowspan="2">Capex (text on blue background)</td><td id="27-1y">Drill rig initial cost</td><td id="27-1z">$</td><td id="27-1A">5.2m</td><td id="27-1B">5.5m</td><td id="27-1C">6.0m</td></tr>
<tr><td id="27-1D">Infrastructure initial cost</td><td id="27-1E">$ (symbol)</td><td id="27-1F"></td><td id="27-1G">310,000</td><td id="27-1H">620,000</td></tr>
</table>
1 OEE: Overall Equipment Effectiveness

<a id='302b7fa8-22c4-484a-b391-67067f7ce27f'></a>

SOURCE: Expert interviews; Client Latin American Copper Mine parameters; Press search

<a id='d97a5876-80bd-460e-9c9f-b7f66f282a44'></a>

McKinsey & Company

<a id='67c2ab2b-63b9-4224-8d20-d054de215904'></a>

27

<!-- PAGE BREAK -->

<a id='6426740c-a70c-4fed-bcf1-7897828f3dde'></a>

Companies are planning for the future with technology
in mind and expect revenues to keep growing at ~4%p.a.

Revenues & EBITDA of the global mining industry
USD billion, real terms 2013

Revenues
EBITDA
Revenue CAGR (%)
Average industry
EBITDA margin (%)

<a id='63066697-aedf-4271-98f0-97d10a2ae1dc'></a>

<::line chart::>The chart displays data over time, with the X-axis representing years from '95 (likely 1995) to '25 (likely 2025), and the Y-axis representing values from 0 to 1,500. There are three lines plotted: a dark blue solid line, a light blue solid line, and a light blue dashed line. The dark blue solid line has several labels indicating annual percentage changes (p.a.): 0.8% p.a. from '95 to approximately '00; 24.5% p.a. from approximately '00 to '08; -5.1% p.a. from approximately '08 to '12; and 3.9% p.a. from approximately '12 to '25. Another label, 3.4% p.a., is associated with the light blue solid line, spanning from approximately '15 to '25. At the bottom of the chart, under the X-axis, there are blue oval shapes with values: '~25' under '95', '~25' under '05', '~40' under '10', '~30' under '15', and '~30' under '20' and '25'. The background features a faint, abstract image of a hand interacting with a digital grid or keyboard.<::

<a id='10709c4f-e24e-4a2a-832f-675a32331e94'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='b5ed41cb-cc04-41e8-ad5f-89cd3501443d'></a>

McKinsey & Company

<a id='1b835e4e-9e56-4155-ac52-7c12f9182834'></a>

28

<!-- PAGE BREAK -->

<a id='54aa9c7c-3722-4891-83b0-6d5a61cb198b'></a>

How are you positioning yourself for the future?

<a id='c050ffe3-e01e-40d9-bca2-301c3d25b9b1'></a>

> "I believe we need to hit the reset button in terms of how we think about innovation and mining in the future"

– *Mark Cutifani, CEO Anglo American*

<a id='c5ce23f2-3587-4a93-8ab6-537a2e92d34d'></a>

<::logo: Anglo American
AngloAmerican
The logo features a stylized, abstract triangular shape composed of concentric blue and red outlines, resembling a layered or spiraling design.::>

<a id='8f12aa71-64fb-4740-9ce0-fdd1337fb220'></a>

SOURCE: Press search

<a id='95add472-3988-4933-bcbe-649e6621bde4'></a>

McKinsey & Company

<a id='efc65bc8-8c8c-49fe-8a65-57f43e7052df'></a>

29

<!-- PAGE BREAK -->

<a id='e0873fef-0fb3-4d3e-87f7-79e202fd4846'></a>

Summary of the rare earth market outlook

<a id='f8c6cfa0-500e-4f05-9756-c148ce259c1b'></a>

* Rare earths are a group of 17 elements, which are divided into light and heavy rare earths. They are used in a wide range of applications, such as **permanent magnets, metal alloys, catalysts and polishing powders**
* The market is large and growing ($8B and ~113 ktons of demand after separation of individual oxides, growing at a 7% CAGR), with heavy rare earths representing <15% of the volume, but ~50% of revenues
* China holds most of the production along the value chain (~80-100%), as well as most of the known reserves, letting it control prices through management of **export quotas**
* Outside of China, most projects are **focused on light rare earths**
  * Rare earths expected to be critical are mainly heavies (Dysprosium, Yttrium, Terbium and Europium), together with the light element neodymium
  * The pipeline of heavy rare earth projects is limited to less than 10k tons and they are at **very early stages of development**
* If China continues to act rationally (and from expert interviews it seems that it will maintain quotas for heavy rare earths at present levels) **prices should continue at greenfield incentive levels**, allowing some penetration from the rest of the world
* Based on this, a mine that is “heavy on heavies” would find itself in a privileged position

<a id='b2e19854-9fec-4823-8f97-493a436b7b13'></a>

McKinsey & Company

<a id='1e9071e4-1571-46ea-8cec-d8e21eb3fe90'></a>

30

<!-- PAGE BREAK -->

<a id='46b74c8a-8261-48db-b2fc-68aa658e7a4e'></a>

RE are essential in the manufacturing of several products, used every day,which has led to a rapid increase in their demand

<a id='36a795f4-02f8-4766-bfda-c04a935bc3b9'></a>

NOT EXHAUSTIVE

<a id='fa0422fd-27bb-4897-957f-adb4eefc9dc5'></a>

# Applications of Light RE Elements

<::transcription of the content
: figure::>

## Lanthanum
*   Used in electric and hybrid vehicles, laptop computers, cameras, high-end camera lenses, telescopes, binoculars – as lanthanum improves visual clarity;
*   Used to reduce the level of phosphates in patients with kidney disease

<a id='0be078e3-460e-4dca-a041-03f479be52c4'></a>

<::image of a bar magnet with magnetic field lines around it, showing the field originating from one end (red) and curving around to the other end (silver) with arrows indicating direction: diagram::>
Samarium
- Primary use is in the production of permanent magnets but also in X-ray lasers
- Precision guided weapons and white-noise production in stealth technology

<a id='6cb21d4b-543d-46f7-958c-4df9ac0d3dd0'></a>

<::image: Two stacks of small, circular, silver-colored neodymium magnets.::>Neodymium- The principal use is in the manufacture of the strongest magnets in the world. These magnets are so strong that one the size of a coin cannot be removed from a refrigerator by hand- Other important applications include laser range finders and guidance systems

<a id='e1f0ca05-dc74-49d7-acff-78211fe061fd'></a>

<::An image of a translucent, iridescent glass sphere or marble, reflecting multiple colors like green, blue, purple, and yellow. It appears to be resting on a surface with its reflection visible.: image::>
Cerium
• Used to polish glass, metal and gemstones, computer
  chips, transistors and other electronic components
• Automotive catalytic converters to reduce pollution
• Added in glass making process to decolorize it, gives
  compact fluorescent bulbs the green part of the light
  spectrum

<a id='6e0147a5-8acb-4cf2-b208-df53527cb7cf'></a>

Applications of Heavy RE Elements

<a id='0ccdde28-d8ce-4643-91db-068f162ecc63'></a>

<::transcription of the content
iPod nano
: figure::>

# Dysprosium

* Most commonly used in the manufacture of neodymium-iron-boron high strength permanent magnets
* Injected into joints to treat rheumatoid arthritis
* Used in radiation badges to detect and monitor radiation exposure

<a id='aef858dd-4562-40b5-9033-5ddb3c94f3f9'></a>

Yttrium
<::Image of a rocket launching with fire and smoke
: figure::>
* Used in energy efficient fluorescent lamps and bulbs
* Used in high temperature applications, such as thermal barrier coating to protect aerospace high temperature surfaces
* Can increase the strength of metallic alloys

<a id='da73de01-b174-4395-9e92-3bdfe6125d64'></a>

<::transcription of the content
: illustration::>

## Gadolinium

*   Used to enhance the clarity of MRI scans by injecting Gadolinium contrast agents into the patient
*   Used in nuclear reactor control rods to control the fission process

<a id='71cae8f4-60f3-4a2f-96cd-756435aecd07'></a>

## Europium

*   Primarily used in phosphors used in pilot display screens, televisions and energy efficient fluorescent lights

<a id='32b2fbb2-eadd-479e-be63-96c5d82de731'></a>

SOURCE: IAMGOLD Report, General Web, team

<a id='c293ee2b-9f48-421f-9986-0bd8412cf6d2'></a>

McKinsey & Company

<a id='b1a8f2db-40ff-4489-ab50-153aea284cd2'></a>

31

<!-- PAGE BREAK -->

<a id='0e58f25f-6cdb-4b0f-8320-ffa9cced54bb'></a>

Increasing demand for RE has led to other countries looking
for potential reserves to reduce their dependency on China
Million metric tons

<a id='004821dd-cc07-4850-a142-17654173d42e'></a>

Rare Earth Reserves¹<::World map illustrating rare earth reserves by region:
- USA & Canada: 14
  - Associated text for USA:
    - Was self-reliant
    - Currently imports 100%
    - Mainly due to lower costs
    - Molycorp owns biggest deposit in USA
- China: 55
  - Associated text for China:
    - Holds 50% of reserves
    - Controls 90% of the supply
- India: 3.1
- Australia: 1.6
- RoW (Rest of World): 22
- Japan:
  - Associated text for Japan:
    - 100% importer
    - Have recently found 80-100 mn metric tons of REE in the Pacific seabed
: map::>

<a id='59d04da9-1e96-4cde-bf76-f0d455559345'></a>

a
1
<::A map showing parts of Asia and Australia. A blue circle is placed over India.
: map::>

<a id='26f5503d-3c61-4b1f-b7df-112fec3d1648'></a>

With the development of new projects, it is expected that this
scenario, with China being the dominant player ,will also change

<a id='c363e733-beea-4810-b85c-95cbdca7be96'></a>

1 Referring only to the identified RE reserves

<a id='287d9a8e-0b07-46a6-8b5f-fb319d660f3d'></a>

SOURCE: USGS, General web and press

<a id='60d7cd06-d68b-4b84-81e4-b19cdc3fa57b'></a>

McKinsey & Company

<a id='0c1afafc-1955-403e-ac9d-80c62a128a8e'></a>

32

<!-- PAGE BREAK -->

<a id='7b541117-dd50-43d4-94ea-fcf216c9e7ee'></a>

SUPPLY

There is a number of projects in the pipeline,
but most focus on light rare earths

<a id='39029e78-b51d-4a1a-98c2-5c2575576ad3'></a>

<::legend
- Green square: HRE
- Red square: LRE
- Dark blue circle: High
- Light blue circle: Low
: legend::>

<a id='b6872c8b-60dd-4b22-855f-ce85ac2bfcbd'></a>

NOT EXHAUSTIVE

<a id='d09366f6-cd63-4bb3-b7fa-a536f74a8498'></a>

Company Project Resource TREO Mt Capacity TREO tpa HRE share % Status Likelihood
<::Canadian flag: flag::> IAMGOLD Niobec 7.70 139,597 1.76 Scoping <::Likelihood indicator: a light blue circle with a small dark blue segment: chart::>
<::Greenland flag: flag::> Greenland Minerals and Energy Kvanefjeld 6.55 51,900 11.80 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Avalon Rare Metals Nechalacho 5.64 8,504 13.84 Feasibility <::Likelihood indicator: a light blue circle with a dark blue half: chart::>
<::Canadian flag: flag::> Commerce Resources Eldor 4.69 50,743 4.04 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Tanzanian flag: flag::> Peak Resources Ngualla 3.82 93,519 1.99 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Geomega Resources Montviel 3.65 105,903 1.71 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Greenland flag: flag::> Greenland Minerals and Energy Sørensen 2.66 N/A 11.72 TBD <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Quest Rare Minerals Strange Lake 2.10 10,652 39.03 Pre-feasibility <::Likelihood indicator: a light blue circle with a dark blue segment: chart::>
<::USA flag: flag::> Molycorp Mountain Pass 2.07 40,301 0.60 Pre-production <::Likelihood indicator: a dark blue circle: chart::>
<::Australian flag: flag::> Lynas Corporation Mount Weld CLD 1.45 22,165 2.85 Pre-production <::Likelihood indicator: a dark blue circle: chart::>
<::Australian flag: flag::> Arafura Resources Nolans Bore 1.24 19,298 3.34 Pre-feasibility <::Likelihood indicator: a light blue circle with a dark blue segment: chart::>
<::Brazilian flag: flag::> MBAC Fertilizer Araxá 1.19 13,154 2.67 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>

<a id='f5e50b0d-65b5-4374-914b-2da298f6d817'></a>

SOURCE: Technology Metals research, expert interviews, companies' reports, press

<a id='a58ea460-e805-4a89-8bb7-75bbbc465739'></a>

McKinsey & Company

<a id='dcb00ef2-caf0-41b2-ad01-69242db9a33a'></a>

33

<!-- PAGE BREAK -->

<a id='515f546d-492d-4787-ac46-c1c15cdae72a'></a>

However, exploration successes are becoming expensive and scarce
10 year period 2003-12

<a id='02b09f97-2e1e-415a-b5ad-bfdbb7f40e69'></a>

<::chart::>Spending, USD Billions | World-class/Other Discoveries
---|---
Lat America | 28 | 15 | 103 | 118
Canada | 22 | 49 | 16 | 65
China + CIS | 22 | 66 | 11 | 77
Africa | 17 | 19 | 97 | 116
Australia | 12 | 13 | 70 | 83
USA | 9 | 9 | 11 | 20
SE Asia/Pacific | 6 | 2 | 21 | 23
W Europe | 3 | 1 | 21 | 22
GLOBAL | 116 | 86 | 438 | 524
NEEDED | 140 | 125 | 625 | 750

- Across all major regions, world-class discoveries cost over 1 billion USD
- Africa and the USA were the most "effective" regions
- Gold deposits still account for nearly half of all discoveries
- .. But only finding 2/3 of the deposits we need<::>


<a id='d68a7904-4f4f-4ffa-baf0-539218ebe1ff'></a>

SOURCE: McKinsey BMI; MinEx Consulting

<a id='a460fc12-50cf-417b-9f5c-db3f759cf710'></a>

McKinsey & Company | 34

<!-- PAGE BREAK -->

<a id='18b0973b-fa1e-477d-8dcf-673f5d782d66'></a>

New and current mining projects will be face strong market forces, which
will have significant impact on the industry over coming decades

<a id='737f793c-243f-40e2-9d61-10c87799f4d2'></a>

1. Continuously increasing safety, health and environment standards
2. High demand and prices but significant volatility
3. Increasingly challenging geologies
4. Polarization of scale creates new challenges
5. Increasingly challenging supply chains
6. Rising energy costs
7. Rising water costs
8. Scarcity of talent
9. Global sourcing

<a id='264e065d-578c-4b4d-8117-392440c45361'></a>

SOURCE: McKinsey analysis

<a id='d8e244ba-0129-420c-8770-16f2ec2f2c6e'></a>

McKinsey & Company

<a id='219008cc-03f0-4552-8f3f-8cc0582a9ed6'></a>

35

<!-- PAGE BREAK -->

<a id='291c288c-59d2-4b39-97d9-a96252b2314f'></a>

PRICING

<a id='091dc783-84e6-4048-a1f8-f1bc6dd95210'></a>

Going forward, a greenfield incentive price scheme is expected for heavy elements and neodymium1

--- Deutsche Bank | ESTIMATES

<a id='953743a7-f4ca-482b-a7fc-5ff9785b82d7'></a>

Historical and future price estimates
Dollars per kg

<::chart: Line charts showing historical and future price estimates for Yttrium, Dysprosium, Terbium, Neodymium, and Europium. The charts share a common x-axis representing years from 2002 to 2017. Two lines are plotted for each element: CIBC (dashed line) and McKinsey greenfield incentive (solid line).::>

Yttrium
<::chart:
Y-axis: 0, 50, 100, 150 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 67 in 2017.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 89 in 2017.
:chart::>
*   Should be in a greenfield
    incentive regime in the short-
    medium term, until some of
    the new capacity eases the
    supply/demand tightness

Dysprosium
<::chart:
Y-axis: 0, 500, 1000, 1500 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 605 in 2017, with an intermediate value of 688.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 1019 in 2017.
:chart::>
*   Expected to remain in
    greenfield incentive for the
    foreseeable future, with
    eventual fly-ups depending on
    China's export policies

Terbium
<::chart:
Y-axis: 0, 1000, 2000, 3000 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 865 in 2017.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 1144 in 2017, with an intermediate value of 1056.
:chart::>
*   Should be in a greenfield
    incentive regime in the short-
    medium term, until some of
    the new capacity eases the
    supply/demand tightness

Neodymium
<::chart:
Y-axis: 0, 100, 200, 300 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 67 in 2017, with an intermediate value of 77.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 93 in 2017.
:chart::>
*   Tightness to be eased with
    volumes from Lynas and
    Molycorp
*   Should be back to
    greenfield/fly-up in longer term

Europium
<::chart:
Y-axis: 0, 1000, 2000, 3000 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 1022 in 2017.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 1269 in 2017, with an intermediate value of 1393.
:chart::>
*   Expected to remain in
    shortage in the foreseeable
    future, with demand growth
    out-spacing supply additions

1 Assuming that China will put maximum
2002 03 04 05 06 07 08 09 10 11 12 13 14 15 16 2017

<a id='269463cb-d271-4e9f-b422-fa65d64052f2'></a>

SOURCE: Analyst reports, team analysis

<a id='db3796fc-1a41-439e-bf3c-049a0beb8a83'></a>

McKinsey & Company | 36

<!-- PAGE BREAK -->

<a id='02b9ad9e-61ea-4404-bf7d-d01df48a08af'></a>

GLOBAL SUPPLY-DEMAND BALANCE

<a id='1fa55c53-3a25-4321-a188-95e2dc41e338'></a>

Mines holding considerable quantities of these five elements will be in a good position in the future

<a id='41e7b934-1b93-437d-9306-4ec3593462ff'></a>

**Y**
* Yttrium is expected to be in shortage in the short term, with most of the new supply only coming online through the end of the decade
* Expert opinions: "I don't see relevant new capacity outside of China coming online in the next few years"

**Dy**
* Dysprosium is expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
* Severe shortage could trigger investments in magnet recycling technology or even partial substitution/decrease in intensities

**Tb**
* Slower demand growth for Terbium when compared to Dysprosium and Yttrium could lead to a balanced market already in the short term
* Given the relatively low volume of the global terbium market, small amounts as by-product from large light-focused projects such as Mountain Pass and Mount Weld could ease the tightness

**Nd**
* Relevant volumes of Neodymium coming from Mountain Pass and Mount Weld in the short term should ease the tight supply-demand balance
* In the longer term, new projects will probably be needed to meet Nd demand

**Eu**
* Europium is expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
* Severe shortage could trigger investments in phosphors recycling, such as the research conducted by Rhodia in France in the last few years

<a id='0d0f2b11-36fb-4e0f-9cab-7e95dd2795c6'></a>

SOURCE: Expert interviews, McKinsey

<a id='76a8f722-4fc2-4002-a95e-832eeaf63652'></a>

McKinsey & Company

<a id='9270d5b5-7992-443f-95be-1177021ff78b'></a>

37

<!-- PAGE BREAK -->

<a id='fce11cc8-9a95-4f12-a5f3-06f00f185897'></a>

SUPPLY
With this relevant position, China controls the current price dynamic

<a id='f2f7907f-cac0-40c3-b1fc-619aa0a5710a'></a>

<::chart: Export quota evolution of rare earth in China
Y-axis: Thousand tons
Bars:
  2006: 62
  2007: 60
  2008: 47
  2009: 50
  2010: 30
  2011: 30
  2012: 31
Annotation: -40% decrease between 2009 and 2012 values
:chart::>
<::chart: Prices of dysprosium oxide in China
Y-axis: $/kg (values: 0, 500, 1000, 1500, 2000)
X-axis: Years (2006, 07, 08, 09, 10, 11, 2012)
Line data: Prices were low from 2006-2009, then increased sharply in 2010 and peaked near 2000 in 2011, then dropped to 800 in 2012.
Annotations:
  - Peak of prices caused by export quotas reduction (pointing to the 2011 peak)
  - Drop in 2012 as a result of demand decrease due to unsustainably high prices, but still significantly higher than historical levels (pointing to the 2012 value of 800)
:chart::>

<a id='c5829b66-a183-4499-b83e-9ef5615d6d6f'></a>

- In 2010, China tightened export quotas for heavy and light rare earths; in the future:
  - Light quotas could be eliminated as new light REO sources are coming online
  - Heavy quotas should remain as China does not have enough reserves and few new heavy rare earth sources are coming online in the future
- If China acts rationally, it will look to maximize profits which would maintain prices at higher than historical levels letting smaller players into the market. However they hold the power to avoid the entry of other players if they wanted to.

<a id='fb5bd7e8-2d7e-4ef9-a353-8f999c053685'></a>

SOURCE: MOFCOM, Press search

<a id='21e2e85b-841c-4d55-bee6-ec6b17b6e250'></a>

McKinsey & Company

<a id='66f2f4c4-d881-4662-b68d-2a4912af290b'></a>

38

<!-- PAGE BREAK -->

<a id='999096c6-719b-4cd4-9370-68ba8455f303'></a>

This has resulted in companies looking for different
avenues to meet their growing requirements;
for which substitution seems best suited

<a id='97c45f23-0fa8-4a67-bc0e-fa6519620a7d'></a>

<::logo: Unknown
Fuller the moon, more viable
A blue and light blue circle is split down the middle with a shadow beneath it::>

<a id='69de1377-1d2b-4209-961f-d8c9ba4175fb'></a>

Best way forward

<a id='cd63d019-18f9-4643-9c23-6731ab6dc29c'></a>

3 best measures to adopt to avoid falling into supply shortage problems

Reduction in the usage of RE is a process that is not yet economically tested by many companies

Some areas where this has come useful is in LED television sets, which require lesser RE than LCD sets

Recently, generator manufacturers have reduced RE content and have used other metals like nickel, which provides similar levels of performance

RE used in fluorescent lighting and computer hard drives, can be recycled

Extract RE from used hybrid motors and lithium-ion batteries in addition to nickel-metal hydride batteries

Benefits of recycling RE from batteries is that a supply of recycled lanthanum should be more reliable than relying on new Chinese sources

Recycling also uses less energy and emits less carbon di than mining

<a id='86f2feac-0497-4915-95e1-6e39d0686dcb'></a>

<::A box with a dashed blue border contains text and two icons. On the left, a circular icon with a red left-pointing arrow and a green right-pointing arrow. On the right, a pie chart icon, mostly blue with a small light blue segment, is placed next to the text describing a 5% efficiency improvement. The text inside the box reads: Motor companies are looking towards creating new techniques to substitute RE, like induction motors and nickel-hydride batteries. Some companies have also substituted RE with iron based amorphous core for motors which is 5% more efficient. Companies who are taking the initiative towards substitution are Hitachi, Ford, Continental AG and Honda.
: figure::>

<a id='ca062467-0ff7-4c20-8a55-e5de6da2714c'></a>

SOURCE: General web and press, team

<a id='7f6aac3d-a982-4eb6-9cbb-20e61934e384'></a>

McKinsey & Company

<a id='4bbb13d1-c39d-49dd-b191-19b494820c7a'></a>

39

<!-- PAGE BREAK -->

<a id='3cc56cb3-edc9-4aed-94af-fa64b0deb3cb'></a>

SUPPLY
In the rest of the world the pipeline of heavy projects is limited to less than
10k tons

<a id='97b50357-6b90-441b-8a16-1f1a6518f6df'></a>

<::Projects in the pipeline by type. Percent, number of projects, TREO ktpa. The chart displays two stacked bar charts. The first bar, labeled "# of projects," represents 45 total projects (100%). It is divided into "Heavy¹" at 33% and "Light" at 67%. The second bar, labeled "Projected production," represents 112 thousand tons. It is divided into a heavy-focused portion at 7% and a light-focused portion at 93%. A callout box states: "Total production from heavy-focused projects expected to account for only ~7k tons of additional production (55% of current supply)".: chart::>

<a id='000ea191-e670-468c-a759-a9d71d0806dd'></a>

1 Heavy rare earths projects are the ones with more than 15% of total rare earth content of heavy elements

<a id='639400d0-b257-4a9b-974e-694b245c60e2'></a>

SOURCE: Technology Metals Research, expert interviews, companies' reports, press

<a id='27e9ed61-d282-4e3f-836d-2f723925ddc4'></a>

McKinsey & Company

<a id='0fee1a48-a335-46c9-8a7d-ad4b698b66df'></a>

40