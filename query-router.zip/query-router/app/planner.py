"""LLM-based query planner.

Sends the user question + available sources/skills to an LLM and gets back
a structured ExecutionPlan (JSON).
"""

from __future__ import annotations

import json
import logging

import anthropic

from app.config import settings
from app.models import ExecutionPlan
from app.skill_registry import registry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

PLANNER_SYSTEM_PROMPT = """\
You are a query planner for a financial services platform.

You have access to three kinds of data sources:

1. **structured** — A chatbot API over structured data: deals, clients,
   interactions, revenue, expenses, wallet. Use this for quantitative
   questions, metrics, lookups by entity, aggregations, timelines,
   and anything answerable from a database.

2. **unstructured** — A chatbot API over document corpora: IPO prospectuses,
   M&A agreements, BizDev proposals, Debt term sheets, board decks, and
   other deal-related documents. Use this for questions about what a
   document says, clause interpretation, risk factors, disclosure language,
   and summarisation of filings.

3. **skills** — Registered executable scripts. Each skill has a name,
   description, trigger condition, and parameters. Use a skill when the
   user's request matches a skill's trigger (e.g., generating a report,
   running an analysis script, exporting data).

## Available Skills
{skills_block}

## Your Task

Given a user question, produce a JSON execution plan.

### Rules
- Decompose compound questions into independent sub-questions.
- Tag each sub-question with the correct source.
- If a step depends on another step's output, set `depends_on` to that step's `step_id`.
- Independent steps should have empty `depends_on` so they can run in parallel.
- When unsure which source to use, route to BOTH structured and unstructured
  as parallel steps — the synthesizer will reconcile.
- For skill steps, include `skill_name` and any required `parameters`.
- Step IDs are sequential integers starting at 1.

### Output Format (JSON only, no markdown fences)
{{
  "reasoning": "brief chain-of-thought explaining your routing decisions",
  "steps": [
    {{
      "step_id": 1,
      "description": "what this step answers",
      "source": "structured | unstructured | skill",
      "skill_name": null,
      "query": "the sub-question or command to send to this source",
      "depends_on": [],
      "parameters": {{}}
    }}
  ]
}}
"""

# ---------------------------------------------------------------------------
# Few-shot examples
# ---------------------------------------------------------------------------

FEW_SHOT_EXAMPLES = [
    # 1 — Simple structured
    {
        "role": "user",
        "content": "What is Acme Corp's total revenue for Q3 2025?",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "reasoning": "Single quantitative question about revenue — structured source.",
                "steps": [
                    {
                        "step_id": 1,
                        "description": "Look up Acme Corp Q3 2025 revenue",
                        "source": "structured",
                        "skill_name": None,
                        "query": "What is Acme Corp's total revenue for Q3 2025?",
                        "depends_on": [],
                        "parameters": {},
                    }
                ],
            }
        ),
    },
    # 2 — Simple unstructured
    {
        "role": "user",
        "content": "What does the Acme Corp merger agreement say about the earnout provisions?",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "reasoning": "Document content question — unstructured source.",
                "steps": [
                    {
                        "step_id": 1,
                        "description": "Find earnout provisions in Acme Corp merger agreement",
                        "source": "unstructured",
                        "skill_name": None,
                        "query": "What does the Acme Corp merger agreement say about the earnout provisions?",
                        "depends_on": [],
                        "parameters": {},
                    }
                ],
            }
        ),
    },
    # 3 — Parallel (both sources, independent)
    {
        "role": "user",
        "content": "What was Acme Corp revenue last quarter and what does their merger agreement say about earnouts?",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "reasoning": "Two independent sub-questions: revenue (structured) and merger clause (unstructured). Run in parallel.",
                "steps": [
                    {
                        "step_id": 1,
                        "description": "Look up Acme Corp revenue last quarter",
                        "source": "structured",
                        "skill_name": None,
                        "query": "What was Acme Corp's revenue last quarter?",
                        "depends_on": [],
                        "parameters": {},
                    },
                    {
                        "step_id": 2,
                        "description": "Find earnout provisions in Acme merger agreement",
                        "source": "unstructured",
                        "skill_name": None,
                        "query": "What does the Acme Corp merger agreement say about earnouts?",
                        "depends_on": [],
                        "parameters": {},
                    },
                ],
            }
        ),
    },
    # 4 — Sequential (structured → unstructured)
    {
        "role": "user",
        "content": "Show me all deals over $50M where the merger agreement had a material adverse change clause.",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "reasoning": "First filter deals by size (structured), then inspect each deal's merger agreement for MAC clause (unstructured). Sequential dependency.",
                "steps": [
                    {
                        "step_id": 1,
                        "description": "Find all deals with value over $50M",
                        "source": "structured",
                        "skill_name": None,
                        "query": "List all deals with deal value over $50M. Return deal IDs and names.",
                        "depends_on": [],
                        "parameters": {},
                    },
                    {
                        "step_id": 2,
                        "description": "Check merger agreements for MAC clauses",
                        "source": "unstructured",
                        "skill_name": None,
                        "query": "For the following deals: {step_1_results}, check each merger agreement for material adverse change (MAC) clauses. Summarize findings per deal.",
                        "depends_on": [1],
                        "parameters": {},
                    },
                ],
            }
        ),
    },
    # 5 — Skill invocation
    {
        "role": "user",
        "content": "Generate a PDF report for the Globex acquisition deal.",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "reasoning": "User wants a formatted report — matches the generate_report skill. Need deal data first from structured source.",
                "steps": [
                    {
                        "step_id": 1,
                        "description": "Fetch Globex acquisition deal data",
                        "source": "structured",
                        "skill_name": None,
                        "query": "Get full deal details for the Globex acquisition deal.",
                        "depends_on": [],
                        "parameters": {},
                    },
                    {
                        "step_id": 2,
                        "description": "Generate PDF report from deal data",
                        "source": "skill",
                        "skill_name": "generate_report",
                        "query": "Generate a PDF report for the Globex acquisition.",
                        "depends_on": [1],
                        "parameters": {"deal_id": "globex_acq", "format": "pdf"},
                    },
                ],
            }
        ),
    },
]


# ---------------------------------------------------------------------------
# Planner class
# ---------------------------------------------------------------------------

class Planner:
    def __init__(self) -> None:
        self._client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)

    async def plan(self, question: str) -> ExecutionPlan:
        """Decompose *question* into an ExecutionPlan."""

        skills_block = registry.summary_for_planner()
        system = PLANNER_SYSTEM_PROMPT.format(skills_block=skills_block)

        messages = [
            *FEW_SHOT_EXAMPLES,
            {"role": "user", "content": question},
        ]

        response = await self._client.messages.create(
            model=settings.planner_model,
            max_tokens=2048,
            system=system,
            messages=messages,
            temperature=0,
        )

        raw = response.content[0].text.strip()
        # Strip markdown fences if the model adds them
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1]
        if raw.endswith("```"):
            raw = raw.rsplit("```", 1)[0]

        try:
            plan_data = json.loads(raw)
        except json.JSONDecodeError:
            logger.error("Planner returned invalid JSON: %s", raw)
            raise ValueError(f"Planner produced invalid JSON:\n{raw}")

        return ExecutionPlan(
            original_question=question,
            reasoning=plan_data.get("reasoning", ""),
            steps=plan_data["steps"],
        )
