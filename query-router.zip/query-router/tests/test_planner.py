"""Tests for planner and skill registry (run with pytest)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.models import SkillManifest
from app.skill_registry import SkillRegistry, _parse_skill_md


# ---------------------------------------------------------------------------
# Skill registry tests
# ---------------------------------------------------------------------------

SAMPLE_SKILL_MD = """\
---
name: test_skill
description: A test skill for unit tests
trigger: when user says test
parameters:
  - name: input_text
    type: string
    required: true
    description: The text to process
  - name: verbose
    type: boolean
    required: false
    default: false
    description: Enable verbose output
---

# Test Skill

This is the body of the skill.
"""


def test_parse_skill_md(tmp_path: Path):
    skill_file = tmp_path / "SKILL.md"
    skill_file.write_text(SAMPLE_SKILL_MD)

    manifest = _parse_skill_md(skill_file)

    assert manifest is not None
    assert manifest.name == "test_skill"
    assert manifest.description == "A test skill for unit tests"
    assert manifest.trigger == "when user says test"
    assert len(manifest.parameters) == 2
    assert manifest.parameters[0].name == "input_text"
    assert manifest.parameters[0].required is True
    assert manifest.parameters[1].default is False


def test_parse_skill_md_missing_frontmatter(tmp_path: Path):
    skill_file = tmp_path / "SKILL.md"
    skill_file.write_text("# No frontmatter here\nJust body text.")

    manifest = _parse_skill_md(skill_file)
    assert manifest is None


def test_registry_discovery(tmp_path: Path):
    # Create two skills
    for name in ["skill_a", "skill_b"]:
        folder = tmp_path / name
        folder.mkdir()
        (folder / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: {name} desc\n---\n# {name}\n"
        )

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)

    assert len(reg.list_all()) == 2
    assert reg.get("skill_a") is not None
    assert reg.get("skill_b") is not None
    assert reg.get("nonexistent") is None


def test_registry_summary(tmp_path: Path):
    folder = tmp_path / "my_skill"
    folder.mkdir()
    (folder / "SKILL.md").write_text(SAMPLE_SKILL_MD)

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)

    summary = reg.summary_for_planner()
    assert "skill:test_skill" in summary
    assert "input_text" in summary


# ---------------------------------------------------------------------------
# Plan structure tests (no LLM call — just validate models)
# ---------------------------------------------------------------------------

def test_execution_plan_roundtrip():
    """Verify that a plan dict round-trips through the model."""
    from app.models import ExecutionPlan

    plan_dict = {
        "original_question": "test question",
        "reasoning": "test reasoning",
        "steps": [
            {
                "step_id": 1,
                "description": "fetch data",
                "source": "structured",
                "skill_name": None,
                "query": "get data",
                "depends_on": [],
                "parameters": {},
            },
            {
                "step_id": 2,
                "description": "search docs",
                "source": "unstructured",
                "skill_name": None,
                "query": "find clause about {step_1_results}",
                "depends_on": [1],
                "parameters": {},
            },
        ],
    }

    plan = ExecutionPlan(**plan_dict)
    assert len(plan.steps) == 2
    assert plan.steps[1].depends_on == [1]
    assert plan.steps[0].source.value == "structured"
