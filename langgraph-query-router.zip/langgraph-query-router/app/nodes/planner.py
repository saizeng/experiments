"""Planner node: LLM-based query decomposition.

Takes the user question from state, calls an LLM with the skill registry,
and writes plan_steps + reasoning back to state.
"""

from __future__ import annotations

import json
import logging

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from app.config import settings
from app.skill_registry import registry
from app.state import PlanStep, RouterState

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

PLANNER_SYSTEM = """\
You are a query planner for a financial services platform.

You have access to a set of **skills** — executable scripts that each do one
thing well. Every data source, search engine, and tool is wrapped as a skill.
Your job is to decompose the user's question into steps and route each step
to the right skill.

## Available Skills
{skills_block}

## Rules
- Decompose compound questions into the smallest independent sub-questions.
- Route each sub-question to exactly one skill by its `name`.
- If a step needs output from a prior step, set `depends_on` to that step's
  `step_id`. The executor injects upstream results via {{step_N_results}}.
- Independent steps have empty `depends_on` — they run in parallel.
- When unsure, pick the most relevant skill. If the question needs external
  real-time info, use the web search skill.
- If no skill can answer a sub-question, omit it and note the gap in reasoning.
- Step IDs are sequential integers starting at 1.

## Output (JSON only, no markdown fences)
{{
  "reasoning": "brief chain-of-thought",
  "steps": [
    {{
      "step_id": 1,
      "description": "what this step answers",
      "skill_name": "name_of_skill",
      "query": "the sub-question for this skill",
      "depends_on": [],
      "parameters": {{}}
    }}
  ]
}}
"""

# ---------------------------------------------------------------------------
# Few-shot examples
# ---------------------------------------------------------------------------

FEW_SHOT: list[dict] = [
    {"role": "user", "content": "What is Acme Corp's total revenue for Q3 2025?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Quantitative revenue question → structured_data.",
        "steps": [{"step_id": 1, "description": "Acme Q3 2025 revenue",
                    "skill_name": "structured_data",
                    "query": "What is Acme Corp's total revenue for Q3 2025?",
                    "depends_on": [], "parameters": {}}],
    })},
    {"role": "user", "content": "What does the Acme merger agreement say about earnout provisions?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Document content → unstructured_docs.",
        "steps": [{"step_id": 1, "description": "Earnout provisions in Acme merger agreement",
                    "skill_name": "unstructured_docs",
                    "query": "What does the Acme Corp merger agreement say about the earnout provisions?",
                    "depends_on": [], "parameters": {}}],
    })},
    {"role": "user", "content": "What was Acme revenue last quarter and what does their merger agreement say about earnouts?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Two independent sub-questions: revenue (structured_data) and clause (unstructured_docs). Parallel.",
        "steps": [
            {"step_id": 1, "description": "Acme revenue last quarter",
             "skill_name": "structured_data",
             "query": "What was Acme Corp's revenue last quarter?",
             "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Earnout clause in merger agreement",
             "skill_name": "unstructured_docs",
             "query": "What does the Acme Corp merger agreement say about earnouts?",
             "depends_on": [], "parameters": {}},
        ],
    })},
    {"role": "user", "content": "Show me all deals over $50M where the merger agreement had a material adverse change clause."},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Filter deals (structured_data) then inspect docs (unstructured_docs). Sequential.",
        "steps": [
            {"step_id": 1, "description": "Deals over $50M",
             "skill_name": "structured_data",
             "query": "List all deals with value over $50M. Return deal IDs and names.",
             "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Check merger agreements for MAC clauses",
             "skill_name": "unstructured_docs",
             "query": "For deals: {step_1_results}, check each merger agreement for material adverse change clauses.",
             "depends_on": [1], "parameters": {}},
        ],
    })},
    {"role": "user", "content": "How does our Acme deal compare to recent similar acquisitions in the market?"},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Internal deal data (structured_data) + external comps (web_search). Parallel.",
        "steps": [
            {"step_id": 1, "description": "Acme deal details",
             "skill_name": "structured_data",
             "query": "Get full deal details for the Acme acquisition.",
             "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Market comparable acquisitions",
             "skill_name": "web_search",
             "query": "Recent comparable acquisitions similar to Acme deal size and sector",
             "depends_on": [], "parameters": {}},
        ],
    })},
    {"role": "user", "content": "Generate a PDF report for the Globex deal including risk factors from the merger agreement."},
    {"role": "assistant", "content": json.dumps({
        "reasoning": "Deal data (structured_data) + risk factors (unstructured_docs) → report (generate_report). Chain.",
        "steps": [
            {"step_id": 1, "description": "Globex deal data",
             "skill_name": "structured_data",
             "query": "Get full deal details for the Globex acquisition.",
             "depends_on": [], "parameters": {}},
            {"step_id": 2, "description": "Risk factors from merger agreement",
             "skill_name": "unstructured_docs",
             "query": "What are the risk factors in the Globex merger agreement?",
             "depends_on": [], "parameters": {}},
            {"step_id": 3, "description": "Generate PDF report",
             "skill_name": "generate_report",
             "query": "Generate PDF report for Globex using {step_1_results} and {step_2_results}.",
             "depends_on": [1, 2], "parameters": {"format": "pdf"}},
        ],
    })},
]


def _build_messages(question: str) -> list:
    """Build the message list for the planner LLM call."""
    skills_block = registry.summary_for_planner()
    system = PLANNER_SYSTEM.format(skills_block=skills_block)

    messages = [SystemMessage(content=system)]
    for msg in FEW_SHOT:
        cls = HumanMessage if msg["role"] == "user" else AIMessage
        messages.append(cls(content=msg["content"]))
    messages.append(HumanMessage(content=question))
    return messages


# ---------------------------------------------------------------------------
# Node function
# ---------------------------------------------------------------------------

async def plan_node(state: RouterState) -> dict:
    """LangGraph node: decompose the question into an execution plan."""

    llm = ChatAnthropic(
        model=settings.planner_model,
        api_key=settings.anthropic_api_key,
        temperature=0,
        max_tokens=2048,
    )

    messages = _build_messages(state["question"])
    response = await llm.ainvoke(messages)

    raw = response.content.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1]
    if raw.endswith("```"):
        raw = raw.rsplit("```", 1)[0]

    try:
        plan_data = json.loads(raw)
    except json.JSONDecodeError:
        logger.error("Planner returned invalid JSON: %s", raw)
        return {"error": f"Planner produced invalid JSON:\n{raw}"}

    # Validate skill names
    known = {s.name for s in registry.list_all()}
    steps = []
    for s in plan_data.get("steps", []):
        if s["skill_name"] not in known:
            logger.warning("Unknown skill '%s' — skipping step", s["skill_name"])
            continue
        steps.append(PlanStep(**s))

    if not steps:
        return {"error": "Planner produced no valid steps."}

    return {
        "reasoning": plan_data.get("reasoning", ""),
        "plan_steps": steps,
        "step_results": [],
        "completed_ids": set(),
    }
