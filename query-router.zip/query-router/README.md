# Query Router & Planner

An intelligent query routing system that classifies user questions, plans
execution across a registry of **skills**, and orchestrates results.

Every capability — structured data access, document search, web search,
report generation — is a **skill**: a folder with a `SKILL.md` manifest
and a `run.py` (or `run.sh`) entry point.

## Architecture

```
User Query
    │
    ▼
┌──────────────┐
│   Planner    │  LLM-based: reads skill registry, decomposes query,
│  (LLM call)  │  picks skills, sets execution order
└──────┬───────┘
       │  Execution Plan (JSON)
       ▼
┌──────────────┐
│  Executor    │  Runs plan steps: parallel when independent,
│              │  sequential when dependent
└──┬───┬───┬───┘
   │   │   │
   ▼   ▼   ▼
┌─────────────────────────────────────┐
│          Skill Registry             │
│  ┌────────────┐ ┌────────────────┐  │
│  │ structured │ │ unstructured   │  │
│  │ _data      │ │ _docs          │  │
│  └────────────┘ └────────────────┘  │
│  ┌────────────┐ ┌────────────────┐  │
│  │ web_search │ │ generate_report│  │
│  └────────────┘ └────────────────┘  │
│  └── ... any future skill ───────┘  │
└─────────────────────────────────────┘
       │
       ▼
┌──────────────┐
│ Synthesizer  │  Merges results from all steps into a coherent answer
└──────────────┘
```

## Project Structure

```
query-router/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI entry point
│   ├── config.py             # Settings & env vars
│   ├── models.py             # Pydantic models for plans, results
│   ├── planner.py            # LLM-based query planner
│   ├── executor.py           # Runs skills per the plan
│   ├── synthesizer.py        # Merges multi-step results
│   └── skill_registry.py     # Discovers & loads SKILL.md files
├── skills/                   # Every capability lives here
│   ├── structured_data/      # Chatbot API for deals, revenue, clients
│   │   ├── SKILL.md
│   │   └── run.py
│   ├── unstructured_docs/    # Chatbot API for IPO, M&A, Debt docs
│   │   ├── SKILL.md
│   │   └── run.py
│   ├── web_search/           # Web search capability
│   │   ├── SKILL.md
│   │   └── run.py
│   ├── generate_report/      # Report generation
│   │   ├── SKILL.md
│   │   └── run.py
│   └── deal_comparison/      # Side-by-side deal analysis
│       ├── SKILL.md
│       └── run.py
├── tests/
│   ├── __init__.py
│   └── test_planner.py
├── pyproject.toml
├── .env.example
└── README.md
```

## Quick Start

```bash
# 1. Install
pip install -e ".[dev]"

# 2. Configure
cp .env.example .env
# Edit .env with your API keys and endpoints

# 3. Run
uvicorn app.main:app --reload

# 4. Query
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What was Acme Corp revenue last quarter and what does their merger agreement say about earnouts?"}'
```

## Adding Skills

1. Create a folder under `skills/`
2. Add a `SKILL.md` with frontmatter:

```markdown
---
name: my_skill
description: What this skill does (shown to the planner)
trigger: when to use this skill (natural language)
category: data_source | search | analysis | generation
parameters:
  - name: query
    type: string
    required: true
    description: The question or command to execute
---

# My Skill

Detailed documentation...
```

3. Add a `run.py` that reads JSON from stdin and writes JSON to stdout:

```python
import json, sys

payload = json.load(sys.stdin)
# payload["query"]      — the sub-question from the planner
# payload["parameters"] — any extra params from the plan step
# payload["upstream"]   — results from prior dependent steps

result = {"answer": "..."}
json.dump(result, sys.stdout)
```

4. The registry auto-discovers on startup — no code changes needed.

## Endpoints

| Method | Path      | Description                                    |
|--------|-----------|------------------------------------------------|
| POST   | `/query`  | Full pipeline: plan → execute → synthesize     |
| POST   | `/plan`   | Dry run: returns execution plan only           |
| GET    | `/skills` | List all registered skills                     |
| GET    | `/health` | Health check with skill count                  |
