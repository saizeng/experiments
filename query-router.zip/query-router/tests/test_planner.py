"""Tests for skill registry and execution plan models."""

from __future__ import annotations

from pathlib import Path

import pytest

from app.models import ExecutionPlan, PlanStep
from app.skill_registry import SkillRegistry, _parse_skill_md


# ---------------------------------------------------------------------------
# Skill registry tests
# ---------------------------------------------------------------------------

SAMPLE_SKILL_MD = """\
---
name: test_skill
description: A test skill for unit tests
trigger: when user says test
category: data_source
parameters:
  - name: query
    type: string
    required: true
    description: The question to answer
  - name: verbose
    type: boolean
    required: false
    default: false
    description: Enable verbose output
---

# Test Skill

This is the body of the skill.
"""


def test_parse_skill_md(tmp_path: Path):
    skill_file = tmp_path / "SKILL.md"
    skill_file.write_text(SAMPLE_SKILL_MD)

    manifest = _parse_skill_md(skill_file)

    assert manifest is not None
    assert manifest.name == "test_skill"
    assert manifest.description == "A test skill for unit tests"
    assert manifest.trigger == "when user says test"
    assert manifest.category == "data_source"
    assert len(manifest.parameters) == 2
    assert manifest.parameters[0].name == "query"
    assert manifest.parameters[0].required is True
    assert manifest.parameters[1].default is False


def test_parse_skill_md_missing_frontmatter(tmp_path: Path):
    skill_file = tmp_path / "SKILL.md"
    skill_file.write_text("# No frontmatter\nJust body.")

    assert _parse_skill_md(skill_file) is None


def test_parse_skill_md_missing_required_fields(tmp_path: Path):
    skill_file = tmp_path / "SKILL.md"
    skill_file.write_text("---\nname: incomplete\n---\n# Body\n")

    assert _parse_skill_md(skill_file) is None


def test_registry_discovery(tmp_path: Path):
    for name in ["skill_a", "skill_b"]:
        folder = tmp_path / name
        folder.mkdir()
        (folder / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: {name} desc\ncategory: test\n---\n# {name}\n"
        )

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)

    assert len(reg.list_all()) == 2
    assert reg.get("skill_a") is not None
    assert reg.get("skill_b") is not None
    assert reg.get("nonexistent") is None


def test_registry_summary_grouped_by_category(tmp_path: Path):
    for name, cat in [("ds", "data_source"), ("ws", "search")]:
        folder = tmp_path / name
        folder.mkdir()
        (folder / "SKILL.md").write_text(
            f"---\nname: {name}\ndescription: {name} desc\ncategory: {cat}\n---\n# {name}\n"
        )

    reg = SkillRegistry()
    reg.load_from_directory(tmp_path)
    summary = reg.summary_for_planner()

    assert "### data_source" in summary
    assert "### search" in summary
    assert "**ds**" in summary
    assert "**ws**" in summary


# ---------------------------------------------------------------------------
# Plan model tests
# ---------------------------------------------------------------------------

def test_execution_plan_roundtrip():
    plan = ExecutionPlan(
        original_question="test question",
        reasoning="test reasoning",
        steps=[
            PlanStep(
                step_id=1,
                description="fetch data",
                skill_name="structured_data",
                query="get data",
                depends_on=[],
                parameters={},
            ),
            PlanStep(
                step_id=2,
                description="search docs",
                skill_name="unstructured_docs",
                query="find clause about {step_1_results}",
                depends_on=[1],
                parameters={},
            ),
        ],
    )

    assert len(plan.steps) == 2
    assert plan.steps[1].depends_on == [1]
    assert plan.steps[0].skill_name == "structured_data"


def test_plan_step_skill_name_required():
    """Every step must specify a skill_name."""
    step = PlanStep(
        step_id=1,
        description="test",
        skill_name="web_search",
        query="test query",
    )
    assert step.skill_name == "web_search"
