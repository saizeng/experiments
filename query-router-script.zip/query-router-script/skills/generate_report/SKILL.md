---
name: generate_report
description: >
  Generates a formatted PDF or DOCX report from deal data. Typically
  used after fetching data from other skills.
trigger: when user asks for a report, summary document, or formatted output
category: generation
parameters:
  - name: query
    type: string
    required: true
    description: What report to generate
  - name: format
    type: string
    required: false
    default: pdf
    description: Output format (pdf or docx)
---

# Generate Report Skill
