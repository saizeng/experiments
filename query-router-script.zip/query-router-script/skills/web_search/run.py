"""Web search skill. TODO: Replace stub with your search API."""


async def run(query: str, parameters: dict, upstream: dict) -> dict:
    max_results = parameters.get("max_results", 5)

    # Example using a real search API:
    #
    # import httpx
    # async with httpx.AsyncClient() as client:
    #     resp = await client.get(
    #         "https://api.tavily.com/search",
    #         params={"query": query, "max_results": max_results},
    #         headers={"Authorization": f"Bearer {API_KEY}"},
    #     )
    #     return resp.json()

    return {
        "results": [
            {"title": f"[STUB] Result for: {query}", "url": "https://example.com", "snippet": f"Stub snippet for: {query}"}
        ],
        "source": "web_search",
    }
