"""FastAPI application — serves the LangGraph query router."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from app.config import settings
from app.graph import router_graph
from app.skill_registry import registry
from app.state import PlanStep, StepResult

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    registry.load_from_directory(settings.skills_dir)
    logger.info(
        "Loaded %d skill(s): %s",
        len(registry.list_all()),
        [s.name for s in registry.list_all()],
    )
    yield


app = FastAPI(
    title="Query Router (LangGraph)",
    description="Intelligent skill-based query routing via LangGraph.",
    version="0.3.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class QueryRequest(BaseModel):
    question: str
    context: dict[str, Any] = Field(default_factory=dict)


class PlanResponse(BaseModel):
    reasoning: str
    steps: list[dict]


class QueryResponse(BaseModel):
    answer: str
    reasoning: str
    plan_steps: list[dict]
    step_results: list[dict]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.post("/query", response_model=QueryResponse)
async def handle_query(req: QueryRequest) -> QueryResponse:
    """Full pipeline: plan → execute (loop) → synthesize."""

    initial_state = {
        "question": req.question,
        "context": req.context,
        "reasoning": "",
        "plan_steps": [],
        "step_results": [],
        "completed_ids": set(),
        "answer": "",
        "error": "",
    }

    try:
        final_state = await router_graph.ainvoke(initial_state)
    except Exception as exc:
        logger.exception("Graph execution failed")
        raise HTTPException(status_code=502, detail=str(exc))

    if final_state.get("error") and not final_state.get("answer"):
        raise HTTPException(status_code=502, detail=final_state["error"])

    return QueryResponse(
        answer=final_state.get("answer", ""),
        reasoning=final_state.get("reasoning", ""),
        plan_steps=[s.model_dump() if isinstance(s, PlanStep) else s
                    for s in final_state.get("plan_steps", [])],
        step_results=[r.model_dump() if isinstance(r, StepResult) else r
                      for r in final_state.get("step_results", [])],
    )


@app.post("/plan", response_model=PlanResponse)
async def plan_only(req: QueryRequest) -> PlanResponse:
    """Dry run: execute only the planner node, return the plan."""
    from app.nodes.planner import plan_node

    state = {
        "question": req.question,
        "context": req.context,
        "reasoning": "",
        "plan_steps": [],
        "step_results": [],
        "completed_ids": set(),
        "answer": "",
        "error": "",
    }

    try:
        result = await plan_node(state)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    if result.get("error"):
        raise HTTPException(status_code=502, detail=result["error"])

    return PlanResponse(
        reasoning=result.get("reasoning", ""),
        steps=[s.model_dump() for s in result.get("plan_steps", [])],
    )


@app.get("/skills")
async def list_skills():
    return [
        {
            "name": s.name,
            "description": s.description,
            "category": s.category,
            "trigger": s.trigger,
            "parameters": [p.model_dump() for p in s.parameters],
        }
        for s in registry.list_all()
    ]


@app.get("/health")
async def health():
    return {"status": "ok", "skills_loaded": len(registry.list_all())}
