"""Synthesizer node: merges step results, aware of conversation history."""

from __future__ import annotations

import json
import logging

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from app.config import settings
from app.state import RouterState, StepStatus

logger = logging.getLogger(__name__)

SYNTHESIZER_SYSTEM = """\
You are a financial services assistant. You are synthesizing results from
multiple data sources and tools to answer the user's latest question.

Rules:
1. Merge all step results into one coherent answer.
2. Note any failed steps and what info is missing.
3. Be precise with numbers; cite which source provided each fact.
4. Flag conflicting results.
5. Be concise. Use the conversation history for context but focus
   your answer on the latest question.
"""


async def synthesize_node(state: RouterState) -> dict:
    """Merge all step results into a final answer."""

    results = state.get("step_results", [])
    plan_steps = state.get("plan_steps", [])

    # Fast path: single successful step
    successful = [r for r in results if r.status == StepStatus.SUCCESS]
    if len(results) == 1 and len(successful) == 1:
        data = successful[0].data
        answer = data if isinstance(data, str) else json.dumps(data, indent=2, default=str)
        return {"answer": answer}

    # Build step summaries
    step_map = {s.step_id: s for s in plan_steps}
    summaries: list[str] = []
    for r in results:
        step = step_map.get(r.step_id)
        desc = step.description if step else f"Step {r.step_id}"
        skill = step.skill_name if step else r.skill_name
        data_str = json.dumps(r.data, indent=2, default=str) if r.data is not None else "(no data)"
        error_str = f"\n  Error: {r.error}" if r.error else ""
        summaries.append(
            f"### Step {r.step_id}: {desc}\n"
            f"Skill: {skill}\nStatus: {r.status.value}{error_str}\n"
            f"Result:\n{data_str}"
        )

    user_content = (
        f"## Question\n{state['question']}\n\n"
        f"## Plan\n{state.get('reasoning', '')}\n\n"
        f"## Results\n\n" + "\n\n".join(summaries)
    )

    llm = ChatAnthropic(
        model=settings.synthesizer_model,
        api_key=settings.anthropic_api_key,
        temperature=0,
        max_tokens=4096,
    )

    messages: list = [SystemMessage(content=SYNTHESIZER_SYSTEM)]

    # Include conversation history so synthesizer can reference prior context
    for msg in state.get("chat_history", []):
        cls = HumanMessage if msg.role == "user" else AIMessage
        messages.append(cls(content=msg.content))

    messages.append(HumanMessage(content=user_content))

    response = await llm.ainvoke(messages)
    return {"answer": response.content.strip()}
