"""Executor node: runs skill steps whose dependencies are satisfied.

Each invocation finds all steps that are ready (deps met, not yet run),
executes them in parallel, and appends results to state.
"""

from __future__ import annotations

import asyncio
import json
import logging
import pathlib
import sys
from typing import Any

from app.config import settings
from app.skill_registry import registry
from app.state import PlanStep, RouterState, StepResult, StepStatus

logger = logging.getLogger(__name__)


async def _invoke_skill(step: PlanStep, upstream: dict[str, Any]) -> StepResult:
    """Run a single skill's runner script via subprocess."""

    manifest = registry.get(step.skill_name)
    if not manifest:
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=f"Unknown skill: {step.skill_name}",
        )

    folder = pathlib.Path(manifest.folder_path)
    runner = folder / "run.py"
    if not runner.exists():
        runner = folder / "run.sh"
    if not runner.exists():
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=f"No run.py or run.sh in {folder}",
        )

    payload = {
        "query": step.query,
        "parameters": step.parameters,
        "upstream": upstream,
    }

    cmd = (
        [sys.executable, str(runner)]
        if runner.suffix == ".py"
        else ["bash", str(runner)]
    )

    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(folder),
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=json.dumps(payload).encode()),
            timeout=settings.skill_timeout_seconds,
        )
    except asyncio.TimeoutError:
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=f"Skill '{step.skill_name}' timed out after {settings.skill_timeout_seconds}s",
        )
    except Exception as exc:
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=str(exc),
        )

    if proc.returncode != 0:
        return StepResult(
            step_id=step.step_id,
            skill_name=step.skill_name,
            status=StepStatus.FAILED,
            error=f"Exit {proc.returncode}: {stderr.decode()[:500]}",
        )

    raw = stdout.decode().strip()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        data = raw

    return StepResult(
        step_id=step.step_id,
        skill_name=step.skill_name,
        status=StepStatus.SUCCESS,
        data=data,
    )


def _resolve_query(step: PlanStep, results_map: dict[int, StepResult]) -> PlanStep:
    """Replace {step_N_results} placeholders in the query with actual data."""
    query = step.query
    for dep_id in step.depends_on:
        placeholder = "{" + f"step_{dep_id}_results" + "}"
        if placeholder in query:
            dep_data = results_map.get(dep_id)
            replacement = json.dumps(dep_data.data, default=str) if dep_data else "(unavailable)"
            query = query.replace(placeholder, replacement)
    return PlanStep(
        step_id=step.step_id,
        description=step.description,
        skill_name=step.skill_name,
        query=query,
        depends_on=step.depends_on,
        parameters=step.parameters,
    )


# ---------------------------------------------------------------------------
# Node function
# ---------------------------------------------------------------------------

async def execute_node(state: RouterState) -> dict:
    """LangGraph node: execute all steps whose dependencies are met."""

    completed = state.get("completed_ids", set())
    existing_results = state.get("step_results", [])
    results_map = {r.step_id: r for r in existing_results}

    # Find ready steps: deps all in completed, not yet run
    ready_steps: list[PlanStep] = []
    for step in state["plan_steps"]:
        if step.step_id in completed:
            continue
        if all(dep_id in completed for dep_id in step.depends_on):
            ready_steps.append(step)

    if not ready_steps:
        return {}  # nothing to do

    # Resolve query templates and build upstream context
    tasks = []
    for step in ready_steps:
        resolved = _resolve_query(step, results_map)
        upstream = {
            f"step_{dep_id}_results": results_map[dep_id].data
            for dep_id in step.depends_on
            if dep_id in results_map
        }
        tasks.append(_invoke_skill(resolved, upstream))

    # Run ready steps in parallel
    new_results = await asyncio.gather(*tasks)

    # Merge into state
    all_results = list(existing_results) + list(new_results)
    new_completed = completed | {r.step_id for r in new_results}

    return {
        "step_results": all_results,
        "completed_ids": new_completed,
    }
