<a id='377961fc-aa18-4354-8f61-120267077fbd'></a>

NEW

VENTURE

COMPETITION

Harvard
Business
School

<a id='8b3b9e6f-64a4-406c-8d25-4615aef6927b'></a>

<::logo: [Unidentifiable] 
 A light blue shield with a pattern of crosses and squares, topped with three indistinct shapes.::>

<a id='19d0d591-7939-450f-b858-1bc037fa876a'></a>

Pitch Deck Example

<a id='fafd594b-6ae5-4af0-89d7-c415c0b26e91'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem to the left of the text, with the word "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='3f816d9d-b8d2-4255-98cc-06e4cb2a0199'></a>

GOAL

<a id='a6cd0237-5a15-4da0-8a57-442c3719bd1f'></a>

* The goal of your pitch deck is to give a snapshot of your investment opportunity, taking into consideration your impact, growth potential, viability, and the ability of your team to execute your plan.

<a id='adec2abd-7950-45a7-b9a0-575c921967ee'></a>

- Think of this as the most compelling elements of your executive summary presented visually and verbally.

<a id='2d121178-870a-430a-b9a2-59fa065d664a'></a>

<::logo: Harvard Business School
Harvard
Business
School
A shield emblem with a black cross and four white symbols is next to the red text "Harvard" and black text "Business School."::>

<!-- PAGE BREAK -->

<a id='a68ffc79-59b6-4703-963b-920efaabf120'></a>

Housekeeping

<a id='dca8034e-8398-4629-9688-1c68678bb9d9'></a>

- Keep in mind that you will be allotted 10 minutes or less to present and may need to adjust the content and number of slides accordingly.

<a id='3d3ceffb-d6b6-4bf6-b7e8-03530ebabcdd'></a>

* Ensure slides are not text or data heavy and use at least a 30pt font.

<a id='a2ad6d45-595c-4a87-93d6-d61615641013'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='bb237f76-82e7-43bf-8c61-8e0b3e05e3db'></a>

Cover page

<a id='e512e332-3a6f-4c85-b87d-0df18c62e8cf'></a>

TAGLINE: Define your
venture with a short
declarative sentence,
getting to the heart of
your venture's unique
advantage.

<a id='322e83cb-c73b-42b2-a0d5-7bc56a08c31c'></a>

Harvard
Business
School
NEW
VENTURE
COMPETITION

<a id='2f9d2cba-fb83-4654-b56f-be1073781fbc'></a>

<::logo: [Unidentifiable] 
 A light blue shield emblem with a cross-like pattern of four oak leaves in the center and a row of unidentifiable symbols at the top.::>

<a id='c3ce4d5c-b936-4173-adb8-c097f49d4531'></a>

DATE:
PRESENTER NAME:

<a id='6574a169-0b85-4ad8-b719-9422af6a7acb'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, three containing books and one with crossed axes, beside the institution's name in red and black text.::>

<!-- PAGE BREAK -->

<a id='91a78e4c-4f80-4b49-b1b4-b3198150c9d3'></a>

Problem

<a id='b54aaf80-70b0-43d3-ae0d-b064941edba0'></a>

"The goal is to get everyone nodding and buying in."
- Guy Kawasaki, The Art of the Start

<a id='7b328960-b842-48d9-9629-ef0182b0db6f'></a>

* Describe the pain of the customer (or the customer's customer)
* Outline how the customer addresses the issue today and why current solutions don't work.
* Is it costing the customer time, money, frustration...
Define the pain point. ($ amount, time lost, etc.)

<a id='dea1b493-eb54-46a1-a512-134013f6d3db'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='a7bc4cde-38cf-49f8-952f-86e09d768169'></a>

Solution

<a id='95dc29ac-b490-46d4-80f1-73b57293f48c'></a>

- Demonstrate your company's value proposition to make the customer's life better
- Provide cases, customer insights, case studies
- Show scalability

<a id='c9cc43ff-4d8f-4a32-b842-14359f9936e6'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='d68ff9c0-626b-405f-8469-758998219b50'></a>

Market Size/Dynamic

<a id='751059fb-4374-4cc8-a3de-b212dced7f63'></a>

_"Good analysis will therefore involve careful segmentation of the true addressable market and thoughtful descriptions of how those customers will pay for the solution over time to build up a picture of a realistic market size." - Michael Skok_

<a id='21047974-552f-4e97-ad9a-70688b1c98d5'></a>

* Identify/profile the customer you cater to
* Provide bottoms-up market sizing: the number of potential customers and the price of the product sold into those customers. * The government census data is a good resource for this analysis.

<a id='c29f565f-3b0b-46b3-bb50-8e9d0f154b2c'></a>

- Changing trends, new technologies, and forces driving this segment

<a id='96779203-1756-47fa-af1a-6fab4f41aaf9'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='a8778ac5-ad69-489d-bbb3-944fa0754ed1'></a>

Competition

<a id='1ee29f8c-9876-4800-95fa-6143bebe6a04'></a>

* Give a list of direct competitors, substitutes, or those about to emerge
* Why hasn't anyone done this before? What are the barriers to entry that keep someone from doing this and/or what would keep a competitor from imitating your product or entering your market?

<a id='03b70b00-d1bd-4afa-bd83-c455bc194362'></a>

* Highlight your venture's competitive advantages

<a id='70e895d0-c6dc-424b-9227-8a8c51cbc666'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='95e6711f-f000-47f1-946a-a62918aa71e8'></a>

Go-to-Market Strategy

<a id='1fa5eb10-8f4c-4922-a331-9b9fa5fadbf3'></a>

Tip: What are you selling?
Who are you selling it to?
How will you reach your target market?
Where will you promote your product?

<a id='4e8c8d23-91b0-4436-9b09-c15bfe021d2f'></a>

- What is your plan for execution?
- Summarize sales, marketing, and partnership plans

<a id='69897372-72a2-4e1c-b188-89fce84b56ae'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='4cdcdda0-af60-48ea-b35e-4aae2631635f'></a>

Product

<a id='bf5cc44f-614d-4cf6-be5a-5addb12c8e7b'></a>

- Product line-up (form factor, functionality, features, architecture, intellectual property)

<a id='b4bea8ca-ad78-4d6a-beb7-48b618c181a7'></a>

* Development roadmap

<a id='b52de008-bb40-4294-bfb1-8ded2307624a'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four symbols, accompanied by the words "Harvard Business School" in red and black text.::>

<!-- PAGE BREAK -->

<a id='206ae2f2-cc75-495c-8bab-1e2032feadb2'></a>

Business Model

<a id='1ef4bcb5-f24b-46c1-b937-d68d698fbc2b'></a>

"Explain how you make money –who pays you, your channels of distribution, and your gross margins." - Guy Kawasaki, The Art of the Start

<a id='ab676294-0546-4b32-bda5-cec3e6e301a3'></a>

* Revenue model
* Pricing
* Average account size and/or lifetime value
* Sales & distribution model
* Customer/pipeline list

<a id='38f786a8-1c84-4eb6-ae05-0a01cfc2a3e8'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='b06b3c23-e1ba-497a-9fb5-4f322309fb7e'></a>

Key Milestones

<a id='3c0bdd2f-dd9e-4647-ac92-2b8e3a1dfc5f'></a>

* Outline current milestones achieved and future milestones.
* Customer research
* MVP development
* Product launch
* Beta users
* Market testing
* Marketing role out/CAC

<a id='dae0c6e3-7ee1-4826-a906-58088600cf1d'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='6dea1c41-38b4-4626-bf98-1dc622987e42'></a>

Financial Snapshot

<a id='ef3a4d5a-51f2-4c6d-9fe8-e51ac8486dca'></a>

Tip: "Define assumptions so it's clear that you've developed a realistic model."

*   Provide a 3 year forecast, including annual revenue,
    net income, and key metrics (customers and
    conversion rates).

<a id='e4c1bda8-21ae-4bd7-8d1e-c1a62f8951ed'></a>

- Prepare supplemental information such as
  - Product launch
  - Go-to-market execution
  - Other?

<a id='9d45ea23-05de-443a-892d-08e497281287'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='38357a4a-34ac-4934-8439-2a70e4fcebe1'></a>

Capital Requirements

<a id='61f62c12-e6c7-47eb-8230-6e3b89f6aeff'></a>

Tip: How much capital will you need prior to becoming cash flow positive and how will your funds be applied? You need to explain the minimum required equity you need to reach your next key milestone.

<a id='6b122a40-e573-4d9d-b790-c27a7cdd443e'></a>

* Customer research- focus groups, surveys
* MVP development
* Product launch
* Go-to-market execution
* Other?

<a id='0bbbdf42-4c47-412f-8ab0-b37227c44a51'></a>

<::logo: Harvard Business School
Harvard Business School
A shield emblem with a cross pattern and four books is placed to the left of the institution's name in red and black text.::>

<!-- PAGE BREAK -->

<a id='41b8b095-079c-4e29-922a-f631bf858232'></a>

Team

<a id='0e54cde7-9cf3-4b90-879c-6b20030aaeb7'></a>

Tip: You need to convey that you are the team to execute this venture!

<a id='40fe31dd-c31a-465e-823e-ade1e7ed2bc8'></a>

*   Founders & Management
    *   What key skills or experience that relate to the product or leading of the company
*   Board of Directors/Board of Advisors
    *   Highlight spheres of influence

<a id='b233bdf8-1b78-4482-97ba-91c073962bf6'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='017fe1bd-80f3-4e72-af7b-e62373742a85'></a>

Appendix

<a id='1cb99fb9-94a7-4259-b4c1-6c963a82b8f2'></a>

Additional slides that can be used for follow-up questions.

<a id='f00b336f-0f3c-46d4-b675-463faa14c8cf'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with three open books above a black cross-like symbol, accompanied by the institution's name in red and black text.::>