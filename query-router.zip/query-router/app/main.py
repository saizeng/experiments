"""FastAPI application — query routing entry point."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException

from app.config import settings
from app.executor import Executor
from app.models import ExecutionPlan, QueryRequest, QueryResponse
from app.planner import Planner
from app.skill_registry import registry
from app.synthesizer import Synthesizer

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    registry.load_from_directory(settings.skills_dir)
    logger.info(
        "Loaded %d skill(s): %s",
        len(registry.list_all()),
        [s.name for s in registry.list_all()],
    )
    yield


app = FastAPI(
    title="Query Router",
    description="Intelligent routing across skill-based data sources and tools.",
    version="0.2.0",
    lifespan=lifespan,
)

planner = Planner()
executor = Executor()
synthesizer = Synthesizer()


@app.post("/query", response_model=QueryResponse)
async def handle_query(req: QueryRequest) -> QueryResponse:
    """Full pipeline: plan → execute → synthesize."""
    try:
        plan = await planner.plan(req.question)
    except Exception as exc:
        logger.exception("Planning failed")
        raise HTTPException(status_code=502, detail=f"Planner error: {exc}")

    try:
        step_results = await executor.execute(plan)
    except Exception as exc:
        logger.exception("Execution failed")
        raise HTTPException(status_code=502, detail=f"Executor error: {exc}")

    try:
        answer = await synthesizer.synthesize(req.question, plan, step_results)
    except Exception as exc:
        logger.exception("Synthesis failed")
        raise HTTPException(status_code=502, detail=f"Synthesizer error: {exc}")

    return QueryResponse(answer=answer, plan=plan, step_results=step_results)


@app.post("/plan", response_model=ExecutionPlan)
async def plan_only(req: QueryRequest) -> ExecutionPlan:
    """Dry run: returns execution plan only (no skill invocation)."""
    try:
        return await planner.plan(req.question)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Planner error: {exc}")


@app.get("/skills")
async def list_skills():
    """List all registered skills with metadata."""
    return [
        {
            "name": s.name,
            "description": s.description,
            "category": s.category,
            "trigger": s.trigger,
            "parameters": [p.model_dump() for p in s.parameters],
        }
        for s in registry.list_all()
    ]


@app.get("/health")
async def health():
    return {"status": "ok", "skills_loaded": len(registry.list_all())}
