#!/usr/bin/env python3
"""Web search skill runner.

TODO: Replace the stub with your actual search API call
(e.g., Tavily, Brave Search, SerpAPI, or custom).
"""

import json
import sys


def main() -> None:
    payload = json.load(sys.stdin)
    query = payload.get("query", "")
    max_results = payload.get("parameters", {}).get("max_results", 5)

    # ── Replace with your actual search API call ──
    result = {
        "results": [
            {
                "title": f"[STUB] Search result for: {query}",
                "url": "https://example.com",
                "snippet": f"Stub snippet for query: {query}",
            }
        ],
        "source": "web_search",
    }

    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
