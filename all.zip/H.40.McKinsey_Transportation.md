<a id='527bcf63-a0b0-423a-a8dc-2a7a5e8bb2a5'></a>

<::McKinsey & Company logo
: figure::>

<a id='f9aedcac-86fa-454c-aa69-17e608a087be'></a>

# Transportation and
# Warehousing
# Sector Analysis

Federal City Council

October 2020

<a id='0fc8b7e5-2239-44e4-ba55-34b2af5aa742'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company
is strictly prohibited

<a id='0720f08b-db8f-4b0a-99f8-0d5929c42db9'></a>

<::Two images. The top image shows a man and a woman riding bicycles, both wearing helmets. The US Capitol building is visible in the background. The woman is on the left, smiling, wearing a striped shirt and a dark jacket. The man is on the right, wearing a white shirt and a blue tie. The bottom image shows the front and side of a red tram or train. The destination sign on the front reads "2018" and "tion to Oklah". The side of the tram has a yellow stripe pattern and the "dc." logo with some text below it.: figure::>

<!-- PAGE BREAK -->

<a id='45603148-ca26-4787-89fc-cfed1e3c430e'></a>

Contents

<a id='925a307c-a7ee-4275-84c2-be432bcd6f2e'></a>

Baseline Conditions

Challenges and trends

Opportunities and best practices

Appendix

<a id='fb11d999-7b2c-437a-b079-fbb4259a2f28'></a>

McKinsey & Company

<a id='30250aee-93f8-4354-ab7c-d11a5c6828bf'></a>

2

<a id='47e9735c-fb27-4475-b71f-20554c477cf8'></a>

Last Modified: 1/13/2023 6:03 PM Eastern Standard Time

<a id='c2e0fd2c-385f-4a7c-8ac2-dd9ce1fdb447'></a>

Printed

<!-- PAGE BREAK -->

<a id='9188aa9f-2a81-4fbe-b5f5-49fbc94ea5f6'></a>

The transportation sector in DC has modest employment...

<a id='2e30498e-c703-40af-8541-e2cc2c36e20f'></a>

<::Employment growth and specialization by industry¹: bubble chart::>

This bubble chart titled "Employment growth and specialization by industry¹" displays Employment CAGR (2019-24) on the y-axis (ranging from -3.5 to 3.5) and Employment specialization² on the x-axis (ranging from 0 to 2.8). A vertical line at LQ = 1 indicates a specialization threshold. A gray bubble in the top right corner serves as a legend, indicating that a bubble of that size represents "~50K jobs".

The chart shows various industries represented by bubbles, with their size indicating job count, color indicating industry type (dark for most, light blue for one), and position indicating their CAGR and specialization:

**Top Left Quadrant (High Growth, Low Specialization):**
- A small dark bubble near (0.3, 3.5).
- Construction: a dark bubble near (0.4, 2.0).
- Finance and insurance: a dark bubble near (0.6, 1.5) and another smaller one near (0.2, 1.0).

**Top Right Quadrant (High Growth, High Specialization):**
- Other services: a dark bubble near (1.4, 1.7).
- Professional, scientific, and technical services: a large dark bubble near (2.2, 2.5).

**Bottom Left Quadrant (Low Growth/Decline, Low Specialization):**
- Admin. and support and waste management and remediation services: a dark bubble near (0.8, 0.0).
- Real estate and rental and leasing: a dark bubble near (0.6, -1.0) and a smaller one near (0.8, -0.5).
- A small dark bubble near (0.0, -3.0).
- Transportation and warehousing: a blue bubble with a white outline near (0.4, -2.7).

**Bottom Right Quadrant (Low Growth/Decline, High Specialization):**
- Government: a very large dark bubble near (2.2, 0.7).
- Information: a dark bubble near (1.4, -0.7).
- Educational services: a dark bubble near (2.6, -0.2).
- Health care and social assistance: a dark bubble near (2.0, -2.5).
- Accommodation and food services: a dark bubble near (1.8, -3.2).
- A small dark bubble near (0.8, -3.2).

<a id='295b389c-e98f-4b0d-8aaa-0fd33916f611'></a>

...but is a critical enabler of economic competitiveness

<a id='e71a162b-a64e-4183-9828-d174d5b1b009'></a>

Transit solutions are essential to **manage congestion** and support **optimal land use**:

- Reduces congestion by **25%**, saving more than **$1.5 billion** annually in wasted time and fuel
- Saves **1 million+** auto trips per day
- Frees up **200,000** more parking spaces in the core, equivalent of **166 blocks** of five-story garages

<a id='ea5a1a85-e344-447f-8838-5b97e7a497bc'></a>

DC has one of the highest rates of **transit** and **bike** usage among major cities in the US:
*   **34%** of workers commute by public transit (**3rd** highest among large US cities) and **4%** of workers commute by bicycle (**2nd** highest)³

<a id='d3b18a03-ba19-4d66-8147-f405ee90bb2d'></a>

Transit enhances DC's affordability for its residents:
- $342 million/year in auto expenditures saved by households using Metro due to reduced car ownership, operating, and maintenance costs
- 360,000 trips by transit dependents per day

<a id='7de6aa61-16f3-478d-8de9-a371d2d3bddc'></a>

* Transportation and warehousing sector is ~2% of DC employment
* 3% decline in jobs forecasted between 2019-24, largely due to COVID-19
* Low specialization relative to the US as a whole (LQ = 0.4)

<a id='07ee5a89-40ad-49b8-aec2-89f86f8af0a4'></a>

1 Mining, quarrying, and oil and gas extraction not included; Forecast from Moody's Analytics;
2 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole;
3 With working populations greater than 250K

<a id='cdb67fcd-86fa-4090-8957-3eb909d57b63'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics; WMATA "Why Metro Matters"; US Census

<a id='fdaf8194-a811-4876-a880-761676934424'></a>

McKinsey & Company

<a id='4c2d0943-ea29-4fe5-989b-d47f77e7e129'></a>

3

<!-- PAGE BREAK -->

<a id='e732da8f-34bc-4d97-9750-3624005ba48f'></a>

Transportation and warehousing is a relatively small sector in DC
with low specialization relative to US average

Employment, growth, and specialization by major industry

<a id='eef4b9bb-b335-4b35-acc8-6ecc17150f55'></a>

option Focus of this document: [x] Analyses by other firms: [ ]<::table::>| Sector | Included in sector analysis | Size Jobs, 2019¹ | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %² | Specialization Jobs LQ³ |
|:---|:---|:---|:---|:---|:---|
| Government and government enterprises | [x] | 248,311 | 0% | 0% | 2.2 |
| Professional, scientific, and technical services | [x] | 147,712 | 3% | 2% | 2.2 |
| Other services (except government and government enterprises)⁴ | [x] | 86,662 | 2% | 1% | 1.6 |
| Health care and social assistance | [ ] | 76,211 | 1% | -2% | 0.7 |
| Accommodation and food services | [x] | 75,933 | 3% | -3% | 1.1 |
| Educational services | [x] | 59,427 | -1% | 0% | 2.7 |
| Admin. and support and waste management and remediation services | [ ] | 52,751 | 0% | -1% | 0.9 |
| Real estate and rental and leasing | [x] | 32,102 | 3% | -2% | 0.7 |
| Finance and insurance | [x] | 27,956 | 3% | 1% | 0.6 |
| Retail trade | [ ] | 26,806 | 2% | 0% | 0.3 |
| Information | [x] | 22,510 | 3% | -1% | 1.4 |
| Arts, entertainment, and recreation | [x] | 19,640 | 6% | 0% | 0.9 |
| Construction | [x] | 17,961 | 1% | 2% | 0.4 |
| Transportation and warehousing | [x] | 15,145 | 13% | -3% | 0.4 |
| Wholesale trade | [ ] | 5,782 | 0% | 1% | 0.2 |
| Management of companies and enterprises | [ ] | 3,489 | 6% | 3% | 0.3 |
| Manufacturing | [ ] | 2,154 | 4% | -3% | 0.0 |
| Utilities | [ ] | 2,116 | 1% | -3% | 0.8 |
| Mining, quarrying, and oil and gas extraction | [ ] | 252 | -10% | -1% | 0.0 |
| Total | | 923,009 | 1% | 0% | 1.0 |<::/table::>

<a id='ad00b8d4-cfab-4910-807c-63cf79cd095d'></a>

Transportation and warehousing represents <2% of total DC employment

1 Full-time and part-time; Includes Wage and salary employment and Proprietors employment;
2 Forecasts from Moody's Analytics;
3 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole;
4 Other services is an especially large sector in DC as it includes NGOs and other institutions

<a id='0cba376a-79b8-425c-bbc1-8aad57dff67c'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics

<a id='4a205baa-b3af-4e73-965a-f48b4d7cba62'></a>

McKinsey & Company

<a id='571c7306-6659-4c99-b2d3-815c1d3795f3'></a>

4

<!-- PAGE BREAK -->

<a id='7b65f045-1203-4360-97a8-7c05187ee577'></a>

Transit and ground passenger transportation is by far the largest
employer within this sector in DC
Employment, growth, and specialization by subsector

<a id='31d2b854-1a76-4f7d-9f9e-ec6a1bbfb222'></a>

<::table::>| Subsector | Size Jobs, 2019¹ | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %² | Specialization Jobs LQ³ ||---|---|---|---|---|| Transit and ground passenger transportation⁴ | 10,156 | 18% | -4% | 1.0 || Couriers and messengers | 1,635⁵ | NA⁶ | 1% | 0.3 || Rail transportation | 1,580 | -2% | -4% | 2.0 || Scenic and sightseeing transportation | 662 | 9% | -4% | 2.8 || Support activities for transportation | 394 | 18% | -1% | 0.1 || Truck transportation | 375 | 5% | -1% | 0.0 || Air transportation | 91 | -2% | -3% | 0.0 || Warehousing and storage | 69 | NA⁶ | 2% | 0.0 || Water transportation | 30 | NA⁶ | -3% | 0.1 || Transportation and warehousing (total) | 15,145 | 13% | -3% | 0.4 <::/table::>

<a id='19f51a2f-d7da-40dd-9dd6-fa7c48e41f7a'></a>

1. Full-time and part-time; Includes Wage and salary employment and Proprietors employment; Subsector jobs may not add up 100% to total due to data suppression
2. Forecasts from Moody's Analytics
3. Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole
4. Includes transit networks such as WMATA and rideshare such as Uber and Lyft, etc.
5. 2018 data (2019 data suppressed)
6. Historical data points suppressed

<a id='1bf4c835-1cb2-4293-9bd7-06ef6ef1130a'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics

<a id='f44739a5-f38e-4c97-b190-6cd5248c8819'></a>

McKinsey & Company

<a id='073ade26-a1fa-4a86-b56e-42230e1aa1e6'></a>

5

<!-- PAGE BREAK -->

<a id='a7043b1b-160d-4e39-a3a5-7263648e29cf'></a>

Top Transportation occupations employ a majority of Black workers, and are at highest risk of displacement from automation

<a id='2c064141-0b9d-4636-8147-b127dc19a15f'></a>

White Black or African American Latinx Other¹

Top 10 Transportation and warehousing occupations by number of jobs within industry in DC¹ Thousand, 2019

<::transcription of the content
: chart::>

*   All top roles (except operations managers) have a higher share of Black workers than DC as a whole, which is 44% Black and 37% White (both non-Latinx)
*   These jobs all require a **high school diploma**, except for heavy truck drivers (certificate) and operations managers (Bachelor's)
*   In the medium term, the District can work towards **upskilling** workers from high automation jobs to those with less risk and higher wages

<a id='7b7c64be-ad39-44b8-b926-37d769750ac2'></a>

1. Asian, American Indian or Alaska Native, Native Hawaiian or Other Pacific Islander, Two or More Races; does not include all "Proprietors employment", which includes many small business owners and contractors
2. Dark = lowest risk of automation; preliminary analysis
3. Taxi drivers and chauffeurs used for automation analysis
4. Transportation attendants used for automation analysis

<a id='854ef546-28ff-42c0-8ac9-7dbd8c28c917'></a>

Source: EMSI; Bureau of Labor Statistics (BLS); McKinsey Global Institute (MGI)

<a id='704d1f44-a185-49fb-9d26-c6f8b226f9b9'></a>

McKinsey & Company

<a id='20a6c1ee-3313-4d88-9add-c71f4f8006ee'></a>

6

<!-- PAGE BREAK -->

<a id='924fb107-8324-4942-b427-1b1690ec33c0'></a>

Contents

<a id='49d08475-4963-4fba-bba3-3f2cc26dd59d'></a>

Baseline Conditions
Challenges and trends
Opportunities and best practices
Appendix

<a id='b33f2f70-48c4-49af-96c1-b59b0381b09f'></a>

McKinsey & Company

<a id='cdce18ad-c3b0-4395-895c-f65eb7f9e840'></a>

7

<a id='15523541-161b-4084-920a-a7db0a2310de'></a>

Last Modified 7/13/2020 6:00 PM Eastern Standard Time

<a id='67b9349f-8e5d-4242-8faf-92eed8c1832a'></a>

Printed

<!-- PAGE BREAK -->

<a id='09bf50a0-6891-4953-b1bc-908cf9c16cdb'></a>

Preliminary, proprietary, pre-decisional Non-exhaustive

<a id='89efad65-59af-4046-931b-6f91e19402b7'></a>

Mobility in DC: Five core challenges will shape the future of the sector and its ability to support broader economic competitiveness

<a id='0039e1f1-6272-4cf8-b04a-3bb9465264f5'></a>

<table><thead><tr><th>Challenge</th><th>A – Pre-COVID-19 trends</th><th>B – Impacts of COVID-19</th></tr></thead><tbody><tr><td>1<br>$<br>Health and<br>viability of transit</td><td>Strong existing transit base with declining ridership levels<ul><li>34% of workers commute by public transit (3rd highest among large US cities) and 4% of workers commute by bicycle (2nd highest)</li><li>15% and 20% decline in rail and bus ridership from 2011-19</li></ul></td><td>Significant transit ridership drop and funding gaps<ul><li>38% and 13% Metrobus and Metrorail ridership compared to pre-COVID levels as of end of Summer</li><li>~$250 million budget gap forecasted by WMATA through end of FY</li><li>5% decline in Trade, transportation, and utilities jobs (Aug '19-20)</li></ul></td></tr><tr><td>2<br>/\<br>Mitigating<br>Congestion and<br>its impacts on<br>productivity</td><td>Congestion, long commute times and increased TNCs<ul><li>3rd in yearly delays per auto commuter among large metros (~$2K annual cost of congestion per commuter)</li><li>3/4 of public transit riders and 1/2 of drivers face daily commutes over 30 minutes</li></ul></td><td>Short-term congestion decline, rebound expected; rise of telework<ul><li>3% increase in driving demand since the start of the pandemic</li><li>55% of executives said most (60-100%) office employees will work remotely at least one day a week post-COVID-19<sup>1</sup></li></ul></td></tr><tr><td>3<br>Managing the<br>curbside</td><td>Pressure on curb from TNCs, e-commerce and curbside delivery<ul><li>10,000 new rideshare drivers added annually (2014-17) in the D.C. metro area</li><li>98% increase in e-commerce sales from 2014 to 2019<sup>1</sup></li></ul></td><td>Continued rise of e-commerce, with new uses for the curb<ul><li>32% increase in e-commerce sales from 2020 Q1 to Q2<sup>1</sup></li><li>81% of 685 poll respondents support "streeteries" post-COVID</li></ul></td></tr><tr><td>4<br>Ensuring equity<br>in transportation<br>and transit access</td><td>Unequal transit access among communities of color<ul><li>39% of Black residents in low-income neighborhoods lack access to high frequency transit</li><li>33.7 minutes is the average commute time for Black workers, longest among racial groups</li></ul></td><td>Unequal transit access for essential workers<ul><li>62% of jobs requiring less formal training, such as drivers and clerks, can be reached by residents with applicable skills (compared to 72% for high-skill jobs and residents)</li><li>50% of Health technologists (example occupation) in low-income neighborhoods lack access to high frequency transit</li></ul></td></tr><tr><td>5<br>Ensuring safety</td><td>Lagging safety outcomes, most notably for cyclists<ul><li>4.3 bicycling fatalities per 1M population, higher than San Francisco, Seattle, Chicago, New York, Boston, and others</li><li>2nd highest share of bicycle commuters yet 15th and 27th city in number of miles of protected and unprotected bike lanes</li></ul></td><td>Increased demand for walking and biking: safety critical<ul><li>5% increase in biking and walking and 1% increase in shared micromobility expected immediately in the "new normal"<sup>1</sup></li></ul></td></tr></tbody><tfoot><tr><td colspan="3">1. US statistic</td></tr></tfoot></table>

<a id='73ef4dbc-277c-43d3-839e-48e4a381b001'></a>

Source: US Census; WMATA, Regional Reopening Plans; PwC "US Remote Work Survey"; Texas A&M, 2019 Urban Mobility Report; Apple Mobility Trends Report; WUSA9; NHTSA Traffic Safety Facts; McKinsey Center for Future Mobility; Metropolitan Policy Program at Brookings; Barred in DC Twitter poll, accessed through WUSA9; BLS-Current Employment Statistics (CES); DCist

<a id='4abf7d95-4879-495c-8969-2b47e491ec1c'></a>

McKinsey & Company

<a id='e874ce1b-1db5-4a9b-9033-daa12c6a7cb9'></a>

8

<!-- PAGE BREAK -->

<a id='e7a351ec-4e74-4dcf-bbc2-e47383054d60'></a>

1b: WMATA has seen record low ridership that is just beginning to

<a id='34077401-f21b-46ce-b7eb-6e41ec263d8b'></a>

recover
WMATA monthly ridership during COVID-19,
% of 2019 ridership, Jan-Jul 2020
<::Line chart showing WMATA monthly ridership during COVID-19 as a percentage of 2019 ridership from January to August 2020.
The x-axis represents months: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug.
The y-axis represents the percentage of 2019 ridership.

Legend:
- Metrobus (black line)
- Metrorail (blue line)

Data points for Metrobus:
- Jan: ~105%
- Feb: 110%
- Mar: 33%
- Apr: 17%
- May: ~18%
- Jun: 19%
- Jul: 33%
- Aug: 38%

Data points for Metrorail:
- Jan: ~100%
- Feb: 112%
- Mar: 49%
- Apr: 5%
- May: ~8%
- Jun: 9%
- Jul: 10%
- Aug: 13%

Vertical dashed lines indicate key events:
- Between Mar and Apr: "Initial regional lockdown"
- Between May and Jun: "Phase 1 reopening (DC)"
- Between Jun and Jul: "Phase 2 reopening (DC)"
: chart::>

<a id='e3b34968-d46f-4831-b5e9-0814508b220e'></a>

Source: WMATA, Regional Reopening Plans

<a id='2806e721-6f35-4c72-8677-7b3c5224b6a8'></a>

McKinsey & Company

<!-- PAGE BREAK -->

<a id='39ad9fe8-b82a-4367-9a14-b1479bb227d6'></a>

1b: Employment in Trade, transportation, and utilities declined by 5%, which was not as steep a decline as DC overall

<a id='69b86d30-26b6-48b5-b8b3-94899e1bab97'></a>

Change in employment by major industry from August 2019 to August 2020¹
% change

<a id='f72f6103-7583-495a-94e1-eafc35918304'></a>

<::Bar chart showing changes in various economic sectors for DC and US. The chart displays categories on the y-axis and numerical values on the x-axis, with separate bars and values for DC and US for each category.

| Category                                 | DC    | US    |
|:-----------------------------------------|:------|:------|
| Leisure and hospitality                  | -47   | -23   |
| Manufacturing                            | -8    | -6    |
| Total                                    | -7    | -7    |
| Financial activities                     | -6    | -1    |
| Education and health services            | -6    | -5    |
| Trade, transportation, and utilities     | -5    | -4    |
| Professional and business services       | -4    | -6    |
| Construction                             | 1     | -4    |
| Government                               | 2     | -3    |
: bar chart::>

<a id='aa970694-4df2-4d70-a948-b674477fc351'></a>

1. Available sectors with data shown here

<a id='5fda3df0-30b5-4404-a447-751c36474641'></a>

Source: Bureau of Labor Statistics (BLS) Current Employment Statistics (CES)

<a id='c52a28d8-9b01-4dd8-99a0-5066a7e0c423'></a>

McKinsey & Company

<a id='6f054531-e94d-4a9e-83a8-90f385409a88'></a>

10

<!-- PAGE BREAK -->

<a id='0e11b675-1d2b-428d-a2b4-1aa3811db41f'></a>

2a: DC faces relatively high congestion delays and costs
National Congestion Table – What congestion means to you, 2017

<a id='be90238e-250d-4888-a776-36e685481bfa'></a>

<table id="10-1">
<tr><td id="10-2"></td><td id="10-3" colspan="2">Yearly Delay per Auto Commuter</td><td id="10-4" colspan="2">Travel Time Index</td><td id="10-5" colspan="2">Excess Fuel per Auto Commuter</td><td id="10-6" colspan="2">Congestion Cost per Auto Commuter</td></tr>
<tr><td id="10-7">Urban Area</td><td id="10-8">Hours</td><td id="10-9">Rank</td><td id="10-a">Value</td><td id="10-b">Rank</td><td id="10-c">Gallons</td><td id="10-d">Rank</td><td id="10-e">Dollars</td><td id="10-f">Rank</td></tr>
<tr><td id="10-g">Very Large Average (15 areas)</td><td id="10-h">83</td><td id="10-i"></td><td id="10-j">1.35</td><td id="10-k"></td><td id="10-l">32</td><td id="10-m"></td><td id="10-n">1,730</td><td id="10-o"></td></tr>
<tr><td id="10-p">Los Angeles-Long Beach-Anaheim CA</td><td id="10-q">119</td><td id="10-r">1</td><td id="10-s">1.51</td><td id="10-t">1</td><td id="10-u">35</td><td id="10-v">4</td><td id="10-w">2,676</td><td id="10-x">1</td></tr>
<tr><td id="10-y">San Francisco-Oakland CA</td><td id="10-z">103</td><td id="10-A">2</td><td id="10-B">1.50</td><td id="10-C">2</td><td id="10-D">39</td><td id="10-E">1</td><td id="10-F">2,619</td><td id="10-G">2</td></tr>
<tr><td id="10-H">Washington DC-VA-MD</td><td id="10-I">102</td><td id="10-J">3</td><td id="10-K">1.35</td><td id="10-L">7</td><td id="10-M">38</td><td id="10-N">2</td><td id="10-O">2,015</td><td id="10-P">3</td></tr>
<tr><td id="10-Q">New York-Newark NY-NJ-CT</td><td id="10-R">92</td><td id="10-S">4</td><td id="10-T">1.35</td><td id="10-U">7</td><td id="10-V">38</td><td id="10-W">2</td><td id="10-X">1,947</td><td id="10-Y">4</td></tr>
<tr><td id="10-Z">Boston MA-NH-RI</td><td id="10-10">80</td><td id="10-11">6</td><td id="10-12">1.30</td><td id="10-13">19</td><td id="10-14">31</td><td id="10-15">7</td><td id="10-16">1,580</td><td id="10-17">8</td></tr>
<tr><td id="10-18">Seattle WA</td><td id="10-19">78</td><td id="10-1a">7</td><td id="10-1b">1.37</td><td id="10-1c">5</td><td id="10-1d">31</td><td id="10-1e">7</td><td id="10-1f">1,541</td><td id="10-1g">9</td></tr>
<tr><td id="10-1h">Atlanta GA</td><td id="10-1i">77</td><td id="10-1j">8</td><td id="10-1k">1.30</td><td id="10-1l">19</td><td id="10-1m">31</td><td id="10-1n">7</td><td id="10-1o">1,653</td><td id="10-1p">5</td></tr>
<tr><td id="10-1q">Houston TX</td><td id="10-1r">75</td><td id="10-1s">9</td><td id="10-1t">1.34</td><td id="10-1u">11</td><td id="10-1v">31</td><td id="10-1w">7</td><td id="10-1x">1,508</td><td id="10-1y">10</td></tr>
<tr><td id="10-1z">Chicago IL-IN</td><td id="10-1A">73</td><td id="10-1B">10</td><td id="10-1C">1.32</td><td id="10-1D">16</td><td id="10-1E">30</td><td id="10-1F">12</td><td id="10-1G">1,431</td><td id="10-1H">11</td></tr>
<tr><td id="10-1I">Miami FL</td><td id="10-1J">69</td><td id="10-1K">12</td><td id="10-1L">1.31</td><td id="10-1M">17</td><td id="10-1N">34</td><td id="10-1O">5</td><td id="10-1P">1,412</td><td id="10-1Q">12</td></tr>
<tr><td id="10-1R">Dallas-Fort Worth-Arlington TX</td><td id="10-1S">67</td><td id="10-1T">13</td><td id="10-1U">1.26</td><td id="10-1V">23</td><td id="10-1W">25</td><td id="10-1X">20</td><td id="10-1Y">1,272</td><td id="10-1Z">18</td></tr>
<tr><td id="10-20">San Diego CA</td><td id="10-21">64</td><td id="10-22">16</td><td id="10-23">1.35</td><td id="10-24">7</td><td id="10-25">24</td><td id="10-26">27</td><td id="10-27">1,584</td><td id="10-28">7</td></tr>
<tr><td id="10-29">Philadelphia PA-NJ-DE-MD</td><td id="10-2a">62</td><td id="10-2b">18</td><td id="10-2c">1.25</td><td id="10-2d">25</td><td id="10-2e">26</td><td id="10-2f">15</td><td id="10-2g">1,203</td><td id="10-2h">22</td></tr>
<tr><td id="10-2i">Phoenix-Mesa AZ</td><td id="10-2j">62</td><td id="10-2k">18</td><td id="10-2l">1.27</td><td id="10-2m">22</td><td id="10-2n">26</td><td id="10-2o">15</td><td id="10-2p">1,089</td><td id="10-2q">30</td></tr>
<tr><td id="10-2r">Detroit MI</td><td id="10-2s">61</td><td id="10-2t">20</td><td id="10-2u">1.24</td><td id="10-2v">28</td><td id="10-2w">25</td><td id="10-2x">20</td><td id="10-2y">1,129</td><td id="10-2z">25</td></tr>
</table>

<a id='a3a4e068-f759-4dd4-89a0-d0be44ba1779'></a>

Source: Texas A&M, 2019 Urban Mobility Report

<a id='7bacf660-a578-41cd-b72e-e35cee064b69'></a>

McKinsey & Company

<a id='ffb2cf16-9b8d-49c8-91bc-7ef1d1e88629'></a>

11

<!-- PAGE BREAK -->

<a id='d438dfdd-4e9d-4709-8c56-e819396b718a'></a>

**2a: Three-quarters of public transit riders and half of drivers face daily commutes over 30 minutes**---

<a id='34b86f0e-89a7-4caa-b02f-678af3a48a03'></a>

51% of DC
automobile
commuters have
trips longer than
30min

<::
Chart: Commute time by automobile, 2017 (with automobile icon)
Y-axis: Percent of automobile commuters
X-axis: Commute time in minutes
- <15 mins: 12%
- 15-29 mins: 38%
- 30-44 mins: 32%
- >45 mins: 19%

Chart: Commute time by public transportation, 2017 (with train icon)
Y-axis: Percent of public transit commuters
X-axis: Commute time in minutes
- <15 mins: 2%
- 15-29 mins: 22%
- 30-44 mins: 41%
- >45 mins: 35%
: chart::>

76% of public
transportation
users have
commutes
over 30
minutes

Travel time

<a id='cd6dbdfc-6ead-4b14-ae53-f8b7121a91a8'></a>

Walking and
biking are most
common for
commutes less
than 30min

<::
Two bar charts displaying commute time distribution by method in 2017.

Chart 1: Commute time by walking, 2017
Description: A bar chart showing the percentage of walking commuters by travel time.
X-axis label: Travel time
Data:
- <15 mins: 36%
- 15-29: 44%
- 30-44: 14%
- >45 mins: 6%

Chart 2: Commute time by other methods, 2017
Description: A bar chart showing the percentage of other transit commuters by travel time.
X-axis label: Travel time
Data:
- <15 mins: 23%
- 15-29: 51%
- 30-44: 21%
- >45 mins: 5%
: chart::>

<a id='7ed3a5b4-da2d-4f21-97ff-0e5f5849fde5'></a>

1. Other includes commuters using bicycles, motorcycles, taxicabs, etc.

<a id='3fdfbb64-1510-444e-904b-e4ca32a2464a'></a>

Source: US Census - American Community Survey; WalletHub

<a id='8250c5ec-a6d9-439d-a1d8-e1ef17fc7823'></a>

Metro DC commuters mode of transit, % of commuters using specific mode of transit, 2016<::Metro DC commuters mode of transit pie chart, 2016: Automobile 80%, Public transit 14%, Walk 4%, Other 2%: chart::>• DC ranked **86th of 100** cities in WalletHub's “**Best & Worst Cities to Drive in**” in 2020• **14% of DC metro commuters use public transit, which is significantly lower than automobile usage, but still one of the highest rates of public transit usage** among metro areas• As a city, Washington, DC has the **3rd highest public transit usage** in the US (34%), after New York and San Francisco

<a id='92ff5905-d5a6-47e6-835d-4d765e0b309f'></a>

McKinsey & Company

<a id='0f071ef2-5b0a-45b6-8910-5692fc072181'></a>

12

<!-- PAGE BREAK -->

<a id='6c002075-e79a-4928-87a7-7e150e1ffc2b'></a>

2b: Transit demand is down significantly but driving is up since the start of the pandemic

<a id='21c855e6-5017-4514-8ef7-c46fcb7fff87'></a>

<::line chart::>Mobility trends, Change in routing requests since January 13, 2020. The chart displays three lines representing different modes of transport: Driving (red, +3%), Walking (orange, -15%), and Transit (purple, -55%). The y-axis ranges from -80% to +60%, indicating the percentage change. The x-axis shows months from January to October. All three lines show high volatility in Jan-Feb, then a sharp drop in March, indicating a significant decrease in mobility. Driving and Walking then show a gradual recovery from April to October, with Driving generally returning to pre-March levels and Walking remaining below. Transit remains significantly suppressed throughout the entire period after March, hovering around -60% to -50%::>

<a id='95adb31f-0495-4ae8-8e9c-ec86f02cf334'></a>

Source: Apple Mobility Trends Report

<a id='c9578d3f-8aa2-4120-a274-4f4907e48322'></a>

McKinsey & Company

<a id='99471fc3-9e32-4e03-a1bf-69fdf9775dae'></a>

13

<!-- PAGE BREAK -->

<a id='2e45198e-69c7-40cc-8461-6f0d01bdae21'></a>

**2b: ~50% of white collar workers are teleworking, and many will continue to work remotely post-COVID part-time**
Teleworking is a challenge and opportunity for transportation systems
---


<a id='f9d9aba0-1d73-4b28-9385-157dfb520e2b'></a>

Share of teleworkers by industry in the United States, May 2020 to September 2020
% of workers within industry

<a id='be1ad860-bc37-4318-a454-d28e85231ebd'></a>

Educational services
Finance and insurance
Professional and technical services
Information
Public administration
Real estate and rental and leasing
Arts, entertainment, and recreation
Utilities
Mining, quarrying, and oil and gas extraction
Wholesale trade
Manufacturing
Other services
Health care and social assistance
Management, administrative, and waste services
Retail trade
Construction
Transportation and warehousing
Accommodation and food services

<a id='1c69221c-4c59-440c-b492-3f5324f2de37'></a>

<::Horizontal bar chart titled "May 2020" showing 18 bars with the following values (from top to bottom): 76, 67, 64, 61, 46, 42, 38, 37, 32, 31, 30, 28, 25, 24, 17, 15, 12, 8.

Horizontal bar chart titled "September 2020" showing 18 bars with the following values (from top to bottom): 41, 53, 50, 45, 33, 26, 21, 27, 22, 22, 20, 15, 16, 14, 9, 8, 8, 5.
: bar chart::>

<a id='1edb0284-58b7-4c5d-a5c0-4400bafc4c81'></a>

According to PwC's US Remote Work Survey:
*   **55%** of executives said most (60-100%) of office employees will work remotely at **least one day a week** post-COVID-19
*   **72%** of surveyed office workers would like to work remotely at **least two days per week**

According to Upwork's The Future of Remote Work
*   **~20%** of the workforce is likely to continue **working remotely** on a **full-time** basis
*   **~33%** will continue doing so **part-time**

<a id='e730e96d-455a-4e3e-973f-ab902b1fd5ee'></a>

The rise in telework presents challenges and opportunities for transit, as people may decide to live further from their employer's offices (swapping a longer, occasional commute for more space), commute to work less times per week, and take more local trips throughout the day during "off-peak" hours

<a id='839fce54-e6c4-40a5-b463-3bf41be7e040'></a>

1. Data from BLS - CPS; Full description: Employed persons who teleworked or worked at home for pay at any time in the last 4 weeks because of the coronavirus pandemic

<a id='a6fd6e28-463a-43cf-a8b0-12be3ba4eb12'></a>

Source: Bureau of Labor Statistics (BLS) - Current Population Survey (CPS); PwC - US Remote Work Survey; Upwork - The Future of Remote Work; government technology magazine

<a id='7359a2b8-dd4e-4a29-b33f-ef0017ebca9f'></a>

McKinsey & Company

<a id='30297367-ee8a-4b69-89e2-3a8d2bc85894'></a>

14

<!-- PAGE BREAK -->

<a id='8376fd82-2263-4160-91fa-3497f677b019'></a>

4a: Transit commutes correlate with income and race, though many workers in low-income neighborhoods work outside DC<::figure: A series of four choropleth maps of Washington D.C. are displayed side-by-side, each showing different demographic or commute-related data by neighborhood.

Map 1: Commute time to work via public transportation
Sub-title: % commuters traveling >45 mins
Legend:
- <20%
- 20-40%
- 40-60%
- 60-80%
- >80%
- No data (gray)
This map shows areas with higher percentages of commuters traveling over 45 minutes by public transportation concentrated in the eastern and southeastern parts of the city.

Map 2: Race
Sub-title: % Black population
Legend:
- <20%
- 20-40%
- 40-60%
- 60-80%
- >80%
- No data (gray)
This map indicates a high percentage of Black population (darkest red) in the eastern and southeastern regions of DC, aligning with areas of longer commute times. An accompanying text box states: "0.6 correlation between Black population and commute time".

Map 3: Household income
Sub-title: % income <$35K
Legend:
- <20%
- 20-40%
- 40-60%
- 60-80%
- >80%
- No data (gray)
This map illustrates areas with a high percentage of households earning less than $35K (darkest red) predominantly in the eastern and southeastern parts of the city.

Map 4: Place of work
Sub-title: % work in DC
Legend:
- <60%
- 60-70%
- 70-80%
- 80-90%
- >90%
This map shows that a higher percentage of residents work within DC (darker red) in the central and northwestern areas, while lower percentages (lighter red) are observed in some eastern and southern neighborhoods.::>

<a id='771f603a-fef9-49a9-954b-c357e55bbfc1'></a>

Source: US Census

<a id='452dded8-f5af-463a-a717-498012da502e'></a>

McKinsey & Company

<a id='52e55137-287c-4d6e-9186-f7c968c438c4'></a>

15

<!-- PAGE BREAK -->

<a id='a847f35b-c9a7-4dda-bca0-1a374ac4ba2c'></a>

**4a: Swathes of low income districts are under-served by high-frequency transit**

<a id='353767ea-668d-4409-929d-e1bd03979dcc'></a>

Population by household income% income <$35K<::map::>A map of a geographical area, likely Washington D.C., displaying population by household income, high-frequency bus lines, and metro stops. The map uses a color scale to represent the percentage of households with income less than $35,000.Legend:High-frequency bus lines² (represented by light blue elongated shapes)Metro stops³ (represented by yellow circular shapes)Percentage of income <$35K:<20% (lightest orange)20-40% (light orange)40-60% (medium orange)60-80% (dark orange)>80% (darkest red/brown)No data (gray)Footnotes:1. Neighborhoods where >40% of households earn <$35K per year; assumption that population in Block Groups is dispersed evenly2. Defined as bus lines with service ~4+ times every hour (~16% of routes); this was estimated by averaging the number of buses on all DC-based routes during 3 sample hours in the day: 8-9 AM, 2-3 PM, and 5-6 PM using WMATA timetables; walking distance of ¼ mile created around bus lines3. Walking distance of ½ mile created around metro stations::>

<a id='41991dcf-ecab-4c04-8840-f34b940ecd7c'></a>

Source: US Census; Open Data DC; WMATA District of Columbia Timetables

<a id='623a097d-81df-406f-b735-5f016b6f16cd'></a>

Share of residents more than  mile from high-frequency buses and  mile from metro stations in low-income neighborhoods
% by selected characteristics

<a id='f48584c8-43ae-48a0-8359-bf767f2a8eb4'></a>

<::Race
: bar chart::>
- Latinx: 21
- Asian: 15
- Black: 39
- White: 18


<a id='1faa8bae-2546-470e-af19-c775d1ac870e'></a>

Occupation<::Health technologists and technicians: 50Protective service occupations: 44Installation maintenance and repair occupations: 39Community and social service occupations: 38Healthcare support occupations: 38Construction and extraction occupations: 36Personal care and service occupations: 36: bar chart::>

<a id='8ca8c2e6-43d0-4395-a6be-2679199f1074'></a>

McKinsey & Company

<a id='3aae52ac-7f4e-4ac6-875f-fc1f7137d9f1'></a>

16

<!-- PAGE BREAK -->

<a id='bffc3b4e-c4ff-4d26-b027-11d390146dca'></a>

4b: Southeast DC has a disproportionate share of essential workers

<a id='6192e04f-01cd-4079-b578-2f08b325074a'></a>

Neighborhoods where essential workers live¹
% share of workers
in essential industries
<::map: The map displays an area divided into numerous neighborhoods, each colored according to the percentage share of workers in essential industries. A legend indicates the color-coding for these percentages:
<30% (lightest shade of red)
30-40% (light red)
40-50% (medium red)
50-60% (dark red)
>60% (darkest shade of red)
The map shows a general trend where some central and northern areas have lower percentages, while southern and eastern areas show higher concentrations of essential workers.::>
1. Essential industries include: Construction, Educational services, Finance and insurance, Information, Health care and social assistance, Public administration, Transportation and warehousing, Utilities

<a id='1c815386-e200-4c0a-9250-be3c2c48de70'></a>

Source: US Census; Government of the District of Columbia

<a id='62cc07ae-340a-4d87-bb84-8fba714b1317'></a>

<::Neighborhoods where Healthcare support workers live¹: choropleth map::> % share of Healthcare support workers. The map displays neighborhoods colored by the percentage of healthcare support workers living there, with a legend indicating the ranges:
<3% (lightest shade)
3-6%
6-9%
9-12%
>12% (darkest shade)

An inset map highlights Southeast DC, where almost all neighborhoods are at least 80% Black (represented by dark red shades on the map).

<a id='f2c5c900-38c1-4dd1-8159-d599e2e97246'></a>

McKinsey & Company

<a id='37f07884-c5c0-4f82-80de-e66f1888d1fe'></a>

17

<!-- PAGE BREAK -->

<a id='5aab192f-9558-4b64-9d37-9e75b4a12380'></a>

5a: Among peers, Washington DC has the highest share of cyclist fatalities

<a id='92e91f7e-50bf-48a8-b0c5-61b698c1d26c'></a>

<::Fatalities per capita, selected large city peers, 2018. This chart displays two horizontal bar graphs side-by-side, comparing pedestrian and bicyclist fatalities per capita across several large cities in 2018. The city of Washington is highlighted in blue in both charts.

**Pedestrians, per 100K population**
| City          | Fatalities |
| :------------ | :--------- |
| Chicago       | 1.7        |
| San Francisco | 1.6        |
| Washington    | 1.6        |
| Baltimore     | 1.5        |
| New York      | 1.3        |
| Boston        | 1.3        |
| Seattle       | 1.1        |

**Bicyclists, per 1M population**
| City          | Fatalities |
| :------------ | :--------- |
| Washington    | 4.3        |
| San Francisco | 3.4        |
| Seattle       | 2.7        |
| Chicago       | 2.2        |
| New York      | 1.1        |
| Baltimore     | 0          |
| Boston        | 0          |
: bar chart::>

<a id='0ed6be31-57e9-4d1b-9ac8-95ddcc5edfd9'></a>

1. Map from WUSA9 report: "These are DC, Maryland & Virginia's most dangerous roads for cyclists & pedestrians"

<a id='e4838d13-97c1-4769-b984-f40136af674a'></a>

Source: NHTSA Traffic Safety Facts; WUSA9

<a id='7334de0b-053b-40f4-a0f5-fc5e51353b5e'></a>

Bicycle collisions, 2016-19¹<::A map of Washington D.C. showing bicycle collision density from 2016-2019. A color legend above the map indicates collision frequency, with light pink representing 2 collisions and dark red representing 16 collisions. The map highlights various streets in shades of red, indicating areas with higher collision rates. Prominently marked streets include U Street Northwest, 14th Street Northwest, 15th Street Northwest, 16th Street Northwest, 9th Street Northwest, 6th Street Northwest, 22nd Street Northwest, I Street Northwest, and E Street Northwest. Some of the most dangerous roadways in DC for cyclists are along U Street NW, 14th Street NW, and Dupont Circle.: map::>

<a id='11d35a3b-5628-4928-aaaa-8796d93ccfe6'></a>

McKinsey & Company

<a id='cd7c7091-4217-45ea-99fd-23b186a1fc28'></a>

18

<!-- PAGE BREAK -->

<a id='dd86be2c-2ba9-40fc-b4a4-c3b0046c0d5a'></a>

5a: While DC has one of the highest shares of bicycle commuters, it
has less bike lanes than many peers
US cities by share of bike commuters (%) and bike lanes in number of miles

<a id='cc54e72d-1fea-47cf-9517-f11dfdb6115f'></a>

<::Table: Cities with working population >250K, their share of bicycle commuters, miles of paved public paths, miles of protected bike lanes, miles of unprotected bike lanes, miles of bike infrastructure per square mile, and state passing law. Also includes a note about Washington, DC.|||Cities with working population >250K|Share of bicycle commuters, %¹|Miles of paved public paths²|Miles of protected bike lanes²|Miles of unprotected bike lanes²|Miles of bike infrastructure per square mile²|State passing law³|||Portland|5.2|94|29|208|2.5|"Safe distance"⁴|||Washington|4|60|12⁶|72|2.3|3 feet|||San Francisco|3.8|70|31|153|5.4|3 feet|||Seattle|3.7|48|10|98|1.9|3 feet + change lanes⁴|||Boston|2.5|53|7|102|3.4|"Safe distance"⁵|||Denver|2.4|65|12|330|2.7|3 feet|||Tucson|2.3|132|6|330|2.1|3 feet|||Philadelphia|2.1|Not Reported|24|237|1.9|4 feet|||Chicago|1.5|42|86|99|1.0|3 feet|||Atlanta|1.3|42|9|47|0.7|3 feet|||Note: Washington, DC has the **2nd** highest share of bicycle commuters yet is the **15th** and **27th** city in number of miles of protected and unprotected bike lanes (of 50 large US cities)::>

<a id='80fab111-3187-43e3-a149-b220b508b774'></a>

1. Data from the US Census, Commuting Characteristics by Sex, by Place, 2019 ACS 1-Year Estimate
2. Data from The League of American Bicyclists, "Bicycling and Walking in the United States, 2018 Benchmarking Report"
3. Data from the National Conference of State Legislatures (NCSL) "Safely Passing Bicyclists Chart", 2020
4. Require motorist to completely change lanes when passing a bicycle if there is more than one lane in the same direction
5. A speed less than 35 mph and a "safe distance" means a distance that is sufficient to prevent contact with the person operating the bicycle if the person were to fall into the driver's lane of traffic.
6. Updated from DDOT

<a id='afa51679-65f7-4adc-a25a-74e32f322969'></a>

Source: US Census; The League of American Bicyclists, "Bicycling and Walking in the United States, 2018 Benchmarking Report"; National Conference of State Legislatures (NCSL)

<a id='a68b3775-2b2e-4199-962a-97b9f69f920b'></a>

McKinsey & Company

<a id='3346172e-7c0b-4c65-a42b-947197573d9a'></a>

19

<!-- PAGE BREAK -->

<a id='19c7ffc4-91b4-4e4c-84d1-aa48dcfb93b8'></a>

5b: Walking and biking expected to increase 5% in the US post- COVID-19, and micromobility set to rise as well

<a id='14bbd265-140f-450d-915c-58841a59ba66'></a>

Results of wave 1 (May 9-18), wave 2 (May 27-29), wave 3 (June 16-18), wave 4 (July 15-17), and wave 5 (Sep 2-4)

<a id='ef8e2034-b380-4de9-b27d-44c89eca6bde'></a>

Change of transportation modes when returning to "next normal" vs. before COVID-19¹,²
Delta of responses for return to "next normal" vs. before COVID-19 outbreak, in percent points

<a id='dd91934c-ab5e-491f-803a-5e60f7deba00'></a>

<::Grouped bar chart showing values for different transportation modes across various regions/countries.

**Transportation Modes (with icons):**
- Car icon: Private car
- Bus icon: Public transport
- Person on bicycle icon: Walking or biking with private bike
- Scooter icon: Shared micromobility (e.g., e-scooter, e-bike)
- Car with three dots above icon: Car sharing (e.g., ShareNow)
- Taxi icon: Ride hailing (e.g., Uber, Lyft, taxis)

**Table Data:**
| Region/Country | Private car | Public transport | Walking or biking with private bike | Shared micromobility (e.g., e-scooter, e-bike) | Car sharing (e.g., ShareNow) | Ride hailing (e.g., Uber, Lyft, taxis) |
|---|---|---|---|---|---|---|
| Global³ | 0.5 | 0.2 | 5.2 | 1.6 | 1.4 | 1.1 |
| Flag of United States | 0.9 | -0.7 | 5.0 | 0.6 | 0.2 | 0.1 |
| Flag of United Kingdom | 0.5 | -2.7 | 8.4 | 0.9 | 0.6 | 0 |
| Flag of Germany | -0.1 | 1.3 | 5.5 | 1.4 | 1.0 | 0.8 |
| Flag of Italy | 0.9 | 0.3 | 6.1 | 4.1 | 2.8 | 2.9 |
| Flag of France | 0.3 | 1.1 | 5.9 | 1.2 | 1.2 | 0.9 |
| Flag of China | 0.7 | 2.3 | 2.1 | 4.1 | 4.0 | 3.8 |
| Flag of Japan | 0.2 | -0.2 | 2.7 | -0.6 | -0.1 | -0.2 |
: bar chart::>

<a id='c66073d5-d131-4a0a-9c2a-a0ecc291ea53'></a>

1 Q: Before/today/when you return to "next normal", how often did/do you/do you expect to use the following modes of transportation?
2. Mode usage once or more than once per week
3. US, UK, Germany, Italy, France, China, Japan

<a id='786bd05e-f78f-45ee-841a-567e85ed5340'></a>

Source: McKinsey Center for Future Mobility

<a id='13963245-bd17-44a7-b3f3-7d3d5ce52b0d'></a>

McKinsey & Company

<a id='6b4b3a0d-b520-45ed-8568-9d5aa9dc1f71'></a>

20

<!-- PAGE BREAK -->

<a id='ea16bcfd-21cc-4625-a226-dcb95e519020'></a>

Contents

<a id='e186dbc1-1b0e-4307-b9b7-ae03cb2a4f3d'></a>

Baseline Conditions

<a id='60e91231-3c49-47dc-b58f-32e3849a323c'></a>

Challenges and trends

<a id='2ec90768-4a27-460a-be5b-1fc4d5072b67'></a>

Opportunities and best practices

<a id='f472dc04-739e-4e3e-bc39-e1e6acc17f22'></a>

Appendix

<a id='624c0eb4-e250-4606-9606-f8a4c051ad35'></a>

McKinsey & Company

<a id='858dcfe7-1be9-42b6-a9ab-569dd93ad727'></a>

21

<a id='46c8f557-f073-4559-9b10-1380070be528'></a>

Last Modified 11/3/2020 6:00 PM Eastern Standard Time

<a id='4c05e199-dbee-4360-9056-69590f0ecbbf'></a>

Printed

<!-- PAGE BREAK -->

<a id='cc8800f4-db81-442b-998b-66d8e9cd7070'></a>

Preliminary, proprietary, pre-decisional Non-exhaustive

<a id='f365421c-d94b-4a4a-9a60-a300d2458ada'></a>

Mobility in DC: opportunities to enhance transportation and economic outcomes across DC

<a id='daa67513-3a46-4500-9943-842b3a1f598a'></a>

Deep dive in Appendix

<a id='831826f3-4db1-4fc5-9318-1f12fed33aeb'></a>

Challenge Opportunities Details Best practices
1
<::dollar sign icon::> Reaffirm commitment to transit solutions and
robust mix of mobility options A Increase **integration** and **agility** of existing networks for long-term
sustainability and financial viability
B View long-term transit health as integrated with **land use solutions** that
increase density, affordability, and access to transit <::BVG Jelbi logo::>
<::Minneapolis 2040 logo::>
2
<::road icon::> Increase **supply of mobility solutions** in connection
with **managing congestion and demand** through
pricing C Adopt mobility solutions based on **dynamic pricing**
D Invest in streetscape to support **walking, cycling-, and micro-mobility**
E Develop **employer-back** transit solutions <::Ministry of Transport Connecting Singapore logo::>
<::Paris logo::>
<::Seattle Office of Labor Standards logo::>
3
<::stacked buildings icon::> Adopt new **regulations, uses,** and **pricing** scheme F Dynamically **price** on-street parking to reduce congestion and raise
revenues
G Facilitate **technological** solutions to improve **delivery management** <::LA Express Park logo::>
<::Starship logo::>
4
<::two people icon::> Close **equity gaps** through **new mobility options**
(e.g., microtransit) and target traditional fixed-route
**high-frequency routes** targeting transit “deserts” H Provide **subsidies** for low-income residents for transit usage
I Leverage **microtransit** or **ride-sharing partnerships** for new routes
J Review and redesign traditional **fixed-route high-frequency** routes
targeting **underserved communities** <::Orca Lift logo::>
<::Via logo::>
<::Go Boston 2030 logo::>
5
<::bicycle icon::> Adopt comprehensive **Vision Zero** goals to enhance
safety outcomes K Fastrack **Vision Zero** initiatives (e.g., District-wide reduction of speed
limits, streetscape redesigns) <::Stockholms stad logo::>

<a id='bf68d45f-4287-4abc-ba7f-214b48048cbc'></a>

McKinsey & Company

<a id='de7f7e77-0f55-4630-af1e-0ce1040db147'></a>

22

<!-- PAGE BREAK -->

<a id='78ee6b58-64eb-4dc3-a966-425d736cfb5c'></a>

<::logo: Jelbi
BVG Jelbi
The logo features a yellow heart with "BVG" inside, next to the word "Jelbi" in black sans-serif font.::>

<a id='8b280ea4-9e08-477f-9f45-ad7a0232e7a3'></a>

1a: Increase integration and agility of existing networks for long-term sustainability and financial viability
---


<a id='32d0f364-76a9-4672-af42-7633524ec354'></a>

Description

* Develop multimodal system that integrates public transit, rideshare, micromobility
* Streamline multimodal transit usage through one-app booking and payments (e.g. Denver residents can use Uber's app to purchase tickets for the local bus and train transit system, RTD)
* Call on regional transit providers (WMATA, MARC, VRE, Circulator) to improve regional integration (e.g., coordinated schedules, increased Union Station capacity and frequency, fare integration, free transfers) and expand nights / weekend service for key residential and employment zones

<a id='e6c4a82c-f002-4dbb-b340-46479d53bdf8'></a>

<::logo: RTD and Uber
RTD
Uber
Two logos are displayed, one with white text "RTD" on a red background and another with white text "Uber" on a black background, set against a blurred cityscape at night::>

<a id='14fe20e9-600e-4584-915f-1bd9eb1a24ea'></a>

Case example

Berlin

*   In 2019, Berlin introduced a Mobility as a Service (MaaS) app called Jelbi, in partnership with mobility platform Trafi
*   Goal of Berlin public transport authority BVG's smart mobility strategy to connect every shared mobility offer in the German capital into a single marketplace for its residents to provide an attractive alternative to private cars
*   Jelbi integrates all public and shared mobility options, including bike sharing, taxis, carpooling, and public transportation
*   Allows Berliners to register one time for all existing and to-be-integrated mobility services, receive messages from transit (e.g. regarding closures or safety), plan intermodal trips (lowest time, cost), receive real time public transport information, and buy any type of ticket (no need to switch between apps)
*   Employers can provide employee travel allowances on the app

Impact:

*   In the first year of Jelbi:
    *   ~5% of Berliners have used Jelbi
    *   15,500+ vehicles available
    *   51% public transport
    *   49% share mobility

<::Mobile phone screen showing the Jelbi app interface.

Top bar with back arrow and 'Where to?' title.

Input fields for 'Potsdamer Platz' and 'Alexander Platz' with an up/down arrow icon between them.

'Leave now?' with a clock icon.

Below this, a list of mobility options with travel times and prices:

*   Icon with 'U U2' and a star: 18 min, €2.90 (09:41-10:01)
*   Icon with a star: 21 min, €4.99 (09:41-10:02)
*   Icon with 'M 1' and a star: 23 min, €1.00 (09:41-10:03)
*   Icon with a star: 23 min, €4.80 (09:41-10:04)
*   Icon with 'M 1' and a star: 19 min, €2.30 (09:41-10:00)
*   Icon with 'VW Polo' and a star: 22 min, €4.12 (09:41-10:03)
: figure::>

<a id='61cdacde-0382-43f7-a85a-d765f75dc744'></a>

Source: The Verge; Unsense; BVG Jelbi website

<a id='3b8df8f2-99cb-4bb9-80df-8a0c0219b240'></a>

McKinsey & Company
McKinsey & Company

<a id='b1c55dba-a7c9-4a7a-9d41-9aafdc3ffd50'></a>

23

<!-- PAGE BREAK -->

<a id='86790625-ea59-447f-84c3-dc641d61e282'></a>

1b: View long-term transit health as integrated with land use solutions that increase density, affordability, and access to transit

<a id='702d408e-8628-4a82-b422-33cde2884ce6'></a>

<::minneapolis | 2040
: figure::>

<a id='482a00fe-7b54-4545-af81-22f90bd65606'></a>

# Description
*   Cities and states such as Minneapolis, Austin, Seattle, Montgomery County MD, Oregon, and more have recently begun implementing changes to land use policy to encourage housing affordability
*   20% of the District's surface area is occupied by single-family units, which increases to 48% of all land not occupied by the federal government (or National Park Service)
*   The District could consider targeted land-use measures near transit to incentivize more housing density and affordability

<a id='a87cc6d0-b83c-4761-afb1-7be76dcc954c'></a>

## Case example

### Minneapolis

- In October 2019, Minneapolis became the first city in the U.S. to eliminate single-family zoning

<::Minneapolis skyline at dusk, showing city buildings, a river, and bridges with illuminated lights
: figure::>

- As part of the Minneapolis 2040 comprehensive plan for the city, a package of further reforms includes:
  - Encouraging further density near transit stops
  - Eliminating off-street minimum parking requirements
  - Requiring new developments set aside units for low- and moderate-income households ("inclusionary zoning")
  - Increasing funding for affordable housing
- Before the 2040 Plan, Minneapolis made incremental steps to increasing housing affordability, such as in 2014 expanding the availability of "Accessory Dwelling Units" (ADUs)

<::A color-coded map of Minneapolis showing primary zoning districts, with a legend on the right side indicating different zoning types like R1, R1A, R2, R2B, OR1, OR2, OR3, C1, C2, C3A, C3, C4, C5, C6, I1, I2, I3, B1, B2, B3, BAC-1, BAC-2, BAC-3, S-1, U1, U2, N, O, and W. The map displays a dense urban core with various colors, surrounded by less dense areas.
: figure::>

### Impact:

- Region-wide goal of 37,900 newly constructed affordable housing units between 2021 and 2030
- ~$10M per year from the City budget to an Affordable Housing Trust Fund providing competitive low/no interest deferred loans
- ~$50M per year in Low Income Housing Tax Credits

<a id='591176f1-a22f-43ef-a32e-efe914320318'></a>

Source: Minneapolis 2040; The Century Foundation; D.C. Policy Center

<a id='6084ad5e-20e2-4a74-b7dc-160af7f480e0'></a>

McKinsey & Company
McKinsey & Company

<a id='b915907e-28ed-4f95-bb2f-146f6169ebf9'></a>

24

<!-- PAGE BREAK -->

<a id='d56482ad-7c88-443d-b4ac-f9a86aef7f7f'></a>

**2c: Adopt mobility solutions based on dynamic pricing (e.g., congestion pricing)**---

<a id='6dcab988-848a-4725-b47f-1ab780d09bf0'></a>

<::logo: Ministry of Transport
MINISTRY OF TRANSPORT
CONNECTING SINGAPORE
This logo features an abstract, intertwined loop design in shades of blue and green.::>

<a id='a02ddf64-a725-4aee-b058-54e624861489'></a>

## Description
*   Charging for use of roads in an effort to reduce congestion and carbon emissions, increase safety, and generate revenue that can be reinvested into transit infrastructure

## Congestion pricing:
*   System can be cordon fee (e.g., charge to pass a cordon line around city center), area-wide, or corridor/facility specific
*   May include a variable pricing scheme to respond to congestion (using algorithms to determine optimal price and time and transmitting this information to road screens or apps)
*   Requires similar infrastructure as current road tolling (cameras, sensors, and electronic transponder devices for vehicles)

## Revenue generation:
*   Potential to endow the city with a sustainable infrastructure bank
*   Net annual revenue is USD $182M in London, $155M in Stockholm, and $100M in Singapore

<a id='6e9ac4f9-98b0-4737-a99a-682d3ed07b44'></a>

Case example

Singapore Electronic Road Pricing (ERP)

*   Singapore launched ERP in 1998 to reduce congestion and improve journey time reliability for car users
*   It is an electronic toll collection system with open road tolling, now (as of 2020) using satellite technology instead of cameras and gantries to charge vehicles

<::An image showing a road gantry with a '4.5m' height limit sign and 'ERP' written on it.
: figure::>

*   It uses variable pricing designed to respond to congestion in real-time (charges depend on type of vehicle, congestion, time, and distance travelled)
*   In conjunction with ERP, Singapore doubled parking fees within the restriction zone, established park-and-ride facilities outside the zone, increased bus frequency, and established HOV lanes
*   Hours are 7 AM-8 PM Monday to Saturday
*   Initial investment: $110M USD
*   Annual operating cost: $18.5M USD
*   Annual net revenue: $100M USD

Impact:

*   Reduced traffic in the inner city by 24% and increased average speeds from 18-22 to 24-28 MPH
*   Public transit improvements (expanded bus, rail, biking and pedestrian network), and bus and train ridership has increased by 15%
*   Levels of CO2 and other greenhouse gas emissions have been reduced by 10-15%

<a id='4358c003-3ed5-4eae-9679-ea5d653d165e'></a>

Source: The Straits Times; Tri-State Transportation Campaign, "ROAD PRICING IN LONDON, STOCKHOLM AND SINGAPORE: A WAY FORWARD FOR NEW YORK CITY"

<a id='1b1abcd6-2449-4f00-8d37-26b23b8ae9d9'></a>

McKinsey & Company McKinsey & Company

<a id='1f16ed61-5001-42c5-9efd-7de3150864b5'></a>

25

<!-- PAGE BREAK -->

<a id='a7c4ca11-ad41-4724-81e1-acfbb51f54b2'></a>

2d: Invest in streetscape to support walking, cycling-, and micro-mobility

<a id='bae83c4e-83cf-4447-8da3-918b3477b481'></a>

<::logo: PARIS
PARIS
A stylized dark blue sailboat icon is positioned to the left of the brand name "PARIS", which is also in dark blue, sans-serif font::>

<a id='bdde36ab-d88c-4dda-95f7-51ed468615fe'></a>

## Description
*   Increase number and mileage of dedicated bike lanes, especially in neighborhoods and around key amenities (e.g. grocery stores)
*   Create additional mixed-use transit-and-micromobility corridors along key arteries, e.g., bus rapid transit (BRT) lanes and non-traditional vehicle "mobility corridors" for bikes, ride-sharing pools, and scooters
*   Allow for year-round, permanent parklet usage by restaurants (e.g., New York)
*   Improve walkability and neighborhood amenities through more car-free zones, plazas, and more Great Streets east of the river
*   Expand dockless bicycle and scooter parking and charging infrastructure

<a id='04721921-f64b-4a10-858a-4d77bbf2d07f'></a>

Case example---Paris has been undergoing a transformation to make the city less congested and more walking- and cycling-friendly. The plan to make Paris a "15-minute city," where a resident's needs are a short walk away, includes:- Pedestrianization of the highways along the Seine's riverbanks- Car-free first Sunday of each month in 10 congested areas of the city- Expansion of the city's bike-share program Vélib'- €350m (£300m) plan to create "a bike lane in every street" by 2024- Plan to do away with 60,000 parking spaces for private cars- Free public transit for kids under eleven and senior citizens- Banned cars near schools when kids are arriving and leaving to make it safe for children to walk and bike- In response to COVID-19, temporary pedestrianized streets and 30 additional miles of dedicated bike lanes<::Diagram titled "LE PARIS DU 1/4 HEURE" (Paris in 1/4 hour) with a "PARIS EN COMMUN" logo. The diagram illustrates a circular concept centered around "CHEZ MOI" (My Home). Various activities are depicted around the circle, accessible within 15 minutes by walking or cycling. The activities and their labels are:- BIEN MANGER (Eat Well): People at market stalls.- APPRENDRE (Learn): A building (school/library) and people reading.- TRAVAILLER (Work): People in an office setting.- PARTAGER ET REEMPLOYER (Share and Reuse): People exchanging items.- S'APPROVISIONNER (Stock Up): A shop with people shopping.- S'AÉRER (Get Fresh Air): A park with people relaxing.- SE CULTIVER, S'ENGAGER (Cultivate Oneself, Get Involved): A cultural building with people engaging.- SE SOIGNER (Take Care of Oneself): A clinic/doctor's office with people receiving care.- CIRCULER (Move Around): People cycling on a bike path.- SE DÉPENSER (Expend Energy/Exercise): People exercising in a sports area.Arrows indicate movement between "CHEZ MOI" and the activity zones, labeled "15mn" (15 minutes).Below the diagram, there is a photograph of two people riding bicycles, with the Eiffel Tower visible in the background.: diagram and photo::>

<a id='f06f6f8c-9d76-4bfb-98af-ac5ac668a249'></a>

**Impact:**
* Vehicular traffic has decreased by 20 percent in the last five years
* The number of cyclists has grown 54% in 2019
* City has reached 620 total miles of cycle paths in 2019, nearing its goal of 870 miles

<a id='fc114268-d515-41ca-93bc-627934f52aaa'></a>

<::A photo shows people on a bridge in Paris with the Eiffel Tower in the background. In the foreground, a person on a red scooter, wearing a white helmet and face mask, is blurred due to motion. Behind them, another person, also wearing a mask, is partially visible. To the right, a woman in a white shirt and yellow pants, wearing a face mask, rides a green bicycle. The bridge railing is ornate and green with golden accents. The Eiffel Tower is clearly visible in the distance under a partly cloudy sky.: figure::>

<a id='589aa210-47d4-4e0a-9ccb-5787d93e02fc'></a>

Source: World Economic Forum; BBC; Ubique; Fast Company

<a id='c90bf333-c6e6-49a4-bd63-f64d6c5d26f7'></a>

McKinsey & Company
McKinsey & Company

<a id='d6e77808-141a-4fab-befe-5d85163e37f7'></a>

26

<!-- PAGE BREAK -->

<a id='dd6fcfd1-ed52-4e87-8536-9b3e6eaa38b1'></a>

3f: Dynamically price on-street parking to reduce congestion and raise revenues

<a id='dcf9028d-8691-404b-8a18-8b70b6f8aa16'></a>

<::logo: LA Express Park
LA Express Park™
save time, park smarter.™
This logo features a stylized blue and white 'p' within a circular element, accompanied by the brand name and a tagline.::>

<a id='b15a4b6b-23b3-43e0-a5ed-1db3fb294291'></a>

## Description

*What is it?*

A system of sensors that detect open parking spaces and make them visible to citizens looking for parking spaces via mobile applications or vehicle navigation systems, reducing time spent looking for parking; dynamic pricing helps shape demand to meet occupancy goals. Systems may also use analytics to predict future parking availability

<a id='111b8c54-d21d-4912-9978-0de7a1ae0188'></a>

_What is the city's role?_
Buy and implement (or partner with third party to implement) smart parking sensors, meters, and applications; encourage privately owned garages and lots to implement parking guidance systems through subsidies or regulation; offer parking availability and pricing data for third parties to leverage

<a id='8b4e0892-4542-4f8e-ab4e-b83af4a9dd5b'></a>

## Case example
**Los Angeles:** The Los Angeles smart parking program leveraged multiple sensors to provide real-time parking spaces through a mobile app. The smart parking application started as a pilot around 4.5 square miles on the downtown area in 2012

<a id='44ce670e-313c-45a5-af9b-5ab3795f0290'></a>

## Features and approach:
The application uses parking sensors, dynamic pricing that reacts to demand, a parking guidance system and a mobile app that supplies real-time information about parking availability

<a id='29179a68-1de7-4be5-bdfd-b7b3881aa112'></a>

The app provides support for mobile payments, current rate, payment methods, voice guidance to
parking spots and spaces available with the option to filter parking searches by permit type

<a id='4a6e0a2c-7888-425d-a6c7-266ff8062e2b'></a>

Reservations can be made on a daily or monthly basis

<a id='c3e6aecc-4a1f-4603-97a1-1b01d99f98a2'></a>

The information helps LA DOT to set enforcement priorities to ensure compliance. All transactions are recorded and then used to optimize operations

AT&T LTE 9:56 AM 75%

<a id='631d218c-1742-4b59-a403-d20f8906063d'></a>

**Operations and cost:**
LA Express Park was founded by grants from the US DOT and the city (~$18M in total). The LA DOT manages the program. The smart parking application uses the parking sensors from Street Line company, and Xerox has helped develop a highly integrated advanced pricing engine

<a id='b5613cc8-aa6d-4499-94c4-8a2cdfa4dca2'></a>

••••• AT&T LTE 9:56 AM 75% Q Current Map Area <::Map interface showing streets and businesses. Streets visible include Gayley Ave, Westwood Blvd, and Lindbrook Dr. Businesses include Chipotle Mexican Grill, Fatburger, Native Foods Cafe, TLT Food, 800 Degrees Neapolitan Pizzeria, The Boiling Crab, Victoria's Secret, Urban Outfitters, AT&T, and Bucks. Multiple parking icons are displayed with '$2' in green, orange, and red colors. An overlay dialog box shows '1000 S WESTWOOD...' with a 'Navigate' button and an information icon. A small user location icon is visible on the map.: map::> 1 Hour. Starting Now option DAILY: [ ] option RESERVE: [ ] option MONTHLY: [ ] option STREET: [x]

<a id='74b0580d-cb68-4b3e-bffb-3c88210685c4'></a>

<::A silver and black parking meter is shown, featuring a digital screen at the top. Various credit card logos, including Visa, Mastercard, American Express, and Discover, are visible on the front panel, indicating accepted payment methods. A large blue 'P' logo is prominently displayed on the side of the meter. Text on the side reads "www.passportparking.com" and "Apple Pay® accepted here!". There is a slot for inserting cards or other payment methods. The background shows a street scene with a concrete wall on the left and a vehicle partially visible on the right.: figure::>

<a id='03f1014d-4deb-4339-8efa-9a5523daa497'></a>

<::logo: LADOT
PAY BY APP
PARK SMARTER
This logo features a QR code and a smartphone icon displaying the text "PARK SMARTER" on an orange and teal background.:>

<a id='90632ae1-df9c-412e-82f6-a2c6414040ee'></a>

Source: Laexpresspark.org; McKinsey Global Institute team analysis

<a id='e3122383-0012-4ab0-a7d8-12535b19f8fd'></a>

McKinsey & Company McKinsey & Company

<a id='906b8b56-a075-43ac-90d4-b51987d348a8'></a>

27

<!-- PAGE BREAK -->

<a id='b7fac0a7-28f9-46eb-914e-ce411cd47480'></a>

4h: Provide subsidies for low-income residents for transit

<a id='ff39d35e-e07b-492e-88b5-f074b7a7dddb'></a>

<::logo: Seattle
Seattle
The logo features a blue circular icon with a stylized profile of a face facing left, accompanied by the bold black text "Seattle".::>

<a id='f3d165f4-6326-4b7c-ae88-9a8cbeb95ac4'></a>

**usage**

<a id='69f7cc2f-5d29-4e61-8459-2885548b1f2b'></a>

# Description
The District already provides some transit subsidies through a number of sources:

The "Kids Ride Free" program allows students to ride MetroBus, Metrorail, and the DC Circulator for free within the District

SmartBenefits allows employers to offer tax-free commuting to employees – with no fee to employees

The Transportation Benefits Equity Amendment requires companies in the District that offer employees free or subsidized parking to also offer subsidized

<a id='c5cee2a7-7f18-4383-b1aa-d456e67e3b67'></a>

The District could consider addressing equity concerns by expanding existing subsidies and providing additional subsidies for low-income residents¹

<a id='adb1015b-e0dc-4be4-9b78-629cbee9db1f'></a>

Revenue sources for this program could come from other initiatives, such as dynamic pricing on certain roads or a cordon fee

<a id='ce8df438-2fec-44d8-8e6f-0e1852d2507b'></a>

## Case example
Seattle: "King County Metro has long offered discounted fares to make transit service more affordable and accessible. In addition to existing programs for youth, seniors, and disabled riders, Metro recently expanded the Human Services Ticket Program and introduced the ORCA LIFT low-income fare in 2015."

<a id='b7368a87-8d07-4df6-810a-ba29d704f615'></a>

According to King Country Metro, "The ORCA LIFT program offers a reduced transit fare for people with incomes at or below 200% of the federal poverty level. Enrollment is available at locations across King County and partner agencies like King County Public Health verify income of participants through existing benefits programs like Apple Health, Social Security and Employment Security.

<a id='801e2a86-3572-490b-a8f4-cbe698d25099'></a>

Metro reached out to the public in spring 2017 to develop recommendations for simplifying fares. We created a stakeholder advisory group, briefed and interviewed interested groups, and gathered two rounds of public feedback. This led the Executive to propose a simplified fare structure of a flat fare of $2.75 at all times, regardless of time or distance, which was adopted by King County Council and took effect in summer 2017."

<a id='2ccb2db3-f74c-495f-a3c2-a0a839f76214'></a>

<::An image showing two distinct parts. On the left, a blue ORCA card is displayed with the text "orca one regional card for all" and numbers "12345678" and "321". The card has colorful wavy lines across it. From the card, an arrow diagram extends to the right, listing various transportation methods it can be used for: STREET CAR (with a streetcar icon), BUS (with a bus icon), LINK LIGHT RAIL (with a light rail icon), SOUNDER TRAIN (with a train icon), WATER TAXI (with a water taxi icon), STATE FERRY (with a ferry icon), and FAST FERRY (with a fast ferry icon). On the right, a photograph shows a person, partially visible and in motion, wearing a red and black jacket, tapping or swiping a card on a fare reader device inside what appears to be a bus or similar vehicle. The driver's seat and dashboard controls are visible in the foreground.: figure::>

<a id='92bd237d-c339-49e0-9b03-e9e66a55946a'></a>

<::logo: ORCA LIFT
orca LIFT
Reduced Fare.
Increased Possibilities.
A blue circular logo with a white stylized orca whale above the word "orca" and a bus image in the background.::>

<a id='d70989ba-2485-4bc6-9f73-955ee2f6ec01'></a>

1. Proposals for such a program do exist, such as Councilmember Allen's proposal to provide a $100 monthly transit subsidy to every DC resident

<a id='0643b636-8df1-4229-b971-c7b84db741ff'></a>

Source: DDOT; WMATA; DC Council; King County

<a id='32d5e021-76ed-42cd-aaff-e1cdc68c2393'></a>

McKinsey & Company
McKinsey & Company

<a id='268b51fe-e92a-48ad-bde2-9b5e4bd40def'></a>

28

<a id='3549bb6a-e543-41b1-90cf-31aa26dadc02'></a>

--- --- --- --- --- ---
transit fare

<!-- PAGE BREAK -->

<a id='ad418df0-1339-4076-b46f-4d0e5a7fccd7'></a>

<::logo: Stockholms stad
Stockholms stad
The logo features a black shield with a stylized head wearing a crown, next to the words "Stockholms stad" in black text.::>

<a id='d688934a-2e5c-4a28-b555-466c733f0eef'></a>

**5k: Fastrack Vision Zero initiatives**

<a id='d30ccffa-7d6c-49b3-a3f7-55cfc6d7221b'></a>

## Description

* Fastrack DC Vision Zero safety efforts by redesigning streets and sidewalks to prioritize and protect pedestrians and cyclists
* Develop connected network of cycling and pedestrian infrastructure, and prioritize junctions with high numbers of accidents (through visibility, predictability and speed reduction)
* Entice more residents to cycle, which is proven to increase safety (e.g., survey bike commuters and DC residents to determine what would encourage them to cycle more, such as additional protected bike lanes, more bike parking infrastructure, slower driving speeds, etc.)
* Strengthen enforcement for 20 mph speed limit on DC roads (e.g., traffic enforcement cameras as in NYC)
* Reduce the volume of motorized traffic, especially during peak times (e.g., through use of congestion charge)

<a id='a158376c-b720-494f-bd8e-49471066f2d0'></a>

Case example

**Stockholm Vision Zero Project**

*   Systems approach to safety: core responsibility for accidents on the overall system design (rather than only faulting drivers)
*   Transport infrastructure redesign to eliminate fatalities and serious injuries
*   The project includes multiple sub-initiatives such as:
    *   Rebuilt intersections: built tighter roundabout focused in slowing speeds which reduced death rate by 90%
    *   Road design: safer cross-walks: Bumps, road narrowing, chicanes, etc. mainly in urban areas
*   Vision Zero 2.0: integrate health benefits of more people walking and cycling

<::People cycling on a city street, showing a crosswalk and buildings in the background.
: figure::>

**Impact:**

*   56% of Stockholm residents commute via public transport, cycling, or walking
*   Sweden has one of the lowest annual rates of road deaths in the world (3 out of 100,000 as compared to 12.3 in the United States)
*   Fatalities involving pedestrians have fallen almost 50% in the last five years

<::People walking along a tree-lined avenue in a park-like setting.
: figure::>

<a id='6852a92c-1718-4d6f-8916-1be37c799c39'></a>

Source: Stockholm Civitas Database; Center for Active Design; DDOT; International Transport Forum

<a id='3b306fcf-1a71-4e24-9508-e4c3f14c040b'></a>

McKinsey & Company McKinsey & Company

<a id='dd19ce5f-3b98-44b4-8e71-8a3cd1e30d67'></a>

29

<!-- PAGE BREAK -->

<a id='98fc3873-a9ec-4979-b027-61621da2751f'></a>

Contents

<a id='24e64998-9217-4d18-a3a5-22904a1463bd'></a>

Baseline Conditions

<a id='87fe9448-6670-4d12-b702-8d7b50459037'></a>

Challenges and trends

<a id='ae8f35ef-84ba-4a29-b200-000d8314a6b1'></a>

Opportunities and best practices

<a id='dfdf0305-0df0-4586-ad8c-bfc08287888c'></a>

Appendix

<a id='da3cee52-4ef4-457a-a323-22c8118353f4'></a>

McKinsey & Company

<a id='c979306f-c06a-4ffb-aeda-6d64aa038656'></a>

30

<a id='57d317d1-afe0-41da-b9bb-115ed7640358'></a>

Last Modified: 9/13/2020 6:20 PM Eastern Standard Time

<a id='e8d89793-be82-400a-b320-7eb51f4a71c7'></a>

Printed

<!-- PAGE BREAK -->

<a id='133d6a2e-b28f-4f05-acc3-0c9e6efb383f'></a>

Transportation and warehousing is a relatively small sector with low specialization
GDP, growth, and specialization by major industry

<a id='e7c13036-4f3e-4645-8c59-225c4a89d1f0'></a>

option Focus of this document: [x]option Analyses by other firms: [ ]<::table::>| Sector                                                      | Included in sector analysis | Size             | Growth                         | Specialization |
|:----------------------------------------------------------|:----------------------------|:-----------------|:-------------------------------|:---------------|
|                                                           |                             | GDP, Mil., 2019¹ | CAGR, 2014-19, % | CAGR, 2019-24, %² | GDP LQ³        |
| Government and government enterprises                       | option : [x]                | 40,721           | 1%                             | 2%             | 2.8            |
| Professional, scientific, and technical services            | option : [x]                | 26,407           | 2%                             | 3%             | 2.7            |
| Real estate and rental and leasing                          | option : [x]                | 9,623            | -1%                            | 2%             | 0.6            |
| Information                                               |                             | 9,246            | 9%                             | 3%             | 1.1            |
| Other services (except government and government enterprises)⁴ |                             | 8,479            | 2%                             | 0%             | 3.5            |
| Health care and social assistance                           | option : [x]                | 5,916            | 2%                             | 0%             | 0.6            |
| Finance and insurance                                     |                             | 4,520            | 2%                             | 1%             | 0.6            |
| Accommodation and food services                             | option : [x]                | 4,193            | 2%                             | 0%             | 1.2            |
| Educational services                                        | option : [x]                | 4,086            | 0%                             | 3%             | 2.8            |
| Admin. and support and waste management and remediation services |                             | 3,140            | 0%                             | 0%             | 0.8            |
| Retail trade                                                | option : [x]                | 1,645            | 4%                             | 4%             | 0.2            |
| Wholesale trade                                           |                             | 1,254            | 2%                             | 4%             | 0.2            |
| Construction                                              |                             | 1,248            | -1%                            | 1%             | 0.3            |
| Utilities                                                 |                             | 1,222            | 3%                             | 1%             | 0.7            |
| Arts, entertainment, and recreation                         | option : [x]                | 1,164            | 4%                             | 3%             | 0.9            |
| Management of companies and enterprises                   |                             | 930              | 7%                             | 7%             | 0.3            |
| Transportation and warehousing                              | option : [x]                | 341              | -2%                            | 3%             | 0.1            |
| Manufacturing                                             |                             | 273              | 6%                             | 2%             | 0.0            |
| Total                                                     |                             | 123,929          | 2%                             | 2%             | 1.0            |<::/table::>

<a id='bae55186-0af5-456f-a06f-d401ccaba9e8'></a>

1 Full-time and part-time; Real GDP chained to 2012 USD; Removed Mining, quarrying, and oil and gas extraction sector due to lack of data; Sector GDP may not add up 100% due to data suppression and real GDP calculations;
2 Forecasts from Moody's Analytics; 3 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole; 4 Other services is an especially large sector in DC as it includes NGOs and other institutions

<a id='0ada58ec-cff4-4280-88da-33b442b71602'></a>

Source: Bureau of Economic Analysis (BEA), SAGDP9N Real GDP by state by NAICS industry; Moody's Analytics

<a id='bb630f38-7160-4f65-9bbf-fb21e06f1b53'></a>

McKinsey & Company

<a id='1c9ebd67-2431-480c-9bbc-9fee334aa69f'></a>

31

<!-- PAGE BREAK -->

<a id='2d818cc8-b0a2-4ef6-a200-4ad85ab8cf25'></a>

Transit and ground passenger transportation is the largest contributor to output in DC

GDP, growth, and specialization by subsector

<a id='ce9c0f95-0c07-4b80-aa21-d2a203374852'></a>

<::table::>
| Subsector                                   | Size              | Growth              | Growth              | Specialization |
|:--------------------------------------------|:------------------|:--------------------|:--------------------|:---------------|
|                                             | GDP, Mil., 2019¹  | CAGR, 2014-19, %    | CAGR, 2019-24, %²   | GDP LQ³        |
| Transit and ground passenger transportation⁴ | 165               | 4%                  | 1%                  | 0.5            |
| Other transportation and support activities⁵ | 103               | 3%                  | 7%                  | 0.2            |
| Rail transportation                         | 36                | -18%                | 1%                  | 0.1            |
| Air transportation                          | 20                | -14%                | 3%                  | 0.0            |
| Truck transportation                        | 10                | -4%                 | 5%                  | 0.0            |
| Water transportation                        | 3                 | 1%                  | 5%                  | 0.0            |
| Warehousing and storage                     | 3                 | 0%                  | 11%                 | 0.0            |
| Pipeline transportation                     | 3                 | -23%                | 8%                  | 0.0            |
| Transportation and warehousing (total)     | 341               | -2%                 | 3%                  | 0.1            |
<::/table::>

<a id='ec294c2e-3a27-41ed-bd73-e6da28caa977'></a>

1. Full-time and part-time; Real GDP chained to 2012 USD; Subsector GDP may not add up 100% due to data suppression and real GDP calculations
2. Forecasts from Moody's Analytics
3. Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole
4. Includes transit networks such as WMATA and rideshare such as Uber and Lyft, etc.
5. Other Transportation and Support Activities includes scenic and sightseeing transportation, couriers and messengers, and support activities for transportation (BEA does not have separate data for them)

<a id='fbe5ab73-5ea3-4f73-b6cc-779bb3dbf29d'></a>

Source: Bureau of Economic Analysis (BEA), SAGDP9N Real GDP by state by NAICS industry; Moody's Analytics

<a id='1f9aae32-cbd7-429b-be2f-e858c0df9501'></a>

McKinsey & Company

<a id='91b5f3ed-6ebb-41eb-8d23-d79338800db7'></a>

32

<!-- PAGE BREAK -->

<a id='a7e83be5-af49-47eb-acc7-d378210c8fcb'></a>

Current as of August 5, 2020

<a id='291cce76-f145-4c01-9cd9-5e8e782d99d6'></a>

1: DC's most vulnerable jobs are concentrated in sectors with the
lowest wages and lowest educational attainment
Number of vulnerable jobs in DC

<a id='9ba11371-729c-4cbd-a5fe-234845fef577'></a>

Preliminary, proprietary, pre-decisional
<::A bubble chart titled "Median earnings in industry, '000" displays various industries. The y-axis ranges from 10 to 100, representing median earnings in thousands. The x-axis ranges from 0 to 65. Each bubble represents an industry, with its size indicating the number of employees in thousands (K) and its vertical position indicating median earnings.

Data points are as follows:
- Professional services: 29K employees, median earnings around 95K (x-pos ~30)
- Government: 11K employees, median earnings around 87K (x-pos ~7)
- Information: 4K employees, median earnings around 80K (x-pos ~20)
- Finance: 5K employees, median earnings around 80K (x-pos ~27)
- Management: 1K employees, median earnings around 80K (x-pos ~32)
- Utilities: 1K employees, median earnings around 78K (x-pos ~30)
- Religious & Civic: 23K employees, median earnings around 75K (x-pos ~37)
- Mining: 0K employees, median earnings around 75K (x-pos ~57)
- Education: 21K employees, median earnings around 70K (x-pos ~37)
- Wholesale: 2K employees, median earnings around 68K (x-pos ~40)
- Construction: 7K employees, median earnings around 67K (x-pos ~47)
- Real Estate: 5K employees, median earnings around 58K (x-pos ~48)
- Healthcare: 12K employees, median earnings around 55K (x-pos ~18)
- Manufacturing: 0K employees, median earnings around 55K (x-pos ~30)
- Repair & maintenance: 0K employees, median earnings around 47K (x-pos ~28)
- Administrative: 17K employees, median earnings around 45K (x-pos ~38)
- Forestry and Logging: 0K employees, median earnings around 40K (x-pos ~28)
- Transportation: 2K employees, median earnings around 50K (x-pos ~57, highlighted in red)
- Retail: 11K employees, median earnings around 35K (x-pos ~55)
: bubble chart::>

<a id='a86191ea-7fae-4f55-a3fb-90bda692b626'></a>

<::bubble chart: Total jobs at risk in DC 52.6K. The chart includes a legend for 'Number of jobs vulnerable' where circle size indicates quantity (e.g., a grey circle represents 10K). Another legend indicates '% of jobs in industry requiring a bachelors degree' by color: black for >40%, dark blue for 20-40%, and light blue for <20%. The chart displays: personal services with a light blue circle representing 6K jobs; Arts, entertainment, & rec with a dark blue circle representing 8K jobs; and Accomm. & food service with a large light blue circle representing 62K jobs.::>

<a id='5bd4c67a-a767-42de-931d-dbf15edc2349'></a>

<::85 90 95 100
% of jobs in industry vulnerable
: chart::>

<a id='0d67f4b2-b54b-44ba-8ff0-a4e95fcf19c3'></a>

Note: Vulnerable jobs are those predicted to be furloughed, laid-off, or otherwise unproductive (e.g., kept on payroll but not working) during periods of high social distancing

<a id='98278b48-9e42-40ca-9025-fe19c33c035c'></a>

Source: MGI Economics analysis based on scenarios generated by McKinsey in partnership with Oxford Economics, input from Moody's Analytics data

<a id='9cb4ef27-22b5-4e5c-8b19-3618c1e08ed9'></a>

McKinsey & Company

<a id='04539fe1-230b-48ce-abf7-f5f80a5d3a7c'></a>

33

<a id='c6bc166e-b5c2-4eb0-b1c6-ec5600ea1aa3'></a>

<::A horizontal line segment with numerical labels 70, 75, 80: figure::>

<!-- PAGE BREAK -->

<a id='9afb0107-81a9-43f9-b6b9-8d3f3cb6aead'></a>

**DC's GDP can be expected to decline by 6.4% in 2020**
Real GDP, indexed to 2019 Q4

<a id='f4a0c7f3-2f2b-40d7-8663-8a371b4337e0'></a>

Preliminary, proprietary, pre-decisional
Real GDP Impacts of COVID-19 Crisis
Indexed to 2019 Q4 = 100
<::A line chart titled "Real GDP Impacts of COVID-19 Crisis", indexed to 2019 Q4 = 100.
Legend:
- History (light gray line)
- Pessimistic scenario (dark blue line)

The y-axis ranges from 85 to 110, with major ticks at 85, 90, 95, 100, 105, 110.
The x-axis shows quarters from 2019Q4 to 2023Q4.

The "History" line starts around 98 in early 2019Q4, rises to 100 by late 2019Q4, and then remains flat at 100.
The "Pessimistic scenario" line starts at 100 in 2019Q4, drops sharply to approximately 91 by 2020Q4, then gradually recovers, crossing the 100 mark around 2022Q2, and continues to rise to nearly 105 by 2023Q4.
: chart::>

<a id='aa461d27-6ca3-4fa3-8f09-fe9a62406a8c'></a>

The pessimistic scenario (A1) assumes there is a virus resurgence and a muted recovery through 2022 globally
1.Average annual percent change

<a id='a2fc87ab-4d99-4dea-b5f4-cf250575dc63'></a>

Source: MGI Economics analysis based on scenarios generated by McKinsey in partnership with Oxford Economics, input from Moody's Analytics data

<a id='999a6a04-02b0-4405-baf1-1abd471786c0'></a>

Current as of October, 2020

<a id='e40034fa-4faf-4571-867d-062acd294141'></a>

2020 GDP
change2
% Change

-6.4%

GDP return
to pre-crisis
Quarter

2022Q3

<a id='8f6aec20-f70e-4be9-baec-42a3bbb81c81'></a>

McKinsey & Company

<a id='55163f9c-2bfb-42aa-9f9c-efcd5d41904f'></a>

34

<!-- PAGE BREAK -->

<a id='e39fe7e3-ade2-464b-9a9a-1d8f359a49b7'></a>

Current as of October, 2020

<a id='2decaacb-dbb2-4bcc-a6a7-a75c36dca222'></a>

Vulnerable jobs and businesses are concentrated disproportionately among Hispanic and Black DC residents

<a id='e0fcef2f-6fda-4b7a-ba1e-157ced14761a'></a>

Preliminary, proprietary, pre-decisionalShare of vulnerability of workers and businesses, by race/ethnicity¹ (%)
<::Bar chart showing the share of vulnerability of workers and businesses, by race/ethnicity.

Vulnerable jobs:
- Hispanic: 47% share, 0.05M jobs
- Black: 31% share, 0.06M jobs
- Asian: 31% share, 0.02M jobs
- White: 26% share, 0.09M jobs

Revenue in most vulnerable sectors:
- Hispanic: 26% share, $3.2B revenue
- Black: 47% share, $1.3B revenue
- Asian: 37% share, $53.5B revenue
- White: 19% share, $2.8B revenue
: chart::>

<a id='f00b2bd4-fb1f-4775-9365-32a814a7061b'></a>

Source: LaborCUBE, BLS Occupational Employment Statistics, Moody's Analytics, McKinsey Global Institute analysis
Mc
1. Vulnerability of minority-owned businesses is measured by share of revenue in five sectors with most vulnerable jobs: Accommodation & Food Service, Retail, Construction, Healthcare, and Professional services

<a id='aac060c7-9555-43ed-8694-936efc982b6d'></a>

McKinsey & Company

<a id='2808697a-1d4a-4f82-8f12-1477a45732aa'></a>

35

<!-- PAGE BREAK -->

<a id='3f40bfb9-fc87-4a28-af1b-e5ce4ffa4192'></a>

Vulnerable jobs analysis: Traditional unemployment does not fully capture the economic risk
facing American families

<a id='5d9214f0-bc02-4c9f-b86c-9f81015e9b25'></a>

In addition to traditional unemployment¹, the “vulnerable jobs” metric attempts to capture the **income risk** facing a larger set of American families by reflecting—

<a id='fe262cfe-f145-4637-8cef-189d9333308f'></a>

Workers placed on **unpaid leave**
Workers facing **cuts to either hourly wages or hours worked**
Workers that **exit the labor force**
Workers that held multiple jobs and **reduced the number of jobs worked** as a result of Covid-19

<a id='1d5d3c80-86da-42a5-8c77-ea60f559ebfe'></a>

1. The BLS measure of U3 unemployment includes all jobless persons who are available to take a job and have actively sought work in the past four weeks

<a id='bfa847cb-ae05-4f21-a5ae-45ee48e39e55'></a>

Source: Pitchbook

<a id='3b0f9250-bb35-4a34-a97d-d6b6c3169738'></a>

36

<a id='6c374f24-c362-47ca-8526-67eff3bd4262'></a>

Last Modified 11/3/2020 6:03 PM Eastern Standard Time

<a id='79597d4e-d3bf-4c9d-8ce7-95f933561202'></a>

Printed

<!-- PAGE BREAK -->

<a id='2e3f6361-4816-4d2b-a0b7-8cfa4bb55161'></a>

Current as of October, 2020

<a id='5dcc0c44-b5a1-48c8-8705-95a6dbdaed6f'></a>

Current as of Oct
Assessing small and medium business vulnerability leads to four
segments that may require different interventions

150

<a id='d4fb96a4-b743-44e7-82da-b36effc1b1fc'></a>

**Preliminary, proprietary, pre-decisional**

<a id='1a586e15-5559-4f7c-a841-7af3a0899000'></a>

<::Quadrant chart: Financial risk as indicator of resilience (Y-axis, from Lower to Higher) versus Degree affected by COVID-19 (X-axis, from Lower to Higher).::>
<::Quadrant 1 (Top Left): Higher financial risk, Lower initial COVID-19 effects::>
SMBs with higher financial risk and lower initial COVID-19 effects. Increasing concern with potentially broader and longer economic impacts, given underlying fragility
<::Quadrant 2 (Top Right): Higher financial risk, Higher immediate COVID-19 effects::>
SMBs with higher financial risk and higher COVID-19 immediate effects. This group is most likely to experience widespread potential vulnerability to closure in the near term
<::Quadrant 3 (Bottom Left): Lower financial risk, Lower initial COVID-19 effects::>
SMBs with lower financial risk and lower initial COVID-19 effects. May still need help, and risk may increase as crisis continues
<::Quadrant 4 (Bottom Right): Lower financial risk, Higher immediate COVID-19 effects::>
SMBs with higher financial risk but also higher COVID-19 immediate effects. Individuals/workers in need of immediate help, though businesses may bounce back more quickly

<a id='46aa0567-2650-479b-b88d-fe881121ff2e'></a>

Note: Financial risk as indicator of resilience is based on adapting a Federal Reserve methodology using profitability, credit score, and use of retained earnings. COVID-19 affectedness is based on the US Census Bureau's Small Business Pulse Survey, where business owners indicated the level of effect they are seeing from COVID-19

<a id='4e627f79-28ed-439f-a9c0-f26d578f51c6'></a>

McKinsey & Company

<a id='a8b4c891-22cd-4855-b82e-754e874c2a69'></a>

37

<a id='4d8a8b41-9da9-484c-9db1-ac6d29f26d9f'></a>

Fin
risk
ind
res

<!-- PAGE BREAK -->

<a id='d896de45-ece5-4d32-a6bf-95180abe43c8'></a>

Current as of October, 2020

<a id='c11186ec-c06a-4673-a031-6197f4e093e6'></a>

**Across sectors, DC has ~4K small-medium businesses with both higher financial risk and COVID-19 immediate impacts**
These SMBs employ ~69K workers, and their workers earn the lowest average income

<a id='499aceb3-2b29-43b6-b534-8fb7185d9495'></a>

Preliminary, proprietary, pre-decisional

<a id='7de142ff-17b3-4628-8d4e-ce4f40950fbe'></a>

<::This image displays a 2x2 matrix comparing Small and Medium Businesses (SMBs) based on "Financial risk as indicator of resilience" (Y-axis: Higher, Lower) and "Degree affected by COVID-19" (X-axis: Lower, Higher). Each quadrant contains a bar chart showing data for Firms, Employment, and Average Income.Financial risk as indicator of resilience: Higher, Degree affected by COVID-19: LowerSMBs with higher financial risk and lower initial COVID-19 effects. Examples: Smaller apparel factories, local construction companies- Firms, thousands: 3- Employment, thousands: 45- Average income, USD thousands: 55Financial risk as indicator of resilience: Higher, Degree affected by COVID-19: HigherSMBs with higher financial risk and higher COVID-19 immediate effects. Examples: Restaurants, barber shops, bed and breakfasts- Firms, thousands: 4- Employment, thousands: 69- Average income, USD thousands: 44Financial risk as indicator of resilience: Lower, Degree affected by COVID-19: LowerSMBs with lower financial risk and lower initial COVID-19 effects. Examples: Law firms, financial advisors, lessors of residential buildings- Firms, thousands: 6- Employment, thousands: 61- Average income, USD thousands: 89Financial risk as indicator of resilience: Lower, Degree affected by COVID-19: HigherSMBs with lower financial risk but also higher COVID-19 immediate effects. Examples: Dentist offices, child care centers- Firms, thousands: 2- Employment, thousands: 27- Average income, USD thousands: 57: bar chart::>

<a id='55619013-5d3e-4bfc-8224-4190ad64aea9'></a>

Note: Financial risk as indicator of resilience is based on adapting a Federal Reserve methodology using profitability, credit score, and use of retained earnings. COVID-19 affectedness is based on the US Census Bureau's Small Business Pulse Survey, where business owners indicated the level of effect they are seeing from COVID-19

<a id='ff48fa0a-d7a0-4198-83fe-435569a41f1c'></a>

McKinsey & Company

<a id='5c7ae9a4-ac56-4dc3-aeb8-d1083fbed551'></a>

38

<!-- PAGE BREAK -->

<a id='a93d2c61-3e1c-422b-9d50-399c8d94a3fa'></a>

Other: Raleigh Commute Smart Consultants

<a id='3da5d42f-a4ba-4db9-b923-5ff87b53e573'></a>

<::logo: Raleigh
Raleigh
The logo features a stylized tree or plant design composed of various shades of green squares and rectangles, resembling pixels, with the word "Raleigh" in black text below it::>

<a id='5660f3a6-3a4c-4a5d-b8b4-f226ac66ae8a'></a>

# Description

* Call on employers to offer paid mobility programs and cash out programs (e.g., providing cash or transit subsidies to employees who do not park at work)

* Pilot employer-centered mobility programs and evaluate the effectiveness, such as through the LAB @ DC

* Launch a dedicated team within the District government focused on assisting employers with commuting programs

* Convene various transit- and commuter-centric organizations to establish an integrated strategy for enhancing commuting in the District

<a id='04bb10ef-397b-4498-adba-164658fbbe02'></a>

## Case example
**Raleigh:** The City of Raleigh has created a dedicated team of "Commute Smart Consultants." This team can assist employers to implement a "Commute Smart Program" for employees, making it easy for companies to support employees in alleviating traffic congestion and commuting stress.

The program offers easy solutions for employers by providing advice and assistance on how to increase the use of transportation options such as walking, biking, transit, carpooling, vanpooling, teleworking, creative work schedules, and parking cash-out.

The City states that "Implementing a Commute Smart Program can:
*   Increase employee satisfaction
*   Reduce the demand for parking
*   Reduce tardiness and absenteeism
*   Reduce employee stress
*   Enhance recruitment and retention
*   Enhance your public image

<::A red and silver city bus with "2 FALLS OF NEUSE" displayed, stopped at a crosswalk with people crossing. : figure::>

<::A person on a bicycle on a dirt path, with other people walking in the background, surrounded by trees. : figure::>

<a id='f954ccf3-4555-4c93-9317-2f90dbd04de2'></a>

For example, one program the City offers for employers to implement is "Emergency Ride Home" which provides employees a free ride home if an emergency ever strikes. This service is available specifically to those who commuted to work by a method other than driving alone. Employers can register their organization at no cost so that all employees get six free emergency rides home per year.

<a id='4a55a9bf-0d96-4eec-8832-f661e180fc41'></a>

Source: Commute Smart Raleigh; The LAB @ DC

<a id='53a2c89a-0721-40fa-a010-316fbda968ba'></a>

McKinsey & Company
McKinsey & Company

<a id='20ebe9ba-fd43-4d3a-9592-a892504368b7'></a>

39

<!-- PAGE BREAK -->

<a id='269cc364-1e9b-4b01-8970-4b4d10a0f0ce'></a>

DollarVan.nyc

<a id='206b54c4-6dbb-48ab-ad91-23215ad8bb9a'></a>

Other: New York City's Dollar Vans

<a id='3707d57a-0a77-426a-9a00-917a1f6ef7af'></a>

## Description
* Provide subsidized microtransit (e.g., shuttles, mini-buses) in underserved communities
* City or transit agency can run the service or regulate private player(s) who run operations (e.g., NYC Dollar Vans, Via, etc.)
* Cross between legacy bus and ridesharing (e.g., Uber Pool)
* Can have fixed routes, fixed stops, or use algorithms to determine routes, vehicle size, and trip frequency
* Can supplement existing bus route capacity along with providing services to under-served areas
* Potential to generate employment and increase business ownership among underserved communities

<a id='a7960799-87f7-4322-9673-158ffed7fad4'></a>

Case example New York City's Dollar Vans
▪ Dollar Vans first appeared in New York City during a transit strike, and currently serve ~120K riders per day in areas of the city with transit gaps, primarily in Queens and Brooklyn
▪ Initially unregulated, the TLC (NYC Taxi & Limousine Commission) provides licenses to van owners, running background checks on all drivers, vehicle safety checks, and checking for proper insurance and licensing
  ▪ Note that the strict requirements and high cost of insurance means that many vans continue to operate without permits
▪ Follow fixed routes linking key hubs and under-served areas, such as Sunset Park, Flushing, Flatbush, and Eastern Queens
▪ Dollaride, an app, allows users to locate licensed vans, determine their arrival time, and pay the fare
▪ Cost for riders:
  ▪ Queens, Flatbush: $2
  ▪ Chinatown, Flushing, Sunset Park: $3-4
<::A map of New York City showing various dollar van routes in different colors (orange, red, blue, green) connecting key hubs and under-served areas. Locations visible include Fort Lee, George Washington Bridge, North Bergen, Fort Authority Bus Terminal, Newport Square, Chinatown Flushing, Jamaica Center Parsons Blvd, Atlantic Ave Barclays Ctr, Fulton Hall, Church Ave & 48th Street, Flatbush, Eastern Queens, 33rd St, Green Acres Hall, Rockaway, Beach 98. Below the map, a smartphone screen displays the 'dollaride' app. The app shows a green dollar van icon with a dollar sign and the text 'Ease your daily commute with NYC's network of dollar vans.': figure::>
Impact:
▪ 120K riders daily
▪ 2K drivers

<a id='80c6c43d-b603-4979-8535-3e865ba4f9c6'></a>

Source: DollarVan.nyc; Dollaride; New York Times; The New Yorker

<a id='e13fef4a-71f3-48f9-a1ae-cb59eea4ecfb'></a>

McKinsey & Company
McKinsey & Company

<a id='4dfa0495-4dc2-4430-8fef-abac78974855'></a>

40