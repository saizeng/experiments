<a id='9d9ff61c-335e-469b-a371-ac43fb65681f'></a>

Table of Contents

<a id='729da390-0ddc-46ed-83bd-931a10d9071e'></a>

We record marketable equity securities not accounted for under the equity method at fair value based on readily determinable market values, of which publicly traded stocks are subject to market price volatility and represent $1.23 billion of our investments as of December 31, 2024. A hypothetical adverse price change of 10% on our December 31, 2024 balance would decrease the fair value of marketable equity securities by $123 million. We did not hold any marketable equity securities as of December 31, 2023.

<a id='9ee04efe-4bf5-4d48-9f74-cf800564ff17'></a>

We elected to account for substantially all of our non-marketable equity securities using the measurement alternative, which is cost, less any impairment, adjusted for changes in fair value resulting from observable transactions for identical or similar securities of the same issuer. We perform a qualitative assessment at each reporting date to determine whether there are triggering events for impairment. The qualitative assessment considers factors such as, but not limited to, the investee's financial condition and business outlook; industry and sector performance; economic or technological environment; and other relevant events and factors affecting the investee. Valuations of our non-marketable equity securities are complex due to the lack of readily available market data and observable transactions. Uncertainties in the global economic climate and financial markets could adversely impact the valuation of the companies we invest in and, therefore, result in a material impairment or downward adjustment in our investments. Our total non-marketable equity securities, which mostly consists of our investment in Jio Platforms Limited, had a carrying value of $6.07 billion and $6.14 billion as of December 31, 2024 and 2023, respectively.

<a id='f8e9b4bf-b6ea-4c31-a47b-77ca85554d45'></a>

For additional information, see Note 1 --- Summary of Significant Accounting Policies, Note 5 --- Financial Instruments, Note 6 --- Non-marketable Equity Securities, and Note 10 --- Long-term Debt in the notes to the consolidated financial statements included in Part II, Item 8, "Financial Statements and Supplementary Data" and Part II, Item 7, "Management's Discussion and Analysis of Financial Conditions and Results of Operations --- Critical Accounting Estimates" contained in this Annual Report on Form 10-K.

<a id='6a6f057f-eef6-44be-8b27-cbb1100b29fa'></a>

80

<!-- PAGE BREAK -->

<a id='4022655a-49e7-4dcb-af38-b15e766586e8'></a>

Table of Contents

<a id='4740ad33-2ad2-46f4-a8e7-e583e6cf1de2'></a>

Item 8. Financial Statements and Supplementary Data

<a id='2d5c1867-7d8e-41fc-a15b-243106251e38'></a>

META PLATFORMS, INC.

<a id='67a715a4-8cb8-438e-898d-e0dcec2d45e5'></a>

## INDEX TO CONSOLIDATED FINANCIAL STATEMENTS

<a id='4f25dfd6-47d3-4323-aaac-f4b2c398b9b0'></a>

<table id="1-1">
<tr><td id="1-2"></td><td id="1-3">Page (text over image)</td></tr>
<tr><td id="1-4">Reports of Independent Registered Public Accounting Firm (PCAOB ID No. 42)</td><td id="1-5">82 (blue numbers)</td></tr>
<tr><td id="1-6">Consolidated Financial Statements:</td><td id="1-7"></td></tr>
<tr><td id="1-8">Consolidated Balance Sheets</td><td id="1-9">86 (blue numbers)</td></tr>
<tr><td id="1-a">Consolidated Statements of Income</td><td id="1-b">87 (blue numbers)</td></tr>
<tr><td id="1-c">Consolidated Statements of Comprehensive Income</td><td id="1-d">88</td></tr>
<tr><td id="1-e">Consolidated Statements of Stockholders&#x27; Equity</td><td id="1-f">89</td></tr>
<tr><td id="1-g">Consolidated Statements of Cash Flows</td><td id="1-h">90</td></tr>
<tr><td id="1-i">Notes to Consolidated Financial Statements</td><td id="1-j">92</td></tr>
</table>

<a id='220179e6-257b-4e8a-b726-9c3cdd8f4676'></a>

81

<!-- PAGE BREAK -->

<a id='6be75cf6-ffc6-46be-8adf-ebf6447520a0'></a>

Table of Contents

<a id='b1128503-3624-4dfb-a91e-d10751384bbf'></a>

Report of Independent Registered Public Accounting Firm
To the Stockholders and the Board of Directors of Meta Platforms, Inc.

<a id='08ee1b87-6728-4003-aeda-721a286efb92'></a>

**Opinion on the Financial Statements**

We have audited the accompanying consolidated balance sheets of Meta Platforms, Inc. (the Company) as of December 31, 2024 and 2023, the related consolidated statements of income, comprehensive income, stockholders' equity and cash flows for each of the three years in the period ended December 31, 2024, and the related notes (collectively referred to as the "consolidated financial statements"). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at December 31, 2024 and 2023, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2024, in conformity with U.S. generally accepted accounting principles.

<a id='272cebac-705f-4dae-8c23-0af3ab98df14'></a>

We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control–Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework), and our report dated January 29, 2025 expressed an unqualified opinion thereon.

<a id='7054385d-f20b-480f-9647-eb328ea0871a'></a>

**Basis for Opinion**
These financial statements are the responsibility of the Company's management. Our responsibility is to express an opinion on the Company's financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

<a id='dc77eb7f-05c9-48c0-8832-82724fab9bac'></a>

We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

<a id='e8d2c834-567f-4fce-b596-eb725c8c5a94'></a>

## Critical Audit Matters
The critical audit matters communicated below are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the Audit & Risk Oversight Committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

<a id='52ef755b-ffda-4cfb-bdd8-0e1355862667'></a>

82

<!-- PAGE BREAK -->

<a id='faeaa255-e1cc-457c-a1c3-508d0cbdcf3b'></a>

Table of Contents

<a id='84cced2c-1e0f-4656-9b43-6b69a32abbd4'></a>

**Loss Contingencies**

Description of the Matter: As described in Note 12 to the consolidated financial statements, the Company is party to various legal proceedings, claims, and regulatory or government inquiries and investigations. The Company accrues a liability when it believes a loss is probable and the amount can be reasonably estimated. In addition, the Company believes it is reasonably possible that it will incur a loss in some of these cases, actions or inquiries described above. When applicable, the Company discloses an estimate of the amount of loss or range of possible loss that may be incurred. However, for certain other matters, the Company discloses that the amount of such losses or a range of possible losses cannot be reasonably estimated at this time.

<a id='e32c3015-0561-4f0a-9dd7-1185eab49919'></a>

Auditing the Company's accounting for, and disclosure of these loss contingencies was especially challenging due to the significant judgment required to evaluate management's assessments of the likelihood of a loss, and their estimate of the potential amount or range of such losses.

<a id='a556bea5-3c4f-43d9-a7a8-5f586c7364fa'></a>

How We Addressed the Matter in Our Audit We obtained an understanding, evaluated the design and tested the operating effectiveness of controls over the identification and evaluation of these matters, including controls relating to the Company's assessment of the likelihood that a loss will be realized and their ability to reasonably estimate the potential range of possible losses.

<a id='76407972-5070-4d4d-91fc-e0bc2cc2d67a'></a>

Our audit procedures included reading the minutes or a summary of the meetings of the committees of the board of directors, reading the proceedings, claims, and regulatory or government inquiries and investigations, or summaries as we deemed appropriate, requesting and receiving internal and external legal counsel confirmation letters, meeting with internal and external legal counsel to discuss the nature of the various matters, and obtaining representations from management. We also evaluated the appropriateness of the related disclosures included in Note 12 to the consolidated financial statements.

<a id='9e13bf81-8f41-4b78-9be3-b0900dbaf859'></a>

83

<!-- PAGE BREAK -->

<a id='c3ce38a9-1a53-4636-b6a3-dbdf58b4c451'></a>

Table of Contents

<a id='ce28de7d-6a0b-455a-8ff9-076b2aefd1ab'></a>

### Uncertain Tax Positions

*Description of the Matter*

As discussed in Note 15 to the consolidated financial statements, the Company has received certain notices from the Internal Revenue Service (IRS) related to transfer pricing agreements with the Company's foreign subsidiaries for certain periods examined. The IRS has stated that it will also apply its position to tax years subsequent to those examined. If the IRS prevails in its position, it could result in an additional federal tax liability, plus interest and any penalties asserted. The Company uses judgment to (1) determine whether a tax position's technical merits are more-likely-than-not to be sustained and (2) measure the amount of tax benefit that qualifies for recognition.

<a id='9637e340-5b4a-4d8e-b801-2f5c3daeae0f'></a>

Auditing the Company's accounting for, and disclosure of, these uncertain tax positions was especially challenging due to the significant judgment required to assess management's evaluation of technical merits and the measurement of the tax position based on interpretations of tax laws and legal rulings.

<a id='451e67d8-21ef-4915-86a9-6c05658ef52b'></a>

*How We Addressed the Matter in Our Audit*

We obtained an understanding, evaluated the design and tested the operating effectiveness of controls over the Company's process to assess the technical merits of tax positions related to these transfer pricing agreements and to measure the benefit of those tax positions.

<a id='7ec1a019-40ea-4792-9042-b7c891a335e4'></a>

As part of our audit procedures over the Company's accounting for these positions, we involved our tax professionals to assist with our assessment of the technical merits of the Company's tax positions. This included assessing the Company's correspondence with the relevant tax authorities, evaluating income tax opinions or other third-party advice obtained by the Company, and requesting and receiving confirmation letters from third-party advisors. We also used our knowledge of, and experience with, the application of international and local income tax laws by the relevant income tax authorities to evaluate the Company's accounting for those tax positions. We analyzed the Company's assumptions and data used to determine the amount of the federal tax liability recognized and tested the mathematical accuracy of the underlying data and calculations. We also evaluated the appropriateness of the related disclosures included in Note 15 to the consolidated financial statements in relation to these matters.

<a id='d5025892-a80e-44ea-9ef8-fcce549af0b4'></a>

<::attestation: Digital Signature/Attestation
Status: Confirmed auditor role since 2007
Signature: legible (Ernst & Young LLP)
Readable Text: /s/ Ernst & Young LLP
We have served as the Company's auditor since 2007.
Short description of visual elements and positioning: Text-based attestation positioned centrally on a plain background.::>

<a id='78be871e-2a2e-41b7-8435-7cbe901ea236'></a>

San Jose, California
January 29, 2025

<a id='b75a47b8-c476-40c4-b676-d555d9d97c10'></a>

84

<!-- PAGE BREAK -->

<a id='01cd6c6b-1c84-461e-956f-42d8f0764f50'></a>

Table of Contents

<a id='b9fed26b-32bc-45da-ae91-c250865aa94d'></a>

Report of Independent Registered Public Accounting Firm
To the Stockholders and the Board of Directors of Meta Platforms, Inc.

<a id='de67c29f-c559-41f2-8053-bc02dbbe5621'></a>

**Opinion on Internal Control Over Financial Reporting**

We have audited Meta Platforms, Inc.'s internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control-Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Meta Platforms, Inc. (the Company) maintained, in all material respects, effective internal control over financial reporting as of December 31, 2024, based on the COSO criteria.

<a id='f2ef127b-91d0-4366-a992-c4979596f554'></a>

We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheets of the Company as of December 31, 2024 and 2023, the related consolidated statements of income, comprehensive income, stockholders' equity and cash flows for each of the three years in the period ended December 31, 2024, and the related notes and our report dated January 29, 2025 expressed an unqualified opinion thereon.

<a id='fa2055da-5a06-419c-9743-530f610be837'></a>

## Basis for Opinion
The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management's Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

<a id='0afb2243-936e-49ed-b34c-8b22dc1e11bd'></a>

We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

<a id='47ebcd31-ab02-4760-ab8c-2d71114f7d87'></a>

Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

<a id='63372206-b319-4b1a-b253-e45d49d3a46a'></a>

## Definition and Limitations of Internal Control Over Financial Reporting
A company's internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

<a id='42834f73-d054-4b90-95db-2b99c784c5b3'></a>

Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

<a id='3d758357-cd26-490a-ada4-32eb0a4624ba'></a>

<::attestation: Digital signature
Signed
Signature: legible
Readable Text: /s/ Ernst & Young LLP
Short description of visual elements and positioning: Centered text indicating a digital signature.::>

<a id='f9188fe3-7400-4c84-b5f1-c6d778b3ca0c'></a>

San Jose, California
January 29, 2025

<a id='e5efccda-f6c7-4570-997f-17d30961a23a'></a>

85

<!-- PAGE BREAK -->

<a id='43fca88d-b910-4eb5-8858-b03485d11aed'></a>

Table of Contents

<a id='23989856-14a0-4b8a-a54b-423b8e77a33c'></a>

META PLATFORMS, INC.
CONSOLIDATED BALANCE SHEETS
(In millions, except number of shares and par value)

<a id='852457df-9831-45f6-a89b-c6483ce26ea2'></a>

<table id="6-1">
<tr><td id="6-2"></td><td id="6-3" colspan="2">December 31,</td></tr>
<tr><td id="6-4"></td><td id="6-5">2024</td><td id="6-6">2023</td></tr>
<tr><td id="6-7" colspan="3">Assets</td></tr>
<tr><td id="6-8">Current assets:</td><td id="6-9"></td><td id="6-a"></td></tr>
<tr><td id="6-b">Cash and cash equivalents</td><td id="6-c">$ 43,889</td><td id="6-d">$ 41,862</td></tr>
<tr><td id="6-e">Marketable securities</td><td id="6-f">33,926</td><td id="6-g">23,541</td></tr>
<tr><td id="6-h">Accounts receivable, net</td><td id="6-i">16,994</td><td id="6-j">16,169</td></tr>
<tr><td id="6-k">Prepaid expenses and other current assets</td><td id="6-l">5,236</td><td id="6-m">3,793</td></tr>
<tr><td id="6-n">Total current assets</td><td id="6-o">100,045</td><td id="6-p">85,365</td></tr>
<tr><td id="6-q">Non-marketable equity securities</td><td id="6-r">6,070</td><td id="6-s">6,141</td></tr>
<tr><td id="6-t">Property and equipment, net</td><td id="6-u">121,346</td><td id="6-v">96,587</td></tr>
<tr><td id="6-w">Operating lease right-of-use assets</td><td id="6-x">14,922</td><td id="6-y">13,294</td></tr>
<tr><td id="6-z">Goodwill</td><td id="6-A">20,654</td><td id="6-B">20,654</td></tr>
<tr><td id="6-C">Other assets</td><td id="6-D">13,017</td><td id="6-E">7,582</td></tr>
<tr><td id="6-F">Total assets</td><td id="6-G">$ 276,054</td><td id="6-H">$ 229,623</td></tr>
<tr><td id="6-I"></td><td id="6-J"></td><td id="6-K"></td></tr>
<tr><td id="6-L">Liabilities and stockholders&#x27; equity</td><td id="6-M"></td><td id="6-N"></td></tr>
<tr><td id="6-O">Current liabilities:</td><td id="6-P"></td><td id="6-Q"></td></tr>
<tr><td id="6-R">Accounts payable</td><td id="6-S">$ 7,687</td><td id="6-T">$ 4,849</td></tr>
<tr><td id="6-U">Operating lease liabilities, current</td><td id="6-V">1,942</td><td id="6-W">1,623</td></tr>
<tr><td id="6-X">Accrued expenses and other current liabilities</td><td id="6-Y">23,967</td><td id="6-Z">25,488</td></tr>
<tr><td id="6-10">Total current liabilities</td><td id="6-11">33,596</td><td id="6-12">31,960</td></tr>
<tr><td id="6-13">Operating lease liabilities, non-current</td><td id="6-14">18,292</td><td id="6-15">17,226</td></tr>
<tr><td id="6-16">Long-term debt</td><td id="6-17">28,826</td><td id="6-18">18,385</td></tr>
<tr><td id="6-19">Long-term income taxes</td><td id="6-1a">9,987</td><td id="6-1b">7,514</td></tr>
<tr><td id="6-1c">Other liabilities</td><td id="6-1d">2,716</td><td id="6-1e">1,370</td></tr>
<tr><td id="6-1f">Total liabilities</td><td id="6-1g">93,417</td><td id="6-1h">76,455</td></tr>
<tr><td id="6-1i">Commitments and contingencies</td><td id="6-1j"></td><td id="6-1k"></td></tr>
<tr><td id="6-1l">Stockholders&#x27; equity:</td><td id="6-1m"></td><td id="6-1n"></td></tr>
<tr><td id="6-1o">Common stock, $0.000006 par value; 5,000 million Class A shares authorized, 2,190 million and 2,211 million shares issued and outstanding, as of December 31, 2024 and 2023, respectively; 4,141 million Class B shares authorized, 344 million and 350 million shares issued and outstanding, as of December 31, 2024 and 2023, respectively</td><td id="6-1p">—</td><td id="6-1q">—</td></tr>
<tr><td id="6-1r">Additional paid-in capital</td><td id="6-1s">83,228</td><td id="6-1t">73,253</td></tr>
<tr><td id="6-1u">Accumulated other comprehensive loss</td><td id="6-1v">(3,097)</td><td id="6-1w">(2,155)</td></tr>
<tr><td id="6-1x">Retained earnings</td><td id="6-1y">102,506</td><td id="6-1z">82,070</td></tr>
<tr><td id="6-1A">Total stockholders&#x27; equity</td><td id="6-1B">182,637</td><td id="6-1C">153,168</td></tr>
<tr><td id="6-1D">Total liabilities and stockholders&#x27; equity</td><td id="6-1E">$ 276,054</td><td id="6-1F">$ 229,623</td></tr>
</table>

<a id='960fa3d5-8aa9-472e-9872-8d7a35ffa6ed'></a>

See Accompanying Notes to Consolidated Financial Statements.

<a id='999ae64e-6a53-4e54-99c3-8cbe65830a68'></a>

86

<!-- PAGE BREAK -->

<a id='092543cf-8237-4211-a07b-d236470cbf5c'></a>

Table of Contents

<a id='cf9d6706-897f-48d8-ac9e-90d0e42cf05c'></a>

**META PLATFORMS, INC.**
**CONSOLIDATED STATEMENTS OF INCOME**
*(In millions, except per share amounts)*

<a id='3e5e4098-ee4b-47d8-9174-d7997c83f452'></a>

<table id="7-1">
<tr><td id="7-2"></td><td id="7-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="7-4"></td><td id="7-5">2024</td><td id="7-6">2023</td><td id="7-7">2022</td></tr>
<tr><td id="7-8">Revenue</td><td id="7-9">$ 164,501</td><td id="7-a">$ 134,902</td><td id="7-b">$ 116,609</td></tr>
<tr><td id="7-c" colspan="4">Costs and expenses:</td></tr>
<tr><td id="7-d">Cost of revenue</td><td id="7-e">30,161</td><td id="7-f">25,959</td><td id="7-g">25,249</td></tr>
<tr><td id="7-h">Research and development</td><td id="7-i">43,873</td><td id="7-j">38,483</td><td id="7-k">35,338</td></tr>
<tr><td id="7-l">Marketing and sales</td><td id="7-m">11,347</td><td id="7-n">12,301</td><td id="7-o">15,262</td></tr>
<tr><td id="7-p">General and administrative</td><td id="7-q">9,740</td><td id="7-r">11,408</td><td id="7-s">11,816</td></tr>
<tr><td id="7-t">Total costs and expenses</td><td id="7-u">95,121</td><td id="7-v">88,151</td><td id="7-w">87,665</td></tr>
<tr><td id="7-x">Income from operations</td><td id="7-y">69,380</td><td id="7-z">46,751</td><td id="7-A">28,944</td></tr>
<tr><td id="7-B">Interest and other income (expense), net</td><td id="7-C">1,283</td><td id="7-D">677</td><td id="7-E">(125)</td></tr>
<tr><td id="7-F">Income before provision for income taxes</td><td id="7-G">70,663</td><td id="7-H">47,428</td><td id="7-I">28,819</td></tr>
<tr><td id="7-J">Provision for income taxes</td><td id="7-K">8,303</td><td id="7-L">8,330</td><td id="7-M">5,619</td></tr>
<tr><td id="7-N">Net income</td><td id="7-O">$ 62,360</td><td id="7-P">$ 39,098</td><td id="7-Q">$ 23,200</td></tr>
<tr><td id="7-R" colspan="3">Earnings per share:</td><td id="7-S"></td></tr>
<tr><td id="7-T">Basic</td><td id="7-U">24.61</td><td id="7-V">15.19</td><td id="7-W">8.63</td></tr>
<tr><td id="7-X">Diluted</td><td id="7-Y">23.86</td><td id="7-Z">14.87</td><td id="7-10">8.59</td></tr>
<tr><td id="7-11" colspan="4">Weighted-average shares used to compute earnings per share:</td></tr>
<tr><td id="7-12">Basic</td><td id="7-13">2,534</td><td id="7-14">2,574</td><td id="7-15">2,687</td></tr>
<tr><td id="7-16">Diluted</td><td id="7-17">2,614</td><td id="7-18">2,629</td><td id="7-19">2,702</td></tr>
</table>

<a id='efefd71b-971e-468d-bf05-4e98a812e2af'></a>

See Accompanying Notes to Consolidated Financial Statements.

<a id='c1eb8e4e-8c16-45dc-aadf-b496dad075f3'></a>

87

<!-- PAGE BREAK -->

<a id='cd2878d5-d512-411d-80cc-f8aef20197be'></a>

Table of Contents

<a id='9a2c4da8-629d-48ac-94ef-e2f194346801'></a>

META PLATFORMS, INC.
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME
(In millions)

<a id='a001be5d-6a4b-4202-a52a-691d05d336b3'></a>

<table id="8-1">
<tr><td id="8-2"></td><td id="8-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="8-4"></td><td id="8-5">2024</td><td id="8-6">2023</td><td id="8-7">2022</td></tr>
<tr><td id="8-8">Net income</td><td id="8-9">$ 62,360</td><td id="8-a">$ 39,098</td><td id="8-b">$ 23,200</td></tr>
<tr><td id="8-c">Other comprehensive income (loss):</td><td id="8-d"></td><td id="8-e"></td><td id="8-f"></td></tr>
<tr><td id="8-g">Change in foreign currency translation adjustment, net of tax</td><td id="8-h">(1,413)</td><td id="8-i">618</td><td id="8-j">(1,184)</td></tr>
<tr><td id="8-k">Change in unrealized gain (loss) on available-for-sale investments and other, net of tax</td><td id="8-l">471</td><td id="8-m">757</td><td id="8-n">(1,653)</td></tr>
<tr><td id="8-o">Comprehensive income</td><td id="8-p">$ 61,418</td><td id="8-q">$ 40,473</td><td id="8-r">$ 20,363</td></tr>
</table>

<a id='2b3cd5d7-fcb6-4279-96c3-8a51eb6ad0af'></a>

See Accompanying Notes to Consolidated Financial Statements.

<a id='0caaac8c-d03a-48e0-a83a-b9f8c53c16c1'></a>

88

<!-- PAGE BREAK -->

<a id='fb665876-792f-4a24-bace-15623ef4368a'></a>

Table of Contents

<a id='c3f49307-3c9f-4be8-b406-135178173e3c'></a>

META PLATFORMS, INC.
CONSOLIDATED STATEMENTS OF STOCKHOLDERS' EQUITY
(In millions, except per share amounts)

<a id='bc30c76a-49ef-4c8e-9513-c2b7782b8a4a'></a>

<table id="9-1">
<tr><td id="9-2"></td><td id="9-3" colspan="2">Class A and Class B Common Stock</td><td id="9-4"></td><td id="9-5" rowspan="2">Accumulated Other Comprehensive Income (Loss)</td><td id="9-6"></td><td id="9-7" rowspan="2">Total Stockholders&#x27; Equity</td></tr>
<tr><td id="9-8"></td><td id="9-9">Shares</td><td id="9-a">Par Value</td><td id="9-b">Additional Paid-In Capital</td><td id="9-c">Retained Earnings</td></tr>
<tr><td id="9-d">Balances at December 31, 2021</td><td id="9-e">2,741</td><td id="9-f">$ —</td><td id="9-g">$ 55,811</td><td id="9-h">$ (693)</td><td id="9-i">$ 69,761</td><td id="9-j">$ 124,879</td></tr>
<tr><td id="9-k">Issuance of common stock</td><td id="9-l">54</td><td id="9-m">—</td><td id="9-n">—</td><td id="9-o">—</td><td id="9-p">—</td><td id="9-q">—</td></tr>
<tr><td id="9-r">Shares withheld related to net share settlement</td><td id="9-s">(20)</td><td id="9-t">—</td><td id="9-u">(3,359)</td><td id="9-v">—</td><td id="9-w">(236)</td><td id="9-x">(3,595)</td></tr>
<tr><td id="9-y">Share-based compensation</td><td id="9-z">—</td><td id="9-A">—</td><td id="9-B">11,992</td><td id="9-C">—</td><td id="9-D">—</td><td id="9-E">11,992</td></tr>
<tr><td id="9-F">Share repurchases</td><td id="9-G">(161)</td><td id="9-H">—</td><td id="9-I">—</td><td id="9-J">—</td><td id="9-K">(27,926)</td><td id="9-L">(27,926)</td></tr>
<tr><td id="9-M">Other comprehensive loss</td><td id="9-N">—</td><td id="9-O">—</td><td id="9-P">—</td><td id="9-Q">(2,837)</td><td id="9-R">—</td><td id="9-S">(2,837)</td></tr>
<tr><td id="9-T">Net income</td><td id="9-U">—</td><td id="9-V">—</td><td id="9-W">—</td><td id="9-X">—</td><td id="9-Y">23,200</td><td id="9-Z">23,200</td></tr>
<tr><td id="9-10">Balances at December 31, 2022</td><td id="9-11">2,614</td><td id="9-12">—</td><td id="9-13">64,444</td><td id="9-14">(3,530)</td><td id="9-15">64,799</td><td id="9-16">125,713</td></tr>
<tr><td id="9-17">Issuance of common stock</td><td id="9-18">65</td><td id="9-19">—</td><td id="9-1a">—</td><td id="9-1b">—</td><td id="9-1c">—</td><td id="9-1d">—</td></tr>
<tr><td id="9-1e">Shares withheld related to net share settlement</td><td id="9-1f">(26)</td><td id="9-1g">—</td><td id="9-1h">(5,218)</td><td id="9-1i">—</td><td id="9-1j">(1,794)</td><td id="9-1k">(7,012)</td></tr>
<tr><td id="9-1l">Share-based compensation</td><td id="9-1m">—</td><td id="9-1n">—</td><td id="9-1o">14,027</td><td id="9-1p">—</td><td id="9-1q">—</td><td id="9-1r">14,027</td></tr>
<tr><td id="9-1s">Share repurchases</td><td id="9-1t">(92)</td><td id="9-1u">—</td><td id="9-1v">—</td><td id="9-1w">—</td><td id="9-1x">(20,033)</td><td id="9-1y">(20,033)</td></tr>
<tr><td id="9-1z">Other comprehensive income</td><td id="9-1A">—</td><td id="9-1B">—</td><td id="9-1C">—</td><td id="9-1D">1,375</td><td id="9-1E">—</td><td id="9-1F">1,375</td></tr>
<tr><td id="9-1G">Net income</td><td id="9-1H"></td><td id="9-1I"></td><td id="9-1J"></td><td id="9-1K"></td><td id="9-1L">39,098</td><td id="9-1M">39,098</td></tr>
<tr><td id="9-1N">Balances at December 31, 2023</td><td id="9-1O">2,561</td><td id="9-1P"></td><td id="9-1Q">73,253</td><td id="9-1R">(2,155)</td><td id="9-1S">82,070</td><td id="9-1T">153,168</td></tr>
<tr><td id="9-1U">Issuance of common stock</td><td id="9-1V">65</td><td id="9-1W"></td><td id="9-1X"></td><td id="9-1Y"></td><td id="9-1Z">—</td><td id="9-20">—</td></tr>
<tr><td id="9-21">Shares withheld related to net share settlement</td><td id="9-22">(27)</td><td id="9-23"></td><td id="9-24">(6,721)</td><td id="9-25"></td><td id="9-26">(7,049)</td><td id="9-27">(13,770)</td></tr>
<tr><td id="9-28">Share-based compensation</td><td id="9-29"></td><td id="9-2a"></td><td id="9-2b">16,690</td><td id="9-2c"></td><td id="9-2d">—</td><td id="9-2e">16,690</td></tr>
<tr><td id="9-2f">Share repurchases</td><td id="9-2g">(65)</td><td id="9-2h">–</td><td id="9-2i">–</td><td id="9-2j">–</td><td id="9-2k">(29,754)</td><td id="9-2l">(29,754)</td></tr>
<tr><td id="9-2m">Dividends and dividend equivalents declared ($2.00 per share)</td><td id="9-2n">–</td><td id="9-2o">–</td><td id="9-2p">–</td><td id="9-2q">–</td><td id="9-2r">(5,121)</td><td id="9-2s">(5,121)</td></tr>
<tr><td id="9-2t">Other</td><td id="9-2u">–</td><td id="9-2v">–</td><td id="9-2w">6</td><td id="9-2x">–</td><td id="9-2y">—</td><td id="9-2z">6</td></tr>
<tr><td id="9-2A">Other comprehensive loss</td><td id="9-2B">–</td><td id="9-2C">–</td><td id="9-2D">–</td><td id="9-2E">(942)</td><td id="9-2F">—</td><td id="9-2G">(942)</td></tr>
<tr><td id="9-2H">Net income</td><td id="9-2I"></td><td id="9-2J"></td><td id="9-2K"></td><td id="9-2L"></td><td id="9-2M">62,360</td><td id="9-2N">62,360</td></tr>
<tr><td id="9-2O">Balances at December 31, 2024</td><td id="9-2P">2,534</td><td id="9-2Q">$ -</td><td id="9-2R">$ 83,228</td><td id="9-2S">$ (3,097)</td><td id="9-2T">$ 102,506</td><td id="9-2U">$ 182,637</td></tr>
</table>

<a id='3b7e48ae-4377-46e9-90e8-05ea22ea6270'></a>

___(1) Our dividend program began in the first quarter of 2024.

<a id='431b881a-b63a-4e72-a1fb-6712dee92e50'></a>

See Accompanying Notes to Consolidated Financial Statements.

<a id='7a54c905-e155-4429-8a41-78b91a6baf7e'></a>

89

<!-- PAGE BREAK -->

<a id='ade838b3-39f8-4bef-bb2d-cbf79525c0a2'></a>

Table of Contents

<a id='ed7bf8ac-32b3-4354-b25c-08572846a65b'></a>

META PLATFORMS, INC.
CONSOLIDATED STATEMENTS OF CASH FLOWS
(_In millions_)

<a id='8bdf78f3-6ff7-4046-8844-29bdd3e18f66'></a>

<table id="10-1">
<tr><td id="10-2"></td><td id="10-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="10-4"></td><td id="10-5">2024</td><td id="10-6">2023</td><td id="10-7">2022</td></tr>
<tr><td id="10-8" colspan="4">Cash flows from operating activities</td></tr>
<tr><td id="10-9">Net income</td><td id="10-a">$ 62,360</td><td id="10-b">$ 39,098</td><td id="10-c">$ 23,200</td></tr>
<tr><td id="10-d" colspan="2">Adjustments to reconcile net income to net cash provided by operating activities:</td><td id="10-e" colspan="2"></td></tr>
<tr><td id="10-f">Depreciation and amortization</td><td id="10-g">15,498</td><td id="10-h">11,178</td><td id="10-i">8,686</td></tr>
<tr><td id="10-j">Share-based compensation</td><td id="10-k">16,690</td><td id="10-l">14,027</td><td id="10-m">11,992</td></tr>
<tr><td id="10-n">Deferred income taxes</td><td id="10-o">(4,738)</td><td id="10-p">131</td><td id="10-q">(3,286)</td></tr>
<tr><td id="10-r">Impairment charges for facilities consolidation</td><td id="10-s">383</td><td id="10-t">2,432</td><td id="10-u">2,218</td></tr>
<tr><td id="10-v">Data center assets abandonment</td><td id="10-w">--</td><td id="10-x">(224)</td><td id="10-y">1,341</td></tr>
<tr><td id="10-z">Other</td><td id="10-A">87</td><td id="10-B">635</td><td id="10-C">641</td></tr>
<tr><td id="10-D" colspan="4">Changes in assets and liabilities:</td></tr>
<tr><td id="10-E">Accounts receivable</td><td id="10-F">(1,485)</td><td id="10-G">(2,399)</td><td id="10-H">231</td></tr>
<tr><td id="10-I">Prepaid expenses and other current assets</td><td id="10-J">(698)</td><td id="10-K">559</td><td id="10-L">162</td></tr>
<tr><td id="10-M">Other assets</td><td id="10-N">(270)</td><td id="10-O">80</td><td id="10-P">(106)</td></tr>
<tr><td id="10-Q">Accounts payable</td><td id="10-R">373</td><td id="10-S">51</td><td id="10-T">210</td></tr>
<tr><td id="10-U">Accrued expenses and other current liabilities</td><td id="10-V">323</td><td id="10-W">5,081</td><td id="10-X">4,300</td></tr>
<tr><td id="10-Y">Other liabilities</td><td id="10-Z">2,805</td><td id="10-10">624</td><td id="10-11">886</td></tr>
<tr><td id="10-12">Net cash provided by operating activities</td><td id="10-13">91,328</td><td id="10-14">71,113</td><td id="10-15">50,475</td></tr>
<tr><td id="10-16" colspan="4">Cash flows from investing activities</td></tr>
<tr><td id="10-17">Purchases of property and equipment</td><td id="10-18">(37,256)</td><td id="10-19">(27,045)</td><td id="10-1a">(31,186)</td></tr>
<tr><td id="10-1b">Purchases of marketable securities</td><td id="10-1c">(25,542)</td><td id="10-1d">(2,982)</td><td id="10-1e">(9,626)</td></tr>
<tr><td id="10-1f">Sales and maturities of marketable securities</td><td id="10-1g">15,789</td><td id="10-1h">6,184</td><td id="10-1i">13,158</td></tr>
<tr><td id="10-1j">Acquisitions of business and intangible assets</td><td id="10-1k">(270)</td><td id="10-1l">(629)</td><td id="10-1m">(1,312)</td></tr>
<tr><td id="10-1n">Other investing activities</td><td id="10-1o">129</td><td id="10-1p">(23)</td><td id="10-1q">(4)</td></tr>
<tr><td id="10-1r">Net cash used in investing activities</td><td id="10-1s">(47,150)</td><td id="10-1t">(24,495)</td><td id="10-1u">(28,970)</td></tr>
<tr><td id="10-1v" colspan="4">Cash flows from financing activities</td></tr>
<tr><td id="10-1w">Taxes paid related to net share settlement of equity awards</td><td id="10-1x">(13,770)</td><td id="10-1y">(7,012)</td><td id="10-1z">(3,595)</td></tr>
<tr><td id="10-1A">Repurchases of Class A common stock</td><td id="10-1B">(30,125)</td><td id="10-1C">(19,774)</td><td id="10-1D">(27,956)</td></tr>
<tr><td id="10-1E">Payments for dividends and dividend equivalents</td><td id="10-1F">(5,072)</td><td id="10-1G">—</td><td id="10-1H">—</td></tr>
<tr><td id="10-1I">Proceeds from issuance of long-term debt, net</td><td id="10-1J">10,432</td><td id="10-1K">8,455</td><td id="10-1L">9,921</td></tr>
<tr><td id="10-1M">Principal payments on finance leases</td><td id="10-1N">(1,969)</td><td id="10-1O">(1,058)</td><td id="10-1P">(850)</td></tr>
<tr><td id="10-1Q">Other financing activities</td><td id="10-1R">(277)</td><td id="10-1S">(111)</td><td id="10-1T">344</td></tr>
<tr><td id="10-1U">Net cash used in financing activities</td><td id="10-1V">(40,781)</td><td id="10-1W">(19,500)</td><td id="10-1X">(2,136)</td></tr>
<tr><td id="10-1Y">Effect of exchange rate changes on cash, cash equivalents, and restricted cash</td><td id="10-1Z">(786)</td><td id="10-20">113</td><td id="10-21">(638)</td></tr>
<tr><td id="10-22">Net increase (decrease) in cash, cash equivalents, and restricted cash</td><td id="10-23">2,611</td><td id="10-24">27,231</td><td id="10-25">(1,269)</td></tr>
<tr><td id="10-26">Cash, cash equivalents, and restricted cash at beginning of the period</td><td id="10-27">42,827</td><td id="10-28">15,596</td><td id="10-29">16,865</td></tr>
<tr><td id="10-2a">Cash, cash equivalents, and restricted cash at end of the period</td><td id="10-2b">$                                        45,438</td><td id="10-2c">$                                        42,827</td><td id="10-2d">$                                        15,596</td></tr>
<tr><td id="10-2e">Reconciliation of cash, cash equivalents, and restricted cash to the consolidated balance sheets</td><td id="10-2f" colspan="3"></td></tr>
<tr><td id="10-2g">Cash and cash equivalents</td><td id="10-2h">$                                        43,889</td><td id="10-2i">$                                        41,862</td><td id="10-2j">$                                        14,681</td></tr>
<tr><td id="10-2k">Restricted cash, included in prepaid expenses and other current assets</td><td id="10-2l">353</td><td id="10-2m">99</td><td id="10-2n">294</td></tr>
<tr><td id="10-2o">Restricted cash, included in other assets</td><td id="10-2p">1,196</td><td id="10-2q">866</td><td id="10-2r">621</td></tr>
<tr><td id="10-2s">Total cash, cash equivalents, and restricted cash</td><td id="10-2t">$ 45,438</td><td id="10-2u">$ 42,827</td><td id="10-2v">$ 15,596</td></tr>
</table>

<a id='a0223979-e8df-4e4f-af79-46aec0533896'></a>

_See Accompanying Notes to Consolidated Financial Statements._

<a id='6ea19fde-203c-4570-89dc-625abfd631fe'></a>

90

<!-- PAGE BREAK -->

<a id='8d14cee1-d80f-4627-9489-899910b4dd68'></a>

Table of Contents

<a id='ab18c2db-fc8d-4108-b3f3-c53f05aea75f'></a>

**META PLATFORMS, INC.**
**CONSOLIDATED STATEMENTS OF CASH FLOWS**
*(In millions)*

<a id='61477bd4-fb66-47cc-b59f-31db39fa8357'></a>

<table id="11-1">
<tr><td id="11-2"></td><td id="11-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="11-4"></td><td id="11-5">2024</td><td id="11-6">2023</td><td id="11-7">2022</td></tr>
<tr><td id="11-8" colspan="4">Supplemental cash flow data</td></tr>
<tr><td id="11-9">Cash paid for income taxes, net</td><td id="11-a">10,554</td><td id="11-b">6,607</td><td id="11-c">6,407</td></tr>
<tr><td id="11-d">Cash paid for interest, net of amounts capitalized</td><td id="11-e">486</td><td id="11-f">448</td><td id="11-g">—</td></tr>
<tr><td id="11-h" colspan="4">Non-cash investing and financing activities:</td></tr>
<tr><td id="11-i">Property and equipment in accounts payable and accrued expenses and other current liabilities</td><td id="11-j">7,127</td><td id="11-k">4,105</td><td id="11-l">3,319</td></tr>
<tr><td id="11-m">Acquisition of businesses and intangible assets in accrued expenses and other current liabilities and other liabilities</td><td id="11-n">172</td><td id="11-o">119</td><td id="11-p">291</td></tr>
<tr><td id="11-q">Repurchases of Class A common stock in accrued expenses and other current liabilities</td><td id="11-r">---</td><td id="11-s">474</td><td id="11-t">310</td></tr>
</table>

<a id='fc1dbe93-34bb-4b4d-a8c9-4f1168b657d9'></a>

See Accompanying Notes to Consolidated Financial Statements.

<a id='2b3c17ed-c896-4c32-90e7-10d89fc0c0e1'></a>

91

<!-- PAGE BREAK -->

<a id='3b1078c2-4e19-44b4-88da-a6ed09c28d90'></a>

Table of Contents

<a id='cd86c8a9-d084-4cd9-9653-03051beee2c0'></a>

META PLATFORMS, INC.
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

<a id='8c1c5a01-ab7e-48b0-a241-ca38de53cccc'></a>

Note 1. Summary of Significant Accounting Policies

<a id='9f8f74f9-8a4a-4711-b52c-6667fea68146'></a>

*Organization and Description of Business*

We were incorporated in Delaware in July 2004. Our mission is to build the future of human connection and the technology that makes it possible.

We report our financial results based on two reportable segments: Family of Apps (FoA) and Reality Labs (RL). The segment information aligns with how the chief operating decision maker (CODM), who is our chief executive officer (CEO), reviews and manages the business. We generate substantially all of our revenue from advertising.

<a id='fd577c62-f962-47aa-81f0-97279e6272b7'></a>

_Basis of Presentation_

We prepared the consolidated financial statements in accordance with U.S. generally accepted accounting principles (GAAP). The consolidated financial statements include the accounts of Meta Platforms, Inc., its subsidiaries where we have controlling financial interests, and any variable interest entities for which we are deemed to be the primary beneficiary. All intercompany balances and transactions have been eliminated.

<a id='ba74f36a-27ef-4aa4-beb5-fa10ce7dc58a'></a>

Balance Sheets Reclassifications

Certain prior period amounts on the consolidated balance sheets have been reclassified to conform to current period presentation.

*   Intangible assets, net was reclassified into other assets
*   Partners payable was reclassified into accrued expenses and other current liabilities
*   Long-term income taxes was reclassified out of other liabilities

<a id='ba90d3f4-1a6a-4748-9219-d7996c3373ed'></a>

These reclassifications had no impact on our previously reported total assets, total liabilities, revenue, income from operations, net income or cash flows.

<a id='e1a4725c-cff9-4b28-a304-4fd39000bff7'></a>

Use of Estimates

Preparation of consolidated financial statements in conformity with GAAP requires the use of estimates and judgments that affect the reported amounts in the consolidated financial statements and accompanying notes. These estimates form the basis for judgments we make about the carrying values of our assets and liabilities, which are not readily apparent from other sources. We base our estimates and judgments on historical information and on various other assumptions that we believe are reasonable under the circumstances. GAAP requires us to make estimates and judgments in several areas, including, but not limited to, those related to loss contingencies, income taxes, valuation of long-lived assets and their associated estimated useful lives, valuation of non-marketable equity securities, revenue recognition, valuation of goodwill, credit losses of available-for-sale (AFS) debt securities and accounts receivable, and fair value of financial instruments and leases. These estimates are based on management's knowledge about current events, interpretation of regulations, and expectations about actions we may undertake in the future. Actual results could differ materially from those estimates.

<a id='0c957ef3-fc36-49ed-9a38-c827cd87a902'></a>

In January 2025, we completed an assessment of the useful lives of certain servers and network assets, and determined we should extend the estimated useful lives to 5.5 years. This change in accounting estimate will be effective beginning fiscal year 2025.

<a id='44d08a51-580b-4190-8a25-106e990553cf'></a>

92

<!-- PAGE BREAK -->

<a id='e5f8b229-d1ce-42c9-a8a8-a48d5263d11a'></a>

Table of Contents

<a id='3ebc2082-e04e-4b23-90cb-f26225ee36ed'></a>

### Revenue Recognition

We recognize revenue under Accounting Standards Codification (ASC) 606 *Revenue from Contracts with Customers*. Revenue is recognized when control of the promised goods or services is transferred to our customers, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services.

<a id='4f4e2c66-9269-4937-8bc1-e9231581ff74'></a>

Sales commissions we pay in connection with contracts are expensed when incurred because the amortization period is one year or less. These costs are recorded within marketing and sales on our consolidated statements of income. We do not disclose the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

<a id='0a836858-d3ac-4bef-a6eb-710ae7cfd41b'></a>

Revenue includes sales and usage-based taxes, except for cases where we are acting as a pass-through agent.

<a id='ee1b234f-32e5-491a-bb14-d23391ea8521'></a>

_Advertising Revenue_

Advertising revenue is generated by displaying ad products on Facebook, Instagram, Messenger, and third-party mobile applications. Marketers pay for ad products either directly or through their relationships with advertising agencies or resellers, based on the number of impressions delivered or the number of actions, such as clicks, taken by our users.

<a id='9a09e1ed-4139-4821-8361-07521a5f223c'></a>

We recognize revenue from the display of impression-based ads in the contracted period in which the impressions are delivered. Impressions are considered delivered when an ad is displayed to users. We recognize revenue from the delivery of action-based ads in the period in which a user takes the action the marketer contracted for. In general, we report advertising revenue on a gross basis, since we control the advertising inventory before it is transferred to our customers. Our control is evidenced by our sole ability to monetize the advertising inventory before it is transferred to our customers.

<a id='89608fd9-97d1-4dd7-bd30-5775837af103'></a>

For revenue generated from arrangements that involve third-parties, we evaluate whether we are the principal, and report revenue on a gross basis, or the agent, and report revenue on a net basis. In this assessment, we consider if we obtain control of the specified goods or services before they are transferred to the customer, as well as other indicators such as the party primarily responsible for fulfillment, inventory risk, and discretion in establishing price.

<a id='3a694293-1aa0-4529-a53e-b864f815fcec'></a>

We may accept lower consideration than the amount promised per the contract for certain revenue transactions and certain customers may receive cash-based incentives, credits, or refunds, which are accounted for as variable consideration when estimating the amount of revenue to recognize. We estimate these amounts and reduce revenue based on the amounts expected to be provided to customers. We believe that there will not be significant changes to our estimates of variable consideration for the reported periods.

<a id='67173808-0e88-4df9-8bc4-9b2583200415'></a>

_Reality Labs Revenue_

RL revenue is generated from the delivery of consumer hardware products, such as Meta Quest and Ray-Ban Meta AI glasses, and related software and content. Revenue is recognized at the time control of the products is transferred to customers, which is generally at the time of delivery, in an amount that reflects the consideration RL expects to be entitled to in exchange for the products.

<a id='6d488464-950a-4191-90c9-26d989a6e95e'></a>

_Other Revenue_

FoA other revenue consists of revenue from WhatsApp Business Platform, Meta Verified subscriptions, net fees we receive from developers using our Payments infrastructure, and revenue from various other sources.

<a id='00ebf77c-cbfe-46a1-919c-dceb75c79801'></a>

_Cost of Revenue_

Our cost of revenue consists of expenses associated with the delivery and distribution of our products. These mainly include expenses related to the operation of our data centers and technical infrastructure, such as depreciation expense from servers, network infrastructure and buildings, employee compensation which includes payroll, share-based compensation and benefits for employees on our operations teams, and energy and bandwidth costs. Cost of revenue also consists of costs associated with partner arrangements, including traffic acquisition costs and credit card and other fees related to processing customer transactions; RL inventory costs, which consist of cost of products sold and estimated losses on non-cancelable contractual commitments; and content costs.

<a id='c16bbb1e-bdce-4eff-bc3e-2e9e9f57571f'></a>

93

<!-- PAGE BREAK -->

<a id='b02bad13-655e-4e04-add2-3d5f2556a9e3'></a>

Table of Contents

<a id='b2f6fd2d-4526-4596-bb18-1557dbd02fda'></a>

_Content Costs_

Our content costs are mostly related to payments to content providers from whom we license video and music to increase engagement on the platform. We pay fees to these content providers based on revenue generated, a flat fee, or both. For licensed video, we expense the cost per title when the title is accepted and available for viewing if the capitalization criteria are not met. Video content costs that meet the criteria for capitalization were not material to date.

<a id='99711cea-c24d-43fd-abb2-678745c313e1'></a>

For licensed music, we expense the license fees over the contractual license period. We pay fees to music partners based on revenue generated, minimum guaranteed fees, flat fees, or a combination thereof. Expensed content costs are included in cost of revenue on our consolidated statements of income.

<a id='e70a2d6d-333a-45af-938b-e4ee6cb14b19'></a>

***Software Development Costs***

Software development costs, including costs to develop software products or the software component of products to be marketed or sold to external users, are expensed before the software or technology reach technological feasibility, which is typically reached shortly before the release of such products.

<a id='02feb7b9-35cf-4259-95dd-b718901c4546'></a>

Software development costs also include costs to develop software to be used solely to meet internal needs and applications used to deliver our services. These software development costs meet the criteria for capitalization once the preliminary project stage is complete, and it is probable that the project will be completed and the software will be used to perform the function intended. Software development costs that meet the criteria for capitalization were not material to date.

<a id='dc86268c-b040-4d82-b4e4-a47ec5d97c2b'></a>

**Share-based Compensation**

Share-based compensation expense consists of the company's restricted stock units (RSUs) expense. RSUs granted to employees are measured based on the grant-date fair value. In general, our RSUs vest over a service period of four years. Share-based compensation expense is generally recognized on the straight-line basis over the requisite service period and forfeitures are accounted for as they occur.

<a id='1540b5d4-d401-46e8-a677-3a9c8cc12241'></a>

## Income Taxes

We are subject to income taxes in the United States and numerous foreign jurisdictions. Significant judgment is required in determining our provision for income taxes and income tax assets and liabilities, including evaluating uncertainties in the application of accounting principles and complex tax laws.

<a id='50be8af2-52c7-4b62-b970-c2c91467fcd8'></a>

We record a provision for income taxes for the anticipated tax consequences of the reported results of operations using the asset and liability method. Under this method, we recognize deferred income tax assets and liabilities for the expected future consequences of temporary differences between the financial reporting and tax bases of assets and liabilities, as well as for loss and tax credit carryforwards. Deferred tax assets and liabilities are measured using the tax rates that are expected to apply to taxable income for the years in which those tax assets and liabilities are expected to be realized or settled. We recognize the deferred income tax effects of a change in tax rates in the period of the enactment.

<a id='81117c24-e777-4a18-bc58-5286c7d5c3cc'></a>

We record a valuation allowance to reduce our deferred tax assets to the net amount that we believe is more likely than not to be realized. We consider all available evidence, both positive and negative, including historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing tax planning strategies in assessing the need for a valuation allowance.

<a id='bfc43895-a020-4079-b98d-06021077802c'></a>

We recognize tax benefits from uncertain tax positions only if we believe that it is more likely than not that the tax position will be sustained on examination by the taxing authorities based on the technical merits of the position. We recognize interest and penalties related to uncertain tax positions as a component of the provision for income taxes.

<a id='907c3d70-b85d-47b0-9514-02c737a1d6ef'></a>

_Advertising Expense_

Advertising costs are expensed when incurred and are included in marketing and sales expenses on our consolidated statements of income. We incurred advertising expenses of $2.06 billion, $2.02 billion, and $2.65 billion for the years ended December 31, 2024, 2023, and 2022, respectively.

<a id='f8eb6c7c-6008-4e3c-b787-dbacfb942303'></a>

94

<!-- PAGE BREAK -->

<a id='df56b05b-fa81-482e-8f0b-b04f5808db27'></a>

Table of Contents

<a id='61f1403d-d852-4497-af96-75508fd3f057'></a>

*Cash and Cash Equivalents, Marketable Securities, and Restricted Cash*

Cash and cash equivalents consist of cash on deposit with financial institutions globally and highly liquid investments with maturities of 90 days or less from the date of purchase. We classify amounts in transit from customer credit cards and payment service providers as cash on our consolidated balance sheets.

<a id='718dc0a4-0f45-458e-b136-12e3db733ceb'></a>

We hold investments in marketable debt securities, consisting of U.S. government securities, U.S. government agency securities, and investment grade corporate debt securities. We classify our marketable debt securities as available-for-sale (AFS) investments in our current assets because they represent investments of cash available for current operations. Our AFS investments are carried at estimated fair value with any unrealized gains and losses, net of taxes, included in accumulated other comprehensive income (loss) in stockholders' equity. AFS debt securities with an amortized cost basis in excess of estimated fair value are assessed to determine what amount of that difference, if any, is caused by expected credit losses. Allowance for credit losses on AFS debt securities are recognized as a charge in interest and other income (expense), net on our consolidated statements of income, and any remaining unrealized losses, net of taxes, are included in accumulated other comprehensive income (loss) in stockholders' equity. We determine realized gains or losses on sale of marketable securities on a specific identification method and include such gains or losses in interest and other income (expense), net on our consolidated statements of income.

<a id='d65c14f1-e7b2-4a11-9f80-c1a0b8da3567'></a>

We also hold investments in marketable equity securities that are publicly traded stocks. We classify these equity securities as marketable securities within current assets on our consolidated balance sheets because they are available to be converted into cash to fund current operations without any restriction. These marketable equity securities are measured at fair value at each reporting date with the resulted unrealized gains and losses recognized in interest and other income (expense), net on our consolidated statements of income.

<a id='ae1e67e9-acfd-471a-9908-82fd4d7f9460'></a>

We classify certain restricted cash balances, consisting mostly of cash related to insurance policies, cash reserves designated for a specific purpose, as well as retention and indemnification holdback for our acquisitions, within prepaid expenses and other current assets and other assets on our consolidated balance sheets, based upon the expected duration of the restrictions.

<a id='fa7eb05c-7483-4726-9309-0b892e9ecb38'></a>

**Non-marketable Equity Securities**Our non-marketable equity securities are investments in privately-held companies without readily determinable fair values. We elected to account for substantially all of our non-marketable equity securities using the measurement alternative, which is cost, less any impairment, adjusted for changes in fair value resulting from observable transactions for identical or similar investments of the same issuer as of the respective transaction dates. We periodically review our non-marketable equity securities for impairment. When indicators exist and the estimated fair value of an investment is below its carrying amount, we write down the investment to fair value. The change in carrying value, resulted from the remeasurements, is recognized in interest and other income (expense), net on our consolidated statements of income. For additional information, see Note 6 — Non-marketable Equity Securities.

<a id='cb502c5e-4438-4bac-bd07-8968adfb0946'></a>

In addition, we also held other non-marketable equity securities accounted for under the equity method which were not material as of December 31,
2024 and 2023.

<a id='f4537520-19e1-4b5a-a0f7-ecf007d4f5e0'></a>

_Fair Value Measurements_

We apply fair value accounting for all financial assets and liabilities and non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. We define fair value as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities, which are required to be recorded at fair value, we consider the principal or most advantageous market in which we would transact and the market-based risk measurements or assumptions that market participants would use in pricing the asset or liability, such as risks inherent in valuation techniques, transfer restrictions and credit risk. Fair value is estimated by applying the following hierarchy, which prioritizes the inputs used to measure fair value into three levels and bases the categorization within the hierarchy upon the lowest level of input that is available and significant to the fair value measurement:

<a id='055f4742-fa54-446d-9cfe-2b03f8a99ae9'></a>

Level 1- Quoted prices in active markets for identical assets or liabilities.

<a id='c8810da7-98b8-4e09-8489-a46956d266cb'></a>

95

<!-- PAGE BREAK -->

<a id='d52fd183-9e37-46ef-b4ae-3ecf9ab071dd'></a>

Table of Contents

Level 2- Observable inputs other than quoted prices in active markets for identical assets and liabilities, quoted prices for identical or similar assets or liabilities in inactive markets, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the assets or liabilities.

<a id='e1ec6383-75f6-4cc0-8814-89ce98feb446'></a>

Level 3- Inputs that are generally unobservable and typically reflect management's estimate of assumptions that market participants would use in pricing the asset or liability.

<a id='80e14f00-27ae-4bed-a0f9-29caf0759b57'></a>

Our cash equivalents, marketable securities, and restricted cash equivalents are classified within Level 1 or Level 2 of the fair value hierarchy because their fair values are derived from quoted market prices or alternative pricing sources and models utilizing observable market inputs. Certain other assets are classified within Level 3 because factors used to develop the estimated fair value are unobservable inputs that are not supported by market activity.

<a id='1ceeda51-9fd4-4308-8bd8-599527bbebf4'></a>

Our non-marketable equity securities accounted for using the measurement alternative are recorded at fair value on a non-recurring basis. When indicators of impairment exist or observable price changes of qualified transactions occur, the respective non-marketable equity security would be classified within Level 3 of the fair value hierarchy because the valuation methods include a combination of the observable transaction price at the transaction date and other unobservable inputs including volatility, rights, and obligations of the securities we hold.

<a id='ac728b0e-d5d8-4b86-8c56-9b80a01274c7'></a>

## Accounts Receivable and Allowances

Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. We make estimates of expected credit and collectibility trends for the allowance for credit losses and allowance for unbilled receivables based upon our assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of our customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from customers. Expected credit losses are recorded as general and administrative expenses on our consolidated statements of income. As of December 31, 2024 and 2023, the allowance for credit losses on accounts receivable were not material.

<a id='98e69255-4835-45f4-92b1-3a4b5c5b30bf'></a>

_Property and Equipment_

Property and equipment, including finance leases, are depreciated and stated at cost less accumulated depreciation. Depreciation is computed using the straight-line method over the estimated useful lives of the assets or the remaining lease term, whichever is shorter.

<a id='5376681d-6cb5-4565-bdb4-0082b5ea2227'></a>

The estimated useful lives of property and equipment and amortization periods of finance lease right-of-use (ROU) assets as of December 31, 2024 are described below:

<a id='06356cdf-e8cd-4a34-bde6-ab6df22db3dc'></a>

<table id="16-1">
<tr><td id="16-2">Property and Equipment</td><td id="16-3">Useful Life/ Amortization period</td></tr>
<tr><td id="16-4">Servers and network assets</td><td id="16-5">Four to Five years (1)</td></tr>
<tr><td id="16-6">Buildings</td><td id="16-7">25 to 30 years</td></tr>
<tr><td id="16-8">Equipment and other</td><td id="16-9">One to 25 years</td></tr>
<tr><td id="16-a">Finance lease right-of-use assets</td><td id="16-b">Five to 20 years</td></tr>
<tr><td id="16-c">Leasehold improvements</td><td id="16-d">Lesser of estimated useful life or remaining lease term</td></tr>
</table>

<a id='939fcb5d-a9cb-48ac-b61c-d0dfd47c8ace'></a>

(1) Effective January 2025, the useful lives of certain servers and network assets are extended to 5.5 years.

<a id='dd05ed76-6a19-4d76-abd4-c17cddfcd40e'></a>

We evaluate at least annually the recoverability of property and equipment for possible impairment whenever events or circumstances indicate that the carrying amount of such assets may not be recoverable. If such review indicates that the carrying amount of property and equipment assets is not recoverable, and the asset's fair value is less than the carrying amount, an impairment charge is recognized.

<a id='bb12e1d4-89d9-42ae-ba9c-3a3e9de3275b'></a>

The useful lives of our property and equipment are management's estimates when the assets are initially recognized and are routinely reviewed for the remaining estimated useful lives. Our estimate of useful lives represents the best estimate of the useful lives based on current facts and circumstances, but may differ from the actual useful lives due to changes to our business operations, changes in the planned use of assets, and technological advancements. When we change the estimated

<a id='c2485fae-1eb3-4e6b-8e38-822f370bbfa5'></a>

96

<!-- PAGE BREAK -->

<a id='4640aa2f-3f79-4a62-8c7d-86bd6a27a494'></a>

Table of Contents

<a id='c9f91807-47eb-471e-b21e-b6bd696e6748'></a>

useful life assumption for any asset, the remaining carrying amount of the asset is accounted for prospectively and depreciated or amortized over the revised estimated useful life.

<a id='58049819-e793-4f65-a601-37e14d248271'></a>

Servers and network assets include equipment mostly in our data centers, which is used to support production traffic. Land and assets held within construction in progress (CIP) are not depreciated. CIP assets are related to the construction or development of property and equipment that have not yet been placed in service for their intended use. We also capitalize interest on our debt related to certain eligible CIP assets and depreciate over the useful life of the related assets.

<a id='23144746-12bf-4742-99d0-7094c2fb5650'></a>

The cost of maintenance and repairs is expensed as incurred. When assets are retired or otherwise disposed of, the cost and related accumulated depreciation are removed from their respective accounts, and gain or loss on such sale or disposal is reflected in income from operations.

<a id='9859c90d-a498-4d9a-97cf-147a50a467e7'></a>

**Lease Obligations**

Our operating leases mostly comprise of certain data centers, offices, and colocations. We also have finance leases for certain network infrastructure. We determine if an arrangement is a lease at inception and most of our leases contain lease and non-lease components. Non-lease components include fixed payments for maintenance, utilities, real estate taxes, and management fees. We combine fixed lease and non-lease components and account for them as a single lease component. Our lease agreements may contain variable costs such as contingent rent escalations, common area maintenance, insurance, real estate taxes, or other costs. These amounts are affected by the Consumer Price Index, payments contingent on energy production for renewable energy purchase arrangements, and maintenance and utilities. Such variable lease costs are expensed as incurred on our consolidated statements of income. For certain colocation and equipment leases, we apply a portfolio approach to effectively account for the operating lease ROU assets and lease liabilities.

<a id='e022b590-1238-4436-b17a-b8e336a28eb3'></a>

For leases with a lease term greater than 12 months, ROU assets and lease liabilities are recognized on our consolidated balance sheets at the commencement date based on the present value of the remaining fixed lease payments and includes only payments that are fixed and determinable at the time of commencement.

<a id='6157a16f-336a-4f3e-8bd9-e9016ac18da8'></a>

Our lease terms may include options to extend or terminate the lease when it is reasonably certain that we will exercise such options. When determining the probability of exercising such options, we consider contract-based, asset-based, entity-based, and market-based factors. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured. Our lease agreements generally do not contain any material residual value guarantees or material restrictive covenants.

<a id='137932f2-8e0f-425c-9c43-10ded4e1e880'></a>

As most of our leases do not provide an implicit rate, we use our incremental borrowing rate based on the information available at the commencement date in determining the present value of lease payments. Our incremental borrowing rate is based on our understanding of what our credit rating would be in a similar economic environment.

<a id='4fd288fe-4eff-4049-9ce1-3fd4c4b8388a'></a>

Operating leases are included in operating lease ROU assets, operating lease liabilities, current, and operating lease liabilities, non-current on our consolidated balance sheets. Finance leases are included in property and equipment, net, accrued expenses and other current liabilities, and other liabilities on our consolidated balance sheets.

<a id='ee96bccf-2cde-490f-b838-49f353625b8b'></a>

Operating lease costs are recognized on a straight-line basis over the lease terms. Finance lease assets are amortized on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease terms.

<a id='cff7259d-365c-4406-b05e-560870538e92'></a>

During the year ended December 31, 2024, 2023 and 2022, we recorded net impairment losses of $383 million, $2.43 billion, and $2.22 billion, respectively, in aggregate for operating lease ROU assets and leasehold improvements under ASC Topic 360 as a part of our facilities consolidation restructuring efforts. The fair values of the impaired assets were estimated using discounted cash flow models (income approach) based on market participant assumptions with Level 3 inputs. The assumptions used in estimating fair value include the expected downtime prior to the commencement of future subleases, projected sublease income over the remaining lease periods, and discount rates that reflect the level of risk associated with receiving future cash flows. For additional information regarding our restructuring efforts, see Note 3 --- Restructuring.

<a id='0d381c36-8143-434d-85f4-d3557d475acb'></a>

97

<!-- PAGE BREAK -->

<a id='772a4ca4-81a1-4ebc-a8ac-8121f2ca9b35'></a>

Table of Contents

<a id='6f09087c-3994-45c2-8240-75a102007d9a'></a>

*Loss Contingencies*

We are involved in legal proceedings, claims, and regulatory, tax or government inquiries and investigations that arise in the ordinary course of business. Certain of these matters include speculative claims for substantial or indeterminate amounts of damages. Additionally, we are required to comply with various legal and regulatory obligations around the world, and we regularly become subject to new laws and regulations in the jurisdictions in which we operate. The requirements for complying with these obligations may be uncertain and subject to interpretation and enforcement by regulatory and other authorities, and any failure to comply with such obligations could eventually lead to asserted legal or regulatory action. With respect to these matters, asserted and unasserted, we evaluate the associated developments on a regular basis and accrue a liability when we believe that it is both probable that a loss has been incurred and the amount can be reasonably estimated. We record such losses as general and administrative expenses on our consolidated statements of income.

<a id='f7dd2ee6-ed38-41d1-8403-162003927fa6'></a>

If we determine that a loss is probable or reasonably possible and the loss or range of loss can be reasonably estimated, we disclose the possible loss in the accompanying notes to the consolidated financial statements to the extent material.

<a id='dc8dfe04-7142-440b-bd8e-143c36106d6e'></a>

***Business Combinations***

We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values as of the acquisition date. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill to reporting units based on the expected benefit from the business combination. Allocation of purchase consideration to identifiable assets and liabilities affects the amortization expense, as acquired finite-lived intangible assets are amortized over the useful life, whereas any indefinite-lived intangible assets, including goodwill, are not amortized. During the measurement period, which is not to exceed one year from the acquisition date, we record adjustments to the assets acquired and liabilities assumed, with the corresponding offset to goodwill. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings. Acquisition-related expenses are recognized separately from business combinations and are expensed as incurred.

<a id='5923730c-97a7-4538-924a-1478cffe8dba'></a>

## Goodwill and Intangibles Assets

We allocate goodwill to reporting units based on the expected benefit from business combinations. We evaluate our reporting units annually, as well as when changes in our operating segments occur. For changes in reporting units, we reassign goodwill using a relative fair value allocation approach. Goodwill is tested for impairment at the reporting unit level annually or more frequently if events or changes in circumstances would more likely than not reduce the fair value of a reporting unit below its carrying value. We have two reporting units, Family of Apps (FoA) and Reality Labs (RL), subject to goodwill impairment testing. As of December 31, 2024, no impairment of goodwill has been identified.

<a id='3ab528a5-e45c-413a-a60f-38891f38bf05'></a>

We evaluate the recoverability of finite-lived intangible assets for possible impairment whenever events or circumstances indicate that the carrying amount of such assets may not be recoverable. The evaluation of these intangible assets are performed at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities. Recoverability of these assets is measured by a comparison of the carrying amounts to the future undiscounted cash flows the assets are expected to generate from the use and eventual disposition. If such review indicates that the carrying amount of a finite-lived intangible asset is not recoverable and the asset's fair value is less than the carrying amount, an impairment charge is recognized. The impairment charges of finite-lived intangible assets were not material during the reporting periods presented.

<a id='fa455b5d-6375-4d70-a73c-3cb74a44c78f'></a>

Our finite-lived intangible assets are amortized on a straight-line basis over the estimated useful lives of the assets. Indefinite-lived intangible assets are not amortized. If an indefinite-lived intangible asset is subsequently determined to have a finite useful life, the asset will be tested for impairment and accounted for as a finite-lived intangible asset prospectively over its estimated remaining useful life. We routinely review the remaining estimated useful lives of finite-lived intangible assets. If we change the estimated useful life assumption for any asset, the remaining unamortized balance is amortized over the revised estimated useful life. Intangible assets are included within other assets on our consolidated balance sheet.

<a id='adccb298-915e-4557-a897-f77334b28fc4'></a>

*Foreign Currency*

Generally, the functional currency of our international subsidiaries is the local currency. We translate the financial statements of these subsidiaries to U.S. dollars using month-end rates of exchange for assets and liabilities, and average rates of exchange for revenue, costs, and expenses. Translation gains and losses are recorded in accumulated other comprehensive

<a id='c0f0b3d6-e220-4b32-aeb6-39142e6944d0'></a>

98

<!-- PAGE BREAK -->

<a id='5d1db6d1-715d-4330-b4e8-24c0ddb5a305'></a>

Table of Contents

<a id='8c0f748e-28da-4608-803e-3547cb192033'></a>

income (loss) as a component of stockholders' equity. As of December 31, 2024 and 2023, we had cumulative translation losses, net of tax, of $2.66 billion and $1.24 billion, respectively.

<a id='ffba8227-0c39-43b8-a4e4-9a2e45c6ee2d'></a>

Foreign currency transaction gains and losses from transactions denominated in a currency other than the functional currency of the subsidiary involved are recorded within interest and other income (expense), net on our consolidated statements of income. Net losses resulting from foreign currency transactions were $690 million, $366 million, and $81 million for the years ended December 31, 2024, 2023, and 2022, respectively.

<a id='c917089c-fb7d-4744-9e9f-86ef42dcf0cd'></a>

**Credit Risk and Concentration**

Our financial instruments that are potentially subject to concentrations of credit risk consist primarily of cash, cash equivalents, restricted cash, marketable debt securities, and accounts receivable. Cash equivalents consists mostly of money market funds, that primarily invest in U.S. government and agency securities. Marketable debt securities consist of investments in U.S. government securities, U.S. government agency securities, and investment grade corporate debt securities. As part of our cash management strategy, we concentrate cash deposits with large financial institutions and our marketable debt securities are held in diversified highly rated securities. Our investment portfolio in corporate debt securities is highly liquid and diversified among individual issuers. The amount of credit losses recorded for the year ended December 31, 2024 was not material.

<a id='87a0f2ce-f737-4dd6-bfe2-bd9c39d8f393'></a>

Accounts receivable are typically unsecured and are derived from revenue earned from customers across different industries and countries. We generated 36%, 37%, and 40% of our revenue for the years ended December 31, 2024, 2023, and 2022, respectively, from marketers and developers based in the United States, with a majority of the revenue outside of the United States in 2024 coming from customers located in western Europe, China, Brazil, Australia, India and Canada.

<a id='e817df0e-3ff6-4a5d-baa7-fe762cd3d628'></a>

We perform ongoing credit evaluations of our customers and generally do not require collateral. We maintain an allowance for estimated credit losses,
and bad debt expense on these losses was not material during the years ended December 31, 2024, 2023, and 2022. In the event that accounts receivable
collection cycles deteriorate, our operating results and financial position could be adversely affected.

<a id='3e6bbc38-524d-46e2-a247-45c1715e8a01'></a>

No customer represented 10% or more of total revenue during the years ended December 31, 2024, 2023, and 2022.

<a id='c944c625-b7c9-4079-a9d8-0ea4d6314c8e'></a>

*Recently Adopted Accounting Pronouncements*

Beginning in 2024 annual reporting, we adopted Accounting Standards Update (ASU) No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (ASU 2023-07) that was issued by the Financial Accounting Standards Board (FASB). This new standard requires an enhanced disclosure of significant segment expenses on an annual and interim basis. Upon adoption, the guidance was applied retrospectively to all prior periods presented in the financial statements, which resulted in the disclosure of employee compensation costs for each reportable segment. For additional information, see Note 16 — Segment and Geographical Information.

<a id='0ff94f29-f469-4059-8459-565c0a5b7aae'></a>

_Accounting Pronouncements Not Yet Adopted_

In December 2023, the FASB issued ASU No. 2023-09, _Income Taxes (Topic 740): Improvements to Income Tax Disclosures_ (ASU 2023-09), which improves the transparency of income tax disclosures by requiring consistent categories and greater disaggregation of information in the effective tax rate reconciliation and income taxes paid disaggregated by jurisdiction. It also includes certain other amendments to improve the effectiveness of income tax disclosures. This new standard will be effective for the annual periods beginning the year ended December 31, 2025. The new standard permits early adoption and can be applied prospectively or retrospectively. We do not expect the adoption of this guidance to have a material impact on our consolidated financial statements.

<a id='93ab2614-6f36-4254-8ebc-677a99420b48'></a>

In November 2024, the FASB issued ASU No. 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses (ASU 2024-03). The new guidance requires disaggregated information about certain income statement expense line items on an annual and interim basis. This guidance will be effective for annual periods beginning the year ended December 31, 2027 and for interim periods thereafter. The new standard permits early adoption and can be applied prospectively or retrospectively. We are evaluating the effect that this guidance will have on our consolidated financial statements and related disclosures.

<a id='28b1448c-0670-49ad-83e5-747f67ba64fc'></a>

99

<!-- PAGE BREAK -->

<a id='f3780309-f0ad-41cd-b2fe-1d7bc4e51124'></a>

Table of Contents

<a id='6caf7a6d-648a-45a5-8772-f3c8eb299ce9'></a>

Note 2. Revenue
Revenue disaggregated by revenue source and by segment consists of the following (in millions):
<table id="20-1">
<tr><td id="20-2"></td><td id="20-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="20-4"></td><td id="20-5">2024</td><td id="20-6">2023</td><td id="20-7">2022</td></tr>
<tr><td id="20-8">Advertising</td><td id="20-9">160,633</td><td id="20-a">131,948</td><td id="20-b">113,642</td></tr>
<tr><td id="20-c">Other revenue</td><td id="20-d">1,722</td><td id="20-e">1,058</td><td id="20-f">808</td></tr>
<tr><td id="20-g">Family of Apps</td><td id="20-h">162,355</td><td id="20-i">133,006</td><td id="20-j">114,450</td></tr>
<tr><td id="20-k">Reality Labs</td><td id="20-l">2,146</td><td id="20-m">1,896</td><td id="20-n">2,159</td></tr>
<tr><td id="20-o">Total revenue</td><td id="20-p">$ 164,501</td><td id="20-q">$ 134,902</td><td id="20-r">$ 116,609</td></tr>
</table>

<a id='60668e6c-632e-4115-aade-1fbf1b07e505'></a>

Revenue disaggregated by geography, based on the addresses of our customers, consists of the following (in millions):
<table id="20-s">
<tr><td id="20-t"></td><td id="20-u" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="20-v"></td><td id="20-w">2024</td><td id="20-x">2023</td><td id="20-y">2022</td></tr>
<tr><td id="20-z">United States and Canada (1)</td><td id="20-A">63,207</td><td id="20-B">52,888</td><td id="20-C">50,150</td></tr>
<tr><td id="20-D">Europe (3)</td><td id="20-E">38,361</td><td id="20-F">31,210</td><td id="20-G">26,681</td></tr>
<tr><td id="20-H">Asia-Pacific (2)</td><td id="20-I">45,009</td><td id="20-J">36,154</td><td id="20-K">27,760</td></tr>
<tr><td id="20-L">Rest of World (3)</td><td id="20-M">17,924</td><td id="20-N">14,650</td><td id="20-O">12,018</td></tr>
<tr><td id="20-P">Total revenue</td><td id="20-Q">$ 164,501</td><td id="20-R">$ 134,902</td><td id="20-S">$ 116,609</td></tr>
</table>

<a id='28c25f98-2a1e-4fb4-bb7f-373cb4dd13b8'></a>

(1) United States revenue was $59.73 billion, $49.78 billion, and $47.20 billion for the years ended December 31, 2024, 2023, and 2022, respectively.
(2) China revenue was $18.35 billion, $13.69 billion, and $7.40 billion for the years ended December 31, 2024, 2023, and 2022, respectively.
(3) Europe includes Russia and Turkey, and Rest of World includes Africa, Latin America, and the Middle East.

<a id='4ed612b4-33b0-445b-a119-4f6a9b63daf5'></a>

Total deferred revenue was $772 million and $675 million as of December 31, 2024 and 2023, respectively. As of December 31, 2024, we expect $721 million of our deferred revenue to be realized in less than a year.

<a id='74de766e-a3c7-4232-a487-572190276bd4'></a>

100

<!-- PAGE BREAK -->

<a id='e7887326-6685-42cd-8db7-b598da55e146'></a>

Table of Contents

<a id='1b7f810c-0d60-411a-9359-de8d92959330'></a>

## Note 3. Restructuring

### *2022 Restructuring*

In 2022, we initiated several measures to pursue greater efficiency and to realign our business and strategic priorities. These measures included a facilities consolidation strategy to sublease, early terminate, or abandon several office buildings under operating leases, a layoff of approximately 11,000 employees across the Family of Apps (FoA) and Reality Labs (RL) segments, and a pivot towards a next generation data center design, including cancellation of multiple data center projects (the 2022 Restructuring). As of December 31, 2024, we have completed the 2022 restructuring initiatives.

<a id='6c0f1d26-50fe-4632-8a49-110cc1e9a3a1'></a>

A summary of our 2022 Restructuring pre-tax charges for the years ended December 31, 2024, 2023, and 2022, including subsequent adjustments, is as follows (in millions):

<a id='ab67ebdc-ff2d-404b-a809-17c27cc10e04'></a>

<table id="21-1">
<tr><td id="21-2"></td><td id="21-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="21-4"></td><td id="21-5">2024 (0)</td><td id="21-6">2023</td><td id="21-7">2022</td></tr>
<tr><td id="21-8">Cost of revenue</td><td id="21-9">31</td><td id="21-a">(47)</td><td id="21-b">1,495</td></tr>
<tr><td id="21-c">Research and development</td><td id="21-d">254</td><td id="21-e">1,572</td><td id="21-f">1,719</td></tr>
<tr><td id="21-g">Marketing and sales</td><td id="21-h">54</td><td id="21-i">395</td><td id="21-j">638</td></tr>
<tr><td id="21-k">General and administrative</td><td id="21-l">50</td><td id="21-m">335</td><td id="21-n">759</td></tr>
<tr><td id="21-o">Total</td><td id="21-p">389</td><td id="21-q">2,255</td><td id="21-r">4,611</td></tr>
</table>

<a id='f29ddd0a-36e5-4d76-9ece-83e9b8f27cad'></a>

___(1) The 2024 charges are all related to facilities consolidation.

<a id='b63de52a-b0cc-4002-ae03-913e89b12df4'></a>

<table id="21-s">
<tr><td id="21-t"></td><td id="21-u" colspan="4">Plan to Date</td></tr>
<tr><td id="21-v"></td><td id="21-w">Facilities Consolidation</td><td id="21-x">Severance and Other Personnel Costs</td><td id="21-y">Data Center Assets</td><td id="21-z">Total</td></tr>
<tr><td id="21-A">Cost of revenue</td><td id="21-B">$ 362</td><td id="21-C">$ —</td><td id="21-D">$ 1,116</td><td id="21-E">$ 1,478</td></tr>
<tr><td id="21-F">Research and development</td><td id="21-G">3,146</td><td id="21-H">399</td><td id="21-I">—</td><td id="21-J">3,545</td></tr>
<tr><td id="21-K">Marketing and sales</td><td id="21-L">854</td><td id="21-M">233</td><td id="21-N">--</td><td id="21-O">1,087</td></tr>
<tr><td id="21-P">General and administrative</td><td id="21-Q">828</td><td id="21-R">316</td><td id="21-S"></td><td id="21-T">1,144</td></tr>
<tr><td id="21-U">Total</td><td id="21-V">5,190</td><td id="21-W">948</td><td id="21-X">1,116</td><td id="21-Y">7,254</td></tr>
</table>

<a id='2eb9f669-073a-4578-9c50-a03e004f3d60'></a>

Total restructuring charges recorded under our FoA segment were $305 million, $1.74 billion, and $4.10 billion, and RL segment were $84 million, $516 million and $515 million for the years ended December 31, 2024, 2023, and 2022, respectively.

<a id='4565116b-8947-4dd9-87df-4b35164e9c2b'></a>

*2023 Restructuring*

The 2023 Restructuring charges for severance and related personnel costs were $1.20 billion for the year ended December 31, 2023. We completed the 2023 restructuring as of December 31, 2023.

<a id='41a38b10-b2b5-4d48-87c3-b7c59a39456b'></a>

101

<!-- PAGE BREAK -->

<a id='28ff41a0-441a-4282-a7c3-ed1a7b919382'></a>

Table of Contents

<a id='0a5fa09f-526a-48d2-b653-3e1a85d79501'></a>

**Note 4. Earnings per Share**
The holders of our Class A and Class B common stock (together, "common stock") have identical liquidation and dividend rights but different voting rights. Accordingly, we present the earnings per share (EPS) for Class A and Class B common stock together.

<a id='353781a0-52b3-41b3-b921-4599da172750'></a>

Basic EPS is computed by dividing net income by the weighted-average number of shares of our common stock outstanding. Diluted EPS is computed by dividing net income by the weighted-average number of fully diluted common stock outstanding and assumes the conversion of our Class B common stock to Class A common stock.

<a id='0d7d203a-4ece-45cb-9c26-dc50605337ef'></a>

Class A common stock equivalent of restricted stock units (RSUs) with anti-dilutive effect were not material for the year ended December 31, 2024. For the years ended December 31, 2023, and 2022, approximately 16 million and 95 million shares of RSUs were excluded from the diluted EPS calculation, respectively, as including them would have an anti-dilutive effect.

<a id='fe99cadc-6c8a-459f-8e1c-9e69691ec229'></a>

The numerators and denominators of the basic and diluted EPS computations for our common stock are calculated as follows (in millions, except per share amounts):

<a id='1340ae6d-a3fa-466b-b81f-03fc1938d153'></a>

<table id="22-1">
<tr><td id="22-2"></td><td id="22-3" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="22-4"></td><td id="22-5">2024</td><td id="22-6">2023</td><td id="22-7">2022 (2)</td></tr>
<tr><td id="22-8" colspan="4">Basic EPS:</td></tr>
<tr><td id="22-9" colspan="4">Numerator</td></tr>
<tr><td id="22-a">Distributed earnings</td><td id="22-b">$ 5,072</td><td id="22-c">$ —</td><td id="22-d">$ —</td></tr>
<tr><td id="22-e">Undistributed earnings</td><td id="22-f">57,288</td><td id="22-g">39,098</td><td id="22-h">23,200</td></tr>
<tr><td id="22-i">Net income</td><td id="22-j">$ 62,360</td><td id="22-k">$ 39,098</td><td id="22-l">$ 23,200</td></tr>
<tr><td id="22-m">Denominator</td><td id="22-n" colspan="2"></td><td id="22-o"></td></tr>
<tr><td id="22-p">Shares used in computation of basic EPS (1)</td><td id="22-q">2,534</td><td id="22-r">2,574</td><td id="22-s">2,687</td></tr>
<tr><td id="22-t">Basic EPS</td><td id="22-u">$ 24.61</td><td id="22-v">$ 15.19</td><td id="22-w">$ 8.63</td></tr>
<tr><td id="22-x">Diluted EPS:</td><td id="22-y"></td><td id="22-z"></td><td id="22-A"></td></tr>
<tr><td id="22-B" colspan="4">Numerator</td></tr>
<tr><td id="22-C">Net income for diluted EPS</td><td id="22-D">$ 62,360</td><td id="22-E">$ 39,098</td><td id="22-F">$ 23,200</td></tr>
<tr><td id="22-G" colspan="4">Denominator</td></tr>
<tr><td id="22-H">Shares used in computation of basic EPS (1)</td><td id="22-I">2,534</td><td id="22-J">2,574</td><td id="22-K">2,687</td></tr>
<tr><td id="22-L">Effect of dilutive RSUs</td><td id="22-M">80</td><td id="22-N">55</td><td id="22-O">15</td></tr>
<tr><td id="22-P">Shares used in computation of diluted EPS</td><td id="22-Q">2,614</td><td id="22-R">2,629</td><td id="22-S">2,702</td></tr>
<tr><td id="22-T">Diluted EPS</td><td id="22-U">$ 23.86</td><td id="22-V">$ 14.87</td><td id="22-W">$ 8.59</td></tr>
</table>

<a id='0f369d22-f1ce-46dd-b865-f017a4bd5d3a'></a>

(1) Includes 2,189 million, 2,220 million, and 2,285 million shares of Class A common stock and 345 million, 354 million, and 402 million shares of Class B common stock, for the years ended December 31, 2024, 2023, and 2022, respectively.
(2) The prior period EPS for Class A and Class B common stock has been presented together to conform with current period presentation, which had no impact on our previously reported basic or diluted EPS.

<a id='6f6c3aa2-6343-4abc-bf66-829229596725'></a>

We declared and paid four quarterly cash dividends, including dividend equivalents, totaling $2.00 for each share of common stock during the year ended December 31, 2024. Total dividends and dividend equivalents paid for Class A and Class B common stock were $4.38 billion and $691 million, respectively, during the year ended December 31, 2024. EPS for Class B common stock is not presented separately as under the two-class method Class A and Class B EPS is not meaningfully different.

<a id='6d9f03f7-6167-4f8b-abd3-b45570e7618d'></a>

102

<!-- PAGE BREAK -->

<a id='aa5d0a5e-1739-46b9-907e-77dfd6b1b348'></a>

Table of Contents

<a id='f9e577dc-6ac4-48fc-b156-6affd8f40738'></a>

Note 5. Financial Instruments

Fair Value Measurements

Our cash equivalents, marketable securities, and restricted cash equivalents are classified within Level 1 or Level 2 of the fair value hierarchy because their fair values are derived from quoted market prices or alternative pricing sources and models utilizing market observable inputs. Certain other assets are classified within Level 3 because factors used to develop the estimated fair value are unobservable inputs that are not supported by market activity.

<a id='68c9df89-7f63-4055-a280-ae788ebf8e3f'></a>

The following tables summarize our assets measured at fair value on a recurring basis and the classification by level of input within the fair value
hierarchy (in millions):
<table id="23-1">
<tr><td id="23-2"></td><td id="23-3"></td><td id="23-4" colspan="3">Fair Value Measurement at Reporting Date Using</td></tr>
<tr><td id="23-5">Description</td><td id="23-6">December 31, 2024</td><td id="23-7">Quoted Prices in Active Markets for Identical Assets (Level 1)</td><td id="23-8">Significant Other Observable Inputs (Level 2)</td><td id="23-9">Significant Unobservable Inputs (Level 3)</td></tr>
<tr><td id="23-a" colspan="5">Cash equivalents:</td></tr>
<tr><td id="23-b">Money market funds</td><td id="23-c">$ 36,165</td><td id="23-d">$ 36,165</td><td id="23-e">$ —</td><td id="23-f">$ —</td></tr>
<tr><td id="23-g">U.S. government and agency securities</td><td id="23-h">23</td><td id="23-i">23</td><td id="23-j">—</td><td id="23-k">—</td></tr>
<tr><td id="23-l">Time deposits</td><td id="23-m">369</td><td id="23-n">--</td><td id="23-o">369</td><td id="23-p">--</td></tr>
<tr><td id="23-q">Corporate debt securities</td><td id="23-r">114</td><td id="23-s">--</td><td id="23-t">114</td><td id="23-u">--</td></tr>
<tr><td id="23-v">Total cash equivalents</td><td id="23-w">36,671</td><td id="23-x">36,188</td><td id="23-y">483</td><td id="23-z">--</td></tr>
<tr><td id="23-A" colspan="5">Marketable securities:</td></tr>
<tr><td id="23-B">U.S. government securities</td><td id="23-C">14,889</td><td id="23-D">14,889</td><td id="23-E">--</td><td id="23-F">--</td></tr>
<tr><td id="23-G">U.S. government agency securities</td><td id="23-H">3,053</td><td id="23-I">3,053</td><td id="23-J">—</td><td id="23-K">—</td></tr>
<tr><td id="23-L">Corporate debt securities</td><td id="23-M">14,758</td><td id="23-N">—</td><td id="23-O">14,758</td><td id="23-P">—</td></tr>
<tr><td id="23-Q">Marketable equity securities</td><td id="23-R">1,226</td><td id="23-S">1,226</td><td id="23-T">—</td><td id="23-U">—</td></tr>
<tr><td id="23-V">Total marketable securities</td><td id="23-W">33,926</td><td id="23-X">19,168</td><td id="23-Y">14,758</td><td id="23-Z">—</td></tr>
<tr><td id="23-10">Restricted cash equivalents</td><td id="23-11">1,193</td><td id="23-12">1,193</td><td id="23-13">—</td><td id="23-14">—</td></tr>
<tr><td id="23-15">Other assets</td><td id="23-16">101</td><td id="23-17">—</td><td id="23-18">—</td><td id="23-19">101</td></tr>
<tr><td id="23-1a">Total</td><td id="23-1b">$ 71,891</td><td id="23-1c">$ 56,549</td><td id="23-1d">$ 15,241</td><td id="23-1e">$ 101</td></tr>
</table>

<a id='2dc60d8b-b371-4df7-bfa2-de29c8c05bef'></a>

103

<!-- PAGE BREAK -->

<a id='8acf913f-931c-4cc2-b42c-d1f61c9c5cc5'></a>

Table of Contents

<a id='af798337-4749-4fd7-8ff2-2867b9f575a2'></a>

<table id="24-1">
<tr><td id="24-2"></td><td id="24-3"></td><td id="24-4" colspan="3">Fair Value Measurement at Reporting Date Using</td></tr>
<tr><td id="24-5">Description</td><td id="24-6">December 31, 2023</td><td id="24-7">Quoted Prices in Active Markets for Identical Assets (Level 1)</td><td id="24-8">Significant Other Observable Inputs (Level 2)</td><td id="24-9">Significant Unobservable Inputs (Level 3)</td></tr>
<tr><td id="24-a">Cash equivalents:</td><td id="24-b" colspan="4"></td></tr>
<tr><td id="24-c">Money market funds</td><td id="24-d">$ 32,910</td><td id="24-e">$ 32,910</td><td id="24-f">$ —</td><td id="24-g">$ —</td></tr>
<tr><td id="24-h">U.S. government and agency securities</td><td id="24-i">2,206</td><td id="24-j">2,206</td><td id="24-k">—</td><td id="24-l">—</td></tr>
<tr><td id="24-m">Time deposits</td><td id="24-n">261</td><td id="24-o">–</td><td id="24-p">261</td><td id="24-q">–</td></tr>
<tr><td id="24-r">Corporate debt securities</td><td id="24-s">220</td><td id="24-t">–</td><td id="24-u">220</td><td id="24-v">–</td></tr>
<tr><td id="24-w">Total cash equivalents</td><td id="24-x">35,597</td><td id="24-y">35,116</td><td id="24-z">481</td><td id="24-A">–</td></tr>
<tr><td id="24-B" colspan="5">Marketable securities:</td></tr>
<tr><td id="24-C">U.S. government securities</td><td id="24-D">8,439</td><td id="24-E">8,439</td><td id="24-F">–</td><td id="24-G">–</td></tr>
<tr><td id="24-H">U.S. government agency securities</td><td id="24-I">3,498</td><td id="24-J">3,498</td><td id="24-K">—</td><td id="24-L">—</td></tr>
<tr><td id="24-M">Corporate debt securities</td><td id="24-N">11,604</td><td id="24-O">—</td><td id="24-P">11,604</td><td id="24-Q">—</td></tr>
<tr><td id="24-R">Total marketable securities</td><td id="24-S">23,541</td><td id="24-T">11,937</td><td id="24-U">11,604</td><td id="24-V">—</td></tr>
<tr><td id="24-W">Restricted cash equivalents</td><td id="24-X">857</td><td id="24-Y">857</td><td id="24-Z">—</td><td id="24-10">—</td></tr>
<tr><td id="24-11">Other assets</td><td id="24-12">101</td><td id="24-13">—</td><td id="24-14">—</td><td id="24-15">101</td></tr>
<tr><td id="24-16">Total</td><td id="24-17">$ 60,096</td><td id="24-18">$ 47,910</td><td id="24-19">$ 12,085</td><td id="24-1a">$ 101</td></tr>
</table>

<a id='fcec2832-a4e5-42c3-bf39-f254e7275e8a'></a>

*Unrealized Losses*

The following tables summarize our available-for-sale marketable debt securities and cash equivalents with unrealized losses as of December 31, 2024 and 2023, aggregated by major security type and the length of time that individual securities have been in a continuous loss position (in millions):

<a id='6b836704-5ffc-464f-b842-a8d12c048c3b'></a>

<table id="24-1b">
<tr><td id="24-1c"></td><td id="24-1d" colspan="6">December 31, 2024</td></tr>
<tr><td id="24-1e"></td><td id="24-1f" colspan="2">Less than 12 months</td><td id="24-1g" colspan="2">12 months or greater</td><td id="24-1h" colspan="2">Total</td></tr>
<tr><td id="24-1i"></td><td id="24-1j">Fair Value</td><td id="24-1k">Unrealized Losses</td><td id="24-1l">Fair Value</td><td id="24-1m">Unrealized Losses</td><td id="24-1n">Fair Value</td><td id="24-1o">Unrealized Losses</td></tr>
<tr><td id="24-1p">U.S. government securities</td><td id="24-1q">$ 6,860</td><td id="24-1r">$ (71)</td><td id="24-1s">$ 4,330</td><td id="24-1t">$ (146)</td><td id="24-1u">$ 11,190</td><td id="24-1v">$ (217)</td></tr>
<tr><td id="24-1w">U.S. government agency securities</td><td id="24-1x">435</td><td id="24-1y">(2)</td><td id="24-1z">2,083</td><td id="24-1A">(44)</td><td id="24-1B">2,518</td><td id="24-1C">(46)</td></tr>
<tr><td id="24-1D">Corporate debt securities</td><td id="24-1E">2,989</td><td id="24-1F">(26)</td><td id="24-1G">6,373</td><td id="24-1H">(192)</td><td id="24-1I">9,362</td><td id="24-1J">(218)</td></tr>
<tr><td id="24-1K">Total</td><td id="24-1L">10,284</td><td id="24-1M">(99)</td><td id="24-1N">12,786</td><td id="24-1O">(382)</td><td id="24-1P">$ 23,070</td><td id="24-1Q">$ (481)</td></tr>
</table>

<a id='97971cc2-564f-4112-a6f1-895fa2fa39ad'></a>

<table id="24-1R">
<tr><td id="24-1S"></td><td id="24-1T" colspan="6">December 31, 2023</td></tr>
<tr><td id="24-1U"></td><td id="24-1V" colspan="2">Less than 12 months</td><td id="24-1W" colspan="2">12 months or greater</td><td id="24-1X" colspan="2">Total</td></tr>
<tr><td id="24-1Y"></td><td id="24-1Z">Fair Value</td><td id="24-20">Unrealized Losses</td><td id="24-21">Fair Value</td><td id="24-22">Unrealized Losses</td><td id="24-23">Fair Value</td><td id="24-24">Unrealized Losses</td></tr>
<tr><td id="24-25">U.S. government securities</td><td id="24-26">$ 336</td><td id="24-27">$ (1)</td><td id="24-28">$ 7,041</td><td id="24-29">$ (275)</td><td id="24-2a">$ 7,377</td><td id="24-2b">$ (276)</td></tr>
<tr><td id="24-2c">U.S. government agency securities</td><td id="24-2d">71</td><td id="24-2e">—</td><td id="24-2f">3,225</td><td id="24-2g">(164)</td><td id="24-2h">3,296</td><td id="24-2i">(164)</td></tr>
<tr><td id="24-2j">Corporate debt securities</td><td id="24-2k">647</td><td id="24-2l">(3)</td><td id="24-2m">10,125</td><td id="24-2n">(491)</td><td id="24-2o">10,772</td><td id="24-2p">(494)</td></tr>
<tr><td id="24-2q">Total</td><td id="24-2r">$ 1,054</td><td id="24-2s">$ (4)</td><td id="24-2t">$ 20,391</td><td id="24-2u">$ (930)</td><td id="24-2v">$ 21,445</td><td id="24-2w">$ (934)</td></tr>
</table>

<a id='7c444f9a-e513-4832-96c7-98b695bc93f8'></a>

The gross unrealized gains on our marketable debt securities were not material as of December 31, 2024 and 2023.

<a id='0edf6122-05b6-45bd-bec1-0fb4cde57020'></a>

104

<!-- PAGE BREAK -->

<a id='a62cc27e-50bb-4eac-bc9d-144eced77097'></a>

Table of Contents

<a id='9179e40b-2f50-4943-b53d-134cf1b2463e'></a>

Contractual Maturities

The following table classifies our marketable debt securities by contractual maturities (in millions):

<a id='67195eda-43c5-4b46-8d4a-34049150f0e8'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3">December 31, 2024</td></tr>
<tr><td id="25-4">Due within one year</td><td id="25-5">7,847</td></tr>
<tr><td id="25-6">Due after one year to five years</td><td id="25-7">24,853</td></tr>
<tr><td id="25-8">Total</td><td id="25-9">32,700</td></tr>
</table>

<a id='0e4c2fce-fa06-4190-8d71-20dfc66534b5'></a>

***Instruments Measured at Fair Value on Non-recurring Basis***

Our non-marketable equity securities accounted for using the measurement alternative are measured at fair value on a non-recurring basis and are classified within Level 3 of the fair value hierarchy because we use significant unobservable inputs to estimate their fair value. For the years ended December 31, 2024 and 2023, changes in the fair value recorded for these non-marketable equity securities were not material. For additional information, see Note 6 — Non-marketable Equity Securities.

<a id='bc51c8bc-ac32-4431-a239-2721dabdc6a1'></a>

**Note 6. Non-marketable Equity Securities** Our non-marketable equity securities are investments in privately-held companies without readily determinable fair values. The following table summarizes our non-marketable equity securities that were measured using measurement alternative and equity method (in millions):

<a id='06c10775-558e-4ca1-8abc-2622a5032446'></a>

<table id="25-a">
<tr><td id="25-b"></td><td id="25-c" colspan="2">December 31,</td></tr>
<tr><td id="25-d"></td><td id="25-e">2024</td><td id="25-f">2023</td></tr>
<tr><td id="25-g">Non-marketable equity securities under measurement alternative:</td><td id="25-h"></td><td id="25-i"></td></tr>
<tr><td id="25-j">Initial cost</td><td id="25-k">$ 6,342</td><td id="25-l">$ 6,389</td></tr>
<tr><td id="25-m">Cumulative upward adjustments</td><td id="25-n">300</td><td id="25-o">293</td></tr>
<tr><td id="25-p">Cumulative impairment/downward adjustments</td><td id="25-q">(624)</td><td id="25-r">(599)</td></tr>
<tr><td id="25-s">Carrying value</td><td id="25-t">6,018</td><td id="25-u">6,083</td></tr>
<tr><td id="25-v">Non-marketable equity securities under equity method</td><td id="25-w">52</td><td id="25-x">58</td></tr>
<tr><td id="25-y">Total non-marketable equity securities</td><td id="25-z">$ 6,070</td><td id="25-A">$ 6,141</td></tr>
</table>

<a id='6ca8a338-654e-4de0-a0cd-a193f4b70d2b'></a>

During the years ended December 31, 2024, 2023 and 2022, impairment and downward adjustments recorded for our non-marketable equity securities that were measured using measurement alternative was $42 million, $101 million, and $447 million, respectively.

<a id='48e867ed-3003-491e-9edb-fa928eefac30'></a>

105

<!-- PAGE BREAK -->

<a id='76ba2a22-ff69-4e8c-b7c2-f23d4919216e'></a>

Table of Contents

<a id='d235c6c1-340b-4e9d-bb18-e4029d67fc0f'></a>

Note 7. Property and Equipment
Property and equipment, net consists of the following (in millions):
<table id="26-1">
<tr><td id="26-2"></td><td id="26-3" colspan="2">December 31,</td></tr>
<tr><td id="26-4"></td><td id="26-5">2024</td><td id="26-6">2023</td></tr>
<tr><td id="26-7">Land</td><td id="26-8">$ 2,561</td><td id="26-9">$ 2,080</td></tr>
<tr><td id="26-a">Servers and network assets</td><td id="26-b">68,397</td><td id="26-c">46,838</td></tr>
<tr><td id="26-d">Buildings</td><td id="26-e">47,076</td><td id="26-f">37,961</td></tr>
<tr><td id="26-g">Leasehold improvements</td><td id="26-h">7,293</td><td id="26-i">6,972</td></tr>
<tr><td id="26-j">Equipment and other</td><td id="26-k">7,150</td><td id="26-l">7,416</td></tr>
<tr><td id="26-m">Finance lease right-of-use assets</td><td id="26-n">5,384</td><td id="26-o">4,185</td></tr>
<tr><td id="26-p">Construction in progress</td><td id="26-q">26,802</td><td id="26-r">24,269</td></tr>
<tr><td id="26-s">Property and equipment, gross</td><td id="26-t">164,663</td><td id="26-u">129,721</td></tr>
<tr><td id="26-v">Less: Accumulated depreciation</td><td id="26-w">(43,317)</td><td id="26-x">(33,134)</td></tr>
<tr><td id="26-y">Property and equipment, net</td><td id="26-z">$ 121,346</td><td id="26-A">$ 96,587</td></tr>
</table>

<a id='5dc5467c-9ad3-4689-9848-9b8c57bddd5a'></a>

Construction in progress includes costs mostly related to construction of data centers, network infrastructure and servers. Depreciation expense on property and equipment was $15.29 billion, $11.02 billion, and $8.50 billion for the years ended December 31, 2024, 2023, and 2022, respectively. Within property and equipment, our servers and network assets depreciation expenses were $11.34 billion, $7.32 billion, and $5.29 billion for the years ended December 31, 2024, 2023, and 2022, respectively. During the year ended December 31, 2024 and 2023, we capitalized $384 million and $283 million of interest expense related to certain eligible construction in progress assets, respectively.

<a id='82b1c30a-365a-4a48-b826-f990b57e3990'></a>

During the year ended December 31, 2024, 2023, and 2022, total impairment losses, including restructuring charges, for property and equipment were $288 million, $738 million and $2.01 billion, respectively. For additional information, see Note 3 --- Restructuring.

<a id='0a4d1271-5389-42d0-82ad-127aa3d79ced'></a>

Note 8. Leases

We have entered into various non-cancelable operating lease agreements mostly for our data centers, offices and colocations. We have also entered into various non-cancelable finance lease agreements for certain network infrastructure. Our leases have original lease periods expiring between 2025 and 2093. Many leases include one or more options to renew.

<a id='77df5a00-624b-430c-a277-6a4f90488ed4'></a>

The components of lease costs are as follows (in millions):
<table id="26-B">
<tr><td id="26-C"></td><td id="26-D" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="26-E"></td><td id="26-F">2024</td><td id="26-G">2023</td><td id="26-H">2022</td></tr>
<tr><td id="26-I">Finance lease cost:</td><td id="26-J"></td><td id="26-K"></td><td id="26-L"></td></tr>
<tr><td id="26-M">Amortization of right-of-use assets</td><td id="26-N">$ 387</td><td id="26-O">$ 349</td><td id="26-P">$ 380</td></tr>
<tr><td id="26-Q">Interest</td><td id="26-R">23</td><td id="26-S">20</td><td id="26-T">16</td></tr>
<tr><td id="26-U">Operating lease cost</td><td id="26-V">2,359</td><td id="26-W">2,091</td><td id="26-X">1,857</td></tr>
<tr><td id="26-Y">Variable lease cost and other</td><td id="26-Z">844</td><td id="26-10">580</td><td id="26-11">363</td></tr>
<tr><td id="26-12">Total</td><td id="26-13">$ 3,613</td><td id="26-14">$ 3,040</td><td id="26-15">$ 2,616</td></tr>
</table>

<a id='5d600c45-f58b-4e31-a089-57de3902b1a2'></a>

We also recorded $385 million, $1.76 billion, and $1.71 billion net impairment losses for operating lease right-of-use assets as a part of our facilities consolidation restructuring efforts for the years ended December 31, 2024, 2023, and 2022, respectively. For additional information, see Note 3 --- Restructuring.

<a id='37b1c50b-ff01-48c0-8d52-c5b6493a2b3e'></a>

106

<!-- PAGE BREAK -->

<a id='37fdb806-592a-4f4e-aaf3-0251046539c7'></a>

Table of Contents

<a id='1f79df5c-9491-4ce3-aca1-1b7f2bbffb28'></a>

Supplemental balance sheet information related to lease liabilities is as follows:

<a id='34e9e0b2-d62c-44f2-bcd0-26474e2ffa8e'></a>

<table id="27-1">
<tr><td id="27-2"></td><td id="27-3" colspan="2">December 31,</td></tr>
<tr><td id="27-4"></td><td id="27-5">2024</td><td id="27-6">2023</td></tr>
<tr><td id="27-7" colspan="3">Weighted-average remaining lease term.</td></tr>
<tr><td id="27-8">Finance leases</td><td id="27-9">13.7 years</td><td id="27-a">14.0 years</td></tr>
<tr><td id="27-b">Operating leases</td><td id="27-c">11.5 years</td><td id="27-d">11.6 years</td></tr>
<tr><td id="27-e" colspan="3">Weighted-average discount rate:</td></tr>
<tr><td id="27-f">Finance leases</td><td id="27-g">3.6%</td><td id="27-h">3.4%</td></tr>
<tr><td id="27-i">Operating leases</td><td id="27-j">3.9%</td><td id="27-k">3.7%</td></tr>
</table>

<a id='72e4e2e3-a760-457e-820a-b61338d99b0b'></a>

The following is a schedule, by years, of maturities of lease liabilities as of December 31, 2024 (in millions):
<table id="27-l">
<tr><td id="27-m"></td><td id="27-n">Operating Leases</td><td id="27-o">Finance Leases</td></tr>
<tr><td id="27-p">2025</td><td id="27-q">2,657</td><td id="27-r">96</td></tr>
<tr><td id="27-s">2026</td><td id="27-t">2,625</td><td id="27-u">68</td></tr>
<tr><td id="27-v">2027</td><td id="27-w">2,575</td><td id="27-x">68</td></tr>
<tr><td id="27-y">2028</td><td id="27-z">2,459</td><td id="27-A">68</td></tr>
<tr><td id="27-B">2029</td><td id="27-C">2,391</td><td id="27-D">64</td></tr>
<tr><td id="27-E">Thereafter</td><td id="27-F">13,022</td><td id="27-G">528</td></tr>
<tr><td id="27-H">Total undiscounted cash flows</td><td id="27-I">25,729</td><td id="27-J">892</td></tr>
<tr><td id="27-K">Less: Imputed interest</td><td id="27-L">(5,495)</td><td id="27-M">(183)</td></tr>
<tr><td id="27-N">Present value of lease liabilities (0)</td><td id="27-O">20,234</td><td id="27-P">709</td></tr>
<tr><td id="27-Q"></td><td id="27-R"></td><td id="27-S"></td></tr>
<tr><td id="27-T">Lease liabilities, current</td><td id="27-U">$ 1,942</td><td id="27-V">$ 76</td></tr>
<tr><td id="27-W">Lease liabilities, non-current</td><td id="27-X">18,292</td><td id="27-Y">633</td></tr>
<tr><td id="27-Z">Present value of lease liabilities (1)</td><td id="27-10">$ 20,234</td><td id="27-11">$ 709</td></tr>
</table>

<a id='9e2fd2b7-e032-4499-b9b2-ca2344f0e568'></a>

(1) Lease liabilities include operating leases under restructuring as a part of our facilities consolidation efforts. For additional information, see Note 3 — Restructuring.

<a id='ae2ff538-a990-43e4-a087-6d7be17d8317'></a>

The table above does not include lease payments that were not fixed at commencement or lease modification. As of December 31, 2024, we have additional operating and finance leases, that have not yet commenced, with total lease obligations of approximately $34.12 billion, mostly for data centers, network infrastructure, and colocations. These operating and finance leases will commence between 2025 and 2030 with lease terms of greater than one year to 30 years.

<a id='6cd08de1-64aa-4aae-80e5-54a524ff42bc'></a>

Supplemental cash flow information related to leases is as follows (in millions):
<table id="27-12">
<tr><td id="27-13"></td><td id="27-14" colspan="3">Year Ended December 31,</td></tr>
<tr><td id="27-15"></td><td id="27-16">2024</td><td id="27-17">2023</td><td id="27-18">2022</td></tr>
<tr><td id="27-19" colspan="4">Cash paid for amounts included in the measurement of lease liabilities:</td></tr>
<tr><td id="27-1a">Operating cash flows for operating leases(1)</td><td id="27-1b">$ 2,830</td><td id="27-1c">$ 2,233</td><td id="27-1d">$ 1,654</td></tr>
<tr><td id="27-1e">Operating cash flows for finance leases</td><td id="27-1f">$ 23</td><td id="27-1g">$ 20</td><td id="27-1h">$ 16</td></tr>
<tr><td id="27-1i">Financing cash flows for finance leases</td><td id="27-1j">1,969</td><td id="27-1k">1,058</td><td id="27-1l">850</td></tr>
<tr><td id="27-1m" colspan="4">Lease liabilities arising from obtaining right-of-use assets:</td></tr>
<tr><td id="27-1n">Operating leases</td><td id="27-1o">3,784</td><td id="27-1p">4,370</td><td id="27-1q">4,366</td></tr>
<tr><td id="27-1r">Finance leases</td><td id="27-1s">181</td><td id="27-1t">588</td><td id="27-1u">223</td></tr>
</table>

<a id='7a336b73-0015-4950-92de-57d0dc3a335f'></a>

(1) Cash flows for operating leases during the year ended December 31, 2024 and 2023 include cash paid for terminations of certain operating leases.

<a id='49ba604a-a8f8-403c-86ad-e9fe5e6265e2'></a>

107

<!-- PAGE BREAK -->

<a id='a4a8cf28-d602-4c3a-be80-310978a0a238'></a>

Table of Contents

<a id='bfaa69fe-1ac0-4edf-a460-038eaaadaec8'></a>

## Note 9. Goodwill and Intangible Assets

Goodwill generated from our business acquisitions was primarily attributable to expected synergies and potential monetization opportunities. Changes in the carrying amount of goodwill by reportable segment for the years ended December 31, 2024 and 2023 are as follows (in millions):

<a id='fb5e4919-eed6-4d1f-a1cf-ec0a3ce5d3d7'></a>

<table id="28-1">
<tr><td id="28-2"></td><td id="28-3">Family of Apps</td><td id="28-4">Reality Labs</td><td id="28-5">Total</td></tr>
<tr><td id="28-6">December 31, 202</td><td id="28-7">$ 19,250</td><td id="28-8">$ 1,056</td><td id="28-9">$ 20,306</td></tr>
<tr><td id="28-a">Acquisitions</td><td id="28-b"></td><td id="28-c">357</td><td id="28-d">357</td></tr>
<tr><td id="28-e">Adjustments</td><td id="28-f">(4)</td><td id="28-g">(5)</td><td id="28-h">(9)</td></tr>
<tr><td id="28-i">December 31, 2023</td><td id="28-j">19,246</td><td id="28-k">1,408</td><td id="28-l">20,654</td></tr>
<tr><td id="28-m">Acquisitions</td><td id="28-n">—</td><td id="28-o">—</td><td id="28-p">—</td></tr>
<tr><td id="28-q">December 31, 2024</td><td id="28-r">$ 19,246</td><td id="28-s">$ 1,408</td><td id="28-t">$ 20,654</td></tr>
</table>

<a id='5428f314-b14d-4bc7-a3b8-6b2929ad1449'></a>

The following table sets forth the major categories of the intangible assets and their weighted-average remaining useful lives (in millions):
<table id="28-u">
<tr><td id="28-v"></td><td id="28-w" colspan="4">December 31, 2024</td><td id="28-x" colspan="3">December 31, 2023</td></tr>
<tr><td id="28-y"></td><td id="28-z">Weighted-Average Remaining Useful Lives (in years)</td><td id="28-A">Gross Carrying Amount</td><td id="28-B">Accumulated Amortization</td><td id="28-C">Net Carrying Amount</td><td id="28-D">Gross Carrying Amount</td><td id="28-E">Accumulated Amortization</td><td id="28-F">Net Carrying Amount</td></tr>
<tr><td id="28-G">Acquired technology</td><td id="28-H">4.6</td><td id="28-I">$ 442</td><td id="28-J">$ (247)</td><td id="28-K">$ 195</td><td id="28-L">$ 478</td><td id="28-M">$ (182)</td><td id="28-N">$ 296</td></tr>
<tr><td id="28-O">Acquired patents</td><td id="28-P">3.7</td><td id="28-Q">252</td><td id="28-R">(165)</td><td id="28-S">87</td><td id="28-T">287</td><td id="28-U">(233)</td><td id="28-V">54</td></tr>
<tr><td id="28-W">Acquired software</td><td id="28-X">2.7</td><td id="28-Y">250</td><td id="28-Z">(58)</td><td id="28-10">192</td><td id="28-11">—</td><td id="28-12">—</td><td id="28-13">—</td></tr>
<tr><td id="28-14">Other</td><td id="28-15">2.0</td><td id="28-16">24</td><td id="28-17">(8)</td><td id="28-18">16</td><td id="28-19">28</td><td id="28-1a">(15)</td><td id="28-1b">13</td></tr>
<tr><td id="28-1c">Total finite-lived assets</td><td id="28-1d"></td><td id="28-1e">968</td><td id="28-1f">(478)</td><td id="28-1g">490</td><td id="28-1h">793</td><td id="28-1i">(430)</td><td id="28-1j">363</td></tr>
<tr><td id="28-1k">Total indefinite-lived assets</td><td id="28-1l">N/A</td><td id="28-1m">425</td><td id="28-1n">—</td><td id="28-1o">425</td><td id="28-1p">425</td><td id="28-1q">—</td><td id="28-1r">425</td></tr>
<tr><td id="28-1s">Total</td><td id="28-1t"></td><td id="28-1u">$ 1,393</td><td id="28-1v">$ (478)</td><td id="28-1w">$ 915</td><td id="28-1x">$ 1,218</td><td id="28-1y">$ (430)</td><td id="28-1z">$ 788</td></tr>
</table>

<a id='d46f4e53-794d-4326-8638-3cb9412139b9'></a>

Amortization expense of intangible assets for the years ended December 31, 2024, 2023, and 2022 was $211 million, $161 million, and $185 million, respectively.

<a id='f644e708-e1fc-4c30-9881-2e1985ac8557'></a>

As of December 31, 2024, expected amortization expense for the unamortized finite-lived intangible assets for the next five years and thereafter is as follows (in millions):

<a id='ff7350f2-08dc-400f-9608-983b2a896f86'></a>

<table id="28-1A">
<tr><td id="28-1B">2025</td><td id="28-1C">205</td></tr>
<tr><td id="28-1D">2026</td><td id="28-1E">125</td></tr>
<tr><td id="28-1F">2027</td><td id="28-1G">64</td></tr>
<tr><td id="28-1H">2028</td><td id="28-1I">38</td></tr>
<tr><td id="28-1J">2029</td><td id="28-1K">23</td></tr>
<tr><td id="28-1L">Thereafter</td><td id="28-1M">35</td></tr>
<tr><td id="28-1N">Total</td><td id="28-1O">$ 490</td></tr>
</table>

<a id='fbf07873-1383-421a-8436-0d3df9690c9c'></a>

108

<!-- PAGE BREAK -->

<a id='e23374e3-5108-4f9f-b6e4-1954fe02e0b1'></a>

Table of Contents

<a id='ada6975a-6acc-4044-b2e7-5cac77429ce1'></a>

### Note 10. Long-term Debt

As of December 31, 2024 and 2023, we had $29.0 billion and $18.50 billion of fixed-rate senior unsecured notes (the Notes), respectively, including $10.50 billion of Notes issued in August 2024. The following table summarizes the Notes and the carrying amount of our long-term debt (in millions, except percentages):

<a id='68160beb-a68b-46fa-90af-eacc6e3422a3'></a>

<table id="29-1">
<tr><td id="29-2"></td><td id="29-3">Maturity</td><td id="29-4">Stated Interest Rate</td><td id="29-5">Effective Interest Rate</td><td id="29-6">December 31, 2024</td><td id="29-7">December 31, 2023</td></tr>
<tr><td id="29-8">August 2022 Notes:</td><td id="29-9">2027-2062</td><td id="29-a">3.50% - 4.65%</td><td id="29-b">3.63% - 4.71%</td><td id="29-c">$ 10,000</td><td id="29-d">$ 10,000</td></tr>
<tr><td id="29-e">May 2023 Notes:</td><td id="29-f">2028-2063</td><td id="29-g">4.60% - 5.75%</td><td id="29-h">4.68% - 5.79%</td><td id="29-i">8,500</td><td id="29-j">8,500</td></tr>
<tr><td id="29-k">August 2024 Notes:</td><td id="29-l">2029-2064</td><td id="29-m">4.30% - 5.55%</td><td id="29-n">4.42% - 5.60%</td><td id="29-o">10,500</td><td id="29-p">—</td></tr>
<tr><td id="29-q">Total face amount of long-term debt</td><td id="29-r"></td><td id="29-s"></td><td id="29-t"></td><td id="29-u">29,000</td><td id="29-v">18,500</td></tr>
<tr><td id="29-w">Unamortized discount and issuance costs, net</td><td id="29-x"></td><td id="29-y"></td><td id="29-z"></td><td id="29-A">(174)</td><td id="29-B">(115)</td></tr>
<tr><td id="29-C">Long-term debt</td><td id="29-D"></td><td id="29-E"></td><td id="29-F"></td><td id="29-G">28,826</td><td id="29-H">$ 18,385</td></tr>
</table>

<a id='cd68bc27-26e2-4694-a39e-0647fb4059b8'></a>

Each series of the Notes in the table above rank equally with each other. Interest on the Notes is payable semi-annually in arrears. We may redeem the Notes at any time, in whole or in part, at specified redemption prices. We are not subject to any financial covenants under the Notes. Interest expense, net of capitalized interest, recognized on the Notes was $683 million, $420 million, and $160 million for the years ended December 31, 2024, 2023, and 2022, respectively.

<a id='c7f85895-4027-4c0d-acb4-c0d3e5548d31'></a>

The total estimated fair value of our outstanding Notes was $27.83 billion and $18.48 billion as of December 31, 2024 and 2023, respectively. The fair value is determined based on the quoted prices at the end of the reporting periods and categorized as Level 2 in the fair value hierarchy.

<a id='9bbdc5ea-4363-453d-a252-b55107f434bf'></a>

As of December 31, 2024, future principal payments for the Notes, by year, are as follows (in millions):
<table id="29-I">
<tr><td id="29-J">2025 through 2026</td><td id="29-K">$ -</td></tr>
<tr><td id="29-L">2027</td><td id="29-M">2,750</td></tr>
<tr><td id="29-N">2028</td><td id="29-O">1,500</td></tr>
<tr><td id="29-P">2029</td><td id="29-Q">1,000</td></tr>
<tr><td id="29-R">Thereafter</td><td id="29-S">23,750</td></tr>
<tr><td id="29-T">Total</td><td id="29-U">$ 29,000</td></tr>
</table>

<a id='6d8fe597-179e-41e2-b638-f6398e85a8a8'></a>

Note 11. Accrued Expenses and Other Current Liabilities

The components of accrued expenses and other current liabilities are as follows (in millions):

<table id="29-V">
<tr><td id="29-W"></td><td id="29-X" colspan="2">December 31,</td></tr>
<tr><td id="29-Y"></td><td id="29-Z">2024</td><td id="29-10">2023</td></tr>
<tr><td id="29-11">Legal-related accruals</td><td id="29-12">5,523</td><td id="29-13">6,592</td></tr>
<tr><td id="29-14">Accrued compensation and benefits</td><td id="29-15">6,350</td><td id="29-16">6,659</td></tr>
<tr><td id="29-17">Accrued property and equipment</td><td id="29-18">2,582</td><td id="29-19">2,213</td></tr>
<tr><td id="29-1a">Accrued taxes</td><td id="29-1b">3,438</td><td id="29-1c">3,65</td></tr>
<tr><td id="29-1d">Other current liabilities</td><td id="29-1e">6,074</td><td id="29-1f">6,369</td></tr>
<tr><td id="29-1g">Total</td><td id="29-1h">23.967</td><td id="29-1i">25.488</td></tr>
</table>

<a id='12ae02db-8534-4b20-aa0e-cf8fdaebb6f0'></a>

(1) Includes accruals for estimated fines, settlements, or other losses in connection with legal and related matters, as well as other legal fees. For further information, see *Legal and Related Matters* in Note 12 — Commitments and Contingencies.

<a id='797524b9-6a50-446d-8a90-bb7c58747088'></a>

109

<!-- PAGE BREAK -->

<a id='bb914809-b3e8-452f-8d7d-3cfb35d48892'></a>

Table of Contents

<a id='15e44ec6-38b3-47a2-ab73-a0d3966eb5e5'></a>

Note 12. Commitments and Contingencies

Contractual Commitments

We have $32.82 billion of non-cancelable contractual commitments as of December 31, 2024, which are primarily related to our investments in servers and network infrastructure, and content costs. The following is a schedule, by years, of non-cancelable contractual commitments as of December 31, 2024 (in millions):

<a id='a1cff280-887a-4607-8b4f-878330aa592f'></a>

<table id="30-1">
<tr><td id="30-2">2025</td><td id="30-3">26,335</td></tr>
<tr><td id="30-4">2026</td><td id="30-5">2,548</td></tr>
<tr><td id="30-6">2027</td><td id="30-7">812</td></tr>
<tr><td id="30-8">2028</td><td id="30-9">227</td></tr>
<tr><td id="30-a">2029</td><td id="30-b">153</td></tr>
<tr><td id="30-c">Thereafter</td><td id="30-d">2,749</td></tr>
<tr><td id="30-e">Total</td><td id="30-f">$ 32,824</td></tr>
</table>

<a id='04da03bf-e08f-4598-80f4-cf006ef865c0'></a>

Additionally, as part of the normal course of business, we have entered into multi-year agreements to purchase renewable energy that do not specify a fixed or minimum volume commitment. We enter into these agreements in order to secure price. Using the expected volume consumption, the total estimated spend related to our renewable energy agreements as of December 31, 2024 was approximately $24.97 billion, a majority of which is due beyond five years. The ultimate spend under these agreements may vary and will be based on actual volume purchased.

<a id='12a53e18-1502-4d9a-8cd6-fbce93a283fa'></a>

Legal and Related Matters

With respect to the cases, actions, and inquiries described below, we evaluate the associated developments on a regular basis and accrue a liability when we believe a loss is probable and the amount can be reasonably estimated. In addition, we believe there is a reasonable possibility that we may incur a loss in some of these matters. Unless otherwise noted, with respect to the matters described below that do not include an estimate of the amount of loss or range of possible loss, such losses or range of possible losses either cannot be estimated or are not individually material, but we believe there is a reasonable possibility that they may be material in the aggregate.

<a id='37cefd05-c517-49d1-9b68-60e99db7aef1'></a>

We are also party to various other legal proceedings, claims, and regulatory, tax or government inquiries and investigations that arise in the ordinary course of business. Additionally, we are required to comply with various legal and regulatory obligations around the world. The requirements for complying with these obligations may be uncertain and subject to interpretation and enforcement by regulatory and other authorities, and any failure to comply with such obligations could eventually lead to asserted legal or regulatory action. With respect to these other legal proceedings, claims, regulatory, tax, or government inquiries and investigations, and other matters, asserted and unasserted, we evaluate the associated developments on a regular basis and accrue a liability when we believe a loss is probable and the amount can be reasonably estimated. In addition, we believe there is a reasonable possibility that we may incur a loss in some of these other matters. We believe that the amount of losses or any estimable range of possible losses with respect to these other matters will not, either individually or in the aggregate, have a material adverse effect on our business and consolidated financial statements.

<a id='ccf530bf-b214-4eb8-8be0-d037fd3e8b82'></a>

The ultimate outcome of the legal and related matters described in this section, such as whether the likelihood of loss is remote, reasonably possible, or probable, or if and when the reasonably possible range of loss is estimable, is inherently uncertain. Therefore, if one or more of these matters were resolved against us for amounts in excess of management's estimates of loss, our results of operations and financial condition, including in a particular reporting period in which any such outcome becomes probable and estimable, could be materially adversely affected.

<a id='184044a8-990d-4391-a5ea-04bedca7ee5d'></a>

For information regarding income tax contingencies, see Note 15 --- Income Taxes.

<a id='38a6595a-1368-4b5c-b51c-cf7812840781'></a>

110