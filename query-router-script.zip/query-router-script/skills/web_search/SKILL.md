---
name: web_search
description: >
  Searches the public web for current information. Use for real-time data,
  recent news, market comparables, regulatory updates, or external context
  not in internal data sources.
trigger: >
  when user asks about external market data, recent news, public
  comparables, regulatory changes, or anything requiring the public internet
category: search
parameters:
  - name: query
    type: string
    required: true
    description: Search query to execute
  - name: max_results
    type: integer
    required: false
    default: 5
    description: Maximum number of results
---

# Web Search Skill
