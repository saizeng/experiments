"""LangGraph state schema with conversation history."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field
from typing_extensions import TypedDict


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"


class PlanStep(BaseModel):
    step_id: int
    description: str
    skill_name: str
    query: str
    depends_on: list[int] = Field(default_factory=list)
    parameters: dict[str, Any] = Field(default_factory=dict)


class StepResult(BaseModel):
    step_id: int
    skill_name: str = ""
    status: StepStatus = StepStatus.PENDING
    data: Any = None
    error: str | None = None


class ChatMessage(BaseModel):
    """A single message in the conversation history."""
    role: str          # "user" or "assistant"
    content: str
    plan_steps: list[PlanStep] | None = None
    step_results: list[StepResult] | None = None


class RouterState(TypedDict):
    """State flowing through the LangGraph graph."""
    question: str
    chat_history: list[ChatMessage]     # full conversation so far
    reasoning: str
    plan_steps: list[PlanStep]
    step_results: list[StepResult]
    completed_ids: set[int]
    answer: str
    error: str
