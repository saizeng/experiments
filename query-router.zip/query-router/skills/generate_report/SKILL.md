---
name: generate_report
description: >
  Generates a formatted PDF or DOCX report from deal data including
  key metrics, timeline, and risk factors. Typically used after
  fetching data from structured_data and/or unstructured_docs skills.
trigger: >
  when user asks for a report, summary document, deal brief, or
  formatted output for a deal
category: generation
parameters:
  - name: query
    type: string
    required: true
    description: Description of what report to generate
  - name: format
    type: string
    required: false
    default: pdf
    description: Output format (pdf or docx)
---

# Generate Report Skill

Produces a formatted report from upstream data.

## run.py contract

- Reads JSON from stdin with `upstream` containing data from prior steps
- Generates report file
- Writes JSON to stdout: `{"file_path": "...", "title": "...", "pages": N}`
