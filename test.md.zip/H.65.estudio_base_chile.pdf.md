<a id='f41b4026-573d-478b-aba1-6dbf0ed5a3dd'></a>

McKinsey
& Company

<a id='cf9d8d80-2050-416a-af24-2271f2471872'></a>

## Chilean Hydrogen
Pathway

<a id='1cce4c8b-84ba-4d5f-826d-b8490f45d9ac'></a>

Final Report

December 2020

<a id='6cf8f3c9-6e2f-4bbf-af2d-3cf8a9fe913a'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company
is strictly prohibited

<!-- PAGE BREAK -->

<a id='6a6c694f-874d-424d-8daa-760b46d486a5'></a>

<table><thead><tr><th>Chapter</th><th>Page</th></tr></thead><tbody><tr><td>Chapter 1: State of global Hydrogen industry</td><td>Page 3-28</td></tr><tr><td>Chapter 2: Business case for domestic Hydrogen<br>production and end use application</td><td>Page 29-50</td></tr><tr><td>Chapter 3: Business case for Hydrogen exportation</td><td>Page 51-56</td></tr><tr><td>Chapter 4: Hydrogen industry development targets and<br>roadmap</td><td>Page 57-60</td></tr><tr><td>Chapter 5: Relevant stakeholders for the hydrogen industry</td><td>Page 61-73</td></tr><tr><td>Chapter 6: Government role in hydrogen industry<br>development</td><td>Page 74-83</td></tr></tbody></table>

<a id='7627bd24-165e-4021-aae4-339c7fca030e'></a>

McKinsey & Company

<a id='728e3ea4-eb33-4616-92a8-a3adca537327'></a>

2

<!-- PAGE BREAK -->

<a id='a27dfa0d-4e85-4d06-9ddb-a98e9e4ad977'></a>

Chapter 1: State of global Hydrogen industry

<a id='458c72db-36df-41c9-9ffa-484006293d7e'></a>

Chapter content description
- State of the global **Hydrogen industry, including**: production, transportation, distribution and utilization of Hydrogen (specific focus on Green Hydrogen)
- **Development of hydrogen market, including**: hydrogen projects and investment analysis by key market and segment of the hydrogen value chain
- **Roadmaps and strategies for hydrogen development in key markets** including key strategic initiatives, incentive mechanisms and other forms of public support

<a id='dfeb3af2-cd04-4238-831d-a8396eb29f6f'></a>

Activities included
* Activity 1.1
* Activity 1.2

<a id='74749954-96cc-4413-a0d1-f49594c19819'></a>

McKinsey & Company

<a id='09fbf81d-9511-443e-8642-b28fccf16f91'></a>

3

<!-- PAGE BREAK -->

<a id='5dbaf65f-9ee1-4887-8045-9ea96b86e413'></a>

1.1/ Blue and Green hydrogen are two low-carbon production methods of H2 with the highest future potential

<a id='41a7c22a-b4d8-4f94-b2a9-80983b144345'></a>

<::Oval shape with 'X' inside, indicating CO2 emissions (kg CO2 per kgH2 produced)
: figure::>

<a id='a54131d2-9840-430f-bbe1-fddccddf9373'></a>

Low-carbon H2
<::Icon of a factory with smoke stacks: icon::> Grey
H2
<::Icon of a factory with CO2 cloud and a storage tank: icon::> Blue
H2
<::Icon of an electrolyzer or similar equipment: icon::> Green
H2
Production
process
Split¹ natural gas
into H2 and CO2
Similar to Grey but additionally capture,
potentially use, and store CO2
Split water into H2 and O2 in an electrolyzer that
is powered by renewables
~10
~1-3 Most CO2
stored
~0 Assuming Green
electricity mix²
Investments
and complexity
Large scale, one-off facilities
Large scale and one-off facilities
Small-scale (5-10MW) facilities that can be
replicated, similar to utility-scale batteries³
Requiring triple-digit million
EURCAPEX per facility
Requiring triple-digit mn EUR CAPEX per facility
Requiring single/double-digit EUR mn CAPEX
per facility, expecting 50-70% reduction until 2030
3-5 years EPC
5-10+ years EPC duration, contingent upon
development of CO2 storage site
1-3 years EPC duration
Direct link to
power sector
<::Icon of a power pylon with an 'X' symbol: icon::>
<::Icon of a power pylon with an 'X' symbol: icon::>
<::Icon of a power pylon with a checkmark symbol: icon::>

<a id='e36c4b64-3adb-46a6-9869-83a89557060d'></a>

1. Process: Sulfur Removal, Synthesis Gas Production via Steam-Methane Reforming (SMR) or Auto-Thermal Reforming (ATR), CO Shift Reaction, Purification. The latter is expected to offer higher efficiencies in combination with CCS. In addition, Grey hydrogen can also be produced from coal gasfication.
2. In Australia, producing hydrogen from electrolyzers that run on grid electricity would lead to an emission intensity of ~40 kgCO2/kgH2.
3. Especially PEM electrolyzers can be largely pre-assembled, containerized, and stacked.

<a id='badba42f-0d36-4a07-bc07-1925ff75fc43'></a>

McKinsey & Company

<a id='9c4c671a-7fcc-4aa0-b3f1-fee999c4e937'></a>

4

<!-- PAGE BREAK -->

<a id='059c72c1-0468-42d1-9bd9-f58400e78597'></a>

## 1.1/ Blue H2 is cheaper today, but Green H2 is the ´new solar´ with costs decreasing rapidly

Global H2 demand and production costs¹

<a id='9b9ee220-4fec-47b2-9c16-f1992b880646'></a>

option Least-cost option: [x]
option 2nd least-cost option: [ ]

<::diagram: Process flow showing the evolution of hydrogen production types, followed by a table detailing H2 demand and production costs.

**Diagram Description:**
- **Legend:**
  option Least-cost option: [x]
  option 2nd least-cost option: [ ]
- **Flow:**
  - A large grey rectangular block labeled "Grey" (representing Grey H2 production).
  - An arrow points from the "Grey" block to a large blue rectangular block labeled "Blue". Text along this arrow indicates influencing factors: "High emission prices, falling CCS cost, availability of CO2 use cases and storage sites".
  - An arrow points from the "Blue" block to a large teal rectangular block labeled "Green". Text along this arrow indicates influencing factors: "High gas and emission prices, falling electrolyzer and renewables cost".

**Table: Global H2 Demand and Production Costs**

| | Global H2 demand Mt p.a. | Thereof Grey H2 Mt p.a. (Share %) | Thereof Blue+Green H2 Mt p.a. | Production cost Grey H2 $/kg | Production cost Blue H2 $/kg | Production cost Green H2 $/kg |
|---|---|---|---|---|---|---|
| **2018** | 73 | 73 (100%) | ~0 | ~1.0-2.5 | ~1.5-3.0 | 4.3 |
| **2030** | 110 | 73+X (>70%) | Up to 37 | ~1.0-2.5 | ~1.5-3.0 | 2.0 |
| **2050** | 545 | 73+/-X (<20%) | Up to 472 | " | " | 1.3 |

**Footnotes:**
1. Estimates by Hydrogen Council; Grey H2 production costs assuming natural gas prices of $4-$8/mmBtu; Blue H2 costs assuming Grey costs +$0.5/kg; Green H2 costs assuming IRENA database weighted average solar PV costs (auctions and PPAs) in 2020
: table::>



<a id='861f51a9-ea7e-4a94-8db9-cc4328f1a653'></a>

McKinsey & Company

<a id='ad1baa7b-a402-4fcc-b353-70b6de6e071f'></a>

5

<!-- PAGE BREAK -->

<a id='26605967-7325-4080-a28a-64b1c25da337'></a>

1.1/ The Green H2 production relies on carbon-free power generation and electrolyzers which split water H2 and an O2 biproduct

<a id='f96ca4bc-a46d-476c-85ff-acc133f7bff6'></a>

<::Diagram: Hydrogen Value Chain::>
This diagram illustrates the hydrogen value chain, categorized by production method (Blue H2 and Green H2) and stages (Upstream, Midstream, Downstream).

**Overall Structure:**
- The diagram is divided into three main columns: "Upstream (incl. CAO¹)", "Midstream (Logistics and Trading)", and "Downstream".
- The "Downstream" column is further subdivided into "Existing segment: Using Grey H2" and "New segments: Potential use of H2 to decarbonize".
- The diagram is also divided into two main rows: "Blue H2" and "Green H2".

**Blue H2 Row:**
- **Upstream (incl. CAO¹):**
  - Icon of oil rig, flare stack, and pipeline valve, labeled "Natural gas exploration and transport".
  - Icon of industrial plant, labeled "SMR / ATR".
  - Icon of a cloud with "CO2" and pipes, labeled "Byproducts: Sulfur, CO, CO2, steam, heat".
  - Icon of pipes with a valve, labeled "CO2 Sequestration & Storage".
- **Midstream (Logistics and Trading):**
  - Icon of a pressure gauge, labeled "H2 compression".
  - Icon of a tanker truck, labeled "Trucking".
  - Icon of a storage tank with pipes, labeled "H2 intermediary storage".
  - Icon of a fueling station, labeled "Fueling infrastructure".
  - Icon of a storage tank with a liquid droplet, labeled "H2 liquifier".
  - Icon of pipes with a valve, labeled "H2 grid or blending into gas network".
  - Icon of a ship, labeled "Shipping (liquid H2)".
- **Downstream:**
  - **Existing segment: Using Grey H2:**
    - Icon of an industrial plant with a tank and smoke stack, labeled "Selling H2 as industrial feedstock²".
  - **New segments: Potential use of H2 to decarbonize:**
    - Icon of a car, truck, airplane, and ship, labeled "Selling H2 to transport industry".

**Green H2 Row:**
- **Upstream (incl. CAO¹):**
  - Icon of a nuclear power plant, solar panels, wind turbine, and hydroelectric dam, labeled "Carbon-free power generation³".
  - Icon of an electrolyzer, labeled "Electrolyzer".
  - Icon of a cloud with "O2", labeled "Byproduct: O2".
- **Midstream (Logistics and Trading):**
  - Icon of a pressure gauge, labeled "H2 compression".
  - Icon of a tanker truck, labeled "Trucking".
  - Icon of a storage tank with pipes, labeled "H2 intermediary storage".
  - Icon of a fueling station, labeled "Fueling infrastructure".
  - Icon of a storage tank with a liquid droplet, labeled "H2 liquifier".
  - Icon of pipes with a valve, labeled "H2 grid or blending into gas network".
  - Icon of a ship, labeled "Shipping (liquid H2)".
- **Downstream:**
  - **New segments: Potential use of H2 to decarbonize:**
    - Icon of an industrial plant, labeled "Selling H2 to industry for industrial heat processes".
    - Icon of houses, labeled "Selling H2 to heat and power homes²".
    - Icon of an industrial plant with smoke stacks, labeled "Selling/using H2 to fuel gas plants".
<::>

<a id='56e9d2b4-f714-4ce1-81f8-7332e3249c4b'></a>

1. Commercial Asset Optimization
2. Refining, ammonia, methanol, olefin, steel 2 Blending H2 in natural gas networks or dedicated H2 networks 3 Water electrolysis based on "grey" electricity mixes may result in "fake-green" H2 with higher emissions than Grey H2

---

<a id='00209d00-415b-4aae-9494-0e445a04a6e9'></a>

McKinsey & Company

<a id='2a2fdaaf-bf0d-43d6-b74c-d75ba268dc02'></a>

12

<!-- PAGE BREAK -->

<a id='2d061661-3245-44cf-9be7-ef0db13dbf64'></a>

1.1 / Hydrogen's value chain is decomposed into production ('green'
or not), handling and final use (across several verticals)

<a id='a1c5a220-408c-4b96-8ef2-e61120590857'></a>

<::Flowchart showing a three-step process::>
Production (techniques)¹
Handling (steps)
Final use

1. Hydrogen produced r
<::

<a id='7ca58ee0-f132-49a2-a057-432f06a0b975'></a>

**Reforming/ gasification of fossil feedstock**
100%+ of current production. Natural gas, oil, coal or biogas is used to get hydrogen:
* Steam methane reforming (SMR)
* Petroliquids or coal gasification
Can be associated to a carbon capture & storage facility to make H2 production more sustainable

<a id='2e34be1b-d118-43ab-97bd-81aaa754bd3a'></a>

## Electrolysis
Splitting of water to get hydrogen, using renewable or fossil fuel-based energy.
*   2 power sources: on-site or from the grid
*   3 main technologies: alkaline (most mature), PEM¹ (increasing interest) and high-temperature splitting (nascent)

<a id='1d588a04-1164-4a44-9baa-73a39c7d2bd5'></a>

**Other techniques**
Other (nascent) techniques to produce hydrogen include:
* Biomass gasification
* Biological / Bacterial production
* Direct solar water splitting

<a id='421d5a8b-2d4c-46cf-bc54-e65fd0aacb29'></a>

**Storage**

Storage of hydrogen or hydrogen-based fuels & feedstock

*   For short duration & small volumes, storing in tanks and / or solid materials
*   For longer duration & large volumes, storing in salt caverns, depleted gas wells or aquifers

<a id='abdae1a5-4774-4d8f-aeab-54103da341f9'></a>

## Transmission
Transmission of hydrogen for long distances / large flows
* Can involve pipelines (H₂ or methane), rail transport, ships and / or trucks
* Can transport hydrogen in a gaseous or liquid form, or transport liquid organic H₂ carriers

<a id='04457700-a548-454e-a5a2-9eeee336a47b'></a>

# Distribution
Transmission of hydrogen for shorter distances to the final user
* Can involve pipelines and / or trucks
* Can transport hydrogen in a gaseous or liquid form, or transport liquid organic H₂ carriers

<a id='56071b04-09ed-42d6-8609-9d71e442aa7c'></a>

<::Infographic presenting five categories, each with an icon and a bulleted list of items:
- Power storage & generation (icon: wind turbine)
  - Battery storage / Buffer
  - Power generation
- Transport (icon: car)
  - Cars
  - Vans / Minibuses
  - Trucks
  - Ships & Planes
  - Forklifts
  - Trains & Trams
- Industry feedstock (icon: factory building)
  - Oil refining
  - Ammonia / Methanol production
  - Steel (iron ore reduction)
- Industrial energy (icon: factory building)
  - Low industry heat
  - Medium industry heat
  - High industry heat
- Building heat and power (icon: house)
  - Heating
  - Onsite power generation
: infographic::>

<a id='853ce5f4-35da-4457-b0cb-31a2c4c06ea7'></a>

1. Hydrogen produced may then be transformed to hydrogen carriers (ammonia, methanol, etc.)
2. Polymer electrolyte membrane

<a id='f42e4777-c12b-4f96-a6b0-45023f9d50da'></a>

Source: IEA 2019; McKinsey analysis

<a id='7defff41-b140-4161-b8fc-838d9c8f99ac'></a>

McKinsey & Company

<a id='d8ca5d94-7304-4d80-9d7b-cb205244ff24'></a>

7

<!-- PAGE BREAK -->

<a id='370b25a2-8cdb-4fce-9833-80cb47b65ad7'></a>

1.1 / Since 2018, the hydrogen industry has been experiencing unprecedented momentum

<a id='d10efed1-7c4d-4ff5-8a2d-fe7281374659'></a>

Not Exhaustive Hydrogen Categories: Transportation (dark blue), Industrial energy (light blue), Building heat (darker blue), Power generation/storage (cyan), Overarching (dark grey), Hydrogen Production (light grey), Hydrogen Infrastructure (grey)

<::timeline:
Year: 2018
- Jan 18 (Overarching): Foundation of Japan H2 Mobility
- Mar 5 (Transportation): FCEV taxi fleet in Paris expanded to 100 FCEVs
- Mar 29 (Hydrogen Infrastructure): Hydrogen roadmap for the Netherlands
- May 2 (Hydrogen Production): Shell and ITM Power agree to build then world's largest electrolysis plant (10 MW) in Germany
- May 14 (Hydrogen Production): NEL announces to build world's largest electrolyzer production plant (360 MW/year) in early 2020
- Jun 24 (Transportation): Siemens and PowerCell announce development of fuel cells for ships
- Jul 25 (Transportation): First hydrogen train starts operating in Germany
- Aug 14 (Overarching): Hydrogen Council expands to 53 members
- Aug 22 (Power generation/storage): ITM Power gets funding to explore 100 MW power-to-gas storage project
- Aug 29 (Transportation): Hyundai announces supply of 1,000 hydrogen fuel cell lorries to Swiss H2 Energy
- Sep 5 (Overarching): Northeast of the US announces start of HRS roll-out
- Sep 17 (Transportation): Hyundai announces FCEV Vision 2030: 7bn USD invest, 700,000 units by 2030
- Sep 27 (Overarching): tk announces carbon-neutrality by 2050, $10bn EUR investments
- Sep 28 (Hydrogen Production): RWE and Innogy announce plans for 100 MW electrolyzer in Netherlands
- Oct 3 (Power generation/storage): 100 MW power-to-gas project by Gasunie, Tennet and Thyssengas starting 2022
- Oct 10 (Overarching): Air Liquide acquires ~20% of Hydrogenics
- Oct 12 (Transportation): Ship-maker CMB announces several hydrogen investments
- Oct 16 (Transportation): Bosch and Hanwa invest over $230m in Nikola
- Oct 22 (Overarching): EDF launches subsidiary to develop hydrogen solutions for industry
- Nov 12 (Transportation): Chinese plans to build hydrogen infrastructure for ~50k FCEVs by 2025
- Dec 12 (Transportation): Toyota aims for 30k FCEV sales per year after 2020 - build two new fuel cell facilities

Year: 2019
- Jan 25 (Overarching): French strategy plan: France as a leader in hydrogen technology
- Feb 5 (Power generation/storage): Yara and Engie to build 20 MW green hydrogen plant
- Feb 18 (Overarching): IEA launches hydrogen report with major reversal of their perspective, report endorsed by G20 energy ministers
- Mar 15 (Hydrogen Production): Linde announces quadrupling of hydrogen and syngas capacity at $1.9b Jurong Island complex
- Apr 8 (Transportation): CNH announces $250m investment in Nikola and JV for hydrogen truck production
- Jun 19 (Overarching): Engie's power-to-gas demo project starts injection of 6% hydrogen in the gas grid, rising to 20%
- Jun 29 (Transportation): Announcement of a test flight of ZeroAvia hydrogen-powered six-seater airplane
- Aug 19 (Overarching): Chinese Weichai strategically invests USD 163m in Ballard
- Aug 27 (Overarching): VW and Stanford University announces significant reduction in platinum use for fuel cells
- Sep 3 (Transportation): Hyundai announces to sell 5,000 FCEVs to France by 2025
- Sep 5 (Hydrogen Production): AirLiquide and Linde announce expansion of liquid H2 production in US
- Undated (below Aug 19): EU energy ministers announce joint hydrogen R&D
- Undated (below Aug 27): New "H2Bus Europe" funding program for 600 fuel cell buses (EUR 40m)
- Undated (below Sep 3): Australian Renewable Energy Agency announces 2-year trial injecting green hydrogen into Sydney's gas grid
- Undated (below Sep 5): China beats FCEV target of 2020 in 2018, on track to become largest fuel cell market
- Undated (below Sep 5): Orsted includes H2 in Dutch offshore auction
- Undated (below Sep 5): Cummins acquires Hydrogenics
::>

Key trends in 2019
Acceleration of momentum as decarbonization commitments become more important
New segments growing, e.g. trucks, trains, ships, synfuel
Push from utilities, renewable developers and oil & gas companies
Large-scale projects with water electrolysis, mostly for use in industry (fertilizers, refining)

<a id='51299733-0ea2-4914-af7d-3988f0dc9ab5'></a>

Source: Press releases; McKinsey

<a id='1c815332-e408-46e0-9d48-7ec60eb5e9c6'></a>

McKinsey & Company

<a id='7b2b07d6-c5d4-4320-bb4d-44cb1719a19e'></a>

8

<!-- PAGE BREAK -->

<a id='6f79564a-e2ef-455b-89c7-879b6fd12038'></a>

**1.1 / Investment has been led by large industrials teaming up for large flagship projects – to reach technological and commercial maturity**

---

<a id='18cc1502-ee07-4a1a-82a1-51d9ff510ce6'></a>

<::World map illustrating various hydrogen projects and their associated companies and locations.: map::>

**100 MW Power-to-Gas** (Germany flag)
- amprion
- Open Grid Europe

**Falkenhagen** (Germany flag)
- uniper

**H2 FC trucks** (USA flag)
- KENWORTH
- UPS
- TOYOTA
- Air Liquide (logo)
- Shell (logo)

**Hynet and H21 heating UK** (UK flag)
- JM Johnson Matthey
- Northern Gas Networks
- equinor
- Cadent
- Progressive energy

**Offshore hydrogen** (Belgium flag)
- Orsted

**Westküste** (Germany flag)
- Orsted
- Open Grid Europe
- The Gas Wheel
- Holcim
- thyssenkrupp
- RAFFINERIE HEIDE
- EDF

**Magnum H2 power plant** (Netherlands flag)
- VATTENFALL
- Gasunie
- equinor

**Northern lights** (Norway flag, Denmark flag)
- equinor
- Shell (logo)
- TOTAL

**Hybrit - Steel CO2 free** (Sweden flag)
- SSAB
- LKAB
- VATTENFALL

**H2 FC trains** (France flag)
- THE LINDE GROUP
- ALSTOM
- LNVG

**Centurion – Cavern – energy flexibility** (Germany flag)
- Cadent
- inovyn
- storengy

**Rhineland refinery** (Germany flag)
- Shell (logo)
- ITM POWER

**Green steel voestalpine** (Austria flag)
- SIEMENS

**H2 FC trucks fleet** (Germany flag)
- Shell (logo)
- Air Liquide (logo)

**H2 Mobility Korea** (South Korea flag)
- Air Liquide (logo)
- nel
- HYUNDAI
- KOGAS
- HONDA

**H2 Mobility Japan** (Japan flag)
- Air Liquide (logo)
- Iwatani
- JAPAN H: MOBILITY (JHyM)
- JXTG Nippon Oil & Energy

**LH2 supply chain** (Japan flag, Oman flag)
- Iwatani
- Kawasaki
- Marubeni
- Shell (logo)

**20 MW green H2 production for ammonia** (Australia flag, Netherlands flag)
- YARA
- ENGIE

<a id='c31d3c2b-d2f4-4eb6-833c-b909079a1526'></a>

Source: Press releases; McKinsey

<a id='9390f71c-33a6-4013-b311-c3ce4c2d9e9e'></a>

McKinsey & Company

<a id='94fd9454-93ff-4b77-8599-2ba77bd5089d'></a>

9

<!-- PAGE BREAK -->

<a id='cb1ab3b4-c7d3-4ee3-89c4-c4179b48cd2d'></a>

1.1 / Global green H2 production capacities are limited, but expected to increase significantly with ~9.5 GW announced until 2025

<a id='a6380115-4951-4408-9e56-cff1a73756a0'></a>

Selected project examples Global electrolysis project announcements, GW
<::Bar chart showing global electrolysis project announcements by year (2015-2025) and cumulative capacity in GW, broken down by region. The Y-axis ranges from 0 to 10 GW. The X-axis represents years from 2015 to 2025. Below the cumulative bars, individual project announcements are listed with their capacity, company, and country flag.

Legend:
- Asia Pacific (black)
- Europe (light blue)
- Middle East (dark blue)
- North America (light teal)
- Africa (dark teal)
- Latin America (purple)

Individual Project Announcements:
- 2016:
  - BJE (Beijing Jingneng Clean Energy Co., Limited): 5 GW, China flag (Asia Pacific)
  - NEOEN: 0.05 GW, Australian flag (Asia Pacific)
- 2017:
  - YARA: 0.06 GW, Australian flag (Asia Pacific)
  - ENGIE: No GW specified, Australian flag (Asia Pacific)
- 2018:
  - H2V: 0.5 GW, French flag (Europe)
- 2019:
  - Thyssengas, Tennet, Gasunie: 0.1 GW, German flag (Europe)
- 2020:
  - Amprion, Open Grid Europe, The Gas Wheel: 0.1 GW, German flag (Europe)
- 2022:
  - DEME: 0.5 GW, Oman flag (Middle East)
- 2023:
  - NEOM: 2 GW, Saudi Arabia flag (Middle East)
  - Nouryon, BP, Port of Rotterdam: 0.25 GW, Netherlands flag (Europe)
  - Unknown project (?3): 0.5 GW, German flag (Europe)

Cumulative Capacity Stacked Bars:
- 2021: Primarily Middle East (dark blue) and Europe (light blue) with small contributions from other regions.
- 2022: Growth in Middle East and Europe.
- 2023: Significant growth, predominantly Middle East and Europe.
- 2024: Continued growth.
- 2025: Highest cumulative capacity, with Middle East and Europe being the largest contributors, followed by Asia Pacific and Africa.: chart::>

<a id='1d70cbb7-973e-4741-be00-21ab4efe42fb'></a>

1. Plant assumed to be constructed over 5 years
2. Various plants announced to be constructed until 2025
3. Government announcements, most likely allocated through tenders/auction

<a id='52b9c853-da32-4cb7-9131-a22e6191413b'></a>

Source: IEA, Press research, McKinsey

<a id='85412804-52e5-4997-96a3-792106a55bf7'></a>

McKinsey & Company

<a id='4b726933-2ac3-4809-878e-7962993d2443'></a>

13

<!-- PAGE BREAK -->

<a id='f4d861d2-1f42-46c7-999c-e4d484be0a10'></a>

1.2 / Countries have establish hydrogen roadmaps with different levels of detail on key issues for the promotion of the industry

---

option Detailed next: [ ]
option Mentioned but not detailed: [x]
option Considered in detail: [x]

PRELIMINARY | NOT EXHAUSTIVE

<a id='c2196caf-f898-4169-af9d-68d08e4b0893'></a>

| Indicators | European Union | Netherlands | Germany | South Korea | Australia | Chile |
|---|---|---|---|---|---|---|
| H2 production projection (Mton) | 1Mton by 2024, 10Mton to 2040 | NA | NA | 0.5 Mton to 2022, 5 Mton to 2040 | NA | 11M 2040 |
| Installed electrolysis Capacity | 6GW by 2024, 40GW by 2030 | 0.5 GW by 2025, 3-4GW by 2030 | 5GW by 2030, 10GW by 2035/40 | NA | NA | 5 GW 2025, 25GW 2030 |
| Investment | 180-470 EUR B by 2050 | NA | 9 EUR B to boost h2 demand | 2.3 USD B to 2022 for the H2 vehicle industry | NA | 45 USD b 2030, +300 USD b 2050 |

<a id='d6da9996-f1d6-456f-9803-c3d4444848c3'></a>

<::Table: Checkmark grid for various domains
| Domains |   |   |   |   |   |   |
| :-------------------------- | :- | :- | :- | :- | :- | :- |
| 1 Vision and targets        | option : [x] | option : [x] | option : [x] | option : [x] | option : [ ] | option : [x] |
| 2 Regulation and licensing  | option : [x] | option : [x] | option : [ ] | option : [x] | option : [ ] | option : [x] |
| 3 Coordination and partnerships | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] |
| 4 Financing and incentives  | option : [ ] | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] |
| 5 Infrastructure            | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] | option : [ ] |
| 6 Research & Development    | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] | option : [x] |
| 7 Skilled Labor             | option : [ ] | option : [x] | option : [ ] | option : [x] | option : [ ] | option : [ ] |
: Table::>

<a id='8605822c-fb11-472a-a8d0-79693e6a4b7c'></a>

McKinsey & Company

<a id='a4efbe7a-8899-4769-9844-7742efb9d2f6'></a>

11

<!-- PAGE BREAK -->

<a id='8002576a-8d3c-4d14-af4e-505672b46ad2'></a>

1.2 / The EU Hydrogen Strategy For a Climate Neutral Europe

<a id='f01a6ae7-d3f5-4de4-8997-1c80fe23713f'></a>

# General approach
The EU has agreed on its **EU Hydrogen strategy** as a **roadmap** to build up a large-scale **green hydrogen industry**

<a id='2999c028-8474-4693-a52d-335c1d7db0fd'></a>

The roadmap is divided into **3**
**phases** until 2050 that aim at
reaching **increasing levels** of
**maturity** for the H₂ market

<a id='1b718bc2-0684-4fa9-89b8-dd1164ee6633'></a>

The strategy explores how green hydrogen can help reducing the **EU**
**economy's carbon emissions** in a
**cost-effective way**

It is in line with the **EU's goal** to be
**climate-neutral by 2050**

<a id='1203f8c4-cd1b-47ca-86e9-03072c397b88'></a>

<::Cumulative investment needs in Europe, EUR bn. The chart shows two bars:
- Bar 1 (2025-30): 24-42
- Bar 2 (2030-50): 180-470
: bar chart::>

<a id='5f68a8e6-ccc8-4eda-8d14-f15e36f01927'></a>

## Overview of key action areas

Vision & targets
Build a concrete **project pipeline** by end of 2020
Develop an **investment agenda** and support further **strategic investments**

<a id='5897da50-f3f1-49c9-9c48-bf44c6673de8'></a>

Coordination
and partnership

Strengthen **EU leadership** internationally
Start cooperation with **Southern and Eastern**
**Neighborhood** partners, **Energy Community**
countries, and the **African Union**

<a id='1161c6c4-5025-42fc-a897-fd86be777e10'></a>

Financing and
Incentives

Explore **support policies** to increase demand
Implement **EU-wide criteria** for low-carbon H₂ **certification** and introduce a **common threshold**
Develop a pilot scheme for a Carbon CfD² program

<a id='4701ee57-9e58-49c4-9a27-4a8ae1188628'></a>

Infrastructure
Build up **infrastructure** for fueling and transport
Design **market rules** to ensure **liquid markets** and
to remove **barriers** for repurposing gas
**infrastructure**
---

<a id='888cdd88-b844-42c5-8801-7ba29a2be2ce'></a>

**R&D**

Develop **pilot projects** that test full **value chains**
Facilitate **demonstration** of H₂-based
technologies

<a id='367290bc-fe18-44ce-b53f-03c278d15591'></a>

11. Contracts for Difference

---

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='e497bdfc-b919-473c-af6a-8cf27cb7616f'></a>

<::logo: [European Union] [] [A blue rectangular flag with a circle of twelve yellow stars in the center.]::>

<a id='716d95f5-2821-4f0e-b9f5-6e518569066c'></a>

NOT EXHAUSTIVE

<a id='fb1b02ce-b835-432a-9b58-3020b297ce78'></a>

Key commitments and targets

6 GW Of installed electrolysis capacity by 2024

<a id='b565753e-d922-4a01-9de4-795c3ffd8e92'></a>

40 GW Of installed electrolysis capacity by 2030

<a id='f78fe6b0-7af4-4f9a-84b2-b4f9acc913a0'></a>

<::Green hydrogen production targets, Million tons: bar chart::>  
This bar chart illustrates green hydrogen production targets in million tons for two different years.  
- **2024**: The target is 1 million tons.  
- **2030**: The target is 10 million tons.

<a id='75dc7bef-174e-4bd0-b38f-21796a6e15d5'></a>

McKinsey & Company

<a id='7aa6f289-8909-4e5d-a8f2-4861f65917e4'></a>

12

<!-- PAGE BREAK -->

<a id='56dd0e00-071f-4d43-924c-01342ef050f9'></a>

1.2 / The EU's Hydrogen Strategy aims at achieving a renewable hydrogen mass market based on a 3-phase-roadmap

<a id='9ec63f61-2eb0-40ab-9e6c-438818390ba2'></a>

<::logo: European Union
A blue rectangular flag with twelve yellow stars arranged in a circle in the center.:>

<a id='9caacd1f-08f7-4cdf-a438-c7152a996a97'></a>

<::Related amount of green hydrogen production in the EU, million tons

Phase 1: 2020-2024
Phase 2: 2025-2030
Phase 3: 2030-2050
: table::>

Objective
Market launch – Decarbonize existing hydrogen
production and facilitating take up of hydrogen
consumption in new end-uses
Scale up – Expand production and end-use to
additional sectors to develop hydrogen as
intrinsic part of an integrated energy system
Mass market – Deploy renewable hydrogen at
large scale to reach all relevant hard-to-
decarbonize sectors

<::Electrolysis capacity targets, GW
chart showing target values for each phase:
- Phase 1: 6 GW (indicated with a '1' in a circle above the bar)
- Phase 2: 40 GW (indicated with a '10' in a circle above the bar)
- Phase 3: A bar with a dashed outline, labeled with a question mark ('?') above it.
: bar chart::>

Infrastructure
roadmap
Mostly local on-site supply combined with
selective gas blending and build-out start of
comprehensive refueling infrastructure¹
Planning of medium range and backbone
transmission infrastructure
Expansion to regional hydrogen clusters with
transport over short distances also through
dedicated hydrogen pipelines
Need for an EU-wide logistical infrastructure
to emerge
400 additional refueling stations (no year
specified)
Expansion to EU-wide hydrogen infrastructure
and hydrogen trading with non-EU partners

Targeted end-use
sectors²
Transport (buses, trucks)
Heavy industries (refineries, steel, chemicals)
Transport (rail, selected maritime, others)
Heating (residential, commercial)
Power system flexibility (storage, backup,
buffering)
Transport (aviation, long distance maritime)
Synthetic fuels production

Selected support
schemes
Revision of the ETS and potentially a carbon border adjustment mechanism
Carbon contracts for difference³, competitive tenders and quotas for end-use sectors
The upcoming Sustainable and Smart Mobility Strategy adds further support for transport uses
No dedicated support schemes stated for
Phase 3 as hydrogen mass market expected to
carry itself 

<a id='2d174b58-f66e-46f7-8062-62c6eba176b6'></a>

1. Refueling infrastructure build-out to continue across phases in line with increase in demand for transport applications
2. From phase 2 targeted end-use sectors refers to additions to the sectors mentioned in the previous phase(s)
3. Scheme potentially to be applied within replacement of existing hydrogen production in refineries and fertilizer production, low carbon and circular steel or maritime and aviation applications
4. Focus on hydrogen production capacities

<a id='ecf8536b-2533-4171-a110-02cb014bea91'></a>

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='3a50a685-599b-4aa1-82e7-4f5ff60322c6'></a>

McKinsey & Company

<a id='ad5b20e2-3e51-43a4-b620-f46d509b4ce6'></a>

13

<!-- PAGE BREAK -->

<a id='7d52a49b-735b-4d79-a051-e09c29df1a3d'></a>

1.2 / Key actions in the EU's Hydrogen Strategy for a climate-neutral Europe – Enabling environment

<a id='9bb9208b-d90b-45f9-978c-227dd41dbaea'></a>

NOT EXHAUSTIVE

<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and targets</td><td>Introducing a roadmap to 2050 for a hydrogen ecosystem</td><td>Establish a clear vision on **hydrogen production targets and deployment timeline**, as well the most relevant end-use sectors per phase<br>Introduce actions around **5 key dimensions**: develop an investment agenda, boost demand an scale up production, design an enabling framework, promote research and innovation, strengthen the international dimension<br>Provide a broad forum to coordinate investment by all stakeholders and engage civil society, through sector-based round tables and a policy-makers' platform, supervised by the European Clean Hydrogen Alliance</td></tr><tr><td>Regulation and licensing</td><td>Designing and enabling market rules</td><td>Design enabling **market rules for the deployment of hydrogen**, including removing barriers for efficient hydrogen infrastructure development (e.g. via repurposing), and ensure access to **liquid markets for hydrogen producers and customers** and the integrity of the internal gas market, through the upcoming legislative reviews (e.g. review of the gas legislation for competitive decarbonized gas markets) (2021)<br>Develop third-party access rules, **clear rules** on connecting electrolyzers to the grid and **streamlining of permitting** and administrative hurdles to reduce undue burden to market access<br>Work to introduce a **comprehensive terminology** and European-wide criteria for the **certification** of renewable and low-carbon hydrogen (by June 2021)<br>Propose measures to facilitate the use of hydrogen and its derivatives in the transport sector in the Commission's upcoming **Sustainable and Smart Mobility Strategy**, and in related policy initiatives (2020)</td></tr></tbody></table>

<a id='fb8baf92-b469-435d-bfb5-86743ba4d784'></a>

Coordination
and
partnerships

Reinforcing EU
leadership in
technical standards
and regulations

Strengthen EU leadership in **international technical standards, regulations and definitions** on hydrogen

Develop the **hydrogen mission** within the next mandate of Mission Innovation (MI2)

Promote cooperation with **Southern and Eastern Neighborhood partners and Energy Community countries, notably Ukraine** on renewable
electricity and hydrogen

Set out a **cooperation process on renewable hydrogen with the African Union** in the framework of the Africa-Europe Green Energy Initiative

Develop a **benchmark for euro denominated transactions** by 2021

<a id='d3fcca8a-f6e6-4ce3-8cea-4d68470a065a'></a>

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='eeef0019-6be5-4f72-920a-2e26dad4efe5'></a>

McKinsey & Company

<a id='c6677f25-2014-4c2f-b0fd-a8aef1e20b71'></a>

14

<!-- PAGE BREAK -->

<a id='12230fea-6ec5-4c76-83c7-62e60dcfc1a7'></a>

1.2 / Key actions in the EU's Hydrogen Strategy for a climate-neutral Europe – Investments and incentives

<a id='a48648bf-0b0a-45b4-b325-bd1926c1ce58'></a>

<::logo: [European Union]
[No text]
A blue rectangular flag with a circle of twelve yellow stars in the center.::>

<a id='0c9c4823-a7d1-4677-bb67-656f73100ace'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Developing an<br>investment agenda<br>for the EU</td><td>Through the European Clean Hydrogen Alliance, develop an investment agenda to stimulate the roll out of production and use of hydrogen and<br>build a concrete pipeline of projects (by end of 2020)<br>Support strategic investments in clean hydrogen in the context of the Commission's recovery plan, in particular through the Strategic European<br>Investment Window of InvestEU (from 2021)<br>Explore additional support measures, including demand-side policies in end-use sectors and a carbon Contracts for Difference program</td></tr></tbody></table>

<a id='fe58f477-f02b-43f7-b34b-0105887340fb'></a>

Infrastructure
Designing a
framework for
infrastructure

<::transcription of the content
: icon::>

Start the planning of hydrogen infrastructure, including in the Trans-European Networks for Energy and Transport and the Ten-Year Network Development Plans (TYNDPs) (2021) taking into account also the planning of a network of refueling stations
Accelerate the deployment of different refueling infrastructure in the revision of the Alternative Fuels Infrastructure Directive and the revision of the Regulation on the Trans-European Transport Network (2021)

<a id='9d583637-a2c2-4e8b-b7fd-3699a169dcad'></a>

<table><thead><tr><th>R&D</th><th></th></tr></thead><tbody><tr><td>Promoting research<br>and innovation in<br>hydrogen<br>technologies</td><td>Launch a 100 MW electrolyzer and a Green Airports and Ports call for proposals as part of the European Green Deal call under Horizon 2020<br>(Q3 2020)</td></tr><tr><td></td><td>Establish the proposed Clean Hydrogen Partnership, focusing on renewable hydrogen production, storage, transport, distribution and key<br>components for priority end-uses of clean hydrogen at a competitive price (2021)</td></tr><tr><td></td><td>Steer the development of key pilot projects that support Hydrogen value chains, in coordination with the SET Plan (from 2020 onwards)</td></tr><tr><td></td><td>Facilitate the demonstration of innovative hydrogen-based technologies through the launch of calls for proposals under the ETS Innovation Fund<br>(first call launched in July 2020)</td></tr><tr><td></td><td>Launch a call for pilot action on interregional innovation under cohesion policy on Hydrogen Technologies in carbon-intensive regions (2020)</td></tr></tbody></table>

<a id='09b0d854-8b1c-480b-ab61-1e051595eaef'></a>

Skilled labor
<::line drawing of a person wearing a graduation cap: icon::>
N/A

<a id='1658044e-1f25-4339-a75a-7a5b7470cea2'></a>

Support the needed adjustments in upskilling and in the labor market through the **European Clean Hydrogen Alliance**

<a id='3768e6c3-2b68-4279-aca6-0c6d212e114a'></a>

Source: European Commission 2020 - A hydrogen strategy for a climate-neutral Europe

<a id='f77cad71-dd65-47c5-adf4-55e97aa5606f'></a>

McKinsey & Company

<a id='50e3200f-11bc-4afb-9947-df813beed22d'></a>

15

<!-- PAGE BREAK -->

<a id='0d60efab-a6cd-40ee-bda9-9e82cb889689'></a>

1.2 / The EU supports hydrogen innovation, demonstration and scale up through different instruments

<a id='d2243ef4-6666-4588-9c44-4c8520e9606f'></a>

<::logo: [European Union] 
A blue rectangular flag with a circle of twelve yellow stars in the center.::>

<a id='1b5478c4-6e19-4108-b961-9293442ead0b'></a>

**Main relevant examples**

---

EU Funding Financial instruments with risk sharing component Loans Technical Assistance

<a id='ac86d86f-dffa-4b8d-97df-814bf9035ff4'></a>

<table id="15-1">
<tr><td id="15-2"></td><td id="15-3"></td><td id="15-4">Pre-commercial development</td><td id="15-5">Uptake, market ready, roll-out</td></tr>
<tr><td id="15-6">Funding sources</td><td id="15-7"></td><td id="15-8">Proof of concept → Pilot → Demonstration</td><td id="15-9">→ Scale up → Roll out</td></tr>
<tr><td id="15-a">EU</td><td id="15-b">Horizon Europe</td><td id="15-c" colspan="2">long arrow pointing right</td></tr>
<tr><td id="15-d"></td><td id="15-e">Connecting Europe Facility (CEF)</td><td id="15-f"></td><td id="15-g">horizontal arrow</td></tr>
<tr><td id="15-h"></td><td id="15-i">LIFE Programme</td><td id="15-j" colspan="2">horizontal arrow pointing right</td></tr>
<tr><td id="15-k"></td><td id="15-l">Innovation Fund</td><td id="15-m">horizontal line</td><td id="15-n">arrow pointing right</td></tr>
<tr><td id="15-o"></td><td id="15-p">InvestEU</td><td id="15-q">horizontal line</td><td id="15-r">arrow pointing right</td></tr>
<tr><td id="15-s"></td><td id="15-t">InnovFin</td><td id="15-u">horizontal line</td><td id="15-v">arrow pointing right</td></tr>
<tr><td id="15-w"></td><td id="15-x">EIB Loans</td><td id="15-y">horizontal line</td><td id="15-z">arrow pointing right</td></tr>
<tr><td id="15-A"></td><td id="15-B">EIB Advisory Hub (EIAH)</td><td id="15-C">horizontal line</td><td id="15-D">arrow pointing right</td></tr>
<tr><td id="15-E">Hybrid, blending EU and national funding</td><td id="15-F">European Structural and Investment Funds (ESIF)</td><td id="15-G">(horizontal arrow)</td><td id="15-H">(horizontal arrow)</td></tr>
<tr><td id="15-I">National Funding on the basis of a European plan</td><td id="15-J">Important Projects of Common Interests (IPCEI)</td><td id="15-K">(horizontal arrow)</td><td id="15-L">(horizontal arrow)</td></tr>
</table>

<a id='c4c78d33-7757-48f3-bdff-17046d6ae932'></a>

McKinsey & Company

<a id='dac4c9d4-ea1c-425d-b36e-cf2e8eabdcad'></a>

16

<!-- PAGE BREAK -->

<a id='0b2ad763-bfff-4170-ad7e-e1e7e2a69dbb'></a>

## 1.2 / South Korea Hydrogen Strategy pursues industrial competitiveness and growth
---


<a id='63f60f3a-76d5-4a14-8976-4d38dab8109c'></a>

## General approach

Long-term targets until 2040 were released in the "Hydrogen Economy Roadmap of Korea" and the "National Roadmap of Hydrogen Technology Development" in 2019

<a id='a73a2278-c406-4431-9255-9cab8f1d1d29'></a>

Next to **hydrogen mobility**, the strategy focuses on the long-term establishment of a "hydrogen-powered" society, with key areas being the **production of hydrogen vehicles**, hydrogen-related **infrastructure** and hydrogen for **power generation**

<a id='2883e784-e6af-472e-bf18-66a1143a6ceb'></a>

**Key measures** include government funding, subsidies, industry alliances and development partnerships with other countries such as Australia, Saudi Arabia, Norway and Israel

<a id='bcb85b16-0c19-468f-9345-3586cfaa1608'></a>

**National OEMs and suppliers** also announced significant investments into hydrogen, e.g. Hyundai Motor Group and its suppliers plan to invest a total of **USD 6.7 bn** and to produce **500k FCEVs** annually by 2030

<a id='278c0db1-b386-4d99-993b-b434eb858847'></a>

# Overview of key action areas

**Vision and targets**

Established targets on **FCEV production** and **refueling stations** in the country

<a id='6efac158-22d6-4c4b-bb1e-e55b232c1a7f'></a>

Regulation and
licensing

Establish legal safety standards to
ensure the reliability and stability of the
hydrogen economy

<a id='fd673d60-9e71-4e63-accb-717dc5709525'></a>

Coordination and partnerships

Establish a cooperation system among Korea, China, and Japan, and reinforce participation in global partnerships (e.g. Hydrogen Council)

<a id='0d179d51-49af-4003-99e5-a0bff226ca58'></a>

R & D

Create of a **Hydrogen Industry Cluster**
(2021) for R&D cooperation between
relevant players

<a id='82cef1f8-04df-434c-8f4f-b028b147df55'></a>

Skilled labor

Create a **safety professional**
**qualification** to manage safety across all
processes of the hydrogen value chain

<a id='f5878fe2-d563-474a-8c94-48cf1dd27e69'></a>

1. Includes grey, blue, and green hydrogen. By 2040 the target is to use 70% low-emissions hydrogen (i.e. blue and green)

<a id='9e40ac19-a296-4802-ab83-e6f554b754e5'></a>

Source: South Korean hydrogen roadmap; MOTIE; Ifri 2018; Green Car Congress; Press search

<a id='c4437c59-630e-4c36-9f8c-88fcd5215eb4'></a>

<::logo: [South Korea]The national flag of South Korea features a red and blue taegeuk symbol in the center, surrounded by four black trigrams on a white background.::>

<a id='71dbd3b2-0526-4a27-ac36-0bcd567c3712'></a>

NOT EXHAUSTIVE

<a id='0cda1dea-9746-431d-bdc9-b01c407e884d'></a>

Key commitments and targets

**No. 1** fuel cell producer worldwide

**6.2 Mn** FCEV annual production capacity (incl. passenger cars, trucks, and buses) by 2040

**2.3 Bn USD** for the establishment of a public-private hydrogen vehicle industry ecosystem by 2022

Hydrogen¹ consumption targets,
Million tons per year

<::Bar chart showing hydrogen consumption targets:
- 2022: 0.5 Million tons per year
- 2040: 5 Million tons per year
: chart::>

<a id='0703b0b6-c7e1-414e-b347-c6c9bdc1bbd5'></a>

McKinsey & Company

<a id='ddc185c6-36bf-4fb5-b0b9-686b3249d090'></a>

17

<!-- PAGE BREAK -->

<a id='6c1872f4-c613-484f-a01d-5f7646391cc1'></a>

## 1.2 / South Korea focuses on scaling up domestic production of transport and electricity segments

<a id='29006385-1aef-45eb-90e2-894c317322a3'></a>

<::logo: [South Korea] [No text] [A white rectangular flag with a red and blue taegeuk symbol in the center, surrounded by four black trigrams in each corner.]::>

<a id='2c02b83e-77b3-4615-a8c7-b42bd9049224'></a>

<::NOT EXHAUSTIVE
Legend: X % share target of low-carbon hydrogen

Timeline and Bar Chart showing Hydrogen consumption, million tons per year:
- 2018: 0.1
- 2022: 0.5
- 2040: 5 (70%)
: figure::>

<a id='9561d09e-cf83-493b-9645-bb32c14b9b6d'></a>

<table><thead><tr><th></th><th>Col 1</th><th>Col 2</th><th>Col 3</th></tr></thead><tbody><tr><td>Infrastructure roadmap</td><td>14 refueling stations<br>500 tube trailers<br>200km of pipelines</td><td>310 refueling stations<br>Introduction of high-pressure trailers for<br>transport, and large-scale gas storage and<br>transportation<br>Establish pipelines near by-product H2<br>production hubs<br>Build infrastructure for overseas production<br>(from 2022)</td><td>1200 refueling stations<br>Liquefaction and liquid and solid storage and<br>transportation (2030)<br>Construction of a nationwide high-pressure<br>pipeline network (2030)<br>Establish nationwide supply infrastructure (2030)</td></tr><tr><td>Targeted end-use sectors</td><td>Transport: 1.8k FC passenger vehicles<br>production capacity, 2 buses</td><td>Transport: 79k FC passenger vehicles<br>production capacity, 2k buses<br>Centralized power generation: 1.5 GW<br>Decentralized power generation (i.e. home fuel<br>cells): 50 MW</td><td>Transport: 5.9 Mn FC passenger vehicles<br>production capacity, 60k buses, 120k taxi fleet,<br>120k trucks. Domestic and for export². Ships,<br>trains, and drones<br>Centralized power generation: 15 GW<br>Decentralized power generation: 2.1+ GW</td></tr></tbody></table>

<a id='a4cf21cf-f9d0-46d3-9d77-133936bb8164'></a>

Selected support
schemes

Subsidies for FCEVs purchase to incentivize domestic production of vehicles at the beginning of the strategy (no year specified). Additionally, the
government will also provide funding for the initial expansion of **refueling stations** and establish **more relaxed permit restrictions**.
Support fuel cells deployment for power generation by my means of **weighted Renewable Energy Certificates**. Provision of financial incentives for
**home fuel cells** such as the establishment of an **LNG-exclusive tariff** by 2022

<a id='f69b4614-ea2d-45d3-a717-f396db25e9a2'></a>

1. Includes grey, blue, and green hydrogen. Includes domestic production and imports;
2. In total, 3.3 Mn units for export and 2.9 Mn units for domestic consumption.

<a id='9ab0a7a3-17ba-4c5d-ac28-e04d56b8ff2e'></a>

Source: Ministry of Economic Affairs and Climate Policy of the Netherlands; IEA; International Hydrogen Strategies (World Energy Council Germany); Hydrogen Economy Roadmap of Korea

<a id='9c09079b-18ce-406c-b768-d325c86b17cb'></a>

McKinsey & Company

<a id='e9256be4-5a13-4c64-9b12-f0a3fabe4e36'></a>

18

<!-- PAGE BREAK -->

<a id='e1759393-8947-442f-a1d8-991dba409fb4'></a>

1.2 / Key actions in for the creation of the hydrogen industrial
ecosystem in South Korea – Enabling environment

<a id='1daf4c0b-3f10-47ed-8f24-1598fb3b10e9'></a>

<::logo: [South Korea]The logo features a white rectangular background with a central red and blue Taegeuk symbol, surrounded by four black trigrams in each corner.::>

<a id='f7e46202-7c36-4ec8-9a72-513b8806c5c1'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and<br>targets</td><td>Fostering of<br>hydrogen industry</td><td>Focus on creating a new industrial ecosystem and placing South Korea as a global leader in hydrogen utilization, by establishing clear targets,<br>mainly in the <b>transport and power generation sectors</b><br>Support all stages of technological development throughout <b>the entire value chain</b>, from development of source technology in hydrogen-powered<br>vehicles, core components of fuel cells, and storage and transportation, to demonstration, commercialization, and improvement of stability<br>Develop guidebooks on <b>hydrogen safety</b> that address public concerns and include them in the <b>school curricula</b>,<br>Designate a 'Hydrogen Day' and hold an exhibit with new technologies and programs</td></tr><tr><td>Regulation<br>and licensing</td><td>Promoting growth<br>across the entire<br>value chain</td><td>Start a detailed roadmap for supporting the technological development throughout the <b>entire value chain</b>, in collaboration between the Ministry<br>of Industry, Ministry of Science and Technology, Ministry of Land, and the Ministry of Water Resources. In addition, <b>launch a cross-ministerial<br>preliminary feasibility study</b> for hydrogen (2021 to 2030)<br>Establish legal <b>safety standards</b> to ensure the reliability and stability of the hydrogen economy throughout the entire value chain. Enactment of a<br>"<b>Hydrogen Economy Act</b>" to provide an institutional base in H2 2019<br>Provide <b>relaxed licensing standards</b> for transportation companies introducing eco-friendly vehicles like hydrogen buses</td></tr></tbody></table>

<a id='13ff8670-fd4d-47ab-b66e-f88465cb7520'></a>

Coordination Enhancing
and international
partnerships cooperation and

<::transcription of the content
: icon of two people::>

industry alliances

Lead international standardization and evaluate at least 15 cases **technical standards in hydrogen production, storage vessels, fueling systems, and fuel cells** by 2030
Establish a **cooperation system among Korea, China, and Japan**, and reinforce participation in **global partnerships** (e.g. Hydrogen Council)
Enhance partnerships for the **development of overseas import base** from e.g. Middle East and Central and South America
Promote a hydrogen economy in South Korea through **industry alliances** and international partnerships
*   **HyNet** (e.g. Hyundai, Air Liquide) promotes the establishment of hydrogen refueling infrastructure
*   **H2Korea** and **FCHEA** sign MoU in Feb. 2020 to increase collaboration in the hydrogen economy

<a id='db7268c1-33bf-4a09-86e4-a070bb31d5bb'></a>

Source: Ministry of Economic Affairs and Climate Policy of the Netherlands; IEA; International Hydrogen Strategies (World Energy Council Germany); Hydrogen Economy Roadmap of Korea

<a id='99e36ca5-44c5-4283-9def-8d73320e7492'></a>

McKinsey & Company

<a id='f191dd33-1822-45a9-8779-319c46b62dc2'></a>

19

<!-- PAGE BREAK -->

<a id='931f53a5-dda7-41d8-bc88-d543387b8025'></a>

1.2 / Key actions in for the creation of the hydrogen industrial ecosystem in South Korea – Investments and incentives

<a id='041e918c-85f5-4bd1-b133-a5495a218ed8'></a>

<::logo: [South Korea] [No text] [A white rectangular flag with a red and blue taegeuk symbol in the center, surrounded by four black trigrams in each corner.]::>

<a id='e3e0f68a-caef-4a30-a398-c97cb27cb48c'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Securing the self-proliferation of the technology</td><td>Offer **subsidies for FCEVs purchase** to incentivize domestic production of vehicles and subsidies for the **operation of refueling stations** as well as establish more **relaxed permit restrictions**<br>Support fuel cells deployment for power generation by my means of **weighted Renewable Energy Certificates**. Provide financial incentives for **home fuel cells** such as the establishment of an **LNG-exclusive tariff** by 2022<br>Support FCEV business partners with long-term, **low-interest policy loans and investment expenses**<br>Promote financial support to **establish mass production facilities**</td></tr><tr><td>Infrastructure</td><td>Fostering<br>technology maturity<br>and expansion</td><td>Establish a supply infrastructure network **nationwide by 2030**<br>Convert from high-pressure gas storage to high-efficiency **liquefaction and liquid and solid storage**<br>**Reduce cost of hydrogen distribution** by establishing high-efficiency, high-capacity hydrogen storage and transportation systems</td></tr><tr><td>R&D</td><td>Performing large-scale<br>demonstrations and<br>supporting domestic<br>production</td><td>Create a **Hydrogen Industry Cluster** (2021) for R&D cooperation and for the development of a **large-scale testbeds**<br>Help selected **companies to secure a global position** with R&D and finance support<br>Build up large-scale demonstration projects for different end-uses. Selection of Ansan, Ulsan, and Wanju/Jeonju as **national testbed cities** by the South Korean Ministry of Land, Infrastructure, Transport, and Tourism.<br>**Invest** to optimize the production of FCEV parts. Public funding for the investigation of **hydrogen trains** efficiency and stability, application of **fuel cells on ships**, and other transport-related activities<br>**Start a pilot project for usage of hydrogen trucks** in the public sector, and a demonstration project for the conversion of general freight trucks</td></tr><tr><td>Skilled labor</td><td>Training of safety<br>standards and<br>development<br>specialists</td><td>Create a **safety professional qualification** to manage safety across all processes of the hydrogen value chain<br>Establish a **training program** covering the **design, operation, and safety of hydrogen refueling stations**, for station managers. **Train core personnel** on the design, production, and maintenance of **fuel cells**,<br>Support SMEs with **research personnel and recruitment**</td></tr></tr></tbody></table>

<a id='7fff1d22-7e7f-4e9c-9b45-3443b5939a5d'></a>

Source: Ministry of Economic Affairs and Climate Policy of the Netherlands; IEA; International Hydrogen Strategies (World Energy Council Germany); Hydrogen Economy Roadmap of Korea

<a id='498de3c7-d470-47d7-b9fb-55d42b5a2cf1'></a>

McKinsey & Company

<a id='bac825f2-5162-4ba1-a2f6-470cd1d4e9cb'></a>

20

<!-- PAGE BREAK -->

<a id='b1e43883-0663-4ff6-a1b4-2ec9059d7d01'></a>

1.2 / Dutch Hydrogen Strategy

<a id='c3b74afc-169a-4350-afd7-3610ca958d7b'></a>

## General approach
The **h2 roadmap until 2050** was released in the Dutch "**National Climate Agreement**" in 2019, and further specific measures were introduced in the "**Government Strategy on Hydrogen**" in 2020

<a id='aea71e61-5d35-445d-95f4-ed8bf5c7361e'></a>

The strategy places hydrogen as a key enabler in the **long-term energy transition** and includes **specific targets in transport**, being other sectors' roadmap subject to further analysis and cost reductions

<a id='22711fee-702f-42be-8050-47b17827fb58'></a>

**Key actions** include government support through new and existing support schemes, international and public-private cooperation, and R&D

<a id='f85e2a68-ad9d-4ec1-9627-97ee28ac16c3'></a>

Additionally, the Dutch government launched
the **Hydrogen Valley initiative** to **establish a**
**hydrogen industry**, as response to **declining**
**gas industry** in **Northern regions** Groningen,
Drenthe and Friesland. Financed with EUR 20
Mn (~MUSD 23.4) by the EU, and EUR 70 Mn
(~MUSD 82) by a consortium.

<a id='138e298f-f24a-46d8-87e0-f1b5ed42edb7'></a>

Currently there are **9+ GW of hydrogen projects announced**, ramping up towards 2040

<a id='1c9a171e-5f68-4b4e-9bab-044410778c31'></a>

Overview of key action areas
<table id="20-1">
<tr><td id="20-2">Regulation and licensing</td><td id="20-3">Implement safety standards and a policy framework for hydrogen safety risks</td></tr>
<tr><td id="20-4">Coordination and partnerships</td><td id="20-5">Promote consultations and bilateral cooperation with North Sea countries to exploit the significant potential of offshore wind energy</td></tr>
<tr><td id="20-6">R &amp; D</td><td id="20-7">Support H2 R&amp;D projects through different programs such as MOOI2 tenders (EUR 17 M) and DEI+ program, (EUR 15 M per project )</td></tr>
<tr><td id="20-8">Skilled labor</td><td id="20-9">Comprehensive framework to tackle labor issues in the National Climate Agreement including specific regional agendas for education development and labor market improvement</td></tr>
</table>

<a id='ad0bc611-958c-4527-9840-e4f63d128432'></a>

Source: Dutch Government Strategy on Hydrogen, Government publications; International Hydrogen Strategies (World Energy Council Germany)

<a id='c2b028fa-5544-42c8-b1af-c29eca749245'></a>

<::logo: [Flag of the Netherlands] NOT EXHAUSTIVE This is a rectangular flag with three horizontal stripes: red on top, white in the middle, and blue at the bottom.::>

<a id='529b85f2-68c2-4673-bd94-0757ee6bb16f'></a>

# Key commitments and targets

**0.5 GW**
of installed electrolysis
capacity until 2025

**3-4 GW**
of installed electrolysis
capacity until 2030

**100%**
climate-neutral economy by
2050

<a id='121d0030-1294-4176-b331-8775799f678c'></a>

McKinsey & Company

<a id='ca2492d2-29bb-412e-8baf-bfd598309074'></a>

21

<!-- PAGE BREAK -->

<a id='a59c0d2d-19fa-4137-aba3-4266bfd34102'></a>

1.2 / Dutch Hydrogen Strategy

<a id='8970406b-df03-42a9-ac2c-5df6ccd13966'></a>

<::logo: The Netherlands
This logo features a rectangular flag with three horizontal stripes: red on top, white in the middle, and blue on the bottom.::>

<a id='35279ca3-9999-4b30-bf8f-f50b0f232899'></a>

Electrolysis capacity targets, GW <::Bar chart showing electrolysis capacity targets in GW for different years. The years are displayed in large dark blue horizontal bars with white text. Below these year bars, smaller dark blue bars indicate the capacity targets. A horizontal line serves as the base for the capacity bars. For 2025, the target is 0.5 GW, represented by a short dark blue bar. For 2030, the target is 3-4 GW, indicated by a taller dark blue bar with a dashed outline extending above it, labeled "3-4". For 2050, the target is unknown, represented by a dark blue bar with a dashed outline above it, labeled "?".: chart::>

<a id='9eddfa89-bca6-4fda-8c89-e26c34e11085'></a>

<table><thead><tr><th>Col 1</th><th>Col 2</th><th>Col 3</th><th>Col 4</th></tr></thead><tbody><tr><td>Infrastructure<br>roadmap</td><td>50 refueling stations. 10% investment costs<br>reduction per year</td><td>N/A</td><td>N/A</td></tr><tr><td></td><td>Port of Rotterdam as international hub for hydrogen import and distribution across Europe (no timeline specified)</td><td></td><td></td></tr><tr><td></td><td>Evaluation of the necessity for grid strengthening and of an obligation for hydrogen blending into the gas grid (no year specified)</td><td></td><td></td></tr></tbody></table>

<a id='4e4a47eb-d3c0-4845-8ebc-d5969f1ef2e8'></a>

Targeted end-use
sectors

(Icons: truck, building, factory)

**Transport:** 15k FCEV, 3k HDV
**Shipping:** increase use of hydrogen in shipping
industry (no year specified)
**Industry:** upgrading and refineries mentioned
but not concrete plans stated

**Transport:** 300k FCEV
**Aviation fuels:** 14% blending obligation

**Aviation fuels:** 100% blending obligation
**Power generation:** long-term relevance of
hydrogen (no specific targets/plan provided)
**Building sector:** higher relevance after 2030
due to uncertain technology costs

<a id='06658bc8-5b3d-4d25-984b-e80b33f59fa4'></a>

Selected support schemes

For a transitional period, to enable scaling up, operational cost support will be available starting 2021 with an annual budget of EUR 35 Mn¹
Starting in 2020, the existing SDE++ scheme² for the generation of sustainable energy will include electrolysis
Development of a system of Guarantees of Origin for green H₂
Allocation of EU funds through the H2 Platform

<a id='895773c1-a267-4d3c-8223-49d474fa9df1'></a>

1. The funds are made available through rearranging part of the existing DEI+ funds; 2. In total 2,000 full load hours are eligible for subsidy through this scheme with a maximum subsidy amounting to 300 EUR/ton abated CO2

<a id='8061f5c0-7cde-4c94-82ce-cb9dc526993f'></a>

Source: Dutch Government Strategy on Hydrogen, Government publications; International Hydrogen Strategies (World Energy Council Germany)

<a id='bc48104e-d5e1-4f7e-956e-458745a2eb62'></a>

McKinsey & Company

<a id='a0c222d2-cbfc-43b8-acfe-d83b0cb50f88'></a>

22

<!-- PAGE BREAK -->

<a id='49646861-ae9a-4856-863f-1d8158ed5da8'></a>

1.2 / Dutch Hydrogen Strategy – Enabling environment

<a id='d2bb64f7-bee1-40e1-88d4-73304ff507f1'></a>

<::logo: [Netherlands] [] [A rectangular flag with three horizontal stripes: red on top, white in the middle, and blue on the bottom.]::>

<a id='6c6dd0e5-711a-44c6-8e53-8902421359ee'></a>

NOT EXHAUSTIVE

<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and<br>targets</td><td>Introducing a vision<br>for the future based<br>on guidance and<br>phasing</td><td>Establish generation and sector targets in addition to those presented in the Dutch National Climate Agreement. The focus is on the following<br>sectors: ports and industry clusters, transport, built environment, electricity sector, and agricultural sector<br>Retain the current strategic position as an energy hub<br>Foster cost reductions in order to unlock scaling up of hydrogen production and the subsequent set up of the supply chain, by means of new<br>and existing support schemes</td></tr><tr><td>Regulation<br>and licensing</td><td>Developing policy<br>tools to facilitate<br>deployment in<br>collaboration with<br>the private sector</td><td>Introduce a policy agenda based on 4 pillars: legislation and regulation, cost reduction and scaling up green hydrogen, sustainability on final<br>consumption, and a supporting and flanking policy<br>Formulate a National Hydrogen Programme as part of the National Climate Agreement, based on the hydrogen phasing plan leading up to<br>2030<br>Review the formulation of a position on the regulation of the value chain. The main goals are to facilitate the market, to ensure security of supply,<br>and to keep social costs the lowest possible<br>Implement safety standards based on international and European guidelines, and implement a policy framework for hydrogen safety risks<br>Launch a public-private Hydrogen Safety Innovation Programme to address safety issues</td></tr></tbody></table>

<a id='3bbd2ed3-3673-49d7-8d0b-014080a8adb1'></a>

Coordination Strengthening
and European
partnerships cooperation

<::transcription of the content
: figure::>

Communicate directly with the **European Commission** regarding EU hydrogen policies
Start initiative, together with Austria, to develop common approaches to critical issues such as **standards, market incentives and market regulations**, in a Forum with **Benelux, Germany, France, Austria and Switzerland**
Promote consultations and bilateral cooperation with **North Sea countries** to exploit the significant potential of **offshore wind energy** as key source for the production of green hydrogen beyond 2030.
Focus on a strong European competitive position internationally through the IPCEI¹

<a id='5acf2ca9-521f-47f4-86fc-bd7633e3b14b'></a>

1. Important Projects of Common European Interest

<a id='4ba058d2-9dbd-487d-809b-7b8f9da89639'></a>

Source: Dutch Government Strategy on Hydrogen; International Hydrogen Strategies (World Energy Council Germany);

<a id='c2e2106c-2f46-46a8-85fa-97a8e1dada6b'></a>

McKinsey & Company

<a id='16ed8ff2-d381-4883-be54-4de1cef30453'></a>

23

<!-- PAGE BREAK -->

<a id='9fb2490e-0cf4-4565-bc4f-c07c633975e2'></a>

1.2 / Dutch Hydrogen Strategy – Investments and incentives

<a id='0e2fb5b6-9052-43ec-862f-d667a6e18fe6'></a>

<::logo: The Netherlands
This image shows the flag of The Netherlands, which consists of three horizontal stripes of red, white, and blue.::>

<a id='f6fbeba1-d0a3-4c95-8469-bd503f06dc22'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Offering financial<br>support at the<br>various phases of<br>the development<br>process</td><td>Develop a reliable system of <b>Guarantees of Origin (GOs)</b> and certification<br>Introduce a new and temporary <b>support scheme for operating costs related to the scaling up and cost reduction</b> process for green hydrogen<br>Facilitate the scaling-up by making use of the existing <b>Climate Budget funds</b> as of 2021, with an annual budget of <b>EUR 35 Mn</b><br>Include electrolysis hydrogen production in the <b>SDE++ support scheme¹</b>. Blue hydrogen production will be able to compete in the CCS category<br>Explore the feasibility of a <b>blending obligation</b> of hydrogen in the distribution networks</td></tr><tr><td>Infrastructure</td><td>Steering the<br>deployment in<br>collaboration with<br>industrial players</td><td>Review the <b>use of the existing gas grid</b>, and determine whether and under which conditions it could be used for hydrogen<br>Coordinate the optimal placement of hydrogen infrastructure through the <b>Main Energy Infrastructure Programme</b><br>Focus on infrastructure as <b>key enabler for industry clusters</b> sustainability improvements</td></tr><tr><td>R&D</td><td>Offering support<br>schemes for<br>research, scaling up<br>and rolling out</td><td>Support hydrogen projects through annual MOOI² tenders. In 2020, hydrogen projects are eligible to compete for a <b>EUR 17 Mn budget</b> (aprox.<br>MUSD 20), with a maximum <b>individual subsidy of EUR 4 Mn</b> (aprox. MUSD 4.7)<br>Support R&D projects in an <b>industrial environment</b> through the DEI+ program, which covers <b>25-45% of eligible cost up to EUR 15 Mn per project</b> (aprox. 17.6 MUSD)<br>Focus on <b>applied research</b> in collaboration with the business community through, among others, the <b>Netherlands Organization for Applied Scientific Research (TNO)</b><br>Research production and applications of green hydrogen through the <b>Energy Top Sector</b> as part of the various multi-year mission-driven innovation programs</td></tr><tr><td>Skilled labor</td><td>N/A</td><td>N/A</td></tr></tbody></table>
1. Support scheme for cost-effective carbon emissions reduction

<a id='3ae67d90-a281-44aa-ad50-bf96c4648465'></a>

Source: Dutch Government Strategy on Hydrogen; International Hydrogen Strategies (World Energy Council Germany);

<a id='c5d96820-910b-4c15-a1a1-957ee1750b32'></a>

McKinsey & Company

<a id='f1157de0-71bd-4bf5-84f5-a7cd5abf00a4'></a>

24

<!-- PAGE BREAK -->

<a id='fb304c8a-cc8d-464f-9a11-8905b5a67eac'></a>

1.2 / German government agrees on National Hydrogen Strategy

<a id='39267b51-abe4-4297-9d9c-b2c0559fd5f6'></a>

## Description
German Government agrees on **National**
**Hydrogen Strategy** that aims at providing
a framework for future **production** and
**application of hydrogen** as well as
related innovations and **investments**

<a id='3117f437-dc9d-4ebd-93a8-435fa6e98914'></a>

**Long-term** focus is on **green** production,
however, the role of **other low-carbon**
**pathways** is **acknowledged** as import tool
for **short-** to **mid-term** market acceleration

<a id='ed626711-a155-4099-8637-92faccc03170'></a>

The strategy aims at laying the **foundation** for a **functioning hydrogen market** until 2023

<a id='3e29c9d7-7251-4423-8516-10ea75295e77'></a>

The government and a **National Hydrogen Council** will **evaluate and review the strategy every 3 years**

<a id='7186b3bb-8661-4b41-9f8c-85d6d3dbdb3e'></a>

Demand for hydrogen in Germany, TWh <::chart: Bar chart showing demand for hydrogen in Germany in TWh. The x-axis represents years, and the y-axis represents TWh. There are two bars: 2020 with a value of 55 TWh, and 2030 with a range of 90-110 TWh.::>

<a id='cd57cb56-088d-4067-be62-5724caeeab01'></a>

# Overview of key measures

The strategy includes **38 measures** that aim at establishing a value chain for the **production, distribution, and large-scale use of hydrogen**

**Generation**
Support **green hydrogen production** via new **support schemes** (contracts-for-difference, auctions) and **investment grants**

**Infrastructure**
Plan **supply infrastructure** via **dedicated pipelines** and **existing gas networks**

**Hydrogen usage**
Support **usage of hydrogen in various sectors** (e.g., industry, transport, heating) via dedicated **support schemes** and **regulations**, and industry-specific dialogues
Define **standards for hydrogen products** to establish **international market**

**Partnerships**
Intensify **international partnership projects** to enable **imports of green hydrogen** as domestic production (14 TWh of in 2030) is expected to be **insufficient for deep decarbonization**

<a id='aa2edc7c-851e-49de-9689-0512c2cca1e6'></a>

1. The strategy mentions a target of 2 GW for electrolyzer but does not specify a concrete time frame or if this is additional to the 5-10 GW targets
2. Additional 5 GW to be added until 2035 if possible but no later than 2040

<a id='290d1235-aa6d-4b0a-bfd6-8161d647bb11'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='d917985e-31f6-44de-9d17-6c2c12b94813'></a>

<::logo: [Germany]
[No text]
A rectangular flag with three horizontal stripes of black, red, and gold, from top to bottom, respectively.::>

<a id='c9c95e1e-edd1-4492-81be-2c27c415847d'></a>

Key commitments and targets

**7 bn** EUR investments for **domestic** hydrogen market ramp-up

**2 bn** EUR investments for hydrogen projects within **international partnerships**

**2%** quota for **green hydrogen-** based aviation fuels until 2030 to be investigated

<a id='ebf93f35-16ca-4e03-81bf-a8f4bb8a1865'></a>

<::Installed electrolysis capacity targets ¹, GW
Bar chart with two bars:
- 2030: 5 GW
- 2035-40²: 10 GW
: bar chart::>

<a id='afc9b42c-531f-4b24-9012-d9f346b7dd7c'></a>

McKinsey & Company

<a id='f52166af-7d41-4ad4-9a71-750a15d57cc4'></a>

25

<!-- PAGE BREAK -->

<a id='5bf00da8-b4cc-4429-910a-95ed20aa97d7'></a>

1.2 / Germany's national hydrogen strategy gets continuously revised in 3-year cycle

<a id='76488958-fa85-4d78-8e87-daa40ec66168'></a>

---option x: [x] Renewable hydrogen production, TWh/yr<::Horizontal roadmap with three phases:1. Phase 1: 2020-2023: Market launch– Decarbonize existing hydrogen production and facilitating take up of hydrogen consumption in new end-uses2. Phase 2: 2023-2030: Scale up – Expand production and end-use to additional sectors to develop hydrogen as intrinsic part of an integrated energy system3. Beyond 2030: Use hydrogen to establish CO2-neutral economy by 2050: roadmap::>Electrolysis capacity targets, GW<::Bar chart showing electrolysis capacity targets in GW:1. For 2030, a bar represents 5 GW, with an additional circled value of 14 GW.2. For 2035-2040, a bar represents 10 GW, with an additional circled value of 28 GW.: bar chart::> 

<a id='cb90639b-a0d7-40e4-8712-2d76450d49b5'></a>

<table><thead><tr><th></th><th></th></tr></thead><tbody><tr><td>Infrastructure roadmap</td><td>Formulate report on recommendations for hydrogen supply through dedicated pipelines as well as<br>hydrogen-readiness of existing gas infrastructure, and buildout of hydrogen gas stations<br>Redesign planning and financing of infrastructure (electricity, heat and gas) to allow for cross-coordination and cost-efficient deployment of energy transition capable energy infrastructure<br>Create hydrogen refueling station infrastructure</td></tr><tr><td>Targeted end-use sectors</td><td>Transport: 3.6 bn EUR in subsidies for vehicles<br>and 1.1 bn for fuels until 2023¹<br>Heating: Support hydrogen fuel cell heating<br>Industry: Subsidize hydrogen use in chemicals<br>and steel. 55 TWh/yr consumption (2020)<br>Transport: 2% green hydrogen in aviation fuel<br>Heating: Further promote hydrogen use<br>Industry: >65TWh/yr consumption</td></tr><tr><td>Selected support schemes</td><td>Subsidies from energy- and climate fonds<br>Exclude green hydrogen from EEG-levy<br>Grant investment support for electrolyzers to support industry shift from grey to green hydrogen<br>Establish pilot project where generators receive difference between CO2 abatement costs for<br>producing green hydrogen (fixed CO2 price) and the CO2 price in the EU emission trading system to<br>guarantee generators stable returns⁴</td></tr></tbody></table>

<a id='f4250f84-cf03-4663-b809-ae29fa660386'></a>

1. Including electric vehicles and biofuels

<a id='b1afa794-1b16-407a-a573-ddeaff1f9906'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='761d0172-f96b-4960-9293-1891e3dc49a9'></a>

McKinsey & Company

<a id='753e2207-ae5a-4582-be6a-a5e03964895c'></a>

26

<!-- PAGE BREAK -->

<a id='18661560-fd51-44c2-a816-a8c1b3d129ff'></a>

1.2 / Key actions in for the creation of the hydrogen industrial ecosystem in Germany – Enabling environment

<a id='76cf8baa-accf-48b9-88b7-952c5b6e5efa'></a>

<::logo: [Germany] [None] [A rectangular flag with three horizontal stripes: black on top, red in the middle, and gold on the bottom.]::>

<a id='e2ed8f3e-f1e2-48e2-8a27-ef1e282c3d61'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Vision and targets</td><td>Ramping up the<br>green hydrogen<br>market and using it<br>to enable<br>Germany's energy<br>transition</td><td>Create a global impact on GHG reduction by developing a market for green hydrogen and increase global cooperation<br>Enable hydrogen as a competitive source of energy by driving technological development and advancing cost degression, establish green hydrogen in industrial processes and as a fuel source for seafaring and aviation<br>Establish a domestic market that incentivizes hydrogen use and develop hydrogen infrastructure to take advantage of synergies with the energy transition in Germany<br>Improve the hydrogen framework and R&D continuously</td></tr></tbody></table>

<a id='991cba1b-b990-4b34-95d5-9aa5fdc1353c'></a>

Regulation
and licensing
<::description: Icon of a building with columns::>

Promoting the
growth of the entire
value chain

Implement the continuously revised **hydrogen strategy**
Regulatory **unbundling** of electrolyzers and power and gas **grid operators**
Develop and improve **framework conditions** for pairing **offshore wind** and electrolyzers including the designation of **dedicated land/areas** and the possibility of additional tenders
Start a European dialogue between regulators and the industry on **decarbonization strategies**, including hydrogen as an option

<a id='1da57fba-f261-4691-8536-743f0a98b8e8'></a>

Coordination and partnerships

Preceding International Standards and promote industry alliances

Develop joint European regulations and industry standards to establish cross-border hydrogen market and support investments in hydrogen technologies via „Important Project of Common European Interest (IPCEI)"

Integrate hydrogen in international energy partnerships to jointly develop hydrogen technologies and thereby guarantee that Germany's future demand for hydrogen can be met via imports

Advance standardization of hydrogen systems in mobility

<a id='58334580-424d-4cd2-919c-2e3e3b1e3d63'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='c27e36eb-0fe5-40b5-8bd5-aca3507fc5e4'></a>

McKinsey & Company

<a id='d6c01344-52f5-4ec6-97cb-88c03d8b9d5c'></a>

27

<!-- PAGE BREAK -->

<a id='2459b1f3-0db5-48cb-9f84-365e60fa4938'></a>

**1.2 / Key actions in for the creation of the hydrogen industrial ecosystem in Germany – Investments and incentives**

<a id='78c29220-80d2-4f84-b000-fd312ea6d227'></a>

<::logo: Germany
None
A rectangular flag with three horizontal stripes of black, red, and gold (yellow) from top to bottom.::>

<a id='a8b14aeb-2836-4b2a-8d3a-80385bc13855'></a>

NOT EXHAUSTIVE
<table><thead><tr><th>Domain</th><th>Key measures</th><th>Description</th></tr></thead><tbody><tr><td>Financing<br>and<br>incentives</td><td>Establishing green<br>hydrogen as a<br>competitive source<br>of energy</td><td>Subsidies from energy- and climate fonds<br>Exclude green hydrogen from EEG-levy<br>Grant **investment support** for **electrolyzers** to support industry shift from grey to green hydrogen<br>Establish pilot project where generators receive difference between **CO2 abatement costs** for producing **green hydrogen** (fixed CO2 price) and<br>the **CO2 price in the EU emission trading system** to guarantee generators stable returns<sup>4</sup></td></tr><tr><td>Infrastructure</td><td>Developing a<br>reliable and secure<br>infrastructure</td><td>Formulate report on **recommendations** for hydrogen supply through **dedicated pipelines** as well as **hydrogen-readiness of existing gas**<br>**infrastructure**, and buildout of hydrogen gas stations<br>Redesign planning and financing of infrastructure (electricity, heat and gas) to allow for **cross-coordination** and **cost-efficient deployment** of<br>energy transition capable energy infrastructure<br>Create hydrogen refueling station infrastructure</td></tr><tr><td>R&D</td><td>Promoting research<br>and innovation in<br>hydrogen<br>technologies</td><td>Strategically **bundle multiple research initiatives** towards hydrogen and investigate measures to facilitate **market entries** for **new hydrogen**<br>**technologies**<br>Provide **EUR 25 million funding** for hydrogen research in **aviation and shipping respectively** over the 2020-2024 period</td></tr><tr><td>Skilled labor</td><td>Training of safety<br>and development<br>specialists</td><td>Find new ways of collaboration between **research** and **education** to maintain and **expand qualified workforce**<br>**Support** and promote **training and development** of workforce in **hydrogen**, especially in production, processing and maintenance</td></tr></tbody></table>

<a id='96857aae-c5f1-4696-b7e2-34d1c8fce5b0'></a>

Source: Nationale Wasserstoffstrategie (National Hydrogen Strategy), BMWi

<a id='3d6e339d-0a3b-44c5-b2cc-0a8b3cc57c44'></a>

McKinsey & Company

<a id='ee57df64-2f2a-405f-a58c-22b704c32e3c'></a>

28

<!-- PAGE BREAK -->

<a id='98a05731-94da-487d-92df-3f2c1853ba2b'></a>

Chapter 2: Business case for domestic Hydrogen production and end use application

<a id='ef2a4e97-c76f-4541-9194-d14dd05379e4'></a>

Chapter content
description

- **Business cases for domestic production of green hydrogen** through green renewables, including costs of generation and hydrogen production
- **Business case for prioritized end use applications**¹ including: heavy transport, urban buses, mining trucks (CAEX), natural gas blending, industry heating, green ammonia production and replacement of grey hydrogen
- **Domestic demand projections for green hydrogen in Chile** by end use application
- **Identify enabling factors** with the greatest influence over the business case

<a id='ba7ad6f8-8cf9-4b8d-ba63-f523b2bf3e30'></a>

Activities
included

* Activity 2.1
* Activity 2.2
* Activity 2.3
* Activity 2.4

<a id='3030fce9-c61e-47ad-bc5f-a0df0491a20b'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='b4b3ef0b-3873-4aa5-b4d2-4638abb86fa0'></a>

McKinsey & Company

<a id='26c8771d-b59b-4119-ad6d-be47173a8892'></a>

29

<!-- PAGE BREAK -->

<a id='0100447c-fae6-480b-8f74-a86b3b986b30'></a>

2.1/ To model the
potential of Green
Hydrogen in Chile,
we need to optimize
3 factors of
production costs

<a id='baf722d5-2ef7-4d3d-ac99-59b31937e21d'></a>

<::Warning icon (triangle with lightning bolt) followed by a list:
Generation cost
- Generation location
- Capacity Factor sequencing
- Generation technology (wind, PV, Bifacial and CSP)
: infobox::>

<a id='5ef2d9c6-101a-48a8-9348-4e637b4b99ea'></a>

<::A white circular arrow icon with three arrows pointing clockwise is displayed on a dark blue background. Below the icon, a thin white horizontal line separates it from the text content that follows:

Electrolyzer
utilization

RES blending
Storage technology
: icon and text block::>

<a id='32a391fa-4579-41f2-beea-68b79f229155'></a>

<::A white icon of a delivery truck, with a rectangular cargo area and a smaller cab, is shown on a dark blue background. Below the icon, a horizontal line separates it from the following text:
: icon::>
Transmission /
distribution
H2 production location
Transmission costs
Transportation costs

<a id='5f0cd0de-b66c-4c43-9aef-1b117e7bad92'></a>

McKinsey & Company

<a id='8bbb6984-acee-4d32-bc3b-3974fb152e5a'></a>

30

<!-- PAGE BREAK -->

<a id='27cb3f6c-f2f3-4b1f-aa0d-c2fb5466b943'></a>

2.1/ In the three macro-zones considered, LCOE costs in the northern and
southern zones can reach as low as ~19 USD / MWh and ~21 USD / MWh
respectively by 2025

<a id='ac98aa49-8871-492e-ba7f-0f5eff927412'></a>

Levelized cost of energy¹ for competitive zones, USD/MWh
<::
Line chart with Y-axis labeled "USD/MWh" (ranging from 0 to 40) and X-axis labeled "Year" (ranging from 2020 to 2050). Three lines with shaded ranges show the levelized cost of energy for different regions:
- South (dark blue line) decreases from approximately 37 USD/MWh in 2020 to 19 USD/MWh in 2050.
- Central (medium blue line) decreases from approximately 23 USD/MWh in 2020 to 18 USD/MWh in 2050.
- North (light blue line) decreases from approximately 26 USD/MWh in 2020 to 13 USD/MWh in 2050.
: chart::>
Capacity factors by region², %
<::
Table with two main columns: "Competitive zones" and "Uncompetitive zones". Rows are grouped by "Production Zone":
- Northern Production Zone:
  - Competitive zones: Atacama PV 34%, Calama PV 33%, Taltal PV 35%
  - Uncompetitive zones: Coquimbo Wind, Taltal Wind, Calama Wind
- Central Production Zone:
  - Competitive zones: Central PV 23-25%
  - Uncompetitive zones: Chiloe Wind, Biobio Wind, Coquimbo Wind
- Southern Production Zone:
  - Competitive zones: Magallanes wind 56-59%
  - Uncompetitive zones: Bahía Inútil, Offshore wind (Competitiveness still being assessed)
: table::>

<a id='f82ed5b1-b364-495d-950f-f906789d3ada'></a>

1. Based on 6% WACC, does not include transmission costs
2. Capacity Factors for Tier 1 sites

<a id='89c536b3-abe8-4dec-b619-d746bd94b2ae'></a>

Source: McKinsey Hydrogen Cost Model

<a id='9fc280f4-9664-4bc2-ae4f-60140841c16c'></a>

McKinsey & Company

<a id='e365d491-807d-4d8f-850b-d2629691ea06'></a>

31

<!-- PAGE BREAK -->

<a id='d93500ac-c342-4768-b8ff-4b27e97d0fcd'></a>

2.1/ Chile´s unparalleled renewable resources in the Atacama and Patagonia makes it the lowest cost place to produce Green Hydrogen in the world

<a id='7c6b0737-8021-47f7-838b-f943aa490501'></a>

Production cost curve for hydrogen by region, Generation and Electrolyzer costs of LCOH, USD / kg H2
<::line chart::
Title: Production cost curve for hydrogen by region
Y-axis: USD / kg H2 (ranging from 0 to 3.0 in increments of 0.5)
X-axis: Year (2020, 2025, 2030, 2035, 2040, 2045, 2050)

Legend:
- Pink line: Central: select domestic application
- Light blue line: South: export
- Dark blue line: North: export + mining applications

Data points:
- Central (pink line):
  - 2025: 2.5
  - 2030: 1.7
  - 2035: 1.4
  - 2040: 1.2
  - 2045: 1.1
  - 2050: 1.0
- South (light blue line):
  - 2025: 1.7
  - 2030: 1.3
  - 2035: 1.1
  - 2040: 1.0
  - 2045: 0.9
  - 2050: 0.8
- North (dark blue line):
  - 2025: 2.0
  - 2030: 1.4
  - 2035: 1.2
  - 2040: 1.1
  - 2045: 1.0
  - 2050: 0.8
::>
Comparison of production costs 2030
Generation and Electrolyzer costs of LCOH
USD / kg H2
<::bar chart::
Title: Comparison of production costs 2030
Y-axis: USD / kg H2
X-axis: Region

Data:
- Chile: 1.3 (with a bracket indicating 1.4)
- Middle East: 1.8
- Australia: 1.7
- China: 2.2
- Europe: 2.6
- US: 2.1
::>

<a id='754fb871-bdb3-41ec-a318-6d1d8c8bd5fb'></a>

Source: McKinsey model, Minister of Energy capacity factor data and PV / Solar profiles

<a id='76e1a3a9-1557-472b-9379-356d28a277a5'></a>

McKinsey & Company

<a id='9c9033a5-344c-46f9-a9a2-1468aeed63be'></a>

32

<!-- PAGE BREAK -->

<a id='59f7feaf-1fe2-4d04-8d4b-17ce9882d9b5'></a>

2.1/ Green hydrogen production cost is projected to drop by 50% within the next 10 years driven by a decrease in electrolyzer costs

<a id='6e18d3b9-2567-4868-b9a3-29717219b2a2'></a>

Cost reduction levers for hydrogen electrolysis connected to dedicated solar PV in Taltal, Chile
USD/kg H₂

<a id='3c89dac2-efce-46a2-b859-ff99fa55a2ea'></a>

<::chart: Waterfall chart showing changes from 2025 to 2035. The chart illustrates a reduction from an initial value of 2.0 in 2025 to a final value of 1.1 in 2035, representing an overall decrease of -46%. The changes are broken down as follows: Power generation costs decrease by 0.2, driven by a steep decline in solar PV CAPEX from ~850 $/kW to ~400 $/kW, and solar PV LCOE in Taltal decreases from 19 to 13 USD/MWh. Electrolyzer CAPEX costs decrease by 0.4, attributed to a sharp 55% decrease in 10 years due to larger global production scale, automation in manufacturing, larger individual system size classes (e.g., going from 2-20 MW today to >100 MW per unit), and decreasing BOS¹ costs. Electrolyzer efficiency shows a change of 0-, with efficiency increasing from 68 to 71% due to technical advancements, such as better catalysts. Other costs decrease by 0.2, especially electrolyzer O&M costs, following a reduction in the cost of parts and learning to operate systems. Footnote: 1. Balance of system::>

<a id='4eac1a11-6d65-429f-ad2f-58588f75555d'></a>

Source: McKinsey Hydrogen Cost Model

<a id='e6693fe3-bb96-44fc-b0a1-e44b778667cd'></a>

McKinsey & Company

<a id='1ebfbcf1-ba8f-4bf4-99d2-5d0f07ba541d'></a>

33

<!-- PAGE BREAK -->

<a id='93004039-8bb2-456b-808f-0c82fc47dad0'></a>

## 2.1/ Different options for solar technology range from fundamental changes to incremental improvements to the system

<a id='c4198fe8-7a19-476b-8b50-039b89c1f243'></a>

option Details to follow: [ ]

<a id='f979c5c9-7da2-4c67-b7ba-0758ff556b7c'></a>

Fundamental shifts on how the system works<::An illustration comparing different energy technologies and tracking methods. The visual content is structured as a list:
- First item: An illustration showing a flat solar photovoltaic (PV) panel on the left and a parabolic trough concentrated solar power (CSP) collector with a sun icon on the right. This visual is associated with the text: PV vs CSP1.
- Second item: An illustration showing two solar panels side-by-side. The left panel has a single curved arrow indicating 1-axis tracking. The right panel has two curved arrows indicating 2-axes tracking. This visual is associated with the text: PV 1-axis vs 2-axes tracking.
- Third item: An illustration of a blue and gray battery, typically used for energy storage. This visual is associated with the text: Battery storage.
: figure::>

<a id='42b9a2ec-0c19-4578-aafa-440ddff09081'></a>

## Incremental improvements to PV technology

*   Manufacturing scale
*   Single vs multi-crystalline Silicon wafers
*   Bifacial modules
*   Perovskite solar cells
*   Professionalization of the industry

<a id='d5f500be-687f-43ac-b014-2728c43c02e7'></a>

Compared to PV technology, CSP represents a fundamental shift on how the system works, leading to significant differences in LCOE. By contrast, bifacial modules provide incremental improvements to PV technology, with a marginal LCOE change that is highly dependent on specific local characteristics, such as albedo (ground material) and labor cost (more complex engineering work is required for project planning and installation)

<a id='7faf6d92-b767-43dc-ab04-ec7b01b36fed'></a>

1. Concentrated Solar Power

<a id='c7a6832f-d2c0-4e7e-9da3-958f3e8f35da'></a>

McKinsey & Company

<a id='e78959dd-5a36-4d03-bcf3-cd04bb17deb6'></a>

34

<!-- PAGE BREAK -->

<a id='3cd0f32b-2831-4b09-b185-d5160a528514'></a>

2.2-2.3/ Economic breakeven will start with domestic applications; exports of green ammonia will ramp up in the second half of this decade, whereas exporting hydrogen and synfuels will happen after 2030 Not exhaustive Preliminary Prioritization matrix for main hydrogen applications² Uncertainty vs Break-even – size of the bubble represents total potential market for 2030 1 GW Electrolyzer Capacity = ~0,1 Mton 5,00 - Mton hydrogen equivalent option Domestic: [x] option International¹: [x] <::chart: Prioritization matrix for main hydrogen applications. The chart plots 'Uncertainty on technological cost evolution' (Low to High on the Y-axis) against 'Estimated breakeven' (2025, 2030, 2035 on the X-axis). The size of the bubble represents the total potential market for 2030. The chart is divided into three waves: Wave 1, Wave 2, and Wave 3.  Wave 1 applications (lower uncertainty, earlier breakeven): - Grey H2 replacement Oil Refinery (Domestic, 0,1 Mton, around 2026-2027) - Ammonia Domestic (Domestic, 0,2 Mton, around 2027-2028) - Long distance buses FCEV (Domestic, 0,4 Mton, around 2028-2029) - Heavy Duty Trucks long distance (Domestic, 1,0 Mton, around 2029-2030) - Medium Duty Truck long distance (Domestic, 0,1 Mton, around 2029-2030) - Ammonia exports (International, 11-23 Mton, around 2029-2030)  Wave 2 applications (mid uncertainty, mid breakeven): - Mining Trucks FCEV (Domestic, 0,8 Mton, around 2028-2029) - Gas blending with H2 (Domestic, 0,2 Mton, around 2030) - SUVs (Domestic, 0,1 Mton, around 2030-2031) - Ammonia for domestic shipping (Domestic, 0,5 Mton, around 2031-2032) - Hydrogen exports (International, 22-34 Mton, around 2030-2031)  Wave 3 applications (higher uncertainty, later breakeven): - Light road transport FCEV (Domestic, high uncertainty, after 2030) - Ammonia Small maritime transport (Domestic, high uncertainty, after 2030) - Small passenger cars FCEV (Domestic, high uncertainty, after 2030) - Power generation and buffering applications most relevant beyond 2035 (Domestic, high uncertainty, after 2035) ::> *   Commercialization of hydrogen applications will take place in three waves: — Wave I: Domestic ramp up and export preparation — Wave II: Capitalization on export markets — Wave III: Leverage scale to expand *   Additional applications (not pictured) can become relevant once the synergies from large scale exports are captured *   Key longer term applications (synfuel and methanol) will bring additional market opportunities in 2035+ *   Industrial head applications considered, but they are small

<a id='0e07a1e4-6032-4565-8bdf-34101acba7ed'></a>

1. Considers domestic demand of ammonia and ammonia used for Fertilizers | 2. Does not consider CO2 Tax | 3: Considers main addressable markets (Low range does not consider China)
Source: Team Analysis; Hydrogen Council report; INE Chile; OCDE

<a id='79d02113-54ae-4190-9bcf-50e21b2a18dd'></a>

McKinsey & Company

<a id='7bac55e3-9056-4d09-87a7-c4178d6794f9'></a>

35

<!-- PAGE BREAK -->

<a id='ed9c14cf-60b8-486d-aba1-d783764fbd41'></a>

## 2.2-2.3 / Market size of the hydrogen industry in Chile

<a id='d0a119b9-0889-4788-81f8-02e4431a7077'></a>

<::Chilean Hydrogen and derivative market projections: 2025-2050 chart::>B USD. The chart displays stacked bars for Domestic Market (gray) and International Market (dark blue) over time, from 2025 to 2050, along with an overall growth trend. A table below shows required GW electrolyzer and RES capacity. Chart Data: - **2025**: Domestic Market: 1, International Market: 0 (Total: 1) - **2030**: Domestic Market: 2, International Market: 3 (Total: 5) - **2035**: Domestic Market: 5, International Market: 11 (Total: 16) - **2040**: Domestic Market: 7, International Market: 16 (Total: 23) - **2045**: Domestic Market: 8, International Market: 19 (Total: 28) - **2050**: Domestic Market: 9, International Market: 24 (Total: 33). The overall growth trend is +12-15% p.a. Table Data: - **Required GW electrolyzer capacity**:   - 2025: 3-5   - 2030: 25   - 2035: 90   - 2040: 130   - 2045: 155   - 2050: 190 - **Required GW RES capacity**:   - 2025: 5-8   - 2030: 40   - 2035: 145   - 2040: 200   - 2045: 250   - 2050: 300::>However, capturing this opportunity requires the **appropriate ramp up of applications:** **Wave I:** Domestic ramp up and export preparation **Wave II:** Capitalize on export markets **Wave III:** Leverage scale to expand *Detailed next*

<a id='48361eb7-4a48-412b-bb74-389c64bb5358'></a>

McKinsey & Company

<a id='4b189134-7a74-40b3-8058-daddfda6a0c5'></a>

36

<!-- PAGE BREAK -->

<a id='07e392d7-bb65-409b-9028-cab7d026818c'></a>

2.2-2.3 / Domestic application anticipation would be focused primarily on grey H2 replacements in oil refinery, grey NH3 replacement in mining / fertilizers and glass blending

<a id='8379644f-aea9-4fac-adc6-d8654f6f3797'></a>

Preliminary
<::table
: chart::>
| | Application | Total Potential Market size¹ - USD B 2050 | Electrolyzer capacity required (GW) | 2020 | 2025 | 2030 | 2035 | 2040 |
|---|---|---|---|---|---|---|---|---|
| Estimated break-even with National H2 Strategy (blue diamond) | | | | | | | | |
| Potential break-even without National H2 strategy (grey diamond) | | | | | | | | |
| Potential ramp-up to achieve 100% (grey triangle) | | | | | | | | |
| 1 | Current H2 replacement Oil refinery | 0.2 (horizontal bar) | 1.8 (oval) | | blue diamond (start of 2025), blue horizontal bar extending to 2030, grey triangle (arrow) | grey diamond (mid-2025), grey horizontal bar extending to 2035 | | |
| 2 | Current NH3 replacement Mining + fertilizers | 0.5 (horizontal bar) | 2.2 (oval) | | blue diamond (start of 2025), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (mid-2030), grey horizontal bar extending to 2035 | | |
| 3 | Mining haul trucks | 1.6 (horizontal bar) | 9.3 (oval) | Pilots starting (+30 trucks) | blue diamond (mid-2025), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (start of 2030), grey horizontal bar extending to 2040 | | |
| 4 | Heavy duty trucks | 2.0 (horizontal bar) | 11 (oval) | Pilots starting (+50 trucks) | blue diamond (mid-2025), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (start of 2030), grey horizontal bar extending to 2040 | | |
| 5 | Coaches / buses | 0.8 (horizontal bar) | 4.5 (oval) | Pilots starting | | blue diamond (start of 2030), blue horizontal bar extending to 2035, grey triangle (arrow) | grey diamond (mid-2030), grey horizontal bar extending to 2040 | | |
| 6 | Gas Blending (up to 20% total residential use) | 0.3 (horizontal bar) | 1.8 (oval) | | blue diamond (start of 2025), blue horizontal bar extending to 2030, grey triangle (arrow) | grey diamond (mid-2025), grey horizontal bar extending to 2035 | | |
| | ~6 USD B (total) | | GW Electrolyzer: (w/ National H2 Strategy) | 3 (oval) | 10 (oval) | 25² (oval) | 40² (oval) | |
<::/table::>

<a id='6c3cc235-4488-4daf-a670-413984efd072'></a>

1. Consider the transition to hydrogen of 100% of the energy demand of each application
2. Including other domestic applications including: airlines, shipping and large passenger cars

<a id='d6b5e6c2-3b62-4e6f-8ce7-bf3e9489499a'></a>

Source: Team analysis; INE, ENAP; DPO

<a id='fb2bcce6-0e8a-4708-aade-4ebb06934c01'></a>

McKinsey & Company

<a id='5d400365-aff6-4f73-86cf-00b06a454bec'></a>

37

<!-- PAGE BREAK -->

<a id='4e7e28ab-b77e-4824-8e91-5ac41a0ab556'></a>

2.2-2.3 / Domestic could account for +3M ton of total hydrogen demand by 2050

<a id='a43c51c7-4df7-4b12-b4de-a016892baf23'></a>

<::Stacked bar chart titled "Hydrogen uptake for different domestic applications". The y-axis represents "Mtons of hydrogen equivalent". The x-axis represents years: 2025, 30, 35, 40, 45, and 2050. The legend indicates the following categories: Oil refinery (lightest blue/purple), Gas blending (lighter blue), Mining trucks (medium blue), Ammonia (darker teal), Buses (darker blue), and Trucks (darkest blue/black). The bars show the hydrogen uptake for each application, stacked for each year.  Year totals are displayed above each bar.  The values for each segment are as follows:  - **2025**: Total 0.3 Mtons. Individual segment values are too small to read. - **2030**: Total 0.5 Mtons. Individual segment values are too small to read. - **2035**: Total 2.0 Mtons. Segments from bottom up: Trucks 0.8, Buses 0.6, Ammonia 0.2, Mining trucks 0.2, Gas blending 0.1, Oil refinery 0.1. - **2040**: Total 2.7 Mtons. Segments from bottom up: Trucks 1.1, Buses 0.8, Ammonia 0.4, Mining trucks 0.2, Gas blending 0.1, Oil refinery 0.1. - **2045**: Total 3.0 Mtons. Segments from bottom up: Trucks 1.1, Buses 0.9, Ammonia 0.4, Mining trucks 0.2, Gas blending 0.2, Oil refinery 0.2. - **2050**: Total 3.2 Mtons. Segments from bottom up: Trucks 1.2, Buses 1.0, Ammonia 0.4, Mining trucks 0.2, Gas blending 0.2, Oil refinery 0.2.: chart::>

<a id='b8a9f7c3-5636-42d4-bbb6-521a615f6714'></a>

<::Hydrogen uptake for different domestic applications% of total consumption: line chart. The y-axis represents "% of total consumption" with major ticks at 0, 25, 50, 75, and 100. The x-axis represents the year, with major ticks at 2025, 30, 35, 40, 45, and 2050. There are six lines representing different applications: Oil refinery, Gas blending, Mining trucks, Ammonia, Buses, and Trucks. Oil refinery (black line) starts around 40% in 2025 and reaches nearly 100% by 2030. Gas blending (dark blue line) starts around 5% in 2025 and slowly rises to about 30% by 2050. Mining trucks (teal line) starts near 0% in 2025, increases significantly from 2030, and reaches nearly 100% by 2037. Ammonia (light blue line) starts around 40% in 2025 and reaches nearly 100% by 2040. Buses (pale blue line) starts near 0% in 2025, increases significantly from 2035, and reaches nearly 100% by 2042. Trucks (light purple line) starts near 0% in 2025, increases significantly from 2030, and reaches nearly 100% by 2037.::>

<a id='ddcb3045-8728-4a6a-9bd3-8c94f87b50f5'></a>

McKinsey & Company

<a id='18b0d104-b084-4fad-91dd-105ea0c92e9e'></a>

38

<!-- PAGE BREAK -->

<a id='d056ddc7-1eb8-462c-b1c8-58faddd83fdb'></a>

2.4/ Factors which produce the largest differences between the results of the business cases

<a id='7fe7994a-cd7b-41a8-a239-bad3dbc7d230'></a>

1 Financing and incentives

Sources of funding to facilitate the launch of feasibility studies, pilots and scaled projects

Incentives structured to support supply and demand development for scaled projects

<a id='e7540125-b4de-47e0-aafc-7604553479d2'></a>

<::A white line icon of a building with columns and a dome, resembling a capitol building, is displayed at the top. Below the icon, a horizontal line separates it from the text. The title "2 Regulation and licensing / permits" is presented, followed by two bullet points: "Long term regulatory structure to diminish uncertainty and minimizes barriers to entry / doing business" and "Acceleration of licensing and permitting processes." : infographic::>

<a id='8611f0b6-2038-43e2-bfea-9ca022c098f6'></a>

<::Outline icon of two people shaking hands, representing partnership.
: figure::>

---

③ Coordination and partnerships

Coordination mechanism to create formalized partners with domestic and international actors to promote industry growth and domestic and international supply chain development

<a id='e70b8598-efe9-45f8-93bb-3ec274d8ae83'></a>

<::icon of pipes
: 4 Infrastructure
Necessary infrastructure to support project development (transmission, ports, refueling stations etc...)::>

<a id='8cc9dcb3-5ae2-489f-a597-7f3e79372b5a'></a>

5 Research & Development

Research and development of technologies for the Chilean context (ex. wind turbines for Patagonian wind profiles and earthquake resistant ammonia production)

<a id='1d272f4d-54e0-46ea-a0b3-416a2a270cf1'></a>

<::An icon of a person wearing a graduation cap is displayed above a horizontal line. Below the line, the number 6 is circled, followed by the text "Skilled Labor". A description below reads: "Ability to attract local talent for construction and production": figure::>

<a id='8f51c5e4-9425-4ecb-9337-d4d12f4409dc'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='7b14af98-f902-4345-b3fa-04fa935cbf5e'></a>

McKinsey & Company

<a id='ee249245-c004-4c7b-a4e9-2888760f207d'></a>

39

<!-- PAGE BREAK -->

<a id='73bff11d-2d98-4092-886f-bb28a9c649e9'></a>

# Chapter 3: Business case for Hydrogen exportation

<a id='f49d9007-cfea-4746-a3ad-3efab2ac62e0'></a>

Chapter content description
*   **Demand projections for key export markets of green hydrogen** by end use application and geography (focus on green hydrogen and green ammonia)
*   **Competitiveness assessment of Chile in key export markets**, including: European Union, Japan, South Korea, China and the United States
*   **Key factors which influence the competitiveness of Chile in these export markets**

Activities included
*   Activity 3.1
*   Activity 3.2

<a id='2a9f6ae4-6c6d-49df-b84a-97a5254f0d8d'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='1e8ffcfc-23ef-466c-b36d-a504b88edd6a'></a>

McKinsey & Company

<a id='af692e54-036e-4d60-a0b4-4492b4f80b37'></a>

40

<!-- PAGE BREAK -->

<a id='39715db8-c744-437b-be84-712c0cde0130'></a>

**3.1 / Ammonia exports:** key potential green ammonia markets for Chile include China, Japan/South Korea, EU, USA and LATAM

<a id='a79802f4-7cab-4cf2-9ea3-987bcb415865'></a>

Total Ammonia consumption 2030 – Mton / year NH3
<::chart: Bar chart showing Total Ammonia Consumption in 2030 (Mton/year NH3). The legend indicates that blue bars represent "Export opportunity for Chile".

**Categories and Values (Mton/year NH3) with associated descriptions:**

*   **China**: 65 (blue bar)
    *   Current consumption of ammonia is served by domestic offer (+95%)
    *   High availability of renewable resources may allow to address its own domestic demand
*   **European Union**: 23 (blue bar)
    *   Net importers of grey ammonia (+25% of total consumption)
    *   New carbon taxes may favor imports of green ammonia
*   **United States**: 18 (blue bar)
    *   Net importers of grey ammonia (+10% of total consumption)
    *   Potential development of domestic market could diminish import needs
*   **Middle East**: 18 (dark bar)
*   **India**: 17 (dark bar)
*   **Russia**: 15 (dark bar)
*   **South America (exc. Chile)**: 3 (blue bar)
    *   Potential attractiveness due to proximity (+75% Brazil and Argentina)
*   **Japan / South Korea**: 3 (blue bar)
    *   Net importers of grey ammonia (+60% of total consumption)
    *   High ambitions for green ammonia transition may require high levels of imports
*   **Rest of the world BAU**: 69 (dark bar)
*   **Total BAU**: 210 (dark bar)
*   **Potential new applications of ammonia**: 40 (dark bar)
*   **Total potencial**: 230-290 (dark bar)
:chart::>


<a id='a8f7291d-ca45-4b27-87f5-d79b613eb3c7'></a>

McKinsey & Company

<a id='6daf8f6c-be40-4ce1-b2a9-46aac783efa7'></a>

41

<!-- PAGE BREAK -->

<a id='86ab2269-a3e6-4bf0-87d1-32b429a993ce'></a>

3.1 / **Hydrogen export**: key hydrogen markets for Chile include South Korea, European Union and the United States

<a id='52df15fb-a81c-4731-a4ba-fbab5b270d5d'></a>

## Potential demand for green hydrogen per country
Mton H2 / year; Low and high ranges found in strategic roadmaps

<a id='c942f73a-9268-42fb-a961-132b97f0656a'></a>

**Preliminary**

<a id='93aaa255-0bae-4a5f-ab4d-489ef0aad0b9'></a>

<::image: flag of China::>
• Domestic production capacity may be sufficient to attend the demand for green hydrogen, however, accelerated expansion may require imports
<::bar chart: two bars. The first bar shows a total capacity of 36, with a small bottom portion filled in dark blue. The second bar shows a total capacity of 60, with the bottom portion filled in dark blue representing 40.::>

<a id='f0131064-54e1-42ba-8033-ce07fa285292'></a>

<::visual content: European Union flag. Text: The limited production capacity in the region may boost imports specially by countries as Germany, Netherlands, Belgium, among others. Bar chart showing values for two years. For 2030, a dark blue bar section of 14, with a total height of 20 (indicated by a dashed outline). For 2050, a dark blue bar section of 23, with a total height of 68 (indicated by a dashed outline).: chart::>

<::visual content: United States flag. Text: Even though the country counts on its own natural resources, Chilean hydrogen presents an attractive cost structure able to compete with the local market. Bar chart showing values for two years. For 2030, a dark blue bar section of 14, with a total height of 17 (indicated by a dashed outline). For 2050, a dark blue bar section of 20, with a total height of 63 (indicated by a dashed outline).: chart::>

<a id='a6052fc6-02d9-468c-90a6-2566dad02503'></a>

<::Bar chart showing two categories: 2030 and 2050. For 2030, the total value is 7, with a dark segment showing 2. For 2050, the total value is 27, with a dark segment showing 11.
: chart::>

<a id='2b759aac-6fbd-4897-a88b-11c70717bce4'></a>

Source: China renewable energy outlook 2018; Hydrogen roadmap South Korea 2018; Japan Strategy Energy Plan 2018; Roadmap to a US hydrogen Economy; Perspectives on hydrogen for the APEC region; Hydrogen Council; EU strategic roadmap; The future of Hydrogen IAE;

<a id='72dddb70-a8a3-4c33-8eed-b085631fe02c'></a>

McKinsey & Company

<a id='20ce571e-16ce-41c1-82d3-238feb9321a6'></a>

42

<a id='54b1a2ac-aead-4371-b169-dcde5825cf0b'></a>

<::
option Export opportunity for Chile: [ ]
option Ambitious scenario: [ ]
option Base scenario: [ ]
: figure::>

<a id='f3bb05ac-d0ae-45ff-add6-f480f1a1cf24'></a>

<::logo: [Flags of Japan and South Korea]
[No readable text]
Two rectangular flags are displayed side by side: the Japanese flag with a red circle on a white background, and the South Korean flag featuring a red and blue taegeuk symbol surrounded by four black trigrams on a white background.::>

<a id='8574dcfb-3402-470d-bbfe-ff3bf8459d6c'></a>

* Japan's Energy foresees the procurement of ~300 Ktons in 2030 and 5-10 Mtons in +2050
* S. Korea plans to start importing hydrogen in 2030

<a id='4d2fca77-dcbf-416d-a3a3-74b2bb4b1d44'></a>

<::Bar chart showing two bars. The first bar, labeled "23", corresponds to the year "2030". The second bar, labeled "40", corresponds to the year "2050".
: chart::>

<!-- PAGE BREAK -->

<a id='4bd2d249-4abf-4e00-b576-d6df278ce837'></a>

**3.1 / Export markets have the potential to ramp up starting 2025, provided that long term contracts are brokered with international players**
---


<a id='2d34bce8-f94e-4d16-9820-7a952b7598ac'></a>

Estimated market size for Chilean exports USD B<::chart: Stacked bar chart showing estimated market size for Chilean exports of Ammonia and Hydrogen in USD B from 2025 to 2050, broken down by destination. A legend indicates colors for LATAM (light blue/cyan), USA (very light blue), Japan/Korea (medium blue), China (darker blue), and Europe (darkest blue/black). The chart also includes two rows of summary data above the main bars.Figure Caption: 1 Total of Ammonia + Hydrogen exports.Top Summary Data:  Total¹:  2025: 0.4  2030: 3  2035: 11  2040: 16  2045: 19  2050: 24  GW Electrolyzer:  2025: 2  2030: 15  2035: 65  2040: 90  2045: 110  2050: 135Ammonia exports:  Year | Europe | China | Japan/Korea | USA | LATAM | Total  ---|---|---|---|---|---|---  2025 | 0.5 | | | | | 0.5  2030 | 1 | 1 | | | | 2  2035 | 2 | 1 | 0 | 1 | | 4  2040 | 3 | 1 | 1 | | | 5  2045 | 3 | 1 | 1 | | | 5  2050 | 3 | 1 | 1 | | | 5Hydrogen exports:  Year | Europe | China | Japan/Korea | USA | LATAM | Total  ---|---|---|---|---|---|---  2025 | | | | | | 0  2030 | 0.5 | | | | | 0.5  2035 | 3 | 1 | 2 | 1 | | 7  2040 | 4 | 1 | 4 | 2 | | 11  2045 | 5 | 1 | 5 | 2 | 1 | 14  2050 | 7 | 2 | 7 | 3 | | 19::>1 Total of Ammonia + Hydrogen exports

<a id='8866d189-64e2-416f-a3f8-81eacee0a602'></a>

Source: Team analysis; National hydrogen roadmaps of the respective countries -Total of Ammonia + Hydrogen exports

<a id='cf920b47-1f1d-4ba6-86c0-2e472674c22c'></a>

McKinsey & Company

<a id='4c03cfce-273d-4e9b-a4eb-cc4924a6ce92'></a>

43

<!-- PAGE BREAK -->

<a id='0e8076b9-0b78-442c-95e9-54d920bc1f16'></a>

## 3.2 / Factor that will influence Chilean export competitiveness
---

<a id='c4c9c056-b314-4d3d-a7c7-ef0411a329e2'></a>

1
Hydrogen roadmaps and decarbonization
targets of main net importer markets of
green hydrogen and derivatives

<a id='b13b3c3d-a0a1-4e6b-963b-11bc2e8dd396'></a>

2 Chile's production and transportation costs vs potential competitors to serve those markets

<a id='f94aa9ce-2cf2-4176-85c6-655d8fee3ff3'></a>

3 Acceleration of export production capacity development to capture potential market share

<a id='7f7c1cb4-d93a-4c28-8f56-b67dc484ccfd'></a>

Chile's strategic position will depend on the offset between lower production costs and higher transpiration costs

<a id='0da8a396-caea-436c-8dcb-8d82815f331e'></a>

<::Production costs (solid light blue square), Transportation costs (dotted square outline): figure::>

<a id='65fd53e7-d858-48cb-bf65-38650c2cceaa'></a>

<::Figure: Bar chart comparing 'Cost to market' for Chile and potential competitors. The chart features two light blue bars on a dark background. Above the left bar, which represents Chile, is the flag of Chile. To the right of the flag, above the right bar, is the label "Potential competitors". Both bars have a dashed line indicating a potential higher cost level above their current filled level. The left bar (Chile) shows a lower 'Cost to market' than the right bar (Potential competitors). Two text annotations with arrows explain factors for Chile's cost: an upward arrow points to the dashed upper part of the left bar, accompanied by the text "Relatively uncertain transportation costs could diminish competitiveness". A downward arrow points to the filled lower part of the left bar, accompanied by the text "Considerable lower production costs make Chile more competitive". The x-axis is labeled "Cost to market".:chart::>

<a id='94a0c2d3-c9cf-43ab-9907-a941d1af5575'></a>

McKinsey & Company

<a id='4b12820c-9e2e-47eb-aee5-6e5b3682048f'></a>

44

<!-- PAGE BREAK -->

<a id='85752038-4149-4285-8b8e-ad9373d3c489'></a>

## Chapter 4: hydrogen industry development targets and roadmap

<a id='b4047573-2d62-48d9-b491-e8adf010a69a'></a>

Chapter content description

*   Hydrogen industry targets for National Green Hydrogen Strategy
*   Roadmap for domestic application development in Chile

<a id='0a3181c1-c7a2-4d0c-a639-13f6cea8aa08'></a>

Activities included

- Activity 4.1

<a id='9eed03c7-3b4d-4421-926c-be6e7cd2ebe5'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='91a50938-5b1e-44b7-b58b-967ec3dec65d'></a>

McKinsey & Company

<a id='bbb80fa3-a206-47ef-97b7-b7275fc94c9e'></a>

45

<!-- PAGE BREAK -->

<a id='be00b771-e756-4c2b-ba1c-4335593b8ab0'></a>

4.1 / We aspire that Chile be among the top 5 producers of green hydrogen worldwide and the top 3 exporters; our target is 5 GW of hydrogen capacity under development by 2025, 25 GW by 2030

<a id='cd2bf30c-1f8e-458f-a63f-5332ac1b4db8'></a>

Hydrogen Roadmap
Aspiration:
Top 5
Global producers
Top 3
Global exporters

Targets: GW of electrolyzer capacity in development
5 GW
by 2025
25 GW
by 2030
<::Hydrogen valleys:
Map of Chile indicating two regions:
Northern hydrogen valley
Southern hydrogen valley
: map::>

<a id='bceb2294-f33c-44f2-9dd6-fe1686284afd'></a>

McKinsey & Company

<a id='ad0efeb9-7c75-4fb0-9859-5164be09ad20'></a>

46

<!-- PAGE BREAK -->

<a id='ab303f51-f216-482a-a73d-067445531a17'></a>

## 4.1 / Capturing this opportunity depends on the short term ramp up of domestic applications
Proposed sequencing and timing of application ramp up
---

<a id='69adfb12-a757-4176-8abd-08ba728f6c8c'></a>

Sequence of steps

Detailed next

Wave I: 2025
Domestic ramp up and export
preparation
3-5¹ GWs

Kick start hydrogen industry with large
domestic applications with earliest
economic breakeven:
* Grey H2 replacement in Oil
Refinery application
* Grey ammonia replacement
* Gas blending
* Pilots for mining Haul Trucks and
Heavy Duty Trucks

Build knowledge, scale, and
infrastructure to move into export
opportunities (primarily Green Ammonia)

1. 3 GW for domestic applications and 2 GW additional based on accelerated export opportunities

<a id='7ec11abe-903a-43db-8d74-b4476c7a6e10'></a>

Wave II: 2030

<a id='df3c7922-a232-4e80-b661-3928be6ebfa9'></a>

Capitalize on export markets

25 GWs

<a id='c0f945ea-5bb4-472b-9a64-e2c6e6af8012'></a>

Leverage domestic base to aggressively scale into a relevant player in the most attractive export markets:

First, Green Ammonia export market (principally: Latam, Europe, US and China)

<a id='af10794f-1484-49a5-b634-7ced6ec5afc1'></a>

Second, Green Hydrogen export
market (principally: Europe, Japan /
South Korea, maybe US and China)

<a id='bfeaf824-05fb-427e-8baa-7fe8d643b7d0'></a>

Wave III: 2035+
Leverage scale to expand
90+ GWs

<a id='9453ee20-adef-4853-8ecc-e23d80a9e18b'></a>

- Synergies and economies of scale enable expansion into additional domestic applications
- Scale up export to other markets to become a significant supplier of world energy consumption
- Capture opportunities in future technologies and applications of Green Hydrogen and derivatives as they become economical:

<a id='6b4c7d5d-aebe-426a-8f50-922bf0604830'></a>

- Synfuel applications (including Jetfuel)
- Ammonia for shipping

<a id='e04d6f60-2967-491a-90f4-991b7b55fa5b'></a>

1. 3 GW for domestic applications and 2 GW additional based on accelerated export opportunities

<a id='5683ec33-7522-43db-8979-0193985b5e9e'></a>

Source: McKinsey analysis

<a id='a3dc54da-25ac-4e27-afab-5c4b8fdc67a6'></a>

McKinsey & Company

<a id='7802bdb7-5bff-4325-83f1-528f486fda0c'></a>

47

<!-- PAGE BREAK -->

<a id='9583fb0e-5568-4cf7-9232-108ca01536f1'></a>

**4.1 / Optimal sequence and ramp up timeline of applications, corresponding infrastructure and skilled jobs required**
Key milestone for the Chilean hydrogen strategy
---
Pilot and infrastructure launch
Application and infrastructure ramp up

<a id='06612873-497c-4542-b16e-da20fcd1f4cc'></a>

<::chart::>
| | Preparation: Today - 2025 | Capitalize exports: 2025 - 2030 | Scale up and expansion : 2030 - onwards | | |
|---|---|---|---|---|---|
| | Today | 2025 | 2030 | 2035 | 2040 |
| **Production** | | | | | |
| Electrolyzer capacity (GW) | | 3 - 5 | 25 | 90 | 130 |
| **Application uptake** | | | | | |
| **Domestic** | | | | | |
| H2 replac. (oil refinery) | Substitution of domestic uses | | Substitution of H2 | | |
| NH3 replacement | Substitutions of exports | | Substitution of grey NH3 | | |
| Mining Haul trucks | Initial bigger scale pilots | | | +80% fleet renovation | |
| Heavy duty trucks | Initial bigger scale pilots | | | +80% fleet renovation | |
| Coaches / Buses | | Initial bigger scale pilots | | | +80% fleet renovation |
| Gas Blending | | | | +15% blending | |
| **Exports** | | | | | |
| NH3 exports | Bilateral partnership agreements | Initial exports | | +80% potential captured | |
| H2 exports | Bilateral partnership agreements | | Initial exports | | +80% potential captured |
| **Impact** | | | | | |
| Killed jobs required - Construction and industry operation | | 30 k | 145 k | +400 k | +400 k |
::>

<a id='f96c8a4d-2137-43f5-ba64-dc6eeb4f2089'></a>

1. Includes investment in energy generation, electrolyzer, transmission and compression, transportation, liquefaction and refueling facilities
Source: DPO; TCO Model; team Analysis

<a id='7b199d76-4829-44eb-9dbf-0062eb4f9e27'></a>

McKinsey & Company

<a id='cfa01034-668f-4bf7-909e-be0744f69b96'></a>

48

<!-- PAGE BREAK -->

<a id='95a80f93-df9d-4c3c-9944-8049b5d67f63'></a>

Chapter 5: relevant stakeholders for the hydrogen industry

<a id='7b996e0e-2fc3-4cb0-9716-cba272624a09'></a>

Chapter content description

* Map of relevant stakeholders (private and public, domestic and international) who could have an important role in the development of a Chilean hydrogen ecosystem
* Identify enabling factors which could facilitate the engagement of these stakeholder groups in Chile's developing hydrogen ecosystem

<a id='d0db4750-f1cc-4b0e-8db1-41043de1325d'></a>

Activities
included

* Activity 5.1
* Activity 5.2
* Activity 5.3
* Activity 5.4

<a id='1b1f991a-dca0-48e9-a1a2-b2b2c320e797'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='db0282cf-77f0-43a1-b17f-40eb041f6ffc'></a>

McKinsey & Company

<a id='f98cf0b2-22b9-43c5-a903-a661f18b3e1a'></a>

49

<!-- PAGE BREAK -->

<a id='097054da-e55e-4109-86b1-b6e32e995c28'></a>

5.1 & 5.2/ The development of the Chilean hydrogen
ecosystem will depend on 6 key groups of
stakeholders

<a id='20c48148-003d-4c68-a235-b00b0240ae4a'></a>

**Off-taker group**
Stakeholders that will diminish the risks of
the projects guaranteeing volume demand;
could be also co-investors

<a id='51473a60-616d-4757-9def-a120218f1005'></a>

**Ecosystem builders**Responsible for creating the enabling conditions for the hydrogen market<::A circular diagram divided into six colored segments, numbered 1 through 6 clockwise around its perimeter. Each numbered segment corresponds to one of the stakeholder descriptions surrounding the circle.: diagram::>**Financing investors**Funds or banks willing to invest in the energy market in Latin America**Hydrogen production**Responsible for technology and infrastructure development for hydrogen production, transportation and storage**Demand technology developers**Technology developers for different hydrogen applications – demand side (e.g. transportation)**Electricity generation (provider or developer)**Current or new energy generation players that will dedicate resources to hydrogen projects

<a id='885aa4e3-1a9e-4adc-b8da-2fed18a2cb9e'></a>

# Key considerations

*   The coordinated actions of different stakeholder groups will allow to accelerate the growth of the hydrogen market by:
    *   Facilitating the creation of the enabling environment for the market to operate
    *   Rapidly acquiring and incorporating the hydrogen technology development to boost demand
    *   Coordinating financing, energy generation and production promoting the development of new projects

<a id='5067d500-a245-4f5e-8f7c-418a4f567d0c'></a>

McKinsey & Company

<a id='e22a53f3-2458-4bc0-99a5-694c639fbabb'></a>

50

<!-- PAGE BREAK -->

<a id='2fe3fb25-8454-4e5e-9de5-d34cb6a71e92'></a>

**5.1 & 5.2/ Stakeholder groups (1/3)**

<a id='a72061fc-cc54-422d-a3fe-810373871594'></a>

**Not exhaustive**

<a id='9e9f8d10-85b2-485f-9991-5053ba0e6362'></a>

<::transcription of the content: table::>
| Group | Role(s) | Organizations |
|:---|:---|:---|
| | | XX Possible champions |
| Potential off-takers 1 | Off-takers of green hydrogen production for oil refinery | ENAP; Linde |
| | Off-takers of green hydrogen for mining trucks | Codelco, BHP, Anglo-American, Teck, Antofagasta Minerals, SQM, Barrick gold |
| | Off-takers of green hydrogen for inter-urban buses | Turbus, Pullman Bus |
| | Off-takers of green ammonia for explosives | ENAEX |
| | Off-takers of green hydrogen for gas blending | Metrogas, GasValpo, GasSur |
| | Off-takers of green hydrogen and green ammonia exports | Yara, Mosaic; Linde; ThyssenKrupp, APM Maersk, Air Liquid (Airgas), Casale |
<::/transcription of the content: table::>

<a id='3ff6e1b9-4623-4e36-80b3-3ce306d28eb8'></a>

Financing
and investors

2

<a id='7a8ba012-d862-4704-83ae-1ea6b3f5afd1'></a>

Funding for consortiums projects - international cooperation agencies

<a id='3a998bf2-49ba-42a3-8553-ad493d934f09'></a>

IDB, World Bank, Development Bank of Japan, Green
Climate Fund, KfW, CAF, CIF

<a id='798c360f-4708-483e-b2a4-8434fac03401'></a>

Funding for consortiums projects – Institutional investors

Pension funds, wealth management, etc.

<a id='0cc28866-ebd5-4c50-ad26-61791c1c90ea'></a>

McKinsey & Company

<a id='3f139c14-b472-4380-9665-cdcca7da0b26'></a>

51

<!-- PAGE BREAK -->

<a id='aa52e492-55e9-4529-acae-19460a5b84cb'></a>

5.1 & 5.2/ Stakeholder groups (2/3)

<a id='f5c7869a-ddb9-4d04-94de-165e12853cee'></a>

<table id="51-1">
<tr><td id="51-2"></td><td id="51-3" colspan="2">Not exhaustive</td></tr>
<tr><td id="51-4">Group</td><td id="51-5">Role(s)</td><td id="51-6">Organizations xx Possible champions</td></tr>
<tr><td id="51-7" rowspan="4">Technology development (number 3 in circle)</td><td id="51-8">Production of FCEVs and hydrogen technology</td><td id="51-9">Hyunday motor company, Toyota, BMW; LIEBHERR; Alset, hydrogenics, Audi, Faurencia, Daimler</td></tr>
<tr><td id="51-a">Production of hydrogen driven mining truck vehicles</td><td id="51-b">Ballard; Caterpillar; Komatsu</td></tr>
<tr><td id="51-c">Development of hydrogen aircrafts</td><td id="51-d">Boeing, GE aviation, Airbus, Safran</td></tr>
<tr><td id="51-e">Development of ammonia ships &amp; vessels</td><td id="51-f">Maersk, Ultramar</td></tr>
<tr><td id="51-g" rowspan="4">Energy generation (number 4 in circle)</td><td id="51-h">Renewable energy generation</td><td id="51-i">Enel, Colbún, AES Gener; Engie, Repsol, EDPR, Statkraft, RWE, Orsted</td></tr>
<tr><td id="51-j">Wind energy generation infrastructure</td><td id="51-k">Vestas, Orsted, Nordex, Siemens, GE</td></tr>
<tr><td id="51-l">Solar energy generation infrastructure</td><td id="51-m">JinkoSolar, SunPower, Hanwha Q Cells</td></tr>
<tr><td id="51-n">Infrastructure required for energy transmission</td><td id="51-o">Transelec</td></tr>
<tr><td id="51-p" rowspan="4">Hydrogen production (number 5 in a circle)</td><td id="51-q">Production of hydrogen technology</td><td id="51-r">Siemens, Cummins, Nel Hydrogen, Hydrogenics, ITM Power</td></tr>
<tr><td id="51-s">Hydrogen production, transport and storage</td><td id="51-t">Total, COPEC group, Repsol, Engie, Air liquid, BP, Nel Hydrogen, Shell, Vopak, ITM power</td></tr>
<tr><td id="51-u">Production of green ammonia and blue fertilizers</td><td id="51-v">Yara, Mosaic, Air Liquid (Airgas), BASF</td></tr>
<tr><td id="51-w">Production of blue methanol</td><td id="51-x">Methanex</td></tr>
</table>

<a id='32184923-66c2-4dae-b549-895d95287519'></a>

McKinsey & Company

<a id='0ad55721-43b2-4661-9485-5f5051a3eff9'></a>

52

<!-- PAGE BREAK -->

<a id='ec9dbce2-f1b0-4e52-9bd8-fcca27738c90'></a>

5.1 & 5.2/ Stakeholder groups (3/3)

<a id='dabdca90-7ea6-4127-97ce-61e75d642635'></a>

Not exhaustive

<a id='517b08a4-4b77-4ab5-965c-49e1371748c2'></a>

<table id="52-1">
<tr><td id="52-2">Group</td><td id="52-3">Role(s)</td><td id="52-4">Organizations XX Possible champions</td></tr>
<tr><td id="52-5" rowspan="11">Ecosystem builder</td><td id="52-6">Coordination and orchestration of different actors - public and private sector Supporting the design of the regulatory framework</td><td id="52-7">Ministry of Energy</td></tr>
<tr><td id="52-8">Facilitating the establishment of international cooperation agreements</td><td id="52-9">Ministry of Foreign Affairs; Embassies at target countries including: Japan, South Korea, China, EU and USA</td></tr>
<tr><td id="52-a">Development of funding lines for initial pilots and feasibility studies via CORFO and promoting the country as an investment destination</td><td id="52-b">Ministry of Economy, Development and Tourism</td></tr>
<tr><td id="52-c">Development of infrastructure studies and coordination with private organizations for infrastructure development</td><td id="52-d">Ministry of public works</td></tr>
<tr><td id="52-e">Promotion of the adoption of green ammonia and low-carbon fertilizers produced with hydrogen</td><td id="52-f">Ministry of agriculture</td></tr>
<tr><td id="52-g">Establishment of environmental requirements and processes for the development of hydrogen projects</td><td id="52-h">Ministry of environment</td></tr>
<tr><td id="52-i">Promoting and coordinating together with universities the research on hydrogen and derivatives</td><td id="52-j">Ministry of Education, Ministry of Science, Technology, Knowledge and Innovation</td></tr>
<tr><td id="52-k">Design the permits for the operation of hydrogen pilots and coordinate the work with companies</td><td id="52-l">Ministry of mining, Ministry of transportation</td></tr>
<tr><td id="52-m">Promotion of research and education on green hydrogen</td><td id="52-n">U. de Chile, PUC, U. de Concepción, U. de Magallanes, U. de Antofagasta, UTFSM</td></tr>
<tr><td id="52-o">International research and development partners</td><td id="52-p">Fraunhofer, Hydrogen Energy Research Center</td></tr>
<tr><td id="52-q">Representation of the private sector and coordination with public entities</td><td id="52-r">Hydrogen council, H2 Chile, Hydrogen Europe, Ammonia Energy Association</td></tr>
</table>

<a id='be5911a6-e864-4413-8791-c7ff7c4e43e8'></a>

McKinsey & Company

<a id='816d6fa1-64f2-4054-b169-5096f37a0f49'></a>

53

<!-- PAGE BREAK -->

<a id='3ce4f6fe-e18f-4bca-aa36-87adde75839a'></a>

5.3/ Conditions which favor the participation of new actors and potential impacts

<a id='794f0073-6761-4843-87ff-37eb4529979e'></a>

# Conditions which favor new actor participation

## Aspiration, roadmap and strategic priorities
Transparent aspiration and roadmap to show government support for green hydrogen industry development, defined strategic priorities to enable companies to identify and capitalize on strategically aligned opportunities

## Regulation & licensing / permitting
Establishing stable regulatory frameworks which support long term investment and development, are easy to understand (particularly for international players) and have a clear point of contact to field questions and doubts

# Potential impact of new actor participation

## Development of consortiums (supply & demand)
Consortium launch for domestic and international applications (and most likely by both domestic and international players), providing both supply, demand and financing requirements for hydrogen industry launch

## Attraction of international financing
The establishment of consortiums (and in particular, the involvement of international actors) will facilitate the attraction of international financers (ex. national banks may become more interested if national companies are taking part in the consortium or if consortium actors have pre-existing relationships with international financers)

<a id='c98ea765-669e-4fcf-96b3-d48234a269c5'></a>

**Effective coordination**
Creating effective communication and coordination through the establishment of specific task forces (responsible for specific targets) and governance structures (responsible for the overall advancement of the roadmap)

**Reduced costs through synergies**
Increased coordination and partnership building will create cost reducing synergies, particularly in infrastructure, which will accelerate green hydrogen industry development

<a id='69a2f5cf-26aa-494b-b58b-4fe021c9b1c6'></a>

McKinsey & Company

<a id='5efbcbe1-c01c-408a-b2e4-268f59c7c5af'></a>

54

<!-- PAGE BREAK -->

<a id='e814edcc-8b11-4ad3-ac36-6113bfa5f408'></a>

# 5.4/ Workshop 1: Private
Actors
Workshop for private actors
---


<a id='fc21ab0f-b605-4a04-80f5-a287a50ebbb6'></a>

# Objectives

Review Chile's National Green Hydrogen Strategy and clarify questions

<a id='f7113939-b7d0-4a3a-92df-017b5e5e8656'></a>

Discuss the principal opportunities, barriers and
demand offtake sources for the establishment of
successful projects in Chile

<a id='9da72510-c24f-4438-a769-3b1939007631'></a>

Prioritize these opportunities, barriers and demand off-take sources for further development by the Ministry of Energy

<a id='26121ee9-2e1b-4ab7-9d43-2c81bced4ed9'></a>

Gain visibility on the immediate next steps for the hydrogen industry in Chile

<a id='d2ef78ab-56a5-4a90-95ac-ce42227bb1ed'></a>

# Agenda

1 Introduction 10:00 - 10:05
2 Review Chile's National Green Hydrogen Strategy 10:05 - 10:35
3 Q&A on national strategy 10:35 - 11:00
4 Small group breakout: building a consortium 11:00 - 11:40
5 What's next? 11:40 - 12:00

<a id='2e741287-cb12-40cd-b577-09bf42a730ea'></a>

McKinsey & Company

<a id='02ca5437-09bc-4c5f-aa57-e4e3c588050b'></a>

55

<!-- PAGE BREAK -->

<a id='e42a466e-0f46-4869-bdca-fbedc46b0704'></a>

5.4/ Workshop 1: National Strategy for Hydrogen Breakout group discussion

<a id='16bb89ba-65bc-4563-8662-68d2d82411e3'></a>

<::logo: [Unknown]  A simple line-art icon of a person's head and shoulders with a question mark inside the head, in dark blue.::>

<a id='e6105c47-0729-4e67-a52c-931bf74e88de'></a>

Breakout group assignments

<a id='a5365235-56cd-4854-abd3-7bb180f9a130'></a>

**Consortium A: Ammonia export**
* H2 Chile, Generadoras, Engie, AME, Mitsui, Sumitomo, GasValpo, RWE, Austrian Solar, Siemens, Air Products
* Facilitator: Xavier Costantini; Note taker: Daniela Hermosilla

<a id='ef4da452-0214-4587-bd29-3a01db702a69'></a>

Consortium B: Mining sector
* UTFSM, H2 Chile, Cummins, CAP, COPEC, Transelec, Pacific Hydro, TCI GECOMP, ENAEX
* Facilitator: Clemens Muller-Falcke; Note taker: María José Lambert

<a id='3c82265d-11e4-431e-be64-13765ae7a659'></a>

**Consortium C:** Domestic applications (natural gas, logistics, oil refinery)
*   PUC, ACERA, Walmart, Metrogas, COPEC, Lipigas, GasValpo, ENAP, CCU
*   Facilitator: Sarah Toupal; Note taker: Benjamín Maluenda

<a id='ff06802c-5d19-49ac-a915-ca7815fad380'></a>

# Discussion questions

* Do you believe in the hydrogen opportunity for your consortium (in what timeline?)
* What are the barriers that stand in the way? How can they be overcome?
* What is required to secure demand offtake for your consortium?

<a id='23d07e21-6376-4aba-8ac3-fbc6b04ae3a8'></a>

McKinsey & Company

<a id='660b7a0d-827c-4be0-92ae-40242f31b923'></a>

56

<!-- PAGE BREAK -->

<a id='5232ab39-80f1-48f7-840d-f6776268cd72'></a>

Workshop 2: Public Actors

<a id='8bb07f6a-1743-4f4a-af71-422015e89c23'></a>

## Objectives

Introduce Chile's National Green Hydrogen Strategy and clarify questions

<a id='9286f4ea-b482-45cf-8696-c45f7e00f54c'></a>

Discuss how hydrogen can help support the goals of each government area and what challenges exist to the successful implementation of the strategy

<a id='85beee4b-2dd9-46b0-b826-aa75df519648'></a>

Gain visibility on the immediate next steps for the hydrogen industry in Chile

<a id='4144b4f2-462c-4df3-af06-4dd6728fe12a'></a>

Agenda

1. Introduction 9:00 – 9:10
2. Review Chile’s National Green Hydrogen Strategy 9:10 – 9:40
3. Q&A on national strategy 9:40 – 10:20
4. Small group breakout: opportunities and barriers 10:20 – 10:50
5. What’s next? 10:50 – 11:00

<a id='b87a9807-057c-444a-b50e-ae0d41983bd8'></a>

McKinsey & Company

<a id='fde1d0f1-1e5a-4b8f-9901-d703a5ffd0e1'></a>

57

<!-- PAGE BREAK -->

<a id='57969c74-343c-4b6d-9984-b16c028d11bd'></a>

Breakout group discussion

<a id='2773e336-3d8a-428e-8a52-84f4094f7616'></a>

<::Gear icon::>

**Dynamic**
Divide into small groups

<a id='0f6e385c-241c-4658-95ee-84f2846afc1a'></a>

**Break out (25 mins)**
* Discuss and answer questions, supported by facilitators

<a id='d29c72e7-a779-4b40-99c4-dd98c80ce6cb'></a>

**Break out wrap up (5 mins)**
* Facilitators present results from each breakout group

<a id='69e8dbab-3705-4c69-a98a-e293ed1dfa95'></a>

?
Discussion questions
What opportunities does
hydrogen offer to your area /
institution (how can hydrogen
support your goals)?

<a id='06a7cf3a-13d0-4401-b56e-ddb197182f7d'></a>

In thinking about your area, what
are the principal challenges you
see in launching the hydrogen
industry in Chile?

<a id='bc65a764-4923-4a39-a4e6-8395b02df23e'></a>

McKinsey & Company

<a id='6321b386-3eb8-4159-bfb5-2d7bd6be69f4'></a>

58

<!-- PAGE BREAK -->

<a id='5e9ae3f9-6868-4262-8355-9f76c22d6130'></a>

**Proposed template to fill with your teams:** articulate the opportunities and challenges you see for your department across our eight domains for work
Thinking beyond the high level actions outlined in the national strategy...
---

<a id='9d5a67a5-233e-4b22-ba56-2dd8680819c8'></a>

Name:

Department:

<::transcription of the content
1 Strategy and targets
2 Regulation and licensing / permits
3 Coordination and partnerships
4 Value chain
: figure::>

<a id='12ddae15-99aa-451e-939a-ad9a27ef4776'></a>

<::Numbered list of four items, each with a circled number and a label, presented horizontally:
5 Financing and incentives
6 Infrastructure
7 Research & Development
8 Skilled Labor
: list::>

<a id='1b69435d-6ec6-4008-97fc-7ecf7c96f366'></a>

McKinsey & Company

<a id='3c2ac134-2f35-4ed8-b79e-3f54357f0911'></a>

59

<!-- PAGE BREAK -->

<a id='1a717e03-4900-4f16-bca3-47943deb966b'></a>

Chapter 6: government role in hydrogen industry development

<a id='6118be81-dbe8-43be-bcc8-ee6239b8b568'></a>

Chapter content description

*   **Domains of work** required to support and accelerate the development of the hydrogen industry in Chile (both demand and supply) and definition of key design principals
*   **List of actions taken by international governments** to implement the domain of work according to the key design principal
*   **Recommendation of immediate next steps** for government action by domain to accelerate and successful implement the hydrogen industry roadmap

<a id='272d0da8-0ee8-4235-9efe-9999c4a836f4'></a>

Activities
included

* Activity 6.1
* Activity 6.2
* Activity 6.3
* Activity 6.4

<a id='9d8dfff9-3c74-4ff9-ac20-c793e329d048'></a>

1. End use applications prioritized based on market potential and impact on strategic roadmap and do not represent an exhaustive list. Some end use applications such as 'energy storage' were included in the original scope of work but deprioritized in favor of replacement of grey hydrogen with green hydrogen, an end use application with the potential to reach economic break even in the short term.

<a id='be982858-4ee3-4a60-abcc-608b3a9fcfd0'></a>

McKinsey & Company

<a id='eea37b77-e92f-4bea-a07b-4d3a4e42b017'></a>

60

<!-- PAGE BREAK -->

<a id='18613d49-e123-4e36-aa0c-aaad08ae7cc6'></a>

6.1-6.4/ The state will support the development of the industry taking action in 8 domains

<a id='60f02596-d705-4d7a-80f5-e59884bf975b'></a>

Not exhaustive

<::Icon of a line graph with an upward trend and a person standing next to it, indicating strategy and targets: figure::> --- Enabling environment

1 Strategy and targets
Establish a clear vision with targets, strategy, and action plan.
Communicate the strategy and play an active role in mobilizing private and public actors in Chile and beyond.

<::Icon of a building with columns, resembling a government building or courthouse, representing regulation and licensing: figure::>

2 Regulation and licensing / permits
Establish a long term regulatory structure which diminishes uncertainty and minimizes barriers to entry / doing business
Accelerates and streamline licensing and permitting processes

<::Icon of two people holding hands, symbolizing coordination and partnerships: figure::>

3 Coordination and partnerships
Coordinate and establish formal partnerships with domestic and international actors to promote industry growth and domestic and international supply chain development

<::Icon of a chain link, representing the value chain: figure::>

4 Value chain
Maximize value creation and economic development in Chile identifying where the opportunities are for domestic industry along the value chain and putting the right enablers in place

<::Icon of stacked coins and a dollar sign, indicating financing and incentives: figure::>

5 Financing and incentives
Provide sources of funding directly and facilitate access to inexpensive capital
Deployment incentives (production and demand)

<::Icon of connected pipes, symbolizing infrastructure: figure::>

6 Infrastructure
Promote infrastructure developments via PPPs and collaboration among actors to capture infrastructure synergies

<::Icon of a magnifying glass over a gear, representing research and development: figure::>

7 Research & Development
Promote research projects on hydrogen technologies both nationally and with international partners

<::Icon of a person wearing a graduation cap, signifying skilled labor: figure::>

8 Skilled Labor
Develop local talent and skills required for H2 production, refueling, storage, etc.

<a id='0bcd82d4-4795-431d-b429-f0b60a277cdf'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='3087a0cf-fa48-410c-a6a4-8eb8a9ecfed1'></a>

McKinsey & Company

<a id='52a155c6-d475-4a37-8aea-188e58f75cd7'></a>

61

<!-- PAGE BREAK -->

<a id='84626d36-5e72-4656-826c-99bd7e6f858c'></a>

**6.1-6.4/ Enabling actions (1/4)**

<a id='0a8578ac-15cc-4c4a-82eb-4e7a6ab52d99'></a>

Not exhaustive

<a id='f0f9efef-634a-4b81-a890-2812f7c14f71'></a>

Not exhaustive
<table id="61-1">
<tr><td id="61-2">Domain</td><td id="61-3">Key design principles</td><td id="61-4">Examples of actions seen in other places</td></tr>
<tr><td id="61-5">Vision &amp; targets</td><td id="61-6">Set clear ambition and direction Create strategy, clear targets and an action plan to support ambition Actively mobilize public and private actors to realize defined strategy (in Chile an internationally) Communicate the benefits of the plan to the society in general</td><td id="61-7">Define national aspiration backed by strategy, targets and action plan, including priorities for industry development and the role of the government and industry actors Mobilize public and private actors to capture strategic opportunities aligned with the aspiration (ex. developing off taker markets, facilitating international financing etc...) Understand the full economic and social impact of the Hydrogen strategy (both supply and demand side) Create the socialization and engagement strategy for the society in general</td></tr>
<tr><td id="61-8">Regulation</td><td id="61-9">Diminish the uncertainty to invest in new projects Facilitate market access Establish safety standards Lay down environmental requirements</td><td id="61-a">Formulate the regulatory framework and protocols for safe production, storage and transportation of hydrogen Establish the rules for grid integration and remuneration for energy production and grid stabilization Create a certification scheme or guarantee of origin to recognize greener supply chains that use green hydrogen</td></tr>
<tr><td id="61-b">Licenses/ permits</td><td id="61-c">Establish clear requirements Design transparent and fast processes Reduce bureaucracy</td><td id="61-d">Establish clear and transparent rules and processes for license granting for H2 projects (plants, refueling stations, storage, etc.) Design a streamlined and transparent application process with clear steps and one only central point of contact Facilitate licenses to access to water sources</td></tr>
</table>

<a id='ff627e3e-5650-4a79-ace0-03f64184cdb3'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='a73c2b36-a84d-4049-b7be-4f136f093e15'></a>

McKinsey & Company

<a id='e2e0810e-2ed6-4cf2-b285-01dba62e2623'></a>

62

<!-- PAGE BREAK -->

<a id='41574577-3ecb-47b3-b009-cd2444948cf2'></a>

6.1-6.4/ Enabling actions (2/4)

<a id='0df7b88d-eb76-4484-9d6d-c56b85fdda12'></a>

Not exhaustive

<a id='3ff9bab4-5e7f-4992-ad03-18541444d3cd'></a>

Not exhaustive

<a id='46348a87-33c7-4c55-b22d-b0142716a476'></a>

<table id="62-1">
<tr><td id="62-2">Domain</td><td id="62-3">Key design principles</td><td id="62-4">Examples of actions seen in other places</td></tr>
<tr><td id="62-5">3 Coordination with local actors</td><td id="62-6">Orchestrate the efforts of different actors Capture potential synergies between actions Balance H2 supply and demand growth</td><td id="62-7">Create a task force to lead the implementation of the strategy and the orchestration with the different sectors Coordinate the procurement activities of industry actors to promote bulk purchases of different technologies (e.g. buses, HDT)</td></tr>
<tr><td id="62-8">Partnerships with technology providers and investors</td><td id="62-9">Establish partnerships with equipment providers to attract and incorporate new technologies</td><td id="62-a">Establish partnership with PV / Wind energy developers and electrolyzer producers to acquire equipment through bulk / long term contracts, including the attraction of production or assembly lines in Chile Establish consortiums with national and international ammonia and fertilizers producers to attract investments (e.g. mosaic, yara) Establish partnerships with technology producers (e.g. hyundai, caterpillar) to support the technology development and attract early pilots to the country</td></tr>
<tr><td id="62-b">Country to country partnerships</td><td id="62-c">Facilitate market access for exports / imports</td><td id="62-d">Establish free trade agreements and country-to-country collaboration partnerships to facilitate imports / exports of technology and products</td></tr>
<tr><td id="62-e">4 Value chain development</td><td id="62-f">Identify strategic opportunities for economic development in the value chain (upstream and downstream) Create mechanisms which support local value chain development</td><td id="62-g">Map green hydrogen value chain activities, both upstream and downstream, prioritizing opportunities based on attractiveness (e.g. size and value-added) and fit with local capabilities and advantages Develop a &quot;Zona de franca&quot;: North &amp; South to attract manufacturing investment and develop domestically value adding activities of the supply chain</td></tr>
</table>

<a id='9ab92451-0b4e-4914-b26f-232ae80ded5f'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='185d4d62-1659-4189-bb3a-5cf14aee12e1'></a>

McKinsey & Company

<a id='d916ebd6-05aa-4d26-90b0-011946a882de'></a>

63

<!-- PAGE BREAK -->

<a id='c4561824-61b9-49fc-90d4-06bccf86479e'></a>

6.1-6.4/ Enabling actions (3/4)

<a id='5fe6e1aa-569f-41cb-ae84-d2d5cb8f9f33'></a>

Not exhaustive

<a id='ebc79647-e8d6-4438-899a-c30871288fba'></a>

Not exhaustive

<a id='4a2b1a0c-70ca-4763-9b47-39a0dd961a05'></a>

<table><thead><tr><th>Domain</th><th>Key design principles</th><th>Examples of actions seen in other places</th></tr></thead><tbody><tr><td>5 Financing</td><td>Provide cheap financing for early proof-of-concepts<br>and pilots to accelerate industry growth without<br>creating industry dependence on government support<br><br>Attract projects and investments with high scale-up<br>potential and secure long term contracts (potential<br>lock-ins)<br><br>Protect private investor rights</td><td>Coordinate actors from the <b>financial sectors</b> to establish <b>investment lines</b> for the development of the hydrogen ecosystem<br><br>Provide financial support for initial <b>feasibility studies</b> with commitment for further scale-up without government financing<br><br>Create financing lines for the initial <b>construction of green ammonia and blue urea factories</b><br><br>Fund <b>pilot projects</b> to test <b>technologies in key applications</b> (mining, transport, H2 replacement, gas blending, etc.) with potential further development without government funding<br><br>Establish <b>financing lines for fleet renovation</b> (e.g. buses, HDT) with FCEV and/or for <b>shared refueling station</b> at key hubs<br><br>Advocate for regulation which <b>reduces risks for the deployment of capital</b> for green hydrogen projects in Chile</td></tr><tr><td>Incentives</td><td>Support initial investments in sectors with higher<br>potential of long-term socio-economic gains<br><br>Apply the most efficient tools to anticipate the<br>industry development without creating industry<br>dependence on government support</td><td>Permit hydrogen producers to use the <b>grid for transmission at marginal costs</b> (not full cost)<br><br>Create <b>carbon bonds</b> for green energy producers and carbon capture in urea production<br><br>Create a <b>Carbon tax</b> per ton of CO2 for transport applications<br><br>Establish <b>royalties abatements</b> for mining companies to incentive investment in FCEV (haul trucks and HDT) – for a limited period of time<br><br><b>Import duty on grey ammonia and derivatives</b><br><br>Increase <b>subsidies for green fertilizers</b> in the market<br><br>Establish <b>emissions standards for vehicles</b> and incentives for FCEVs</td></tr></tbody></table>

<a id='9a9866c8-88eb-4336-b0f6-b04e02f80da0'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='778fac85-f8c9-41df-a9f1-7027b58b1d19'></a>

McKinsey & Company

<a id='e4ef9cb3-0d2a-4699-b3bc-d50f36807418'></a>

64

<!-- PAGE BREAK -->

<a id='990c7cce-21a8-4840-9b27-34633618dfa6'></a>

6.1-6.4/ Enabling actions (4/4)

<a id='afcd7222-1708-4b0f-922d-da70c49691bf'></a>

Not exhaustive

<a id='eb988e07-0a00-4e18-a894-252be8e79735'></a>

Not exhaustive
<table id="64-1">
<tr><td id="64-2">Domain</td><td id="64-3">Key design principles</td><td id="64-4">Examples of actions seen in other places</td></tr>
<tr><td id="64-5">6 Infrastructure</td><td id="64-6">Facilitate infrastructure development to enable hydrogen / derivative supply and demand Capture synergies in infrastructure development Leverage infrastructure already in place</td><td id="64-7">Establish protocols and rules for repurposing of existing infrastructure (ports, pipelines, etc.) Develop pipeline network for hydrogen and ammonia transport (from production to utilization sites) Develop port infrastructure and road transportation routes via PPPs Build transmission line infrastructure at scale Facilitate the installation of refueling stations at key hubs (e.g. bus terminals, ports, etc.) Reinforce the Infrastructure of key cities / regions to make them more attractive for skilled people</td></tr>
<tr><td id="64-8">7 Research &amp; development</td><td id="64-9">Enable rapid technology development, transfer and adoption Partner with other governments to conduct joint R&amp;D on key topics for Chilean H2 development</td><td id="64-a">Create a research center for green hydrogen that promotes and coordinate research efforts between among bodies and companies Create lines of funding for research (e.g. Fondecyt) on hydrogen related issues at universities and R&amp;D centers of companies Develop research projects together with international research centers / universities on key issues for the Chilean hydrogen economy</td></tr>
<tr><td id="64-b">8 Skilled Labor</td><td id="64-c">Prepare sound technical experts for the industry Give job opportunities to disadvantage communities Promote gender equality</td><td id="64-d">Promote programs and courses on hydrogen related topics in universities and technical centers Support worker training and educational programs in hydrogen production centers, refueling stations, storage points, among others</td></tr>
</table>

<a id='db9c6df0-b9b0-4c07-9748-2516fc0c7646'></a>

Source: Press research; Hydrogen roadmap for EU, USA; Netherlands, France, Australia, Germany, South Korea; Team analysis

<a id='156968cd-4a98-4170-b6a8-44afc2b46e55'></a>

McKinsey & Company

<a id='966060af-22cf-4bf4-b039-f415fb9fda62'></a>

65