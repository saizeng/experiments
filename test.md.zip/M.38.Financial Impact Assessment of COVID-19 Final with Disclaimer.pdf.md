<a id='5180ddd1-e960-485d-96e5-bfc8f33db2f3'></a>

## Disclaimer

<a id='98cc4f7a-5dab-4dfe-9578-6c2018b908e2'></a>

McKinsey Analysis—Metropolitan Transportation Authority
Financial Impact Assessment on 2020 Revenue of COVID-19

<a id='a21bddcf-f0d0-4726-8e52-8e8247c67883'></a>

McKinsey & Company was contracted to provide MTA with a detailed economic analysis (the "Report") which will assist management in assessing the financial impact of the COVID-19 pandemic on MTA operations. Before reviewing the Report, users are advised to carefully read the "Disclaimer" page of the Report in its entirety.

<a id='994260a1-41df-4d2f-9fee-18f8d21b5ee8'></a>

Please take a few minutes to read the Terms of Use below as they are complementary to the information presented in the Report.

**Terms of Use**

1.  **Not an Offer to Sell/Buy Securities:** The information provided in the Report does not constitute an offer to sell or buy securities or the solicitation of an offer to sell or buy securities and should not be relied upon to provide specific offering information in connection with any issuance, sale, resale, or remarketing of bonds, notes, or other municipal obligations.
2.  **Information is Subject to Change Without Notice and May Not Be Updated**: MTA is under no obligation to update any information included in the Report. The information and expressions of opinion therein are subject to change without notice.
3.  **Estimates or Other Forward-Looking Statements:** The Report may make "forward-looking statements" by using forward-looking words such as "may," "will," "should," "expects," "believes," "anticipates," "estimates," or others. You are cautioned that forward-looking statements are subject to a variety of uncertainties that could cause actual results to differ from the projected results. Because MTA cannot predict all factors that may affect future decisions, actions, events, policy decisions, or financial circumstances, what actually happens may be different than what is included in forward-looking statements.
4.  **Investment Decisions:** The Report is not intended to replace any information or consultation provided by a professional financial advisor.
5.  **Unauthorized Use Not Permitted:** The Report is part of the official website of MTA. MTA disclaims all responsibility for any copies, modifications, and reproductions of this Report or the information it contains that are not produced by MTA.

<a id='26330b32-886b-4e07-826a-a059879a48af'></a>

<::logo: Metropolitan Transportation Authority
MTA Metropolitan Transportation Authority
A blue circle with "MTA" in white, next to the full name in blue text.::>

<!-- PAGE BREAK -->

<a id='6baa56c0-5335-4999-9ac5-cd2f79216238'></a>

Metropolitan
Transportation
Authority

Financial impact assessment on 2020 revenue of COVID-19

<a id='9b385f21-cc8b-45b4-94a3-e84483498239'></a>

<::logo: MTA
MTA
A blue circular logo with white bold letters "MTA" in the center, and the text "1 May 2020" above it.::>

<!-- PAGE BREAK -->

<a id='db501297-1921-40b1-9f01-2ce6e58a52ca'></a>

In April 2020, McKinsey & Company was contracted by the MTA to analyze the potential near-term financial impact of Covid-19 on the MTA. This document represents a summary of the approach, analyses, and key findings.

<a id='d13992ea-fae0-4f0e-9918-4c5ed4b0aa44'></a>

2

<!-- PAGE BREAK -->

<a id='ccaf604a-e1cc-442f-a570-3b4fe29104c5'></a>

Disclaimer

<a id='6d28b11c-d69a-4870-b897-88dbcc640ad7'></a>

The analyses and conclusions contained in this document were conducted on an accelerated basis, reflect preliminary perspectives concerning MTA operations and do not purport to contain or incorporate all the information that would be required by MTA to properly evaluate its operational and strategic options. Furthermore, these materials are not intended to constitute legal, accounting, policy or similar professional or regulatory advice normally provided by licensed or certified practitioners and are similarly not intended as materials to be relied on.

<a id='cafad2d6-819b-4da7-98e8-95379281ca24'></a>

The analyses and conclusions contained in this document are based on various assumptions that were developed by MTA, which partly may or may not be correct, being based upon factors and events subject to uncertainty. Such assumptions were developed solely as a means of illustrating the principal considerations that may be taken into account and independently evaluated. Such information has not been independently verified and is inherently uncertain and subject to change. Given the uncertainty surrounding the pandemic, these materials are not a guarantee of results, and future results could differ materially from any forecasts or projections. These materials do not constitute policy advice or legal, medical or other regulated advice. Particularly in light of the rapidly evolving COVID-19 pandemic, and the attendant regulatory and market supply conditions, these materials were developed to provide fact-based, independent analysis to the MTA for its own use to develop its own recommendations and make its own decisions regarding future plans.

<a id='349ff2da-2939-4c1f-ab9e-c6b2aee493d5'></a>

McKinsey & Company, Washington, D.C., Inc. makes no representation or warranty, express or implied, as to the accuracy or completeness of the underlying assumptions, estimates, analyses, or other information contained in this document, and nothing contained herein is or shall be relied upon as a promise or a representation, whether as to the past, the present, or the future.

<a id='ebffd514-1756-4f42-83f4-97ee99b57bae'></a>

This document is not intended to, and may not, be relied upon by any person or entity and, therefore, any person or entity who receives this document or the information contained herein, with McKinsey & Company, Washington, D.C., Inc.'s permission or otherwise, is hereby put on notice that (i) they are responsible for their own analyses and may not rely on any information contained herein, and (ii) McKinsey & Company, Washington, D.C., Inc. makes no representations or warranties, including with respect to the accuracy or completeness of the information contained herein or any other written or oral communication transmitted or made available to the third party, and expressly disclaims any and all liabilities based on such information or on omissions there from

<a id='b147d460-77b1-4b1a-955e-e3ab3a3e71d7'></a>

3

<!-- PAGE BREAK -->

<a id='bb8b84de-7c1f-49d4-82c4-829add69b184'></a>

## Contents

<a id='28a11a90-569f-4103-8bb3-8d4635d744fe'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='15b351d6-b8ec-4ebd-b694-bf5b318ee745'></a>

**Fare and toll revenue methodology**

Non-fare revenue methodology

Additional operating expense methodology

Operating gap

Impact of filling the gap

<a id='085c0741-6f30-46bb-a927-9fbeba73c6ac'></a>

4

<!-- PAGE BREAK -->

<a id='71405987-3a9a-43d6-b63b-2cd9b1c71e9e'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='10b11c86-4824-4636-96dc-c9d161a56114'></a>

Overview of revenue components and forecast approach

<a id='2387979c-5f98-4d99-9d20-95d0d0c227f5'></a>

- Focus of this chapter

<a id='b5664434-ac53-4ce1-b08a-9ec4fc8917b5'></a>

**Fare and toll revenue**

---

Applied different scenarios of how long the current state of social distancing will last based on actuals, and what ridership/mobility ramp-up might look like after that. For those scenarios, considered the impact of epidemiology, policy effects, and behavioral changes

---

v

**Ridership/traffic curves**

<a id='a34b0361-1781-4fa4-b424-734c824febd0'></a>

# Non-fare revenue

Identified five archetypes of tax or subsidy revenue – Employment, Real Estate and Mortgages, Sales, Business Income, and Mobility – each with a distinct driver. Created a multiplier for each archetype, which was applied to each source to forecast 2020 revenue

<a id='12984af9-bacf-413d-b497-eb15902a025c'></a>

⌄

Tax-specific change profiles

<a id='d586cdec-263c-4bea-ab5f-3f6bf12894d5'></a>

5

<!-- PAGE BREAK -->

<a id='8ffebe61-bb7f-4973-ab1b-7e0645cbf9a2'></a>

Current as of 4/28/20

<a id='6f0913df-3405-4386-bf3a-fac10201b080'></a>

Guiding questions for fare methodology

<a id='5952fb33-ef31-4940-b59c-45a0e0d2fce8'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='0cc18cf4-1920-4cd1-aca1-a836e2f9803e'></a>

## Guiding questions

1.  What is current ridership during intense social distancing (e.g., the current period)?
2.  What level of ridership are we going to, i.e., what's the 'new normal' level in a period of economic decline/social distancing?
3.  What will the ramp up be like to get from point 1 to point 2, and when will it start?
4.  How will this ramp up be interrupted by a potential resurgence of the virus in Q4 2020?

## Resulting actions for methodology

Used actuals provided by the MTA and compared across systems to calibrate. Ridership for most systems is down dramatically (~90%).

Looked at historical experience for what "new normal" looks like in an economic crisis. Began with ridership and toll recovery from the trough during the Great Recession, then took an additional haircut to reflect a number of factors that could continue to suppress demand (e.g., increased prevalence of work from home)

Looked at ramp-up curves in health/safety/security crises (e.g., 9/11, SARS) as well as economic crises (e.g., Great Recession) to understand how demand has reacted to past crises, and shaped a potential curve for a dual health/safety and economic crisis

Modeled two scenarios of potential interruption by a resurgence, one where a second wave would result in something similar to present-day physical distancing conditions (in addition to seasonal flu), and a second more positive scenario factoring in the impact of better preparedness which would reduce the trough as currently experienced

<a id='89d1347d-5ee8-40fc-ab55-209896d4bb6b'></a>

Although different assets may behave differently, e.g., commuter rail may have a slower ramp-up than bus given that commuter rail riders could be more likely to work from home for longer or to use a personal vehicle, some early sensitivity testing was conducted and showed that additional precision from a bottom-up build did not meaningfully impact the aggregate number

<a id='f6324cd3-077e-411d-a741-baa141d3dbc9'></a>

6

<!-- PAGE BREAK -->

<a id='20c81bc6-0d57-431a-8cf8-a70be1a5f3c1'></a>

1 Due to COVID-19 ridership has fallen
drastically across all transit systems...
Commuter and heavy rail have been affected particularly severely

<a id='d407aa7a-55d2-458c-b560-d44e5a9fedb0'></a>

<::bar chart: Greatest reported reduction in ridership vs. last month or last year¹, percent reduction in ridership. Legend: Commuter Rail (dark blue/black), Heavy Rail (medium blue), Bus (darker blue), Mix (light blue). The chart displays transit agencies, the date of data, the percentage reduction in ridership, and the type of service. Data points are as follows: MBTA Boston, 14 April, 99%, Commuter Rail; MTA LIRR, 24 April, 97%, Commuter Rail; MTA Metro-North, 24 April, 95%, Commuter Rail; WMATA, 28 April, 95%, Heavy Rail; BART SF, 28 April, 94%, Heavy Rail; NYC Transit, 20 April, 90%, Heavy Rail; MARTA, 26 April, 81%, Heavy Rail; Chicago Transit Authority, 23 April, 80%, Heavy Rail; LA Metro, 29 April, 80%, Heavy Rail; NYC Transit, 24 April, 81%, Bus; MBTA Boston, 28 April, 80%, Bus; WMATA, 28 April, 73%, Bus; LA Metro, 29 April, 65%, Bus; MARTA, 26 April, 45%, Bus; NJ TRANSIT, 18 April, 90%, Mix; SF Muni, 28 April, 83%, Mix; Denver RTD, 16 April, 70%, Mix.::>

<a id='d23e705c-a6cb-406d-adf8-dff388ddc616'></a>

1 Data collection and accuracy may vary across transit systems - some might be based on ticket entry, others on samples and extrapolation

<a id='4f3280dc-b55d-463b-b99e-94044f7cbbb5'></a>

Source: Chicago Tribune, Eno Center for Transportation, Boston Herald, WMATA.com, Bart.gov, The New York Times, Saporta Report, Chicago Sun Times, LAist, Seattle Transit Blog, MTA internal data, Boston Business Journal, LAist, WOMB, Bloomberg, Colorado Politics

<a id='c7842853-a1f1-497a-97c9-0ffcf38fff61'></a>

Data collected April 30, 2020

<a id='bdd5d93b-c03b-475a-ba0b-7509334fa834'></a>

Effects on public transit
systems ridership

Ridership has fallen across
systems across the US
and the globe

<a id='7fa3a37d-7cfb-4376-95ce-909728cbf0d6'></a>

Due to increased work
from home policies, commuter
rail systems are affected
particularly strongly

<a id='a5a9ac48-4c8e-465a-8562-50649e520df9'></a>

Government mandates have also had strong effects in key geographies

<a id='3ac9a558-a2cc-4977-a620-99e39f55cb54'></a>

(4/28/20) Please see disclaimer on page
3. These analyses represent only
potential scenarios based on discrete
data from one point in time. They are not
intended as a prediction or forecast, and
the situation is changing daily.

<a id='f854761f-85a3-47d9-96e3-332f7c4b791f'></a>

7

<!-- PAGE BREAK -->

<a id='d77f2c03-0dbd-4fe2-a1dd-8d92ad4af1db'></a>

1

<a id='1fdc9b0c-fc3d-41ae-bb90-18922065ef4b'></a>

...and has remained low since this

<a id='1e369f2e-14f2-469c-9919-e5741bd618f8'></a>

# sharp drop

Initial declines led to persistently low ridership

---

<a id='517fa731-f23c-48cb-ba08-2408ed0813d6'></a>

Initial decline: ridership fell swiftly and sharply across systems starting the week of March 9th<::chart showing % decline in ridership for various public transit systems from March 9th to March 19th. The y-axis represents the % decline in ridership, ranging from 0 to -100. The x-axis represents dates from Mar 9 to Mar 19. A vertical line at Mar 13 is annotated with "President Trump declares a national emergency". The chart includes seven lines, each representing a transit system:
- NYCT Bus (light green dashed line): declined from approximately -10 on Mar 9 to -15 on Mar 11 and -49 on Mar 17.
- NYCT Subway (light blue dashed line): declined from approximately -10 on Mar 9 to -19 on Mar 11 and -60 on Mar 17.
- LIRR (light green solid line): declined from approximately -20 on Mar 9 to -31 on Mar 11 and -67 on Mar 17.
- Metro-North (dark green dashed line): declined from approximately -30 on Mar 9 to -48 on Mar 11 and -90 on Mar 17.
- BART SF (yellow dashed line): declined from approximately -20 on Mar 9 to -35 on Mar 10, -48 on Mar 13, and -70 on Mar 17.
- MBTA Boston (dark blue dashed line): declined from approximately -30 on Mar 9 to -48 on Mar 13 and -78 on Mar 17.
- NJ TRANSIT (red dashed line): declined from approximately -10 on Mar 9 to -20 on Mar 13 and -88 on Mar 19.

The overall trend for all systems shows a sharp decline in ridership over the period.: chart::>

<a id='6c4ad7bd-1507-4e92-bc39-27f8580aeb62'></a>

Source: The New York Times, Bloomberg, The Boston Herald, The Verge, CBS San Francisco, WHYY, TransitApp data
measuring frequency of app opens compared to projected use of the app (adjusted for annual growth)

<a id='224b06f0-a7ca-4e7f-a14a-a476a094115c'></a>

Current as of 4/28

<a id='48168ba1-e1f5-49f6-b8a3-f9d5ff36081c'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='72cdc20b-ace9-40bb-b02d-ae6dade6a8db'></a>

**Sustained decline:** Transit app data shows use at persistently low levels through April

% change in public transit demand measured by app use

<a id='2acef7ad-ce2a-48d2-82a3-23bca628335e'></a>

<::line chart: Title: Change in public transit demand. Y-axis: Percentage change from 20% to -100%. X-axis: Mar 5, Mar 24, Apr 12, Apr 29. Legend: All New York City, BART SF, MBTA Boston, NJ TRANSIT rail (and bus). The chart shows multiple lines representing the change in public transit demand over time for different cities/regions. All lines show a sharp decline in demand starting around mid-March, stabilizing at significantly lower levels (mostly between -60% and -80%) by late March and into April, with some slight fluctuations and a minor upward trend for NJ TRANSIT rail towards the end of April. Source: transitapp.com/coronavirus. Logo: transit.::>

<a id='df22f748-0208-4725-99dd-014e8429d0c6'></a>

8

<!-- PAGE BREAK -->

<a id='135280d8-bdec-4918-8d5e-7e61ab17fae5'></a>

<::logo: [Unknown Brand]
2
A white number "2" is centered within a dark blue circular shape.::>

<a id='877d0ef9-db26-4623-97dd-f553c266b2a7'></a>

Data collected March 23, 2020

<a id='71e065d2-d786-413c-ad4a-5f0ebfaeac4c'></a>

In the 08/09 financial crisis, urban transit
ridership followed a "U" shape...

<a id='61e5210a-dd07-4077-a955-ee42c5582097'></a>

Impact of 2008/09 financial crisis on US urban transit!
By mode of transportation, average monthly ridership, in %

<a id='a15de4df-0f66-46d1-990b-0c0aec9889d6'></a>

<::Line chart titled "Crash of Lehman Brothers (September 2008)" with data from -8 to 40 on the x-axis. The left y-axis is labeled "Pre-outbreak = 100" ranging from 60 to 115. The right y-axis is labeled "Unemployment rate" ranging from 0 to 25. The legend shows: Heavy rail (subway) (black line), Bus (pink line), Commuter rail (blue line), Light rail (light blue line), and Unemployment rate (dashed light blue line). Vertical lines are marked with "Feb 2009", "Feb 2010", and "Feb 2011".::>

<a id='44c4e64e-ce70-410e-9b4c-799c366fef1a'></a>

Months before/after crisis start

<a id='03cca411-3394-4554-a97c-cdc3863c0a2a'></a>

1. Includes New York, San Francisco, Washington DC, and Boston metro areas

<a id='4b79bcd9-6251-4a16-b82d-5696eed43754'></a>

Source: National Transit Database (NTD), Bureau of Labor Statistics (BLS)

<a id='2803df5a-47b7-4d40-918b-4afa080a1a89'></a>

... a decline with a long
path to recovery

<a id='772cdeb3-d75b-4fdd-846a-eb174d8d478d'></a>

Financial crisis showed a long-term impact on transit ridership

<a id='f49a32c0-b943-4f2a-b6ef-6d8ef0224e9c'></a>

While seasonality led to normal fluctuations
in ridership, there was a drop of up to 20%
across systems (February 2010) correlating
with the peak of the unemployment rate in
the US

<a id='9b2fc989-7071-4137-bd5e-56a148a5ab7f'></a>

The impact of the crisis was felt over a long
time period, “U” vs. “V” shaped recovery

<a id='90289de3-5ad2-428e-bcdc-dc94a01bc5c4'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='bc7b1e30-d94b-4805-b66b-f143d3c024dd'></a>

9

<!-- PAGE BREAK -->

<a id='e6f28e90-be24-4562-bb0e-3f3056354c5e'></a>

3

<a id='94eaa608-72fa-409f-a0fe-5169e46459cb'></a>

Data collected March 23, 2020

<a id='3b3be859-d96f-472c-8707-4e7c7aa88991'></a>

Shocks affecting health and safety have historically had a “V” shape, with ridership dropping 30-50%, then returning to near normal in 2-3 months

<a id='785331a1-3902-4fe5-91c0-1b94e861fc60'></a>

Impact of historical crises on urban transit ridership

<a id='7ccef2bb-4cc7-4356-b8af-3c4874e69fe0'></a>

<::Line chart titled "Effect of safety/security crises – 9/11". The y-axis represents ridership relative to pre-event levels, where "Pre-event = 100". The y-axis ranges from 40 to 110. The x-axis represents "Months before/after 9/11", ranging from -3 to 10. A vertical line at x=0 is labeled "September 2001".The chart displays three lines:
- Black line: Average weekday ridership, Bay Area Rapid Transit (BART)
- Red line: Average daily ridership, Taipei Metro
- Blue line: Monthly ridership, Port-Authority Trans-Hudson (PATH)

Trends:
- BART (black line): Starts around 100, drops sharply at 0 (September 2001) to around 43, then recovers to 96 by month 1 and generally stays in the 90-96 range.
- Taipei Metro (red line): Starts around 100, peaks at 108 at -1 month, drops sharply at 0 to around 58, then gradually recovers and rises to 104 by month 10.
- PATH (blue line): Starts around 100, drops at 0 to 78, recovers to 86 by month 1, then declines to around 65 by month 5 and stays relatively low, around 70-72, for the remainder of the period.

Annotations:
- An arrow points to the lowest point of the BART line with the text: ">50% drop in urban transit in Bay Area post 9/11".
- Text near the PATH line from month 5 onwards: "Part of PATH did not reopen till mid-2003".
: chart::>

<a id='f1744164-c20f-4a09-a911-cef2d05ffb94'></a>

Effect of health crises – SARS 2003

<a id='df7450a5-5c29-4f49-bdeb-1ba8489f3387'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

- Average daily ridership, Taipei Metro
- Monthly ridership, public transportation Hong Kong¹

<a id='156f724b-a09b-4fbb-9437-28fa2b7597e2'></a>

<::Line chart showing two trends over time relative to an outbreak.
The Y-axis ranges from 40 to 110, with "Pre-outbreak = 100" as a reference.
The X-axis is labeled "Months before/after outbreak", ranging from -3 to 10.
A vertical line at X=0 indicates the "Start of outbreak (April 2003)".

One line (red) shows the following approximate values:
- At -3 months: 100
- At -2 months: 103
- At -1 month: 103
- At 0 months (start of outbreak): 95
- At 1 month: 67
- At 2 months: 77
- At 3 months: 93
- At 4 months: 96
- At 5 months: 100
- At 6 months: 104
- At 7 months: 104
- At 8 months: 108
- At 9 months: 97
- At 10 months: 108

Another line (blue) shows the following approximate values:
- At -3 months: 100
- At -2 months: 88
- At -1 month: 94
- At 0 months (start of outbreak): 75
- At 1 month: 88
- At 2 months: 88
- At 3 months: 94
- At 4 months: 97
- At 5 months: 95
- At 6 months: 99
- At 7 months: 96
- At 8 months: 100
- At 9 months: 96
- At 10 months: 92

Both lines start at 100 at -3 months. The red line peaks slightly before the outbreak, drops significantly after the outbreak starts, reaching a low at month 1, and then recovers, eventually surpassing its pre-outbreak level. The blue line fluctuates before the outbreak, drops sharply at the outbreak's start, recovers, and generally stays below or around the pre-outbreak level for most of the period after the outbreak.::>

<a id='3f9aca18-9664-42f8-b4a6-aff8de13bd10'></a>

1. Includes various modes of transportation, such as bus, rail, and ferry; does not include taxi

<a id='e99d2264-ef6a-4c9b-91d6-f34dc37034d3'></a>

Source: Bay Area Rapid Transit, Taipei Metro, New York State Open Data (data.ny.gov), Hong Kong Census and Statistics Department

<a id='1f6b8655-722a-4de1-b69e-8095bb0f7bd5'></a>

10

<!-- PAGE BREAK -->

<a id='61f57ceb-798a-4363-bf24-e6898b722286'></a>

3

<a id='0ff56e29-da32-4282-ba0d-ee28a9fa8394'></a>

Current as of 4/28/20

<a id='8c0602c8-d45f-49e7-9a66-93fbeb7aa6b4'></a>

How COVID-19 may be different than past health or safety shocks
Considerations for modeling a COVID-19 curve

<a id='b254daf0-36bf-4d81-8fb7-5b71b6a1b5d2'></a>

<u>Not Exhaustive</u>

<a id='e1c7c66b-c7ea-44fc-962c-0be5b9364276'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='e987af6e-55f0-4b97-8c17-4d925faa8970'></a>

# Length of crisis
This does not appear to be a point in time crisis like 9/11 but an extended multi-month and possibly multi-year event until the virus is contained and therapeutics and vaccines are developed

<a id='94528b30-03f7-4805-863a-577ea2cf80ac'></a>

# Recovery pattern

As of this date, it is widely expected by public health officials that as social isolation measures are lifted, infection rates will increase

<a id='e19359dd-cc19-4f04-a5d6-64765fd83857'></a>

# Seasonality
It is unclear what the
impact of
seasonality, if any,
may be on the
coronavirus spread

<a id='12bb0dcd-4dd0-43b5-82bb-a825a95791d5'></a>

# Potential for resurgence
Depending on multiple factors including herd immunity, human behaviors, hospital capacity readiness, and policies in the fall, a second major wave could be experienced, potentially coinciding with peak flu season

<a id='b7efcea8-3b75-49b7-a3e6-ba66fd06f926'></a>

11

<!-- PAGE BREAK -->

<a id='a49fada1-7689-4a99-a7c9-f489d60d7576'></a>

4 Two ridership scenarios were developed...

<a id='2cafc710-219a-4baa-8e61-993872326482'></a>

Potential scenarios for ridership through the end of 2020

<::Potential scenarios for ridership through the end of 2020
: line chart::>
% of base level ridership (previous year)
Pre-outbreak = 100

**Y-axis:**
100
90
80
70
60
50
40
30
20
10
0

**X-axis:**
Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec

**Legend:**
— Scenario 1: Earlier containment and recovery
— Scenario 2: Delayed containment and recovery

**Annotations:**
xx% Approximate decrease in annualized fare-based revenue
-60% (for Scenario 1, indicating decrease from pre-outbreak)
-75% (for Scenario 2, indicating decrease from pre-outbreak)

**Data Points (approximate):**
**Scenario 1 (Earlier containment and recovery):**
Jan: 100
Feb: 100
Mar: 50
Apr: 10
May: 10
Jun: 20
Jul: 35
Aug: 45
Sep: 60
Oct: 55
Nov: 55
Dec: 55

**Scenario 2 (Delayed containment and recovery):**
Jan: 100
Feb: 100
Mar: 70
Apr: 10
May: 10
Jun: 15
Jul: 25
Aug: 35
Sep: 40
Oct: 10
Nov: 10
Dec: 10
::>

<a id='52186b9c-48b3-42e2-8073-8d33b53ffd8d'></a>

Source: MTA ridership scenarios analysis

<a id='a37fdd35-5b54-41ee-a36f-7fd66cd75995'></a>

Current as of 4/17

<a id='db85cede-29ec-4118-99b3-b1966f4f883d'></a>

...combining the characteristics of health and economic crises

<a id='555b4285-1c28-4845-b11b-021c0959e86f'></a>

Major assumptions underlying the difference in scenarios

<a id='64113a31-e262-4b64-842b-fe34c55c32e4'></a>

**Ramp-up after lockdown**
Scenario 2 features a relatively slower change from
current ridership levels due to an increased prevalence
of countervailing factors (e.g., personal preferences
away from transit, increased work from home, stronger
virus spread resurgence) compared to those modeled in
scenario 1

<a id='644f17d6-36e4-4ea0-a539-eb06895437c2'></a>

Resurgence in the fall

In both scenarios the COVID-19 pandemic could resume in the fall, but in scenario 2, the outcomes could be more dire (e.g., strained healthcare system, weak/lacking "herd immunity")

<a id='4c580ed2-16a1-410c-96d2-30afc02a4824'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='7ba5d373-4734-432a-aecb-721e90300c70'></a>

12

<!-- PAGE BREAK -->

<a id='fb7ea62d-f66f-4aa6-bcda-465f83b09170'></a>

<::logo: [Unknown]4A white number '4' is centered within a dark blue circular background.::>

<a id='24324230-7c64-4bf6-8473-afd8fa186d23'></a>

Current as of 4/17

<a id='a1fe96bd-590c-41ad-b6a8-a5dd226be3de'></a>

## Resulting fare revenue assumptions and modeling
% of typical ridership in a given month
---


<a id='14baed1a-b74c-46b3-b960-77445d6707d5'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='fc0eb85b-c26e-4f2a-8d58-df371b28b1cd'></a>

<table id="13-1">
<tr><td id="13-2">Assumptions</td><td id="13-3"></td><td id="13-4"></td><td id="13-5"></td><td id="13-6"></td><td id="13-7"></td><td id="13-8"></td><td id="13-9"></td><td id="13-a"></td><td id="13-b"></td><td id="13-c"></td><td id="13-d"></td><td id="13-e"></td></tr>
<tr><td id="13-f">Ridership as % of baseline in social distancing period</td><td id="13-g">10%</td><td id="13-h"></td><td id="13-i"></td><td id="13-j"></td><td id="13-k"></td><td id="13-l"></td><td id="13-m"></td><td id="13-n"></td><td id="13-o"></td><td id="13-p"></td><td id="13-q"></td><td id="13-r"></td></tr>
<tr><td id="13-s">System trough % of baseline in Great Recession</td><td id="13-t">90.6%</td><td id="13-u"></td><td id="13-v" colspan="3">Nov 12 over Nov 07 ridership trough</td><td id="13-w"></td><td id="13-x"></td><td id="13-y"></td><td id="13-z"></td><td id="13-A"></td><td id="13-B"></td><td id="13-C"></td></tr>
<tr><td id="13-D">System trough % of baseline in COVID-19</td><td id="13-E">85.9%</td><td id="13-F"></td><td id="13-G" colspan="2">50% greater impact</td><td id="13-H"></td><td id="13-I"></td><td id="13-J"></td><td id="13-K"></td><td id="13-L"></td><td id="13-M"></td><td id="13-N"></td><td id="13-O"></td></tr>
<tr><td id="13-P">Annual fare revenue</td><td id="13-Q">6.49</td><td id="13-R">B</td><td id="13-S" colspan="2">2020 Feb Plan revenue</td><td id="13-T"></td><td id="13-U"></td><td id="13-V"></td><td id="13-W"></td><td id="13-X"></td><td id="13-Y"></td><td id="13-Z"></td><td id="13-10"></td></tr>
<tr><td id="13-11">Mar-Dec fare revenue</td><td id="13-12">5.49</td><td id="13-13">B</td><td id="13-14"></td><td id="13-15"></td><td id="13-16"></td><td id="13-17"></td><td id="13-18"></td><td id="13-19"></td><td id="13-1a"></td><td id="13-1b"></td><td id="13-1c"></td><td id="13-1d"></td></tr>
<tr><td id="13-1e">Leakage from enhanced health procedures</td><td id="13-1f">10%</td><td id="13-1g"></td><td id="13-1h"></td><td id="13-1i"></td><td id="13-1j"></td><td id="13-1k"></td><td id="13-1l"></td><td id="13-1m"></td><td id="13-1n"></td><td id="13-1o"></td><td id="13-1p"></td><td id="13-1q"></td></tr>
<tr><td id="13-1r"></td><td id="13-1s"></td><td id="13-1t"></td><td id="13-1u"></td><td id="13-1v"></td><td id="13-1w"></td><td id="13-1x"></td><td id="13-1y"></td><td id="13-1z"></td><td id="13-1A"></td><td id="13-1B"></td><td id="13-1C"></td><td id="13-1D"></td></tr>
<tr><td id="13-1E">Monthly cashflow</td><td id="13-1F"></td><td id="13-1G"></td><td id="13-1H">$ 0.25</td><td id="13-1I">$ -</td><td id="13-1J">$ -</td><td id="13-1K">$ 0.05</td><td id="13-1L">$ 0.13</td><td id="13-1M">$ 0.21</td><td id="13-1N">$ 0.27</td><td id="13-1O">$ 0.27</td><td id="13-1P">$ 0.24</td><td id="13-1Q">$ 0.24</td></tr>
<tr><td id="13-1R">Monthly ridership</td><td id="13-1S"></td><td id="13-1T"></td><td id="13-1U">8.5%</td><td id="13-1V">8.5%</td><td id="13-1W">8.9%</td><td id="13-1X">8.3%</td><td id="13-1Y">8.3%</td><td id="13-1Z">8.2%</td><td id="13-20">8.5%</td><td id="13-21">9.1%</td><td id="13-22">8.2%</td><td id="13-23">8.1%</td></tr>
<tr><td id="13-24">Scenario 1- Moderate</td><td id="13-25"></td><td id="13-26"></td><td id="13-27">Mar-20</td><td id="13-28">Apr-20</td><td id="13-29">May-20</td><td id="13-2a">Jun-20</td><td id="13-2b">Jul-20</td><td id="13-2c">Aug-20</td><td id="13-2d">Sep-20</td><td id="13-2e">Oct-20</td><td id="13-2f">Nov-20</td><td id="13-2g">Dec-20</td></tr>
<tr><td id="13-2h">Virus spread largely contained in Q2, positive seasonal effect in Q3 with moderate resurgence in Q4</td><td id="13-2i"></td><td id="13-2j"></td><td id="13-2k">55%</td><td id="13-2l">10%</td><td id="13-2m">10%</td><td id="13-2n">20%</td><td id="13-2o">35%</td><td id="13-2p">50%</td><td id="13-2q">60%</td><td id="13-2r">55%</td><td id="13-2s">55%</td><td id="13-2t">55%</td></tr>
<tr><td id="13-2u">Ridership in remainder of 2020</td><td id="13-2v">40%</td><td id="13-2w"></td><td id="13-2x"></td><td id="13-2y"></td><td id="13-2z"></td><td id="13-2A"></td><td id="13-2B"></td><td id="13-2C"></td><td id="13-2D"></td><td id="13-2E"></td><td id="13-2F"></td><td id="13-2G"></td></tr>
<tr><td id="13-2H">Revenue loss</td><td id="13-2I">$3.82</td><td id="13-2J">B</td><td id="13-2K"></td><td id="13-2L"></td><td id="13-2M"></td><td id="13-2N"></td><td id="13-2O"></td><td id="13-2P"></td><td id="13-2Q"></td><td id="13-2R"></td><td id="13-2S"></td><td id="13-2T"></td></tr>
<tr><td id="13-2U">Monthly cashflow</td><td id="13-2V"></td><td id="13-2W"></td><td id="13-2X">$ 0.25</td><td id="13-2Y">$ -</td><td id="13-2Z">$ -</td><td id="13-30">$ 0.03</td><td id="13-31">$ 0.05</td><td id="13-32">$ 0.11</td><td id="13-33">$ 0.16</td><td id="13-34">$ -</td><td id="13-35">$ -</td><td id="13-36">$ -</td></tr>
<tr><td id="13-37">Monthly ridership</td><td id="13-38"></td><td id="13-39"></td><td id="13-3a">8.5%</td><td id="13-3b">8.5%</td><td id="13-3c">8.9%</td><td id="13-3d">8.3%</td><td id="13-3e">8.3%</td><td id="13-3f">8.2%</td><td id="13-3g">8.5%</td><td id="13-3h">9.1%</td><td id="13-3i">8.2%</td><td id="13-3j">8.1%</td></tr>
<tr><td id="13-3k">Scenario 2 - Severe</td><td id="13-3l"></td><td id="13-3m"></td><td id="13-3n">Mar-20</td><td id="13-3o">Apr-20</td><td id="13-3p">May-20</td><td id="13-3q">Jun-20</td><td id="13-3r">Jul-20</td><td id="13-3s">Aug-20</td><td id="13-3t">Sep-20</td><td id="13-3u">Oct-20</td><td id="13-3v">Nov-20</td><td id="13-3w">Dec-20</td></tr>
<tr><td id="13-3x">Virus spread less controlled, limited seasonality effect</td><td id="13-3y"></td><td id="13-3z"></td><td id="13-3A">55%</td><td id="13-3B">10%</td><td id="13-3C">10%</td><td id="13-3D">15%</td><td id="13-3E">20%</td><td id="13-3F">30%</td><td id="13-3G">40%</td><td id="13-3H">10%</td><td id="13-3I">10%</td><td id="13-3J">10%</td></tr>
<tr><td id="13-3K">Ridership in remainder of 2020</td><td id="13-3L">21%</td><td id="13-3M"></td><td id="13-3N"></td><td id="13-3O"></td><td id="13-3P"></td><td id="13-3Q"></td><td id="13-3R"></td><td id="13-3S"></td><td id="13-3T"></td><td id="13-3U"></td><td id="13-3V"></td><td id="13-3W"></td></tr>
<tr><td id="13-3X">Revenue loss</td><td id="13-3Y">$4.89</td><td id="13-3Z">B</td><td id="13-40"></td><td id="13-41"></td><td id="13-42"></td><td id="13-43"></td><td id="13-44"></td><td id="13-45"></td><td id="13-46"></td><td id="13-47"></td><td id="13-48"></td><td id="13-49"></td></tr>
</table>

<a id='c8219f75-75e2-4281-a3f6-089ded52f385'></a>

13

<!-- PAGE BREAK -->

<a id='4aea406f-95e3-4c3c-b47e-c08b38b6b679'></a>

**Two toll scenarios were developed based on current data and traffic projections**
Toll revenue followed many of the same underlying assumptions as ridership
---

<a id='07d00bd7-05be-4fd5-b3a3-3aa7f2f82e5e'></a>

<::Potential scenarios for traffic development through the end of 2020
% of base level traffic (previous year)

Legend:
  - Scenario 1: earlier containment and recovery (dark blue line)
  - Scenario 2: delayed containment and recovery (light blue line)

Chart data:
  - X-axis: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
  - Y-axis: 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100
  - Scenario 1 data points (approximate):
    - May: 35%
    - Jun: 45%
    - Jul: 55%
    - Aug: 65%
    - Sep: 75%
    - Oct: 65%
    - Nov: 65%
    - Dec: 65%
  - Scenario 2 data points (approximate):
    - Jan: 100%
    - Feb: 100%
    - Mar: 70%
    - Apr: 35%
    - May: 35%
    - Jun: 40%
    - Jul: 45%
    - Aug: 50%
    - Sep: 55%
    - Oct: 35%
    - Nov: 35%
    - Dec: 35%
: line chart::>

<a id='59918f1f-b89a-4d41-adc7-e411547a4c4f'></a>

Current as of 4/17

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='a84abc38-9231-47cd-b584-90903dfd65b5'></a>

Impact of social distancing
on toll revenue was
modeled using current data
(i.e., down to 35% of typical
traffic)

<a id='d2f66d2c-3110-4482-99ac-a597138f381c'></a>

Modeled a slightly longer
length of "lockdown" for
Scenario 2 than 1, following
the assumptions in the
ridership model

<a id='66e3ba3a-0aaa-46e8-b125-37ba528c09bd'></a>

Similar to ridership model,
the impact of a
"resurgence" in Q4 was
modeled in two scenarios,
one returning to present
levels, one slightly more
resilient

<a id='4ebf4ded-465a-4743-9771-10901196f80e'></a>

14

<!-- PAGE BREAK -->

<a id='befadca0-8f55-41d5-a12f-8aa7ecf5ab19'></a>

Current as of 4/17

<a id='b53986bc-5912-4081-b7bd-4cc44fda17ec'></a>

Resulting toll revenue assumptions and modeling
% of typical ridership in a given month

<a id='4e531e6a-56de-4ed9-a36a-b2ebc03863e5'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='5936d960-97d4-45e7-bf08-7359c08c5462'></a>

<table id="15-1">
<tr><td id="15-2">Assumptions</td><td id="15-3"></td><td id="15-4"></td><td id="15-5"></td><td id="15-6"></td><td id="15-7"></td><td id="15-8"></td><td id="15-9"></td><td id="15-a"></td><td id="15-b"></td><td id="15-c"></td><td id="15-d"></td><td id="15-e"></td></tr>
<tr><td id="15-f">Ridership as % of baseline in social distancing period</td><td id="15-g">35%</td><td id="15-h" colspan="3">&lt;- Rev ridership</td><td id="15-i"></td><td id="15-j"></td><td id="15-k"></td><td id="15-l"></td><td id="15-m"></td><td id="15-n"></td><td id="15-o"></td><td id="15-p"></td></tr>
<tr><td id="15-q">System trough % of baseline in Great Recession</td><td id="15-r">84.4%</td><td id="15-s" colspan="6">&lt;-- Nov 12 over Nov 07 ridership trough</td><td id="15-t"></td><td id="15-u"></td><td id="15-v"></td><td id="15-w"></td><td id="15-x"></td></tr>
<tr><td id="15-y">System trough % of baseline in COVID-19</td><td id="15-z">76.5%</td><td id="15-A" colspan="4">&lt;-- 50% greater impact</td><td id="15-B"></td><td id="15-C"></td><td id="15-D"></td><td id="15-E"></td><td id="15-F"></td><td id="15-G"></td><td id="15-H"></td></tr>
<tr><td id="15-I">Annual toll revenue</td><td id="15-J">2.12</td><td id="15-K">B</td><td id="15-L" colspan="4">&lt;-- 2020 Feb Plan revenue</td><td id="15-M"></td><td id="15-N"></td><td id="15-O"></td><td id="15-P"></td><td id="15-Q"></td><td id="15-R"></td></tr>
<tr><td id="15-S">Mar-Dec toll revenue</td><td id="15-T">1.81</td><td id="15-U">B</td><td id="15-V"></td><td id="15-W"></td><td id="15-X"></td><td id="15-Y"></td><td id="15-Z"></td><td id="15-10"></td><td id="15-11"></td><td id="15-12"></td><td id="15-13"></td><td id="15-14"></td></tr>
<tr><td id="15-15">Leakage from enhanced health procedures</td><td id="15-16">0%</td><td id="15-17"></td><td id="15-18"></td><td id="15-19"></td><td id="15-1a"></td><td id="15-1b"></td><td id="15-1c"></td><td id="15-1d"></td><td id="15-1e"></td><td id="15-1f"></td><td id="15-1g"></td><td id="15-1h"></td></tr>
<tr><td id="15-1i"></td><td id="15-1j"></td><td id="15-1k"></td><td id="15-1l"></td><td id="15-1m"></td><td id="15-1n"></td><td id="15-1o"></td><td id="15-1p"></td><td id="15-1q"></td><td id="15-1r"></td><td id="15-1s"></td><td id="15-1t"></td><td id="15-1u"></td></tr>
<tr><td id="15-1v" colspan="2">Monthly cashflow --&gt;</td><td id="15-1w"></td><td id="15-1x">$ 0.12</td><td id="15-1y">$0.06</td><td id="15-1z">$ 0.07</td><td id="15-1A">$0.08</td><td id="15-1B">$0.10</td><td id="15-1C">$0.12</td><td id="15-1D">$0.13</td><td id="15-1E">$0.12</td><td id="15-1F">$0.11</td><td id="15-1G">$0.11</td></tr>
<tr><td id="15-1H" colspan="2">Monthly traffic --&gt;</td><td id="15-1I"></td><td id="15-1J">8.3%</td><td id="15-1K">8.3%</td><td id="15-1L">8.9%</td><td id="15-1M">8.7%</td><td id="15-1N">8.8%</td><td id="15-1O">8.9%</td><td id="15-1P">8.4%</td><td id="15-1Q">8.5%</td><td id="15-1R">8.2%</td><td id="15-1S">8.2%</td></tr>
<tr><td id="15-1T">Scenario 1- Moderate</td><td id="15-1U"></td><td id="15-1V"></td><td id="15-1W">Mar-20</td><td id="15-1X">Apr-20</td><td id="15-1Y">May-20</td><td id="15-1Z">Jun-20</td><td id="15-20">Jul-20</td><td id="15-21">Aug-20</td><td id="15-22">Sep-20</td><td id="15-23">Oct-20</td><td id="15-24">Nov-20</td><td id="15-25">Dec-20</td></tr>
<tr><td id="15-26">Virus spread largely contained in Q2, positive seasonal effect in Q3 with moderate resurgence in Q4</td><td id="15-27"></td><td id="15-28"></td><td id="15-29">71%</td><td id="15-2a">35%</td><td id="15-2b">35%</td><td id="15-2c">45%</td><td id="15-2d">55%</td><td id="15-2e">65%</td><td id="15-2f">75%</td><td id="15-2g">65%</td><td id="15-2h">65%</td><td id="15-2i">65%</td></tr>
<tr><td id="15-2j">Ridership in remainder of 2020</td><td id="15-2k">57%</td><td id="15-2l"></td><td id="15-2m"></td><td id="15-2n"></td><td id="15-2o"></td><td id="15-2p"></td><td id="15-2q"></td><td id="15-2r"></td><td id="15-2s"></td><td id="15-2t"></td><td id="15-2u"></td><td id="15-2v"></td></tr>
<tr><td id="15-2w">Revenue loss</td><td id="15-2x">$ 0.77</td><td id="15-2y">B</td><td id="15-2z"></td><td id="15-2A"></td><td id="15-2B"></td><td id="15-2C"></td><td id="15-2D"></td><td id="15-2E"></td><td id="15-2F"></td><td id="15-2G"></td><td id="15-2H"></td><td id="15-2I"></td></tr>
<tr><td id="15-2J"></td><td id="15-2K"></td><td id="15-2L"></td><td id="15-2M"></td><td id="15-2N"></td><td id="15-2O"></td><td id="15-2P"></td><td id="15-2Q"></td><td id="15-2R"></td><td id="15-2S"></td><td id="15-2T"></td><td id="15-2U"></td><td id="15-2V"></td></tr>
<tr><td id="15-2W" colspan="2">Monthly cashflow --&gt;</td><td id="15-2X"></td><td id="15-2Y">$ 0.12</td><td id="15-2Z">$0.06</td><td id="15-30">$ 0.07</td><td id="15-31">$0.07</td><td id="15-32">$0.08</td><td id="15-33">$0.09</td><td id="15-34">$0.10</td><td id="15-35">$0.06</td><td id="15-36">$0.06</td><td id="15-37">$0.06</td></tr>
<tr><td id="15-38" colspan="2">Monthly traffic --&gt;</td><td id="15-39"></td><td id="15-3a">8.3%</td><td id="15-3b">8.3%</td><td id="15-3c">8.9%</td><td id="15-3d">8.7%</td><td id="15-3e">8.8%</td><td id="15-3f">8.9%</td><td id="15-3g">8.4%</td><td id="15-3h">8.5%</td><td id="15-3i">8.2%</td><td id="15-3j">8.2%</td></tr>
<tr><td id="15-3k">Scenario 2 - Severe</td><td id="15-3l"></td><td id="15-3m"></td><td id="15-3n">Mar-20</td><td id="15-3o">Apr-20</td><td id="15-3p">May-20</td><td id="15-3q">Jun-20</td><td id="15-3r">Jul-20</td><td id="15-3s">Aug-20</td><td id="15-3t">Sep-20</td><td id="15-3u">Oct-20</td><td id="15-3v">Nov-20</td><td id="15-3w">Dec-20</td></tr>
<tr><td id="15-3x">Virus spread less controlled, limited seasonality effect</td><td id="15-3y"></td><td id="15-3z"></td><td id="15-3A">71%</td><td id="15-3B">35%</td><td id="15-3C">35%</td><td id="15-3D">40%</td><td id="15-3E">45%</td><td id="15-3F">50%</td><td id="15-3G">55%</td><td id="15-3H">35%</td><td id="15-3I">35%</td><td id="15-3J">35%</td></tr>
<tr><td id="15-3K">Ridership in remainder of 2020</td><td id="15-3L">44%</td><td id="15-3M"></td><td id="15-3N"></td><td id="15-3O"></td><td id="15-3P"></td><td id="15-3Q"></td><td id="15-3R"></td><td id="15-3S"></td><td id="15-3T"></td><td id="15-3U"></td><td id="15-3V"></td><td id="15-3W"></td></tr>
<tr><td id="15-3X">Revenue loss</td><td id="15-3Y">$ 1.02</td><td id="15-3Z">B</td><td id="15-40"></td><td id="15-41"></td><td id="15-42"></td><td id="15-43"></td><td id="15-44"></td><td id="15-45"></td><td id="15-46"></td><td id="15-47"></td><td id="15-48"></td><td id="15-49"></td></tr>
</table>

<a id='a45c8b86-090f-49f6-8b74-f858745f3727'></a>

15

<!-- PAGE BREAK -->

<a id='f1491f89-bb84-4cbf-a335-ff24a1103a2e'></a>

Current as of 4/2
sing similar considerations, the projections for fare and tolls were

<a id='b1ecbf21-5192-4985-bac4-7cf94bb73d72'></a>

**extended through Q1 2022**
Ridership and traffic projections as % of monthly budget

<a id='6b347c1b-acc3-4cca-a5be-1f73022500c1'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent
only potential scenarios based on discrete data from one point in time.
They are not intended as a prediction or forecast, and the situation is
changing daily.

<a id='d2d4fb26-61b8-4f85-938c-ad9e76b64b81'></a>

<::Line chart showing Ridership and Traffic over time from March 2020 to March 2022, with two scenarios: Scenario 1 and Scenario 2. The y-axis for both charts is 'Percent' from 0 to 100. The x-axis is labeled with months and years (2020, 2021, 2022). A shaded vertical area from October to December 2020 is labeled 'Influenza season 2020/21'. A shaded vertical area from October to December 2021 is labeled 'Influenza season 2021/22'. A light blue shaded background covers the period from January 2021 to March 2022, with the text 'Further preliminary estimates were developed using assumptions on 2021' overlaid on it. The legend indicates 'Scenario 1' (dark blue line) and 'Scenario 2' (light blue line). A vertical dashed line at January 2021 is labeled 'Scenario 1: Vaccine first available'. Another vertical dashed line around August 2021 is labeled 'Scenario 1: Vaccine widely commercially available'. A text box around September 2021 is labeled 'Scenario 2: Vaccine not commercially available until Fall 2022'.

**Top Chart: Ridership**
- **Scenario 1 (dark blue line)**: Starts at ~55% in March 2020, drops to ~10% in April-May 2020, then gradually increases to ~60% by September 2020, stabilizes at ~55% from October to December 2020, then increases steadily from January 2021 to ~80% by July 2021, and remains stable at ~80% through March 2022.
- **Scenario 2 (light blue line)**: Starts at ~55% in March 2020, drops to ~10% in April-May 2020, gradually increases to ~40% by September 2020, drops to ~10% from October to December 2020, then gradually increases from January 2021 to ~80% by March 2022.

**Bottom Chart: Traffic**
- **Scenario 1 (dark blue line)**: Starts at ~70% in March 2020, drops to ~35% in April-May 2020, then gradually increases to ~75% by September 2020, drops to ~60% from October to December 2020, then gradually increases from January 2021 to ~85% by August 2021, and remains stable at ~85% through March 2022.
- **Scenario 2 (light blue line)**: Starts at ~70% in March 2020, drops to ~35% in April-May 2020, then gradually increases to ~55% by September 2020, drops to ~35% from October to December 2020, then gradually increases from January 2021 to ~80% by March 2022.
: line chart::>

<a id='fa365602-8823-41a6-81ef-e70c45a93c4f'></a>

16

<!-- PAGE BREAK -->

<a id='dc9c9bb8-430b-46ec-8768-a1e783a668fb'></a>

Contents

<a id='b024d4c7-092e-4145-bace-e99014d067ba'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='f9715b60-642e-4ac9-9778-e566882ca194'></a>

Fare and toll revenue methodology
**Non-fare revenue methodology**
Additional operating expense methodology
Operating gap
Impact of filling the gap

<a id='84922d8f-79df-4ed2-894a-b2ba600182fd'></a>

17

<!-- PAGE BREAK -->

<a id='14b00e65-67a6-4b5a-9a88-bc1fef1c6bbf'></a>

Overview of revenue components and forecast approach

<a id='02727cdb-f0fe-49da-a69f-29146554e328'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one point
in time. They are not intended as a prediction or
forecast, and the situation is changing daily.

<a id='5b2be637-9a5c-46da-a398-20e6e698e8c2'></a>

Focus of this chapter

<a id='8990df72-26e7-40fc-bd7b-029c3d7bb07c'></a>

# Fare and toll revenue

Applied different scenarios of how long the
current state of social distancing will last based
on actuals, and what ridership/mobility ramp-up
might look like after that. For those scenarios,
considered the impact of epidemiology, policy
effects, and behavioral changes

<a id='ba96e753-d838-454d-a80e-60f6b57cb276'></a>

v
Ridership/traffic curves

<a id='2520df2b-dc45-45c5-88bc-dc063d24f8e9'></a>

## Non-fare revenue

Identified five archetypes of tax or subsidy revenue – Employment, Real Estate and Mortgages, Sales, Business Income, and Mobility – each with a distinct driver. Created a multiplier for each archetype, which was applied to each source to forecast 2020 revenue

---

<br>

---

## Tax-specific change profiles

<a id='5adc6a26-4dc8-4433-9537-93e7e401edb2'></a>

18

<a id='a727ce01-19c1-4171-84f7-a5ba171dc71e'></a>

<::An icon of a plus sign inside a circle.: figure::>

<!-- PAGE BREAK -->

<a id='fb9753ed-46f2-46d4-ae0e-0d3dee03106f'></a>

Current as of 4/17

<a id='e6eb0ae7-b495-4c7f-847a-7f404cf9298e'></a>

Approach to forecasting tax and subsidy
revenue (1/2)

<a id='263f700a-2897-48f0-9c8d-bd6a1c5af5f2'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='6f41aac0-d462-4625-b3d7-dce56e29b857'></a>

Details to follow
<table id="19-1">
<tr><td id="19-2">Archetype</td><td id="19-3">Methodology for multiplier calculation</td><td id="19-4">Applicable MTA taxes</td></tr>
<tr><td id="19-5">Employment</td><td id="19-6">Projected changes in wages and salaries from employment for the NY counties served by MTA</td><td id="19-7">Payroll Mobility Tax</td></tr>
<tr><td id="19-8">Real Estate + Mortgages</td><td id="19-9">Application of historical % change of MRT and Urban tax (40%) during Great Recession</td><td id="19-a">MRT 1 + 2; Urban tax (MRT, Real Property Transfer Tax), Mansion Tax</td></tr>
<tr><td id="19-b">Sales</td><td id="19-c">% drop of projected 2020 GDP vs. 2019 actuals for sales tax relevant industries (retail and leisure and hospitality)</td><td id="19-d">MMTOA (MTA District Sales Tax, Hold Harmless for Clothing)</td></tr>
<tr><td id="19-e">Business Income</td><td id="19-f">Used corporate income tax elasticity during the Great Recession applied to % change between forecasted 2020 GDP and 2019 actual GDP</td><td id="19-g">MMTOA (Corp franchise tax, both Corp &amp; utilities taxes, insurance and bank taxes)</td></tr>
<tr><td id="19-h">Mobility</td><td id="19-i">Calculated based on expected traffic volume, incorporating thinking on epidemiological, behavioral, policy, and economic factors by using forecasted toll revenue as proxy</td><td id="19-j">MMTOA (PBT); PBT (Petroleum business tax, Motor fuel tax, MCTD taxicab tax, MTA passenger car rentals); FHV surcharge</td></tr>
<tr><td id="19-k">Other</td><td id="19-l">Average of all other tax multipliers</td><td id="19-m">MMTOA (investment income), &lt;1% of 2020 budget</td></tr>
</table>

<a id='807bf53d-142d-460f-ad90-ff6114884e9f'></a>

_**No or minimal anticipated change**_ _Not determined by underlying policy or economic driver_

<a id='ed2e9525-ef8c-4f2a-917a-ce45f8e8fe05'></a>

PBT (Motor vehicle fees); MRT adjustments; CBDTP; Internet marketplace tax; State and local subsidies (Local and State operating assistance, Station maintenance); other funding agreements (for MTA bus, SI Railway, Metro North), PMT replacement fund; B&T operating surplus transfer¹

<a id='6a7d1d77-d53a-4673-85ee-a57fbc02c363'></a>

1. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue losses

<a id='3fbebb5e-ff21-4197-a533-27ca4c3cab79'></a>

19

<!-- PAGE BREAK -->

<a id='15654c5b-6224-462e-8674-fb31d399b9cb'></a>

Current as of 4/17

<a id='05d66357-9510-41db-bac5-2577f34714db'></a>

Approach to forecasting tax and subsidy revenue (2/2)

<a id='81ce42a9-b3e5-406f-a109-5007f0a92c0a'></a>

(4/28/20) Please see disclaimer on page 3. These
analyses represent only potential scenarios based
on discrete data from one point in time. They are
not intended as a prediction or forecast, and the
situation is changing daily.

<a id='37d60f79-2501-46b5-bd0d-9095d2719174'></a>

Archetype Considerations for analysis/methodology What you need to believe 1 Employment <::Icon of three stick figures representing people or employment.: icon::> • Based on overall employment changes by quarter tied to macroeconomic modeling by industry for 12 MTA counties in New York State • Adjustments applied based on an analysis of jobs at risk, reducing the amount of wages and labor beyond employment loss to reflect reality of changing labor patterns (furloughs, loss of hours) by industry • Industries weighted by wage levels in New York State • Employment is going to track macroeconomic changes and impact the amount of payroll tax collected 2 Real estate + Mortgages <::Icon of a house.: icon::> • Based on performance of MRT (MRT-1, MRT-2 and MRT in Urban Tax) and Real Property Transfer Tax during Great Recession • Saw ~40% y.o.y. drop in real estate and mortgage-related taxes 2007-2008, with further declines in 2008-2009 • Applied that initial decline of 40% to each relevant tax, given the forecasting is for the first year of COVID-19 impact (2020) • There are two opposing forces at play right now: — This recession is likely going to be deeper/longer than the GR — At the same it may not be a housing real estate crisis, i.e. not the same expectations of credit drying up, refinancing going down etc. • Assume that those two effects will roughly offset each other so that using the GR to model the forecast is still applicable 3 Sales <::Icon of a shopping cart.: icon::> • Apply the % change y.o.y. for the 2020 GDP forecast (inflation adjusted) for MTA NYS counties vs. 2019 data for each quarter to the 2019 tax • Since ~20% of the tax base is from B2B, used weighted average of GDP change for Retail and Leisure/Hospitality (80%) + GDP of remaining industries (20%, proxy for B2B) to reflect underlying tax base • Sales tax will closely track GDP 4 Business Income <::Icon of a line graph with an upward trend.: icon::> • Assume that the elasticity of corporate income tax to GDP is the same as in the Great Recession and apply that factor to project 2020 data • Many of the considered taxes are surcharges on the State corporate income tax, so apply the same logic as to the tax itself • Great Recession is a good model for what is happening to the economy right now, i.e. that the elasticity relationship between change in tax and change in GDP during times of crises is constant/very similar 5 Mobility¹ <::Icon of a car.: icon::> • Based on projected decrease in toll revenue by month (see details on toll revenue projection and methodology) • Economic and public health policy decisions (social distancing, business closures etc.) have a large impact on mobility • Even after the crisis, there will likely be a "new normal" - below old levels

<a id='73cc52b8-ddc3-405d-a75a-fd733cdbf23f'></a>

1. Mobility assumptions explained in further detail in Fare revenue section

<a id='e9d8a7dd-b9f6-485a-b944-41d34ab60402'></a>

20

<!-- PAGE BREAK -->

<a id='76af94d5-9abb-4c6e-9c98-4604510106db'></a>

1 Economic scenario for change in employment used in the analysis

<a id='951636ea-79d3-497f-99ec-578bd12340ac'></a>

<::Change in Employment relative to Q4 2019: line chart::>Percent: The y-axis ranges from 0 to -18 in increments of 2. The x-axis shows time points from Q4 2019 to Q4 2020. A red line, labeled "Employment (MTA counties in NY)", shows the change in employment. The line starts at 0% in Q4 2019, remains at 0% in Q1 2020, drops to approximately -13% in Q2 2020, then further declines to approximately -15% in Q3 2020, and reaches approximately -17% in Q4 2020.

<a id='6fcf1faa-348f-4e4e-a123-c196f52e9e58'></a>

Source: Data tied to analysis of A1 scenario – see pages 22 and 23

<a id='e4af561d-8177-47f5-90b3-28993f79551b'></a>

Current as of 4/17
(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='f34a09ae-59eb-4759-aa3b-5321dbdb1bc9'></a>

Changes in employment levels for the NY MTA counties were modified using an analysis of "Jobs at Risk" to capture income impacts beyond just job loss (e.g., furloughs, lost hours)

<a id='c4534598-1a2f-48b4-b935-7999a459d0f9'></a>

Industries were also weighted by average income

<a id='208f6d2e-d5bd-4bf0-8f16-c9580450ce30'></a>

The modeled change in
income across all industries
in the NY MTA counties was
then used to predict
employment-related tax
income

<a id='9b13ada5-9d59-4423-a692-a603407d2f5f'></a>

21

<!-- PAGE BREAK -->

<a id='3de2e713-0468-43f3-86b9-a59e2fbbcf60'></a>

2
Historical real estate tax performance in the
Great Recession
$ Millions of tax received and % change from previous year

<a id='871d5a0a-93d3-4baf-b393-194a15a3af87'></a>

<table id="22-1">
<tr><td id="22-2"></td><td id="22-3">2007</td><td id="22-4">2008</td><td id="22-5">2009</td><td id="22-6">2010</td><td id="22-7">2011</td><td id="22-8">2012</td></tr>
<tr><td id="22-9">MRT-1</td><td id="22-a">460</td><td id="22-b">277</td><td id="22-c">150</td><td id="22-d">147</td><td id="22-e">160</td><td id="22-f">187</td></tr>
<tr><td id="22-g">Difference relative to prior year</td><td id="22-h"></td><td id="22-i">-40%</td><td id="22-j">-46%</td><td id="22-k">-2%</td><td id="22-l">9%</td><td id="22-m">17%</td></tr>
<tr><td id="22-n">MRT-2</td><td id="22-o">243</td><td id="22-p">142</td><td id="22-q">92</td><td id="22-r">92</td><td id="22-s">85</td><td id="22-t">92</td></tr>
<tr><td id="22-u">Difference relative to prior year</td><td id="22-v"></td><td id="22-w">-42%</td><td id="22-x">-35%</td><td id="22-y">0%</td><td id="22-z">-8%</td><td id="22-A">9%</td></tr>
<tr><td id="22-B">Total</td><td id="22-C">703</td><td id="22-D">419</td><td id="22-E">242</td><td id="22-F">239</td><td id="22-G">245</td><td id="22-H">280</td></tr>
<tr><td id="22-I">Difference relative to prior year</td><td id="22-J"></td><td id="22-K">-40%</td><td id="22-L">-42%</td><td id="22-M">-1%</td><td id="22-N">2%</td><td id="22-O">14%</td></tr>
<tr><td id="22-P">Real Property Transfer Tax (100%)</td><td id="22-Q">664</td><td id="22-R">389</td><td id="22-S">110</td><td id="22-T">138</td><td id="22-U">297</td><td id="22-V">322</td></tr>
<tr><td id="22-W">Difference relative to prior year</td><td id="22-X"></td><td id="22-Y">-41%</td><td id="22-Z">-72%</td><td id="22-10">25%</td><td id="22-11">116%</td><td id="22-12">9%</td></tr>
<tr><td id="22-13">Urban Mortgage Recording Tax (100%)</td><td id="22-14">318</td><td id="22-15">193</td><td id="22-16">56</td><td id="22-17">55</td><td id="22-18">95</td><td id="22-19">130</td></tr>
<tr><td id="22-1a">Difference relative to prior year</td><td id="22-1b"></td><td id="22-1c">-39%</td><td id="22-1d">-71%</td><td id="22-1e">-1%</td><td id="22-1f">72%</td><td id="22-1g">36%</td></tr>
<tr><td id="22-1h">Less 4% NYC DOT</td><td id="22-1i">-39</td><td id="22-1j">-23</td><td id="22-1k">-7</td><td id="22-1l">-8</td><td id="22-1m">-16</td><td id="22-1n">-18</td></tr>
<tr><td id="22-1o">Less 6% Paratransit</td><td id="22-1p">-59</td><td id="22-1q">-35</td><td id="22-1r">-10</td><td id="22-1s">-12</td><td id="22-1t">-24</td><td id="22-1u">-27</td></tr>
<tr><td id="22-1v">Total</td><td id="22-1w">884</td><td id="22-1x">524</td><td id="22-1y">150</td><td id="22-1z">174</td><td id="22-1A">353</td><td id="22-1B">407</td></tr>
<tr><td id="22-1C">Difference relative to prior year</td><td id="22-1D"></td><td id="22-1E">-41%</td><td id="22-1F">-71%</td><td id="22-1G">16%</td><td id="22-1H">103%</td><td id="22-1I">15%</td></tr>
</table>

<a id='0a6b14de-83a5-41d5-afed-2bef1c7586b4'></a>

MRT 1 & 2

<a id='ec077f15-531c-4eee-a772-ac3b3953fe79'></a>

Urban tax

<a id='bfbb33a8-cb6b-4292-a65c-312326cd916a'></a>

Source: MTA historical tax data

<a id='b0086575-57c3-41ec-9ba3-bb7bbeec94fc'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one point
in time. They are not intended as a prediction or
forecast, and the situation is changing daily.

<a id='9b165183-4c91-4fcf-a7cd-9925824b3ad5'></a>

The first year of the Great
Recession was used to
inform analysis of the first
year of the current crisis

<a id='8c9644a0-8ad9-4f48-afcf-f3b83c0017ec'></a>

While the magnitude of this
crisis is larger, it is not a
housing or liquidity crisis -
two counteracting effects
which were assumed to
roughly balance out

<a id='c830b13e-3b33-4c58-aad5-98c336f929fc'></a>

Used the historic
performances of the MTA's
real estate tax revenue to
capture potential
differences or similarities
between residential and
commercial real estate

<a id='3c15f346-26cf-4b8d-ab4b-d0bf4b65d6e3'></a>

22

<!-- PAGE BREAK -->

<a id='9c17f2e0-d208-4b3f-b9e2-2975828ad58b'></a>

<u>Preliminary</u>

<a id='1e8b9bc6-2e6b-414d-b125-272ad9a94b4d'></a>

# Economic scenario for change in GDP (1/2)

## Macroeconomic scenarios

<a id='95fed40d-053c-4ece-a4a2-6ae3b273fc43'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='97bd21c3-4075-4451-b700-e2b6b8408d5f'></a>

option Details to follow: [ ]

<a id='5f4a4f53-9475-48c3-b8ab-c8450dec90ea'></a>

Updated April 20, 2020

<a id='c4314487-007e-4f2b-ab57-3714f184a9f2'></a>

Scenarios for the Economic Impact of the COVID-19 Crisis
GDP Impact of COVID-19 Spread, Public Health Response, and Economic Policies

<a id='e79bf4a5-3583-40cd-898e-c8d3ccf15463'></a>

# Virus Spread &
# Public Health
# Response

Effectiveness of the public
health response
in controlling the spread
and human impact
of COVID-19

<a id='f40b846b-a68d-4686-8f65-d522e8f5e229'></a>

Rapid and effective
control of virus spread
Strong public health response succeeds
in controlling spread in each country
within 2-3 months

<a id='488a3b5c-b490-435c-b91b-a1c178818d0b'></a>

Effective response, but
(regional) virus recurrence
Initial response succeeds but is
insufficient to prevent localized
recurrences; local social distancing
restrictions are periodically reintroduced

<a id='727031ec-76f7-491c-83fb-962580d3a6cd'></a>

Broad failure of public
health interventions

Public health response fails
to control the spread of the virus
for an extended period of time
(e.g., until vaccines are available)

<a id='004bd4b1-1147-4aa3-bfd7-2c42727164b4'></a>

<::Figure: Two charts are presented side-by-side. The first chart, labeled "B1", displays a U-shaped curve on a simple x-y coordinate system. Below the chart, the text reads: "Virus contained, but sector damage; lower long-term trend growth". The second chart, labeled "A3", also displays a U-shaped curve on a simple x-y coordinate system. Below this chart, the text reads: "Virus contained, growth returns". Both charts illustrate a similar pattern of initial decline followed by recovery, with the text providing context for each scenario.: chart::>

<a id='48880bb5-bce5-4da1-aa56-63917a7ad164'></a>

<::B2chart showing a curve that drops sharply, then recovers slowly with small fluctuations, ending below the initial level.Virus recurrence, slow long-term growth insufficient to deliver full recovery: chart::><::A1chart showing a curve that drops sharply, then recovers slowly with small fluctuations, ending with a higher value than the previous chart.Virus recurrence; slow long-term growth with muted world recovery: chart::>

<a id='f4664339-72c0-4dad-9def-5b649573d890'></a>

<::Figure B3: Graph showing a curve that starts high, decreases sharply, and then flattens out, indicating a prolonged downturn without economic recovery.
Pandemic escalation, prolonged downturn without economic recovery
: figure::>
<::Figure B4: Graph showing a curve that starts high, decreases, and then slowly rises again, forming a U-shape, indicating a slow progression towards economic recovery.
Pandemic escalation, slow progression towards economic recovery
: figure::>

<a id='db16caf7-0e89-4278-a476-fd57c9684547'></a>

<::A2
[chart showing a V-shaped curve]
Virus recurrence; return to trend growth with strong world rebound
: chart::>

<a id='bb1c38e5-679e-4198-99b3-d67b71b0b80c'></a>

<::B5
A W-shaped curve, indicating a double dip or prolonged downturn before recovery.
Pandemic escalation, delayed but full economic recovery
:chart::>

<a id='ea95e880-f235-4278-b8d8-4147bf0fca8b'></a>

Ineffective
interventions
Self-reinforcing recession dynamics
kick-in; widespread bankruptcies and
credit defaults; potential banking crisis

<a id='eab87d32-d6ef-4c85-bf90-13e5837efce1'></a>

**Partially effective interventions**
Policy responses partially offset economic damage; banking crisis is avoided; recovery levels muted

<a id='7947c03e-a593-416b-af92-1029821e8cee'></a>

**Highly effective interventions**

Strong policy responses prevent
structural damage; recovery to pre-
crisis fundamentals and momentum

<a id='091518f3-264e-4348-ab7c-4423b69a2dcf'></a>

Knock-on Effects & Economic Policy Response
Speed and strength of recovery depends on whether policy moves can mitigate self-reinforcing recessionary dynamics (e.g., corporate defaults, credit crunch)

<a id='1941f061-9230-4cdc-accb-6d9cfa125704'></a>

23

<a id='60ff46c5-fe97-4b1b-bd40-fdde7fc29c93'></a>

A4

<::A chart with a V-shaped curve
: chart::>

Virus contained; strong growth rebound

<!-- PAGE BREAK -->

<a id='439e0e7f-c83b-409a-9494-f1849a455f23'></a>

<::logo: [Unknown]3/4A dark circular shape contains the text "3/4" in white.::>

<a id='5d12a2ff-593c-486e-bf16-a7cc595194d1'></a>

Preliminary

<a id='277d543e-44b3-4f18-a272-2995615f2f5d'></a>

Economic scenario
for change in GDP
(2/2)

Scenario A1 used for analysis

<a id='92916515-6fb2-4b8d-8c53-b57de01a3fe5'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='a0dc42b5-4258-4da5-ad07-6ef79a587274'></a>

Updated April 20, 2020

**Pace of decline of economic activity in Q2 2020 is likely to be the steepest since decline since WWII**

---
High frequency indicators show the drop has already started in Q1

<a id='bc2adb11-04a8-4b9a-ad5d-182e5043c93e'></a>

United States, comparison of post-WWII recessions% real GDP draw-down from previous peak<::Line chart titled "United States, comparison of post-WWII recessions" showing "% real GDP draw-down from previous peak" on the y-axis (from 0 to -14) and quarters after peak (+Q1 to +Q14) on the x-axis.The chart displays multiple lines representing different recessions or scenarios:
- A black line labeled "Scenario A3" drops to a low of -8% by +Q2, then partially recovers, then drops again, and finally recovers to 0 by +Q10.
- A dark blue line labeled "Scenario A1" drops to a low of -12.5% by +Q4, then gradually recovers to 0 by +Q13.
- A light purple line labeled "73 oil shock" drops to about -3% by +Q3 and recovers to 0 by +Q13.
- A light blue line labeled "81 recession" drops to about -4% by +Q4 and recovers to 0 by +Q13.
- A medium blue line labeled "Global financial crisis" drops to about -4.5% by +Q5 and recovers to 0 by +Q12.
- Several other unlabeled lines (in various shades of blue and green, some dashed) show different recession profiles, generally dropping between -2% and -4% and recovering within +Q8 to +Q12.
: chart::>Source: Historical Statistics of the United States Vol 3, Bureau of economic analysis, McKinsey team analysis, in partnership with Oxford EconomicsMcKinsey & Company 12

<a id='a6b4bb3b-a998-4fad-a125-5c4cc94b7c28'></a>

12

<a id='84b6c1ca-42d9-432e-919e-86b0591e3eee'></a>

24

<!-- PAGE BREAK -->

<a id='fc4b405f-7985-49d4-95cf-075ec3f3ea56'></a>

5 Mobility-related tax methodology follows toll projections

<a id='eee26145-f2e9-43a3-bf85-ac9efdf3dfb6'></a>

Potential scenarios for traffic development through the end of 2020% of base level traffic (previous year)<::chart: line chart showing the percentage of base level traffic (previous year) on the y-axis from 0 to 100, and months from Jan to Dec on the x-axis.Two scenarios are plotted:1. Scenario 1: earlier containment and recovery (dark blue line):Jan: 100%, Feb: 100%, Mar: 70%, Apr: 35%, May: 35%, Jun: 40%, Jul: 55%, Aug: 70%, Sep: 75%, Oct: 65%, Nov: 65%, Dec: 65%.2. Scenario 2: delayed containment and recovery (light blue line):Jan: 100%, Feb: 100%, Mar: 85%, Apr: 35%, May: 35%, Jun: 40%, Jul: 45%, Aug: 50%, Sep: 55%, Oct: 35%, Nov: 35%, Dec: 35%.::>

<a id='057f129f-662b-427f-ae41-2604f9853ff4'></a>

Current as of 4/17

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='ddce7681-560c-4e50-ae3e-192d714c518f'></a>

Tolls were assumed to be
an indicator for relative
performance of mobility-
driven taxes (e.g., PMT)

<a id='680bd238-7ad0-46fd-9938-d30c60b2a637'></a>

These taxes were modeled
using the toll curves
developed during the toll
revenue analysis

<a id='b0b2a528-3514-4d08-b2c9-e30415597e83'></a>

25

<!-- PAGE BREAK -->

<a id='359d47db-755c-45a5-bc69-790103688bb4'></a>

Resulting non-fare revenue modeling for 2020 by groups of taxes

<a id='e8793063-caf8-46c4-b601-b57415e56df2'></a>

Current as of 4/17

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='b4210e98-7cd2-439b-a021-ddb0c948dbd7'></a>

<table id="26-1">
<tr><td id="26-2">Tax group</td><td id="26-3">Original 2020 Budget, $B</td><td id="26-4">Projected losses in 2020, $B</td><td id="26-5">Decrease projected for 2020, %</td></tr>
<tr><td id="26-6">Mobility</td><td id="26-7">1.9</td><td id="26-8">(0.4) - (0.5)</td><td id="26-9">-23 to -29%</td></tr>
<tr><td id="26-a">Employment</td><td id="26-b">1.6</td><td id="26-c">(0.3)</td><td id="26-d">-17%</td></tr>
<tr><td id="26-e">Real Estate</td><td id="26-f">1.5</td><td id="26-g">(0.4)</td><td id="26-h">-27%</td></tr>
<tr><td id="26-i">Business income</td><td id="26-j">1.1</td><td id="26-k">(0.3)</td><td id="26-l">-30%</td></tr>
<tr><td id="26-m">Sales</td><td id="26-n">0.9</td><td id="26-o">(0.3)</td><td id="26-p">-32%</td></tr>
<tr><td id="26-q">Other</td><td id="26-r">0.02</td><td id="26-s">(0.0)</td><td id="26-t">-42 to -44%</td></tr>
<tr><td id="26-u">No change¹</td><td id="26-v">2.1</td><td id="26-w"></td><td id="26-x">0%</td></tr>
<tr><td id="26-y">Total²,³</td><td id="26-z">8.4</td><td id="26-A">(1.6) – (1.8)</td><td id="26-B">-19 to -21%</td></tr>
</table>

<a id='29191e08-29f8-41d6-a3a1-c206119a7844'></a>

1. 25% of the original 2020 budget was predicted to remain unchanged because it represented legal commitments to provide funds, or because it appeared the underlying drivers were unlikely to shift significantly in 2020 (e.g., Payroll Mobility Tax Replacement Funds, Internet Marketplace Tax, Motor Vehicle Fees for registering vehicles)
2. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue losses
3. Totals may not add due to rounding. Total also does not reflect the impact of adjustments (applies to Urban Tax, the "Mansion Tax", and the Internet Marketplace Tax)

<a id='0da233da-af3e-4fd8-ad2e-31e5f0d9f846'></a>

26

<!-- PAGE BREAK -->

<a id='f94f19ab-adc1-44c9-ad09-986def1a5948'></a>

Using similar considerations, the projections for non-fare revenue were extended through 2021

---

Scenario assumptions and resulting estimate of financial impact

<a id='6f68efac-8edd-4827-934b-4719f15e07ba'></a>

# Approach to estimating non-fare revenue for 2021

## Major assumptions for non-fare

### Mobility
Mobility will continue to track toll revenue

### Employment
Employment will improve from Q4 of 2020 but slowly and will continue to reflect at-risk jobs

### Real estate
Second year of this crisis will follow GDP growth; second year of the Great Recession is not a good proxy

### Sales
Sales taxes will track GDP growth

### Business income
Business income will lag GDP growth (based on historical precedent)

<a id='bbec2a5c-5933-4e3c-9f84-68c025d7918c'></a>

<::
Financial impact
on fare and toll
revenue, in $B
(Image of a piggy bank icon)

| | Budget¹ | Projected delta |
| :--- | :--- | :--- |
| CY 2020 | 8.4 | (1.6) - (1.8) |
| CY 2021 | 8.4 | (1.8) - (2.0) |
: table::>

<a id='04791379-40b9-48d4-a191-b27447e556b5'></a>

1. As per the 2020 February Financial plan. 2021 budget deltas do not take into account any revisions to revenue expectations that may have taken place since releasing the plan (e.g., a revised view on revenue from congestion pricing); they are deltas from the plan as-released.

<a id='579b5540-e09a-45fe-b612-a3ee3dadb9fe'></a>

Current as of 4/24

<a id='4f136f89-f259-4afd-8bf3-f98f99e26441'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='b770087e-758e-4034-8508-09423501cdc2'></a>

Underlying economic
conditions could be similar
or more severe in 2021 as
in 2020 but potentially
offset by an improvement in
mobility

<a id='8e443dc4-f594-486a-a75b-be6d5af1fee9'></a>

There are areas where MTA
may make decisions that
will impact the overall totals
(e.g., capital fund
allocations)

<a id='4691dfb2-2283-42c2-9fa9-8e18eb485885'></a>

27

<!-- PAGE BREAK -->

<a id='06cace25-daf9-4953-a01e-5d760181e7df'></a>

Contents

<a id='9e346c24-e0dc-42e5-9a70-3b92cacb1bff'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='575665ff-10ee-4455-8275-bfe8939a9a65'></a>

Fare and toll revenue methodology
Non-fare revenue methodology

<a id='4a503e2b-e0fc-42b9-b39a-d3a92987f694'></a>

**Additional operating expense methodology**

Operating gap

Impact of filling the gap

<a id='4870a314-918b-43b3-9d77-7537d7310656'></a>

28

<!-- PAGE BREAK -->

<a id='6ea6fe4c-f292-4a9f-b355-18fb10a77fe1'></a>

Current as of 4/17

<a id='17349b44-ea2f-4fbb-a17f-d6f2ade13627'></a>

Methodology for initial estimate of additional operating expenses

<a id='a74296f3-2ab5-40be-ab00-bb3af24c8b50'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='552e91d7-c579-44e6-b968-8882fcc585d9'></a>

# Top-down

Identified the overall operating expenses in the 2020 MTA budget that would be impacted by increased public health measures (e.g., materials) and applied a benchmark of ~6% increase, as determined from the change in Hong Kong MTR financials during the peak month of SARS in 2003

**$0.4-0.5B**

<a id='af9da3a6-14dd-45dc-bb63-3b803c2e83a5'></a>

Details to follow

## Bottom-up

Used the existing MTA estimate for COVID-19 related expenses as a base and built in additional expense items or expense increases based upon common policies enacted by transit agencies around the world for responses to COVID-19 and SARS

$0.7-$0.8B

<a id='47f4fd47-8412-4d0d-a9be-794ebcf7ff20'></a>

Expenses do not include:
* Any new capex (e.g., ventilation upgrades, thermal imaging, re-furbishing breakrooms, etc.)
* Costs related to further service changes in response to the pandemic

<a id='248d27f6-c2c5-4020-9ef6-026a3e95d5e6'></a>

29

<a id='7fb92a1e-d2ef-489a-a2f1-a0a6286e2366'></a>

<::transcription of the content
: plus sign icon inside a circle::>

<!-- PAGE BREAK -->

<a id='0a6a5caa-1e8a-4b0e-80a5-4eb00e627fb7'></a>

Current as of 4/22

<a id='4d4654b9-1722-4806-be66-44b76afc9bb5'></a>

**Incremental operating expenses may increase $0.7-$0.8B in 2020**
Expense assumptions for 2020 from a "bottom up" perspective
---

<a id='acb6ff77-34d0-4189-870e-eac570cf9b35'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='bb780249-0771-4393-86dc-b654cf9ace07'></a>

Preliminary

<a id='e89ec79a-482e-470f-8449-893e89c06903'></a>

Descriptions of expenses considered for 2020

<a id='63809d3b-a19c-4434-97c5-f8f43260f31e'></a>

<table><thead><tr><th>Drivers of operating expenses</th><th>Type</th><th>Description</th><th>Examples (non exhaustive)</th></tr></thead><tbody><tr><td rowspan="3"></td><td>"Ongoing"</td><td>Activities already begun by March that are likely to continue through the year</td><td>OHS hotline and current level of temperature testing, cleaning, and PPE for employees</td></tr><tr><td>"Expansion"</td><td>Extending existing activity to larger populations or additional locations</td><td>Additional temperature testing and adding some COVID-19 tests for employees, limited expansion of police presence</td></tr><tr><td>"New"</td><td>Net new activity not yet contemplated but seen in peer systems or under active discussion as potential solutions for transit agencies</td><td>Daily cleaning of buses and subway and commuter rail cars</td></tr></tbody></table>

<a id='1811dbf5-f739-4bd3-8f21-e49eecddc3d3'></a>

Incremental
expenses
<::An outline icon of a piggy bank with a coin dropping into its slot.: figure::>

<a id='9efd0b1d-d8da-407c-b3e1-407afb77dc6f'></a>

1
<table id="30-1">
<tr><td id="30-2" colspan="2">Lower range or 2020, $M</td><td id="30-3">Total</td><td id="30-4">Q1</td><td id="30-5">Q2</td><td id="30-6">Q3</td><td id="30-7">Q4</td></tr>
<tr><td id="30-8"></td><td id="30-9">Ongoing</td><td id="30-a">385</td><td id="30-b">37</td><td id="30-c">112</td><td id="30-d">117</td><td id="30-e">118</td></tr>
<tr><td id="30-f"></td><td id="30-g">Expansion</td><td id="30-h">67</td><td id="30-i">4</td><td id="30-j">21</td><td id="30-k">21</td><td id="30-l">21</td></tr>
<tr><td id="30-m"></td><td id="30-n">New</td><td id="30-o">213</td><td id="30-p">0</td><td id="30-q">63</td><td id="30-r">88</td><td id="30-s">61</td></tr>
<tr><td id="30-t"></td><td id="30-u">Total</td><td id="30-v">665</td><td id="30-w">41</td><td id="30-x">196</td><td id="30-y">227</td><td id="30-z">201</td></tr>
</table>

<a id='50720f5d-9532-4e3d-920e-4d74c234ee08'></a>

Higher range
for 2020, $
<table id="30-A">
<tr><td id="30-B">M</td><td id="30-C">Total</td><td id="30-D">Q1</td><td id="30-E">Q2</td><td id="30-F">Q3</td><td id="30-G">Q4</td></tr>
<tr><td id="30-H">Ongoing</td><td id="30-I">402</td><td id="30-J">37</td><td id="30-K">112</td><td id="30-L">120</td><td id="30-M">132</td></tr>
<tr><td id="30-N">Expansion</td><td id="30-O">78</td><td id="30-P">4</td><td id="30-Q">25</td><td id="30-R">25</td><td id="30-S">25</td></tr>
<tr><td id="30-T">New</td><td id="30-U">297</td><td id="30-V">0</td><td id="30-W">66</td><td id="30-X">109</td><td id="30-Y">123</td></tr>
<tr><td id="30-Z">Total</td><td id="30-10">777</td><td id="30-11">42</td><td id="30-12">203</td><td id="30-13">253</td><td id="30-14">280</td></tr>
</table>

<a id='e1191c74-f514-4e02-8221-ea1e6ccef46a'></a>

30

<!-- PAGE BREAK -->

<a id='e62d5595-b4a3-4ec2-8015-eec43eb53dac'></a>

Contents

<a id='30c99503-9681-4d4a-a1e0-95fea01e9dc4'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='362fabec-6d08-4efc-a10d-83d7170751a7'></a>

Fare and toll revenue methodology
Non-fare revenue methodology
Additional operating expense methodology
**Operating gap**
Impact of filling the gap

<a id='c2d836b2-f8d2-4af4-b2d5-e014f782f3cd'></a>

31

<!-- PAGE BREAK -->

<a id='550cce84-4ffb-49a8-bc43-e09cd79006f2'></a>

Current as of 4/17

<a id='baf1e8ca-4316-481d-9f85-8c0caf4faa64'></a>

Summary of financial impacts across revenue
streams for 2020
2020 Estimates

<a id='c5914c68-4fea-409d-a33e-60c18684e8f8'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='5d55dbd3-0ebb-47cf-8e85-5c17ea6e8185'></a>

Preliminary estimates, $ billions

<a id='8841307c-ed4f-40c0-8b77-8531d90ac331'></a>

<table id="32-1">
<tr><td id="32-2"></td><td id="32-3">Earlier containment and recovery</td><td id="32-4">Delayed containment and recovery</td></tr>
<tr><td id="32-5">Fare revenue</td><td id="32-6">(3.9)</td><td id="32-7">(4.9)</td></tr>
<tr><td id="32-8">Toll revenue</td><td id="32-9">(0.8)</td><td id="32-a">(1.0)</td></tr>
<tr><td id="32-b">Non-fare revenue¹</td><td id="32-c">(1.6)</td><td id="32-d">(1.8)</td></tr>
<tr><td id="32-e">Additional operating expenses (preliminary)</td><td id="32-f">(0.7)</td><td id="32-g">(0.8)</td></tr>
<tr><td id="32-h">Total gap</td><td id="32-i">(7.0)</td><td id="32-j">(8.5)</td></tr>
<tr><td id="32-k">CARES</td><td id="32-l">3.8</td><td id="32-m">3.8</td></tr>
<tr><td id="32-n">Additional</td><td id="32-o">(3.2)</td><td id="32-p">(4.7)</td></tr>
</table>

<a id='6b0abaa5-3df5-44eb-a2c5-756209d8de20'></a>

**Critical to note about these estimates**
**Non-fare revenue:**

Initial estimates are based on quantitative underlying drivers of various sources of revenue.
* Further reconciliation will be required with the State budget, e.g., MMTOA
* There are also areas where MTA may make decisions that will impact the overall totals (e.g., capital fund allocations)

<a id='b9b7ef47-fffb-46d3-8d00-59ea83d724d8'></a>

**Fare and toll revenue:**
Fare and toll revenue estimates are calculated
based on anticipated epidemiological
and economic scenarios, including inputs
from historical periods and current data

<a id='10b133a2-9ab9-4728-9fae-d8b8ca95a599'></a>

1. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue losses

<a id='acadba3a-4237-43a0-b8ab-5e374465a751'></a>

32

<!-- PAGE BREAK -->

<a id='71d703ab-387f-4432-b127-8a4c92b9dff1'></a>

Current as of 4/24

<a id='3311bcbb-2f13-433c-b0e1-4383feb76011'></a>

Preliminary summary of initial revenue estimates for out years
2020 and 2021 estimates

<a id='57538a67-66d4-4c53-86c9-281d45009ac0'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='720c23b3-ac7f-4f41-b1cb-aec22244cb12'></a>

Preliminary estimates of deltas to budget, $ billions
<table id="33-1">
<tr><td id="33-2"></td><td id="33-3" colspan="2">2020</td><td id="33-4" colspan="2">2021</td></tr>
<tr><td id="33-5"></td><td id="33-6">Earlier containment and recovery</td><td id="33-7">Delayed containment and recovery</td><td id="33-8">Earlier containment and recovery</td><td id="33-9">Delayed containment and recovery</td></tr>
<tr><td id="33-a">Fare revenue</td><td id="33-b">(3.9)</td><td id="33-c">(4.9)</td><td id="33-d">(2.2)</td><td id="33-e">(4.1)</td></tr>
<tr><td id="33-f">Toll revenue</td><td id="33-g">(0.8)</td><td id="33-h">(1.0)</td><td id="33-i">(0.5)</td><td id="33-j">(1.0)</td></tr>
<tr><td id="33-k">Non-Fare revenue</td><td id="33-l">(1.6)</td><td id="33-m">(1.8)</td><td id="33-n">(1.8)</td><td id="33-o">(2.0)</td></tr>
<tr><td id="33-p">Operating expenses (preliminary)</td><td id="33-q">(0.7)</td><td id="33-r">(0.8)</td><td id="33-s">(0.7)²</td><td id="33-t">(0.8)²</td></tr>
<tr><td id="33-u">Total revenue gap³</td><td id="33-v">(7.0)</td><td id="33-w">(8.5)</td><td id="33-x">(5.1)</td><td id="33-y">(7.8)</td></tr>
<tr><td id="33-z">Size of range</td><td id="33-A"></td><td id="33-B">1.5</td><td id="33-C"></td><td id="33-D">2.7</td></tr>
</table>

<a id='a12a46e4-6cca-406b-9318-bec5faec0bf0'></a>

1. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue loss
2. Operational expenses may vary in 2021 depending on MTA's decisions on how to respond to the crisis
3. Totals may not add due to rounding

<a id='5c9bba52-7d89-4e47-9b3a-42b545a65680'></a>

33

<!-- PAGE BREAK -->

<a id='2d9e9198-08a3-4c46-ab98-5c928ddbdabd'></a>

## Contents

<a id='07d3cb43-f047-4d1c-8b9b-e0c7225cbad5'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.
---


<a id='bc2e15c7-89ab-48be-a679-28e9fb8dbbcf'></a>

Fare and toll revenue methodology
Non-fare revenue methodology
Additional operating expense methodology
Operating gap
**Impact of filling the gap**

<a id='10dd6a36-9ef5-48d8-9c2c-04a5fb6fde9e'></a>

34

<!-- PAGE BREAK -->

<a id='ce4f7db1-e257-49fb-8773-e3ee2a2ac514'></a>

Current as of 4/17

<a id='08f34866-4dcc-4183-80f4-e3b33bb869b5'></a>

## Estimating potential economic impacts
Possible effects of spending

<a id='2c53814e-abb2-47bd-83b2-a74386c5ed0f'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='2eb2e55d-e8e8-48dd-8aaf-b90f324cb339'></a>

1 The NYC metro area is an engine of the overall national economy

## Rationale
NYC metro's GDP of $1.7 trillion in 2017 is the largest of any metro area in the U.S.
In recent years, NYC Metropolitan Statistical Area (MSA) has contributed the greatest share of U.S. and global nominal GDP growth of all metro areas. NYC metro has generated 8.3% of all U.S. nominal GDP growth and 2.6% of all global nominal GDP growth between 2010 and 2017

<a id='48c89110-b146-4404-9eb0-a375834276cc'></a>

2 NY MTA is a critical part of what makes the NYC MSA economy possible

The MTA carries 8M people every day, allowing a large portion of the NYC MSA to get to work
* 87% of people who enter the Manhattan Central Business District during the peak do so through bus, subway, or railroad
* Every day Manhattan goes from a population of 1.6M residents to a daytime population of nearly 4M people, including nearly 1.6M commuters and 400K day-trippers
* If 1.6M commuters drove in their own automobiles, the parking alone would occupy 520M SF of space, this would require paving over 80% of Manhattan for a parking lot; or replacing Central Park with a 13 story parking garage

<a id='53d31928-b71b-40a1-b244-1f48a663831f'></a>

3 NY MTA represents the bulk of losses in transit ridership and fares in the US

Across the US, major transit systems - CTA, LA Metro, MBTA, WMATA, SEPTA, NJ Transit, and others - have all lost 80-90% of ridership in transit in recent weeks
MTA represents 40-50% of the total loss in ridership in the United States

<a id='b2fc5425-4900-46a5-9792-b73c947317da'></a>

4
Spending on the MTA has the potential to drive national economic impact

Preliminary analysis of impact shows a $3.2-4.7B investment has a $6.2-9.1B total national GDP impact and generates 75-109K jobs

<a id='b1dfdb44-d189-4c7a-8804-5e7a4fe53620'></a>

Source: Press search, FTA NTD data, NYMTC data, BEA multiplier analysis

<a id='1790f5f0-2288-4bdf-ab9f-916c427578bf'></a>

35

<!-- PAGE BREAK -->

<a id='68f65944-e870-4561-afa0-524b61a76b66'></a>

3 **MTA carries the most riders with majority of fare revenue**
Compared with the Top 12 US transit agencies

---

<a id='123460c5-a317-403b-9aef-9ca13855dfb1'></a>

Ridership share among the top 12 US transit agencies¹, Percent<::chart: Donut chart showing ridership proportion among the top 12 US transit agencies.
- MTA: 57%
- CTA: 7%
- LA Metro: 6%
- WMATA: 6%
- MBTA: 5%
- SEPTA: 5%
- NJ Transit: 4%
- SF Muni: 3%
- King County Metro: 2%
- BART: 2%
- MARTA: 2%
- Denver RTD: 2%
Annotation: Assuming decline system proportion the portion incurred.
::>1. Based on 2019 monthly ridership data
2. Based on 2018 fare revenue data (2017 for MTA MNR)

<a id='8d8a300b-562b-4b88-aaf7-0588c638faf3'></a>

Source: National Transit Database (NTD)

<a id='b508fa2f-5bc9-4d6d-a351-d6d58b628e54'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='f61643cc-63ed-481c-a627-788aad0fe1fc'></a>

Fare revenue share among the top 12 US transit agencies², Percent <::A donut chart titled "Fare revenue proportion" displays the fare revenue share among the top 12 US transit agencies. The segments are: MTA 56%, NJ Transit 9%, WMATA 6%, MBTA 6%, CTA 5%, BART 4%, SEPTA 4%, LA Metro 3%, King County Metro 2%, SF Muni 2%, Denver RTD 1%, and MARTA 1%. A speech bubble associated with the chart contains the text: "percentage hip across re revenue Iso represent fare losses ystem during s".: chart::>

<a id='2096ba47-f9be-45b3-a4a6-928eb1495d3b'></a>

36

<a id='b4be64b6-9f0b-45f6-ab78-e3d6ce08fb98'></a>

ng similar
s in riders
s, these fa
hs would a
on of total
by each sy
the crisi

<!-- PAGE BREAK -->

<a id='69a375fd-6451-4be0-ad06-8807ac6f1cd2'></a>

4. Replacing lost operating funds may create up to $9.1B in GDP impact and 109K jobs

<a id='8c6d92c5-6227-4f08-becf-0cd84e58cfa7'></a>

<table id="37-1">
<tr><td id="37-2"></td><td id="37-3">Impacts</td><td id="37-4">Net impact</td><td id="37-5">US direct impact</td><td id="37-6">Total value add with Induced</td></tr>
<tr><td id="37-7" rowspan="2">Earlier containment and recovery</td><td id="37-8">GDP</td><td id="37-9">$3.18B</td><td id="37-a">$1.93B1</td><td id="37-b">$6.17B3</td></tr>
<tr><td id="37-c">Jobs</td><td id="37-d">$3.18B</td><td id="37-e">31,6312</td><td id="37-f">74,6483</td></tr>
<tr><td id="37-g" rowspan="2">Delayed containment and recovery</td><td id="37-h">GDP</td><td id="37-i">$4.66B</td><td id="37-j">$2.83B1</td><td id="37-k">$9.05B3</td></tr>
<tr><td id="37-l">Jobs</td><td id="37-m">$4.66B</td><td id="37-n">46,3522</td><td id="37-o">109,3903</td></tr>
</table>

<a id='3bd4eb83-8bcf-49bc-b2b5-035071c6c597'></a>

1. Conversion to GDP (Value Added) using Valued Added to Sales multiplier for Mixed Mode Transit Systems NAICS code
2. Conversion to Jobs using Job to Sales multiplier for Mixed Mode Transit Systems NAICS code
3. Uses BEA multipliers to translate direct effect into total impact (including indirect and induced)

<a id='f7934859-70a2-492f-9bab-28b4c3f39413'></a>

Source: Bureau of Economic Analysis

<a id='54c7130c-8b17-4017-9bb0-530946b46721'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='7812fb4c-176f-47cf-b558-f77b7a91bfe7'></a>

Replacing $3.2 to $4.6B in
operating funds may translate into
a direct value-add (GDP) impact
of between $1.9 and $2.8B
and between 32 and 46K jobs

<a id='f47dfd2a-2358-4814-8f47-e85a4a3e1ef6'></a>

Using BEA multipliers, this GDP
**impact could increase to**
**between $6.2 - $9.1B nationally,**
**and 75 and 109K jobs,** when all
indirect and induced impacts
are accounted for

<a id='58fce402-9be1-46b9-b544-c3f53764b3e7'></a>

37