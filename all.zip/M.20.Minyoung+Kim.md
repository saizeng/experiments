<a id='08d1ee71-5ca0-4019-bfb8-dc67ba6ea7b5'></a>

<::A digital illustration featuring a blue wireframe model of a human body, with a partial view of its skeletal structure. In the background, several hexagonal icons are visible, representing concepts such as an eye, lungs, and a smartphone, suggesting themes of health, technology, and human interface. A glowing circular interface element is at the bottom.: figure::>
l
i
i
ñ
F

<a id='ad2bc4e8-aa14-4bd2-99de-d920e4374489'></a>

McKinsey&Company

<a id='39dc545d-a828-4b9c-8124-16ebfefce187'></a>

Current perspectives on Medical Affairs
in Japan

<::JAPAN MEDICAL AFFAIRS SUMMIT logo with a red circle and an ECG line illustration.
: figure::>

February 8, 2018

<a id='89ed8e0a-9c63-4793-981d-90ac087da69f'></a>

<::AN
DICAL AFF.
SUM
: figure::>

<a id='1d4e4352-413d-468e-8ff7-16929a48ee61'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is
strictly prohibited

<a id='6f03c514-dc38-4648-ae69-7edc7661a1cd'></a>

<::A close-up photograph shows a person's hands holding a dark blue smartphone. The person is wearing a white long-sleeved shirt. Abstract blue and white digital graphic overlays are visible on the image.: photograph::>CONFIDENTIAL AND PROPRIETARYAny use of this material without specific permission of McKinsey & Company isstrictly prohibited

<!-- PAGE BREAK -->

<a id='2aebc2ce-559a-4003-92ba-26d3b0581e66'></a>

Five+ years ago, Medical Affairs played primarily a support role

<a id='62c29c35-fd22-4e57-a853-8b42610a5718'></a>

<::An image of a laboratory with two female scientists. In the foreground, a scientist wearing a white lab coat and safety glasses is stirring a red liquid in an Erlenmeyer flask on a white lab bench. Next to her, there are beakers with yellow and orange liquids, and various lab equipment including a stirrer. In the background, another scientist in a lab coat is seated at a lab bench, working with some apparatus. The lab is brightly lit and features white cabinets and counters. A blue banner overlays the top portion of the image, displaying the text "R&D" in white, bold letters.: figure::>

<a id='5223b176-0a58-447a-93c7-f77b3fd2ded5'></a>

<::A blue banner with the text "Commercial" is at the top. Below the banner, a woman in a grey pinstripe suit and a man in a white lab coat and blue tie are shaking hands over a white counter. The background features green plants. A dark blue arrow points upwards from the bottom of the image.: figure::>

<a id='ae4989b0-3941-4cfa-b8d5-49ec8b01bbec'></a>

<::A group of medical professionals, with a man and a woman in the foreground looking at a clipboard. The man is wearing a white lab coat and a tie, smiling, and holding a pen. The woman is also wearing a white lab coat with a stethoscope around her neck, gesturing with her hand. Other medical staff are blurred in the background. A blue banner across the top reads "Medical Affairs".: photo::>

<a id='3f41e4be-9575-48b3-8747-6cacddc7c2be'></a>

"Commercial roles matter, Medical Affairs is there to support"

<a id='22837329-2b6c-436d-ae92-ad9ae67af250'></a>

McKinsey & Company

<a id='db996ff1-2ec8-4737-8721-9cab0761e24d'></a>

2

<!-- PAGE BREAK -->

<a id='25954a10-f71f-4b4c-bb3f-7ec3d86fb1c1'></a>

Today, the demands on Medical Affairs are rapidly growing globally

<a id='a56245a3-ebaf-402a-830a-201451836506'></a>

New decision-makers

<a id='5094d987-e490-4dcb-bd8e-4d15a28c0d4d'></a>

<::figure: A diagram illustrating "Emerging demands" at its center, surrounded by six circular images each representing a contributing factor. The central circle contains the text "Emerging demands" and three upward-pointing arrows. The surrounding circles are:
1. Top-left: A stethoscope on an American flag, labeled "Changing regulatory environment."
2. Middle-left: Two people in business attire seated in a modern building, labeled "Evolving commercial model."
3. Bottom-left: A person in a white coat (doctor) using a laptop, labeled "Wide-spread adoption of technology."
4. Bottom-right: A blue bar and line graph, labeled "More data and transparency."
5. Middle-right: A hand pointing at a computer screen displaying chemical structures, labeled "Increasingly complex science."
6. Top-right: A document with the word "VALUE" highlighted in green, next to a green marker. The text visible on the document includes "VALUATION," "1. estimate," "2. act," and "VALUE worth of a thing that will have." This is labeled "Broader definition of value."::>

<a id='35683b6d-93d6-4206-8869-d7554a4e6a5f'></a>

which a prom
It includes n
grant, and
love and a

ALUATIO
1. esti wor
2. act stimati

ALUE worth of
thing that will h

<a id='43b2898f-d337-4fa7-a771-9b71319a712e'></a>

SOURCE: Medical Affairs Leader Forum

<a id='b57a369a-b7d4-4942-b862-fa582b568b68'></a>

McKinsey & Company

<a id='1a4a5a39-257f-4916-9541-7337557ffa4a'></a>

3

<!-- PAGE BREAK -->

<a id='54944e65-cdde-4d64-9fdb-106136248bcd'></a>

Similar changes and demands are arising in Japan

<a id='267921ac-1e02-4387-ac9e-66a42a77a83d'></a>

<::logo: [Japan] [No readable text] A red circle with a white outline is centered on a white background.::>

<a id='b653b81d-a2e1-44a5-b8bf-a5f574d85aa6'></a>

## New decision-makers
*   Increasing use of clinical guidelines by the government

## Increasingly complex science
*   New technology such as CAR-T and gene therapy in pipeline

## Wide-spread adoption of technology
*   Increasing adoption of digital channel by HCPs

<a id='8f264633-76c0-4797-92b5-73f313c960e7'></a>

<::A close-up image of a dictionary page with the word "VALUE" highlighted in green by a marker.: image::>Broader definition of value- Ongoing HTA pilot and futureintegration into price revisionscheme<::A blue-toned bar chart with an overlaid line graph and a grid background, symbolizing data and transparency.: chart::>More data and transparency- Full launch of MID-NET fromFY 2018

<a id='b5fb4e3d-64c5-464b-8c8c-b4557d26110b'></a>

ALUABLE
which a prom
It includes 2
grant, and
love and a

ALUATIO
1. estiv
2. act
WOL
stimat
ALUE worth of a

<a id='3f4de2ad-35d0-4954-b004-a201c5668618'></a>

Evolving commercial model
* MR visit restrictions
* Rise of multi-channel

<a id='eccccadd-e29e-474a-8edc-bbd255b2fdbf'></a>

<::A stethoscope rests on an American flag. To the right of the image, text reads: Increasingly stringent regulatory environment. Below that, a bullet point says: Recent pricing reform.
: figure::>

<a id='82afeea9-32fa-44f0-8f74-1edabb0d32cf'></a>

SOURCE: Medical Affairs Leader Forum

<a id='4503b24b-b4fc-41ee-99f1-e5ca5e295770'></a>

McKinsey & Company

<a id='3d621fa8-86ea-4e54-8f2b-07aafe02721d'></a>

4

<!-- PAGE BREAK -->

<a id='c757a860-5510-43af-917e-5d945086a877'></a>

The scope of medical activities continues to increase

<a id='40becd56-bfe3-426c-a12b-e586bc096a38'></a>

<::list of services with icons
: icon: Two overlapping speech bubbles.
: text: Relationship management and communication of product information
: icon: A person presenting in front of a whiteboard.
: text: Medical education
: icon: A circle with an 'i' inside, representing information.
: text: Medical information services
: icon: A megaphone.
: text: Medical communications, including publications::>

<a id='d8260386-3bf9-4da7-8b66-6d54485f1b76'></a>

<::Legend: Grey square: Historical focus, Blue square: Growing focus, Dark blue square: New focus::>

<::Icon: A stylized smartwatch/wrist device with a line graph on its screen::> Post-launch clinical trials
(e.g., Phase IIIb/IV trials, IIS and
observational studies)

<::Icon: A stylized plus sign connected to a vertical line with three dots::> Medical strategy

<::Icon: A clipboard with a plus sign on it::> Health Economics and
Outcomes Research (HEOR)

<::Icon: A document/paper with gears and binary code (0s and 1s) on it::> Real world evidence

<a id='8d2523e5-45e9-4369-b403-a009ced5f834'></a>

McKinsey & Company

<a id='6f062706-97c0-4181-b1cd-1c9bcb4e6b18'></a>

5

<!-- PAGE BREAK -->

<a id='e25f329b-4e09-49fb-aaf0-a63e95e054c4'></a>

We see medical taking more prominent role as the "Third Pillar" of the
business in Japan

<a id='f6fda3ac-3ca9-4021-9137-b308ffceb424'></a>

<::The image displays a diagram titled "The third pillar" at the top, depicted as a gray arrow pointing upwards. Below this, there are three main sections arranged horizontally, each featuring a blue banner, an image, and an associated descriptive text in a circle below. Blue arrows connect the sections, indicating a flow from left to right. The sections are:1.  **R&D**: Under a blue banner labeled "R&D", an image shows two scientists in a laboratory, wearing lab coats and safety glasses, working with beakers and chemicals. Below this, a circle contains the text "Highly strategic". A blue arrow points from this section to the "Medical Affairs" section.2.  **Medical Affairs**: Under a blue banner labeled "Medical Affairs", an image shows a group of medical professionals (doctors and nurses) in scrubs and lab coats, gathered and discussing, with some looking at a clipboard. Below this, a circle contains the text "In-market data generation". A blue arrow points from this section to the "Commercial" section.3.  **Commercial**: Under a blue banner labeled "Commercial", an image shows a man in a lab coat shaking hands with a woman in a business suit across a desk. Below this, a circle contains the text "In-market monitoring".::>

<a id='c3431888-9aca-4e04-8d48-0822aa87d123'></a>

SOURCE: Medical Affairs Leader Forum

<a id='a4ae2f39-d466-41f7-8d1f-12fc93ffd866'></a>

McKinsey & Company

<a id='4f40399b-5383-4432-a1d3-da23ea7f27f9'></a>

6

<!-- PAGE BREAK -->

<a id='8023b862-93cd-4792-85c4-c092708cc546'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='33930c8d-cf67-4255-84be-47133c753442'></a>

<::icon: A blue circle with a white silhouette of a doctor wearing a headlamp and a stethoscope.::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<a id='a5ede52b-881b-4ef9-af3c-929290ec6bbf'></a>

<::Blue circle with a white caduceus symbol in the center, surrounded by six white arrows pointing outwards in different directions: icon::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<a id='74efdd7f-9635-44c5-8f4b-8e7bdb02c677'></a>

<::An icon depicting a blue circle with a white magnifying glass. Inside the magnifying glass, there are white pill and tablet icons.
: figure::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<a id='58ebabee-d623-484f-b1a5-93215405ddc6'></a>

<::An icon depicting three stylized white human figures within a blue circle, representing a group or team. Below the icon, the letter "D" is present. The accompanying text reads: Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies: icon::>

<a id='5343ca71-4e4d-4e5b-8e9d-5e86635d5276'></a>

McKinsey & Company

<a id='391fc8b7-9fa2-4b78-9fd2-a2fc96f08f8d'></a>

7

<!-- PAGE BREAK -->

<a id='897e0715-d0db-4010-a545-cd738ffb1ef1'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='2ff1e241-1cf0-4d6d-833d-4f0f32ce4757'></a>

<::logo: [Medical Professional/Healthcare]A white silhouette of a medical professional with a stethoscope is set against a circular blue background with a long shadow.::>

<a id='85bdb203-f241-4f7c-872b-87f3dbfa0328'></a>

*Deeper*
*understanding of*
*the customers* to
better target the
different needs of
physicians and be
able to provide
tangible value

<a id='66fe945a-ae93-4fb9-9006-29cf8c82cce3'></a>

<::A light blue circle with a white caduceus symbol at its center, surrounded by six white arrows pointing outwards in different directions: diagram::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge 

<a id='b6a2e8a8-e698-4af8-bc84-543b8442dbce'></a>

<::An icon of a magnifying glass over several pills and capsules, all enclosed within a circle.
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment
: icon::>

<a id='d621f57c-9c0b-45be-be4a-20bc854e2c73'></a>

<::icon of three people silhouettes in a circle, labeled 'D' : figure::>Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies

<a id='43aad4bf-8d40-4007-ab80-0cfac708b75d'></a>

McKinsey & Company

<a id='2e0b3e7d-f11e-40cd-8739-a1c50f3f9b89'></a>

8

<!-- PAGE BREAK -->

<a id='878601f9-244d-4304-8cbf-74a63ee4f733'></a>

Quality of MSL interaction have clear correlation with the satisfaction and scientific influence of the company

<a id='81f1dfbf-889a-427d-89fe-ee5ff8c84692'></a>

<::logo: Unidentified
None
A blue circle with a white doctor icon and a red circle on a white background, representing the Japanese flag.::>

<a id='0fefcd2d-820f-4deb-9e11-f92288c633cb'></a>

Correlation between quality and quantity of the MSL activities and overall impact of a pharma company Percentage of respondents per case; n =460 <::chart: A horizontal bar chart illustrating the correlation between MSL activities (quality and quantity) and the overall impact on a pharma company, measured across three impact metrics: 'Level of satisfaction with the company', '"Scientific influence" of the company', and 'Likelihood of recommendation to peers'. The chart displays the following correlation values:

| Category | MSL Activity | Level of satisfaction with the company | "Scientific influence" of the company | Likelihood of recommendation to peers |
|:---|:---|:---|:---|:---|
| Quality | Process management skills of MSL | 0.66 | 0.47 | 0.49 |
| Quality | Level of scientific and medical knowledge of MSL | 0.64 | 0.44 | 0.49 |
| Quality | Interpersonal communication skills of MSL | 0.60 | 0.45 | 0.46 |
| Quantity | Number of MSL visits | 0.33 | 0.25 | 0.28 |
| Quantity | Number of MSL related activities | 0.27 | 0.17 | 0.35 |
| Quantity | Average duration of MSL visits | 0.10 | 0.10 | 0.15 |
::>

<a id='b5a0cf25-e558-4057-98aa-8ada9028b960'></a>

SOURCE: Japan MAPES 2016

<a id='a693e0ce-0750-4a9d-961a-8a93c0a56184'></a>

McKinsey & Company

<a id='5e4c4eca-fc14-4b07-98b9-cde18c731118'></a>

9

<!-- PAGE BREAK -->

<a id='c28f6dc2-1747-4ddb-a9ef-f397d0c55574'></a>

Yet, most companies are measuring quantity metrics of MSL activities
than quality or impact metrics

<a id='97bb3d87-82d5-4c3f-a3b2-1837b17dec19'></a>

<::logo: [Medical Professional/Healthcare Service]A white icon of a doctor with a stethoscope is set against a circular blue background with a long shadow.::>

<a id='cb0f7f69-16e3-4969-b0c2-f4554bd79cbb'></a>

Performance management & metrics, 2015
<::transcription of the content: chart
Title: Percentage of respondents gathering the metrics¹

- Quantify of activity: 78%
- Quality of activity: 40%
- Impact of interaction: 20%
::>
- What are the quality and impact metrics that are representative of Medical performance in Japan?
- How can we find more practical and objective ways to measure these metrics? More real time?
- How can we build a better feedback mechanism for continuous performance improvement?

<a id='925de5f0-bbe4-4c7c-94f7-cf17e20b0b20'></a>

1 N=13

<a id='fa6eacb4-2666-47e0-8595-9630afe93118'></a>

McKinsey & Company

<a id='9759407e-6090-4d88-811b-b95ad98bdb12'></a>

10

<!-- PAGE BREAK -->

<a id='a3367d7d-b924-4540-92e0-03fe7a0c1cd5'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='4363fae1-58ad-4e52-a33f-0369b78ead69'></a>

<::icon: A light blue circle with a white icon of a doctor wearing a stethoscope.::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::icon: A dark blue circle with a white Caduceus symbol at its center, from which five arrows point outwards in different directions.::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::icon: A light blue circle with a white icon of a magnifying glass over several pills and capsules.::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<a id='6ba536d5-e24a-4f6e-8e73-72fd86b858a7'></a>

<::A light blue circular icon containing three white silhouettes of people (busts), representing a group or team. Below the icon, the letter "D" is prominently displayed.: figure::>Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies

<a id='03e5e8a4-85ce-4ec7-a663-139962187322'></a>

McKinsey & Company

<a id='6a6c01bd-e9ee-4d12-89d9-7de5d29b69f7'></a>

11

<!-- PAGE BREAK -->

<a id='3477302f-60c5-4b4a-a0a7-ade41a320f3b'></a>

Pharma players in Japan generally lag behind digital leaders across most elements of digital enablement

<a id='50410f1b-2a2c-4d13-afc7-1d68dee1fec5'></a>

<::logo: Unknown

A white caduceus symbol is centered within a six-pointed star, all enclosed in a blue circle with a subtle shadow effect.:>

<a id='1bd9d514-61aa-4985-b40b-c45b1150972d'></a>

Rating on 5 point scale by 40 digital leaders across industry in Japan
<::Bar chart showing ratings for "Digital leaders" (gray bars) and "Japan PMP" (blue bars) on a 5-point scale, alongside a list of participating company logos.

**Legend:**
*   Digital leaders: Gray bar
*   Japan PMP: Blue bar

**Strategy**
*   How aligned are your digital and corporate strategies?
    *   Digital leaders: 4.1
    *   Japan PMP: 2.6
*   How customer-centric is your digital strategy?
    *   Digital leaders: 3.8
    *   Japan PMP: 2.5

**Organization**
*   What share of your digital talent has experience from outside?
    *   Digital leaders: 3.2
    *   Japan PMP: 3.0
*   Can your senior managers articulate their digital KPIs?
    *   Digital leaders: 3.6
    *   Japan PMP: 2.4

**Culture**
*   What is your company's comfort level in taking risks regarding digital initiatives?
    *   Digital leaders: 3.9
    *   Japan PMP: 3.0
*   To what extent do you use external partners to build digital capabilities?
    *   Digital leaders: 3.5
    *   Japan PMP: 3.3

**Capabilities**
*   How well does your company leverage the data you collect to generate insights?
    *   Digital leaders: 3.7
    *   Japan PMP: 2.7
*   Are your core back-office processes digitized?
    *   Digital leaders: 4.0
    *   Japan PMP: 3.5

**Results from Digital round-table in Japan**
*   **Companies:** Google, McKinsey&Company
*   **Participants:** AbbVie, Bayer, GSK GlaxoSmithKline, Lilly, Novartis, Daiichi-Sankyo, Janssen, Shionogi, Pfizer, Omron, MSD, Philips, Terumo
: chart::>

<a id='49361840-b2c5-4713-a550-d7e70f98b038'></a>

SOURCE: McKinsey DQ - Digital Benchmarking Survey

<a id='53faad08-8dbb-4bce-91cb-65b309964574'></a>

McKinsey & Company

<a id='1ac0c0fe-ae84-4dd7-a0e9-9c43af44c9d3'></a>

12

<!-- PAGE BREAK -->

<a id='c18ee0e0-6f11-46fc-9683-a64ecef07a59'></a>

Digital has potential to change ways of working across whole Medical Affairs value chain

<a id='fc2f3a2f-1900-467f-8e1b-82358e6af4d3'></a>

<::logo: [Unknown] No readable text. A white six-pointed star with a medical caduceus symbol inside is set against a blue circular background.::>

<a id='586660d7-42f0-4e30-9af6-2206aa79a5ce'></a>

NOT EXHAUSTIVE

<a id='81a77ddf-9c31-4c90-905b-116ff8f96500'></a>

Medical strategy

*   How advanced is my organization in digital Medical versus other Pharmacos?
*   What are customer preferences and potential future disruptors?
*   How to measure effectiveness of digital approaches?
*   How to evolve engagement model over Lifecycle using digital?

<a id='2b285343-44f3-47c2-b999-98392ddd7d56'></a>

## Field Medical/Engagement

*   What are the most effective ways to engage Medical KOLs in the digital world?
*   How to build optimal continuum of Medical engagement using mix of digital and physical interactions?
*   How to bring our content to places where HCPs and patients normally search for content (e.g. search engine optimization)

<a id='73776bf9-6904-44a9-9af3-86090bdbf0a3'></a>

Medical support

* Can we use digital to make compliance more efficient and simple?
* Can we digitize our support (e.g. Medical Information processes) to make them more efficient and user friendly?
* How to run Medical Communication campaigns in digital world (e.g. which channels, what is calendar)?

<a id='bed9837f-2e79-462a-945e-8b0a8cc21c1b'></a>

Data generation & HEOR

* How to leverage digital and analytics to collect more granular data and better insights about patient's?
* Can we use digital to source new ideas for data generation?
* Are digital tools a potential threat to our current approach while enabling payors and other stake-holders to have granular data about our patients? How to respond?

<a id='85ddff00-ea66-42a7-8818-9816fa9f54dd'></a>

McKinsey & Company

<a id='3019d726-9d33-4ea4-aca2-840690932159'></a>

13

<!-- PAGE BREAK -->

<a id='70c58699-47f1-4430-b36f-22eed65fe99f'></a>

There are already numerous sources of data available in Japan

<a id='81d4c1ae-cb20-4da1-a540-0c09ac1d4c59'></a>

<::logo: [Unidentifiable]
[No readable text]
A blue circular logo with a white six-pointed star and a blue medical caduceus symbol in the center, featuring a subtle shadow effect.:>

<a id='68109cf9-32c3-44b1-b8b8-d2b4124d9d51'></a>

Treatment data
Medical claims data
Health checkup data
Wholesale sales data
Available now
<::logo of HCEI
: figure::>
医療統計情報プラットフォーム
Platform for Clinical Information Statistical Analysis
<::logo of MDV medical.data.vision
: figure::>
<::logo of Fujita Health University
: figure::>
藤田保健衛生大学
FUJITA HEALTH UNIVERSITY
<::logo of Japan Medical Data Center
: figure::>
株式会社日本医療データセンター
Japan Medical Data Center.
<::logo of JMIRI Japan Medical Information Research Institute, Inc
: figure::>
株式会社医療情報総合研究所
JMIRI Japan Medical Information Research Institute, Inc (JMIRI)
患者中心の保健医療を支える、地方情報分析のリーディングカンパニー
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
NDB open data by prefecture
(National database)
<::logo of HCEI
: figure::>
<::logo of Japan Medical Data Center
: figure::>
株式会社日本医療データセンター
Japan Medical Data Center
<::diagram of a building/structure
: figure::>
<::logo of IQVIA
: figure::>
<::logo of CRECON RESEARCH & CONSULTING
: figure::>
CRECON
RESEARCH & CONSULTING
Pharma can use by 2020
<::logo of Pmda
: figure::>
MID-NET
May open-up going forward
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
DPC database
<::logo of NCD National Clinical Database
: figure::>
NCD
National
Clinical
Database
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
NDB
(National database)
<::logo of Health Insurance Claims Review & Reimbursement Services
: figure::::>
社会保険診療報酬支払基金
Health Insurance Claims Review & Reimbursement Services
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
<::logo of Health Insurance Claims Review & Reimbursement Services
: figure::>
社会保険診療報酬支払基金
Health Insurance Claims Review & Reimbursement Services
<::logo of Japan Gastroenterological Endoscopy Society
: figure::>
JAPAN GASTROENTEROLOGICAL
ENDOSCOPY SOCIETY
一般社団法人
日本消化器内視鏡学会

<a id='fbcce1b1-720d-47b2-8615-ace38907d37c'></a>

SOURCE: International pharmaceutical intelligence; McKinsey

<a id='87294a41-1814-4804-b0f7-9765225839e3'></a>

McKinsey & Company

<a id='0d332262-e3a1-4283-b496-fb7171566012'></a>

14

<!-- PAGE BREAK -->

<a id='64f2de4e-3a91-441f-b8f9-b0795a775c11'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='fccaeb60-89e0-41a0-bf70-ea00914722d6'></a>

<::figure: Four columns, each containing a circular icon at the top and descriptive text below it. The background of each column is a light grey. The icons are inside circles with shadows, giving a 3D effect. The text below each icon is presented as a key point.::>

<::figure: Column A::>
<::figure: Icon A: A light blue circle containing a white silhouette of a doctor wearing a stethoscope and a head mirror.::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::figure: Column B::>
<::figure: Icon B: A light blue circle containing a white Caduceus symbol (staff with two snakes and wings) at its center, with six arrows pointing outwards from it.::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::figure: Column C::>
<::figure: Icon C: A white circle containing a blue magnifying glass over various blue pills (capsules and a tablet).::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<::figure: Column D::>
<::figure: Icon D: A light blue circle containing white silhouettes of three human busts, representing a group of people.::>
D
Develop and acquire
talent to cultivate and
to build a strong,
multi-faceted Medical
Affairs organization
that encompasses the
new set of
competencies
<::/figure::>

<a id='699b1425-7c53-44af-a2e6-6bdd4e7021e5'></a>

McKinsey & Company

<a id='8ff95713-d8fe-44a4-8194-3ec50d55732a'></a>

15

<!-- PAGE BREAK -->

<a id='7b903516-87cd-44a5-869a-e48e1d986de7'></a>

Coordination with other functions is critical in creating Medical impact

<a id='dae7c7f4-0ad5-406e-9bd4-d676716b7cc6'></a>

<::logo: [Medical/Pharmaceutical]A blue circle contains a white magnifying glass examining various pills and capsules, with a long shadow extending to the right::>

<a id='b3cde5c2-781c-4c43-b36e-675f8a40bfe0'></a>

Typical company interaction with a KOL <::radial diagram: The diagram features a central circular image of a smiling male doctor in a light purple shirt and tie, wearing glasses, with his chin resting on his hand, appearing to be in a medical office. Surrounding this central image are segments of a circle, each associated with a label representing different points of interaction. Clockwise from the top, these labels are: MSL, Conference website, R&D, Company website, e-Detailing, Marketing, MR, and Area Manager.::>

<a id='636537bc-b3cf-4ea2-ae6f-1d07d82378d8'></a>

**What we often hear from KOLs**

"I meet at least 4-5 different people from one company. But they don't seem to talk to each other."

"What I hear from one person is sometimes different from what I hear from another. It is quite confusing"

"Sometimes it takes weeks to get an answer to my questions. I don't know why. By then I am wrestling with another problem"

<a id='d1f09593-062a-44ae-bd1d-666393200101'></a>

McKinsey & Company

<a id='252cd57d-1d44-4bd9-8cc8-56574414759a'></a>

16

<!-- PAGE BREAK -->

<a id='ddd708d5-b203-45f6-83ae-f2f923a088ff'></a>

Role as a true 3rd pillar will require close collaboration with other functions

<a id='9234ea12-88eb-4dd7-89fe-b80e6f523c3b'></a>

<::logo: [Medical/Pharmaceutical]A blue circle contains a white magnifying glass examining various pills and capsules, with a long shadow extending to the right::>

<a id='7741138b-00b3-4441-97f5-6b0d6dcc54f7'></a>

<::A diagram titled "The third pillar" at the top, represented by a grey upward-pointing arrow. Below it, three columns represent different functions, each with a blue header and an image. From left to right:1.  **R&D**: Image of a woman in a lab coat and safety glasses stirring a red liquid in a beaker in a laboratory.2.  **Medical Affairs**: Image of a group of medical professionals in white coats and scrubs, looking at a clipboard and interacting. This column is connected to the R&D column by a blue circular arrow icon, and to the Commercial column by another blue circular arrow icon.3.  **Commercial**: Image of a woman in a business suit shaking hands with a man in a lab coat.: figure::>

<a id='57e56f24-84b3-4c98-8952-67a6b6784d31'></a>

*   *Where can we find the largest opportunity for impact? What are customers expecting?*
*   *Where can Medical take immediate leadership in these collaborations? And how?*
*   *What are current barriers in realizing better collaboration with others? Internal policy? Cultural?*

<a id='25eb39c7-9b53-454b-a7ea-39937207349c'></a>

McKinsey & Company

<a id='85d77346-5da0-4d5a-b7e5-47fd67fc3110'></a>

17

<!-- PAGE BREAK -->

<a id='14837a44-5b7c-4fb0-a3d2-d1618337182b'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='f6fa89cc-769c-4dab-96de-97bad4e72a6e'></a>

<::Light blue circle with a white icon of a doctor (head, torso, stethoscope) with a long shadow.: figure::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::Light blue circle with a white icon of a caduceus symbol with arrows pointing outwards in eight directions, with a long shadow.: figure::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::Light blue circle with a white icon of a magnifying glass over pills and capsules, with a long shadow.: figure::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<::Darker blue circle with a white icon of three stylized human figures (busts with collars and ties), representing a team, with a long shadow.: figure::>
D
Develop and acquire
talent to cultivate and
to build a strong,
multi-faceted Medical
Affairs organization
that encompasses the
new set of
competencies

<a id='5b88edf8-ecea-48fe-85c2-ebe977785bc4'></a>

McKinsey & Company

<a id='697586fc-8c7e-4808-980c-8fca233e1cac'></a>

18

<!-- PAGE BREAK -->

<a id='d403f727-5807-45be-9b6b-428fdfe7bbf1'></a>

A strength-based approach to Medical Affairs talent

<a id='6fff32c2-ecfe-4abd-90a5-93654f294451'></a>

<::logo: [Unknown]No readable text.A blue circle contains three white stylized figures of people with long shadows, suggesting a team or group.:>

<a id='933bec92-da7c-47e8-b250-d3ece8364b3a'></a>

<::diagram: Medical Affairs capabilities

The central theme is "Medical Affairs capabilities".

Surrounding capabilities (clockwise from top):
1. Learning agility (icon: person running)
2. Business leadership (icon: group of people with one person raising a hand)
3. Strategic vision (icon: chess pieces, a knight and a queen)
4. Emotional intelligence (icon: brain with light rays)
5. Deep understanding of compliance (icon: balance scale)
6. Scientific and technological thought leadership (icon: microscope)

All items are connected to the central "Medical Affairs capabilities" by lines.
: diagram::>

<a id='f633358a-c2f5-4517-b4d2-1d930a18d490'></a>

# A strength-based approach

- Skills and competencies examined at level of the group, e.g.,
  - Cultivate individual's strengths for the benefit of the group
  - Seek candidates that fill gaps in the group, not the "perfect" candidate
- Comprehensive talent strategy supports and builds skills and capabilities of group
- "Field and Forum" approach integrates learning modules and real work experiences (as reinforcement)

<a id='e4ffbe95-996a-41a1-b673-c695eea4ae19'></a>

SOURCE: Managing talent in the Medical Affairs function: Creating value through strengths-based approach

<a id='1cd627d3-220d-4a1a-8cc6-8e48908237ba'></a>

McKinsey & Company

<a id='170ff6fb-de63-4c47-937b-e40819068284'></a>

19

<!-- PAGE BREAK -->

<a id='b7c3b62c-4b02-42d8-bd92-d8dc4878a4cd'></a>

Medical *is* the "Third Pillar" of pharmaceutical business

<a id='142832be-9fff-4844-a5a5-089127c5e1be'></a>

<::R&D. Two women in lab coats and safety glasses working in a laboratory. One woman is in the foreground, mixing a red liquid in a flask with her hands. On the counter, there are various beakers and flasks containing colorful liquids (yellow, red, orange) and lab equipment, including a mixer with a yellow liquid. Another woman is visible in the background, seated and working at a lab bench. The lab has white cabinets and counters.: figure::>

<a id='5d3de48d-236c-47e0-9a61-f459b4060f04'></a>

<::icon: A white silhouette of a person wearing a doctor's head mirror and a stethoscope, inside a blue circle with a long shadow.::>

Deeper understanding of
the customers

<a id='d29098d1-05bd-4d83-b916-146e3ca7581a'></a>

<:: Diagram illustrating "The third pillar" with three key components:

1.  **"The third pillar"**: Represented by a grey house-like roof structure at the top.
2.  **Medical Affairs + Commercial**: Below the "third pillar" are two main sections.
    *   **Medical Affairs**: A blue banner with the text "Medical Affairs" above an image of several medical professionals (doctors and nurses) in a discussion, looking at a clipboard. A large blue plus sign is to the left of this section and another large blue plus sign is to its right.
    *   **Commercial**: A blue banner with the text "Commercial" above an image of a businesswoman shaking hands with a man in a lab coat, possibly a doctor or researcher, across a counter.
3.  **Three Strategic Initiatives**: Below the "Medical Affairs" and "Commercial" sections, a large blue downward-pointing arrow leads to three circular icons, each with a descriptive text below it:
    *   **Getting ahead in digital leadership**: A blue circular icon with a white star-like shape, featuring a caduceus symbol (medical staff with wings and two snakes) in the center, and arrows pointing outwards.
    *   **Integrated working model with internal partners**: A blue circular icon with a white magnifying glass hovering over various pills and capsules.
    *   **Develop and acquire talent**: A blue circular icon with three white stylized human figures (representing a team or group).
: infographic::>

<a id='2fd2d759-4c65-4df6-8c14-9f87be202203'></a>

McKinsey & Company

<a id='bd836d11-7680-44a1-bd84-9399b9c45dd0'></a>

20