"""FastAPI app: chat endpoint with conversation history + static UI."""

from __future__ import annotations

import logging
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app.config import settings
from app.graph import router_graph
from app.skill_registry import registry
from app.state import ChatMessage, PlanStep, StepResult

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory session store (swap for Redis/DB in production)
# ---------------------------------------------------------------------------

_sessions: dict[str, list[ChatMessage]] = {}


def _get_history(session_id: str) -> list[ChatMessage]:
    return _sessions.setdefault(session_id, [])


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    registry.load_from_directory(settings.skills_dir)
    logger.info("Loaded %d skill(s): %s", len(registry.list_all()), [s.name for s in registry.list_all()])
    yield


app = FastAPI(title="Query Router Chat", version="0.4.0", lifespan=lifespan)

# Serve static files (chat UI)
static_dir = Path(__file__).parent.parent / "static"
if static_dir.is_dir():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None


class ChatResponse(BaseModel):
    answer: str
    session_id: str
    reasoning: str = ""
    plan_steps: list[dict] = Field(default_factory=list)
    step_results: list[dict] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    """Serve the chat UI."""
    index = static_dir / "index.html"
    if not index.exists():
        return HTMLResponse("<h1>Chat UI not found</h1><p>Place index.html in /static</p>")
    return HTMLResponse(index.read_text())


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest) -> ChatResponse:
    """Chat endpoint with conversation history."""

    session_id = req.session_id or str(uuid.uuid4())
    history = _get_history(session_id)

    # Build graph state
    initial_state = {
        "question": req.message,
        "chat_history": list(history),
        "reasoning": "",
        "plan_steps": [],
        "step_results": [],
        "completed_ids": set(),
        "answer": "",
        "error": "",
    }

    try:
        final_state = await router_graph.ainvoke(initial_state)
    except Exception as exc:
        logger.exception("Graph execution failed")
        raise HTTPException(status_code=502, detail=str(exc))

    answer = final_state.get("answer", "")
    if final_state.get("error") and not answer:
        answer = f"Error: {final_state['error']}"

    # Append to session history
    history.append(ChatMessage(role="user", content=req.message))
    history.append(ChatMessage(
        role="assistant",
        content=answer,
        plan_steps=final_state.get("plan_steps"),
        step_results=final_state.get("step_results"),
    ))

    return ChatResponse(
        answer=answer,
        session_id=session_id,
        reasoning=final_state.get("reasoning", ""),
        plan_steps=[s.model_dump() if isinstance(s, PlanStep) else s
                    for s in final_state.get("plan_steps", [])],
        step_results=[r.model_dump() if isinstance(r, StepResult) else r
                      for r in final_state.get("step_results", [])],
    )


@app.get("/sessions/{session_id}/history")
async def get_history(session_id: str):
    """Retrieve conversation history for a session."""
    history = _sessions.get(session_id, [])
    return [msg.model_dump() for msg in history]


@app.delete("/sessions/{session_id}")
async def clear_session(session_id: str):
    """Clear conversation history for a session."""
    _sessions.pop(session_id, None)
    return {"status": "cleared"}


@app.get("/skills")
async def list_skills():
    return [
        {"name": s.name, "description": s.description, "category": s.category,
         "trigger": s.trigger, "parameters": [p.model_dump() for p in s.parameters]}
        for s in registry.list_all()
    ]


@app.get("/health")
async def health():
    return {"status": "ok", "skills_loaded": len(registry.list_all())}
