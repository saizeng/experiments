<a id='ea3cb644-47bf-45d2-87e4-b8d73e6a1b62'></a>

## Attracting Responsible Mining
## Investment in Fragile and Conflict
## Affected Settings

Fraser Thompson
Senior Fellow
McKinsey Global Institute (MGI)

<a id='a036b76e-44f6-49aa-b476-4c464c60a0ef'></a>

Reversing the curse presentation
February 6, 2014

<a id='825d7028-d9b4-4772-813a-c96cdfe91322'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='920ad923-7be5-46da-958d-e689021588c5'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='252d1ec2-fab1-4eb1-82ef-b2c69a388275'></a>

This presentation draws upon material in our “Reverse the curse” report -
available for download at www.mckinsey.com/mgi

<a id='78e1add8-da22-4c79-a44f-01277b32e999'></a>

McKinsey&Company

<a id='bbc49471-a5d3-4279-b488-7b47d5e2bbc7'></a>

Prepublication Version — Embargoed — for Release December 5, 2013

<a id='574d435b-275a-4ef0-9a37-5ce8673ae780'></a>

McKinsey Global Institute McKinsey Global Energy & Materials Practice McKinsey Sustainability & Resource Productivity Practice <::Four images depicting different industrial and resource-related activities: 1. A person in a hard hat and high-visibility vest operating surveying equipment in a rocky, barren landscape. 2. An offshore oil rig silhouetted against a vibrant sunset over the ocean. 3. Two workers in hard hats and blue coveralls performing tasks on what appears to be drilling or pipeline equipment. 4. A curving railroad track running parallel to a dirt road through a grassy area.: set of images::> December 2013

<a id='123362f6-e587-41d8-89c6-f1075defd6a0'></a>

Reverse the curse:
Maximizing the potential of
resource-driven economies

<a id='2f691fa6-64fc-439c-a274-69911ef24568'></a>

<::A world map, represented by a pattern of small gray dots on a white background. The map shows the continents of North America, South America, Europe, Africa, Asia, and Australia, outlined by these dots. The dots are uniformly distributed to form the landmasses.: map::>

<a id='737a658e-e289-448c-a0ec-60974e9bce45'></a>

# Central questions

1. How is the resource supply
landscape changing?
2. What are the implications for
resource-driven economies?
3. What are the implications for
extractive companies operating
in these countries?

<a id='33f965c9-960d-4938-b0d6-cc4ea2b09ce2'></a>

McKinsey & Company

<a id='f1864169-823f-4408-afe3-861b4f782fda'></a>

1

<!-- PAGE BREAK -->

<a id='61949bc1-b02c-4d36-ba5b-fdece1900703'></a>

The number of resource-driven countries has increased by almost 40% since 1995 and most newcomers have low average incomes

<a id='0d6bf13e-d764-4d06-9659-b57c6dbe9ba4'></a>

Number of resource-driven countries over time, by income class
<::stacked bar chart::>
**Stacked Bar Chart: Number of resource-driven countries by income class**

**1995 (Total: 58 countries)**
*   Low income: 22
*   Lower middle income: 19
*   Upper middle income: 8
*   High income: 9

**2011 (Total: 81 countries, +40% increase from 1995)**
*   Low income: 17
*   Lower middle income: 21
*   Upper middle income: 27
*   High income: 16

**Additional Data:**
| Category              | 1995 | 2011 |
|:----------------------|:-----|:-----|
| % of world GDP        | 18   | 26   |
| % of world population | 18   | 49   |
<::chart::>

<a id='1561e892-dffe-43a8-9184-f2efaaf67907'></a>

Income class at time of becoming
resource-driven
<::pie chart
%, 1995–2011
High: 11%
Upper middle: 25%
Lower middle: 11%
Low: 54%
: chart::>

<a id='af3828bd-ec0b-474d-be4d-4b6bd28865e2'></a>

McKinsey & Company

<a id='dca847f3-41b8-4435-a46f-a29fe4e95ecd'></a>

2

<!-- PAGE BREAK -->

<a id='aac9a2df-d50c-4b65-9be4-1458fb6ce316'></a>

Annual investment in oil and gas and minerals could need to more than double to meet new demand and replace existing supply

<a id='6f639945-f576-48f4-a20a-14ae294e1126'></a>

2012 $ billion

<a id='1dfcd94b-1aff-4755-bdd0-1643478492f5'></a>

Annual investment requirements
Minerals
<::Bar chart showing annual investment requirements broken down by Replacement capex (blue) and Growth capex (light blue).

**Legend:**
Replacement capex: Blue
Growth capex: Light blue

**Minerals:**
- 2003-2012:
  - Replacement capex: 41
  - Growth capex: 57
  - Total: 98
- 2013-2030:
  - Replacement capex: 110
  - Growth capex: 105
  - Total: 215
- Increase from 2003-2012 to 2013-2030: +119%

**Oil and gas:**
- 1995-2012:
  - Replacement capex: 121
  - Growth capex: 165
  - Total: 286
- 2013-2030:
  - Replacement capex: 299
  - Growth capex: 451
  - Total: 749
- Increase from 1995-2012 to 2013-2030: +162%
: chart::>
$17 trillion by 2030 (~3.8 trillion for minerals alone)

<a id='9bc80253-3b34-4197-ba34-d5e905dfca20'></a>

Resource investment in low and lower-middle income countries<::chart: Bar chart showing resource investment in low and lower-middle income countries.
Legend:
- Potential upside: Dotted outline box
- Base case: Solid blue box

Data:
- 1995-2012:
  - Base case: 835
- 2013-2030:
  - Base case: 1,245
  - Potential upside: 1,770
  - Total (Base case + Potential upside): 3,015

Annotation:
- An arrow points from the top of the 1995-2012 bar to the top of the 2013-2030 potential upside. Next to the arrow is a green oval with "3.6x" inside, and the text: "Resource extraction investment in lower income countries could potentially more than triple from historical levels".:chart::>

<a id='cf839ef6-b08e-42f4-92a0-520cc86131bb'></a>

McKinsey & Company

<a id='a5dc3234-3e51-4849-bacf-3fad12d750a6'></a>

3

<!-- PAGE BREAK -->

<a id='6083e3a9-668e-4202-b98e-1d16979345a4'></a>

**However historically resource-driven countries have not performed well economically**

<a id='16cfdab3-0f7c-4938-8f54-60e8b39b6f54'></a>

<::scatter plot
: Title: Per capita GDP, 2011 (Real 2005 $)

Legend: Blue circle represents "% of RDCs"

Y-axis: Per capita GDP, 2011 (Real 2005 $), ranging from 0 to 70,000.
X-axis: Per capita GDP compound annual growth rate, 1995–2011 (%), ranging from -4 to 19.

The plot is divided into four quadrants by two dashed lines:
- A vertical dashed line at X = 2.5%, labeled "Average country growth: 2.5%".
- A horizontal dashed line at Y = $10,900, labeled "Average country per capita GDP: $10,900".

Quadrants:
- Top-left quadrant (High GDP, Low/Negative Growth): Labeled "16% Slowing".
- Top-right quadrant (High GDP, High Growth): Labeled "5% Stars".
- Bottom-left quadrant (Low GDP, Low/Negative Growth): Labeled "40% Falling behind".
- Bottom-right quadrant (Low GDP, High Growth): Labeled "37% Catching up".

Numerous blue circular data points are scattered across all four quadrants.: chart::>

<a id='3c5c08dc-1aa7-4aa4-8a8d-c4a87d335e04'></a>

McKinsey & Company

<a id='9f8e1226-e7e8-4983-aaae-001e5888b194'></a>

4

<!-- PAGE BREAK -->

<a id='3d9de5aa-786c-4836-8316-b8f97ea89e46'></a>

Our research suggests governments must consider six important
dimensions to transform sub-soil wealth into long-term prosperity

<a id='6f46c9b0-f02e-44e1-ac2b-ae2c46d29158'></a>

<::objectives and topics: diagram::>Objectives Topics
Produce resources efficiently 1 Institutions and governance
                               2 Infrastructure

Capture value from resources   3 Fiscal policy/competitiveness
                               4 Local content

Transform value into long-term 5 Spending the windfall
development                    6 Economic diversification

<a id='b18dd716-f150-49d3-9517-f967eeff4baa'></a>

McKinsey & Company

<a id='be102915-e5d7-4dcf-9fa3-9cb1d4bb1f6a'></a>

5

<!-- PAGE BREAK -->

<a id='983e50e1-3a9b-461d-a1a4-c1459db83fb6'></a>

Three factors are putting pressure on the social contract between
extractive companies and resource-driven countries

<a id='26ad8c01-1199-4d2e-b733-375e52256965'></a>

<::logo: [Unknown]RISKRed cubes stacked vertically, spelling out "RISK" in white letters::>

<a id='bb46d70e-67f3-425f-ab9a-2dcc6a43a313'></a>

1. **High and volatile resource prices.** Volatile resource prices have led to significant choppiness in resource rents and increased the likelihood that governments feel "cheated" and seek to renegotiate terms.

<a id='68dc2363-f764-4f41-bf88-21b69bb3eaa1'></a>

2. New projects are **bigger** and **more complex**. Exploration and production are increasingly moving toward deposits which are environmentally and logistically challenging and geologically complex. This is driving up project costs and increasing the risk of delays.

<a id='27a74f80-c8ba-4d68-b8ec-2bf4772a59fd'></a>

3. Projects are a large share of the economies. Historically, petroleum projects have been on a huge scale relative to their host economies, but today some mining projects are on a similar relative scale.

<a id='1b0fc32f-a3bf-4d28-8aba-f7bec1bacf70'></a>

McKinsey & Company

<a id='4095d889-60c0-4a54-ad35-aa0506212a53'></a>

6

<!-- PAGE BREAK -->

<a id='e639b06a-e95a-4587-af21-e3caa2c1dca5'></a>

Companies need to shift their approach in managing these risks – moving it from "art" to "science"

<a id='17404d48-6eb2-4636-b47a-54993c2fcd60'></a>

Develop a detailed understanding of the country context
1 10 dimensions matter, which go beyond simple political risk considerations

<::A circular diagram with an inner dark blue circle and an outer light blue ring divided into segments. Each segment contains an icon: a euro symbol (€), a gear, an H-shaped building, a handshake, and a group of people. Another icon resembling a recycling symbol is also present. : diagram::>

<a id='a59eae68-ee34-4e38-90e2-60eaaaa5a01e'></a>

**Properly understand the risk (and upside)**

2. What type of risks does under-performance create?
   Which are possible consequences and what is the magnitude/impact if risk materializes?

<a id='d495a17b-a43d-441e-8bee-93dea97d6a4c'></a>

<::A risk matrix chart with 'Risk impact' on the vertical axis (ranging from Low to High) and 'Risk likelihood' on the horizontal axis (ranging from Low to High). The chart is divided into four quadrants. The top-left quadrant contains the letters B and K. The bottom-left quadrant contains A, E, and J. The top-right quadrant is shaded blue and contains C and G. The bottom-right quadrant contains D, F, L, I, and H. A legend in the top-right corner indicates that the blue shaded area represents 'Focus of risk avoidance'.
: figure::>

<a id='0d46768b-14ba-42fa-a089-4cca26f5dc77'></a>

**Understand performance versus expectations**

3. To what degree are company priorities aligned with key stakeholder priorities?
How is the company performing vis-à-vis those expectations?

<a id='8814e828-272a-49c2-94ef-a4a8ddea7be1'></a>

2. In depth, qualitative assessment of action ROI
Project-specific cost curve
<::A bar chart titled "Project-specific cost curve".
The Y-axis is labeled "Short-term value to company", with "High" at the top and "Low" at the bottom.
The X-axis represents different actions/initiatives, implicitly ordered by "Value to society".
A note states: "Width of bar = total value impact".

The bars, from left to right, represent the following actions/initiatives and their short-term value to the company:
- Transport infrastructure (negative value)
- Healthcare (negative value)
- Education (negative value)
- Water preservation (negative value)
- Air pollution remediation (negative value)
- Land preservation & rehabilitation (negative value)
- Biodiversity preservation (negative value)
- Energy infrastructure (negative value)
- Other infrastructure (slightly negative value)
- Housing & homelessness (slightly positive value)
- National tax transparency & anti-corruption (positive value)
- Workforce development (positive value)
- Supplier development (positive value)
- Downstream sector development (positive value)
- Vocational training & job matching (positive value)
- Water infrastructure (positive value)
- Waste management (positive value)
- Tracking impact (positive value)
- Engaging in public relations (positive value)
- Local tax transparency & anti-corruption (positive value)
- Building strong relationships (positive value)
- Safety (positive value)
- Clarifying needs & expectations (positive value)
- Forming a joint vision (positive value, highest)
: chart::>

<a id='fc340ce8-31c5-4879-bb38-ddf3b792499b'></a>

### Explore bold moves that create a symbiotic relationship

4. Don't optimize for the short-term

*   Understand network of decision-makers and influencers
*   Make clear to government what is at stake
*   Link the company's operations to the country vision

<a id='cd3de419-650c-4b7a-9b97-4959ff113f4b'></a>

<::Flowchart: CSR Assessment Process::>
Phase 0
Preparation
Phase 1
Diagnostic
Phase 2
Risk assessment
Phase 3
Develop portfolio of initiatives
Phase 4
Action planning

Key activities

Phase 0: Preparation
*   Understand CSR work done to date, e.g., align with strategic framing and specific deep dives conducted
*   Prepare reference case contacts

Phase 1: Diagnostic
*   Tailor asset specific CSR assessment (SE version of Compass)
*   Conduct diagnosis on site, interviews with management, workforce and external stakeholders
*   Prepare joint SE and McK team, e.g., joint 'boot camp'

Phase 2: Risk assessment
*   Conduct local workshops with stakeholders to identify and evaluate risks
*   Leverage McK risk database to categorize and estimate risks
*   Rank risks, highlight any high-impact, high likelihood
*   Calculate NPV for all important risks

Phase 3: Develop portfolio of initiatives
*   Leverage McK CSR database to generate ideas for initiatives
*   Conduct local workshops do develop adequate initiatives
*   Iterate initiatives with stakeholders to ensure buy-in, feasibility and efficiency
*   Rank initiatives based on ROI
*   Select mix of initiatives

Phase 4: Action planning
*   Develop detailed action plan for implementation of each initiative
*   Include local stakeholders (internal and external) in planning
*   Launch implementation teams
<::/Flowchart::>

<a id='22b2dcc2-c095-4e6f-bb7f-43193b72658c'></a>

McKinsey & Company

<a id='7acf2bb4-f2e0-4c03-96dd-5ee3718aeb71'></a>

7