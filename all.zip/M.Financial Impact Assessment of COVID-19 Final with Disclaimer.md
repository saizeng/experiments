<a id='9d612edb-77f6-4b87-ab54-90daa8432966'></a>

## Disclaimer

<a id='d66df144-ab0d-41cc-8da3-35da9df494ce'></a>

McKinsey Analysis—Metropolitan Transportation Authority
Financial Impact Assessment on 2020 Revenue of COVID-19

<a id='287f3937-4b29-4c9b-bcb1-3c172a8bce0f'></a>

McKinsey & Company was contracted to provide MTA with a detailed economic analysis (the "Report") which will assist management in assessing the financial impact of the COVID-19 pandemic on MTA operations. Before reviewing the Report, users are advised to carefully read the "Disclaimer" page of the Report in its entirety.

<a id='8467ca32-8600-4085-956d-ff0bdc4cdd11'></a>

Please take a few minutes to read the Terms of Use below as they are complementary to the information presented in the Report.

**Terms of Use**

1.  **Not an Offer to Sell/Buy Securities:** The information provided in the Report does not constitute an offer to sell or buy securities or the solicitation of an offer to sell or buy securities and should not be relied upon to provide specific offering information in connection with any issuance, sale, resale, or remarketing of bonds, notes, or other municipal obligations.
2.  **Information is Subject to Change Without Notice and May Not Be Updated**: MTA is under no obligation to update any information included in the Report. The information and expressions of opinion therein are subject to change without notice.
3.  **Estimates or Other Forward-Looking Statements:** The Report may make "forward-looking statements" by using forward-looking words such as "may," "will," "should," "expects," "believes," "anticipates," "estimates," or others. You are cautioned that forward-looking statements are subject to a variety of uncertainties that could cause actual results to differ from the projected results. Because MTA cannot predict all factors that may affect future decisions, actions, events, policy decisions, or financial circumstances, what actually happens may be different than what is included in forward-looking statements.
4.  **Investment Decisions:** The Report is not intended to replace any information or consultation provided by a professional financial advisor.
5.  **Unauthorized Use Not Permitted:** The Report is part of the official website of MTA. MTA disclaims all responsibility for any copies, modifications, and reproductions of this Report or the information it contains that are not produced by MTA.

<a id='0dac3549-7c15-4e33-8c35-c2712449680f'></a>

<::logo: Metropolitan Transportation Authority
MTA Metropolitan Transportation Authority
A blue circle with "MTA" in white, next to the full name in blue text.::>

<!-- PAGE BREAK -->

<a id='b7c75b93-fcfb-491b-8684-89965190ed77'></a>

Metropolitan
Transportation
Authority

Financial impact assessment on 2020 revenue of COVID-19

<a id='9ee15549-5274-4559-b605-1ae5737877e6'></a>

<::logo: MTA
MTA
A blue circular logo with white bold letters "MTA" in the center, and the text "1 May 2020" above it.::>

<!-- PAGE BREAK -->

<a id='eaad3d18-3a2d-4aac-b32e-d61233062705'></a>

In April 2020, McKinsey & Company was contracted by the MTA to analyze the potential near-term financial impact of Covid-19 on the MTA. This document represents a summary of the approach, analyses, and key findings.

<a id='65b298f0-120e-4e5f-ac79-06216843a0b7'></a>

2

<!-- PAGE BREAK -->

<a id='80ba1fd6-42c0-41a3-a45b-24431efaf3ba'></a>

Disclaimer

<a id='c1c31932-ea6b-49f5-be40-7e7e2f9183f1'></a>

The analyses and conclusions contained in this document were conducted on an accelerated basis, reflect preliminary perspectives concerning MTA operations and do not purport to contain or incorporate all the information that would be required by MTA to properly evaluate its operational and strategic options. Furthermore, these materials are not intended to constitute legal, accounting, policy or similar professional or regulatory advice normally provided by licensed or certified practitioners and are similarly not intended as materials to be relied on.

<a id='6c0b26b1-a803-4841-aaff-f538e1ec305b'></a>

The analyses and conclusions contained in this document are based on various assumptions that were developed by MTA, which partly may or may not be correct, being based upon factors and events subject to uncertainty. Such assumptions were developed solely as a means of illustrating the principal considerations that may be taken into account and independently evaluated. Such information has not been independently verified and is inherently uncertain and subject to change. Given the uncertainty surrounding the pandemic, these materials are not a guarantee of results, and future results could differ materially from any forecasts or projections. These materials do not constitute policy advice or legal, medical or other regulated advice. Particularly in light of the rapidly evolving COVID-19 pandemic, and the attendant regulatory and market supply conditions, these materials were developed to provide fact-based, independent analysis to the MTA for its own use to develop its own recommendations and make its own decisions regarding future plans.

<a id='a49235b6-c9a8-471d-9051-0e9cea48e77e'></a>

McKinsey & Company, Washington, D.C., Inc. makes no representation or warranty, express or implied, as to the accuracy or completeness of the underlying assumptions, estimates, analyses, or other information contained in this document, and nothing contained herein is or shall be relied upon as a promise or a representation, whether as to the past, the present, or the future.

<a id='745c5f51-d31a-47b2-b800-76c0b022a2fb'></a>

This document is not intended to, and may not, be relied upon by any person or entity and, therefore, any person or entity who receives this document or the information contained herein, with McKinsey & Company, Washington, D.C., Inc.'s permission or otherwise, is hereby put on notice that (i) they are responsible for their own analyses and may not rely on any information contained herein, and (ii) McKinsey & Company, Washington, D.C., Inc. makes no representations or warranties, including with respect to the accuracy or completeness of the information contained herein or any other written or oral communication transmitted or made available to the third party, and expressly disclaims any and all liabilities based on such information or on omissions there from

<a id='08af4073-0f60-47be-828e-24351b045c3d'></a>

3

<!-- PAGE BREAK -->

<a id='370e67e2-3ebc-4b3f-b4cc-e013eae3e25f'></a>

## Contents

<a id='7a241145-eada-4bb8-a5d6-f6e41993d88f'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='464a1dbf-e707-4126-9044-18395a80cd71'></a>

**Fare and toll revenue methodology**

Non-fare revenue methodology

Additional operating expense methodology

Operating gap

Impact of filling the gap

<a id='fb0d2f1f-e4a4-488c-be83-87a2dbc2683e'></a>

4

<!-- PAGE BREAK -->

<a id='604e27b4-e3af-4abd-8588-45c46677ac00'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='efaed4d0-89cc-4fa1-ae13-6c97bcc8ca20'></a>

Overview of revenue components and forecast approach

<a id='19026868-1fba-451d-ac32-c17558c5c3eb'></a>

- Focus of this chapter

<a id='ed947c00-555d-4fb0-938c-035994dbe4d2'></a>

**Fare and toll revenue**

---

Applied different scenarios of how long the current state of social distancing will last based on actuals, and what ridership/mobility ramp-up might look like after that. For those scenarios, considered the impact of epidemiology, policy effects, and behavioral changes

---

v

**Ridership/traffic curves**

<a id='acd3b6bc-1348-4529-bb34-7ee7f0f8e687'></a>

# Non-fare revenue

Identified five archetypes of tax or subsidy revenue – Employment, Real Estate and Mortgages, Sales, Business Income, and Mobility – each with a distinct driver. Created a multiplier for each archetype, which was applied to each source to forecast 2020 revenue

<a id='27f9ca6a-3073-4b46-b96b-30e95d612f6f'></a>

⌄

Tax-specific change profiles

<a id='a358dfd3-3d92-4d2c-9e02-173e55e5c8ca'></a>

5

<!-- PAGE BREAK -->

<a id='86995aa9-743a-474c-8143-5a9dc91789d0'></a>

Current as of 4/28/20

<a id='458bc76d-0a84-4cdc-b7f1-aa12fa66c830'></a>

Guiding questions for fare methodology

<a id='f9bf01f6-d3d7-4fd5-8356-70837141c484'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='cb3ab3fe-91a3-4c13-a7aa-2a6f40b01e32'></a>

### Guiding questions

1. What is current ridership during intense social distancing (e.g., the current period)?
2. What level of ridership are we going to, i.e., what's the 'new normal' level in a period of economic decline/social distancing?
3. What will the ramp up be like to get from point 1 to point 2, and when will it start?
4. How will this ramp up be interrupted by a potential resurgence of the virus in Q4 2020?

### Resulting actions for methodology

Used actuals provided by the MTA and compared across systems to calibrate.
Ridership for most systems is down dramatically (~90%).

Looked at historical experience for what "new normal" looks like in an economic crisis. Began with ridership and toll recovery from the trough during the Great Recession, then took an additional haircut to reflect a number of factors that could continue to suppress demand (e.g., increased prevalence of work from home)

Looked at ramp-up curves in health/safety/security crises (e.g., 9/11, SARS) as well as economic crises (e.g., Great Recession) to understand how demand has reacted to past crises, and shaped a potential curve for a dual health/safety and economic crisis

Modeled two scenarios of potential interruption by a resurgence, one where a second wave would result in something similar to present-day physical distancing conditions (in addition to seasonal flu), and a second more positive scenario factoring in the impact of better preparedness which would reduce the trough as currently experienced

<a id='559759bc-33dc-48c1-b749-d78a99970560'></a>

Although different assets may behave differently, e.g., commuter rail may have a slower ramp-up than bus given that commuter rail riders could be more likely to work from home for longer or to use a personal vehicle, some early sensitivity testing was conducted and showed that additional precision from a bottom-up build did not meaningfully impact the aggregate number

<a id='df492617-f3dd-4423-bc8f-72dafb7c7d51'></a>

6

<!-- PAGE BREAK -->

<a id='08eb9881-8145-40fc-adef-809f3f07c483'></a>

1 Due to COVID-19 ridership has fallen
drastically across all transit systems...
Commuter and heavy rail have been affected particularly severely

<a id='bc9add32-be38-4027-9ca4-c495a3c085c9'></a>

<::bar chart: Greatest reported reduction in ridership vs. last month or last year¹, percent reduction in ridership. Legend: Commuter Rail (dark blue/black), Heavy Rail (medium blue), Bus (darker blue), Mix (light blue). The chart displays transit agencies, the date of data, the percentage reduction in ridership, and the type of service. Data points are as follows: MBTA Boston, 14 April, 99%, Commuter Rail; MTA LIRR, 24 April, 97%, Commuter Rail; MTA Metro-North, 24 April, 95%, Commuter Rail; WMATA, 28 April, 95%, Heavy Rail; BART SF, 28 April, 94%, Heavy Rail; NYC Transit, 20 April, 90%, Heavy Rail; MARTA, 26 April, 81%, Heavy Rail; Chicago Transit Authority, 23 April, 80%, Heavy Rail; LA Metro, 29 April, 80%, Heavy Rail; NYC Transit, 24 April, 81%, Bus; MBTA Boston, 28 April, 80%, Bus; WMATA, 28 April, 73%, Bus; LA Metro, 29 April, 65%, Bus; MARTA, 26 April, 45%, Bus; NJ TRANSIT, 18 April, 90%, Mix; SF Muni, 28 April, 83%, Mix; Denver RTD, 16 April, 70%, Mix.::>

<a id='f2a24a06-2b73-490d-886f-9d9a98f73dfb'></a>

1 Data collection and accuracy may vary across transit systems - some might be based on ticket entry, others on samples and extrapolation

<a id='8e756a63-6379-4e4f-82ff-ee729bd681ab'></a>

Source: Chicago Tribune, Eno Center for Transportation, Boston Herald, WMATA.com, Bart.gov, The New York Times, Saporta Report, Chicago Sun Times, LAist, Seattle Transit Blog, MTA internal data, Boston Business Journal, LAist, WOMB, Bloomberg, Colorado Politics

<a id='c552fa86-4213-483f-955b-60ef78f5a711'></a>

Data collected April 30, 2020

<a id='2168f8ee-95b6-453a-8ba1-b2a5a5f26dd3'></a>

Effects on public transit
systems ridership

Ridership has fallen across
systems across the US
and the globe

<a id='ad175767-6138-44a9-82cb-2ae6b5b9551f'></a>

Due to increased work
from home policies, commuter
rail systems are affected
particularly strongly

<a id='e7134b8d-a818-4fc8-b1c7-fbe0289ba644'></a>

Government mandates have also had strong effects in key geographies

<a id='281d7d27-f384-4f57-a8b4-2bcdf6f296ff'></a>

(4/28/20) Please see disclaimer on page
3. These analyses represent only
potential scenarios based on discrete
data from one point in time. They are not
intended as a prediction or forecast, and
the situation is changing daily.

<a id='50474cae-b9c8-4bfc-81b6-be2c472ed341'></a>

7

<!-- PAGE BREAK -->

<a id='a214e9ca-92de-4411-b27a-ba647ce846c7'></a>

1

<a id='1bde72a0-b618-4205-ac21-89b261b28b3b'></a>

...and has remained low since this

<a id='8d7db3ec-be36-4c7c-b876-8033eec38559'></a>

# sharp drop
Initial declines led to persistently low ridership
---

<a id='0cf1a06a-fdde-46ad-ab18-0438cb01030e'></a>

Initial decline: ridership fell swiftly and sharply across systems starting the week of March 9th<::chart showing % decline in ridership for various public transit systems from March 9th to March 19th. The y-axis represents the % decline in ridership, ranging from 0 to -100. The x-axis represents dates from Mar 9 to Mar 19. A vertical line at Mar 13 is annotated with "President Trump declares a national emergency". The chart includes seven lines, each representing a transit system:
- NYCT Bus (light green dashed line): declined from approximately -10 on Mar 9 to -15 on Mar 11 and -49 on Mar 17.
- NYCT Subway (light blue dashed line): declined from approximately -10 on Mar 9 to -19 on Mar 11 and -60 on Mar 17.
- LIRR (light green solid line): declined from approximately -20 on Mar 9 to -31 on Mar 11 and -67 on Mar 17.
- Metro-North (dark green dashed line): declined from approximately -30 on Mar 9 to -48 on Mar 11 and -90 on Mar 17.
- BART SF (yellow dashed line): declined from approximately -20 on Mar 9 to -35 on Mar 10, -48 on Mar 13, and -70 on Mar 17.
- MBTA Boston (dark blue dashed line): declined from approximately -30 on Mar 9 to -48 on Mar 13 and -78 on Mar 17.
- NJ TRANSIT (red dashed line): declined from approximately -10 on Mar 9 to -20 on Mar 13 and -88 on Mar 19.

The overall trend for all systems shows a sharp decline in ridership over the period.: chart::>

<a id='7e9638ec-f22a-4ef3-a77a-f44727cbf404'></a>

Source: The New York Times, Bloomberg, The Boston Herald, The Verge, CBS San Francisco, WHYY, TransitApp data
measuring frequency of app opens compared to projected use of the app (adjusted for annual growth)

<a id='8e6ea206-e50f-476a-899f-b12adc034917'></a>

Current as of 4/28

<a id='901bc1ca-761f-48b4-b870-f4c1be220970'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='bb094bda-548e-4b6f-a0ba-90ef7450bf11'></a>

**Sustained decline:** Transit app data shows use at persistently low levels through April

% change in public transit demand measured by app use

<a id='9924d899-9dd5-42ec-b33d-c0232688dc80'></a>

<::line chart: Title: Change in public transit demand. Y-axis: Percentage change from 20% to -100%. X-axis: Mar 5, Mar 24, Apr 12, Apr 29. Legend: All New York City, BART SF, MBTA Boston, NJ TRANSIT rail (and bus). The chart shows multiple lines representing the change in public transit demand over time for different cities/regions. All lines show a sharp decline in demand starting around mid-March, stabilizing at significantly lower levels (mostly between -60% and -80%) by late March and into April, with some slight fluctuations and a minor upward trend for NJ TRANSIT rail towards the end of April. Source: transitapp.com/coronavirus. Logo: transit.::>

<a id='0efed056-0849-48a7-bc25-cbaadcca4974'></a>

8

<!-- PAGE BREAK -->

<a id='653f22f0-c7b2-4837-bc13-47d5aa370d55'></a>

<::logo: [Unknown Brand]
2
A white number "2" is centered within a dark blue circular shape.::>

<a id='5896f320-15dd-42f2-b89d-20057df53243'></a>

Data collected March 23, 2020

<a id='b44a2649-314c-4278-81d9-5fd924c4b1d7'></a>

In the 08/09 financial crisis, urban transit
ridership followed a "U" shape...

<a id='e106e436-b9b1-4e9a-a214-c8afea08ca07'></a>

Impact of 2008/09 financial crisis on US urban transit!
By mode of transportation, average monthly ridership, in %

<a id='59c47103-2928-425f-95b2-e3ee83ffa3d5'></a>

<::Line chart titled "Crash of Lehman Brothers (September 2008)" with data from -8 to 40 on the x-axis. The left y-axis is labeled "Pre-outbreak = 100" ranging from 60 to 115. The right y-axis is labeled "Unemployment rate" ranging from 0 to 25. The legend shows: Heavy rail (subway) (black line), Bus (pink line), Commuter rail (blue line), Light rail (light blue line), and Unemployment rate (dashed light blue line). Vertical lines are marked with "Feb 2009", "Feb 2010", and "Feb 2011".::>

<a id='490da06c-c440-4f5b-bbb1-bd65ecbe2cc3'></a>

Months before/after crisis start

<a id='73bfc7d3-3d31-4caf-833b-dccd1603bd74'></a>

1. Includes New York, San Francisco, Washington DC, and Boston metro areas

<a id='1aaa7a3b-9b0c-44f1-82e4-5209ea834834'></a>

Source: National Transit Database (NTD), Bureau of Labor Statistics (BLS)

<a id='c68910fe-7ab7-4486-8832-e0731cb24446'></a>

... a decline with a long
path to recovery

<a id='b76c2257-500d-4265-8503-a8ed8ef88d6c'></a>

Financial crisis showed a long-term impact on transit ridership

<a id='025b34c3-e519-4d03-bda2-49569001563f'></a>

While seasonality led to normal fluctuations in ridership, there was a drop of up to 20% across systems (February 2010) correlating with the peak of the unemployment rate in the US

<a id='59094a66-0c85-4c33-b043-6b49d6d6462d'></a>

The impact of the crisis was felt over a long
time period, “U” vs. “V” shaped recovery

<a id='48f1c87f-5261-4837-ac6c-a6071796b702'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='278e0fe8-73a9-4deb-aa08-98cabb412d95'></a>

9

<!-- PAGE BREAK -->

<a id='f0ec05d0-be10-4dbf-90fe-005df2e631c9'></a>

3

<a id='b35cf45c-4798-4b1a-a3d0-3dc8cbcf3538'></a>

Data collected March 23, 2020

<a id='969e26db-c5f8-4a1b-9bbb-33507086b49f'></a>

Shocks affecting health and safety have historically had a “V” shape, with ridership dropping 30-50%, then returning to near normal in 2-3 months

<a id='e7c26495-207c-4a1c-900c-6be0536b34ef'></a>

Impact of historical crises on urban transit ridership

<a id='36e105e7-58de-4a51-9747-bfe13fff17b5'></a>

<::Line chart titled "Effect of safety/security crises – 9/11". The y-axis represents ridership relative to pre-event levels, where "Pre-event = 100". The y-axis ranges from 40 to 110. The x-axis represents "Months before/after 9/11", ranging from -3 to 10. A vertical line at x=0 is labeled "September 2001".The chart displays three lines:
- Black line: Average weekday ridership, Bay Area Rapid Transit (BART)
- Red line: Average daily ridership, Taipei Metro
- Blue line: Monthly ridership, Port-Authority Trans-Hudson (PATH)

Trends:
- BART (black line): Starts around 100, drops sharply at 0 (September 2001) to around 43, then recovers to 96 by month 1 and generally stays in the 90-96 range.
- Taipei Metro (red line): Starts around 100, peaks at 108 at -1 month, drops sharply at 0 to around 58, then gradually recovers and rises to 104 by month 10.
- PATH (blue line): Starts around 100, drops at 0 to 78, recovers to 86 by month 1, then declines to around 65 by month 5 and stays relatively low, around 70-72, for the remainder of the period.

Annotations:
- An arrow points to the lowest point of the BART line with the text: ">50% drop in urban transit in Bay Area post 9/11".
- Text near the PATH line from month 5 onwards: "Part of PATH did not reopen till mid-2003".
: chart::>

<a id='36736708-d3e8-4d8b-820f-41ae07495f24'></a>

Effect of health crises – SARS 2003

<a id='a926c3fd-f18e-4955-a7db-969775e61b95'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

- Average daily ridership, Taipei Metro
- Monthly ridership, public transportation Hong Kong¹

<a id='5c030993-8f50-48ca-abfe-2f133afd2127'></a>

<::Line chart showing two trends over time relative to an outbreak.
The Y-axis ranges from 40 to 110, with "Pre-outbreak = 100" as a reference.
The X-axis is labeled "Months before/after outbreak", ranging from -3 to 10.
A vertical line at X=0 indicates the "Start of outbreak (April 2003)".

One line (red) shows the following approximate values:
- At -3 months: 100
- At -2 months: 103
- At -1 month: 103
- At 0 months (start of outbreak): 95
- At 1 month: 67
- At 2 months: 77
- At 3 months: 93
- At 4 months: 96
- At 5 months: 100
- At 6 months: 104
- At 7 months: 104
- At 8 months: 108
- At 9 months: 97
- At 10 months: 108

Another line (blue) shows the following approximate values:
- At -3 months: 100
- At -2 months: 88
- At -1 month: 94
- At 0 months (start of outbreak): 75
- At 1 month: 88
- At 2 months: 88
- At 3 months: 94
- At 4 months: 97
- At 5 months: 95
- At 6 months: 99
- At 7 months: 96
- At 8 months: 100
- At 9 months: 96
- At 10 months: 92

Both lines start at 100 at -3 months. The red line peaks slightly before the outbreak, drops significantly after the outbreak starts, reaching a low at month 1, and then recovers, eventually surpassing its pre-outbreak level. The blue line fluctuates before the outbreak, drops sharply at the outbreak's start, recovers, and generally stays below or around the pre-outbreak level for most of the period after the outbreak.::>

<a id='63f1ac63-98c5-4753-aa3e-33f1543c9b95'></a>

1. Includes various modes of transportation, such as bus, rail, and ferry; does not include taxi

<a id='3e0fb75a-ba9a-4411-b275-0a0c84ed6d01'></a>

Source: Bay Area Rapid Transit, Taipei Metro, New York State Open Data (data.ny.gov), Hong Kong Census and Statistics Department

<a id='a1dde572-2b1b-4d21-b69b-769e1516f973'></a>

10

<!-- PAGE BREAK -->

<a id='ecfd7cf7-7c72-4f61-b4a2-b6806ad7fba1'></a>

3

<a id='ec42f2dc-8ac4-4bdc-bc0d-b89ddb30d002'></a>

Current as of 4/28/20

<a id='e39a5554-ec17-4db6-8ff4-826c20bd9043'></a>

How COVID-19 may be different than past health or safety shocks
Considerations for modeling a COVID-19 curve

<a id='23d83afa-5f80-45d4-8b8e-5cb2731eb175'></a>

<u>Not Exhaustive</u>

<a id='7bbc6fa1-9b72-4129-9c43-f2d05333dab8'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='3254d5d6-f74d-4547-acec-5905f582c9a8'></a>

# Length of crisis
This does not appear to be a point in time crisis like 9/11 but an extended multi-month and possibly multi-year event until the virus is contained and therapeutics and vaccines are developed

<a id='a21c6c26-2a89-4e34-acc4-218b406c5b7f'></a>

# Recovery pattern

As of this date, it is widely expected by public health officials that as social isolation measures are lifted, infection rates will increase

<a id='259bf3f0-502c-4edc-95d0-aa49b4a8f4dd'></a>

# Seasonality
It is unclear what the
impact of
seasonality, if any,
may be on the
coronavirus spread

<a id='c3ffe827-41d7-4237-903e-b9913b772816'></a>

# Potential for resurgence
Depending on multiple factors including herd immunity, human behaviors, hospital capacity readiness, and policies in the fall, a second major wave could be experienced, potentially coinciding with peak flu season

<a id='cb9e5e13-be2d-41db-890d-5a98bf3c114e'></a>

11

<!-- PAGE BREAK -->

<a id='ef8d2984-7259-4b4e-8ca2-31008d21123b'></a>

4 Two ridership scenarios were developed...

<a id='dd5daa9e-0b80-40d6-aa0e-36819de57e83'></a>

Potential scenarios for ridership through the end of 2020

<::Potential scenarios for ridership through the end of 2020
: line chart::>
% of base level ridership (previous year)
Pre-outbreak = 100

**Y-axis:**
100
90
80
70
60
50
40
30
20
10
0

**X-axis:**
Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec

**Legend:**
— Scenario 1: Earlier containment and recovery
— Scenario 2: Delayed containment and recovery

**Annotations:**
xx% Approximate decrease in annualized fare-based revenue
-60% (for Scenario 1, indicating decrease from pre-outbreak)
-75% (for Scenario 2, indicating decrease from pre-outbreak)

**Data Points (approximate):**
**Scenario 1 (Earlier containment and recovery):**
Jan: 100
Feb: 100
Mar: 50
Apr: 10
May: 10
Jun: 20
Jul: 35
Aug: 45
Sep: 60
Oct: 55
Nov: 55
Dec: 55

**Scenario 2 (Delayed containment and recovery):**
Jan: 100
Feb: 100
Mar: 70
Apr: 10
May: 10
Jun: 15
Jul: 25
Aug: 35
Sep: 40
Oct: 10
Nov: 10
Dec: 10
::>

<a id='8ee71607-64a4-4457-83e6-50ea08edd176'></a>

Source: MTA ridership scenarios analysis

<a id='20ade926-653c-4bea-b829-44f54d1f8a72'></a>

Current as of 4/17

<a id='7e7283ab-4677-4298-bf35-f16d65de4450'></a>

...combining the characteristics of health and economic crises

<a id='8b6e6c9f-7f8f-4ffc-aa91-e5270e88b709'></a>

Major assumptions underlying the difference in scenarios

<a id='3454a94a-efdc-4c64-8415-174c7ffa3d74'></a>

**Ramp-up after lockdown**
Scenario 2 features a relatively slower change from
current ridership levels due to an increased prevalence
of countervailing factors (e.g., personal preferences
away from transit, increased work from home, stronger
virus spread resurgence) compared to those modeled in
scenario 1

<a id='9485053d-ce50-4fbd-97f0-cb0855d32bf4'></a>

Resurgence in the fall

In both scenarios the COVID-19 pandemic could resume in the fall, but in scenario 2, the outcomes could be more dire (e.g., strained healthcare system, weak/lacking "herd immunity")

<a id='072d467c-8290-426c-94f3-80db03f21c23'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='e616b226-4de5-4371-8388-7b85e9597e5b'></a>

12

<!-- PAGE BREAK -->

<a id='ed2a66ad-da0c-4bb7-813a-a9eef3ed7e39'></a>

<::logo: [Unknown]4A white number '4' is centered within a dark blue circular background.::>

<a id='2185abff-dc50-4c81-8035-c715a5f6a728'></a>

Current as of 4/17

<a id='6f67b7ad-94fa-4691-8251-d8c580967a56'></a>

**Resulting fare revenue assumptions and modeling**
% of typical ridership in a given month
---

<a id='302ec754-5410-4604-9da5-600ebaaae5d9'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='d12d48bb-f7cc-42f8-b664-c478201cc08f'></a>

<table id="13-1">
<tr><td id="13-2">Assumptions</td><td id="13-3"></td><td id="13-4"></td><td id="13-5"></td><td id="13-6"></td><td id="13-7"></td><td id="13-8"></td><td id="13-9"></td><td id="13-a"></td><td id="13-b"></td><td id="13-c"></td><td id="13-d"></td><td id="13-e"></td></tr>
<tr><td id="13-f">Ridership as % of baseline in social distancing period</td><td id="13-g">10%</td><td id="13-h"></td><td id="13-i"></td><td id="13-j"></td><td id="13-k"></td><td id="13-l"></td><td id="13-m"></td><td id="13-n"></td><td id="13-o"></td><td id="13-p"></td><td id="13-q"></td><td id="13-r"></td></tr>
<tr><td id="13-s">System trough % of baseline in Great Recession</td><td id="13-t">90.6%</td><td id="13-u"></td><td id="13-v" colspan="3">Nov 12 over Nov 07 ridership trough</td><td id="13-w"></td><td id="13-x"></td><td id="13-y"></td><td id="13-z"></td><td id="13-A"></td><td id="13-B"></td><td id="13-C"></td></tr>
<tr><td id="13-D">System trough % of baseline in COVID-19</td><td id="13-E">85.9%</td><td id="13-F"></td><td id="13-G" colspan="2">50% greater impact</td><td id="13-H"></td><td id="13-I"></td><td id="13-J"></td><td id="13-K"></td><td id="13-L"></td><td id="13-M"></td><td id="13-N"></td><td id="13-O"></td></tr>
<tr><td id="13-P">Annual fare revenue</td><td id="13-Q">6.49</td><td id="13-R">B</td><td id="13-S" colspan="2">2020 Feb Plan revenue</td><td id="13-T"></td><td id="13-U"></td><td id="13-V"></td><td id="13-W"></td><td id="13-X"></td><td id="13-Y"></td><td id="13-Z"></td><td id="13-10"></td></tr>
<tr><td id="13-11">Mar-Dec fare revenue</td><td id="13-12">5.49</td><td id="13-13">B</td><td id="13-14"></td><td id="13-15"></td><td id="13-16"></td><td id="13-17"></td><td id="13-18"></td><td id="13-19"></td><td id="13-1a"></td><td id="13-1b"></td><td id="13-1c"></td><td id="13-1d"></td></tr>
<tr><td id="13-1e">Leakage from enhanced health procedures</td><td id="13-1f">10%</td><td id="13-1g"></td><td id="13-1h"></td><td id="13-1i"></td><td id="13-1j"></td><td id="13-1k"></td><td id="13-1l"></td><td id="13-1m"></td><td id="13-1n"></td><td id="13-1o"></td><td id="13-1p"></td><td id="13-1q"></td></tr>
<tr><td id="13-1r"></td><td id="13-1s"></td><td id="13-1t"></td><td id="13-1u"></td><td id="13-1v"></td><td id="13-1w"></td><td id="13-1x"></td><td id="13-1y"></td><td id="13-1z"></td><td id="13-1A"></td><td id="13-1B"></td><td id="13-1C"></td><td id="13-1D"></td></tr>
<tr><td id="13-1E">Monthly cashflow</td><td id="13-1F"></td><td id="13-1G"></td><td id="13-1H">$ 0.25</td><td id="13-1I">$ -</td><td id="13-1J">$ -</td><td id="13-1K">$ 0.05</td><td id="13-1L">$ 0.13</td><td id="13-1M">$ 0.21</td><td id="13-1N">$ 0.27</td><td id="13-1O">$ 0.27</td><td id="13-1P">$ 0.24</td><td id="13-1Q">$ 0.24</td></tr>
<tr><td id="13-1R">Monthly ridership</td><td id="13-1S"></td><td id="13-1T"></td><td id="13-1U">8.5%</td><td id="13-1V">8.5%</td><td id="13-1W">8.9%</td><td id="13-1X">8.3%</td><td id="13-1Y">8.3%</td><td id="13-1Z">8.2%</td><td id="13-20">8.5%</td><td id="13-21">9.1%</td><td id="13-22">8.2%</td><td id="13-23">8.1%</td></tr>
<tr><td id="13-24">Scenario 1- Moderate</td><td id="13-25"></td><td id="13-26"></td><td id="13-27">Mar-20</td><td id="13-28">Apr-20</td><td id="13-29">May-20</td><td id="13-2a">Jun-20</td><td id="13-2b">Jul-20</td><td id="13-2c">Aug-20</td><td id="13-2d">Sep-20</td><td id="13-2e">Oct-20</td><td id="13-2f">Nov-20</td><td id="13-2g">Dec-20</td></tr>
<tr><td id="13-2h">Virus spread largely contained in Q2, positive seasonal effect in Q3 with moderate resurgence in Q4</td><td id="13-2i"></td><td id="13-2j"></td><td id="13-2k">55%</td><td id="13-2l">10%</td><td id="13-2m">10%</td><td id="13-2n">20%</td><td id="13-2o">35%</td><td id="13-2p">50%</td><td id="13-2q">60%</td><td id="13-2r">55%</td><td id="13-2s">55%</td><td id="13-2t">55%</td></tr>
<tr><td id="13-2u">Ridership in remainder of 2020</td><td id="13-2v">40%</td><td id="13-2w"></td><td id="13-2x"></td><td id="13-2y"></td><td id="13-2z"></td><td id="13-2A"></td><td id="13-2B"></td><td id="13-2C"></td><td id="13-2D"></td><td id="13-2E"></td><td id="13-2F"></td><td id="13-2G"></td></tr>
<tr><td id="13-2H">Revenue loss</td><td id="13-2I">$3.82</td><td id="13-2J">B</td><td id="13-2K"></td><td id="13-2L"></td><td id="13-2M"></td><td id="13-2N"></td><td id="13-2O"></td><td id="13-2P"></td><td id="13-2Q"></td><td id="13-2R"></td><td id="13-2S"></td><td id="13-2T"></td></tr>
<tr><td id="13-2U">Monthly cashflow</td><td id="13-2V"></td><td id="13-2W"></td><td id="13-2X">$ 0.25</td><td id="13-2Y">$ -</td><td id="13-2Z">$ -</td><td id="13-30">$ 0.03</td><td id="13-31">$ 0.05</td><td id="13-32">$ 0.11</td><td id="13-33">$ 0.16</td><td id="13-34">$ -</td><td id="13-35">$ -</td><td id="13-36">$ -</td></tr>
<tr><td id="13-37">Monthly ridership</td><td id="13-38"></td><td id="13-39"></td><td id="13-3a">8.5%</td><td id="13-3b">8.5%</td><td id="13-3c">8.9%</td><td id="13-3d">8.3%</td><td id="13-3e">8.3%</td><td id="13-3f">8.2%</td><td id="13-3g">8.5%</td><td id="13-3h">9.1%</td><td id="13-3i">8.2%</td><td id="13-3j">8.1%</td></tr>
<tr><td id="13-3k">Scenario 2 - Severe</td><td id="13-3l"></td><td id="13-3m"></td><td id="13-3n">Mar-20</td><td id="13-3o">Apr-20</td><td id="13-3p">May-20</td><td id="13-3q">Jun-20</td><td id="13-3r">Jul-20</td><td id="13-3s">Aug-20</td><td id="13-3t">Sep-20</td><td id="13-3u">Oct-20</td><td id="13-3v">Nov-20</td><td id="13-3w">Dec-20</td></tr>
<tr><td id="13-3x">Virus spread less controlled, limited seasonality effect</td><td id="13-3y"></td><td id="13-3z"></td><td id="13-3A">55%</td><td id="13-3B">10%</td><td id="13-3C">10%</td><td id="13-3D">15%</td><td id="13-3E">20%</td><td id="13-3F">30%</td><td id="13-3G">40%</td><td id="13-3H">10%</td><td id="13-3I">10%</td><td id="13-3J">10%</td></tr>
<tr><td id="13-3K">Ridership in remainder of 2020</td><td id="13-3L">21%</td><td id="13-3M"></td><td id="13-3N"></td><td id="13-3O"></td><td id="13-3P"></td><td id="13-3Q"></td><td id="13-3R"></td><td id="13-3S"></td><td id="13-3T"></td><td id="13-3U"></td><td id="13-3V"></td><td id="13-3W"></td></tr>
<tr><td id="13-3X">Revenue loss</td><td id="13-3Y">$4.89</td><td id="13-3Z">B</td><td id="13-40"></td><td id="13-41"></td><td id="13-42"></td><td id="13-43"></td><td id="13-44"></td><td id="13-45"></td><td id="13-46"></td><td id="13-47"></td><td id="13-48"></td><td id="13-49"></td></tr>
</table>

<a id='eea7e819-5008-449e-93ab-557a918043a8'></a>

13

<!-- PAGE BREAK -->

<a id='7d47e95b-1b1c-40ff-af0d-5f4fb743f0ed'></a>

**Two toll scenarios were developed based on current data and traffic projections**
Toll revenue followed many of the same underlying assumptions as ridership
---

<a id='6216846e-abe8-4c55-8a11-6af2954c6686'></a>

<::Potential scenarios for traffic development through the end of 2020
% of base level traffic (previous year)

Legend:
  - Scenario 1: earlier containment and recovery (dark blue line)
  - Scenario 2: delayed containment and recovery (light blue line)

Chart data:
  - X-axis: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
  - Y-axis: 0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100
  - Scenario 1 data points (approximate):
    - May: 35%
    - Jun: 45%
    - Jul: 55%
    - Aug: 65%
    - Sep: 75%
    - Oct: 65%
    - Nov: 65%
    - Dec: 65%
  - Scenario 2 data points (approximate):
    - Jan: 100%
    - Feb: 100%
    - Mar: 70%
    - Apr: 35%
    - May: 35%
    - Jun: 40%
    - Jul: 45%
    - Aug: 50%
    - Sep: 55%
    - Oct: 35%
    - Nov: 35%
    - Dec: 35%
: line chart::>

<a id='819e0e49-3445-492f-8f9d-7cc0dcaa2bc1'></a>

Current as of 4/17
(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='ab39b1da-6d51-4a22-9caa-fc211addd268'></a>

Impact of social distancing
on toll revenue was
modeled using current data
(i.e., down to 35% of typical
traffic)

<a id='32dc1dab-b643-412a-8edb-b7dbb0ace1b1'></a>

Modeled a slightly longer
length of "lockdown" for
Scenario 2 than 1, following
the assumptions in the
ridership model

<a id='cc84fcde-94b1-4e63-8479-fbb92af0d57e'></a>

Similar to ridership model,
the impact of a
“resurgence” in Q4 was
modeled in two scenarios,
one returning to present
levels, one slightly more
resilient

<a id='d428ad31-6c43-4943-a85d-15f1a4786d19'></a>

14

<!-- PAGE BREAK -->

<a id='6abc9d2b-63d2-4ad7-84f4-28d5812b927e'></a>

Current as of 4/17

<a id='b97e1534-e570-42a5-89d4-121739ad04c3'></a>

Resulting toll revenue assumptions and modeling
% of typical ridership in a given month

<a id='729bc1b3-ad31-4d7a-8c01-8e759f907564'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='107048d2-bef9-4c47-b159-179dc53c63d8'></a>

<table id="15-1">
<tr><td id="15-2">Assumptions</td><td id="15-3"></td><td id="15-4"></td><td id="15-5"></td><td id="15-6"></td><td id="15-7"></td><td id="15-8"></td><td id="15-9"></td><td id="15-a"></td><td id="15-b"></td><td id="15-c"></td><td id="15-d"></td><td id="15-e"></td></tr>
<tr><td id="15-f">Ridership as % of baseline in social distancing period</td><td id="15-g">35%</td><td id="15-h" colspan="3">&lt;- Rev ridership</td><td id="15-i"></td><td id="15-j"></td><td id="15-k"></td><td id="15-l"></td><td id="15-m"></td><td id="15-n"></td><td id="15-o"></td><td id="15-p"></td></tr>
<tr><td id="15-q">System trough % of baseline in Great Recession</td><td id="15-r">84.4%</td><td id="15-s" colspan="6">&lt;-- Nov 12 over Nov 07 ridership trough</td><td id="15-t"></td><td id="15-u"></td><td id="15-v"></td><td id="15-w"></td><td id="15-x"></td></tr>
<tr><td id="15-y">System trough % of baseline in COVID-19</td><td id="15-z">76.5%</td><td id="15-A" colspan="4">&lt;-- 50% greater impact</td><td id="15-B"></td><td id="15-C"></td><td id="15-D"></td><td id="15-E"></td><td id="15-F"></td><td id="15-G"></td><td id="15-H"></td></tr>
<tr><td id="15-I">Annual toll revenue</td><td id="15-J">2.12</td><td id="15-K">B</td><td id="15-L" colspan="4">&lt;-- 2020 Feb Plan revenue</td><td id="15-M"></td><td id="15-N"></td><td id="15-O"></td><td id="15-P"></td><td id="15-Q"></td><td id="15-R"></td></tr>
<tr><td id="15-S">Mar-Dec toll revenue</td><td id="15-T">1.81</td><td id="15-U">B</td><td id="15-V"></td><td id="15-W"></td><td id="15-X"></td><td id="15-Y"></td><td id="15-Z"></td><td id="15-10"></td><td id="15-11"></td><td id="15-12"></td><td id="15-13"></td><td id="15-14"></td></tr>
<tr><td id="15-15">Leakage from enhanced health procedures</td><td id="15-16">0%</td><td id="15-17"></td><td id="15-18"></td><td id="15-19"></td><td id="15-1a"></td><td id="15-1b"></td><td id="15-1c"></td><td id="15-1d"></td><td id="15-1e"></td><td id="15-1f"></td><td id="15-1g"></td><td id="15-1h"></td></tr>
<tr><td id="15-1i"></td><td id="15-1j"></td><td id="15-1k"></td><td id="15-1l"></td><td id="15-1m"></td><td id="15-1n"></td><td id="15-1o"></td><td id="15-1p"></td><td id="15-1q"></td><td id="15-1r"></td><td id="15-1s"></td><td id="15-1t"></td><td id="15-1u"></td></tr>
<tr><td id="15-1v" colspan="2">Monthly cashflow --&gt;</td><td id="15-1w"></td><td id="15-1x">$ 0.12</td><td id="15-1y">$0.06</td><td id="15-1z">$ 0.07</td><td id="15-1A">$0.08</td><td id="15-1B">$0.10</td><td id="15-1C">$0.12</td><td id="15-1D">$0.13</td><td id="15-1E">$0.12</td><td id="15-1F">$0.11</td><td id="15-1G">$0.11</td></tr>
<tr><td id="15-1H" colspan="2">Monthly traffic --&gt;</td><td id="15-1I"></td><td id="15-1J">8.3%</td><td id="15-1K">8.3%</td><td id="15-1L">8.9%</td><td id="15-1M">8.7%</td><td id="15-1N">8.8%</td><td id="15-1O">8.9%</td><td id="15-1P">8.4%</td><td id="15-1Q">8.5%</td><td id="15-1R">8.2%</td><td id="15-1S">8.2%</td></tr>
<tr><td id="15-1T">Scenario 1- Moderate</td><td id="15-1U"></td><td id="15-1V"></td><td id="15-1W">Mar-20</td><td id="15-1X">Apr-20</td><td id="15-1Y">May-20</td><td id="15-1Z">Jun-20</td><td id="15-20">Jul-20</td><td id="15-21">Aug-20</td><td id="15-22">Sep-20</td><td id="15-23">Oct-20</td><td id="15-24">Nov-20</td><td id="15-25">Dec-20</td></tr>
<tr><td id="15-26">Virus spread largely contained in Q2, positive seasonal effect in Q3 with moderate resurgence in Q4</td><td id="15-27"></td><td id="15-28"></td><td id="15-29">71%</td><td id="15-2a">35%</td><td id="15-2b">35%</td><td id="15-2c">45%</td><td id="15-2d">55%</td><td id="15-2e">65%</td><td id="15-2f">75%</td><td id="15-2g">65%</td><td id="15-2h">65%</td><td id="15-2i">65%</td></tr>
<tr><td id="15-2j">Ridership in remainder of 2020</td><td id="15-2k">57%</td><td id="15-2l"></td><td id="15-2m"></td><td id="15-2n"></td><td id="15-2o"></td><td id="15-2p"></td><td id="15-2q"></td><td id="15-2r"></td><td id="15-2s"></td><td id="15-2t"></td><td id="15-2u"></td><td id="15-2v"></td></tr>
<tr><td id="15-2w">Revenue loss</td><td id="15-2x">$ 0.77</td><td id="15-2y">B</td><td id="15-2z"></td><td id="15-2A"></td><td id="15-2B"></td><td id="15-2C"></td><td id="15-2D"></td><td id="15-2E"></td><td id="15-2F"></td><td id="15-2G"></td><td id="15-2H"></td><td id="15-2I"></td></tr>
<tr><td id="15-2J"></td><td id="15-2K"></td><td id="15-2L"></td><td id="15-2M"></td><td id="15-2N"></td><td id="15-2O"></td><td id="15-2P"></td><td id="15-2Q"></td><td id="15-2R"></td><td id="15-2S"></td><td id="15-2T"></td><td id="15-2U"></td><td id="15-2V"></td></tr>
<tr><td id="15-2W" colspan="2">Monthly cashflow --&gt;</td><td id="15-2X"></td><td id="15-2Y">$ 0.12</td><td id="15-2Z">$0.06</td><td id="15-30">$ 0.07</td><td id="15-31">$0.07</td><td id="15-32">$0.08</td><td id="15-33">$0.09</td><td id="15-34">$0.10</td><td id="15-35">$0.06</td><td id="15-36">$0.06</td><td id="15-37">$0.06</td></tr>
<tr><td id="15-38" colspan="2">Monthly traffic --&gt; (text with blurred image)</td><td id="15-39"></td><td id="15-3a">8.3%</td><td id="15-3b">8.3%</td><td id="15-3c">8.9%</td><td id="15-3d">8.7%</td><td id="15-3e">8.8%</td><td id="15-3f">8.9%</td><td id="15-3g">8.4%</td><td id="15-3h">8.5%</td><td id="15-3i">8.2%</td><td id="15-3j">8.2%</td></tr>
<tr><td id="15-3k">Scenario 2 - Severe</td><td id="15-3l"></td><td id="15-3m"></td><td id="15-3n">Mar-20</td><td id="15-3o">Apr-20</td><td id="15-3p">May-20</td><td id="15-3q">Jun-20</td><td id="15-3r">Jul-20</td><td id="15-3s">Aug-20</td><td id="15-3t">Sep-20</td><td id="15-3u">Oct-20</td><td id="15-3v">Nov-20</td><td id="15-3w">Dec-20</td></tr>
<tr><td id="15-3x">Virus spread less controlled, limited seasonality effect</td><td id="15-3y"></td><td id="15-3z"></td><td id="15-3A">71%</td><td id="15-3B">35%</td><td id="15-3C">35%</td><td id="15-3D">40%</td><td id="15-3E">45%</td><td id="15-3F">50%</td><td id="15-3G">55%</td><td id="15-3H">35%</td><td id="15-3I">35%</td><td id="15-3J">35%</td></tr>
<tr><td id="15-3K">Ridership in remainder of 2020</td><td id="15-3L">44%</td><td id="15-3M"></td><td id="15-3N"></td><td id="15-3O"></td><td id="15-3P"></td><td id="15-3Q"></td><td id="15-3R"></td><td id="15-3S"></td><td id="15-3T"></td><td id="15-3U"></td><td id="15-3V"></td><td id="15-3W"></td></tr>
<tr><td id="15-3X">Revenue loss</td><td id="15-3Y">$ 1.02</td><td id="15-3Z">B</td><td id="15-40"></td><td id="15-41"></td><td id="15-42"></td><td id="15-43"></td><td id="15-44"></td><td id="15-45"></td><td id="15-46"></td><td id="15-47">(horizontal gray line)</td><td id="15-48">(horizontal gray line)</td><td id="15-49">(horizontal gray line)</td></tr>
</table>

<a id='4bb16401-fb8e-4ca6-8817-b4decff56f33'></a>

15

<!-- PAGE BREAK -->

<a id='201300bb-7e78-4bbc-bee4-f20f0f97dd74'></a>

Current as of 4/2
sing similar considerations, the projections for fare and tolls were

<a id='3841eb22-b4a2-488b-b65e-6ab40a177509'></a>

**extended through Q1 2022**
Ridership and traffic projections as % of monthly budget

<a id='949f1ba3-69d1-448e-b4a9-0f7c5d979840'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent
only potential scenarios based on discrete data from one point in time.
They are not intended as a prediction or forecast, and the situation is
changing daily.

<a id='e1dbec6e-fdaf-422d-b273-f91ba7a96ab4'></a>

<::Line chart showing Ridership and Traffic over time from March 2020 to March 2022, with two scenarios: Scenario 1 and Scenario 2. The y-axis for both charts is 'Percent' from 0 to 100. The x-axis is labeled with months and years (2020, 2021, 2022). A shaded vertical area from October to December 2020 is labeled 'Influenza season 2020/21'. A shaded vertical area from October to December 2021 is labeled 'Influenza season 2021/22'. A light blue shaded background covers the period from January 2021 to March 2022, with the text 'Further preliminary estimates were developed using assumptions on 2021' overlaid on it. The legend indicates 'Scenario 1' (dark blue line) and 'Scenario 2' (light blue line). A vertical dashed line at January 2021 is labeled 'Scenario 1: Vaccine first available'. Another vertical dashed line around August 2021 is labeled 'Scenario 1: Vaccine widely commercially available'. A text box around September 2021 is labeled 'Scenario 2: Vaccine not commercially available until Fall 2022'.

**Top Chart: Ridership**
- **Scenario 1 (dark blue line)**: Starts at ~55% in March 2020, drops to ~10% in April-May 2020, then gradually increases to ~60% by September 2020, stabilizes at ~55% from October to December 2020, then increases steadily from January 2021 to ~80% by July 2021, and remains stable at ~80% through March 2022.
- **Scenario 2 (light blue line)**: Starts at ~55% in March 2020, drops to ~10% in April-May 2020, gradually increases to ~40% by September 2020, drops to ~10% from October to December 2020, then gradually increases from January 2021 to ~80% by March 2022.

**Bottom Chart: Traffic**
- **Scenario 1 (dark blue line)**: Starts at ~70% in March 2020, drops to ~35% in April-May 2020, then gradually increases to ~75% by September 2020, drops to ~60% from October to December 2020, then gradually increases from January 2021 to ~85% by August 2021, and remains stable at ~85% through March 2022.
- **Scenario 2 (light blue line)**: Starts at ~70% in March 2020, drops to ~35% in April-May 2020, then gradually increases to ~55% by September 2020, drops to ~35% from October to December 2020, then gradually increases from January 2021 to ~80% by March 2022.
: line chart::>

<a id='a6b8a72d-f716-4a93-8320-3127366231f8'></a>

16

<!-- PAGE BREAK -->

<a id='146fe2a4-6543-465d-ab22-c40e8807554e'></a>

Contents

<a id='d15eab2c-f7c6-41a8-b275-636c4353d7bf'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='c6a42d54-482f-4c05-b30d-404c58871dfd'></a>

Fare and toll revenue methodology

**Non-fare revenue methodology**

Additional operating expense methodology

Operating gap

Impact of filling the gap

<a id='1ba43416-83c4-4610-81be-53eee43769c3'></a>

17

<!-- PAGE BREAK -->

<a id='aaa4b0bc-5350-45ab-ad17-16bed4c9cdf3'></a>

Overview of revenue components and forecast approach

<a id='020a31ad-d3ef-4ffa-92be-a3feb1c7e52e'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one point
in time. They are not intended as a prediction or
forecast, and the situation is changing daily.

<a id='da441e9a-416d-44e2-93e6-36b9b003332d'></a>

Focus of this chapter

<a id='91464805-c008-4ba1-8b14-ba7381304fec'></a>

# Fare and toll revenue

Applied different scenarios of how long the
current state of social distancing will last based
on actuals, and what ridership/mobility ramp-up
might look like after that. For those scenarios,
considered the impact of epidemiology, policy
effects, and behavioral changes

<a id='7eaac7e2-101c-4b54-bcda-941699eae14e'></a>

v
Ridership/traffic curves

<a id='57dbaca3-bf3c-4fb6-9ca2-7ecc0da5dc9e'></a>

## Non-fare revenue

Identified five archetypes of tax or subsidy revenue – Employment, Real Estate and Mortgages, Sales, Business Income, and Mobility – each with a distinct driver. Created a multiplier for each archetype, which was applied to each source to forecast 2020 revenue

---

<br>

---

## Tax-specific change profiles

<a id='13d8232b-ed2c-4b00-94cb-65faaa421d0c'></a>

18

<a id='f831cd58-ec9d-41e0-ba07-af7d31ae28ac'></a>

<::An icon of a plus sign inside a circle.: figure::>

<!-- PAGE BREAK -->

<a id='ee3e3cd1-e310-4ae4-bc7a-d049eead4f76'></a>

Current as of 4/17

<a id='c640cc55-5f36-433c-92da-7cb10e613f50'></a>

Approach to forecasting tax and subsidy
revenue (1/2)

<a id='1664a10d-a6bc-4b80-8e80-62b7922c3406'></a>

(4/28/20) Please see disclaimer on page 3. These
analyses represent only potential scenarios based
on discrete data from one point in time. They are
not intended as a prediction or forecast, and the
situation is changing daily.

<a id='1dcfb502-47cc-4ae9-aea2-ecdf65a44fc4'></a>

Details to follow
<table id="19-1">
<tr><td id="19-2">Archetype</td><td id="19-3">Methodology for multiplier calculation</td><td id="19-4">Applicable MTA taxes</td></tr>
<tr><td id="19-5">Employment</td><td id="19-6">Projected changes in wages and salaries from employment for the NY counties served by MTA</td><td id="19-7">Payroll Mobility Tax</td></tr>
<tr><td id="19-8">Real Estate + Mortgages</td><td id="19-9">Application of historical % change of MRT and Urban tax (40%) during Great Recession</td><td id="19-a">MRT 1 + 2; Urban tax (MRT, Real Property Transfer Tax), Mansion Tax</td></tr>
<tr><td id="19-b">Sales</td><td id="19-c">% drop of projected 2020 GDP vs. 2019 actuals for sales tax relevant industries (retail and leisure and hospitality)</td><td id="19-d">MMTOA (MTA District Sales Tax, Hold Harmless for Clothing)</td></tr>
<tr><td id="19-e">Business Income</td><td id="19-f">Used corporate income tax elasticity during the Great Recession applied to % change between forecasted 2020 GDP and 2019 actual GDP</td><td id="19-g">MMTOA (Corp franchise tax, both Corp &amp; utilities taxes, insurance and bank taxes)</td></tr>
<tr><td id="19-h">Mobility</td><td id="19-i">Calculated based on expected traffic volume, incorporating thinking on epidemiological, behavioral, policy, and economic factors by using forecasted toll revenue as proxy</td><td id="19-j">MMTOA (PBT); PBT (Petroleum business tax, Motor fuel tax, MCTD taxicab tax, MTA passenger car rentals); FHV surcharge</td></tr>
<tr><td id="19-k">Other</td><td id="19-l">Average of all other tax multipliers</td><td id="19-m">MMTOA (investment income), &lt;1% of 2020 budget</td></tr>
</table>

<a id='ee4fad97-d380-40c4-96d6-73b36477e27f'></a>

_**No or minimal anticipated change**_ _Not determined by underlying policy or economic driver_

<a id='88855fb5-7ace-476b-a005-4216304b27f5'></a>

PBT (Motor vehicle fees); MRT adjustments; CBDTP; Internet marketplace tax; State and local subsidies (Local and State operating assistance, Station maintenance); other funding agreements (for MTA bus, SI Railway, Metro North), PMT replacement fund; B&T operating surplus transfer¹

<a id='e7147f4a-7d1f-4c09-b267-4b6e2425002c'></a>

1. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue losses

<a id='fed0afdd-e20d-4990-99cf-ea43d49f7d7a'></a>

19

<!-- PAGE BREAK -->

<a id='672b66a5-7e58-4cc6-9394-46b1f62c6db5'></a>

Current as of 4/17

<a id='6ffaea03-da6f-49cc-89a2-7dbbd31556c6'></a>

Approach to forecasting tax and subsidy revenue (2/2)

<a id='37723af5-0609-4249-aa8a-d311dce583b1'></a>

(4/28/20) Please see disclaimer on page 3. These
analyses represent only potential scenarios based
on discrete data from one point in time. They are
not intended as a prediction or forecast, and the
situation is changing daily.

<a id='b0bb53b3-a598-4412-b5a4-bf862ffefe9c'></a>

Archetype Considerations for analysis/methodology What you need to believe 1 Employment <::icon: Three stick figures, one male and two female, standing together::> • Based on overall employment changes by quarter tied to macroeconomic modeling by industry for 12 MTA counties in New York State • Adjustments applied based on an analysis of jobs at risk, reducing the amount of wages and labor beyond employment loss to reflect reality of changing labor patterns (furloughs, loss of hours) by industry • Industries weighted by wage levels in New York State • Employment is going to track macroeconomic changes and impact the amount of payroll tax collected 2 Real estate + Mortgages <::icon: A house with a chimney and a door::> • Based on performance of MRT (MRT-1, MRT-2 and MRT in Urban Tax) and Real Property Transfer Tax during Great Recession • Saw ~40% y.o.y. drop in real estate and mortgage-related taxes 2007- 2008, with further declines in 2008-2009 • Applied that initial decline of 40% to each relevant tax, given the forecasting is for the first year of COVID-19 impact (2020) • There are two opposing forces at play right now: — This recession is likely going to be deeper/longer than the GR — At the same it may not be a housing real estate crisis, i.e. not the same expectations of credit drying up, refinancing going down etc. • Assume that those two effects will roughly offset each other so that using the GR to model the forecast is still applicable 3 Sales <::icon: A shopping cart::> • Apply the % change y.o.y. for the 2020 GDP forecast (inflation adjusted) for MTA NYS counties vs. 2019 data for each quarter to the 2019 tax • Since ~20% of the tax base is from B2B, used weighted average of GDP change for Retail and Leisure/Hospitality (80%) + GDP of remaining industries (20%, proxy for B2B) to reflect underlying tax base • Sales tax will closely track GDP 4 Business Income <::icon: A line graph with two lines showing trends::> • Assume that the elasticity of corporate income tax to GDP is the same as in the Great Recession and apply that factor to project 2020 data • Many of the considered taxes are surcharges on the State corporate income tax, so apply the same logic as to the tax itself • Great Recession is a good model for what is happening to the economy right now, i.e. that the elasticity relationship between change in tax and change in GDP during times of crises is constant/very similar 5 Mobility¹ <::icon: A car::> • Based on projected decrease in toll revenue by month (see details on toll revenue projection and methodology) • Economic and public health policy decisions (social distancing, business closures etc.) have a large impact on mobility • Even after the crisis, there will likely be a "new normal" – below old levels 

<a id='29b6661c-9f6d-436a-9dc0-ef3107c324b3'></a>

1. Mobility assumptions explained in further detail in Fare revenue section

<a id='2b710958-0b4a-4eea-a578-73070749e9ee'></a>

20

<!-- PAGE BREAK -->

<a id='e9acb205-36d1-4ed1-b9d0-f08a05a6d650'></a>

1 Economic scenario for change in employment used in the analysis

<a id='ab648abb-b8bc-4c81-a63e-2885bb1b6789'></a>

<::Change in Employment relative to Q4 2019: line chart::>Percent: The y-axis ranges from 0 to -18 in increments of 2. The x-axis shows time points from Q4 2019 to Q4 2020. A red line, labeled "Employment (MTA counties in NY)", shows the change in employment. The line starts at 0% in Q4 2019, remains at 0% in Q1 2020, drops to approximately -13% in Q2 2020, then further declines to approximately -15% in Q3 2020, and reaches approximately -17% in Q4 2020.

<a id='dedbcd48-25d1-43d6-a048-52886c9439f9'></a>

Source: Data tied to analysis of A1 scenario – see pages 22 and 23

<a id='e4899bef-e607-484b-8d26-f75309dde9f3'></a>

Current as of 4/17
(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='cc6f07ae-8083-4324-aee0-7ff1394d0f67'></a>

Changes in employment levels for the NY MTA counties were modified using an analysis of "Jobs at Risk" to capture income impacts beyond just job loss (e.g., furloughs, lost hours)

<a id='04b74518-ecaf-40a8-85ea-31182f7fc5ab'></a>

Industries were also weighted by average income

<a id='f822152e-7e50-4f0f-874e-5c5285e9f494'></a>

The modeled change in
income across all industries
in the NY MTA counties was
then used to predict
employment-related tax
income

<a id='f72f246b-d658-4161-9166-f2698648bf84'></a>

21

<!-- PAGE BREAK -->

<a id='caacfaf1-faf3-4d98-9501-582b42c0ef67'></a>

2
Historical real estate tax performance in the
Great Recession
$ Millions of tax received and % change from previous year

<a id='ca46290f-a8e4-46ed-aaca-3f7f924eea67'></a>

<table id="22-1">
<tr><td id="22-2"></td><td id="22-3">2007</td><td id="22-4">2008</td><td id="22-5">2009</td><td id="22-6">2010</td><td id="22-7">2011</td><td id="22-8">2012</td></tr>
<tr><td id="22-9">MRT-1</td><td id="22-a">460</td><td id="22-b">277</td><td id="22-c">150</td><td id="22-d">147</td><td id="22-e">160</td><td id="22-f">187</td></tr>
<tr><td id="22-g">Difference relative to prior year</td><td id="22-h"></td><td id="22-i">-40%</td><td id="22-j">-46%</td><td id="22-k">-2%</td><td id="22-l">9%</td><td id="22-m">17%</td></tr>
<tr><td id="22-n">MRT-2</td><td id="22-o">243</td><td id="22-p">142</td><td id="22-q">92</td><td id="22-r">92</td><td id="22-s">85</td><td id="22-t">92</td></tr>
<tr><td id="22-u">Difference relative to prior year</td><td id="22-v"></td><td id="22-w">-42%</td><td id="22-x">-35%</td><td id="22-y">0%</td><td id="22-z">-8%</td><td id="22-A">9%</td></tr>
<tr><td id="22-B">Total</td><td id="22-C">703</td><td id="22-D">419</td><td id="22-E">242</td><td id="22-F">239</td><td id="22-G">245</td><td id="22-H">280</td></tr>
<tr><td id="22-I">Difference relative to prior year</td><td id="22-J"></td><td id="22-K">-40%</td><td id="22-L">-42%</td><td id="22-M">-1%</td><td id="22-N">2%</td><td id="22-O">14%</td></tr>
<tr><td id="22-P">Real Property Transfer Tax (100%)</td><td id="22-Q">664</td><td id="22-R">389</td><td id="22-S">110</td><td id="22-T">138</td><td id="22-U">297</td><td id="22-V">322</td></tr>
<tr><td id="22-W">Difference relative to prior year</td><td id="22-X"></td><td id="22-Y">-41%</td><td id="22-Z">-72%</td><td id="22-10">25%</td><td id="22-11">116%</td><td id="22-12">9%</td></tr>
<tr><td id="22-13">Urban Mortgage Recording Tax (100%)</td><td id="22-14">318</td><td id="22-15">193</td><td id="22-16">56</td><td id="22-17">55</td><td id="22-18">95</td><td id="22-19">130</td></tr>
<tr><td id="22-1a">Difference relative to prior year</td><td id="22-1b"></td><td id="22-1c">-39%</td><td id="22-1d">-71%</td><td id="22-1e">-1%</td><td id="22-1f">72%</td><td id="22-1g">36%</td></tr>
<tr><td id="22-1h">Less 4% NYC DOT</td><td id="22-1i">-39</td><td id="22-1j">-23</td><td id="22-1k">-7</td><td id="22-1l">-8</td><td id="22-1m">-16</td><td id="22-1n">-18</td></tr>
<tr><td id="22-1o">Less 6% Paratransit</td><td id="22-1p">-59</td><td id="22-1q">-35</td><td id="22-1r">-10</td><td id="22-1s">-12</td><td id="22-1t">-24</td><td id="22-1u">-27</td></tr>
<tr><td id="22-1v">Total</td><td id="22-1w">884</td><td id="22-1x">524</td><td id="22-1y">150</td><td id="22-1z">174</td><td id="22-1A">353</td><td id="22-1B">407</td></tr>
<tr><td id="22-1C">Difference relative to prior year</td><td id="22-1D"></td><td id="22-1E">-41%</td><td id="22-1F">-71%</td><td id="22-1G">16%</td><td id="22-1H">103%</td><td id="22-1I">15%</td></tr>
</table>

<a id='e5223c7d-e530-4691-9412-fe957afc9ae7'></a>

MRT 1 & 2

<a id='fda9b1f3-a331-4258-b2a8-999c3bb17729'></a>

Urban tax

<a id='1ecd0202-4698-4c3d-8042-b1ab4dbad925'></a>

Source: MTA historical tax data

<a id='7888fc97-38f7-4ab1-bb0c-f6eab3c632f0'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one point
in time. They are not intended as a prediction or
forecast, and the situation is changing daily.

<a id='d2d55b15-6393-41f5-8785-c7b69181ec0d'></a>

The first year of the Great
Recession was used to
inform analysis of the first
year of the current crisis

<a id='55bc38cf-6934-403d-8acb-e9d62e160ad8'></a>

While the magnitude of this
crisis is larger, it is not a
housing or liquidity crisis -
two counteracting effects
which were assumed to
roughly balance out

<a id='4aefcf6f-63bb-4f54-8ca1-6ecca828c703'></a>

Used the historic
performances of the MTA's
real estate tax revenue to
capture potential
differences or similarities
between residential and
commercial real estate

<a id='9512415c-c206-4df7-83b7-1139589ec5de'></a>

22

<!-- PAGE BREAK -->

<a id='8dbddafd-cc51-437a-96e7-75edc28f3c4e'></a>

<u>Preliminary</u>

<a id='6646d2a7-eb4b-49f0-bed9-a22ac1e50812'></a>

# Economic scenario for change in GDP (1/2)

## Macroeconomic scenarios

<a id='207a9bc9-0ec7-49c2-aaad-0e1175dd413c'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='95519119-b6a0-44e3-9efb-1dd66784d022'></a>

option Details to follow: [ ]

<a id='995ef560-95b9-46a5-8dc7-ee4f193844ca'></a>

Updated April 20, 2020

<a id='40ebb97e-5399-46b6-9aa4-8fd9d32c5b16'></a>

Scenarios for the Economic Impact of the COVID-19 Crisis
GDP Impact of COVID-19 Spread, Public Health Response, and Economic Policies

<a id='59b24fde-7290-4729-be4a-55e070907a67'></a>

Virus Spread &
Public Health
Response

Effectiveness of the public
health response
in controlling the spread
and human impact
of COVID-19

<a id='de9b338d-5aa9-436a-bef0-bf2fe169cdc1'></a>

Rapid and effective
control of virus spread
Strong public health response succeeds
in controlling spread in each country
within 2-3 months

<a id='87d336c6-bf9e-4f0c-8daa-9ed69dc3994b'></a>

Effective response, but
(regional) virus recurrence
Initial response succeeds but is
insufficient to prevent localized
recurrences; local social distancing
restrictions are periodically reintroduced

<a id='ae6717de-59ac-4bcb-8b4d-c9a3ab597697'></a>

Broad failure of public
health interventions

Public health response fails
to control the spread of the virus
for an extended period of time
(e.g., until vaccines are available)

<a id='535d6d25-0f8a-4686-89b3-c42e72ea4ef3'></a>

<::Figure: Two charts are presented side-by-side. The first chart, labeled "B1", displays a U-shaped curve on a simple x-y coordinate system. Below the chart, the text reads: "Virus contained, but sector damage; lower long-term trend growth". The second chart, labeled "A3", also displays a U-shaped curve on a simple x-y coordinate system. Below this chart, the text reads: "Virus contained, growth returns". Both charts illustrate a similar pattern of initial decline followed by recovery, with the text providing context for each scenario.: chart::>

<a id='abc061bc-bac0-4b45-b00b-7e67693c791e'></a>

<::B2chart showing a curve that drops sharply, then recovers slowly with small fluctuations, ending below the initial level.Virus recurrence, slow long-term growth insufficient to deliver full recovery: chart::><::A1chart showing a curve that drops sharply, then recovers slowly with small fluctuations, ending with a higher value than the previous chart.Virus recurrence; slow long-term growth with muted world recovery: chart::>

<a id='31d624de-02df-4fdb-82d8-6157acff8403'></a>

<::Figure B3: Graph showing a curve that starts high, decreases sharply, and then flattens out, indicating a prolonged downturn without economic recovery.
Pandemic escalation, prolonged downturn without economic recovery
: figure::>
<::Figure B4: Graph showing a curve that starts high, decreases, and then slowly rises again, forming a U-shape, indicating a slow progression towards economic recovery.
Pandemic escalation, slow progression towards economic recovery
: figure::>

<a id='0c69b9de-1ba7-4cce-8bec-f43362738e3b'></a>

<::A2
[chart showing a V-shaped curve]
Virus recurrence; return to trend growth with strong world rebound
: chart::>

<a id='72c70e18-e82c-469d-9b9b-a37f0b62b681'></a>

<::B5
A W-shaped curve, indicating a double dip or prolonged downturn before recovery.
Pandemic escalation, delayed but full economic recovery
:chart::>

<a id='a25b50d5-5dca-4c14-ac65-8a39129b64c8'></a>

Ineffective
interventions
Self-reinforcing recession dynamics
kick-in; widespread bankruptcies and
credit defaults; potential banking crisis

<a id='f6c88706-19a5-42f8-95be-bf6e26c0b65a'></a>

**Partially effective interventions**
Policy responses partially offset economic damage; banking crisis is avoided; recovery levels muted

<a id='933c9a82-4ad8-4608-b431-7236fc580907'></a>

**Highly effective interventions**

Strong policy responses prevent
structural damage; recovery to pre-
crisis fundamentals and momentum

<a id='f180450f-e30d-4845-a23a-17ec521252ee'></a>

Knock-on Effects & Economic Policy Response
Speed and strength of recovery depends on whether policy moves can mitigate self-reinforcing recessionary dynamics (e.g., corporate defaults, credit crunch)

<a id='2619d21f-8e4e-4c80-956c-171f4e35715f'></a>

23

<a id='6cf2024b-025f-4162-8666-0a95379afea4'></a>

A4

<::A chart with a V-shaped curve
: chart::>

Virus contained; strong growth rebound

<!-- PAGE BREAK -->

<a id='f9b842da-35ad-44de-81ea-04fde9651e01'></a>

<::logo: [Unknown]3/4A dark circular shape contains the text "3/4" in white.::>

<a id='afbda4db-2d4c-41d3-bcdc-4d8315b95747'></a>

Preliminary

<a id='a2e778a7-6537-4b37-8cae-a61fcf66b9b5'></a>

Economic scenario
for change in GDP
(2/2)

Scenario A1 used for analysis

<a id='77e8f6e9-e5a5-4a58-be5d-571100d016de'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='3bc06a37-bfd8-4b99-ad7a-8212409a035e'></a>

Updated April 20, 2020

**Pace of decline of economic activity in Q2 2020 is likely to be the steepest since decline since WWII**

---
High frequency indicators show the drop has already started in Q1

<a id='b109ad55-785b-4611-bbb5-69ceab52b6f2'></a>

United States, comparison of post-WWII recessions% real GDP draw-down from previous peak<::Line chart titled "United States, comparison of post-WWII recessions" showing "% real GDP draw-down from previous peak" on the y-axis (from 0 to -14) and quarters after peak (+Q1 to +Q14) on the x-axis.The chart displays multiple lines representing different recessions or scenarios:
- A black line labeled "Scenario A3" drops to a low of -8% by +Q2, then partially recovers, then drops again, and finally recovers to 0 by +Q10.
- A dark blue line labeled "Scenario A1" drops to a low of -12.5% by +Q4, then gradually recovers to 0 by +Q13.
- A light purple line labeled "73 oil shock" drops to about -3% by +Q3 and recovers to 0 by +Q13.
- A light blue line labeled "81 recession" drops to about -4% by +Q4 and recovers to 0 by +Q13.
- A medium blue line labeled "Global financial crisis" drops to about -4.5% by +Q5 and recovers to 0 by +Q12.
- Several other unlabeled lines (in various shades of blue and green, some dashed) show different recession profiles, generally dropping between -2% and -4% and recovering within +Q8 to +Q12.
: chart::>Source: Historical Statistics of the United States Vol 3, Bureau of economic analysis, McKinsey team analysis, in partnership with Oxford EconomicsMcKinsey & Company 12

<a id='e05c22f5-8563-4a66-80c2-d2aed0e73fdd'></a>

12

<a id='f1a98958-61ff-4d63-9d65-750e918575d0'></a>

24

<!-- PAGE BREAK -->

<a id='a0c675e3-8239-4508-afbb-46079e1b6d8b'></a>

5 Mobility-related tax methodology follows toll projections

<a id='25d7b5b7-737f-49ea-9762-4a642553eb77'></a>

Potential scenarios for traffic development through the end of 2020
<::chart: Line chart showing two scenarios for traffic development through the end of 2020.
Y-axis: % of base level traffic (previous year), ranging from 0 to 100 in increments of 10.
X-axis: Months from Jan to Dec.

Legend:
— Scenario 1: earlier containment and recovery (dark blue line)
— Scenario 2: delayed containment and recovery (light blue line)

Data points for Scenario 1 (earlier containment and recovery):
- May: 35%
- Jun: 45%
- Jul: 55%
- Aug: 65%
- Sep: 75%
- Oct: 65%
- Nov: 65%
- Dec: 65%

Data points for Scenario 2 (delayed containment and recovery):
- Jan: 100%
- Feb: 100%
- Mar: 70%
- Apr: 35%
- May: 35%
- Jun: 40%
- Jul: 45%
- Aug: 50%
- Sep: 55%
- Oct: 35%
- Nov: 35%
- Dec: 35%::>

<a id='1469c38d-1ebc-4f12-bf72-c2e8dd27aa81'></a>

Current as of 4/17

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='d676ea7b-2907-4144-b964-c0efd554c31f'></a>

Tolls were assumed to be
an indicator for relative
performance of mobility-
driven taxes (e.g., PMT)

<a id='32111309-3d24-4d22-a05c-b14c078bcd6a'></a>

These taxes were modeled
using the toll curves
developed during the toll
revenue analysis

<a id='146b34c5-8166-42ea-ae32-ed83ff4710cb'></a>

25

<!-- PAGE BREAK -->

<a id='764a4bfe-f5fe-4c27-a1b6-75babb29c46b'></a>

Resulting non-fare revenue modeling for 2020 by groups of taxes

<a id='e9d2e9b5-e43f-4cf0-97af-3d5623ca9a86'></a>

Current as of 4/17

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='1ecd5e1d-54a9-493b-8845-ad7cdfe95aa7'></a>

<table id="26-1">
<tr><td id="26-2">Tax group</td><td id="26-3">Original 2020 Budget, $B</td><td id="26-4">Projected losses in 2020, $B</td><td id="26-5">Decrease projected for 2020, %</td></tr>
<tr><td id="26-6">Mobility</td><td id="26-7">1.9</td><td id="26-8">(0.4) - (0.5)</td><td id="26-9">-23 to -29%</td></tr>
<tr><td id="26-a">Employment</td><td id="26-b">1.6</td><td id="26-c">(0.3)</td><td id="26-d">-17%</td></tr>
<tr><td id="26-e">Real Estate</td><td id="26-f">1.5</td><td id="26-g">(0.4)</td><td id="26-h">-27%</td></tr>
<tr><td id="26-i">Business income</td><td id="26-j">1.1</td><td id="26-k">(0.3)</td><td id="26-l">-30%</td></tr>
<tr><td id="26-m">Sales</td><td id="26-n">0.9</td><td id="26-o">(0.3)</td><td id="26-p">-32%</td></tr>
<tr><td id="26-q">Other</td><td id="26-r">0.02</td><td id="26-s">(0.0)</td><td id="26-t">-42 to -44%</td></tr>
<tr><td id="26-u">No change¹</td><td id="26-v">2.1</td><td id="26-w"></td><td id="26-x">0%</td></tr>
<tr><td id="26-y">Total²,³</td><td id="26-z">8.4</td><td id="26-A">(1.6) – (1.8)</td><td id="26-B">-19 to -21%</td></tr>
</table>

<a id='8714a3cb-d2e6-46d0-9cda-6e91a537a388'></a>

1. 25% of the original 2020 budget was predicted to remain unchanged because it represented legal commitments to provide funds, or because it appeared the underlying drivers were unlikely to shift significantly in 2020 (e.g., Payroll Mobility Tax Replacement Funds, Internet Marketplace Tax, Motor Vehicle Fees for registering vehicles)
2. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue losses
3. Totals may not add due to rounding. Total also does not reflect the impact of adjustments (applies to Urban Tax, the "Mansion Tax", and the Internet Marketplace Tax)

<a id='15568dfc-70e3-4097-a579-20e3e6a20c5c'></a>

26

<!-- PAGE BREAK -->

<a id='f08f94b2-39ce-4895-b320-ea024eb3ce9d'></a>

Using similar considerations, the projections for non-fare revenue were extended through 2021

---

Scenario assumptions and resulting estimate of financial impact

<a id='d9e33442-1d5d-458d-9215-1410cadb86a5'></a>

# Approach to estimating non-fare revenue for 2021

## Major assumptions for non-fare

### Mobility
Mobility will continue to track toll revenue

### Employment
Employment will improve from Q4 of 2020 but slowly and will continue to reflect at-risk jobs

### Real estate
Second year of this crisis will follow GDP growth; second year of the Great Recession is not a good proxy

### Sales
Sales taxes will track GDP growth

### Business income
Business income will lag GDP growth (based on historical precedent)

<a id='db8837d3-c909-413e-93fe-4bfe005bc389'></a>

<::
Financial impact on fare and toll revenue, in $B

[Piggy bank icon]

| | Budget¹ | Projected delta |
|:---|:---|:---|
| CY 2020 | 8.4 | (1.6) - (1.8) |
| CY 2021 | 8.4 | (1.8) - (2.0) |
: table::>

<a id='dc839683-d92d-4457-9b16-ff91b36ed99d'></a>

1. As per the 2020 February Financial plan. 2021 budget deltas do not take into account any revisions to revenue expectations that may have taken place since releasing the plan (e.g., a revised view on revenue from congestion pricing); they are deltas from the plan as-released.

<a id='4ee8224c-c73c-43d7-9f0a-8558ea4b50a9'></a>

Current as of 4/24

<a id='3a9e1f27-17a8-463f-b2a0-1deff1a2c5a6'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='7a71bf04-b592-4749-ad15-d619d185583c'></a>

Underlying economic
conditions could be similar
or more severe in 2021 as
in 2020 but potentially
offset by an improvement in
mobility

<a id='b59d91e8-e491-472e-ab03-5350acffe3ba'></a>

There are areas where MTA
may make decisions that
will impact the overall totals
(e.g., capital fund
allocations)

<a id='91b2c1d0-8b01-4698-a024-f737b7fbd0f6'></a>

27

<!-- PAGE BREAK -->

<a id='6efd0df9-572a-4c9a-ba3b-3b12717472d5'></a>

Contents

<a id='e8919f85-2482-4a55-9131-e00d42bd66b0'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='e3f7d9f8-b6cc-45c5-85ee-013abc936a50'></a>

Fare and toll revenue methodology
Non-fare revenue methodology

<a id='5ad37a1e-2b9c-4238-aaa7-e0ffa6387f30'></a>

**Additional operating expense methodology**
Operating gap
Impact of filling the gap

<a id='91736811-ad62-451b-82d0-bd5d03e62ccf'></a>

28

<!-- PAGE BREAK -->

<a id='00ce35b4-44e2-4f14-827f-8e9e2a2340ea'></a>

Current as of 4/17

<a id='c764f579-4718-4c49-b5a4-c5ee5cf99476'></a>

Methodology for initial estimate of additional operating expenses

<a id='546d7204-2a4f-4aae-84f8-57797b3ad294'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='612afa6a-962d-427a-abfc-6d5d806927e9'></a>

# Top-down

Identified the overall operating expenses in the 2020 MTA budget that would be impacted by increased public health measures (e.g., materials) and applied a benchmark of ~6% increase, as determined from the change in Hong Kong MTR financials during the peak month of SARS in 2003

**$0.4-0.5B**

<a id='9bd86009-48d2-4f13-bfe3-2eddf6caa47b'></a>

Details to follow

## Bottom-up

Used the existing MTA estimate for COVID-19 related expenses as a base and built in additional expense items or expense increases based upon common policies enacted by transit agencies around the world for responses to COVID-19 and SARS

$0.7-$0.8B

<a id='8230eb46-c8ee-42dc-ab85-d36a84d390b6'></a>

Expenses do not include:
* Any new capex (e.g., ventilation upgrades, thermal imaging, re-furbishing breakrooms, etc.)
* Costs related to further service changes in response to the pandemic

<a id='cd33b75a-873b-4efd-9a5a-61042b4dc6fa'></a>

29

<a id='edb8218a-b837-4844-bc21-5e0aa73b9f5e'></a>

<::transcription of the content
: plus sign icon inside a circle::>

<!-- PAGE BREAK -->

<a id='97f3a436-2d97-4b5c-9cc6-875341a2a534'></a>

Current as of 4/22

<a id='f3315c53-dea4-48c4-8b53-8c3ce7102d20'></a>

**Incremental operating expenses may increase $0.7-$0.8B in 2020**
<u>Expense assumptions for 2020 from a “bottom up” perspective</u>

<a id='436eccba-69f0-4ad6-8fee-2dd0b8914d02'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='a812a71c-2708-4bf3-a746-b5222b750ea0'></a>

Preliminary

<a id='231cfa96-6983-4065-95c3-3d64f08211b3'></a>

Descriptions of expenses considered for 2020

<a id='b481f248-b833-4df9-8189-9fce50e548f5'></a>

<table><thead><tr><th>Drivers of operating expenses</th><th>Type</th><th>Description</th><th>Examples (non exhaustive)</th></tr></thead><tbody><tr><td rowspan="3"></td><td>"Ongoing"</td><td>Activities already begun by March that are likely to continue through the year</td><td>OHS hotline and current level of temperature testing, cleaning, and PPE for employees</td></tr><tr><td>"Expansion"</td><td>Extending existing activity to larger populations or additional locations</td><td>Additional temperature testing and adding some COVID-19 tests for employees, limited expansion of police presence</td></tr><tr><td>"New"</td><td>Net new activity not yet contemplated but seen in peer systems or under active discussion as potential solutions for transit agencies</td><td>Daily cleaning of buses and subway and commuter rail cars</td></tr></tbody></table>

<a id='64b1e0dd-fc94-4156-b895-6be4254ab80d'></a>

<::Text: Incremental expenses. Icon: A piggy bank with a coin being dropped into the slot.: figure::>

<a id='c367d14a-e169-4cf5-b2a1-107c94e74ff4'></a>

I
1
<table id="30-1">
<tr><td id="30-2" colspan="2">Lower range for 2020, $M</td><td id="30-3">Total</td><td id="30-4">Q1</td><td id="30-5">Q2</td><td id="30-6">Q3</td><td id="30-7">Q4</td></tr>
<tr><td id="30-8"></td><td id="30-9">Ongoing</td><td id="30-a">385</td><td id="30-b">37</td><td id="30-c">112</td><td id="30-d">117</td><td id="30-e">118</td></tr>
<tr><td id="30-f"></td><td id="30-g">Expansion</td><td id="30-h">67</td><td id="30-i">4</td><td id="30-j">21</td><td id="30-k">21</td><td id="30-l">21</td></tr>
<tr><td id="30-m"></td><td id="30-n">New</td><td id="30-o">213</td><td id="30-p">0</td><td id="30-q">63</td><td id="30-r">88</td><td id="30-s">61</td></tr>
<tr><td id="30-t"></td><td id="30-u">Total</td><td id="30-v">665</td><td id="30-w">41</td><td id="30-x">196</td><td id="30-y">227</td><td id="30-z">201</td></tr>
</table>

<a id='c1606104-9f17-4f7f-868d-f9242c906cb5'></a>

Higher range
for 2020, $
<table id="30-A">
<tr><td id="30-B">M</td><td id="30-C">Total</td><td id="30-D">Q1</td><td id="30-E">Q2</td><td id="30-F">Q3</td><td id="30-G">Q4</td></tr>
<tr><td id="30-H">Ongoing</td><td id="30-I">402</td><td id="30-J">37</td><td id="30-K">112</td><td id="30-L">120</td><td id="30-M">132</td></tr>
<tr><td id="30-N">Expansion</td><td id="30-O">78</td><td id="30-P">4</td><td id="30-Q">25</td><td id="30-R">25</td><td id="30-S">25</td></tr>
<tr><td id="30-T">New</td><td id="30-U">297</td><td id="30-V">0</td><td id="30-W">66</td><td id="30-X">109</td><td id="30-Y">123</td></tr>
<tr><td id="30-Z">Total</td><td id="30-10">777</td><td id="30-11">42</td><td id="30-12">203</td><td id="30-13">253</td><td id="30-14">280</td></tr>
</table>

<a id='8a2f76e2-ffe8-4022-8056-163b4c64466e'></a>

30

<!-- PAGE BREAK -->

<a id='89ddc5c6-b272-445a-97bd-6c876b1aa9bf'></a>

Contents

<a id='67813bc3-7ddc-4990-a059-cf00a6cebbcd'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='5d073c04-5e99-432d-bad2-5c30c6f2cac5'></a>

Fare and toll revenue methodology
Non-fare revenue methodology
Additional operating expense methodology
**Operating gap**
Impact of filling the gap

<a id='d2fa0327-869e-4203-96f4-cc52090cd460'></a>

31

<!-- PAGE BREAK -->

<a id='09f77cc6-c278-48e5-a2a1-3d397bc45091'></a>

Current as of 4/17

<a id='cfacdd15-19c8-44a3-8311-e39fc17b4f14'></a>

## Summary of financial impacts across revenue streams for 2020

2020 Estimates

<a id='0d1f38d1-5c1d-4a22-9cc9-fb9fe12b7735'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='481e2460-b851-46c9-9e8b-0f12a73c1873'></a>

Preliminary estimates, $ billions

<a id='322a4657-bd4b-4d10-96d2-c9e3ab97bc5e'></a>

<table id="32-1">
<tr><td id="32-2"></td><td id="32-3">Earlier containment and recovery</td><td id="32-4">Delayed containment and recovery</td></tr>
<tr><td id="32-5">Fare revenue</td><td id="32-6">(3.9)</td><td id="32-7">(4.9)</td></tr>
<tr><td id="32-8">Toll revenue</td><td id="32-9">(0.8)</td><td id="32-a">(1.0)</td></tr>
<tr><td id="32-b">Non-fare revenue¹</td><td id="32-c">(1.6)</td><td id="32-d">(1.8)</td></tr>
<tr><td id="32-e">Additional operating expenses (preliminary)</td><td id="32-f">(0.7)</td><td id="32-g">(0.8)</td></tr>
<tr><td id="32-h">Total gap</td><td id="32-i">(7.0)</td><td id="32-j">(8.5)</td></tr>
<tr><td id="32-k">CARES</td><td id="32-l">3.8</td><td id="32-m">3.8</td></tr>
<tr><td id="32-n">Additional</td><td id="32-o">(3.2)</td><td id="32-p">(4.7)</td></tr>
</table>

<a id='1a302903-3c31-42f9-9bbd-3232dd476a78'></a>

**Critical to note about these estimates**
**Non-fare revenue:**

Initial estimates are based on quantitative underlying drivers of various sources of revenue.
* Further reconciliation will be required with the State budget, e.g., MMTOA
* There are also areas where MTA may make decisions that will impact the overall totals (e.g., capital fund allocations)

<a id='102a4fb1-baf6-401b-b7c0-74cc161a51fe'></a>

**Fare and toll revenue:**
Fare and toll revenue estimates are calculated
based on anticipated epidemiological
and economic scenarios, including inputs
from historical periods and current data

<a id='c214a4f2-0135-44ec-844b-ac1fae2b99d4'></a>

1. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue losses

<a id='a54c47a1-027e-4111-a936-2f57825f2144'></a>

32

<!-- PAGE BREAK -->

<a id='8c2dd9e1-04bc-41bf-996a-c5705cb53661'></a>

Current as of 4/24

<a id='1117f4fb-09c9-43cf-9479-dda22abbb841'></a>

Preliminary summary of initial revenue estimates for out years
2020 and 2021 estimates

<a id='81702243-d582-479c-b120-29821cc113da'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='1527b8e5-5d80-4650-b20b-6733db323f98'></a>

Preliminary estimates of deltas to budget, $ billions
<table id="33-1">
<tr><td id="33-2"></td><td id="33-3" colspan="2">2020</td><td id="33-4" colspan="2">2021</td></tr>
<tr><td id="33-5"></td><td id="33-6">Earlier containment and recovery</td><td id="33-7">Delayed containment and recovery</td><td id="33-8">Earlier containment and recovery</td><td id="33-9">Delayed containment and recovery</td></tr>
<tr><td id="33-a">Fare revenue</td><td id="33-b">(3.9)</td><td id="33-c">(4.9)</td><td id="33-d">(2.2)</td><td id="33-e">(4.1)</td></tr>
<tr><td id="33-f">Toll revenue</td><td id="33-g">(0.8)</td><td id="33-h">(1.0)</td><td id="33-i">(0.5)</td><td id="33-j">(1.0)</td></tr>
<tr><td id="33-k">Non-Fare revenue</td><td id="33-l">(1.6)</td><td id="33-m">(1.8)</td><td id="33-n">(1.8)</td><td id="33-o">(2.0)</td></tr>
<tr><td id="33-p">Operating expenses (preliminary)</td><td id="33-q">(0.7)</td><td id="33-r">(0.8)</td><td id="33-s">(0.7)²</td><td id="33-t">(0.8)²</td></tr>
<tr><td id="33-u">Total revenue gap³</td><td id="33-v">(7.0)</td><td id="33-w">(8.5)</td><td id="33-x">(5.1)</td><td id="33-y">(7.8)</td></tr>
<tr><td id="33-z">Size of range</td><td id="33-A"></td><td id="33-B">1.5</td><td id="33-C"></td><td id="33-D">2.7</td></tr>
</table>

<a id='a6aa39b1-52b2-4411-bdc1-83b12f523e46'></a>

1. Non-fare revenue loss does not include the impact of reduced transfers from toll revenue; these are accounted for in the toll revenue loss
2. Operational expenses may vary in 2021 depending on MTA's decisions on how to respond to the crisis
3. Totals may not add due to rounding

<a id='14255eab-1b27-40f3-98ac-cec099e74d75'></a>

33

<!-- PAGE BREAK -->

<a id='35938486-607d-4a67-9192-44ccdf37775a'></a>

## Contents

<a id='c88f0698-5693-4e4c-83b6-5f65e59db7a0'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.
---


<a id='25c8c8ac-bb4b-4a73-b927-abd4f66db017'></a>

Fare and toll revenue methodology
Non-fare revenue methodology
Additional operating expense methodology
Operating gap
**Impact of filling the gap**

<a id='1947ed26-fa61-4d28-8350-1c28d6f89ee4'></a>

34

<!-- PAGE BREAK -->

<a id='786ecc15-2014-4ad7-9817-19d36a2528cf'></a>

Current as of 4/17

<a id='35b284fa-bef1-452b-932e-075f9dcb0e12'></a>

## Estimating potential economic impacts
Possible effects of spending

<a id='37308faa-a929-40af-9174-73208511b798'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='de5d0e9b-7497-4284-8962-467e501f4304'></a>

1 The NYC metro area is an engine of the overall national economy

## Rationale
NYC metro's GDP of $1.7 trillion in 2017 is the largest of any metro area in the U.S.
In recent years, NYC Metropolitan Statistical Area (MSA) has contributed the greatest share of U.S. and global nominal GDP growth of all metro areas. NYC metro has generated 8.3% of all U.S. nominal GDP growth and 2.6% of all global nominal GDP growth between 2010 and 2017

<a id='3dfdcb0a-0936-4af1-b63b-3a32ac294fa5'></a>

2 NY MTA is a critical part of what makes the NYC MSA economy possible

The MTA carries 8M people every day, allowing a large portion of the NYC MSA to get to work
* 87% of people who enter the Manhattan Central Business District during the peak do so through bus, subway, or railroad
* Every day Manhattan goes from a population of 1.6M residents to a daytime population of nearly 4M people, including nearly 1.6M commuters and 400K day-trippers
* If 1.6M commuters drove in their own automobiles, the parking alone would occupy 520M SF of space, this would require paving over 80% of Manhattan for a parking lot; or replacing Central Park with a 13 story parking garage

<a id='a7f086a1-a7bd-4019-ada1-717a7d627722'></a>

3 NY MTA represents the bulk of losses in transit ridership and fares in the US

Across the US, major transit systems - CTA, LA Metro, MBTA, WMATA, SEPTA, NJ Transit, and others - have all lost 80-90% of ridership in transit in recent weeks
MTA represents 40-50% of the total loss in ridership in the United States

<a id='8d7c04fa-4144-4b07-a2d6-c85093c0c2e1'></a>

4
Spending on the MTA has the potential to drive national economic impact

Preliminary analysis of impact shows a $3.2-4.7B investment has a $6.2-9.1B total national GDP impact and generates 75-109K jobs

<a id='e74dcba5-f2d5-439a-98be-bea55169c07d'></a>

Source: Press search, FTA NTD data, NYMTC data, BEA multiplier analysis

<a id='9d1008d0-9a45-4f05-ac0e-7362df11b5fc'></a>

35

<!-- PAGE BREAK -->

<a id='49c30727-c96c-4407-8bd6-1092d9f2a502'></a>

3 **MTA carries the most riders with majority of fare revenue**
Compared with the Top 12 US transit agencies

---

<a id='d2ab91f2-aab9-4abb-ab2e-f7deddae59bd'></a>

Ridership share among the top 12 US transit agencies¹, Percent<::chart: Donut chart showing ridership proportion among the top 12 US transit agencies.
- MTA: 57%
- CTA: 7%
- LA Metro: 6%
- WMATA: 6%
- MBTA: 5%
- SEPTA: 5%
- NJ Transit: 4%
- SF Muni: 3%
- King County Metro: 2%
- BART: 2%
- MARTA: 2%
- Denver RTD: 2%
Annotation: Assuming decline system proportion the portion incurred.
::>1. Based on 2019 monthly ridership data
2. Based on 2018 fare revenue data (2017 for MTA MNR)

<a id='ac450db2-79bd-44f9-a3b8-b7cdf70039d4'></a>

Source: National Transit Database (NTD)

<a id='55253838-927f-459d-a29b-b378d4556273'></a>

(4/28/20) Please see disclaimer on page 3. These analyses represent only potential scenarios based on discrete data from one point in time. They are not intended as a prediction or forecast, and the situation is changing daily.

<a id='f9d6cad4-8ccc-4ac5-9446-8e6b0eb642df'></a>

Fare revenue share among the top 12 US transit agencies², Percent <::A donut chart titled "Fare revenue proportion" displays the fare revenue share among the top 12 US transit agencies. The segments are: MTA 56%, NJ Transit 9%, WMATA 6%, MBTA 6%, CTA 5%, BART 4%, SEPTA 4%, LA Metro 3%, King County Metro 2%, SF Muni 2%, Denver RTD 1%, and MARTA 1%. A speech bubble associated with the chart contains the text: "percentage hip across re revenue Iso represent fare losses ystem during s".: chart::>

<a id='2fa56db3-0276-49f9-a69d-42973da5f3bb'></a>

36

<a id='1203ae33-f92c-45d0-a327-a951643ac78a'></a>

ng similar
s in riders
s, these fa
hs would a
on of total
by each sy
the crisi

<!-- PAGE BREAK -->

<a id='e681fd3c-3213-46e3-838f-3b0a8ed83350'></a>

4. Replacing lost operating funds may create up to $9.1B in GDP impact and 109K jobs

<a id='82cb521a-ee69-4abb-9542-ca529085d02e'></a>

<table id="37-1">
<tr><td id="37-2"></td><td id="37-3">Impacts</td><td id="37-4">Net impact</td><td id="37-5">US direct impact</td><td id="37-6">Total value add with Induced</td></tr>
<tr><td id="37-7" rowspan="2">Earlier containment and recovery</td><td id="37-8">GDP</td><td id="37-9">$3.18B</td><td id="37-a">$1.93B1</td><td id="37-b">$6.17B3</td></tr>
<tr><td id="37-c">Jobs</td><td id="37-d">$3.18B</td><td id="37-e">31,6312</td><td id="37-f">74,6483</td></tr>
<tr><td id="37-g" rowspan="2">Delayed containment and recovery</td><td id="37-h">GDP</td><td id="37-i">$4.66B</td><td id="37-j">$2.83B1</td><td id="37-k">$9.05B3</td></tr>
<tr><td id="37-l">Jobs</td><td id="37-m">$4.66B</td><td id="37-n">46,3522</td><td id="37-o">109,3903</td></tr>
</table>

<a id='4b4c1f39-3c62-4b8c-ae1b-825fa33e4e5f'></a>

1. Conversion to GDP (Value Added) using Valued Added to Sales multiplier for Mixed Mode Transit Systems NAICS code
2. Conversion to Jobs using Job to Sales multiplier for Mixed Mode Transit Systems NAICS code
3. Uses BEA multipliers to translate direct effect into total impact (including indirect and induced)

<a id='20347dab-2bc8-45fe-8b38-64d62952c22e'></a>

Source: Bureau of Economic Analysis

<a id='1b2357f4-cb2a-461b-a262-4307ef943a18'></a>

(4/28/20) Please see disclaimer on page 3.
These analyses represent only potential
scenarios based on discrete data from one
point in time. They are not intended as a
prediction or forecast, and the situation is
changing daily.

<a id='df60ddfe-0c30-41a4-b75c-498874b81c67'></a>

Replacing $3.2 to $4.6B in
operating funds may translate into
a direct value-add (GDP) impact
of between $1.9 and $2.8B
and between 32 and 46K jobs

<a id='1a792913-f472-4c61-b6b2-39b96224a83b'></a>

**Using BEA multipliers, this GDP**
**impact could increase to**
**between $6.2 - $9.1B nationally,**
**and 75 and 109K jobs, when all**
**indirect and induced impacts**
**are accounted for**

<a id='e3fc441b-0978-4bc8-b7f4-5ae5c7845939'></a>

37