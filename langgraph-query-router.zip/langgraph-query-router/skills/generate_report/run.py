#!/usr/bin/env python3
"""Report generation skill. TODO: Replace stub."""
import json, sys

def main():
    payload = json.load(sys.stdin)
    fmt = payload.get("parameters", {}).get("format", "pdf")
    json.dump({"file_path": f"/tmp/reports/report.{fmt}", "title": "Report", "pages": 1, "note": "Stub"}, sys.stdout)

if __name__ == "__main__":
    main()
