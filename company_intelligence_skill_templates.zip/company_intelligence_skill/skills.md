---
name: company_intelligence_lookup
description: Retrieve company intelligence by routing requests across Capital IQ, public web search, and optional internal APIs, then normalize the response into a common schema.
---

# Company Intelligence Retrieval Skill

## Purpose
This skill provides a single entry point for company intelligence retrieval. It analyzes the request, selects the most appropriate retrieval path, invokes the corresponding script, and returns a normalized result.

This skill is designed for enterprise research assistants that need to support:
- structured company fundamentals
- public company and market information
- optional proprietary internal data

## Retrieval Paths
The skill can invoke one of the following retrieval scripts.

### 1. Capital IQ Retrieval
Script: `capitaliq_retrieval.py`

Use this path for structured financial and company data such as:
- revenue
- EBITDA
- valuation
- market capitalization
- ownership
- investors
- comparable companies
- M&A activity
- industry classification

### 2. Web Search Retrieval
Script: `web_search_retrieval.py`

Use this path for public information such as:
- recent news
- company descriptions
- products and services
- executive changes
- partnerships
- official websites
- recent announcements

### 3. Internal API Retrieval
Script: `internal_api_retrieval.py`

Use this path for proprietary information such as:
- internal profiles
- internal research
- internal CRM or deal records
- enterprise knowledge sources

## Entry Point
Main entry script: `main.py`

`main.py` is responsible for:
1. receiving the request
2. calling `router.py`
3. invoking the selected retrieval script
4. formatting the result into a common schema
5. returning the final response

## Routing Rules
Routing is determined by the request content unless the caller explicitly provides a source override.

### Route to Capital IQ first when the query is about:
- revenue
- EBITDA
- earnings
- market cap
- valuation
- ownership
- investors
- comparable companies
- M&A
- fundamentals
- industry classification

### Route to Web Search first when the query is about:
- latest news
- announcements
- products
- partnerships
- management changes
- public company overview
- recent developments

### Route to Internal API first when the query is about:
- internal data
- proprietary records
- internal research
- internal coverage
- internal company notes

## Fallback Logic
If the primary retrieval path returns insufficient data:
1. attempt a secondary path if enabled
2. merge the results when useful
3. preserve source attribution in the final output

Recommended fallback order:
- Capital IQ -> Web Search
- Internal API -> Capital IQ -> Web Search
- Web Search -> Capital IQ only if the query shifts toward fundamentals

## Input
The skill accepts a JSON payload like this:

```json
{
  "query": "latest revenue and ownership of Datadog",
  "company_name": "Datadog",
  "source": "auto",
  "allow_fallback": true
}
```

### Input Fields
- `query`: natural language request
- `company_name`: optional explicit company name
- `source`: one of `auto`, `capitaliq`, `web_search`, `internal_api`
- `allow_fallback`: whether to try another retrieval path if the first one is weak

## Output
All retrieval scripts should return the same normalized schema.

```json
{
  "company": "Datadog, Inc.",
  "source_used": "capitaliq",
  "confidence": "high",
  "data": {
    "revenue": "example value",
    "ownership": "example value"
  },
  "references": [
    {
      "source": "Capital IQ",
      "id": "optional id",
      "url": "optional url",
      "title": "optional title"
    }
  ]
}
```

## Common Output Schema
Every retrieval script should return:
- `company`
- `source_used`
- `confidence`
- `data`
- `references`
- `raw`

## File Structure
Recommended structure:

```text
company_intelligence_lookup/
├── skills.md
├── main.py
├── router.py
├── capitaliq_retrieval.py
├── web_search_retrieval.py
├── internal_api_retrieval.py
└── result_formatter.py
```

## Operational Guidelines
- Prefer Capital IQ for company fundamentals and structured financial data
- Prefer internal APIs for proprietary enterprise data
- Prefer web search for current public information
- Keep routing logic deterministic and easy to audit
- Normalize all outputs before returning them
- Do not silently mix sources without preserving attribution

## Error Handling
If no retrieval path returns useful data:
- return an empty `data` object
- set `confidence` to `low`
- include an explanatory message in the response
- preserve any error details in `raw` for debugging if appropriate

## Security and Compliance
- Internal API retrieval must respect authentication and authorization requirements
- Licensed sources such as Capital IQ must be accessed only through approved credentials
- Public web search results should be filtered for quality and reliability
