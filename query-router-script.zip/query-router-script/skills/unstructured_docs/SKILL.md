---
name: unstructured_docs
description: >
  Chatbot API for unstructured deal documents. Answers questions about
  IPO prospectuses, M&A merger agreements, BizDev proposals, Debt term
  sheets, and other deal-related filings.
trigger: >
  when user asks about document content, clauses, risk factors,
  disclosures, or terms from deal documents
category: data_source
parameters:
  - name: query
    type: string
    required: true
    description: Natural-language question for the document chatbot
---

# Unstructured Documents Skill
