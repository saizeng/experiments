<a id='a8f1b587-fcd1-4ac0-8699-e9131c1ec2c0'></a>

Helping Global Health
Partnerships to increase their
impact: Stop TB Partnership –
McKinsey collaboration

<a id='4a136302-402c-4d57-8b29-13cea1de49fe'></a>

Pre-reading for Coordinating Board presentation
Thursday, Nov 5, 2009

<a id='57ce30f8-7519-4754-a880-ff8e277b4ff5'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='7c079117-df29-4a32-b0ec-e2b11c2cbff4'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='1f16c014-961d-4e45-98e4-d1337040c38b'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 1

<!-- PAGE BREAK -->

<a id='e7c4e6a7-4460-406b-8323-3f1b66293d82'></a>

Background to this work: The performance of Global Health Partnerships (GHPs) is increasingly important and scrutinized, yet achieving high performance is proving challenging

<a id='8848636e-730a-4d6e-ba15-32a7cd3d93e7'></a>

## Increasing role of GHP performance

*   GHPs play a major role in global health
*   Performance of GHPs can have huge impact on health of world's population
*   The focus on performance is increasing, driven by
    *   Increasing donor focus on impact, effectiveness, and efficiency
    *   Increasing number of Partnerships in global health
    *   Likelihood of lower funding growth or less funding, given financial crisis

<a id='8e043f37-9eac-4a4d-b572-1f0d2526d8ac'></a>

# Challenging factors

Complex environment and nature of GHP organizations create challenges, e.g.

*   **Objective-setting**: distinguishing between change GHP hopes to bring about in the world vs. the goals it sets itself that will help bring about the change
*   **Accountability**: ensuring accountability and delivery in the context of loose Partnership structures, voluntary membership, and limited hierarchy
*   **Capabilities**: gaining the capacity and capabilities needed to continuously improve their performance

<a id='ec95c71e-3def-49f9-add6-07e3c90b3ecd'></a>

McKinsey & Company | 2

<!-- PAGE BREAK -->

<a id='4f2338f2-0c85-4f05-a430-b1847fa118a3'></a>

Project goals, approach, and end-products: The project will deliver practical insights on improving the performance of GHPs based on piloted improvement ideas

<a id='0775752b-2f69-4572-b3fa-dd63d4cda5ff'></a>

## Goals

*   Develop a joint perspective, tested and proven, on how GHPs can improve performance, by
    *   Exploring how to improve performance in a GHP, not simply to adopt existing (e.g. private sector) approaches
    *   Testing new ways of working with STB bodies that could lead to higher performance
    *   Develop a joint perspective to share with global health community

<a id='34b93f3a-a08c-4f7d-bf00-6a98ce03214c'></a>

# Approach
- Build on strengths and improvement opportunities outlined in 2008 evaluation
- Joint working, collaborative, co-creation. Not client-consultant work
- Duration: ~22 weeks: 10 weeks (diagnosis and design), 12 weeks (delivery)
- Scope: 5 Partnership bodies: GDF, MDR-TB WG, CFCS, Advocacy and CB&M teams
- External interactions with other GHPs, e.g., RBM, UNAIDS, GAVI, GF

<a id='f6c2c3d3-aa14-4094-b487-15ae090329c3'></a>

3 main end-products

* Successful performance **improvement pilots** in selected Partnership bodies, with accompanying documentation to support roll-out to other bodies
* A **co-authored project report**, suitable for publication in major journals, detailing the experience, including impact of the work and lessons for other GHPs
* A "**practitioners guide**" to support McKinsey teams conducting similar work

<a id='4c34c760-a805-49db-ad1e-5c3c14716dc8'></a>

McKinsey & Company | 3

<!-- PAGE BREAK -->

<a id='19b19f1f-d5e9-4cc3-bd11-5ee6df289203'></a>

Project approach: This project is organized in 3 distinct phases

<a id='37d79fff-ec9f-4861-9b2a-fce432caf134'></a>

Today
<table id="4-1">
<tr><td id="4-2">Diagnose August - September</td><td id="4-3">Design September - October</td><td id="4-4">Deliver November - December</td></tr>
<tr><td id="4-5">Selection of Partnership Bodies to work with</td><td id="4-6" rowspan="2">Intensive work within selected Partnership Bodies to</td><td id="4-7">Implementation and refinement</td></tr>
<tr><td id="4-8">GDF</td><td id="4-9" rowspan="3">▪ Problem-solving sessions on findings, lessons learned, and implications</td></tr>
<tr><td id="4-a">Advocacy</td><td id="4-b" rowspan="6">- Develop improvement ideas on selected performance issue - Select actions to implement in next phase - Development of implementation plans for Delivery phase</td></tr>
<tr><td id="4-c">Communication,</td></tr>
<tr><td id="4-d">Marketing and Branding – CFCS</td><td id="4-e" rowspan="3">Workshop to share achievements across Partnership Report and publication of results</td></tr>
<tr><td id="4-f">– MDR-TB Working Group</td></tr>
<tr><td id="4-g" rowspan="3">▪ Understanding of current performance ▪ Identification of areas of high performance</td></tr>
<tr><td id="4-h" rowspan="3">■ Presentation of results to Coordinating Board in March 2010</td></tr>
<tr><td id="4-i" rowspan="2">■ Information update to Coordinating Board in Nov 2009</td></tr>
<tr><td id="4-j">■ Selection of one performance issue to improve</td></tr>
</table>

<a id='9023dd4d-592f-4e06-80ee-1466e28de781'></a>

McKinsey & Company | 4

<!-- PAGE BREAK -->

<a id='14818f6b-dbcf-4c8b-850a-e11dfc5c82c6'></a>

Project deliverables for December 2009

<a id='a541544b-5f8a-463b-83a4-eb62e7852d5a'></a>

<table id="5-1">
<tr><td id="5-2">End-products</td><td id="5-3">Description</td></tr>
<tr><td id="5-4">Improvement pilots</td><td id="5-5">Each participating Partnership body conducting improvement project, focusing on one relevant area, e.g. Definition of objectives/goals Development of scorecards Improvement of processes Activation of relevant &#x27;enablers&#x27;, e.g., mindsets and capabilities Pilot progress showcase/workshop (mid-December) Development of accompanying &quot;pilot playbook&quot; (how-to guide for Partnership bodies)</td></tr>
<tr><td id="5-6">Project report</td><td id="5-7">A detailed project description, including Problem definition and why it matters Why it is and remains a problem Case account of Stop TB Partnership (what it&#x27;s doing well; what can be improved) Perspective from other GPH organizations (How &quot;typical&quot; is this?) Improvement projects launched and early findings Lessons, insights, conclusions</td></tr>
<tr><td id="5-8">Practitioners Guide</td><td id="5-9">Detailed account of work conducted to improve performance management for use by consultant teams in and beyond social sector</td></tr>
</table>

<a id='0fcdb241-ff72-4ae7-b48d-69e7ec6807b8'></a>

McKinsey & Company | 5

<!-- PAGE BREAK -->

<a id='d0e27a0e-31e1-451f-99bb-b48deb240b14'></a>

Framework: We think about performance in terms of both processes and enablers –(1) Processes

<a id='c288ea3b-e032-4d02-af1c-580385d16fd4'></a>

<::Performance management cycle diagram:

Central text: Performance management

1. Set objectives
   - Set time-bound objectives that contribute to fulfilling mission and vision
2. Establish clear metrics
   - Set metrics that directly measure agreed objectives
   - Set additional metrics that cascade down from key metric
3. Set targets
   - Set quantitative targets for the metrics
   - Translate these into operational plans and budgets
4. Track and disseminate metrics
   - Produce progress reports
   - Disseminate report to team members and stakeholders at pre-aligned intervals
5. Review performance
   - Use report to discuss progress in structured review meetings
   - Identify possible performance gaps and decide how to address them
6. Celebrate achievements and take further action
   - Celebrate successes
   - Take any required corrective actions
: flowchart::>

<a id='82913fba-0ee8-4a71-9a43-c088d3271a1e'></a>

McKinsey & Company | 6

<!-- PAGE BREAK -->

<a id='c5a9dc7f-1242-48c8-bd5e-04de8cb95316'></a>

Framework (backup): Definition of performance management terms

<a id='6462ba85-543d-4cd1-98ed-9a51ebd9b571'></a>

Vision

### Definition/description
- Articulates the aspiration or target for the future
- Describes core ideology, which may include "timeless" guiding principles and purpose

### Example
- A TB-free world

---


<a id='9f545e1e-5c8b-4dc3-98d7-9d8fab8c47d8'></a>

## Mission

*   Defines the organization's purpose and primary objectives
*   Supply low-cost, quality drugs to countries that need them

<a id='1732661d-cf3f-4a3e-8b8c-f7f59fe56941'></a>

Objective
---
- Narrow, time-bound, quantifiable goal that
  contributes to delivering the mission
- Supply low cost, quality TB drugs at
  USD 20/treatment course for X
  number of patients in 2010

<a id='bbb65781-7420-4d0b-9f59-7a531ad8e45d'></a>

Metric

- Measurable variable that indicates progress
towards objective

---

- E.g., funds raised, number of patient
treatments supplied, number of grants
and treatments approved

<a id='8e702e8d-802d-41df-86ef-0687e5030086'></a>

Target

*   The target value of the metric chosen
*   E.g., 15 million patient treatments supplied by 2010

<a id='398cf860-c083-4676-a48d-813a940cdd78'></a>

Report

* Set of metrics and current values vs. target
* Explanation of reasons for current performance and how to get to targets
* See pages 22, 23 in this document for examples

<a id='281792b4-6bfc-4127-af65-876f531a179c'></a>

Performance review

---

* A sequence of meetings conducted to
  * Review performance
  * Understand root causes of performance gaps
  * Decide how to address them
  * Agree appropriate actions

<a id='d0119bad-76fb-4134-8fda-5f01a062970d'></a>

McKinsey & Company | 7

<!-- PAGE BREAK -->

<a id='049e6497-72d0-4c85-ab26-d8ded86bf0de'></a>

Framework: We think about performance in terms of both processes and enablers –(2) Enablers

<a id='9193e561-f213-44c4-bb11-99c69c66765a'></a>

<::Diagram: This diagram illustrates a model centered around "Committed leadership". It shows three main interconnected components surrounding the central concept: Culture, Communications, and Capacity. Each component is further elaborated with text and an accompanying image. There is also an additional text box directly connected to "Committed leadership".

- **Central Element:**
  - **Committed leadership**

- **Surrounding Components:**
  - **Culture:**
    - Text: Developed shared cultural norms for performance (e.g., accountability, behaviors)
    - Image: Four cartoon figures, three men and one woman, sitting around a round table, engaged in a discussion.
  - **Communications:**
    - Text: Communicate both performance and the importance of discussing performance regularly to all stakeholders
    - Image: A cartoon woman with dark hair and glasses, wearing a light blue jacket and dark skirt, speaking into a microphone at a light brown podium.
  - **Capacity:**
    - Text: Ensure sufficient skills, infrastructure, and resources for performance
    - Image: A cartoon figure, wearing a colorful patterned shirt and dark pants, unrolling a large yellow scroll that has 

<a id='b41c3eed-212a-4dc8-8cbb-0a14c110c0c2'></a>

McKinsey & Company | 8

<!-- PAGE BREAK -->

<a id='00a3a3b0-3949-4560-961b-6a2552d63586'></a>

Challenges (1): Many Global Health Partnerships find some performance processes challenging given their complex environment and structure

*   Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities
*   Aligning divergent partner views on which objectives to pursue
*   Setting advocacy objectives that stay current and relevant in changing external circumstances
*   Finding and making visible tactical advocacy opportunities for partners to act on

<::Performance management processes flowchart:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements and take further action
: flowchart::>

*   Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB
*   Aligning organization structures with performance drivers and metrics to enable clear accountability

*   Committing to targets is sometimes difficult because
    *   (a) some targets are not entirely deliverable by partnership
    *   (b) voluntary nature of partnerships
    *   (c) consequences of not meeting targets (e.g., on future funding)

Committing to specific corrective actions, given loose and voluntary nature of partnership

Getting good performance data because of in-country data gathering limitations

Holding regular, trust-based performance conversations

<a id='9496bae3-3409-406f-8391-0099c31d4161'></a>

SOURCE: Interviews with Stop TB Partnership, Global Alliance for Vaccines and Immunization, UNAIDS McKinsey & Company | 9

<!-- PAGE BREAK -->

<a id='e638aac4-fb2a-48fc-ba0b-2e678e1077f8'></a>

Challenges (2): Many GHPs also struggle with the right enablers

<a id='4fa7a0cb-5fd0-4120-832a-5f75d47e4cf6'></a>

<::Committed leadership diagram::>Committed leadership is at the center of a larger circle divided into three sections: Culture, Capacity, and Communications.  Each section has a descriptive callout box.  
- **Callout 1 (connected to Culture):** Getting from a culture of performance measurement (e.g., extensive reporting) to performance management (including open discussion of performance outcomes)
- **Callout 2 (connected to Communications):** Ensuring that leaders regularly lead and participate in performance reviews, in spite of many other calls on their time
- **Callout 3 (connected to Capacity):** Allocating appropriate resources to performance management given limited resources for internal processes
- **Callout 4 (connected to Committed leadership, top left):** Establishing a shared understanding of accountability across the different backgrounds of partners. Ensuring partners within a loose working group arrangement are engaged and motivated to contribute
- **Callout 5 (connected to Committed leadership, bottom left):** Defining specific and ambitious goals given culture of consensus-building that tends towards more inclusive, yet abstract objectives<::

<a id='807e69ad-58ea-4229-8337-36b8bced51b3'></a>

McKinsey & Company | 10

<!-- PAGE BREAK -->

<a id='9f00e438-a8e1-4760-bf8d-3434eaae3d3b'></a>

Diagnostic phase findings (1): The Stop TB Partnership displays a number of strengths across performance processes

<a id='039cb323-587c-496e-ad1c-0d813615ca18'></a>

Examples

*   **Setting objectives** – GDF objectives are clearly defined and distinguish "the change the GDF hopes to bring about in the world" (e.g., Millennium Development Goals – 70% TB cases diagnosed, 85% cure rate) from the internal goals it sets itself that will enable this change
*   **Establishing clear metrics and setting targets** – MDR-TB Working Group defines concrete metrics (e.g., number of patients with access to MDR-TB treatment; research projects launched for evaluation of diagnostic algorithms) and sets specific targets for these metrics (e.g. for 2009, 200000 patients, 4 projects)
*   **Tracking and disseminating metrics** – Despite limited resources for performance management, GDF manages to track and report on a wide variety of metrics to meet the different demands of donors
*   **Reviewing performance** – In response to donor demands, the Advocacy Team conducts an in-depth review of performance against objectives stated in funding proposal so as to take stock of results achieved and lessons learned

<a id='cc5c07c4-60ee-4d8c-9879-9ea5bb10d494'></a>

McKinsey & Company | 11

<!-- PAGE BREAK -->

<a id='ce205426-5919-4d12-a6fa-cc50a29d768a'></a>

Diagnostic phase findings (2): The Stop TB Partnership also displays a number of strengths across the enablers of performance

<a id='a7eeb4f7-4199-4cfd-9341-a9074117aaec'></a>

# Examples

- **Committed leadership**
  - GDF leaders driving performance improvement initiatives
  - Secretariat leaders setting ambitious performance targets for teams
  - Coordinating Board members supporting focus on performance

- **Culture** – GDF has created a culture of performance with a focus on continuous improvement and quality management. The team is actively eliciting feedback on performance, e.g., through the Business Advisory Committee

- **Communication** – The Advocacy Team engages in ongoing communication across the Secretariat as well as with key partners such as the Stop TB department at WHO and the TB-HIV Working Group. Thereby, performance objectives are well known among relevant stakeholders

- **Capacity** – The Communications, Marketing and Branding Team makes efficient use of pro bono resources volunteered by partners. These resources are used to deliver some of the team's activities (e.g., production and distribution of public service announcements) as well as to assess performance against specific metrics (e.g., data received from partner on number of viewers)

<a id='42edbfb0-d6ff-4582-8cd2-5f5b7ab0e8f7'></a>

McKinsey & Company | 12

<!-- PAGE BREAK -->

<a id='5d41fc7e-4ff0-4e9d-bda1-4c085e30e609'></a>

Diagnostic phase findings (3): Brief overview of performance issues we have jointly agreed to address in Design and Deliver phases (more detail in following sections)

<a id='0407e459-5e7a-447f-bf45-6ec54d69a329'></a>

<::GDF
Advocacy
Communication, Marketing and Branding
Challenge Facility for Civil Society
MDR-TB Working Group
: flowchart::>

<a id='86b3727b-d3d7-46c1-921e-cf5c89670dbd'></a>

<table id="13-1">
<tr><td id="13-2">Central Global Health Partnership performance issue</td><td id="13-3">Specific question addressed with Partnership body</td></tr>
<tr><td id="13-4">Agreeing the right metrics for objectives that are difficult to measure</td><td id="13-5">GDF tracks 250 metrics but Not all are related to GDF Some overlap Metrics are not organized systematically/hierarchically</td></tr>
<tr><td id="13-6">Setting advocacy objectives that stay current and relevant in changing external circumstances</td><td id="13-7">Setting advocacy objectives within Stop TB Partnership that stay current and relevant in changing external circumstances</td></tr>
<tr><td id="13-8">Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB</td><td id="13-9">Determining detailed objectives for each audience group that the Communications, marketing and branding team seeks to address Define metrics for each detailed objective</td></tr>
<tr><td id="13-a">Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities</td><td id="13-b">Refine the mission based on experience and lessons learned in the first two years of the CFCS program Articulate specific objectives around the newly refined mission statement</td></tr>
<tr><td id="13-c">• Ensuring partners within a loose working group arrangement are engaged and motivated to contribute</td><td id="13-d">• Developing a simple survey-based tool to assess the level of working group engagement</td></tr>
</table>
McKinsey & Company | 13

<a id='4542464f-6a2d-4ead-b7c9-bb3d842085a8'></a>

13

<!-- PAGE BREAK -->

<a id='7b5f9ca3-8d8b-47cf-9687-56ae6b1ef573'></a>

Contents

- Project overview
- Global Drug Facility
- Advocacy
- Communication, Marketing and Branding
- Challenge Facility for Civil Society
- MDR-TB Working Group
- Next steps

McKinsey & Company | 14

<!-- PAGE BREAK -->

<a id='734a24aa-39f6-4012-ab5f-c1659b1c55e2'></a>

GDF issues and opportunities

<a id='0ef6c581-1f5c-4d83-bc74-447d52b41d2c'></a>

GHP performance issue

option ②: Agreeing the right metrics for objectives that are difficult to measure
option ②: Aligning organization structures with performance drivers and metrics to enable clear accountability
option ④: Getting good performance data because of in-country data gathering limitations
option ⑤: Holding regular, trust-based performance conversations

<::A circular diagram with three interconnected segments. One segment is filled in blue and labeled "Capacity". The other two segments are lighter in color and unlabeled.
: chart::>

GDF performance improvement opportunity

option ②: GDF tracks 250 metrics but
- Not all are related to GDF
- Some overlap
- Metrics are not organized systematically/hierarchically
option ②: Limited clarity on accountability for data collection/performance against each KPI
option ②: Difficult to assess GDF's performance against its objectives
option ④: Limited resources (personnel and time) to gather data and prepare reports for internal use
option ⑤: Limited time available for performance discussions

<::A cyclical flowchart titled "Performance management" with six steps:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements/take further action
: flowchart::>

<a id='642ccc49-d5a5-4955-83d3-e835ec2c007f'></a>

McKinsey & Company | 15

<!-- PAGE BREAK -->

<a id='bbdaf18c-b3bd-4064-9421-61a044d516cd'></a>

While most of the 250 metrics were relevant and helpful to GDF,
data collection and reporting was onerous

"All together we
report on over 200
KPIs that cover
our numerous
external reporting
requirements"

"Most individual
KPIs are relevant
and helpful"

"KPIs are specific
and measurable"

<::An image of a spreadsheet titled "GDF KPI list".

| | Source | KPI name |
| :--- | :--- | :--- |
| **208** | UNITAID MDR-TB Plan 2008-2011 | Number of treatments provided |
| **209** | UNITAID MDR-TB Plan 2008-2011 | Potential global saving on - total actual treatments |
| **210** | UNITAID MDR-TB Plan 2008-2011 | Potential global saving on - total treatments needs |
| **211** | UNITAID MDR-TB Plan 2008-2011 | Price decrease |
| **212** | UNITAID MDR-TB Plan 2008-2011 | Procurement fee ratio |
| **213** | UNITAID MDR-TB Plan 2008-2011 | Product availability - High quality 2nd line |
| **214** | UNITAID MDR-TB Plan 2008-2011 | Product availability - Prequalified 2nd line |
| **215** | UNITAID MDR-TB Plan 2008-2011 | Product dispatch performance |
| **216** | UNITAID MDR-TB Plan 2008-2011 | Product price fluctuation buffer |
| **217** | UNITAID MDR-TB Plan 2008-2011 | Product registration - High quality 2nd line |
| **218** | UNITAID MDR-TB Plan 2008-2011 | Product registration - Pre-qualified 2nd line |
| **219** | UNITAID MDR-TB Plan 2008-2011 | Product shipping performance |
| **220** | UNITAID MDR-TB Plan 2008-2011 | Stockpile large management cost |
| **221** | UNITAID MDR-TB Plan 2008-2011 | Stockpile management overhead cost |
| **222** | UNITAID MDR-TB Plan 2008-2011 | Stockpile storage cost |
| **223** | UNITAID MDR-TB Plan 2008-2011 | Total appropriate products in market |
| **224** | UNITAID MDR-TB Plan 2008-2011 | Treatment cost |
| **225** | UNITAID MDR-TB Plan 2008-2011 | Treatment need |
| **226** | UNITAID MDR-TB Progress report 2007 | Patients able to start or continue treatment for MDR-TB with drugs delivered (all orders) |
| **227** | UNITAID MDR-TB Progress report 2007 | Patients able to start or continue treatment for MDR-TB with drugs delivered (Global Fund orders) |
| **228** | UNITAID Pediatric Report 2007 | Average number of days for manufacturing |
| **229** | UNITAID Pediatric Report 2007 | Average total cost of a delivered request |
| **230** | UNITAID Pediatric Report 2007 | Spending on procurement fees as a percent of total order costs (all orders) |
| **231** | UNITAID Pediatric Report 2007 | Spending on products as a percent of total order costs (all orders) |
| **232** | UNITAID Pediatric Report 2007 | Spending on shipping, insurance and quality control as percent of total order costs (all orders) |
| **233** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Average lead time for delivery of drugs per country |
| **234** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Average percentage of time that Paediatric TB drugs used in the most common treatment regimens are not available in TRC approved countries |
| **235** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Country applications reviewed and approved by TRC |
| **236** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | GDF key products price secured in 2010‡‡ compared to baseline prices |
| **237** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | GDF secured cost per patient treatment**** in 2010 compared to baseline cost |
| **238** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | GDF secured price of each paediatric TB drug compared with lowest price available from non-GDF manufacturers/mechanisms using same quality standards |
| **239** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Increase in the number of LTAs signed with manufacturers for supply of paediatric TB treatments |
| **240** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Increase in the number of manufacturers for paediatric TB products currently listed in the GDF catalogue |
| **241** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Increase in the number of manufacturers of new paediatric TB products |
| **242** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Number of paediatric TB drugs either prequalified or with complete dossiers submitted to the WHO pre-qualification programme for the duration of the project |
| **243** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Number of pre-qualified optimal paediatric TB drug formulations available each year for the duration of the project |
| **244** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Paediatric treatments supplied to each beneficiary country reported semi-annually |
| **245** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Per cent of orders (per product) placed through pooled procurement |
| **246** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Per cent of orders placed for beneficiary countries annually within the timeline recommended by TRC |
| **247** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Per cent of paediatric patients completing treatment in a 6 month period |
| **248** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Per cent of total budget allocated to LIC, LMIC, UMIC |
| **249** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Per cent of treatments ordered by countries that match the number of treatments budgeted for in the project agreement |
| **250** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Proportion of paediatric TB cases reported out of total TB cases reported by a country |
| **251** | UNITAID Pediatric Reporting Template (2006 Q4 and 2010) | Total number of patient treatments approved by the TRC for each country include an additional 20% of each treatment to be held as buffer stock |

Spreadsheet tabs: Pivot T, KPI list, Unclassified KPI, Sheet3
:table::>

"It takes too much
time to collect the
information and to
adapt it to our
200+ KPIs"

"It is difficult to
define metrics for
some areas so we
have KPI gaps"

"Some of our KPIs
overlap so it is
unclear what we
are optimizing for"

"Since the hierar-
chy of KPIs is not
clear, it is hard to
prioritize" 

<a id='15a08134-17be-4a7d-add0-bab314b2421a'></a>

SOURCE: Interviews                                                                                                                                                                                                                                  McKinsey & Company | 16

<!-- PAGE BREAK -->

<a id='7ba8bf32-bbb7-4e00-8ce7-2365fef92935'></a>

The team followed an 8 step process to create streamlined and structured KPIs, dashboards, and review meetings <::The visual is a complex diagram illustrating an 8-step process for performance management, with a central cycle and surrounding detailed actions. The central cycle is labeled "Performance management" and consists of six steps:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements/take further action

Around this central cycle, there are eight detailed steps (a-h), each with a small illustrative image:
a. Collate all GDF metrics reported on in one database: sum: ~ 250 (Image: a spreadsheet view)
b. Agree on GDF objectives and cluster metrics/KPIs to objectives (Image: sticky notes on a board)
c. Develop detailed KPI tree for each objective (Image: a hierarchical diagram)
d. Streamline detailed trees, excluding activity-related or non-GDF-owned KPIs (Image: a modified hierarchical diagram)
e. Assign owners to, and define review frequency of each KPI (Image: a table with KPI, owner, frequency columns)
f. Develop clear cascade of KPIs from teams up to COO annual performance review (Image: a table showing a cascade of KPIs)
g. Create dashboards and review calendars for each team (Image: a dashboard and a calendar)
h. Hold workshop on conducting performance dialogues (Image: a smaller circular diagram with "Performance dialogue" in the center)
: flowchart::>

<a id='a3ac1873-35e1-41eb-9af4-31feadc15ed7'></a>

McKinsey & Company | 17

<!-- PAGE BREAK -->

<a id='c190c867-22ea-4a3e-8be4-aa67e6d809cc'></a>

7 KPIs give a clear overview of GDF's performance against its 3 main objectives

**Objective**

1. Provide uninterrupted supply of 1st and 2nd line TB drugs and diagnostics:
   * At low-cost
   * At high quality
   * Timely
   * In a demand and customer-driven way
   * To eligible countries
2. Sustainably strengthen eligible countries' national drug management and procurement capacity, and financial self-sufficiency¹
3. Ensure appropriate and efficient staffing and funding to drive the mission

**KPI**

1a. Average cost per patient treatment
1b. Number of patient treatments delivered

2a. Number of countries that move to direct procurement

3a. Organizational health and culture index
3b. Staff capacity and capability index
3c. Funds raised vs. required for GDF administrative costs
3d. Funds raised vs. required for GDF activities

<a id='89cfc292-35b0-4aff-8e35-bd264867f051'></a>

1 Financial self-sufficiency of countries may be an objective for the Partnership as a whole

<a id='4ca1d07f-da90-4bd6-8b4e-a3c35f3eee4c'></a>

McKinsey & Company | 18

<!-- PAGE BREAK -->

<a id='36a1e368-72c1-4670-b6c6-3d7601e005a9'></a>

The COO's annual dashboard is the output of each team's performance review

<a id='2626e6c4-6650-44a5-9e32-4a7bb121780a'></a>

Annual performance reviews

GDF COO
1a Number of patient treatments delivered
1b Average cost per patient treatment
2a Number of grantee countries that move to direct procurement
3a Staff capacity and capability index
3b Organizational health/culture index
3c Ratio of funds raised/required for GDF activities
3d Ratio of funds raised/required for GDF administrative costs

<table id="19-1">
<tr><td id="19-2">Capacity Building</td><td id="19-3">General Management and Support</td><td id="19-4">Portfolio Management</td><td id="19-5">Procurement</td><td id="19-6">Quality Management/ Assurance</td></tr>
<tr><td id="19-7">Annual</td><td id="19-8">Annual</td><td id="19-9">Annual</td><td id="19-a">Annual</td><td id="19-b">Annual</td></tr>
<tr><td id="19-c">2.1.1</td><td id="19-d">3.1.1</td><td id="19-e">1.3.1.1</td><td id="19-f">1.1.1</td><td id="19-g">1.2.1</td></tr>
<tr><td id="19-h">2.1.3</td><td id="19-i">3.1.2</td><td id="19-j">1.3.1.2</td><td id="19-k">1.2.3</td><td id="19-l">1.2.2</td></tr>
<tr><td id="19-m">3.2.1</td><td id="19-n">3.1.3</td><td id="19-o">2.1.2</td><td id="19-p">1.3.1.3</td><td id="19-q">1.4.1.1</td></tr>
<tr><td id="19-r">3.2.2</td><td id="19-s">3.2.2</td><td id="19-t">2.1.4</td><td id="19-u">1.3.1.4</td><td id="19-v">3.2.1</td></tr>
<tr><td id="19-w"></td><td id="19-x"></td><td id="19-y">3.2.1</td><td id="19-z">3.2.1</td><td id="19-A">3.2.2</td></tr>
<tr><td id="19-B"></td><td id="19-C"></td><td id="19-D">3.2.2</td><td id="19-E">3.2.2</td><td id="19-F"></td></tr>
<tr><td id="19-G">Blank (with arrow)</td><td id="19-H">Blank (with arrow)</td><td id="19-I">Blank (with arrow)</td><td id="19-J">Blank (with arrow)</td><td id="19-K">Blank (with arrow)</td></tr>
<tr><td id="19-L">Monthly Quarterly</td><td id="19-M">Semi-annual</td><td id="19-N">Monthly Quarterly</td><td id="19-O">Monthly Semi-annual</td><td id="19-P">Monthly Semi-annual</td></tr>
<tr><td id="19-Q">2.1.3.3  2.1.1</td><td id="19-R">3.1.1</td><td id="19-S">1.3.1.1  1.3.1.1</td><td id="19-T">1.3.1.3  1.1.1.1</td><td id="19-U">1.4.1.1  1.2.1</td></tr>
<tr><td id="19-V">3.2.1.1*  2.1.3</td><td id="19-W">3.1.2</td><td id="19-X">1.3.1.2  1.3.1.2</td><td id="19-Y">1.3.1.4  1.1.1.2</td><td id="19-Z">1.4.3  1.2.1.1</td></tr>
<tr><td id="19-10">2.1.3.1</td><td id="19-11">3.1.2.1</td><td id="19-12">2.1.2  2.1.2</td><td id="19-13">3.2.1.1*  1.2.3</td><td id="19-14">3.2.1.1*  1.2.2</td></tr>
<tr><td id="19-15">2.1.3.2</td><td id="19-16">3.1.2.2</td><td id="19-17">2.1.4.2  2.1.4</td><td id="19-18">1.3.1.3</td><td id="19-19">1.4.1.1</td></tr>
<tr><td id="19-1a">2.1.3.4**</td><td id="19-1b">3.1.2.3</td><td id="19-1c">2.1.4.3  2.1.4.1</td><td id="19-1d">1.3.1.4</td><td id="19-1e">1.4.2</td></tr>
<tr><td id="19-1f">3.1.3.1</td><td id="19-1g">3.2.2</td><td id="19-1h">3.2.1.1*</td><td id="19-1i">3.1.3.1</td><td id="19-1j">1.4.3</td></tr>
<tr><td id="19-1k">3.2.2</td><td id="19-1l"></td><td id="19-1m">2.1.4.3</td><td id="19-1n">3.2.3</td><td id="19-1o">3.1.3.1</td></tr>
<tr><td id="19-1p">3.2.3</td><td id="19-1q"></td><td id="19-1r">2.1.4.4**</td><td id="19-1s"></td><td id="19-1t">3.2.3</td></tr>
</table>

Performance reviews
throughout the year

<a id='fc21d423-875b-4092-98ac-80fa721fd40b'></a>

* May be reviewed less frequently depending upon team needs
** To be reviewed semi-annually

<a id='59ba3efa-6005-4beb-9eaa-ff07b29b61c1'></a>

McKinsey & Company | 19

<!-- PAGE BREAK -->

<a id='ec6c65db-c600-4c97-ba42-7a67cf92d18c'></a>

KPI tree for GDF's first objective

<a id='b50fc78a-715d-4472-a55d-5a6a85aa9229'></a>

<::An organizational chart detailing Objectives, Categories, High-level KPIs, Detailed KPIs, Owners, and Review Frequencies. The chart is structured with a main objective branching into categories, which then branch into high-level and detailed KPIs. Review frequencies are marked with 'X' in a grid of options (M, 3M, 6M, A).: chart::>

| Objective | Category | High-level KPI | Detailed KPIs | Owner | Review frequency⁷ M | Review frequency⁷ 3M | Review frequency⁷ 6M | Review frequency⁷ A |
|---|---|---|---|---|---|---|---|---|
| Provide uninterrupted supply of 1st and 2nd line TB drugs and diagnostics<br>- At low cost<br>- At high quality<br>- On time<br>- In a demand and customer-driven way<br>- To eligible countries | 1.1 Cost | 1.1.1 Average total patient treatment or diagnostic unit cost:<br>- Prophylaxis (adult and pediatric)<br>- 1st line drugs (adult and pediatric)<br>- 2nd line drugs (adult and pediatric)<br>- Diagnostics | 1.1.1.1 Average product cost per patient/unit | Procurement | option M: [ ] | option 3M: [ ] | option 6M: [ ] | option A: [x] |
| | | | 1.1.1.2 Average additional costs per patient/unit | Procurement | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | 1.2 Product quality and selection | 1.2.1 Percentage of GDF products that meet GDF QA standards | 1.2.1.1 Percentage of suppliers that meet GDF QA standards | Quality Assurance | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | | 1.2.2 Percentage of TB products recommended in WHO/GLC guidelines that are available in GDF catalogue | | Quality Assurance | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | | 1.2.3 Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries (contracted/non-contracted)¹ | | Quality Assurance | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | 1.3 Timeliness | 1.3.1 Percentage of orders delivered within the time stated on signed agreement | 1.3.1.1 Average lead time between receipt of country grant application to delivery of agreement to country for signing | Procurement | option M: [ ] | option 3M: [ ] | option 6M: [ ] | option A: [x] |
| | | | 1.3.1.2 Average lead time between receipt of country-signed agreement and GDF placing order | Procurement and portfolio management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | | 1.3.1.3 Average length of time from GDF placing order to date of order/shipment dispatch | Portfolio Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | | 1.3.1.4 Average length of time from order/shipment dispatch date to proof of delivery to country | Portfolio Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| Overarching KPIs<br>1a Number of patient treatments provided<br>1b Average cost per treatment course | 1.4 Customer demand driven | 1.4.1 Percentage of patient treatments/diagnostics delivered vs. approved through grant/technical agreement | 1.4.1.1 Orders delivered as percent of orders placed | Procurement | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | 1.4.2 Number of country-level stock-outs in countries served by GDF | | Quality Management | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | | 1.4.3 Customer satisfaction "index" (TBD) | | Quality Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | | | Quality Management | option M: [ ] | option 3M: [ ] | option 6M: [x] | option A: [ ] |
| | | | | Quality Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |


<a id='9e7e3ea3-4a51-41dc-bcf1-a254080c31c3'></a>

1 Depends upon shortlist of suppliers received from Quality Assurance function
2 M = monthly; 3M = 3 monthly; 6M = 6 monthly; A = annually

<a id='9d1e360d-d453-41df-90a9-6cc9a23676b5'></a>

SOURCE: Annual GDF report 2008; GDF strategic plan 2006 -10, Standard Operating Procedure for surveillance and measurement (SOP - 40.00); GDF Quality
Management Manual Rev 4.1 issue March 3, 2009; Team analysis

<a id='279b2a8d-53ef-426a-97f5-9121b265bc0e'></a>

McKinsey & Company | 20

<!-- PAGE BREAK -->

<a id='1d4accb2-6111-47c4-b641-d4f03461c70d'></a>

**COO – _Annual dashboard_**

<a id='e780e2f2-b863-45ff-b293-5c84b6fb71e6'></a>

DUMMY NUMBERS

<a id='64f53a87-d085-495f-8944-2a3ef742fc21'></a>

<::1a Number of patient treatments delivered: chart::>

Objective 1

| | Target | Actual | YoY trend (2008) | YoY trend (09) | YoY trend (2010) |
|---|---|---|---|---|---|
| **1st line** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.4 | Target: 2.3, Actual: 1.9 | Target: 2.1, Actual: 2.5 |
| **2nd line** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.2 | Target: 1.9, Actual: 1.7 | Target: 2.1, Actual: 2.1 |
| **Prophylaxis** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.2 | Target: 1.9, Actual: 1.7 | Target: 2.1, Actual: 2.1 |
| **Diagnostics** | option X: [ ] | option X: [ ] | Target: 2.0, Actual: 2.3 | Target: 3.8, Actual: 3.5 | Target: 4.0, Actual: 4.1 |

Legend:
option Target: [ ]
option Actual: [ ]
<::

<a id='2eaa52de-df8d-499e-8595-cd9f6cb3689e'></a>

1b Average cost per patient treatment or diagnostic unit ($)
<::Table: Average cost per patient treatment or diagnostic unit ($)

Legend: Target (light blue square), Actual (dark blue square)

| Category | Target | Actual | YoY trend (2008) Target | YoY trend (2008) Actual | YoY trend (2009) Target | YoY trend (2009) Actual | YoY trend (2010) Target | YoY trend (2010) Actual |
|:---------|:-------|:-------|:------------------------|:------------------------|:------------------------|:------------------------|:------------------------|:------------------------|
| 1st line | X      | X      | 4.7                     | 4.1                     | 4.5                     | 4.3                     | 4.4                     | 4.3                     |
| 2nd line | X      | X      | 13.0                    | 16.0                    | 12.0                    | 12.3                    | 12.0                    | 11.5                    |
| Prophylaxis | X      | X      | 1.6                     | 1.2                     | 1.6                     | 1.4                     | 1.5                     | 1.5                     |
| Diagnostics | X      | X      | 11.5                    | 12.0                    | 11.0                    | 11.0                    | 11.0                    | 12.0                    |
: chart::>

<a id='24778e0a-67c6-4ab9-81b4-0629a729ce71'></a>

<table id="21-1">
<tr><td id="21-2"></td><td id="21-3" colspan="5">2a Number of grantee countries that moved to direct procurement this year</td></tr>
<tr><td id="21-4"></td><td id="21-5">Target</td><td id="21-6">Actual</td><td id="21-7">Countries</td><td id="21-8">Comments</td><td id="21-9"></td></tr>
<tr><td id="21-a">Objective 2</td><td id="21-b">X</td><td id="21-c">X</td><td id="21-d">bullet points</td><td id="21-e">bullet points</td><td id="21-f">... (list of asterisks)</td></tr>
</table>

<a id='95dd0774-3c5c-4f5e-bcf1-836e9ce3a7d1'></a>

Objec-
tive 3

3a Staff capacity and capability index

<::transcription of the content
: The image shows a traffic light icon with the bottom light (green) illuminated, while the top two lights (red and yellow) are unlit.::>

Comments

* ...
* ...

* ...
* ...

3c Ratio of funds raised/required for GDF activities ($M)

Funds raised Funds required Ratio

* X
* Y
* X/Y

<a id='29d4fb47-b6b9-4722-bf49-dd13ff8f6d3f'></a>

3b Organizational health/culture index

<::description: A vertical traffic light icon with the middle (yellow) light illuminated.::>

Comments

*   ...
*   ...
*   ...
*   ...

<a id='a7212594-2b40-44da-8c49-500a67ea7a9b'></a>

3d Ratio of funds raised/required for GDF administrative costs ($M)

Funds raised
* X

Funds required
* Y

Ratio
* X/Y

<a id='d952b15f-cf98-4514-87e9-aae347b0efe4'></a>

McKinsey & Company | 21

<!-- PAGE BREAK -->

<a id='0433c5d1-92d0-4d04-b5fd-f46894418747'></a>

Procurement Team – *Annual dashboard*

<a id='7c4f7f87-5bef-40e8-b7f7-13c223988dfd'></a>

DUMMY NUMBERS

<a id='e50eb687-58f3-416d-bc7c-4e70465a9213'></a>

Objec-tive 1

1.1.1: Average cost per patient treatment or diagnostic unit (USD)
<::table::>
Legend: Target (light blue square), Actual (dark blue square)

| | | Target | Actual | YoY trend (2008) | YoY trend (2009) | YoY trend (2010) |
|:---|:---|:---|:---|:---|:---|:---|
| **1st line** | Adults | ▪ X | ▪ X | Target 1.1, Actual 1.4 | Target 2.3, Actual 1.9 | Target 2.1, Actual 2.5 |
| | Pediatrics | ▪ X | ▪ X | Target 1.1, Actual 1.4 | Target 2.3, Actual 1.9 | Target 2.1, Actual 2.5 |
| **2nd line** | | ▪ X | ▪ X | Target 1.1, Actual 1.2 | Target 1.9, Actual 1.7 | Target 2.1, Actual 2.1 |
| | |
| **Prophylaxis** | Adults | ▪ X | ▪ X | Target 1.1, Actual 1.2 | Target 1.9, Actual 1.7 | Target 2.1, Actual 2.1 |
| | Pediatrics | ▪ X | ▪ X | Target 0.9, Actual 1.1 | Target 1.6, Actual 1.5 | Target 1.7, Actual 1.6 |
| **Diagnostics** | | ▪ X | ▪ X | Target 2.0, Actual 2.3 | Target 3.8, Actual 3.5 | Target 4.0, Actual 4.1 |
<::/table::>

1.2.3: Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries
<::table::>
| | | Number of products | Percentage with ≥ 2 suppliers |
|:---|:---|:---|:---|
| **1st line** | Adults | X | X% |
| | Pediatrics | X | X% |
| **2nd line** | | X | X% |
| **Prophylaxis** | Adults | X | X% |
| | Pediatrics | X | X% |
<::/table::>

1.3.1.3: Average length of time from GDF placing order to date of order/shipment dispatch (days)
<::table::>
Legend: Production (dark blue line), Average (medium blue line), Stock (light blue line)

| | Target | Actual | Deviation | Trend |
|:---|:---|:---|:---|:---|
| Average | ▪ X | ▪ X | ▪ X% | Line chart showing values between 5 and 15 from J to D. |
| Shipments from stock | ▪ X | ▪ X | ▪ X% | |
| Shipments from production | ▪ X | ▪ X | ▪ X% | |
<::/table::>

1.3.1.4: Average length of time from order/shipment dispatch date to proof of delivery to country (days)
<::table::>
| | Target | Actual | Deviation | Trend |
|:---|:---|:---|:---|:---|
| | ▪ X | ▪ X | ▪ X% | Line chart showing values between 10 and 40 from J to D. |
<::/table::>

Objec-tive 3

3.2.1: Staff satisfaction and motivation
<::visual content::>
Traffic light indicator: option red: [ ] option yellow: [x] option green: [ ]
<::/visual content::>
Comments
*   ...
*   ...
*   ...

3.2.2: Staff retention level/attrition rate
<::visual content::>
Traffic light indicator: option red: [x] option yellow: [ ] option green: [ ]
<::/visual content::>
Comments
*   ...
*   ...
*   ...

<a id='15fdfbb9-6907-4004-bc2b-7718d482545c'></a>

McKinsey & Company | 22

<!-- PAGE BREAK -->

<a id='a17806d3-c1a2-4248-9c63-aa5ab304d2e7'></a>

Procurement Team – 1.2.3 Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries

<a id='87989087-7f61-46fc-aa7a-057e9eba6c10'></a>

<::table
Legend: A blue background indicates "Does not meet target".
| | Total number of products | Percentage with ≥ 2 suppliers | Product | Number of suppliers > 4 | Number of suppliers 4 | Number of suppliers 3 | Number of suppliers 2 | Number of suppliers 1 | Number of suppliers 0 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
| 1st line | x | x | A | ✓ | | | | | |
| • Adults | | | B | | ✓ | | | | |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | ✓ | | | |
| | | | E | | | | ✓ | | |
| | | | F | ✓ | | | | | |
| | | | G | | ✓ | | | | |
| | | | H (Does not meet target) | | | | | | ✓ |
| | | | I | | | ✓ | | | |
|...|
| 1st line | x | x | A (Does not meet target) | | ✓ | | | | |
| • Paediatrics | | | B | | | ✓ | | | |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | | ✓ | | |
| | | | E | | | | | ✓ | |
|...|
| 2nd line | x | x | A (Does not meet target) | | | | | ✓ | |
| | | | B | | | | | | ✓ |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | | ✓ | | |
| | | | E (Does not meet target) | | | | | | ✓ |
::>

<a id='4d1b5ecc-6444-4bda-a7a8-d7b80c7a90f6'></a>

McKinsey & Company | 23

<!-- PAGE BREAK -->

<a id='50fe8b80-31c7-4a61-ba15-19c6fcb71a09'></a>

GDF performance review calendar



[ ] Combined meetings

<a id='b67557da-9131-4d1b-a37d-9dfe34589aa8'></a>

<::Table showing meeting schedules for 2010
: table::>
| Meetings | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec |
| :-------------------------------------- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| **Annual review meetings** | | | | | | | | | | | | |
| Coordinating Board | | | | | | | | | | | △ | △ |
| GDF COO | | | | | | | | | | | △ | △ |
| **Team meetings** | | | | | | | | | | | | |
| Annual¹ | | | | △ | | | | | | △ | | |
| Quarterly² | | | △△ | | | △ | | | △△ | | | △ |
| Monthly | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| **Cross-team meetings** | | | | | | | | | | | | |
| Procurement effectiveness | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| Product quality, selection, and supply | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| TA/M+E customer satisfaction | | | △△ | | | △ | | | △△ | | | △ |
| TA/M+E effectiveness | | △ | | | △△ | | | △ | | | △△ | |
| Recommendation implementation | △ | | | △△ | | | △ | | | △△ | | |
<::/Table showing meeting schedules for 2010
: table::>

<a id='1030c436-0ca6-4831-b1df-78ebcc2352a9'></a>

1. Quarterly and monthly KPIs can be discussed as necessary
2. Monthly KPIs can be discussed as necessary

McKinsey & Company | 24

<!-- PAGE BREAK -->

<a id='4882293b-5f59-4c95-bbd7-0b824b257bb4'></a>

Next steps to implement and capture benefits

<a id='d92402f1-46ef-4d02-b699-e575286c684d'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3">Description</td></tr>
<tr><td id="25-4">Share KPI trees with donors</td><td id="25-5">Present GDF KPI tree to donors and compare with KPIs/metrics requested by donors Discuss with donors if streamlined GDF KPIs meet their reporting requirements</td></tr>
<tr><td id="25-6"></td><td id="25-7">Agree on any additional KPIs that need to be reported upon</td></tr>
<tr><td id="25-8">Integrate KPIs into MIS</td><td id="25-9">Establish simple mechanisms within GDF&#x27;s existing MIS system to input and analyze data required for KPIs</td></tr>
<tr><td id="25-a">Complete performance dialogue workshop</td><td id="25-b">Conduct 2 hour workshop with GDF team leads on facilitating constructive performance dialogues with teams</td></tr>
<tr><td id="25-c">Embed KPIs in team performance review</td><td id="25-d">Officially launch new performance management process; next steps are Assign data collection/reporting responsibilities within teams Schedule review meetings or add review to agendas of existing meetings Complete one round of performance reviews Refine KPIs and review process based on team feedback</td></tr>
</table>

<a id='541fac98-3449-43e7-aa94-dbcddfe54cce'></a>

McKinsey & Company | 25

<!-- PAGE BREAK -->

<a id='ae967454-87c9-4cc3-a391-94833b27fafa'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 26

<!-- PAGE BREAK -->

<a id='02b36361-e275-46b7-a3ee-58c76ec250cb'></a>

Advocacy Team issues and opportunities

<a id='0aba3b19-d9c2-4d9e-9678-a2fd87b3acbf'></a>

GHP performance issue
① Setting advocacy objectives that stay current and relevant in changing external circumstances

① Finding and making visible tactical advocacy opportunities for partners to act

<::Performance management: flowchart::>
1 Set objectives
2 Establish clear metrics
3 Set targets
4 Track and disseminate metrics
5 Review performance
6 Celebrate achievements and take further action
Advocacy improvement opportunities
① Setting advocacy objectives within Stop TB Partnership that stay current and relevant in changing external circumstances

① Finding and making visible tactical advocacy opportunities for Stop TB partners to act 

<a id='9df77eed-b279-4a95-9298-f83c4f624d0b'></a>

McKinsey & Company | 27

<!-- PAGE BREAK -->

<a id='b165e366-0f1b-4e30-9bf3-97fc312f39ec'></a>

3 steps ensure that emerging opportunities are incorporated in advocacy partners' plans and/or into the Framework Document

<a id='09a76155-eb37-4552-9acf-83a4e2c07bac'></a>

1

Get more information

- Make advocacy every partner's business and get them to increase their information sharing
- Extend the reach of TB advocacy beyond the Partnership

"Develop the sunflower"

2

Filter the information received

- To manage the flow of information collected, set up a process that allows the Advocacy Team¹ to filter the information for
  - Validity
  - Impact
  - Global relevance
  - Feasibility

"Filter the intelligence"

3

Create new or adjust current objectives and activity plans

I For tactical opportunities requiring immediate action

- Create new or adjusted objectives and activity plans based on new opportunities
- Define what success looks like, how to track progress

II For all opportunities not requiring immediate action

- Draft adjustments into the Framework Document
- Seek advice from AAC on changes drafted
- Share revised objectives and plans with partners

"Keep the framework relevant"

Review performance on new and adjusted objectives

<::transcription of the content
: The small visual shows "Stop TB Partnership" and text:
FRAMEWORK FOR ADVOCACY 2010
1. Problem: TB Burden (WHO 2009 Report)
- Globally, there were an estimated 9.27 million incident cases of TB (2007). Most of the cases were in Asia (55%), Africa (31%), and Europe (4%). Only 10% of incident cases were smear-positive. The TB incidence rate has remained stable or declined slowly in most regions of the world, except in Africa, where it has increased. The highest burden is in South-East Asia (3.3 million), followed by Africa (3.0 million), Western Pacific (1.8 million), and Europe (0.45 million), Americas (0.31 million), and Eastern Mediterranean (0.26 million).
- The total number of incident cases of TB is decreasing at the global level, but the rate of decline is not sufficient to reach the MDG target of halting and reversing the TB epidemic. The MDG target is to halt and begin to reverse the incidence of TB by 2015. The TB incidence rate declined at an average rate of 1.2% per year between 2000 and 2007.
- The global number of deaths from TB is estimated to be 1.3 million in 2007 (excluding HIV-positive cases).
- The proportion of cases that are HIV-positive is increasing, particularly in Africa.::>

1 Advocacy Team includes Secretariat advocacy and WHO STB department advocacy teams

<a id='a5b6c34d-7bff-40a4-9ebf-096c7a6285ab'></a>

SOURCE: Workshops                                                     McKinsey & Company | 28

<!-- PAGE BREAK -->

<a id='fa29af36-73f7-4b56-840b-ce51b6262814'></a>

1 There are 2 steps to get more relevant information, faster

<a id='d80839b3-249f-45c0-8362-f23df9198e64'></a>

Make advocacy every partner's business

Advocacy
Network
Working Groups
Ambassadors
STB Leadership
Coordinating
Board

A Present the advocacy framework to the Partnership
B Use recent framework developments to keep partners informed and excited about advocacy priorities
C Foster partner discussions on advocacy priorities/activities on Center for Resource Mobilization website
D Actively engage “Network Stars” within the Partnership

<a id='62a91463-f93e-4eb7-9e56-aeaf331e4b5d'></a>

Extend the reach of TB advocacy beyond the Partnership

<::graphic: A stylized sun or flower graphic composed of twelve yellow, leaf-like or petal-like shapes arranged in a circle.::>

E Locate, research and prioritize target Network Stars
F Create opportunities to initiate contact with the Network Stars targeted
G Nurture relationships with collaborative Network Stars, de-prioritize others

<a id='2b75855d-49bb-49e3-8a8e-b62ec8619073'></a>

1 Network Stars are defined as the most highly connected individuals within a network through whom information flows first

SOURCE: Workshops
McKinsey & Company | 29

<!-- PAGE BREAK -->

<a id='265ad704-d278-404a-9b1b-e6400394c241'></a>

2. The information received from an active and extended network needs to be filtered across 4 criteria

<a id='1139985d-e363-4ac5-a3c8-75c30a9c6587'></a>

<::logo: 
PRELIMINARY
The logo features three rectangular bars in a step-like arrangement, with the middle bar highlighted in blue against two lighter grey bars.::>

<a id='e63586f7-bbf9-41f7-bd41-2f45b94b1f12'></a>

<::flowchart::>This flowchart illustrates an information filtering process for an advocacy team.The process begins with an input box labeled "Advocacy Team receives unfiltered information".This input feeds into a large, horizontal funnel structure, which represents the filtering process.Along the funnel, there are four distinct filter stages, each with a corresponding label and description below it:1.  **Validity Filter**  The received information is checked for validity with a second source: "Is the information accurate and true?"2.  **Impact Filter**  Once validated, the information is filtered for work plan impact: Can the information affect  *   Policy?  *   Donors?  *   Public opinion?3.  **Global Filter**  The information is filtered for global relevance: "Does it have implications beyond local/national boundaries?"4.  **Feasibility Filter**  Determine whether the information can feasibly and realistically be translated into sufficiently impactful activitiesAt the bottom center, a final action box states: "Apply filter at start of advocacy meetings"<::

<a id='a8153b86-bf7c-4afb-8886-9aff30a749e8'></a>

SOURCE: Workshops                                                  McKinsey & Company | 30

<!-- PAGE BREAK -->

<a id='d893107e-1cf8-4af2-b123-b9009a5c8697'></a>

3 Framework document needs to be refined and revised based on information received <::process diagram: This diagram shows a three-step process depicted as ascending blocks, with an additional review step and a preliminary indicator. Above the steps, a small icon of three ascending bars is present, labeled "PRELIMINARY". The steps are:
1. Get more information
2. Set up process to filter the information received
3. Create new or adjust current objectives and work plans
An additional step, presented in an oval, is: Review performance on adjusted objectives.::>

<a id='5c5737c2-e7cf-4c17-9287-206f2ff0b61d'></a>

For tactical opportunities requiring immediate action
<table id="31-1">
<tr><td id="31-2">Analyze filtered intelligence and create new-or update current-objective</td><td id="31-3">Prompt for rapid input from AAC</td><td id="31-4">Share updates to all relevant stakeholders for immediate buy-in and action</td></tr>
<tr><td id="31-5">Create new objectives and plans, define success and how to measure progress For all opportunities not requ</td><td id="31-6">As time is limited, input gathering to happen over phone or same day email feedback loop ring immediate action</td><td id="31-7">Share new/adjusted objectives and plans Define success and how to measure/track progress (e.g., how many updates suggested? Pursued? Achieved?)</td></tr>
<tr><td id="31-8">Analyze filtered intelligence and create new-or update current-objective</td><td id="31-9">Share updates with and seek advice from AAC</td><td id="31-a">Input into Framework Document, share with Advocacy Network</td></tr>
<tr><td id="31-b">Secretariat Leadership and Advocacy Team jointly analyze and discuss the filtered information, drafting new or adjusted objectives</td><td id="31-c">Submit changes to AAC for input by next Advocacy Network call More substantial adjustments to be submitted to the Coordinating Board</td><td id="31-d">Share adjusted Framework with Advocacy Network and other partners In monthly Advocacy Network call In monthly email update with link to CRM website</td></tr>
</table>

<a id='5736ff50-644d-4908-98bd-2fbb5012901a'></a>

SOURCE: Workshops McKinsey & Company | 31

<!-- PAGE BREAK -->

<a id='ab4fc2de-3383-40ca-9717-214318608ff1'></a>

Next steps and expected impact

<a id='3b2c042a-cca6-4a7c-a0f0-6b870f649742'></a>

PRELIMINARY

<a id='c64922df-81c1-413c-a2da-0971527815b1'></a>

<table id="32-1">
<tr><td id="32-2"></td><td id="32-3">Description</td></tr>
<tr><td id="32-4">Engage the Partnership</td><td id="32-5">▪ Present framework document to – Coordinating Board: Nov 2009 – Advocacy Network: Dec 2009 (Cancun) – Stop TB Leadership: Nov 2009 – Core groups of the Working Groups: Nov 2009 ▪ Set up Advocacy Network calls</td></tr>
<tr><td id="32-6">Identify Network Stars, plan engagement</td><td id="32-7">▪ Map Network Stars within and beyond the Partnership ▪ Link Network Stars to objectives, prioritize outreach ▪ Plan engagement for prioritized Network Stars</td></tr>
<tr><td id="32-8">Develop CRM website section, Standard Operating Procedures</td><td id="32-9">▪ Advocacy Team to determine ideal structure and content of the CRM site section devoted to the framework ▪ Develop and disseminate Standard Operating Procedures for sharing information, updating the website (Nov 2009) ▪ Complete work on CRM website (Dec 2009)</td></tr>
</table>

<a id='0c24dd96-aab2-4077-8e31-f12aff4619c4'></a>

## Expected impact

*   Strengthen Advocacy Network ties and increase dialogue between advocacy stakeholders
*   Improve the use and increase the sharing of relevant information
*   Stay ahead of emerging threats and opportunities
*   More efficient use of Advocacy Team's limited time - no extra resources required

<a id='1e1853eb-e432-4f60-99d0-ffdfcf9fd931'></a>

McKinsey & Company | 32

<!-- PAGE BREAK -->

<a id='c00dc20b-120a-4627-b164-9dd9a7fdd158'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   **Communication, Marketing and Branding**
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 33

<!-- PAGE BREAK -->

<a id='26e74a2f-3bae-4ee3-a315-47b8129ef2bd'></a>

Communications Marketing and Branding issues and opportunities

<a id='21be1ce7-a461-4c8e-918d-ce582bedf462'></a>

GHP performance issue
① Getting from a vision to the specific
objectives for the partnership and its bodies
rather than directly to activities

② Agreeing the right metrics for objectives that
are difficult to measure, e.g., awareness
about TB

Communications, marketing, and
branding improvement opportunities
① Determining detailed objectives for each
audience group that the
Communications, marketing and
branding team seeks to address

② Define metrics for each detailed
objective

<::Performance management diagram: 
1 Set objectives
2 Establish clear metrics
3 Set targets
4 Track and disseminate metrics
5 Review performance
6 Celebrate achievements and take further action
: diagram::>

<a id='855b7908-0948-4f5f-a6a4-d93112dbbf20'></a>

McKinsey & Company | 34

<!-- PAGE BREAK -->

<a id='a512fe87-debf-4ad7-be90-29e7aac810cc'></a>

4 steps lead to clear objectives, metrics and targets, as well as to required activities to deliver

<a id='d102b899-90aa-42dd-b131-4d87b793e86a'></a>

<::structured list:>
High level objective: 2 Raise awareness about TB among members of the public in donor countries and selected high-burden countries / BRICS
  Stakeholder group/audience:
  - 2.1 High net worth individuals, DC
  - 2.2 High net worth individuals, HBC, BRICS
  - 2.3 Students / young adults, DC and HBC, BRICS
  - 2.4 All other adults, DC
  - 2.5 All other adults, HBC and BRICS
  - 2.6 Children, DC and HBC, BRICS
Callout: Identified and prioritized all audience groups per high-level objective
<::>
1
Identify audience groups
2 Raise awareness about TB among members of the public in donor
countries and selected high-burden countries

High level objective
Stakeholder
group/audience
2.1
High net worth individuals, DC
2.2
High net worth individuals,
HBC, BRICS
2.3
Students / young adults, DC
and HBC, BRICS
2.4
All other adults, DC
2.5
All other adults, HBC and
BRICS
2.6
Children, DC and HBC,
BRICS
2
Raise awareness
about TB among
members of the
public in donor
countries and
selected high-
burden countries
/ BRICS

Identified and
prioritized all
audience groups
per high-level
objective

SOURCE: Team discussion
McKinsey & Company | 5
<::structured list:>
PRELIMINARY
High level objective: 2 Raise awareness about TB among members of the public in donor countries and selected high-burden countries / BRICS
  Stakeholder group/audience:
  - 2.1 High net worth individuals, DC
    Objective per stakeholder group/audience:
    - Raise awareness about TB via traditional and innovative channels in order to increase private donations and penetrate influential networks
  - 2.2 High net worth individuals, HBC, BRICS
    Objective per stakeholder group/audience:
    - Raise awareness about TB (focusing on the target's own context) via traditional and innovative channels in order to increase private donations and penetrate influential networks
  - 2.3 Students / young adults, DC and HBC, BRICS
    Objective per stakeholder group/audience:
    - Develop and roll out a viral marketing / social media campaign
      - Stimulate commitment and action against TB from students
      - Generate student involvement for World TB Day, e.g., planning and organization of activities
  - 2.4 All other adults, DC
    Objective per stakeholder group/audience:
    - Raise awareness about the prevalence and the threat of TB via traditional and innovative channels in order to grow donor base and generate additional bottom-up pressure on governments
  - 2.5 All other adults, HBC and BRICS
    Objective per stakeholder group/audience:
    - Provide communications and marketing support in raising awareness and familiarity with TB so as to:
      - Support the increase in detection and treatment (e.g., educating about self-diagnosis, treatment steps), understanding of contagion risks
      - Foster additional pressure from civil society onto HBC governments
  - 2.6 Children, DC and HBC, BRICS
    Objective per stakeholder group/audience:
    - Raise children's awareness for and sensitivity to TB by providing playful educational materials about the threat of TB, preventative measures, and common symptoms (in local language), e.g., using the Figo animated cartoon
Callout: Defined key communications/ marketing objectives for each audience group/ stakeholder
<::>
2
Define specific objectives per audience group
2 Raise awareness about TB among members of the public in donor
countries and selected high-burden countries

High level objective
Stakeholder
group/audience
Objective per stakeholder group/audience
PRELIMINARY
M
Defined key
communications/
marketing
objectives for
each audience
group/
stakeholder
2.1
High net worth individuals, DC
• Raise awareness about TB via traditional and innovative c
to increase private donations and penetrate influential net
2.2
High net worth individuals,
HBC, BRICS
• Raise awareness about TB (focusing on the target's own
traditional and innovative channels in order to increase pri
and penetrate influential networks
2.3
Students / young adults, DC
and HBC, BRICS
• Develop and roll out a viral marketing / social media camp
— Stimulate commitment and action against TB from sti
— Generate student involvement for World TB Day, e
and organization of activities
2.4
All other adults, DC
• Raise awareness about the prevalence and the
and innovative channels in order to grow dor
additional bottom-up pressure on governm
2.5
All other adults, HBC and
BRICS
• Provide communications and marketing support in raising a
and familiarity with TB so as to:
— Support the increase in detection and treatment (e.g., educating
— self-diagnosis, treatment steps), understanding of contagion risks
— Foster additional pressure from civil society onto HBC governments
2.6
Children, DC and HBC,
BRICS
• Raise children's awareness for and sensitivity to TB by providing playful
educational materials about the threat of TB, preventative measures,
and common symptoms (in local language), e.g., using the Figo
animated cartoon
2
Raise awareness
about TB among
members of the
public in donor
countries and
selected high-
burden countries
/ BRICS

SOURCE: Team discussion
McKinsey & Company | 5

<a id='48be78eb-9413-4a38-9c12-cd69342665a8'></a>

<::figure::>
# 3 Set metrics and targets

## 1B Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRICS

PRELIMINARY

| High level objective | Stakeholder group/audience | Objective per audience group | Metrics |
| :--- | :--- | :--- | :--- |
| Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRICS<br><br>**Metrics:**<br>- Website traffic from DC/BRICS)<br>- Public rating of TB as Global Health priority (in DC/BRICS) | 1B.1 HNWI¹ and highly networked individuals, DC | Raise awareness about TB via traditional and innovative channels | - Number of individuals reached<br>- Monetary and in kind contributions² (e.g., pro bono consultancy, TV placement of public service announcements) |
| | 1B.2 HNWI and highly networked individuals, HBC, BRICS | Raise awareness about TB in individual's country via traditional and innovative channels | - Number of individuals reached<br>- Percentage of people rating TB as priority health issue |
| | 1B.3 Students / young adults, DC and HBC, BRICS | Develop and roll out a viral marketing/social media campaign | - Number of people reached |
| | 1B.4 All other adults, DC | Raise awareness about the prevalence and threat of TB using traditional and innovative communication channels and marketing products | - Percentage of people rating TB as priority health issue |
| | 1B.5 All other adults, HBC and BRICS | Provide communications and marketing support in raising awareness of and familiarity with TB (special focus on women) | - Number of World TB Day campaign partners |
| | 1B.6 Children, DC and HBC, BRICS | Raise children's awareness for and sensitivity to TB by providing playful educational materials about the threat of TB | - Number of children reached through educational projects |

> Set specific metrics and S.M.A.R.T. targets for each prioritized objective

¹ High Net Worth Individuals
² Value of in kind donations to be estimated and translated in dollar amounts

SOURCE: Team discussion

# 4 Define activity plan

## 1C Raise awareness about TB among selected institutions – Business community (1/2)

| Priority stakeholder group/audience | Objectives | Metrics | Target |
| :--- | :--- | :--- | :--- |
| Business community | - Raise awareness among business people by targeting locations and venues they regularly encounter (restaurants, hotels, conference centers, rental car agencies) | - Number of business people reached through business partners (e.g., Kempinsky, Sixt)<br>- Monetary and in kind contributions¹ (e.g., pro bono consultancy, TV placement of public service announcements) | - 5M (VC to confirm Kempinsky numbers for 2009)<br>- >50%<br>- $2,000 (VC to confirm) |
| WHO DCO | | | |
| UNAIDS | | | |

> Defined activity plans required to achieve each prioritized target

¹ Value of in kind donations to be estimated and translated into dollar amount

SOURCE: Team discussion

McKinsey & Company | 5
::>

<a id='fb1c6fc5-8601-4002-b7a2-ee0dfa5a90ff'></a>

McKinsey & Company | 35

<!-- PAGE BREAK -->

<a id='4a63f646-9f6d-41fb-97b0-99db512529c4'></a>

The high-level objectives are related to 3 areas – raising awareness about TB, engaging TB networks and supporting the Secretariat

<a id='6429f5e8-7b41-4506-b67a-4e0e8b300ebd'></a>

<::High-level objectives flowchart:
Mission
Inspire the world into action against tuberculosis (TB)

High-level objectives
1. Raise awareness about TB among
   A. The "fourth estate" (news media)
   B. Members of the public in donor countries and selected high-burden countries/BRIC+21
   C. Selected institutions
2. Engage, support and foster a shared sense of purpose among partners and other members of TB networks
3. Provide coordinated support for the core work of the Secretariat
: flowchart::>

<a id='588fa391-054c-4b7f-ae58-94e0b1ad1510'></a>

1 BRIC + 2 = Brazil, Russia, India, China, Indonesia and South Africa

<a id='0c07c85a-8f64-476e-a41b-779b01c74e20'></a>

McKinsey & Company | 36

<!-- PAGE BREAK -->

<a id='c3550cc4-33d0-4062-a8ab-3330ab956b80'></a>

For each high-level objective, audience groups, objectives, metrics, and targets have been defined (1/2)

<a id='4cc9b57b-e355-49ad-97a4-271b6b62cb79'></a>

<::High-level objective, Audience group, Objective, Metric, Target diagram:
- High-level objective:
  - 1B: Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRIC + 2
    - Audience group:
      - Students and adults in donor countries
        - Objective: Raise awareness about the prevalence and threat of TB using traditional and innovative communication channels and marketing products in order to grow donations and generate additional bottom-up pressure on social opinion
          - Metric: Total number of people reached through marketing channels
            - Target: Online viral campaign: 30 million
            - Target: TV Public Service Announcements (PSAs): 5 million
            - Target: Internet PSAs: 10 million
      - Students and adults in HBC¹
        - Objective:
          - Develop and roll out a viral marketing/social media campaign to:
            - Stimulate commitment and action against TB
            - Generate involvement in World TB Day, e.g. participation in and organization of activities
              - Metric: Number of high profile TB events targeting students and adults successfully planned and executed Total
              - Metric: Percentage of population 18-65 years old acknowledging TB as top 5 Global Health Priority
                - Target: Social networking tools/channels, e.g., YouTube, Facebook 5 million
      - Highly networked individuals in DC² and HBC
: figure::>

<a id='3162198d-f5f9-464b-a233-9a4f91b47ea1'></a>

1 HBC = High burden countries including BRIC +2
2 DC = Donor countries
<table id="37-1">
<tr><td id="37-2"></td><td id="37-3">McKinsey &amp; Company</td><td id="37-4">37</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='45104368-36e0-42df-b576-76696ec292d8'></a>

For each high-level objective, audience groups, objectives, metrics,
and targets have been defined (2/2)

<a id='764abc15-2a2e-427d-a990-50694c05e8b1'></a>

<::
High-level objective: 1A Raise awareness about TB among the "fourth estate" (news media)
- Audience group: Feature writers/ magazine editors, DC
  - Objective: Meet with editors to encourage TB coverage (focus on women's magazines)
    - Metric: Number of personal meetings with editors
      - Target: 4
- Audience group: Health/Science/Development journalists, DC
  - Objective: Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB
    - Metric: Number of editors engaged in ongoing dialogue following personal meeting
      - Target: 2
- Audience group: Editorial page editors, DC
  - Objective: Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB
    - Metric: Number of editors engaged in ongoing dialogue following personal meeting
      - Target: 2
- Audience group: Influential journalists and editors, HBC²
  - Objective: Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB
    - Metric: Number of editors engaged in ongoing dialogue following personal meeting
      - Target: 2
- Audience group: Broadcast producers, DC
  - Objective: Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB
    - Metric: Number of editors engaged in ongoing dialogue following personal meeting
      - Target: 2
- Audience group: Citizen journalists, DC
  - Objective: Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB
    - Metric: Number of editors engaged in ongoing dialogue following personal meeting
      - Target: 2
: flowchart::>

<a id='c1839d8a-80d8-4451-ab74-efd36a7178d2'></a>

McKinsey & Company | 38

<!-- PAGE BREAK -->

<a id='a8ece8b8-7558-407b-bb2a-6392b0618398'></a>

The team will finalize execution plans and align with other teams to ensure the right activities get done

<a id='622813b7-e43d-4b54-a593-53eb4b2a25ee'></a>

Execution plans and budgets

<a id='6949a09e-fc45-4fbe-82ec-8ac33dafeab6'></a>

Internal and
cross-
functional
alignment

<a id='a9fd1d79-d481-4230-b8ad-1ac59d1304cb'></a>

Performance review

<a id='2570dd6d-3528-4120-a7a8-33735522c31a'></a>

## Description

- Present updated objectives to Executive Secretary
- Complete detailed execution plans with activities required to meet objectives
- Allocate budgets/resources to activities

---

- Align with Advocacy and Partnering and Social Mobilization teams to ensure
  - Responsibilities for shared objectives are clear
  - Ownership of activities is transparent
  - Interfaces on joint projects are well managed

---

- Ensure regular (e.g., quarterly) review to assess progress against objectives

<a id='7b5b49a9-359c-4327-a8dc-45855e9243a0'></a>

# Expected impact
- Focus within team on the high-impact activities that directly aim at delivering against objectives
- Clear ownership for deliverables, within and across teams
- Ability to measure and review performance of communication, marketing and branding – functions that are typically difficult to assess

<a id='5f6bafa4-5de7-44a4-8d9c-3a05b5754884'></a>

McKinsey & Company | 39

<!-- PAGE BREAK -->

<a id='7777613f-d163-4a6a-8f29-09f186416dd8'></a>

Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 40

<!-- PAGE BREAK -->

<a id='1cdbbb95-632d-4743-921b-83fe5d0d10ed'></a>

CFCS issues and opportunities

<a id='53bf1375-88e7-4d55-9826-bb5dfaac3519'></a>

<::attestation: Official status mark
Status indicators - Preliminary
Readable Text: PRELIMINARY
Short description of visual elements and positioning: Gray text "PRELIMINARY" underlined, with a vertical line on the left, centered in the image.::>

<a id='d505bfb4-d781-4bfc-a6c3-60f8565aa90e'></a>

GHP performance issue
① Getting from a vision to the specific
objectives for the partnership and its bodies
rather than directly to activities

CFCS improvement opportunities
① Refine the mission based on experience
and lessons learned in the first two years
of the CFCS program
① Articulate specific objectives around the
newly refined mission statement

<::Performance management: flowchart::>
<::1 Set objectives::>
<::2 Establish clear metrics::>
<::3 Set targets::>
<::4 Track and disseminate metrics::>
<::5 Review performance::>
<::6 Celebrate achievements and take further action::>

<a id='b160b6ed-2deb-42ef-b972-e274a7c2695f'></a>

McKinsey & Company | 41

<!-- PAGE BREAK -->

<a id='40eb5f12-e655-4c1b-b542-9a7a72e4f243'></a>

The team conducted 4 workshops to revise the CFCS mission, objectives, selection and evaluation criteria

<a id='e1ed6e40-db62-426b-bab5-1bd63fb14c38'></a>

1. Refine current mission based on the experience accumulated since program inception, reviews and lessons from field visits
2. Define objectives based on the newly revised mission
3. Determine the proper set of application selection criteria that best help achieve CFCS objectives
4. Define grant evaluation criteria and template to allow for easy and efficient assessment of individual grant performance

<a id='931257c4-a6e8-4039-b9e0-e8afd8e87a1c'></a>

McKinsey & Company | 42

<!-- PAGE BREAK -->

<a id='5644f690-40fe-4ce6-822f-f347c184e7ce'></a>

As a first step, the team clarified the CFCS mission and defined objectives to deliver this mission

<a id='0a768411-1b1e-4d4e-90c8-2c3956a84ca7'></a>

<::flowchart
: Mission
: To provide support to community-based organizations engaged in advocacy and social mobilization activities seeking to raise awareness and empower communities to become part of the solution in the fight against TB
: Objectives
:   Assist community-based civil society organizations
:     Detail
:       Provide small grants for projects that
:       - Increase awareness and active participation of local communities
:       - Build capabilities of members of local communities
:       Provide coaching and technical assistance to grant recipients
:       Strengthen links between grant recipients and local authorities
:       Bring together different organizations and grant holders to exchange best practices in mobilizing communities and managing projects
:       Identify and stimulate the submission of high-quality/competitive applications
:   Efficiently manage CFCS resources
:     Detail
:       Develop selection criteria that
:       - Ensure the involvement of local health services and TB programs
:       - Strengthen the autonomy and responsibility of local people
:       - Demonstrate the greatest promise of project sustainability
:       Use simple project evaluation processes and criteria that:
:       - Assess project impact
:       - Extract lessons learned
:       - Integrate lessons learned in subsequent selection and evaluation
:       Hold grantees accountable to abide by project milestones
: flowchart::>

<a id='718a99ba-7435-4d32-a33f-78fdee8cc80e'></a>

McKinsey & Company | 43

<!-- PAGE BREAK -->

<a id='2c4b83d0-033c-4974-a1e5-09135fac85a0'></a>

The CFCS team can use 2 simple indicators to monitor performance against the objectives

<a id='17cec16a-3a50-49d0-b8c8-831216599a84'></a>

<table id="44-1">
<tr><td id="44-2">Objectives</td><td id="44-3">Metrics</td></tr>
<tr><td id="44-4">Assist community-based civil society organizations</td><td id="44-5">Percentage of funded projects that have impact, defined as achieving ≥X score on evaluation criteria</td></tr>
<tr><td id="44-6">Efficiently manage CFCS resources</td><td id="44-7">Percentage of funds dispersed to projects that receive ≥Y score on selection criteria</td></tr>
</table>

<a id='1d63b8df-e7b2-4a4b-ba35-a4e89f1bed70'></a>

The selection and evalua- tion criteria help to define performance standards

<a id='225d88ee-3d5c-4f95-b16a-b4d38733fa50'></a>

McKinsey & Company | 44

<!-- PAGE BREAK -->

<a id='6b7f6c6a-2451-420c-b8b4-128d109c2a59'></a>

The selection template will allow the selection committee to assess if proposals aim to deliver against CFCS objectives

<a id='f8ddd598-c1fa-495e-b906-8f3a23c65e15'></a>

0 Strongly disagree
4 Strongly agree

<a id='336bc0ae-3dff-4411-ae19-3c642bb1a1bf'></a>

<table id="45-1">
<tr><td id="45-2"></td><td id="45-3"></td><td id="45-4" colspan="5">Score</td></tr>
<tr><td id="45-5">Themes</td><td id="45-6">Detailed criteria</td><td id="45-7">0</td><td id="45-8">1</td><td id="45-9">2</td><td id="45-a">3</td><td id="45-b">4</td></tr>
<tr><td id="45-c" rowspan="4">Contribution of grants to CFCS objectives</td><td id="45-d">The proposal includes advocacy and social mobilization activities within the target community</td><td id="45-e">blank checkbox</td><td id="45-f">blank checkbox</td><td id="45-g">blank checkbox</td><td id="45-h">white rectangle with shadow</td><td id="45-i">white rectangle with shadow</td></tr>
<tr><td id="45-j">The proposal includes activities that build awareness and encourage participation of local community</td><td id="45-k">blank checkbox</td><td id="45-l">blank checkbox</td><td id="45-m">blank checkbox</td><td id="45-n">white rectangle with shadow</td><td id="45-o">white rectangle with shadow</td></tr>
<tr><td id="45-p">The proposal contains capability building/training activities that empower individuals within the target community with practical knowledge about their rights and responsibilities in TB care and control</td><td id="45-q">blank checkbox</td><td id="45-r">blank checkbox</td><td id="45-s">blank checkbox</td><td id="45-t">white rectangle with shadow</td><td id="45-u">white rectangle with shadow</td></tr>
<tr><td id="45-v">The proposal contains activities that strengthen the engagement of local health services and other relevant organizations with the local community</td><td id="45-w">two stacked rectangles (checkboxes)</td><td id="45-x">two stacked rectangles (checkboxes)</td><td id="45-y">two stacked rectangles (checkboxes)</td><td id="45-z">one gray rectangle (visual)</td><td id="45-A">one gray rectangle (visual)</td></tr>
<tr><td id="45-B" rowspan="4">Clarity of objectives and activities</td><td id="45-C">Grant objectives respond to a specific TB control challenge Objectives are S.M.A.R.T.¹</td><td id="45-D">two stacked rectangles (checkboxes)</td><td id="45-E">two stacked rectangles (checkboxes)</td><td id="45-F">two stacked rectangles (checkboxes)</td><td id="45-G">two gray rectangles (visual)</td><td id="45-H">two gray rectangles (visual)</td></tr>
<tr><td id="45-I">Activities are in logical and consistent relation to the objectives</td><td id="45-J">rectangle (checkbox)</td><td id="45-K">rectangle (checkbox)</td><td id="45-L">rectangle (checkbox)</td><td id="45-M">one gray rectangle (visual)</td><td id="45-N">one gray rectangle (visual)</td></tr>
<tr><td id="45-O">Each activity is appropriately budgeted</td><td id="45-P">rectangle (checkbox)</td><td id="45-Q">rectangle (checkbox)</td><td id="45-R">rectangle (checkbox)</td><td id="45-S">one gray rectangle (visual)</td><td id="45-T">one gray rectangle (visual)</td></tr>
<tr><td id="45-U">Administrative costs do not surpass 25% of the total budget</td><td id="45-V">rectangle (checkbox)</td><td id="45-W">rectangle (checkbox)</td><td id="45-X">rectangle (checkbox)</td><td id="45-Y">one gray rectangle (visual)</td><td id="45-Z">one gray rectangle (visual)</td></tr>
<tr><td id="45-10" rowspan="2">Clarity of expected outcomes</td><td id="45-11">The proposal includes metrics and targets</td><td id="45-12">single white square</td><td id="45-13">single white square</td><td id="45-14">single white square</td><td id="45-15">one grey rectangle</td><td id="45-16">one grey rectangle</td></tr>
<tr><td id="45-17">There is a clear plan to measure against metrics</td><td id="45-18">single white square</td><td id="45-19">single white square</td><td id="45-1a">single white square</td><td id="45-1b">one grey rectangle</td><td id="45-1c">one grey rectangle</td></tr>
<tr><td id="45-1d">Project sustainability</td><td id="45-1e">The outcomes generated by the activities in the proposal Can be sustained in a way that meets funding requirements Result from processes that have been institutionalized</td><td id="45-1f">two white squares</td><td id="45-1g">two white squares</td><td id="45-1h">two white squares</td><td id="45-1i">two grey rectangles</td><td id="45-1j">two grey rectangles</td></tr>
</table>

<a id='657dd4dd-3650-45a3-8e88-8ea22b064619'></a>

1 SMART – Specific, measurable, actionable, realistic, time-bound

<a id='338df566-bbeb-45de-949f-4bffd72500be'></a>

<table><thead><tr><th>Total score = TBD</th></tr><tr><th>(Maximum score = 52)</th></tr></thead><tbody><tr><td>McKinsey & Company</td><td>45</td></tr></tbody></table>

<!-- PAGE BREAK -->

<a id='bebc498c-96c3-4d93-924a-f440bfeae788'></a>

The evaluation criteria template assesses whether grants have performed against CFCS objectives

<a id='70ea1a4b-8476-441a-ae34-0c3047ed5429'></a>

0 Strongly disagree
4 Strongly agree

<a id='7a802568-fdf6-4d2c-b209-dd9140112705'></a>

Score

<::0 1 2 3 4
: figure::>

<a id='02da6c70-c37a-4f8a-9feb-c26fb6aa6117'></a>

<table id="46-1">
<tr><td id="46-2">Themes</td><td id="46-3">Detailed criteria</td><td id="46-4">0</td><td id="46-5">1</td><td id="46-6">2</td><td id="46-7">3</td><td id="46-8">4</td></tr>
<tr><td id="46-9" rowspan="3">Empower communities by increasing awareness/participation and by building capabilities</td><td id="46-a">Grant increased awareness within local community</td><td id="46-b">square icon</td><td id="46-c">square icon</td><td id="46-d">square icon</td><td id="46-e">white rectangle with shadow</td><td id="46-f">white rectangle with shadow</td></tr>
<tr><td id="46-g">Grant increased active participation within local community</td><td id="46-h">square icon</td><td id="46-i">square icon</td><td id="46-j">square icon</td><td id="46-k">white rectangle with shadow</td><td id="46-l">white rectangle with shadow</td></tr>
<tr><td id="46-m">Grant provided evidence of knowledge transfer to local community (e.g., examples of activities within local community that were enabled by training)</td><td id="46-n">square icon</td><td id="46-o">square icon</td><td id="46-p">square icon</td><td id="46-q">white rectangle with shadow</td><td id="46-r">white rectangle with shadow</td></tr>
</table>

<a id='de50d310-8238-45b2-801d-e0fb4f43c11c'></a>

<table id="46-s">
<tr><td id="46-t" rowspan="3">Strengthened links with local health services/ other organizations</td><td id="46-u">Grantee has developed a collaboration mechanism with local health services</td><td id="46-v">(blank square)</td><td id="46-w">(blank square)</td><td id="46-x">(blank square)</td><td id="46-y">rectangle with shadow</td></tr>
<tr><td id="46-z">Local health services endorsed activities and outcomes</td><td id="46-A">(blank square)</td><td id="46-B">(blank square)</td><td id="46-C">(blank square)</td><td id="46-D">rectangle with shadow</td></tr>
<tr><td id="46-E">Grantee proactively engaged and interacted with other local relevant organizations</td><td id="46-F">(blank square)</td><td id="46-G">(blank square)</td><td id="46-H">(blank square)</td><td id="46-I">rectangle with shadow</td></tr>
</table>

<a id='c348ff63-435e-44a8-bf8b-3b729e4246ad'></a>

<table id="46-J">
<tr><td id="46-K">Ensured activities are sustainable</td><td id="46-L">Generated outcomes are sustainable/long-lasting (e.g., required funds are in place, processes to sustain outcomes are in place)</td><td id="46-M"></td><td id="46-N"></td><td id="46-O"></td></tr>
</table>

<a id='593d79cd-f0fe-4e28-8c22-1da9b73dc258'></a>

Total score = TBD
(Maximum score = 28)

<a id='19756253-aef6-405e-8c72-3c7c79b647e7'></a>

McKinsey & Company | 46

<!-- PAGE BREAK -->

<a id='47b27253-2950-4b45-90ce-ce9a5d65d083'></a>

Implementing the selection and evaluation criteria would allow CFCS to fund the right proposals and more easily assess their impact

<a id='bbe19634-00a8-42a2-85c0-efebb0005332'></a>

<table id="47-1">
<tr><td id="47-2"></td><td id="47-3">Description</td></tr>
<tr><td id="47-4">Implementation Cross-functional alignment</td><td id="47-5">▪ Receive approval to continue CFCS from Coordinating Board ▪ Define list of activities to elicit project proposals that are aligned with objectives and selection criteria ▪ Apply selection template in review of applications for next funding round in Q1 2010 ▪ Apply evaluation templates to assess awarded grants ▪ Discuss short-listed proposals with other Partnership bodies to ensure synergies between activities at local level*</td></tr>
<tr><td id="47-6">Performance review</td><td id="47-7">• Ensure regular (e.g., semi-annual) performance review to assess progress against CFCS objectives</td></tr>
</table>

<a id='19512b1a-1d1c-4861-a86e-ed2d3b1e1034'></a>

# Expected impact

*   Increase in number
    of high potential,
    relevant applications
*   Decrease in time
    and resources
    needed to
    *   Correctly assess
        potential of an
        application
    *   Evaluate the
        implementation of
        grants
*   Synergies captured
    across CFCS and
    other Partnership
    bodies

<a id='ac62d4f1-f53f-4b5c-855b-ab3f1b6267f9'></a>

1 E.g., country X to move from GDF grant services to direct procurement; CFCS project supports activities to advocate with local government to increase TB resources

<a id='3af18c9e-f89e-4e90-8a60-6cfd221f1ed3'></a>

McKinsey & Company | 47

<!-- PAGE BREAK -->

<a id='899d45cf-8398-4187-a604-716035282de6'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 48

<!-- PAGE BREAK -->

<a id='b4cc8f2e-3700-43ad-9cb0-fd4960eb4463'></a>

MDR-TB Working Group issues and opportunities

<a id='bac57d7d-426e-467c-81f7-621bf0d0c6c6'></a>

GHP performance issue

Enablers
*   **Culture** – Ensuring partners within a loose working group arrangement are engaged and motivated to contribute
*   **Capacity** – Allocating significant resources to performance management given limited resources for internal processes

Processes

② Agreeing the right metrics for objectives that are difficult to measure
③ Committing to targets is difficult because of voluntary nature of partnerships

<::transcription of the content
: chart::>

<::transcription of the content
: flowchart::>

<a id='f9f38806-e21f-4d62-becb-465f3bd9ccb9'></a>

# MDR-TB Working Group improvement opportunities

## Enablers
* Developing a simple survey-based tool to assess the level of working group engagement
* The procedural operations of the WG (e.g., following-up on specific activities) are restricted by limited secretariat/ managerial resources

## Processes
2. Metrics set by the WG could be more explicitly tied to objectives of the WG and its members
3. Accountabilities and timelines for specific actions/outcomes are not always clear

<a id='34111b9f-7142-4d71-a292-4176f3ec6554'></a>

McKinsey & Company | 49

<!-- PAGE BREAK -->

<a id='73829428-9af4-4427-929a-cf8ad5c4d695'></a>

Questions for MDR-TB WG team barometer

<a id='52f5626d-4465-4150-9fa3-9a5ef7fbb9e8'></a>

<table id="50-1">
<tr><td id="50-2"></td><td id="50-3" colspan="2">Strongly disagree (arrow pointing left)</td><td id="50-4"></td><td id="50-5" colspan="2">Strongly agree (with arrow)</td></tr>
<tr><td id="50-6"></td><td id="50-7">1</td><td id="50-8">2</td><td id="50-9">3</td><td id="50-a">4</td><td id="50-b">5</td></tr>
<tr><td id="50-c" colspan="6">Objectives and direction</td></tr>
<tr><td id="50-d">The objectives of the WG are clear and members are fully aligned on them</td><td id="50-e">empty checkbox</td><td id="50-f">empty checkbox</td><td id="50-g">empty checkbox</td><td id="50-h">empty checkbox</td><td id="50-i">rectangle shape with shadow</td></tr>
<tr><td id="50-j">The WG&#x27;s leaders provide clear strategic direction</td><td id="50-k">empty checkbox</td><td id="50-l">empty checkbox</td><td id="50-m">empty checkbox</td><td id="50-n">empty checkbox</td><td id="50-o">two stacked rectangles with shadow</td></tr>
<tr><td id="50-p">The Chair of my subgroup provides clear direction</td><td id="50-q">checkbox (empty)</td><td id="50-r">checkbox (empty)</td><td id="50-s">checkbox (empty)</td><td id="50-t">checkbox (empty)</td><td id="50-u">simple rectangle shape</td></tr>
<tr><td id="50-v" colspan="6">Delivery against objectives</td></tr>
<tr><td id="50-w">I believe the WG is making good progress towards achieving its objectives</td><td id="50-x">checkbox (empty)</td><td id="50-y">checkbox (empty)</td><td id="50-z">checkbox (empty)</td><td id="50-A">checkbox (empty)</td><td id="50-B">simple rectangle shape</td></tr>
<tr><td id="50-C">My subgroup meaningfully contributes to the overall objectives of the WG</td><td id="50-D">checkbox (empty)</td><td id="50-E">checkbox (empty)</td><td id="50-F">checkbox (empty)</td><td id="50-G">checkbox (empty)</td><td id="50-H">simple rectangle shape</td></tr>
<tr><td id="50-I">The WG is having a meaningful impact in the fight against MDR-TB</td><td id="50-J">checkbox (empty)</td><td id="50-K">checkbox (empty)</td><td id="50-L">checkbox (empty)</td><td id="50-M">checkbox (empty)</td><td id="50-N">simple rectangle shape</td></tr>
</table>

<a id='73c64ecc-2946-4b33-b256-6fae2c3a22f4'></a>

<table id="50-O">
<tr><td id="50-P" colspan="6">Individual contributions</td></tr>
<tr><td id="50-Q">My role within my subgroup is clearly defined</td><td id="50-R">empty checkbox</td><td id="50-S">empty checkbox</td><td id="50-T">empty checkbox</td><td id="50-U">empty checkbox</td><td id="50-V">rectangular shape (with shadow)</td></tr>
<tr><td id="50-W">The individual contribution of each member of my subgroup meets my expectations</td><td id="50-X">empty checkbox</td><td id="50-Y">empty checkbox</td><td id="50-Z">empty checkbox</td><td id="50-10">empty checkbox</td><td id="50-11">rectangular shape (with shadow)</td></tr>
<tr><td id="50-12">After meetings, accountabilities and deadlines for specific actions are clear</td><td id="50-13">empty checkbox</td><td id="50-14">empty checkbox</td><td id="50-15">empty checkbox</td><td id="50-16">empty checkbox</td><td id="50-17">rectangular shape (with shadow)</td></tr>
<tr><td id="50-18">My contribution to the subgroup receives sufficient recognition</td><td id="50-19">empty checkbox</td><td id="50-1a">empty checkbox</td><td id="50-1b">empty checkbox</td><td id="50-1c">empty checkbox</td><td id="50-1d">rectangular shape (with shadow)</td></tr>
</table>

<a id='2cb3a821-0c4c-4bf7-a72e-0c28cf44a770'></a>

Mindsets and behaviors

The culture within the WG is collaborative and constructive
option : [ ]
option : [ ]
option : [ ]
option : [ ]
option : [ ]

Members are encouraged to voice their opinions, even if they are controversial
option : [ ]
option : [ ]
option : [ ]
option : [ ]
option : [ ]

<a id='dbe1f386-362c-40b7-ae86-76304ab82096'></a>

McKinsey & Company | 50

<!-- PAGE BREAK -->

<a id='6f6b7268-983c-4c5f-802a-714eb8deb1c5'></a>

The collaborative work with the MDR-TB Working Group is just beginning
– overview of suggested next steps

<a id='db96096b-98a6-4b81-903e-b3666e884e78'></a>

# Next steps

* Launch MDR-TB Working Group "team barometer" survey
* Develop metrics and targets that directly evaluate
  performance against WG objectives
* Develop further approaches to improve members'
  participation and accountability
* Assess the implications of MDR-TB scale-up on the WG
  and assess future capacity requirements
* Develop a "business case" for additional secretariat/
  managerial resources, if required

<a id='0a5aa7d3-8e9e-4c3e-9334-30a6bcf7f68a'></a>

McKinsey & Company | 51

<!-- PAGE BREAK -->

<a id='9d4f09c6-3a08-4719-b70e-1241b0c67d7b'></a>

# Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 52

<!-- PAGE BREAK -->

<a id='36804e2a-fcb8-4af3-a17e-3bbc21ad6594'></a>

Project outlook – the next ~ 10 weeks will focus on implementing the solutions developed

<a id='717504d7-922c-4021-9c80-b77ccdf3f982'></a>

<::Process flow diagram or timeline. It shows three main stages represented by horizontal colored blocks:
1.  **Diagnose** (light blue block): August - September
2.  **Design** (light blue block): September - October
3.  **Deliver** (dark blue block, shaped like an arrow pointing right): November - December

A black inverted triangle labeled "Today" points to the transition point between the "Design" and "Deliver" stages, indicating that "Today" is at the end of October or the beginning of November.
: process flow::>

<a id='534848e5-58cb-4e9f-b027-f5e10bbc0f5a'></a>

* Implementation within project teams begins
* Problem-solving sessions on findings, lessons learned, and implications are conducted
* Workshops to share achievements with other Partnership bodies are conducted
* Report is produced and findings are published
* Progress is presented to Coordinating Board in March 2010

<a id='784b9149-ad6c-44b1-b6f3-6bb7ecff720b'></a>

McKinsey & Company | 53