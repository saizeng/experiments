<a id='31076cc3-3d71-464a-a426-ea7b3848f666'></a>

Alpha Automation Pvt. Ltd. Tally
104 - The Grand Apurva, Nr. Hotel Fortune Palace, Digjam Circle, Airport Road, Jamnagar - 361008. (Gujarat) Certified Partner
Ph. 0288-2713956/57/58 M. 98250 98442 E-mail: kapil@saplautomation.com www.sapiautomation.com Sales & Solutions

<a id='b6b9da81-54e3-44cd-8515-9c1f3fd84f37'></a>

<table id="0-1">
<tr><td id="0-2"></td><td id="0-3">TAX INVOICE</td><td id="0-4" colspan="2">(ORIGINAL FOR RECIPIENT)</td></tr>
<tr><td id="0-5">Consignee (Ship To)</td><td id="0-6">Bujer (Bill To)</td><td id="0-7">Invoice No</td><td id="0-8">TI/BVN/1950</td></tr>
<tr><td id="0-9">Alpha Enterprise</td><td id="0-a">Alpha Enterprise</td><td id="0-b"></td><td id="0-c">22-Jan-21</td></tr>
<tr><td id="0-d">90. Grain Merchant</td><td id="0-e">807, Dhan Rajhi Complex</td><td id="0-f">-Way Bill No.</td><td id="0-g"></td></tr>
<tr><td id="0-h">Second Flour, Plot No. 297</td><td id="0-i">N.Nad Imperial Palace</td><td id="0-j">PO No.</td><td id="0-k">1736, BY PHONE</td></tr>
<tr><td id="0-l">Ward No. 12/8</td><td id="0-m">Dr. Yagnik Road</td><td id="0-n">PO Date</td><td id="0-o">25-Dec-20, 22-Jan-21</td></tr>
<tr><td id="0-p">Gandhidham(Kutch)-370 201</td><td id="0-q">Rajkot - 361001</td><td id="0-r">Terms Of Payment</td><td id="0-s">30 DAY</td></tr>
<tr><td id="0-t"></td><td id="0-u"></td><td id="0-v">Terms Of Delivery</td><td id="0-w">PAID</td></tr>
<tr><td id="0-x">GST No. : 24AAAG0242A</td><td id="0-y">GSTIN 24AAAG3242A</td><td id="0-z">Destination</td><td id="0-A">GANDHINAGAR</td></tr>
<tr><td id="0-B">PAN No. : AAAG3242A</td><td id="0-C">PAN No. AAAG3242A</td><td id="0-D">Dispatch Through</td><td id="0-E">AADITYA ROADWAYS</td></tr>
<tr><td id="0-F">: Gujarat</td><td id="0-G">State : Gujarat</td><td id="0-H">R No</td><td id="0-I">485</td></tr>
<tr><td id="0-J">State Code : 24</td><td id="0-K">State Code : 24</td><td id="0-L">Vehicle No</td><td id="0-M">GJ04AT7977</td></tr>
</table>

<a id='29ab45c1-98d4-44f3-8d38-8df4d8582301'></a>

<table id="0-N">
<tr><td id="0-O">Sr No</td><td id="0-P">No.of Pkgs</td><td id="0-Q">Description of Goods</td><td id="0-R">HSN</td><td id="0-S">Qty</td><td id="0-T">Rate</td><td id="0-U">Per</td><td id="0-V">Amount</td></tr>
<tr><td id="0-W">1</td><td id="0-X">10 Box</td><td id="0-Y">HR COIL -72083740 (MIX SIZE)</td><td id="0-Z">72083740</td><td id="0-10">8.640 MTS.</td><td id="0-11">1.12</td><td id="0-12">MTS</td><td id="0-13">9.68</td></tr>
<tr><td id="0-14">2</td><td id="0-15">10 Box</td><td id="0-16">HR COIL -72083740 (MIX SIZE)</td><td id="0-17">72083740</td><td id="0-18">2.420 MTS.</td><td id="0-19">62,006.00</td><td id="0-1a">MTS.</td><td id="0-1b">1,50,054.52</td></tr>
<tr><td id="0-1c">3</td><td id="0-1d">15 box</td><td id="0-1e">HR COIL -72083740 (MIX SIZE)</td><td id="0-1f">72083740</td><td id="0-1g">4.330 MTS.</td><td id="0-1h">61.006.00</td><td id="0-1i">MTS</td><td id="0-1j">2.64.155.98</td></tr>
<tr><td id="0-1k">4</td><td id="0-1l">15 Box</td><td id="0-1m">G.P. COIL/SHEET -72107000</td><td id="0-1n">72107000</td><td id="0-1o">500.000 MT</td><td id="0-1p">1,500.00</td><td id="0-1q">MT</td><td id="0-1r">7,50,000.00</td></tr>
<tr><td id="0-1s">5</td><td id="0-1t"></td><td id="0-1u">G.P. COIL/SHEET - 72107000</td><td id="0-1v">72107000</td><td id="0-1w">50.000 MT</td><td id="0-1x">100.00</td><td id="0-1y">MT</td><td id="0-1z">5,000.00</td></tr>
<tr><td id="0-1A">6</td><td id="0-1B"></td><td id="0-1C">G.P. COIL/SHEET - 72107000</td><td id="0-1D">72107000</td><td id="0-1E">10.000 MT</td><td id="0-1F">1,500.00</td><td id="0-1G">MT</td><td id="0-1H">15,000.00</td></tr>
<tr><td id="0-1I">7</td><td id="0-1J"></td><td id="0-1K">HR COIL - 2&quot; 1230 - 72083940</td><td id="0-1L">72083940</td><td id="0-1M">1.000 MTS.</td><td id="0-1N">500.00</td><td id="0-1O">MTS</td><td id="0-1P">500.00</td></tr>
<tr><td id="0-1Q">8</td><td id="0-1R"></td><td id="0-1S">HR COIL - 2&quot; - 1200 - 72083940</td><td id="0-1T">72083940</td><td id="0-1U">2.000 MTS.</td><td id="0-1V">200.00</td><td id="0-1W">MTS.</td><td id="0-1X">400.00</td></tr>
<tr><td id="0-1Y">9</td><td id="0-1Z"></td><td id="0-20">HR COIL - 2&quot; - 1200 - 72083940</td><td id="0-21">720839.40</td><td id="0-22">3.000 MTS.</td><td id="0-23">300.00</td><td id="0-24">MTS</td><td id="0-25">900.00</td></tr>
<tr><td id="0-26">10</td><td id="0-27"></td><td id="0-28">MR COIL-3*1200-72083540</td><td id="0-29">72083840</td><td id="0-2a">1.000 MTS.</td><td id="0-2b">100.00</td><td id="0-2c">MTS.</td><td id="0-2d">100.00</td></tr>
<tr><td id="0-2e">11</td><td id="0-2f"></td><td id="0-2g">HR COIL-3-1200-72083840</td><td id="0-2h">72083840</td><td id="0-2i">2.000 MTS.</td><td id="0-2j">200.00</td><td id="0-2k">MTS</td><td id="0-2l">400.00</td></tr>
<tr><td id="0-2m">12</td><td id="0-2n"></td><td id="0-2o">HR COIL-3*1200-72083840</td><td id="0-2p">72083840</td><td id="0-2q">3.000 MTS.</td><td id="0-2r">300.00</td><td id="0-2s">MTS.</td><td id="0-2t">900.00</td></tr>
<tr><td id="0-2u"></td><td id="0-2v"></td><td id="0-2w">Total</td><td id="0-2x"></td><td id="0-2y"></td><td id="0-2z"></td><td id="0-2A"></td><td id="0-2B">11.87.420.18</td></tr>
</table>

<a id='76dd6758-5d86-4174-894b-f51b6dec997e'></a>

<table id="0-2C">
<tr><td id="0-2D">IRN</td><td id="0-2E">616110011de74662adb463dcd13-</td><td id="0-2F" rowspan="10">QR code</td></tr>
<tr><td id="0-2G"></td><td id="0-2H">CD44d92d003726a61a1ba042a05-</td></tr>
<tr><td id="0-2I"></td><td id="0-2J">06016911b3a</td></tr>
<tr><td id="0-2K">Ack No.</td><td id="0-2L">16211030753589</td></tr>
<tr><td id="0-2M">Ack Date</td><td id="0-2N">22-Jan-21</td></tr>
<tr><td id="0-2O">Bank Name</td><td id="0-2P">SBI CURRENT A/C.</td></tr>
<tr><td id="0-2Q"></td><td id="0-2R">31027166874</td></tr>
<tr><td id="0-2S">A/C No.</td><td id="0-2T">31027166074</td></tr>
<tr><td id="0-2U">Branch</td><td id="0-2V">DIWANPARA BRANCH</td></tr>
<tr><td id="0-2W">IFSC</td><td id="0-2X">SBIN001842</td></tr>
</table>

<a id='37331121-6aa6-485e-8f40-dac86c1d681d'></a>

<table><thead><tr><th>Col 1</th><th>Col 2</th></tr></thead><tbody><tr><td>CGST</td><td>1,06,868.00</td></tr><tr><td>SGST</td><td>1,06,868.00</td></tr><tr><td>TCS 0.075%</td><td>810.00</td></tr><tr><td>ROUND OFF+/-</td><td>(-0.18</td></tr><tr><td>Grand Total</td><td>14,01,966.00 ₹</td></tr></tbody></table>

<a id='eab258ae-772a-4056-93fb-1fcdea37a85d'></a>

<table id="0-2Y">
<tr><td id="0-2Z" colspan="8">Amount in Wards Fourteen Lakh One Thousand Nine Hundred Sixty Six INR Only</td></tr>
<tr><td id="0-30" rowspan="2" colspan="2">HSN/SAC</td><td id="0-31" rowspan="2">Taxable Value</td><td id="0-32" colspan="2">Central Tax</td><td id="0-33" colspan="2">State Tax</td><td id="0-34" rowspan="2">Total Tax Amount</td></tr>
<tr><td id="0-35">Rate</td><td id="0-36">Amount</td><td id="0-37">Rate</td><td id="0-38">Amount</td></tr>
<tr><td id="0-39">7208 3740</td><td id="0-3a"></td><td id="0-3b">4,14,220.18</td><td id="0-3c">9%</td><td id="0-3d">37.279.88</td><td id="0-3e">9%</td><td id="0-3f">37,279.88</td><td id="0-3g">74,599.76</td></tr>
<tr><td id="0-3h">72107000</td><td id="0-3i"></td><td id="0-3j">7,70.000.00</td><td id="0-3k">9%</td><td id="0-3l">69.300.11</td><td id="0-3m">9%</td><td id="0-3n">69,300.11</td><td id="0-3o">1,38,600.22</td></tr>
<tr><td id="0-3p">7208 3940</td><td id="0-3q"></td><td id="0-3r">1,800.00</td><td id="0-3s">9%</td><td id="0-3t">162.00</td><td id="0-3u">9%</td><td id="0-3v">162.00</td><td id="0-3w">324.00</td></tr>
<tr><td id="0-3x">7208 3940</td><td id="0-3y"></td><td id="0-3z">1,400.00</td><td id="0-3A">9%</td><td id="0-3B">126.00</td><td id="0-3C">9%</td><td id="0-3D">126.01</td><td id="0-3E">252.02</td></tr>
<tr><td id="0-3F"></td><td id="0-3G">total</td><td id="0-3H">11,47,420.18</td><td id="0-3I"></td><td id="0-3J">1,06,888.00</td><td id="0-3K"></td><td id="0-3L">1,08,888.00</td><td id="0-3M">2,13,708.00</td></tr>
</table>

<a id='ff16c3c8-229a-4e1c-9430-4f911caf709e'></a>

<table id="0-3N">
<tr><td id="0-3O">Terms &amp; Condition: We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</td><td id="0-3P">For, Alpha Sales Authorised Signatory</td></tr>
</table>

<a id='403df207-603f-4e4e-adad-9d7bdd7625c4'></a>

B. O. : 807, Dhanrajni Complex, Nr. Hotel Imperial, Dr. Yagnik Road, Rajkot-360 001. (Gujarat) Ph.: 0281-2460756 / 58 Mob.: 99099 93319 / 20
B. O. : 92, G.M.A. Building, 2nd Floor, Plot No. 297, Sector 12-B, Gandhidham-370201. (Gujarat) Ph.: 99099 93318 / 90999 39018

▲ Software Development ▲ Tally Sales - Service - Customization - AMC - Training ▲ Mobile Application ▲ Cloud Solutions ▲ www.tallyndl.com