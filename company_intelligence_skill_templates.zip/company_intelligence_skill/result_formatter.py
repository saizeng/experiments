"""
Helpers for normalizing and merging retrieval results.
"""

from typing import Any, Dict, Optional


def normalize_result(
    raw_result: Dict[str, Any],
    source_used: str,
    company_name: Optional[str],
) -> Dict[str, Any]:
    data = raw_result.get("data", {})
    confidence = raw_result.get("confidence", "medium")
    references = raw_result.get("references", [])

    return {
        "company": raw_result.get("company") or company_name or "Unknown",
        "source_used": source_used,
        "confidence": confidence,
        "data": data,
        "references": references,
        "raw": raw_result,
    }


def merge_results(primary: Dict[str, Any], fallback: Dict[str, Any]) -> Dict[str, Any]:
    merged_data = dict(fallback.get("data", {}))
    merged_data.update(primary.get("data", {}))

    merged_references = list(primary.get("references", [])) + list(fallback.get("references", []))

    confidence_rank = {"low": 1, "medium": 2, "high": 3}
    primary_conf = primary.get("confidence", "low")
    fallback_conf = fallback.get("confidence", "low")
    best_confidence = primary_conf if confidence_rank.get(primary_conf, 1) >= confidence_rank.get(fallback_conf, 1) else fallback_conf

    return {
        "company": primary.get("company") or fallback.get("company") or "Unknown",
        "source_used": f"{primary.get('source_used')}+{fallback.get('source_used')}",
        "confidence": best_confidence,
        "data": merged_data,
        "references": merged_references,
        "raw": {
            "primary": primary.get("raw"),
            "fallback": fallback.get("raw"),
        },
    }
