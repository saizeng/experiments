#!/usr/bin/env python3
"""Web search skill. TODO: Replace stub with your search API call."""
import json, sys

def main():
    payload = json.load(sys.stdin)
    query = payload.get("query", "")
    json.dump({"results": [{"title": f"[STUB] {query}", "url": "https://example.com", "snippet": f"Stub for: {query}"}], "source": "web_search"}, sys.stdout)

if __name__ == "__main__":
    main()
