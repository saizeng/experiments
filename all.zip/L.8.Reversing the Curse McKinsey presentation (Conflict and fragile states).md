<a id='4aed9152-2cbb-4b16-a373-67b52232fab3'></a>

## Attracting Responsible Mining
## Investment in Fragile and Conflict
## Affected Settings

Fraser Thompson
Senior Fellow
McKinsey Global Institute (MGI)

<a id='f3ea0955-5dfd-4c4f-ab8a-b614f5ec882c'></a>

Reversing the curse presentation
February 6, 2014

<a id='1740467c-b1c6-4574-bacd-cc2f9e6d30bf'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='4d2fca1c-17b4-429e-9ab3-4110551f11b8'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='6aca922a-9fd9-4616-a45a-c2853886f4d3'></a>

This presentation draws upon material in our “Reverse the curse” report -
available for download at www.mckinsey.com/mgi

<a id='7fd92cf3-449e-4226-8719-117672e52c0d'></a>

McKinsey&Company

<a id='cad9cfe1-4763-42db-82bd-6ea16af948c1'></a>

Prepublication Version — Embargoed — for Release December 5, 2013

<a id='10f1ba27-4c86-476c-a179-d0078f04a4e8'></a>

McKinsey Global Institute
McKinsey Global Energy & Materials Practice
McKinsey Sustainability & Resource Productivity Practice
<::A collage of four images:
1. A person wearing a hard hat and safety vest operates surveying equipment in a rugged, rocky landscape.
2. An offshore oil rig is silhouetted against a vibrant orange and yellow sunset over the ocean.
3. Two workers in hard hats and blue overalls are operating industrial equipment, possibly on a drilling site or pipeline.
4. A curved railway track runs parallel to a dirt road through a green, open landscape.
: collage::>
December 2013

<a id='496f2cfa-9c1f-4a08-91af-4d66b4432d20'></a>

Reverse the curse:
Maximizing the potential of
resource-driven economies

<a id='3af75968-16fb-4989-a1ca-eef517926fe2'></a>

<::A world map, represented by a pattern of small gray dots on a white background. The map shows the continents of North America, South America, Europe, Africa, Asia, and Australia, outlined by these dots. The dots are uniformly distributed to form the landmasses.: map::>

<a id='1ae06ebf-5fc7-48c1-95c4-f6c9d33c3dce'></a>

# Central questions

1. How is the resource supply
landscape changing?
2. What are the implications for
resource-driven economies?
3. What are the implications for
extractive companies operating
in these countries?

<a id='739ea929-0f21-422b-a320-56da58a0d7ce'></a>

McKinsey & Company

<a id='1ecc18ad-5e51-448e-8ef6-5cad007c0688'></a>

1

<!-- PAGE BREAK -->

<a id='43520e37-bb1d-4061-a948-6b0e0484b18f'></a>

The number of resource-driven countries has increased by almost 40% since 1995 and most newcomers have low average incomes

<a id='7d5d2626-8bb4-46c3-9336-3e68dc7a2f0f'></a>

Number of resource-driven countries over time, by income class
<::stacked bar chart::>
**Stacked Bar Chart: Number of resource-driven countries by income class**

**1995 (Total: 58 countries)**
*   Low income: 22
*   Lower middle income: 19
*   Upper middle income: 8
*   High income: 9

**2011 (Total: 81 countries, +40% increase from 1995)**
*   Low income: 17
*   Lower middle income: 21
*   Upper middle income: 27
*   High income: 16

**Additional Data:**
| Category              | 1995 | 2011 |
|:----------------------|:-----|:-----|
| % of world GDP        | 18   | 26   |
| % of world population | 18   | 49   |
<::chart::>

<a id='8e8159be-a6db-4760-8ef4-0efd3f6dca66'></a>

Income class at time of becoming resource-driven%, 1995–2011<::Pie chart showing income class at time of becoming resource-driven, percentages from 1995–2011. The breakdown is as follows: Low: 54%, Upper middle: 25%, High: 11%, Lower middle: 11%.: chart::>

<a id='c7e0f286-f6a1-4d13-8664-d1f4f8a20027'></a>

McKinsey & Company

<a id='d7559042-ad95-495a-9d6c-2c571c38b063'></a>

2

<!-- PAGE BREAK -->

<a id='0540cb0f-5f0c-40c3-936c-5d0c5fffd5ef'></a>

Annual investment in oil and gas and minerals could need to more than double to meet new demand and replace existing supply

<a id='250ea35f-ddfe-4624-81a0-333deb8b5ce8'></a>

2012 $ billion

<a id='96784172-9ddd-4af2-ac8f-76aacd6acee2'></a>

<::chart: Annual investment requirements::>Annual investment requirements Legend: option Replacement capex: [x] option Growth capex: [ ] Minerals 2003–2012: Replacement capex 41, Growth capex 57, Total 98 2013–2030: Replacement capex 110, Growth capex 105, Total 215 Increase: +119% Oil and gas 1995–2012: Replacement capex 121, Growth capex 165, Total 286 2013–2030: Replacement capex 299, Growth capex 451, Total 749 Increase: +162% Overall: $17 trillion by 2030 (~3.8 trillion for minerals alone)<::>

<a id='1f268c8e-be85-4867-ace6-d02cb2607877'></a>

Resource investment in low and lower-middle income countries<::chart: Bar chart showing resource investment in low and lower-middle income countries.
Legend:
- Potential upside: Dotted outline box
- Base case: Solid blue box

Data:
- 1995-2012:
  - Base case: 835
- 2013-2030:
  - Base case: 1,245
  - Potential upside: 1,770
  - Total (Base case + Potential upside): 3,015

Annotation:
- An arrow points from the top of the 1995-2012 bar to the top of the 2013-2030 potential upside. Next to the arrow is a green oval with "3.6x" inside, and the text: "Resource extraction investment in lower income countries could potentially more than triple from historical levels".:chart::>

<a id='45ba6ad0-148e-4df5-818d-42c00120b63c'></a>

McKinsey & Company

<a id='9d68cfa4-3ef1-4353-a8cf-2957e0f7a5a1'></a>

3

<!-- PAGE BREAK -->

<a id='c9a8edf1-7226-4d82-bac7-316ed41562c7'></a>

However historically resource-driven countries have not performed well economically

<a id='f21e7e83-83c1-468e-b642-256748f5594e'></a>

<::Scatter plot titled "Per capita GDP, 2011" with the subtitle "Real 2005 $". The plot shows data points representing % of RDCs, as indicated by the legend (a blue circle). The x-axis is labeled "Per capita GDP compound annual growth rate, 1995–2011 %" and ranges from -4 to 19. The y-axis is labeled "Per capita GDP, 2011 Real 2005 $" and ranges from 0 to 70,000. A horizontal dashed line at approximately 10,900 on the y-axis is labeled "Average country per capita GDP: $10,900". A vertical dashed line at 2.5% on the x-axis is labeled "Average country growth: 2.5%". These lines divide the plot into four quadrants: The top-left quadrant is labeled "16% Slowing", the top-right is labeled "5% Stars", the bottom-left is labeled "40% Falling behind", and the bottom-right is labeled "37% Catching up". Multiple blue circular data points are scattered across the plot within these quadrants.: chart::>

<a id='e09710ed-d3e4-44fd-a882-eca9ffb03510'></a>

McKinsey & Company

<a id='f49ecfe8-612f-437c-825a-0805821e0bcc'></a>

4

<!-- PAGE BREAK -->

<a id='7d164b48-229e-4b92-892c-2e58900cb364'></a>

Our research suggests governments must consider six important
dimensions to transform sub-soil wealth into long-term prosperity

<a id='e3526f8f-3f55-4c19-9fa3-4fd164fd2b83'></a>

<::Objectives and Topics Diagram:Objectives:- Produce resources efficiently  Topics:  1 Institutions and governance  2 Infrastructure- Capture value from resources  Topics:  3 Fiscal policy/competitiveness  4 Local content- Transform value into long-term development  Topics:  5 Spending the windfall  6 Economic diversification: diagram::>

<a id='c0a497e1-7a04-4cfb-afe2-57f85455f2e1'></a>

McKinsey & Company

<a id='6f9a283d-a5ce-4896-b827-9a52d762385c'></a>

5

<!-- PAGE BREAK -->

<a id='125d0ca5-d186-4353-9e11-c10472a63ca0'></a>

Three factors are putting pressure on the social contract between
extractive companies and resource-driven countries

<a id='abb3012d-ca9e-4aa9-a9ea-538ad744e321'></a>

<::logo: [Unknown]RISKRed cubes stacked vertically, spelling out "RISK" in white letters::>

<a id='4b5f4f4f-9ffe-46d9-9eaf-5bf4eb79868e'></a>

1. **High and volatile resource prices.** Volatile resource prices have led to significant choppiness in resource rents and increased the likelihood that governments feel "cheated" and seek to renegotiate terms.

<a id='1094f7fc-2c98-4935-8d6e-32c3df8f3004'></a>

2. New projects are **bigger** and **more complex**. Exploration and production are increasingly moving toward deposits which are environmentally and logistically challenging and geologically complex. This is driving up project costs and increasing the risk of delays.

<a id='40a61175-0245-40cd-9b0c-b744517ce82f'></a>

3. Projects are a large share of the economies. Historically,
petroleum projects have been on a huge scale relative to their
host economies, but today some mining projects are on a
similar relative scale.

<a id='330a6b4d-6b00-4be4-b42b-68290b8b8ea5'></a>

McKinsey & Company

<a id='45c07b5c-b434-4641-9006-3ae7889ca451'></a>

6

<!-- PAGE BREAK -->

<a id='7ff69790-6585-416e-84a0-3cf1470ec1bb'></a>

Companies need to shift their approach in managing these risks – moving it from "art" to "science"

<a id='d72b0fac-790c-4a54-b832-09b5274c9555'></a>

Develop a detailed understanding of the country context
1 10 dimensions matter, which go beyond simple political risk considerations

<::Circular diagram with a central dark blue circle, surrounded by a light blue ring divided into segments, each containing an icon. Icons include: euro symbol, wrench, building, group of people, handshake, and recycle symbol.
: figure::>

<a id='acb2da15-f60b-4e21-b1fc-95befa4c0da9'></a>

**Properly understand the risk (and upside)**

2. What type of risks does under-performance create?
   Which are possible consequences and what is the magnitude/impact if risk materializes?

<a id='b2239b56-0782-424d-99c2-2bd1ded46bd0'></a>

<::A risk matrix chart with 'Risk impact' on the vertical axis (ranging from Low to High) and 'Risk likelihood' on the horizontal axis (ranging from Low to High). The chart is divided into four quadrants. The top-left quadrant contains the letters B and K. The bottom-left quadrant contains A, E, and J. The top-right quadrant is shaded blue and contains C and G. The bottom-right quadrant contains D, F, L, I, and H. A legend in the top-right corner indicates that the blue shaded area represents 'Focus of risk avoidance'.
: figure::>

<a id='e4e7fe1b-b83e-4656-a70e-06c1a03d23f0'></a>

## Understand performance versus expectations
3 To what degree are company priorities aligned with key stakeholder priorities?
How is the company performing vis-à-vis those expectations?

<a id='23ae87b7-9602-4356-a5b2-2cf58831ee41'></a>

2. In depth, qualitative assessment of action ROI
Project-specific cost curve
<::chart: A bar chart titled "Project-specific cost curve" shows the "Short-term value to company" relative to "total cost" on the Y-axis (ranging from "High" to "Low"). The X-axis represents "Value to society," with the note "Width of bar = total value impact." The bars are arranged from left to right, indicating increasing "Value to society." The categories and their approximate "Short-term value to company" are:
- Transport infrastructure: Negative value
- Healthcare: Negative value
- Education: Negative value
- Water preservation: Positive value
- Air pollution remediation: Positive value
- Biodiversity preservation: Positive value
- Energy infrastructure: Positive value
- Other infrastructure: Positive value
- Housing & resettlement: Positive value
- Notional tax transparency & anti-corruption: Positive value
- Workforce development: Positive value
- Supplier development: Positive value
- Downstream sector development: Positive value
- Vocational training & job matching: Positive value
- Water infrastructure: Positive value
- Waste management: Positive value
- Tracking impact: Positive value
- Engaging in public relations: Positive value
- Local tax transparency & anti-corruption: Positive value
- Building strong relationships: Positive value
- Safety: Positive value
- Clarifying needs & expectations: Positive value
- Forming a joint vision: Positive value
The bars generally increase in height (more positive value) from left to right, and their widths also vary.::>


<a id='de6a9814-340f-43af-9b84-feeb3218233a'></a>

### Explore bold moves that create a symbiotic relationship

4. Don't optimize for the short-term

*   Understand network of decision-makers and influencers
*   Make clear to government what is at stake
*   Link the company's operations to the country vision

<a id='01cf127b-ffba-4c60-90d5-4f65b981afa8'></a>

<::Flowchart: CSR Assessment Process::>
Phase 0
Preparation
Phase 1
Diagnostic
Phase 2
Risk assessment
Phase 3
Develop portfolio of initiatives
Phase 4
Action planning

Key activities

Phase 0: Preparation
*   Understand CSR work done to date, e.g., align with strategic framing and specific deep dives conducted
*   Prepare reference case contacts

Phase 1: Diagnostic
*   Tailor asset specific CSR assessment (SE version of Compass)
*   Conduct diagnosis on site, interviews with management, workforce and external stakeholders
*   Prepare joint SE and McK team, e.g., joint 'boot camp'

Phase 2: Risk assessment
*   Conduct local workshops with stakeholders to identify and evaluate risks
*   Leverage McK risk database to categorize and estimate risks
*   Rank risks, highlight any high-impact, high likelihood
*   Calculate NPV for all important risks

Phase 3: Develop portfolio of initiatives
*   Leverage McK CSR database to generate ideas for initiatives
*   Conduct local workshops do develop adequate initiatives
*   Iterate initiatives with stakeholders to ensure buy-in, feasibility and efficiency
*   Rank initiatives based on ROI
*   Select mix of initiatives

Phase 4: Action planning
*   Develop detailed action plan for implementation of each initiative
*   Include local stakeholders (internal and external) in planning
*   Launch implementation teams
<::/Flowchart::>

<a id='c7cc874c-58b5-4280-b573-16154efc6000'></a>

McKinsey & Company

<a id='88162bbd-018e-4614-b01e-c80bae9594ee'></a>

7