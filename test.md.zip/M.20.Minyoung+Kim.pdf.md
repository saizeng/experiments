<a id='c33bbb8a-6d94-4f98-b7d0-ee0ecb0b329c'></a>

<::A digital illustration featuring a blue wireframe model of a human body, with a partial view of its skeletal structure. In the background, several hexagonal icons are visible, representing concepts such as an eye, lungs, and a smartphone, suggesting themes of health, technology, and human interface. A glowing circular interface element is at the bottom.: figure::>
l
i
i
ñ
F

<a id='76245bcc-7360-4a8a-b5c8-7a04661a16b6'></a>

McKinsey&Company

<a id='787ef924-0677-440f-b94d-402be513806c'></a>

Current perspectives on Medical Affairs in Japan

JAPAN MEDICAL AFFAIRS SUMMIT

February 8, 2018

<a id='e67dea66-6e76-481d-8910-929030914aa8'></a>

<::A logo with a red circle containing a white ECG line. Partial text overlaid reads: "AN", "DICAL AFF", and "SUM".: figure::>

<a id='3473e693-8152-438f-a1c3-6d6d4dd862a0'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is
strictly prohibited

<a id='f5515365-4475-46d7-a400-1e725ccad692'></a>

<::A close-up photograph shows a person's hands holding a dark blue smartphone. The person is wearing a white long-sleeved shirt. Abstract blue and white digital graphic overlays are visible on the image.: photograph::>CONFIDENTIAL AND PROPRIETARYAny use of this material without specific permission of McKinsey & Company isstrictly prohibited

<!-- PAGE BREAK -->

<a id='b4fb452d-781c-4ba3-8f5b-21aa7a6f4dd0'></a>

Five+ years ago, Medical Affairs played primarily a support role

<a id='d8d14ffd-06ef-4c18-9bc7-a592aba9bdc5'></a>

<::A blue banner with "R&D" in white text overlays an image of two women working in a laboratory. The woman in the foreground wears a white lab coat with grey sleeves and safety glasses, mixing a red liquid in a conical flask on a white lab bench. Various lab equipment, including beakers with yellow and orange liquids, are visible. In the background, another woman in a lab coat is seated, working with lab equipment at a white counter.: figure::>

<a id='caa27d1a-18ee-43ca-9232-b597d0367e8f'></a>

<::A blue banner with the text "Commercial" is at the top. Below the banner, a woman in a grey pinstripe suit and a man in a white lab coat and blue tie are shaking hands over a white counter. The background features green plants. A dark blue arrow points upwards from the bottom of the image.: figure::>

<a id='aec27fc7-74b3-4f6b-9eda-9ceb60adb816'></a>

<::A group of medical professionals, with a man and a woman in the foreground looking at a clipboard. The man is wearing a white lab coat and a tie, smiling, and holding a pen. The woman is also wearing a white lab coat with a stethoscope around her neck, gesturing with her hand. Other medical staff are blurred in the background. A blue banner across the top reads "Medical Affairs".: photo::>

<a id='c8fe566c-705b-4192-ad02-5a59132b39f0'></a>

"Commercial roles matter, Medical Affairs is there to support"

<a id='4d7e3f88-36ef-4e47-9c76-e5ae48a8c399'></a>

McKinsey & Company

<a id='287f1877-9b18-44be-9938-f2ed42d0214a'></a>

2

<!-- PAGE BREAK -->

<a id='7f6843b1-d703-4d21-a930-c583f2523a67'></a>

Today, the demands on Medical Affairs are rapidly growing globally

<a id='e2ebedaf-e62d-4850-9e02-42867f0ccaef'></a>

New decision-makers

<a id='7db257f7-93ae-4213-a1cb-c5fe53b60cc4'></a>

<::figure: A diagram illustrating "Emerging demands" at its center, surrounded by six circular images each representing a contributing factor. The central circle contains the text "Emerging demands" and three upward-pointing arrows. The surrounding circles are:
1. Top-left: A stethoscope on an American flag, labeled "Changing regulatory environment."
2. Middle-left: Two people in business attire seated in a modern building, labeled "Evolving commercial model."
3. Bottom-left: A person in a white coat (doctor) using a laptop, labeled "Wide-spread adoption of technology."
4. Bottom-right: A blue bar and line graph, labeled "More data and transparency."
5. Middle-right: A hand pointing at a computer screen displaying chemical structures, labeled "Increasingly complex science."
6. Top-right: A document with the word "VALUE" highlighted in green, next to a green marker. The text visible on the document includes "VALUATION," "1. estimate," "2. act," and "VALUE worth of a thing that will have." This is labeled "Broader definition of value."::>

<a id='2f528f26-ccc5-44a5-bb1e-ac73159cdfcc'></a>

which a prom
It includes n
grant, and
love and a
ALUATIO
1. esti
2. act
wor
stimati
ALUE worth of
thing that will h

<a id='7b18a496-642c-4c9c-8115-ea4779e88d1c'></a>

SOURCE: Medical Affairs Leader Forum

<a id='daae3cf1-1676-47f1-8ab4-6bf1adf9eee1'></a>

McKinsey & Company

<a id='86f74f3d-c7e0-4b33-9eff-9dad218edf57'></a>

3

<!-- PAGE BREAK -->

<a id='4cfc710f-de52-4f83-8120-de523bf3701c'></a>

Similar changes and demands are arising in Japan

<a id='97c78512-5b79-490c-aac7-e4ab1fa7210e'></a>

<::logo: [Japan] [No readable text] A red circle with a white outline is centered on a white background.::>

<a id='44da4dd4-593a-470d-94a1-8bc063d46f6d'></a>

New decision-makers
* Increasing use of clinical guidelines by the government

Increasingly complex science
* New technology such as CAR-T and gene therapy in pipeline

Wide-spread adoption of technology
* Increasing adoption of digital channel by HCPs

<a id='01618a39-73cd-413e-b352-e06326e92f40'></a>

Broader definition of value
- Ongoing HTA pilot and future integration into price revision scheme

More data and transparency
- Full launch of MID-NET from FY 2018

<a id='38fc0b6e-d66d-4b49-a6bc-8dc7e20610ad'></a>

ALUABLE
which a prom
It includes 2
grant, and
love and a

ALUATIO
1. estiv
2. act
WOL
stimat
ALUE worth of a

<a id='cacc4049-45d1-49e6-b79a-b46dd2551b76'></a>

<::A photograph showing three business people seated in a modern, brightly lit building lobby or atrium, with large windows and multiple levels. The people are engaged in conversation.: figure::>

**Evolving commercial model**

* MR visit restrictions
* Rise of multi-channel

<a id='f187992c-8dc8-4db2-b87b-b13b3ca55723'></a>

<::A stethoscope rests on an American flag. To the right of the image, text reads: Increasingly stringent regulatory environment. Below that, a bullet point says: Recent pricing reform.
: figure::>

<a id='966b5d94-d856-4c64-bfd9-64b35c8cd96f'></a>

SOURCE: Medical Affairs Leader Forum

<a id='5101143d-bf34-454e-a5e3-98c0a1a36651'></a>

McKinsey & Company

<a id='f557aae8-a27e-4969-8173-86a4c0a22532'></a>

4

<!-- PAGE BREAK -->

<a id='c1b3591d-15b1-4604-b94c-67e8ce6b6ad7'></a>

The scope of medical activities continues to increase

<a id='f9e5ba1a-119c-4987-a428-cb20014b09ac'></a>

<::list of services with icons
: icon: Two overlapping speech bubbles.
: text: Relationship management and communication of product information
: icon: A person presenting in front of a whiteboard.
: text: Medical education
: icon: A circle with an 'i' inside, representing information.
: text: Medical information services
: icon: A megaphone.
: text: Medical communications, including publications::>

<a id='8ea90752-ad2f-4149-9823-1b88747fed14'></a>

<::Legend: Grey square: Historical focus, Blue square: Growing focus, Dark blue square: New focus::>

<::Icon: A stylized smartwatch/wrist device with a line graph on its screen::> Post-launch clinical trials
(e.g., Phase IIIb/IV trials, IIS and
observational studies)

<::Icon: A stylized plus sign connected to a vertical line with three dots::> Medical strategy

<::Icon: A clipboard with a plus sign on it::> Health Economics and
Outcomes Research (HEOR)

<::Icon: A document/paper with gears and binary code (0s and 1s) on it::> Real world evidence

<a id='ba266ac1-0037-4e78-b87d-652e2f5736d3'></a>

McKinsey & Company

<a id='8efccc24-46aa-4294-88a4-ce5a28cf263f'></a>

5

<!-- PAGE BREAK -->

<a id='f5eb4c83-9b5e-41af-8b0f-c8dee60318a4'></a>

We see medical taking more prominent role as the "Third Pillar" of the
business in Japan

<a id='728ec859-48b3-4e04-8e13-1c27daa72e54'></a>

<::The image displays a diagram titled "The third pillar" at the top, depicted as a gray arrow pointing upwards. Below this, there are three main sections arranged horizontally, each featuring a blue banner, an image, and an associated descriptive text in a circle below. Blue arrows connect the sections, indicating a flow from left to right. The sections are:1.  **R&D**: Under a blue banner labeled "R&D", an image shows two scientists in a laboratory, wearing lab coats and safety glasses, working with beakers and chemicals. Below this, a circle contains the text "Highly strategic". A blue arrow points from this section to the "Medical Affairs" section.2.  **Medical Affairs**: Under a blue banner labeled "Medical Affairs", an image shows a group of medical professionals (doctors and nurses) in scrubs and lab coats, gathered and discussing, with some looking at a clipboard. Below this, a circle contains the text "In-market data generation". A blue arrow points from this section to the "Commercial" section.3.  **Commercial**: Under a blue banner labeled "Commercial", an image shows a man in a lab coat shaking hands with a woman in a business suit across a desk. Below this, a circle contains the text "In-market monitoring".::>

<a id='0ad847af-562a-45ea-8342-3cdc39769808'></a>

SOURCE: Medical Affairs Leader Forum

<a id='54eeda5b-4a00-429e-85b4-6541abf59b97'></a>

McKinsey & Company

<a id='a3176018-731c-4bd2-b3c7-a20733025df4'></a>

6

<!-- PAGE BREAK -->

<a id='feec4b67-55aa-4d18-9225-5c6372079298'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='ee88cda2-68cb-4ca7-8c0c-696159e01fcb'></a>

<::icon: A blue circle with a white silhouette of a doctor wearing a headlamp and a stethoscope.::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<a id='dc8c9902-b53f-4ee1-86aa-0bd7ec2d90e1'></a>

<::Blue circle with a white caduceus symbol in the center, surrounded by six white arrows pointing outwards in different directions: icon::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<a id='7bcc92e4-587b-4fb6-84b3-102c9b368ee6'></a>

<::An icon depicting a blue circle with a white magnifying glass. Inside the magnifying glass, there are white pill and tablet icons.
: figure::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<a id='56bcbe54-99e5-4bf9-8280-9a09864d6064'></a>

<::An icon depicting three stylized white human figures within a blue circle, representing a group or team. Below the icon, the letter "D" is present. The accompanying text reads: Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies: icon::>

<a id='13df83b2-0791-4547-881c-368ac6a4f01e'></a>

McKinsey & Company

<a id='20449b9a-130f-4a7e-8e32-3de2a1142543'></a>

7

<!-- PAGE BREAK -->

<a id='70bfe41f-6609-485b-92ad-799ede8155b0'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='ea8ed7c1-ce2f-4c11-ae2b-6e38e257ecb3'></a>

<::logo: [Medical Professional/Healthcare]A white silhouette of a medical professional with a stethoscope is set against a circular blue background with a long shadow.::>

<a id='61f42558-23ae-4964-a1b5-900894379bf0'></a>

*Deeper*
*understanding of*
*the customers* to
better target the
different needs of
physicians and be
able to provide
tangible value

<a id='57552cf0-2449-45ef-a3db-e4a303ce8541'></a>

<::A light blue circle with a white caduceus symbol at its center, surrounded by six white arrows pointing outwards in different directions: diagram::>

B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge 

<a id='2364a0ce-453c-4aa6-90d4-c31f56be07d7'></a>

<::An icon of a magnifying glass over several pills and capsules, all enclosed within a circle.
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment
: icon::>

<a id='85dbc56f-3009-4387-8422-b105459804d6'></a>

<::icon of three people silhouettes in a circle, labeled 'D' : figure::>Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies

<a id='8bf3659e-4669-4108-a2a1-8a73252e6ba0'></a>

McKinsey & Company

<a id='510f9917-5d07-4f3d-a258-83b332a929d6'></a>

8

<!-- PAGE BREAK -->

<a id='f758f75c-7a15-45e4-b248-49452806128d'></a>

Quality of MSL interaction have clear correlation with the satisfaction and scientific influence of the company

<a id='369e5671-57b4-4887-ab3e-aa7bcbca927e'></a>

<::logo: Unidentified
None
A blue circle with a white doctor icon and a red circle on a white background, representing the Japanese flag.::>

<a id='8a1a5e2e-ba4a-4e99-a101-83fa97bc5c93'></a>

Correlation between quality and quantity of the MSL activities and overall impact of a pharma company Percentage of respondents per case; n =460 <::chart: A grouped horizontal bar chart titled "Correlation between quality and quantity of the MSL activities and overall impact of a pharma company" displays data for Quality and Quantity categories, broken down by specific MSL activity aspects, against three impact measures: "Level of satisfaction with the company", ""Scientific influence" of the company", and "Likelihood of recommendation to peers". The values represent correlation coefficients. The chart data is as follows:  Quality:  - Process management skills of MSL:    - Level of satisfaction with the company: 0.66    - "Scientific influence" of the company: 0.47    - Likelihood of recommendation to peers: 0.49  - Level of scientific and medical knowledge of MSL:    - Level of satisfaction with the company: 0.64    - "Scientific influence" of the company: 0.44    - Likelihood of recommendation to peers: 0.49  - Interpersonal communication skills of MSL:    - Level of satisfaction with the company: 0.60    - "Scientific influence" of the company: 0.45    - Likelihood of recommendation to peers: 0.46  Quantity:  - Number of MSL visits:    - Level of satisfaction with the company: 0.33    - "Scientific influence" of the company: 0.25    - Likelihood of recommendation to peers: 0.28  - Number of MSL related activities:    - Level of satisfaction with the company: 0.27    - "Scientific influence" of the company: 0.17    - Likelihood of recommendation to peers: 0.35  - Average duration of MSL visits:    - Level of satisfaction with the company: 0.10    - "Scientific influence" of the company: 0.10    - Likelihood of recommendation to peers: 0.15::>

<a id='05ad5e85-4732-4778-9ca9-9869f2df5cca'></a>

SOURCE: Japan MAPES 2016

<a id='a69dd514-dba4-4d01-8a07-6c0a4e7fad31'></a>

McKinsey & Company

<a id='7818a6aa-00bc-4e06-8662-def57a4df0dd'></a>

9

<!-- PAGE BREAK -->

<a id='bcb81f4e-285d-472f-80f1-f67771899976'></a>

Yet, most companies are measuring quantity metrics of MSL activities
than quality or impact metrics

<a id='26c2ddd6-b780-49c9-8c26-0542db18d59e'></a>

<::logo: [Medical Professional/Healthcare Service]A white icon of a doctor with a stethoscope is set against a circular blue background with a long shadow.::>

<a id='7be18999-727c-44c8-baa3-4e9bfe2fd3f9'></a>

Performance management & metrics, 2015
<::transcription of the content: chart
Title: Percentage of respondents gathering the metrics¹

- Quantify of activity: 78%
- Quality of activity: 40%
- Impact of interaction: 20%
::>
- What are the quality and impact metrics that are representative of Medical performance in Japan?
- How can we find more practical and objective ways to measure these metrics? More real time?
- How can we build a better feedback mechanism for continuous performance improvement?

<a id='8ccfa736-a5b5-4653-bb7a-5d2ab3726d3a'></a>

1 N=13

<a id='57799e7e-5610-4af5-a1a4-a2f1b1a74fc3'></a>

McKinsey & Company

<a id='1438868a-1518-46dd-92cd-facc92e3d9a8'></a>

10

<!-- PAGE BREAK -->

<a id='01c02d01-6549-4de4-b57f-0e0c282cbec2'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='2da83107-7219-4dc7-a06f-0f252dd20c1c'></a>

<::visual content: light blue circle with a white icon of a doctor (head, shoulders, stethoscope)::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::visual content: dark blue circle with a white icon of a caduceus symbol (staff with two snakes and wings) at the center, surrounded by five arrows pointing outwards in different directions::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::visual content: light blue circle with a white icon of a magnifying glass over various pills/capsules::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<a id='0bfd33ee-333e-4102-b397-597892b3ec87'></a>

<::A light blue circular icon containing three white silhouettes of people (busts), representing a group or team. Below the icon, the letter "D" is prominently displayed.: figure::>Develop and acquire talent to cultivate and to build a strong, multi-faceted Medical Affairs organization that encompasses the new set of competencies

<a id='9c1ce1e3-9167-48a2-bb08-d97f23d34540'></a>

McKinsey & Company

<a id='54bf440f-f0a8-4c8e-84fa-8b8e372c471f'></a>

11

<!-- PAGE BREAK -->

<a id='19306766-bcc5-4399-b132-fd547caddf70'></a>

Pharma players in Japan generally lag behind digital leaders across most elements of digital enablement

<a id='b1c86906-5470-40d8-a303-4b3dda9956cd'></a>

<::logo: [Unidentifiable]
[No readable text]
A blue circular logo with a white six-pointed star and a blue medical caduceus symbol in the center, featuring a subtle shadow effect.:>

<a id='cae70c77-5eef-4e0b-8577-66e772607898'></a>

Rating on 5 point scale by 40 digital leaders across industry in Japan
<::chart: Bar chart showing ratings on a 5-point scale for various digital transformation aspects, comparing 'Digital leaders' (grey bars) and 'Japan PMP' (blue bars).

**Strategy**
- How aligned are your digital and corporate strategies?
  - Digital leaders: 4.1
  - Japan PMP: 2.6
- How customer-centric is your digital strategy?
  - Digital leaders: 3.8
  - Japan PMP: 2.5

**Organization**
- What share of your digital talent has experience from outside?
  - Digital leaders: 3.2
  - Japan PMP: 3.0
- Can your senior managers articulate their digital KPIs?
  - Digital leaders: 3.6
  - Japan PMP: 2.4

**Culture**
- What is your company's comfort level in taking risks regarding digital initiatives?
  - Digital leaders: 3.9
  - Japan PMP: 3.0
- To what extent do you use external partners to build digital capabilities?
  - Digital leaders: 3.5
  - Japan PMP: 3.3

**Capabilities**
- How well does your company leverage the data you collect to generate insights?
  - Digital leaders: 3.7
  - Japan PMP: 2.7
- Are your core back-office processes digitized?
  - Digital leaders: 4.0
  - Japan PMP: 3.5

Results from Google McKinsey&Company Digital round-table in Japan
Participants:
- AbbVie
- Bayer
- GSK GlaxoSmithKline
- Lilly
- Novartis
- Daiichi-Sankyo
- Janssen
- Shionogi
- Pfizer
- Omron
- MSD
- Philips
- Terumo
:chart:>


<a id='50973633-682e-430c-ae39-b94f8a813677'></a>

SOURCE: McKinsey DQ - Digital Benchmarking Survey

<a id='dd6a0cc1-ea19-4ea5-a976-f6ad4fa16d2d'></a>

McKinsey & Company

<a id='261f32e1-725e-46b0-8889-569429023eb9'></a>

12

<!-- PAGE BREAK -->

<a id='d9585a0a-bf10-4f67-838d-f5090a1f13d9'></a>

Digital has potential to change ways of working across whole Medical Affairs value chain

<a id='00bdd454-c043-4c75-9c8c-ca83370d311c'></a>

<::logo: [Unknown] No readable text. A white six-pointed star with a medical caduceus symbol inside is set against a blue circular background.::>

<a id='efdd27b3-1868-4cb8-8ba3-e84e22bc52c6'></a>

NOT EXHAUSTIVE

<a id='fc96bf81-8902-4291-9a7d-d3227e53d30e'></a>

Medical strategy

*   How advanced is my organization in digital Medical versus other Pharmacos?
*   What are customer preferences and potential future disruptors?
*   How to measure effectiveness of digital approaches?
*   How to evolve engagement model over Lifecycle using digital?

<a id='bd5fbec8-e6b5-4213-98a2-8dfa26aa6a30'></a>

## Field Medical/Engagement

*   What are the most effective ways to engage Medical KOLs in the digital world?
*   How to build optimal continuum of Medical engagement using mix of digital and physical interactions?
*   How to bring our content to places where HCPs and patients normally search for content (e.g. search engine optimization)

<a id='509b3710-d5ea-40f1-b943-ebb099cd8e7c'></a>

Medical support

* Can we use digital to make compliance more efficient and simple?
* Can we digitize our support (e.g. Medical Information processes) to make them more efficient and user friendly?
* How to run Medical Communication campaigns in digital world (e.g. which channels, what is calendar)?

<a id='8cc003be-11da-44bc-ae5e-15fcd055a539'></a>

Data generation & HEOR

* How to leverage digital and analytics to collect more granular data and better insights about patient's?
* Can we use digital to source new ideas for data generation?
* Are digital tools a potential threat to our current approach while enabling payors and other stake-holders to have granular data about our patients? How to respond?

<a id='2acbaab5-fc71-45e0-8850-ba2a39877de2'></a>

McKinsey & Company

<a id='e8c37f47-ab90-41c6-8d0e-6133a0bfae33'></a>

13

<!-- PAGE BREAK -->

<a id='ddac31e2-b799-42f9-a8e5-dd7c594e5316'></a>

There are already numerous sources of data available in Japan

<a id='ae94ec5a-2313-4eb6-9e7b-2db92ef69ddf'></a>

<::logo: [Unidentifiable]
[No readable text]
A blue circular logo with a white six-pointed star and a blue medical caduceus symbol in the center, featuring a subtle shadow effect.:>

<a id='c1ac1fe2-4a22-4e0b-8464-6648c0e62049'></a>

Treatment data
Medical claims data
Health checkup data
Wholesale sales data
Available now
<::logo of HCEI
: figure::>
医療統計情報プラットフォーム
Platform for Clinical Information Statistical Analysis
<::logo of MDV medical.data.vision
: figure::>
<::logo of Fujita Health University
: figure::>
藤田保健衛生大学
FUJITA HEALTH UNIVERSITY
<::logo of Japan Medical Data Center
: figure::>
株式会社日本医療データセンター
Japan Medical Data Center.
<::logo of JMIRI Japan Medical Information Research Institute, Inc
: figure::>
株式会社医療情報総合研究所
JMIRI Japan Medical Information Research Institute, Inc (JMIRI)
患者中心の保健医療を支える、地方情報分析のリーディングカンパニー
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
NDB open data by prefecture
(National database)
<::logo of HCEI
: figure::>
<::logo of Japan Medical Data Center
: figure::>
株式会社日本医療データセンター
Japan Medical Data Center
<::diagram of a building/structure
: figure::>
<::logo of IQVIA
: figure::>
<::logo of CRECON RESEARCH & CONSULTING
: figure::>
CRECON
RESEARCH & CONSULTING
Pharma can use by 2020
<::logo of Pmda
: figure::>
MID-NET
May open-up going forward
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
DPC database
<::logo of NCD National Clinical Database
: figure::>
NCD
National
Clinical
Database
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
NDB
(National database)
<::logo of Health Insurance Claims Review & Reimbursement Services
: figure::::>
社会保険診療報酬支払基金
Health Insurance Claims Review & Reimbursement Services
<::logo of Ministry of Health, Labour and Welfare
: figure::>
厚生労働省
Ministry of Health, Labour and Welfare
<::logo of Health Insurance Claims Review & Reimbursement Services
: figure::>
社会保険診療報酬支払基金
Health Insurance Claims Review & Reimbursement Services
<::logo of Japan Gastroenterological Endoscopy Society
: figure::>
JAPAN GASTROENTEROLOGICAL
ENDOSCOPY SOCIETY
一般社団法人
日本消化器内視鏡学会

<a id='ed629ad2-bf0d-4d71-b1dc-f3b0981f7a78'></a>

SOURCE: International pharmaceutical intelligence; McKinsey

<a id='06828fbb-9abe-4a33-abf6-8b9be304566c'></a>

McKinsey & Company

<a id='db5e4ce6-c96e-4b5b-b237-68d67092255b'></a>

14

<!-- PAGE BREAK -->

<a id='5c537316-35f8-4884-abe8-01d7870a5ebe'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='c9d2bbf8-9856-450d-a708-3d39f6b6bca0'></a>

<::figure: Four columns, each containing a circular icon at the top and descriptive text below it. The background of each column is a light grey. The icons are inside circles with shadows, giving a 3D effect. The text below each icon is presented as a key point.::>

<::figure: Column A::>
<::figure: Icon A: A light blue circle containing a white silhouette of a doctor wearing a stethoscope and a head mirror.::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::figure: Column B::>
<::figure: Icon B: A light blue circle containing a white Caduceus symbol (staff with two snakes and wings) at its center, with six arrows pointing outwards from it.::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::figure: Column C::>
<::figure: Icon C: A white circle containing a blue magnifying glass over various blue pills (capsules and a tablet).::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<::figure: Column D::>
<::figure: Icon D: A light blue circle containing white silhouettes of three human busts, representing a group of people.::>
D
Develop and acquire
talent to cultivate and
to build a strong,
multi-faceted Medical
Affairs organization
that encompasses the
new set of
competencies
<::/figure::>

<a id='8d58f21f-de0f-4d42-ad52-3c34d7044ca4'></a>

McKinsey & Company

<a id='0d77c5cf-746e-41e5-956f-cf8532b86a13'></a>

15

<!-- PAGE BREAK -->

<a id='71622804-ead5-44c8-9e38-2d9c3b6cf190'></a>

Coordination with other functions is critical in creating Medical impact

<a id='bd725e69-d747-4dac-8bbd-325e2aa610b9'></a>

<::logo: [Medical/Pharmaceutical]A blue circle contains a white magnifying glass examining various pills and capsules, with a long shadow extending to the right::>

<a id='f34236a0-752d-4562-b508-6875a9e51a59'></a>

Typical company interaction with a KOL <::radial diagram: The diagram features a central circular image of a smiling male doctor in a light purple shirt and tie, wearing glasses, with his chin resting on his hand, appearing to be in a medical office. Surrounding this central image are segments of a circle, each associated with a label representing different points of interaction. Clockwise from the top, these labels are: MSL, Conference website, R&D, Company website, e-Detailing, Marketing, MR, and Area Manager.::>

<a id='bb715fc3-7cf4-4991-a8ca-8163b9bf0625'></a>

**What we often hear from KOLs**

"I meet at least 4-5 different people from one company. But they don't seem to talk to each other."

"What I hear from one person is sometimes different from what I hear from another. It is quite confusing"

"Sometimes it takes weeks to get an answer to my questions. I don't know why. By then I am wrestling with another problem"

<a id='709f3579-a3f7-4bbf-8771-1c3721d9ae09'></a>

McKinsey & Company

<a id='9745e3de-77ed-4799-8498-391799e3b4e9'></a>

16

<!-- PAGE BREAK -->

<a id='9c6a7fb4-22c1-408f-8657-54b66bbee8c0'></a>

Role as a true 3rd pillar will require close collaboration with other functions

<a id='975403c7-2bf3-4481-b74b-187f46aa816d'></a>

<::logo: [Medical/Pharmaceutical]A blue circle contains a white magnifying glass examining various pills and capsules, with a long shadow extending to the right::>

<a id='3fbb25dc-afd1-4d59-9404-7368a0ddd1a6'></a>

<::A diagram titled "The third pillar" at the top, represented by a grey upward-pointing arrow. Below it, three columns represent different functions, each with a blue header and an image. From left to right:1.  **R&D**: Image of a woman in a lab coat and safety glasses stirring a red liquid in a beaker in a laboratory.2.  **Medical Affairs**: Image of a group of medical professionals in white coats and scrubs, looking at a clipboard and interacting. This column is connected to the R&D column by a blue circular arrow icon, and to the Commercial column by another blue circular arrow icon.3.  **Commercial**: Image of a woman in a business suit shaking hands with a man in a lab coat.: figure::>

<a id='e029c6bf-28fe-4b12-a76d-c831203bf9e4'></a>

*   *Where can we find the largest opportunity for impact? What are customers expecting?*
*   *Where can Medical take immediate leadership in these collaborations? And how?*
*   *What are current barriers in realizing better collaboration with others? Internal policy? Cultural?*

<a id='7796b1e3-a94c-4648-93e6-513b3609df10'></a>

McKinsey & Company

<a id='1edd4b21-ae12-4683-8d22-f3a67d560748'></a>

17

<!-- PAGE BREAK -->

<a id='46dd7dad-e7ef-4a19-b2c7-6084c2b0e5d2'></a>

Four priorities for Medical Affairs leadership in Japan

<a id='2b6d1a48-6b33-497b-b18e-008b978dabff'></a>

<::Light blue circle with a white icon of a doctor (head, torso, stethoscope) with a long shadow.: figure::>
A
Deeper
understanding of
the customers to
better target the
different needs of
physicians and be
able to provide
tangible value

<::Light blue circle with a white icon of a caduceus symbol with arrows pointing outwards in eight directions, with a long shadow.: figure::>
B
Getting ahead in
digital leadership to
facilitate coordination
and integration across
different medical data
and knowledge

<::Light blue circle with a white icon of a magnifying glass over pills and capsules, with a long shadow.: figure::>
C
More integrated
working model with
commercial & other
internal partners to
enhance patient
access to and best
use of optimal
medical treatment

<::Darker blue circle with a white icon of three stylized human figures (busts with collars and ties), representing a team, with a long shadow.: figure::>
D
Develop and acquire
talent to cultivate and
to build a strong,
multi-faceted Medical
Affairs organization
that encompasses the
new set of
competencies

<a id='41a64283-1d3b-4c94-b353-217763b0e697'></a>

McKinsey & Company

<a id='6993d821-7fae-4a1d-b924-d3a89e324609'></a>

18

<!-- PAGE BREAK -->

<a id='a35b7535-0409-4054-9b39-ff55e0571823'></a>

A strength-based approach to Medical Affairs talent

<a id='326d3cc2-a7b8-4d39-9dbb-02fe890f51be'></a>

<::logo: [Unknown]No readable text.A blue circle contains three white stylized figures of people with long shadows, suggesting a team or group.:>

<a id='f9f4217e-2f22-4724-8d53-054e03cc79fc'></a>

<::Medical Affairs capabilities diagram
: The diagram is titled "Medical Affairs capabilities" at the top. At the center, it states "Medical Affairs capabilities". Surrounding this central point, arranged in a circular flow, are six other capabilities, each represented by an icon within a circle and a descriptive label:
- Learning agility: Icon of a running person.
- Business leadership: Icon of a group of people with one raising an arm.
- Strategic vision: Icon of a chess king and knight.
- Emotional intelligence: Icon of a brain with light rays.
- Deep understanding of compliance: Icon of scales of justice.
- Scientific and technological thought leadership: Icon of a microscope.::>

<a id='23a7db5c-959d-4cd8-a959-540e473a9f65'></a>

# A strength-based approach

*   **Skills and competencies** examined at level of the group, e.g.,
    *   Cultivate individual's strengths for the benefit of the group
    *   Seek candidates that fill gaps in the group, not the "perfect" candidate
*   **Comprehensive talent strategy** supports and builds skills and capabilities of group
*   "**Field and Forum**" approach integrates learning modules and real work experiences (as reinforcement)

<a id='b87e3b0a-7702-41d6-b35c-3dc555d6fc03'></a>

SOURCE: Managing talent in the Medical Affairs function: Creating value through strengths-based approach

<a id='0d48f6f1-d1a0-4021-869d-c290d1d89a78'></a>

McKinsey & Company

<a id='ec825e82-3691-41fa-8ddb-e68aef985e83'></a>

19

<!-- PAGE BREAK -->

<a id='fc0e305c-1f1c-4f1d-9127-95414b534755'></a>

Medical *is* the "Third Pillar" of pharmaceutical business

<a id='a5819f6c-ac5d-40b3-9690-d39938b3b621'></a>

<::A photograph of a laboratory setting. In the foreground, a woman wearing a white lab coat and safety glasses is mixing a red liquid in a conical flask with a stirring rod. To her left, there's a beaker containing a yellow liquid under a mechanical stirrer. In the background, another woman in a lab coat is seated at a workbench, working with equipment. The lab has white countertops, shelves with glassware, and scientific instruments. A blue banner at the top of the image displays the text "R&D" in white letters.
: figure::>

<a id='2fccbc17-0cf7-4bc0-a148-ebaf85eb56a1'></a>

<::icon: A white silhouette of a person wearing a doctor's head mirror and a stethoscope, inside a blue circle with a long shadow.::>

Deeper understanding of
the customers

<a id='70d4874e-0ef0-49c9-b15d-a9645c210429'></a>

<::Diagram titled "The third pillar" at the top, presented within a house-shaped banner. Below this, two main sections are shown side-by-side, connected by a large blue plus sign (+). The left section is labeled "Medical Affairs" and contains an image of a group of medical professionals (doctors and nurses) in a discussion, looking at clipboards. The right section is labeled "Commercial" and contains an image of a businesswoman shaking hands with a man in a lab coat. Below these two sections, a large blue arrow points downwards to three circular icons, each with text beneath it. The first icon on the left shows a white caduceus-like symbol with multiple arrows radiating outwards in a star shape on a blue background, with the text "Getting ahead in digital leadership". The middle icon shows a white magnifying glass over various pills and capsules on a blue background, with the text "Integrated working model with internal partners". The third icon on the right shows three white stylized human figures on a blue background, with the text "Develop and acquire talent".: diagram::>

<a id='e0994422-9cbf-4882-8a7d-5414cb53e0dd'></a>

McKinsey & Company

<a id='718abaee-ff70-4a7a-96bc-2f6f0558cdaa'></a>

20