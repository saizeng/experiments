---
name: web_search
description: >
  Searches the public web for current information. Use when the question
  requires real-time data, recent news, market comparables, regulatory
  updates, public company filings, or any external context not available
  in internal structured data or document stores.
trigger: >
  when user asks about external market data, recent news, public
  comparables, regulatory changes, industry benchmarks, or anything
  that requires up-to-date information from the public internet
category: search
parameters:
  - name: query
    type: string
    required: true
    description: Search query to execute
  - name: max_results
    type: integer
    required: false
    default: 5
    description: Maximum number of search results to return
---

# Web Search Skill

Wraps a web search API to fetch current external information.

## When to use
- Market comps and benchmarks not in internal data
- Recent news about a client, deal, or sector
- Regulatory or legal updates
- Public filings (SEC EDGAR, etc.)
- General knowledge questions outside internal data scope

## run.py contract

- Reads JSON from stdin: `{"query": "...", "parameters": {"max_results": 5}, "upstream": {}}`
- Executes web search
- Writes JSON to stdout: `{"results": [{"title": "...", "url": "...", "snippet": "..."}]}`
