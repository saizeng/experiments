#!/usr/bin/env python3
"""Stub skill runner — replace with real report generation logic."""

import json
import sys


def main():
    payload = json.load(sys.stdin)
    deal_id = payload.get("deal_id", "unknown")
    fmt = payload.get("format", "pdf")

    # TODO: Replace with actual report generation
    result = {
        "file_path": f"/tmp/reports/{deal_id}_report.{fmt}",
        "title": f"Deal Report — {deal_id}",
        "pages": 1,
        "note": "This is a stub. Implement real logic here.",
    }

    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
