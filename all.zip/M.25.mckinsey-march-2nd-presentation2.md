<a id='f514535b-f70f-4a88-8915-5aabd1fdcb07'></a>

<::An image showing stacks of white bags or boxes, each with "UNITED STATES" printed on it multiple times, next to stacks of blue plastic crates.: figure::>

<a id='ac02fb7b-7d49-4c95-bdb2-c3f621a3a248'></a>

Envisioning America's
Future Postal Service

Options for a Changing Environment

<a id='dc5bd42e-e35b-488f-bab9-a87792a8fef0'></a>

March 2, 2010

<a id='20ae6438-ba18-4a7c-8579-a0f6ae0851a4'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='46a37408-a333-4996-997c-47bccc6c0eb6'></a>

<::photograph: The image shows a storage area with stacks of containers. On the left, there are tall stacks of blue plastic crates. To the right, there are tall stacks of white containers or boxes, with text printed on their sides. The visible text on these white containers includes: INTEN, UNITED STATES, UNITED STATES, UNITED STATES, NITED STATES, IMITED STATES, UNITED STATTO, UNITED STATES, FASTER STATES, UNITED STATES, UNITED STATES, LUNITED, 20::>

<a id='d34c0b79-c21c-49a3-8aec-e448ff17bce6'></a>

Today's discussion

<a id='66a6d5ba-3985-46a6-a358-61018de29af9'></a>

- Review of economic trends and financial forecast

<a id='3053e83d-35bf-469e-a47e-8a55e7c258fa'></a>

* Value of planned actions

<a id='6013c221-e495-4aea-894e-ff5e012c1e6c'></a>

- Additional options to ensure a viable Postal Service

<a id='b232b597-ca1d-4999-87f9-7ab705339ffa'></a>

1

<a id='b91376f1-8f61-40ed-88f7-3d6d64837a50'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='3546018c-6200-4d2c-a4bb-ff5cfe6fe54f'></a>

McKinsey built an integrated forecast and set of options

<a id='b5cbb013-fbfd-4734-9308-5a2d6f47d44a'></a>

Volume forecast

BCG
THE BOSTON CONSULTING GROUP

Prepared volume and revenue
projections of the USPS core
mailing and shipping business

<a id='dbab8bbe-283f-4f7f-ab8c-a7cb1d12deb4'></a>

Revenue diversification
research

accenture

Examined revenue diversification
pursued by foreign posts

<a id='e4e02bb7-45b3-4f3f-bbd6-176dd1895296'></a>

Integrated business forecast

McKinsey&Company

Integrated the BCG and
Accenture work with
USPS data

<a id='75b34046-05d1-4f00-b941-7496ad0c995e'></a>

- Forecast baseline and scenario profitability

<a id='d9edda55-f625-47c5-9cf4-19efa491d362'></a>

* Assessed a comprehensive list of revenue and cost options

<a id='beffefab-c7da-44a1-8fe9-2f58fd1994eb'></a>

2

<a id='d3c5d688-0167-4bdd-8db1-6d06b9dba8a5'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='761469f4-e401-49d0-b940-73d4b59574ec'></a>

Four trends are increasing pressure on USPS

<::transcription of the content
: Revenue trends
Volume
Declining steadily

Price
Rising but capped

Cost trends
Universal Service
Obligation
Large fixed cost base

Workforce costs
Rising cost per hour

UNITED STATES
POSTAL SERVICE
: infographic::>

<a id='d5c26bf2-e9f5-4e8d-889d-5c6f1a457b1a'></a>

3

<a id='c18e9250-7e01-41c4-83f5-e5693ba22111'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='860e12e8-dc49-4b72-b028-41ff7d05c766'></a>

Price: Price increases combine with volume declines for flat revenue through 2020

<a id='ed19470d-b706-4bb8-af39-8a89767bd7fb'></a>

Volumes declining
-1.5% per year from
2009-2020

X

Prices rising
with inflation
+1.9% per year from
2009-2020

<a id='0366f055-087f-4383-b287-eabd5f381363'></a>

<::USPS revenue in Billions, presented as a waterfall chart.The chart starts with "2009 revenue" at $68 B. There is a decrease of $16 due to "Volume decline & mix shift", followed by an increase of $17 due to "Price impact". The chart concludes with "2020 revenue" at $69 B.
: chart::>

<a id='9e4bf20e-b14e-4e11-91e2-a8663eb0e1db'></a>

4

<a id='8057b120-e055-4a94-bcdc-967ca3ecfd66'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='a6fc19fb-9ab1-4ff6-9d10-ca91030bf256'></a>

Revenue trends: Declines focused in higher contribution First-Class Mail <::chart: This bar chart displays volume trends in billion pieces for First-Class and Standard mail, comparing data from 2009 and 2020. Volume is measured in Billion pieces. For First-Class mail, the volume decreased from 84 in 2009 to 53 in 2020, representing a -37% change. For Standard mail, the volume increased from 83 in 2009 to 86 in 2020, representing a +4% change. Below the chart, the "Portion of total margin available to cover fixed costs (2009)" is shown as 71% for First-Class mail and 21% for Standard mail.::>

<a id='b7b0ec1a-44a2-4cb3-9105-5c83edea21b2'></a>

5

<a id='bed60433-aedd-4030-b817-eab519c6f182'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='5c4f3488-6b09-45d5-9e82-9021f6dac49c'></a>

Universal Service Obligation

<a id='e94f0bb2-6b8a-4464-84e5-91a7a90655f5'></a>

<::A composite image features a light blue map of the United States, including Alaska and Hawaii, set against a dark blue background. Overlaid on the map is the text: "Network was historically built to provide high service levels to customers, regardless of volumes".

Three smaller images are positioned over different parts of the map:
1. Top right: A photograph of a United States Post Office building with a blue awning. The sign above the entrance reads "UNITED STATES POST OF UPTOWN STATION HOBOKEN, NEW JERSEY 070" and includes the USPS eagle logo.
2. Bottom left: A photograph of a black mailbox on a wooden post, with several colorful letters visible inside, set against a blue sky with white clouds.
3. Bottom right: A photograph showing an intricate view of a mail sorting machine with numerous compartments and mechanical components.: figure::>

<a id='0d8512dd-3251-4db6-be3f-4dd52dfd5b60'></a>

6

<a id='99ec8600-39cf-4c85-96bb-746e489e528b'></a>

<::McKinsey&Company: figure::>

<!-- PAGE BREAK -->

<a id='10aaaaa7-d9a4-4b5e-b671-8a08e13ef720'></a>

Universal Service Obligation:
Customer service network costs are largely fixed

<a id='4141493e-f1a8-47be-9824-b9ddc755a6c4'></a>

<::A photograph of the exterior of a United States Post Office building. The building has a reddish-brown facade with horizontal siding. Above the main entrance, a blue awning with the white USPS eagle logo is visible. On the building facade, white text reads "UNITED STATES POST OFFICE UPTOWN STATION HOBOKEN, NEW JERSEY 070". Below the text and awning are large glass windows reflecting the surrounding environment.: figure::>

<a id='b9a71089-f67a-4558-a211-7ce5f3cd50ad'></a>

<::U.S. retail locations chart::>
<::Title: U.S. retail locations
Unit: Thousands

Bar chart data:
- USPS: 36.5
- McDonalds: 13.9
- Starbucks: 11.1
- Walgreens: 7.5
- Walmart: 3.6
: chart::>

<a id='f33bdd31-0560-4e3c-9ee9-88dff8e84177'></a>

## Service network
- 600 weekly counter customers at the average Post Office, 1/10th of Walgreens
- Prohibited from closing Post Offices solely for economic reasons

<a id='c6d4ecda-93fd-4f97-b7a4-672f47311b42'></a>

7

<a id='c2e7ac78-1b20-4947-930b-3a7f4390f31c'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='11d15c26-ae2b-4cb6-a7bc-8ba69bcf9e5b'></a>

Universal Service Obligation:
Processing overhead costs are largely fixed

<a id='c210f762-8a8e-4c84-8525-b80f1cca2b5d'></a>

<::An industrial machine with multiple black compartments, some filled with papers or cards, and others containing mechanical components and wiring. A cylindrical silver object is visible near the center. The machine appears to be a sorting or processing unit.: figure::>

<a id='f5e44b3b-9aa9-42b5-8c84-051a5f311af6'></a>

600 processing facilities
---
~12 for every state

<a id='1d3453c8-7652-4c87-b118-ae8534548759'></a>

# Sortation plants

* Ensure overnight delivery of local mail
* Network largely fixed
* Volume declines are rapidly reducing economies of scale

<a id='2eac49ca-01c4-48ed-9111-a605fe97aaef'></a>

8

<a id='1eeee549-1058-420d-8395-13e9235dd396'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='ee3b7f10-bd1b-403b-ae6c-b9a4edc758f6'></a>

Universal Service Obligation:
Delivery requirements are growing

<a id='8ec333c4-7914-431c-b3bd-02200399a968'></a>

<::A photograph of a black mailbox with its door open, revealing several colorful envelopes inside. The mailbox is mounted on a wooden post against a sky with white clouds. To the right is a bar chart titled "Addresses Millions". The chart shows two bars: one for 2009 with a value of 150, and one for 2020 with a value of 162. An arrow with a circular orange label indicates a "+8%" increase from 2009 to 2020.
: figure::>

<a id='df2c3f2f-25f1-4379-8de0-ea7a8be73060'></a>

Delivery network
* Deliver to every address in America
* 6-day delivery
* Corresponding high fixed delivery cost

<a id='d7d531fe-5c25-4766-b59c-68fb243e3e93'></a>

9

<a id='502d87b5-80c5-4cff-bc02-09bca2d03361'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='1a34db11-848b-450f-803c-2818fb3d03b3'></a>

Workforce costs:
Continue to rise faster than inflation

<a id='f52a2b34-01e4-4a1a-a04c-2bc9d5dd8321'></a>

<::bar chart::>Workforce annual rate increases, 2010-2020
Percent

Bar 1:
Label: Wages
Value: 1.3-2.5

Bar 2:
Label: Workers' compensation
Value: 2.0-4.0

Bar 3:
Label: Health benefits
Value: 4.7-5.2

Inflation line (dotted yellow):
Value: 1.9%
Label: Inflation (CPI at 1.9%)::>

<a id='2d81b76c-2e6a-4f2a-9b87-b052a937a9db'></a>

10

<a id='c79a35e5-728b-4348-a680-cd0b8a8d561a'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='66adecdb-962c-4a2c-b23f-1ceacf5b5cfe'></a>

Workforce costs: Required Retiree Health Benefit funding is substantial from 2010-2016

<a id='8c92f1bb-985b-4d4a-8afd-02aea4019d0e'></a>

<::A large modern building with a sign that reads "Medical Center" on the side. The building has multiple stories, with the upper section featuring large blue-tinted windows and the lower sections constructed with light brown brick or stone. A covered entrance area with large pillars is visible in the foreground, leading into the building. The sky is clear blue. There are some trees without leaves and a mountain range in the background on the left. The foreground shows a paved area, possibly a parking lot or driveway, with yellow bollards and red markings.: figure::>

<a id='7810faee-1799-4cad-8f11-d46f5fd6712c'></a>

<::A smiling male doctor wearing a white lab coat, a light blue collared shirt, and a red patterned tie, with a stethoscope draped around his neck. He has short dark hair and a light beard. The background is a solid dark blue with a subtle lighter blue curved shape visible behind his head.: figure::>

<a id='fdf34582-7ddb-45eb-859e-320df3677e2b'></a>

Required Annual Retiree Health Benefit (RHB) funding
<::
- 2005: $1.5 billion (indicated by a blue arrow)
- 2010-16: $9.0 billion average (indicated by a blue arrow)
Percent of total revenues 2010-16
- 12-16% (indicated by a blue arrow)
: data visualization::>

<a id='4c5fc82a-4572-4598-9ecb-99258ace9355'></a>

11

<a id='4b5920bc-1474-4e8a-b920-c7dfb1836c75'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='63c5510c-9662-404c-92fd-c0819676a183'></a>

Recent losses are forecast to grow without changes <::Net profit/loss chart showing $ Billions on the y-axis (ranging from -30 to 10) and years on the x-axis (ranging from 2000 to 2020). The chart is divided into two sections by a vertical dotted line at 2009: 'Actual' data from 2000 to 2009, and 'Forecast' data from 2009 to 2020. The 'Actual' line shows fluctuations, starting near 0 in 2000, peaking above 0, and then declining to below 0 by 2009. The 'Forecast' area, shaded in light blue, shows a continuous decline, indicating a 'Cumulative loss 2010-2020 $238 billion'.::>

<a id='142be187-9052-4d3c-8b10-96a10b74e2a0'></a>

12

<a id='5c6da3b9-d161-47e5-834c-2e853124130d'></a>

<::McKinsey&Company
: figure::>

<!-- PAGE BREAK -->

<a id='7d3ca387-a16f-4193-8a4e-c11305755a8b'></a>

Actions within Postal Service control: Four sets of actions could reduce the 2020 gap by $18 B

<::table:
| Action                               | Net profit benefit in 2020 ($ Billions) |
|:-------------------------------------|:----------------------------------------|
| 1 Product and service actions        | ~2                                      |
| 2 Productivity improvements          | ~10                                     |
| 3 Workforce flexibility improvements | ~0.5                                    |
| 4 Purchasing savings                 | ~0.5                                    |
| Avoided interest due to reduced debt | ~5                                      |
| Total                                | ~18                                     |
| Cumulative impact 2010-2020          | ~123                                    |
:table::>

<a id='36c27436-f10c-4849-a880-ee3aec582509'></a>

13

<a id='09752648-6896-41ce-a15d-d6fb81ac2ea6'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='41481d5c-4420-4d06-baa2-d9de4bf7f7e8'></a>

Actions within Postal Service control will improve long-term sustainability, but a gap will remain
<::chart: Line graph titled "Actions within Postal Service control will improve long-term sustainability, but a gap will remain" showing Net income in $ Billions over time.

Y-axis (Net income, $ Billions) ranges from -35 to 10, with major ticks at -35, -30, -25, -20, -15, -10, -5, 0, 5, 10.
X-axis shows years 2005, 2009, 2020.

The graph is divided into two sections by a dotted vertical line at 2009.

Left section (before 2009) is labeled "Actual". The net income line starts near 0 in 2005, dips to around -5, then rises slightly before dipping again towards -5 by 2009.

Right section (after 2009) is labeled "Forecast". The net income line continues to decline, showing increasing losses. The area under the forecast line is shaded, representing cumulative loss.

Text within the shaded forecast area indicates: "Cumulative loss 2010-2020 $115 billion".

Two callouts with arrows point to different levels of loss in the forecast period:
1. An arrow points to a level around -15 to -20 on the Y-axis, labeled "($15B)". Associated text reads: "Actions within the Postal Service control will reduce annual loss to $15 billion, cumulative loss to $115 billion".
2. Another arrow points to a lower level around -33 on the Y-axis, labeled "($33B)". Associated text reads: "Base case without product, service or productivity actions".
: figure::>

<a id='54019354-a91b-4eaf-8127-1345b9e5d87d'></a>

14

<a id='858885cd-28bb-4651-a20f-9a616941287b'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='131e9b78-11e9-45e4-9e85-3e7b0fe121b0'></a>

McKinsey examined an extensive range of options

<a id='614c072d-0800-48e2-a815-d1e11caa2597'></a>

50+ options considered

*   Aggressive internal cost improvement options across the organization
*   Products and services options from:
    *   Foreign posts (banking, logistics)
    *   Private sector firms
    *   Other government entities
    *   The Postal Service
*   Other product and service extensions from existing assets
*   Pricing actions
*   Privatization

<a id='88082b7e-4ac7-4de7-8a38-ede85ad6281a'></a>

Filtered on criteria

- Overall profit impact
- Impact on customers and mailers
- U.S. specific-industry dynamics
- Time and capital investment required
- Feasibility

<a id='e7649d7b-0960-442b-91e6-38961575405d'></a>

15

<a id='e1cde60c-aba7-4ecc-bb2f-f62c21560026'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='7ead5d50-475f-4bb2-aaf8-34d2381b239e'></a>

Privatization: An unlikely option for USPS

<a id='3474d0f6-623e-4a8a-b029-813ca638a836'></a>

<::A line chart with a y-axis labeled 20, 40, 60, 80, 100 and an x-axis labeled 1 through 12. Multiple colored lines plot data points. A magnifying glass is positioned over the upper right portion of the chart. A partial table of values is visible next to the chart, including 63,04, 52,30, 97,54, 87,45, 99,32, 90,59.: chart::> Investors require a clear path to profitability before acquisition. Changes USPS requires to become attractive to investors are more extensive than those required to ensure a viable government entity.

<a id='9ba962af-1a5e-437a-ad8f-6084b44da0e3'></a>

- The scale and associated risk further limit investor interest in the business

<a id='1a1f32bb-4f15-4d63-be84-159182406107'></a>

* Even after a privatization, U.S. Government would need to maintain implicit or explicit support for the Postal Service

<a id='53260945-c285-4efc-9f9f-3f041163f020'></a>

16

<a id='62176052-dad2-48d4-9f55-b5c44516cd86'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='bc5ddedd-763d-46c2-bf52-233796051244'></a>

Fundamental change: Options exist across five areas to address the remaining $15 billion gap

<a id='29b630fe-e7e9-42c9-86dd-93a7f5c2189b'></a>

<::An image on a dark blue background with a lighter blue oval shape in the bottom right. On the left, a white cardboard box with "PRIORITY MAIL" and a USPS logo. In the top right, a postage stamp featuring the American flag and "USA44". Text overlaid on the image reads: Products and services. Pricing. Remaining FY 2020 gap = $15 billion.: figure::>

<a id='5c8364e8-3440-499a-84e0-d3e9cf64fb80'></a>

<::A map of the United States is shown, filled with the pattern of the American flag (red and white stripes, blue field with white stars). The text "Service levels" is overlaid in white text on the upper right side of the map.
: figure::>

<a id='2a0cc051-e96b-4cb4-a8a4-ac3e7b744b5f'></a>

<::Text "Public policy considerations" overlaid on an image of the US Capitol Building at night, illuminated, with a dark blue background.
: image::>

<a id='20e32e96-a194-426c-9ea4-94f800853354'></a>

<::A photograph of a female postal worker in a blue uniform, holding mail and magazines, with an American flag displayed behind her. To the right, on a dark blue background, the word "Workforce" is displayed in white, bold text.
: photograph::>

<a id='384a26c6-15ea-4759-863e-90e2d2cb1bc1'></a>

17

<a id='ca753dba-a811-4622-b08d-2e9f1f37c3b6'></a>

<::McKinsey&Company
: figure::>

<!-- PAGE BREAK -->

<a id='c605efd5-658e-407f-970e-301baf487f5d'></a>

Fundamental change options:
Products and services

<a id='590d28a8-2cfd-4fb5-ac7d-7f4a483ade5f'></a>

Create new products and services
consistent with USPS mission

<a id='805a011a-b8e2-4711-9eb6-478ddf2c8a21'></a>

<::A conceptual graphic depicts a white laptop computer with a blue screen. On the screen, a stack of various mail items, including white envelopes and brown padded envelopes, is visible. A red mailbox flag extends from the top left corner of the laptop, suggesting mail delivery or integration. The text, "Develop a suite of hybrid mail products that integrate electronic and physical mail," is displayed alongside this graphic on a dark blue background, forming a cohesive visual element.
: figure::>

<a id='b126f3d9-37a0-4266-a8f6-0008fb963be8'></a>

<::
: advertisement::
[Image of a family in a home setting]

freshFX
Green Control & Prevention

914-232-4405
REMOVE & PREVENT
MOLD & INFECTIOUS GERMS
In Your Home or Business.

For Our Best Rates... Call 24/7 (Mold & Germs, Home & Auto), Licensed & Insured.

PROTECT
Basements, Kitchen/Counters,
Bathrooms, Garages, Sheds, Siding,
Roofs/Attics, Linear Rooms, Wooding,
Walls, Sports Equipment, Attics,
Shoes & Uniforms, Towels, Walls,
Clothing, Ducts & Vents.

- All Natural Products
- 99.9% Effective
- Certified Mold Professionals (IICRC)
- Safe for Kids, Non-Toxic
- Protects against future germs
- Fast & friendly application
- Fights against allergens, Common Cold,
  Colds, MRSA, H1N1, MERS & Measles, Mumps & Chickenpox

$150 off
Any Service
of $500 or More

Coupon:
FreshFX
914-232-4405
Valid only for new customers
who use coupon. Not valid with
other offers or prior sales.
Offer expires 12-31-19.

The first
PREVENTATIVE
MOLD & GERM SOLUTION
available

CALL NOW FOR WINTER PRICING

INTEX
Building Services
Environmental
FREE EVALUATION
Licensed & Insured - 24/7 Service

FreshFX services will organically clean
and disinfect critical areas of your home
AND belongings and PREVENT them
with a Safe & ALL NATURAL product.
Fresh, Germ-free, 99.9% of all germs will
die in less than 2 minutes.

Proudly owned & operated • www.freshFX.org
::>

<a id='37f3a47b-cb30-4eb4-bb0b-88394f81bfab'></a>

Simplify advertising products

<a id='132657ba-e145-4d74-ba48-ed994e322db3'></a>

18

<a id='c8ae1c83-a5d4-4534-8e6c-727bc2a633b5'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='ed01e05b-5843-415f-bab2-ecd20e689ba7'></a>

Fundamental change options: Pricing

<a id='55f52146-1b8c-4ee9-9fd9-9163a0a5f079'></a>

Modify price cap to apply across all market dominant products rather than by class

Apply exigent price increase

Increase prices on select products to cover costs:
* Periodicals
* Nonprofit mail
* Media and Library mail

<a id='cdd98f2c-9529-44c4-b469-6c1d41741852'></a>

19

<a id='edfdd7ad-c1aa-4d51-b055-73b8f3446f83'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='7a078e48-6d12-40c9-aba4-39bd4cdfa2f0'></a>

Fundamental change options: Service levels

<a id='0a9d5df0-9db0-458d-a7d6-695fea61d069'></a>

<::transcription of the content
: figure::>

Change service levels from 1-3 day
to 2-5 day delivery for First Class Mail

<a id='cc50f2f5-3fcd-450e-9029-2fcb4c4dba90'></a>

<::A mail carrier in a blue jacket is standing next to a white mail truck. The text next to the mail carrier reads: Reduce delivery frequency to 3 days or 5 days per week. Change delivery location to curb or cluster boxes.
: figure::>

<a id='4a520a93-1c1e-4c07-a453-db1150d6abb2'></a>

<::Screenshot of a website interface for "THE POSTAL STORE".

**Top Banner/Navigation:**
- Logo: "THE POSTAL STORE"
- Navigation links: Quick Order, My Account, FAQs, Stamps, For Mailing, Shipping, For Fun, For Collecting.

**Main Content Area:**
- Section Title: Shop our Sale >
- Large graphical banner: "p.s. I love You"
- Product 1: "Buy a Coil of 100 Stamps" - $44.00
- Product 2: "Stamps > First Class Stamps, Additional Postage, Coil of Stamps, Priority Mail" (with an image of Olympic-themed stamps, likely Vancouver 2010 Olympic Winter Games 38-80) - $8.30
- Button: View our Collection >
- Button: BUY >
: screenshot::>
Expand access through
alternative channels
■ Private sector retail partnerships
■ Kiosks
■ Direct (e.g., online, mobile)

<a id='f4ca4954-1aa6-4aef-b7b1-8bbbe952b726'></a>

20

<a id='1844ed11-83de-4880-bf5f-17458fac53fb'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='b28523ca-783d-429d-8ea9-12fc74bcd973'></a>

Fundamental change options: Workforce

<a id='02347059-63c4-45ed-8f8c-27bfc7c7f9df'></a>

<::A woman in a light-colored sleeveless top over a brown long-sleeved shirt is working in what appears to be a mail or package sorting facility. She is looking down, focused on handling a stack of white envelopes or flat packages on a conveyor belt or sorting table. To her left, there's an open cardboard box and other items on the table. In the background, there are automated sorting machines or conveyor systems with various packages and boxes, and shelves filled with bins or mail slots. The overall impression is of an industrial or postal work environment.: figure::>

<a id='69ee1a8d-ab1a-4485-af77-5558224ac95e'></a>

Improve workforce flexibility
by changing the employee mix and taking
advantage of over 300,000 voluntary
separations over the next 10 years

<a id='2cbf46ee-637a-48ab-b1c8-4a82f8791cb7'></a>

<::A 3D bar chart with red and white bars showing an increasing trend, overlaid with a green line graph also showing an upward trend. Faint numbers are visible in the background.: chart::>

<a id='9d4aadd5-00a9-4c3a-8693-23b2f10dca76'></a>

Align workforce costs with overall
market trends and inflation

<a id='2fd31917-0427-44a3-974f-571336c322c0'></a>

21

<a id='1561d2be-2498-4194-b8ad-11b671331b1c'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='a5a05e33-caa0-4f8e-8550-7a03cec531fb'></a>

Fundamental change: Public policy considerations

<a id='68492bd6-02f8-4558-b4cc-1ec9523d5b9f'></a>

Restructure RHB pre-funding

* Defer payments
* Shift to a "pay-as-you-go" system comparable to other federal agencies and private companies

<a id='5193ff95-fc1a-480a-9fe5-578648526145'></a>

<::Image of the US Capitol building at dusk, with its dome illuminated.: image::>Receive Universal Service Obligation subsidies through Federal appropriations

<a id='3f1704ca-3f69-45e0-8a77-22ef4b105002'></a>

<::An image of an eagle flying, set against a light blue sky, on the left. On the right, against a dark blue background with lighter blue diagonal stripes, is the text: "Streamline oversight model to improve flexibility and timeliness". The words "Streamline oversight model" are in yellow, and "to improve flexibility and timeliness" are in white.: figure::>

<a id='8dcf4507-0eca-4814-a8e6-6f7589835eba'></a>

22

<a id='29697e12-54b8-4806-b41f-c39a50b7db14'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='d8ef5bd3-db93-49f7-a4b1-9c17820cecf8'></a>

Closing perspective

<a id='8b7c104e-4ed1-4f90-9a2e-aac2e1bc4375'></a>

Even undertaking all opportunities within Postal Service
control, USPS is facing a cumulative $115 billion loss

<a id='3a8eaf6b-2704-4b03-b7e4-a1cce4d705e5'></a>

Actions in any one area will not be enough to close this gap

<a id='70fe7a0a-35d5-4359-9e69-2aa7b36387f2'></a>

Pursuing multiple actions can result in enhanced customer service and a financially viable operating model

<a id='fbe62bac-9b33-4335-a9f6-37f94765fb86'></a>

Legislative and regulatory changes are necessary and will require cooperation from multiple stakeholders

<a id='a7132161-e384-4d4b-93c2-3c12e52deed3'></a>

23

<a id='5cf627e5-359d-4ceb-ad30-ab5a959ec2c6'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='63fef7e8-fab0-4f8e-8498-e1a1711b2663'></a>

<::An image showing a storage area with stacks of blue plastic crates on the left side. On the right, there are tall stacks of white materials, possibly ballots or documents, with the words "UNITED STATES" printed repeatedly in black ink on their visible edges. The text "UNITED STATES" is visible multiple times on the stacked white items.: image::>

<a id='39c20e07-55ab-46cf-b17b-3872ff7ca967'></a>

Envisioning America's
Future Postal Service
Options for a Changing Environment

<a id='cd1c90a3-1f91-44f5-8c39-39b56d8a9581'></a>

March 2, 2010

<a id='89e6c7fd-5638-4d23-ba19-42be2f413f88'></a>

24

<a id='6f7dca85-6d26-4951-ba4e-9e6bab59386c'></a>

McKinsey&Company