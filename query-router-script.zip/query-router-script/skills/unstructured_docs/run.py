"""Unstructured documents skill. TODO: Replace stub."""


async def run(query: str, parameters: dict, upstream: dict) -> dict:
    return {
        "answer": f"[STUB] Document search for: {query}",
        "sources": [],
        "source": "unstructured_docs",
    }
