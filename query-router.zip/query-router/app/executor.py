"""Executor: runs an ExecutionPlan respecting dependencies.

Independent steps run concurrently via asyncio; dependent steps wait for
their upstream results and inject them as context.
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import sys
from typing import Any

from app.clients.structured import StructuredClient
from app.clients.unstructured import UnstructuredClient
from app.config import settings
from app.models import (
    DataSource,
    ExecutionPlan,
    PlanStep,
    StepResult,
    StepStatus,
)
from app.skill_registry import registry

logger = logging.getLogger(__name__)


class Executor:
    def __init__(self) -> None:
        self._structured = StructuredClient()
        self._unstructured = UnstructuredClient()

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    async def execute(self, plan: ExecutionPlan) -> list[StepResult]:
        """Execute all steps in *plan*, returning results in step_id order."""

        results: dict[int, StepResult] = {
            step.step_id: StepResult(step_id=step.step_id) for step in plan.steps
        }

        # Build adjacency: step_id → set of step_ids that depend on it
        dependents: dict[int, set[int]] = {s.step_id: set() for s in plan.steps}
        for step in plan.steps:
            for dep_id in step.depends_on:
                dependents[dep_id].add(step.step_id)

        # Track remaining in-degree
        in_degree = {s.step_id: len(s.depends_on) for s in plan.steps}
        step_map = {s.step_id: s for s in plan.steps}

        # Kick off with all zero-degree steps
        ready = asyncio.Queue()
        for sid, deg in in_degree.items():
            if deg == 0:
                await ready.put(sid)

        completed = 0
        total = len(plan.steps)

        async def worker() -> None:
            nonlocal completed
            while completed < total:
                try:
                    sid = await asyncio.wait_for(ready.get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                step = step_map[sid]
                result = results[sid]
                result.status = StepStatus.RUNNING

                # Gather upstream context
                upstream_ctx = self._build_upstream_context(step, results)

                try:
                    data = await self._run_step(step, upstream_ctx)
                    result.data = data
                    result.status = StepStatus.SUCCESS
                except Exception as exc:
                    logger.exception("Step %s failed", sid)
                    result.error = str(exc)
                    result.status = StepStatus.FAILED

                completed += 1

                # Unblock dependents
                for dep_sid in dependents.get(sid, set()):
                    in_degree[dep_sid] -= 1
                    if in_degree[dep_sid] == 0:
                        await ready.put(dep_sid)

        # Run workers (bounded parallelism)
        workers = [
            asyncio.create_task(worker())
            for _ in range(min(settings.max_parallel_steps, total))
        ]
        await asyncio.gather(*workers)

        return [results[s.step_id] for s in plan.steps]

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_upstream_context(
        self, step: PlanStep, results: dict[int, StepResult]
    ) -> dict[str, Any]:
        """Collect results from upstream steps for injection into the query."""
        ctx: dict[str, Any] = {}
        for dep_id in step.depends_on:
            dep_result = results[dep_id]
            ctx[f"step_{dep_id}_results"] = dep_result.data

        # Template replacement: replace {step_N_results} in the query
        if ctx:
            query = step.query
            for key, val in ctx.items():
                placeholder = "{" + key + "}"
                if placeholder in query:
                    query = query.replace(placeholder, json.dumps(val, default=str))
            step.query = query

        return ctx

    async def _run_step(self, step: PlanStep, upstream: dict[str, Any]) -> Any:
        """Dispatch a single step to the appropriate source."""
        match step.source:
            case DataSource.STRUCTURED:
                return await self._structured.query(step.query, context=upstream or None)

            case DataSource.UNSTRUCTURED:
                return await self._unstructured.query(step.query, context=upstream or None)

            case DataSource.SKILL:
                return await self._run_skill(step, upstream)

            case _:
                raise ValueError(f"Unknown source: {step.source}")

    async def _run_skill(self, step: PlanStep, upstream: dict[str, Any]) -> Any:
        """Execute a registered skill script.

        Convention: the skill folder must contain a `run.py` (or `run.sh`)
        that accepts JSON on stdin and writes JSON to stdout.
        """
        if not step.skill_name:
            raise ValueError("Skill step has no skill_name")

        manifest = registry.get(step.skill_name)
        if not manifest:
            raise ValueError(f"Skill not found: {step.skill_name}")

        # Merge parameters with upstream context
        payload = {**step.parameters, "query": step.query, "upstream": upstream}

        # Look for run.py or run.sh
        import pathlib

        folder = pathlib.Path(manifest.folder_path)
        runner = folder / "run.py"
        if not runner.exists():
            runner = folder / "run.sh"
        if not runner.exists():
            raise FileNotFoundError(
                f"No run.py or run.sh in skill folder: {folder}"
            )

        cmd = (
            [sys.executable, str(runner)]
            if runner.suffix == ".py"
            else ["bash", str(runner)]
        )

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate(input=json.dumps(payload).encode())

        if proc.returncode != 0:
            raise RuntimeError(
                f"Skill {step.skill_name} exited with {proc.returncode}: {stderr.decode()}"
            )

        raw = stdout.decode().strip()
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return raw  # return as plain text
