---
name: deal_comparison
description: Compares two or more deals side-by-side across key dimensions like valuation, timeline, structure, and risk factors
trigger: when user asks to compare deals, benchmark a deal, or wants a side-by-side analysis
parameters:
  - name: deal_ids
    type: list
    required: true
    description: List of deal identifiers to compare
  - name: dimensions
    type: list
    required: false
    default: null
    description: Specific dimensions to compare (e.g., valuation, structure, timeline, risk)
---

# Deal Comparison Skill

Produces a structured side-by-side comparison of multiple deals.

## Input

Receives JSON on stdin:
- `deal_ids` — list of deal IDs
- `dimensions` — optional filter on comparison axes
- `upstream` — pre-fetched deal data from earlier steps
- `query` — the original sub-question

## Output

Writes JSON to stdout:
```json
{
  "comparison_table": [...],
  "summary": "Deal A has a higher valuation but longer timeline...",
  "deals_analyzed": 2
}
```
