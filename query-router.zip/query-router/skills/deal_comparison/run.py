#!/usr/bin/env python3
"""Deal comparison skill runner. TODO: Replace with real logic."""

import json
import sys


def main() -> None:
    payload = json.load(sys.stdin)
    deal_ids = payload.get("parameters", {}).get("deal_ids", [])
    dimensions = payload.get("parameters", {}).get("dimensions") or [
        "valuation", "structure", "timeline", "risk"
    ]
    result = {
        "comparison_table": [
            {"deal_id": did, "dimensions": {d: "N/A" for d in dimensions}}
            for did in deal_ids
        ],
        "summary": f"Stub comparison of {len(deal_ids)} deals.",
        "deals_analyzed": len(deal_ids),
    }
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
