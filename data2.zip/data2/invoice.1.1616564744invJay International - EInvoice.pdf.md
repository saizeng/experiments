<a id='5d654249-75b5-423d-9703-658ae6a99bdb'></a>

# INVOICE
(Invoice Under Rules 46 of the GST Tax Rules, 2017)

e-Invoice
<::scan_code: QR code::>

<a id='86ff6968-4a16-4f28-91c0-cae74336b4b3'></a>

<::logo: [Unknown]  A red triangular outline encloses a stylized 'oc' symbol.::>

<a id='d0c646b5-7d6a-47e5-bb6b-925dbfaa8b6e'></a>

# ALPHA COOL PRODUCTS
104, The Grand Apurva, Nr. Hotel Fortune Palace, Nr. Digjam Circle, Aerodrome Road, Jamnagar GSTIN/UIN: 24AATCS7449H1ZQ
Phone: 0288-2713956/57/58 Email: kapil@aaplautomation.com
Website: www.tallytdl.com
GSTIN / UIN: 24AATCS7449H1ZQ , PAN No:

<a id='d9a703e8-687d-4bd5-b204-881c999db250'></a>

<::scan_code: QR code
This is a clear, high-quality QR code with no visible damage or obstruction.::>

<a id='f719e33e-31a6-4ffa-8330-fceaa337b58d'></a>

<table id="0-1">
<tr><td id="0-2">Ship To,</td><td id="0-3">Bill To,</td></tr>
<tr><td id="0-4">K.K.Brown Papers LLP</td><td id="0-5">Kishan Traders - Byavar (Ajmer)</td></tr>
<tr><td id="0-6">127/A,127/B, Devraj Industrial Park,</td><td id="0-7">7/107, W/O Mohandas Pamnani</td></tr>
<tr><td id="0-8">Piplaj Pirana Road.Nr. Ka mod Cokadi(Gay Grcle)</td><td id="0-9">Kishanganj In Front Of Prem Prakash Ashram</td></tr>
<tr><td id="0-a">Piplaj, Ahmedabad-382405</td><td id="0-b">Beawar Ajmer</td></tr>
<tr><td id="0-c">GSTIN/UIN: 24AAPFK3768E1Z4</td><td id="0-d">GSTIN/UIN : 08BIKPP7599E1ZI</td></tr>
<tr><td id="0-e">State : Gujarat</td><td id="0-f">Place of Supply: Rajasthan</td></tr>
<tr><td id="0-g">State Code : 24</td><td id="0-h">State Code : 08</td></tr>
<tr><td id="0-i">PAN No. : AAPFK3768E</td><td id="0-j">PAN No. : BIKPP7599E</td></tr>
</table>

<a id='664d0f60-a2af-451d-af9a-14dc44057dc7'></a>

<table id="0-k">
<tr><td id="0-l">Invoice No.</td><td id="0-m">: SCP/41590/20-21</td></tr>
<tr><td id="0-n">Date</td><td id="0-o">: 19-Feb-21</td></tr>
<tr><td id="0-p" colspan="2">Payment Terms : Advance</td></tr>
<tr><td id="0-q">Transport</td><td id="0-r">:</td></tr>
<tr><td id="0-s">LR No.</td><td id="0-t">: Local-Document</td></tr>
<tr><td id="0-u">Destination</td><td id="0-v">: Amreli</td></tr>
<tr><td id="0-w">No. of Article</td><td id="0-x">: 10</td></tr>
<tr><td id="0-y">E-Way Bill No.</td><td id="0-z">:691269365025</td></tr>
</table>

<a id='52b839a4-06c4-493f-a85a-af53929758eb'></a>

<table id="0-A">
<tr><td id="0-B">Sr No.</td><td id="0-C">Description of Goods</td><td id="0-D">PO No.</td><td id="0-E">PO Date</td><td id="0-F">HSN</td><td id="0-G">Qty.</td><td id="0-H">Price</td><td id="0-I">Unit</td><td id="0-J">Amount</td></tr>
<tr><td id="0-K">1</td><td id="0-L">Moon Chips - 1X10X9=90 - 5/-</td><td id="0-M">SCPI Odent170820-21</td><td id="0-N">19-Feb-21</td><td id="0-O">1905</td><td id="0-P">5</td><td id="0-Q">321.429</td><td id="0-R">BOX</td><td id="0-S">1,374.109</td></tr>
<tr><td id="0-T">2</td><td id="0-U">Tomato Moon Chips 1X10X9=90 - 5/-</td><td id="0-V">SCPI Odent170820-21</td><td id="0-W">19-Feb-21</td><td id="0-X">1905</td><td id="0-Y">50</td><td id="0-Z">321.429</td><td id="0-10">BOX</td><td id="0-11">13,741.090</td></tr>
<tr><td id="0-12">3</td><td id="0-13">Ring - 1X10X9=90-5/-</td><td id="0-14">SCPI Odert1710120-21</td><td id="0-15">19-Feb-21</td><td id="0-16">1905</td><td id="0-17">5</td><td id="0-18">321.429</td><td id="0-19">BOX</td><td id="0-1a">1,374.109</td></tr>
<tr><td id="0-1b">4</td><td id="0-1c">Pasta - 1X10X9-90-5/-</td><td id="0-1d">SCOPI Odern170820-21</td><td id="0-1e">19-Feb-21</td><td id="0-1f">1905</td><td id="0-1g">20</td><td id="0-1h">321.429</td><td id="0-1i">BOX</td><td id="0-1j">5,496.436</td></tr>
<tr><td id="0-1k">5</td><td id="0-1l">MiX Fryums - 1X10X9=90 - 5/-</td><td id="0-1m">SCP Oder170821-21</td><td id="0-1n">19Feb-21</td><td id="0-1o">1905</td><td id="0-1p">20</td><td id="0-1q">321.429</td><td id="0-1r">BOX</td><td id="0-1s">5,496.436</td></tr>
<tr><td id="0-1t">6</td><td id="0-1u">Pop Corn - 1X10X9=90-5/-</td><td id="0-1v">SCP. Odett 70821-21</td><td id="0-1w">19Feb-21</td><td id="0-1x">1905</td><td id="0-1y">80</td><td id="0-1z">321.429</td><td id="0-1A">BOX</td><td id="0-1B">21,985.744</td></tr>
<tr><td id="0-1C">7</td><td id="0-1D">Sabudana - 1X10X12=120-5/-</td><td id="0-1E">SCP Oder170820-21</td><td id="0-1F">19-Feb-21</td><td id="0-1G">1905</td><td id="0-1H">5</td><td id="0-1I">428.571</td><td id="0-1J">BOX</td><td id="0-1K">1,832.141</td></tr>
<tr><td id="0-1L">8</td><td id="0-1M">FF Papad - 1X10X9=90-5/-</td><td id="0-1N">SCP Oder170820-27</td><td id="0-1O">19-Feb-21</td><td id="0-1P">1905</td><td id="0-1Q">10</td><td id="0-1R">321.429</td><td id="0-1S">BOX</td><td id="0-1T">2,748.218</td></tr>
<tr><td id="0-1U">9</td><td id="0-1V">Aeroplane - 1X10X9=90 - 5/-</td><td id="0-1W">SCPI Order170820-21</td><td id="0-1X">19-Feb-21</td><td id="0-1Y">1905</td><td id="0-1Z">5</td><td id="0-20">321.429</td><td id="0-21">BOX</td><td id="0-22">1,374.109</td></tr>
<tr><td id="0-23">10</td><td id="0-24">Khichu Papad - 1X10X9=90 - 5/-</td><td id="0-25">SCPI Order 1770820-21</td><td id="0-26">19 Feb-21</td><td id="0-27">1905</td><td id="0-28">15</td><td id="0-29">321.429</td><td id="0-2a">BOX</td><td id="0-2b">4.122.327</td></tr>
<tr><td id="0-2c">11</td><td id="0-2d">Noodles - 1X10X9=90 - 5/-</td><td id="0-2e">SCPI Order 1770820-21</td><td id="0-2f">19 Feb-21</td><td id="0-2g">1905</td><td id="0-2h">400</td><td id="0-2i">321.429</td><td id="0-2j">BOX</td><td id="0-2k">1,09928.7 18</td></tr>
<tr><td id="0-2l">12</td><td id="0-2m">Soya Stick -1X10X20=200 - 5/-</td><td id="0-2n">SCPI Order 1770820-21</td><td id="0-2o">19 Feb-21</td><td id="0-2p">21069099</td><td id="0-2q">1</td><td id="0-2r">714.286</td><td id="0-2s">BOX</td><td id="0-2t">610.715</td></tr>
<tr><td id="0-2u"></td><td id="0-2v">Total</td><td id="0-2w"></td><td id="0-2x"></td><td id="0-2y"></td><td id="0-2z">616</td><td id="0-2A"></td><td id="0-2B"></td><td id="0-2C">Rs. 1,70,084.152</td></tr>
</table>

<a id='37525648-d9a9-4fd7-ac91-3ced9bac57c5'></a>

(Amount in Words): INR One Lakh Ninety Thousand Six Hundred Thirty Seven Only

IRN: 327e005302bf9eff0ef0ce498ef084db2ac662fdf61a25168-84a32b62578634b

Ack No.: 162110382095909 Ack Date: 19-Feb-21

Insurance Company Name:

Insurance Number :

<a id='9ed8e681-062f-42f8-bbc5-330e2541a09f'></a>

<table id="0-2D">
<tr><td id="0-2E">IGST</td><td id="0-2F">20,410.097</td></tr>
<tr><td id="0-2G">TCS On Sales</td><td id="0-2H">143.000</td></tr>
<tr><td id="0-2I">Round Off</td><td id="0-2J">(-)0.249</td></tr>
<tr><td id="0-2K"></td><td id="0-2L"></td></tr>
<tr><td id="0-2M">GRAND TOTAL</td><td id="0-2N">Rs. 1,90,637.000</td></tr>
</table>

<a id='6d328ebb-c496-4288-8634-9ffbd506248c'></a>

<table id="0-2O">
<tr><td id="0-2P" colspan="5"></td></tr>
<tr><td id="0-2Q" rowspan="2">HSN/SAC</td><td id="0-2R" rowspan="2">Taxable Value</td><td id="0-2S" colspan="2">Integrated Tax</td><td id="0-2T" rowspan="2">Total Tax Amount</td></tr>
<tr><td id="0-2U">Rate</td><td id="0-2V">Amount</td></tr>
<tr><td id="0-2W">1905</td><td id="0-2X">1,69,473.437</td><td id="0-2Y">12%</td><td id="0-2Z">20,336.81</td><td id="0-30">20,336.811</td></tr>
<tr><td id="0-31">21069099</td><td id="0-32">610.715</td><td id="0-33">12%</td><td id="0-34">73.286</td><td id="0-35">73.286</td></tr>
<tr><td id="0-36">Total</td><td id="0-37">1,70,84152</td><td id="0-38"></td><td id="0-39">20,410.097</td><td id="0-3a">20,410,097</td></tr>
</table>

<a id='56520fdc-c97b-40f7-9e7e-ff987a0a6655'></a>

<table id="0-3b">
<tr><td id="0-3c" colspan="2">Tax Amount (in words) : INR Twenty Thousand Four Hundred Ten and Ninety Seven paise Only</td></tr>
<tr><td id="0-3d">We declare that this invoice shows the actual price of the goods described and that all particulars are true and correct.</td><td id="0-3e">For, ALPHA COOL PRODUCTS Authorised Signatory</td></tr>
</table>