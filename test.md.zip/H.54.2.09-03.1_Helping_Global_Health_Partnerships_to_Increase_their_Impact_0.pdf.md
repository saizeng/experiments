<a id='ec674a82-7db9-4bdd-b404-7b54de1421e1'></a>

Helping Global Health
Partnerships to increase their
impact: Stop TB Partnership –
McKinsey collaboration

<a id='55c5127c-6b9b-4af2-8fff-677a15f31062'></a>

Pre-reading for Coordinating Board presentation
Thursday, Nov 5, 2009

<a id='65b7e32e-790e-44e3-a167-36b493eee7e9'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='6397eeb3-1ca6-4ad6-8a80-fe923d1a4a2a'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='e7f27074-d0f1-4bd5-a75d-0d4226ef48d6'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 1

<!-- PAGE BREAK -->

<a id='40be04cf-f363-4d72-907f-220ddc64ae02'></a>

Background to this work: The performance of Global Health Partnerships (GHPs) is increasingly important and scrutinized, yet achieving high performance is proving challenging

<a id='bfbdc342-2db0-457d-993f-cfcdeb3e509f'></a>

## Increasing role of GHP performance

*   GHPs play a major role in global health
*   Performance of GHPs can have huge impact on health of world's population
*   The focus on performance is increasing, driven by
    *   Increasing donor focus on impact, effectiveness, and efficiency
    *   Increasing number of Partnerships in global health
    *   Likelihood of lower funding growth or less funding, given financial crisis

<a id='1a319222-4b1e-4db0-a248-28c5adf4bca0'></a>

## Challenging factors

Complex environment and nature of GHP organizations create challenges, e.g.

*   **Objective-setting:** distinguishing between change GHP hopes to bring about in the world vs. the goals it sets itself that will help bring about the change
*   **Accountability:** ensuring accountability and delivery in the context of loose Partnership structures, voluntary membership, and limited hierarchy
*   **Capabilities:** gaining the capacity and capabilities needed to continuously improve their performance

<a id='45ade363-261c-48c5-bc69-2cde7dcc79a9'></a>

McKinsey & Company | 2

<!-- PAGE BREAK -->

<a id='e5f7bb62-3b28-4b0b-8911-d4f5999dce8a'></a>

Project goals, approach, and end-products: The project will deliver practical insights on improving the performance of GHPs based on piloted improvement ideas

<a id='6fb283bf-92d7-46cf-a3f7-1caaca364726'></a>

## Goals

*   Develop a joint perspective, tested and proven, on how GHPs can improve performance, by
    *   Exploring how to improve performance in a GHP, not simply to adopt existing (e.g. private sector) approaches
    *   Testing new ways of working with STB bodies that could lead to higher performance
    *   Develop a joint perspective to share with global health community

<a id='b8bb016d-1713-47e8-afbf-232e4c458451'></a>

# Approach
- Build on strengths and improvement opportunities outlined in 2008 evaluation
- Joint working, collaborative, co-creation. Not client-consultant work
- Duration: ~22 weeks: 10 weeks (diagnosis and design), 12 weeks (delivery)
- Scope: 5 Partnership bodies: GDF, MDR-TB WG, CFCS, Advocacy and CB&M teams
- External interactions with other GHPs, e.g., RBM, UNAIDS, GAVI, GF

<a id='fab25efc-140c-4744-a559-bd4b34f60edc'></a>

3 main end-products

* Successful performance **improvement pilots** in selected Partnership bodies, with accompanying documentation to support roll-out to other bodies
* A **co-authored project report**, suitable for publication in major journals, detailing the experience, including impact of the work and lessons for other GHPs
* A "**practitioners guide**" to support McKinsey teams conducting similar work

<a id='51485a82-9ff5-4476-aeef-94a4cf639c1f'></a>

McKinsey & Company | 3

<!-- PAGE BREAK -->

<a id='2574e843-7cdf-4902-9b73-23383933fdf3'></a>

Project approach: This project is organized in 3 distinct phases

<a id='c54764ef-7ac3-49bc-a095-52fbe43893b0'></a>

Today
<table id="4-1">
<tr><td id="4-2">Diagnose August - September</td><td id="4-3">Design September - October</td><td id="4-4">Deliver November - December</td></tr>
<tr><td id="4-5">Selection of Partnership Bodies to work with</td><td id="4-6" rowspan="2">Intensive work within selected Partnership Bodies to</td><td id="4-7">Implementation and refinement</td></tr>
<tr><td id="4-8">GDF</td><td id="4-9" rowspan="3">▪ Problem-solving sessions on findings, lessons learned, and implications</td></tr>
<tr><td id="4-a">Advocacy</td><td id="4-b" rowspan="6">— Develop improvement ideas on selected performance issue — Select actions to implement in next phase ▪ Development of implementation plans for Delivery phase</td></tr>
<tr><td id="4-c">Communication,</td></tr>
<tr><td id="4-d">Marketing and Branding – CFCS</td><td id="4-e" rowspan="3">Workshop to share achievements across Partnership Report and publication of results</td></tr>
<tr><td id="4-f">– MDR-TB Working Group</td></tr>
<tr><td id="4-g" rowspan="3">▪ Understanding of current performance ▪ Identification of areas of high performance</td></tr>
<tr><td id="4-h" rowspan="3">■ Presentation of results to Coordinating Board in March 2010</td></tr>
<tr><td id="4-i" rowspan="2">■ Information update to Coordinating Board in Nov 2009</td></tr>
<tr><td id="4-j">■ Selection of one performance issue to improve</td></tr>
</table>

<a id='73fdf90f-fbd7-473a-b034-c9117306f675'></a>

McKinsey & Company | 4

<!-- PAGE BREAK -->

<a id='b5df1c14-d1ab-4e5e-913c-1587e135ba18'></a>

Project deliverables for December 2009

<a id='657b60ca-2090-44ca-92e3-c6e250d8d6a2'></a>

<table id="5-1">
<tr><td id="5-2">End-products</td><td id="5-3">Description</td></tr>
<tr><td id="5-4">Improvement pilots</td><td id="5-5">Each participating Partnership body conducting improvement project, focusing on one relevant area, e.g. Definition of objectives/goals Development of scorecards Improvement of processes Activation of relevant &#x27;enablers&#x27;, e.g., mindsets and capabilities Pilot progress showcase/workshop (mid-December) Development of accompanying &quot;pilot playbook&quot; (how-to guide for Partnership bodies)</td></tr>
<tr><td id="5-6">Project report</td><td id="5-7">A detailed project description, including Problem definition and why it matters Why it is and remains a problem Case account of Stop TB Partnership (what it&#x27;s doing well; what can be improved) Perspective from other GPH organizations (How &quot;typical&quot; is this?) Improvement projects launched and early findings Lessons, insights, conclusions</td></tr>
<tr><td id="5-8">Practitioners Guide</td><td id="5-9">Detailed account of work conducted to improve performance management for use by consultant teams in and beyond social sector</td></tr>
</table>

<a id='09941c33-f1b6-4b33-90f3-6d0b4c046003'></a>

McKinsey & Company | 5

<!-- PAGE BREAK -->

<a id='95755b75-6622-4432-9889-fa97a0044f8a'></a>

Framework: We think about performance in terms of both processes and enablers –(1) Processes

<a id='15f5488c-8a9d-470a-ae2b-152839bb0206'></a>

<::Performance management flowchart::>Central Theme: Performance management.1. Set objectives:- Set time-bound **objectives** that contribute to fulfilling **mission** and **vision**2. Establish clear metrics:- Set **metrics** that directly measure agreed objectives- Set additional metrics that cascade down from key metric3. Set targets:- Set **quantitative targets** for the metrics- Translate these into **operational plans** and **budgets**4. Track and disseminate metrics:- Produce **progress reports**- Disseminate report to team members and stakeholders at pre-aligned intervals5. Review performance:- Use report to discuss progress in structured **review meetings**- Identify possible performance gaps and decide how to address them6. Celebrate achievements and take further action:- Celebrate successes- Take any required **corrective actions**<::

<a id='3f14bbed-51b0-4f11-a7d2-f0023b73d4bc'></a>

McKinsey & Company | 6

<!-- PAGE BREAK -->

<a id='28dc6f33-5ac3-49b7-9f25-7eeacb0f6db8'></a>

Framework (backup): Definition of performance management terms

<a id='0b547329-66b1-4085-9f68-b3ee50c54538'></a>

Vision

### Definition/description
- Articulates the aspiration or target for the future
- Describes core ideology, which may include "timeless" guiding principles and purpose

### Example
- A TB-free world

---


<a id='762e64e0-9980-4741-b937-36a0ec3ce51b'></a>

## Mission

*   Defines the organization's purpose and primary objectives
*   Supply low-cost, quality drugs to countries that need them

<a id='e8374880-fe80-4522-8b03-94dee2d4c63c'></a>

Objective
---
- Narrow, time-bound, quantifiable goal that
  contributes to delivering the mission
- Supply low cost, quality TB drugs at
  USD 20/treatment course for X
  number of patients in 2010

<a id='9d74fa58-3aa3-446c-8ae0-ae5bad76bab3'></a>

Metric

- Measurable variable that indicates progress
towards objective

---

- E.g., funds raised, number of patient
treatments supplied, number of grants
and treatments approved

<a id='ead97699-5ed4-4712-b49c-1d2f91d7c354'></a>

Target

*   The target value of the metric chosen
*   E.g., 15 million patient treatments supplied by 2010

<a id='4a679dcd-7519-4171-9852-4d098eaf5cad'></a>

Report

* Set of metrics and current values vs. target
* Explanation of reasons for current performance and how to get to targets
* See pages 22, 23 in this document for examples

<a id='a26ea3c7-5ae0-42ec-ab80-df6384f77210'></a>

Performance review

---

* A sequence of meetings conducted to
  * Review performance
  * Understand root causes of performance gaps
  * Decide how to address them
  * Agree appropriate actions

<a id='60b3a3b8-d86b-405b-984a-31e5d13a3d80'></a>

McKinsey & Company | 7

<!-- PAGE BREAK -->

<a id='31f3e69d-d1aa-4ce1-bb7c-30f06bc19bec'></a>

Framework: We think about performance in terms of both processes and enablers –(2) Enablers

<a id='1c2d3d6a-c4b3-4cfc-aa2c-e6131aaf16e2'></a>

<::Diagram: This diagram illustrates a model centered around "Committed leadership". It shows three main interconnected components surrounding the central concept: Culture, Communications, and Capacity. Each component is further elaborated with text and an accompanying image. There is also an additional text box directly connected to "Committed leadership".

- **Central Element:**
  - **Committed leadership**

- **Surrounding Components:**
  - **Culture:**
    - Text: Developed shared cultural norms for performance (e.g., accountability, behaviors)
    - Image: Four cartoon figures, three men and one woman, sitting around a round table, engaged in a discussion.
  - **Communications:**
    - Text: Communicate both performance and the importance of discussing performance regularly to all stakeholders
    - Image: A cartoon woman with dark hair and glasses, wearing a light blue jacket and dark skirt, speaking into a microphone at a light brown podium.
  - **Capacity:**
    - Text: Ensure sufficient skills, infrastructure, and resources for performance
    - Image: A cartoon figure, wearing a colorful patterned shirt and dark pants, unrolling a large yellow scroll that has 

<a id='6bc1a2ee-ee24-445c-8e33-83ff0cd70e80'></a>

McKinsey & Company | 8

<!-- PAGE BREAK -->

<a id='d7729d7f-c0d2-4485-a2d4-27859b2dba96'></a>

Challenges (1): Many Global Health Partnerships find some performance processes challenging given their complex environment and structure

*   Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities
*   Aligning divergent partner views on which objectives to pursue
*   Setting advocacy objectives that stay current and relevant in changing external circumstances
*   Finding and making visible tactical advocacy opportunities for partners to act on

<::Performance management processes flowchart:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements and take further action
: flowchart::>

*   Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB
*   Aligning organization structures with performance drivers and metrics to enable clear accountability

*   Committing to targets is sometimes difficult because
    *   (a) some targets are not entirely deliverable by partnership
    *   (b) voluntary nature of partnerships
    *   (c) consequences of not meeting targets (e.g., on future funding)

Committing to specific corrective actions, given loose and voluntary nature of partnership

Getting good performance data because of in-country data gathering limitations

Holding regular, trust-based performance conversations

<a id='221ee10d-d7ce-4369-bdfa-8948cf92d843'></a>

SOURCE: Interviews with Stop TB Partnership, Global Alliance for Vaccines and Immunization, UNAIDS McKinsey & Company | 9

<!-- PAGE BREAK -->

<a id='f099db7d-c991-4606-97bf-87add036befc'></a>

Challenges (2): Many GHPs also struggle with the right enablers

<a id='5084b395-14a6-45a5-ac5d-26b5fd5464b5'></a>

<::Committed leadership diagram::>Committed leadership is at the center of a larger circle divided into three sections: Culture, Capacity, and Communications.  Each section has a descriptive callout box.  
- **Callout 1 (connected to Culture):** Getting from a culture of performance measurement (e.g., extensive reporting) to performance management (including open discussion of performance outcomes)
- **Callout 2 (connected to Communications):** Ensuring that leaders regularly lead and participate in performance reviews, in spite of many other calls on their time
- **Callout 3 (connected to Capacity):** Allocating appropriate resources to performance management given limited resources for internal processes
- **Callout 4 (connected to Committed leadership, top left):** Establishing a shared understanding of accountability across the different backgrounds of partners. Ensuring partners within a loose working group arrangement are engaged and motivated to contribute
- **Callout 5 (connected to Committed leadership, bottom left):** Defining specific and ambitious goals given culture of consensus-building that tends towards more inclusive, yet abstract objectives<::

<a id='20c8131c-3f4a-4ef8-95af-d185f696f504'></a>

McKinsey & Company | 10

<!-- PAGE BREAK -->

<a id='206b794b-ca46-48cc-b090-f0ee4a522ec8'></a>

Diagnostic phase findings (1): The Stop TB Partnership displays a number of strengths across performance processes

<a id='47eaf4e2-c141-4ae5-9b48-03ca69fe9150'></a>

Examples

*   **Setting objectives** – GDF objectives are clearly defined and distinguish "the change the GDF hopes to bring about in the world" (e.g., Millennium Development Goals – 70% TB cases diagnosed, 85% cure rate) from the internal goals it sets itself that will enable this change
*   **Establishing clear metrics and setting targets** – MDR-TB Working Group defines concrete metrics (e.g., number of patients with access to MDR-TB treatment; research projects launched for evaluation of diagnostic algorithms) and sets specific targets for these metrics (e.g. for 2009, 200000 patients, 4 projects)
*   **Tracking and disseminating metrics** – Despite limited resources for performance management, GDF manages to track and report on a wide variety of metrics to meet the different demands of donors
*   **Reviewing performance** – In response to donor demands, the Advocacy Team conducts an in-depth review of performance against objectives stated in funding proposal so as to take stock of results achieved and lessons learned

<a id='07db9dc3-b35e-4117-bd28-769a4d00c65b'></a>

McKinsey & Company | 11

<!-- PAGE BREAK -->

<a id='e7684976-75a8-4ef9-9ec8-e0276283f7db'></a>

Diagnostic phase findings (2): The Stop TB Partnership also displays a number of strengths across the enablers of performance

<a id='e56bcf8c-8f22-458e-8f93-167f80c69d91'></a>

# Examples

- **Committed leadership**
  - GDF leaders driving performance improvement initiatives
  - Secretariat leaders setting ambitious performance targets for teams
  - Coordinating Board members supporting focus on performance

- **Culture** – GDF has created a culture of performance with a focus on continuous improvement and quality management. The team is actively eliciting feedback on performance, e.g., through the Business Advisory Committee

- **Communication** – The Advocacy Team engages in ongoing communication across the Secretariat as well as with key partners such as the Stop TB department at WHO and the TB-HIV Working Group. Thereby, performance objectives are well known among relevant stakeholders

- **Capacity** – The Communications, Marketing and Branding Team makes efficient use of pro bono resources volunteered by partners. These resources are used to deliver some of the team's activities (e.g., production and distribution of public service announcements) as well as to assess performance against specific metrics (e.g., data received from partner on number of viewers)

<a id='1c7be8db-a110-4f4e-afcd-527ed751c25e'></a>

McKinsey & Company | 12

<!-- PAGE BREAK -->

<a id='44236f21-44ff-488a-9b1a-3649bafb5adb'></a>

Diagnostic phase findings (3): Brief overview of performance issues we have jointly agreed to address in Design and Deliver phases (more detail in following sections)

<a id='fa43d9fa-f4a0-4ec8-89cb-e74f7be59cc2'></a>

<::GDF
Advocacy
Communication, Marketing and Branding
Challenge Facility for Civil Society
MDR-TB Working Group
: flowchart::>

<a id='7cc5561e-f85d-429e-ba0a-153cd39b220b'></a>

<table id="13-1">
<tr><td id="13-2">Central Global Health Partnership performance issue</td><td id="13-3">Specific question addressed with Partnership body</td></tr>
<tr><td id="13-4">Agreeing the right metrics for objectives that are difficult to measure</td><td id="13-5">GDF tracks 250 metrics but Not all are related to GDF Some overlap Metrics are not organized systematically/hierarchically</td></tr>
<tr><td id="13-6">Setting advocacy objectives that stay current and relevant in changing external circumstances</td><td id="13-7">Setting advocacy objectives within Stop TB Partnership that stay current and relevant in changing external circumstances</td></tr>
<tr><td id="13-8">Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB</td><td id="13-9">Determining detailed objectives for each audience group that the Communications, marketing and branding team seeks to address Define metrics for each detailed objective</td></tr>
<tr><td id="13-a">Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities</td><td id="13-b">Refine the mission based on experience and lessons learned in the first two years of the CFCS program Articulate specific objectives around the newly refined mission statement</td></tr>
<tr><td id="13-c">• Ensuring partners within a loose working group arrangement are engaged and motivated to contribute</td><td id="13-d">• Developing a simple survey-based tool to assess the level of working group engagement</td></tr>
</table>
McKinsey & Company | 13

<a id='86c3d614-872e-4cd3-8367-939718651f05'></a>

13

<!-- PAGE BREAK -->

<a id='4504b0ac-a4da-4383-94ab-54ad31c0828e'></a>

Contents

- Project overview
- Global Drug Facility
- Advocacy
- Communication, Marketing and Branding
- Challenge Facility for Civil Society
- MDR-TB Working Group
- Next steps

McKinsey & Company | 14

<!-- PAGE BREAK -->

<a id='a5dacd03-081b-4ca7-b0a5-2838a462a4a3'></a>

GDF issues and opportunities

<a id='752ca046-a1bb-4581-8892-7e43b0634611'></a>

GHP performance issue
② Agreeing the right metrics for objectives that are
difficult to measure
② Aligning organization structures with performance
drivers and metrics to enable clear accountability
④ Getting good performance data because of in-
country data gathering limitations
⑤ Holding regular, trust-based performance
conversations

<::
Left visual:
A circular diagram with three segments. One segment is filled in dark blue and labeled "Capacity". The other two segments are light blue and are not labeled.

Right visual:
A cyclical diagram illustrating "Performance management" with 6 steps:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements/take further action
: diagram::>

GDF performance improvement
opportunity
② GDF tracks 250 metrics but
– Not all are related to GDF
– Some overlap
– Metrics are not organized
systematically/hierarchically
② Limited clarity on accountability for data
collection/performance against each KPI
② Difficult to assess GDF's performance against
its objectives
④ Limited resources (personnel and time) to
gather data and prepare reports for internal use
⑤ Limited time available for performance
discussions 

<a id='e4fe07c9-fc5a-4d13-9b57-5ba68fbefbbc'></a>

McKinsey & Company | 15

<!-- PAGE BREAK -->

<a id='b420970f-6543-4960-9317-6f6f251e0881'></a>

While most of the 250 metrics were relevant and helpful to GDF,
data collection and reporting was onerous

"All together we
report on over 200
KPIs that cover
our numerous
external reporting
requirements"

"Most individual
KPIs are relevant
and helpful"

"KPIs are specific
and measurable"
<::
| | Source | KPI name |
| :--- | :--- | :--- |
| 1 | GDF KPI list | | 
| 208 | UNITAID MDR-TB Plan 2008-2011 | Number of treatments provided |
| 209 | UNITAID MDR-TB Plan 2008-2011 | Potential global saving on total actual treatments |
| 210 | UNITAID MDR-TB Plan 2008-2011 | Potential global saving on total treatments needed |
| 211 | UNITAID MDR-TB Plan 2008-2011 | Price decrease |
| 212 | UNITAID MDR-TB Plan 2008-2011 | Procurement fee ratio |
| 213 | UNITAID MDR-TB Plan 2008-2011 | Product availability - High quality 2nd line |
| 214 | UNITAID MDR-TB Plan 2008-2011 | Product availability - Prequalified 2nd line |
| 215 | UNITAID MDR-TB Plan 2008-2011 | Product dispatch performance |
| 216 | UNITAID MDR-TB Plan 2008-2011 | Product price fluctuation buffer |
| 217 | UNITAID MDR-TB Plan 2008-2011 | Product registration - High quality 2nd line |
| 218 | UNITAID MDR-TB Plan 2008-2011 | Product registration - Pre-qualified 2nd line |
| 219 | UNITAID MDR-TB Plan 2008-2011 | Product shipping performance |
| 220 | UNITAID MDR-TB Plan 2008-2011 | Stockpile loss management cost |
| 221 | UNITAID MDR-TB Plan 2008-2011 | Stockpile Management overhead cost |
| 222 | UNITAID MDR-TB Plan 2008-2011 | Stockpile storage cost |
| 223 | UNITAID MDR-TB Plan 2008-2011 | Total appropriate products in market |
| 224 | UNITAID MDR-TB Plan 2008-2011 | Treatment cost |
| 225 | UNITAID MDR-TB Plan 2008-2011 | Treatment need |
| 226 | UNITAID MDR-TB Progress report 2007 | Patients able to start or continue treatment for MDR-TB with drugs delivered (all orders) |
| 227 | UNITAID MDR-TB Progress report 2007 | Patients able to start or continue treatment for MDR-TB with drugs delivered (Global Fund orders) |
| 228 | UNITAID Paediatric Report 2007 | Average number of days for manufacturing |
| 229 | UNITAID Paediatric Report 2007 | Average total cost of a delivered request |
| 230 | UNITAID Paediatric Report 2007 | Spending on procurement fees as a percent of total order costs (all orders) |
| 231 | UNITAID Paediatric Report 2007 | Spending on products as a percent of total order costs (all orders) |
| 232 | UNITAID Paediatric Report 2007 | Spending on shipping, insurance and quality control as percent of total order costs (all orders) |
| 233 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Average lead time for delivery of drugs per country |
| 234 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Average percentage of time that Paediatric TB drugs used in the most common treatment regimens are not available in TRC approved countries |
| 235 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Country applications reviewed and approved by TRC |
| 236 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | GDF key products price secured in 2010 compared to baseline prices |
| 237 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | GDF secured cost per patient treatment in 2010 compared to baseline cost |
| 238 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | GDF secured price of each paediatric TB drug compared with lowest price available from non-GDF manufacturers/mechanisms using same quality standards |
| 239 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Increase in the number of LTAs signed with manufacturers for supply of paediatric TB treatments |
| 240 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Increase in the number of manufacturers for paediatric TB products currently listed in the GDF catalogue |
| 241 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Increase in the number of manufacturers of new paediatric TB products |
| 242 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Number of paediatric TB drugs either prequalified or with complete dossiers submitted to the WHO prequalification programme for the duration of the project |
| 243 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Number of pre-qualified optimal paediatric TB drug formulations available each year for the duration of the project |
| 244 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Paediatric treatments supplied to each beneficiary country reported semi-annually |
| 245 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Per cent of orders (per product) placed through pooled procurement |
| 246 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Per cent of orders placed for beneficiary countries annually within the timeline recommended by TRC |
| 247 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Per cent of paediatric patients completing treatment in a 6 month period |
| 248 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Per cent of total budget allocated to LIC, LMIC, UMIC |
| 249 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Per cent of treatments ordered by countries that match the number of treatments budgeted for in the project agreement |
| 250 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Proportion of paediatric TB cases reported out of total TB cases reported by a country |
| 251 | UNITAID Paediatric Reporting Template (2006 Q4 and 2010) | Total number of patient treatments approved by the TRC for each country include an additional 20% of each treatment to be held as buffer stock |

Sheet tabs: Pivot T | KPI list | Unclassified KPI | Sheet3
::table>
"It takes too much
time to collect the
information and to
adapt it to our
200+ KPIs"

"It is difficult to
define metrics for
some areas so we
have KPI gaps"

"Some of our KPIs
overlap so it is
unclear what we
are optimizing for"

"Since the hierar-
chy of KPIs is not
clear, it is hard to
prioritize"

<a id='beda93dd-3fac-44ab-a8f5-6e695b2b873a'></a>

SOURCE: Interviews                                                                 McKinsey & Company | 16

<!-- PAGE BREAK -->

<a id='594dcb0e-d24a-404c-91a4-d0a482ef4d98'></a>

The team followed an 8 step process to create streamlined and structured KPIs, dashboards, and review meetings <::The visual is a complex diagram illustrating an 8-step process for performance management, with a central cycle and surrounding detailed actions. The central cycle is labeled "Performance management" and consists of six steps:
1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements/take further action

Around this central cycle, there are eight detailed steps (a-h), each with a small illustrative image:
a. Collate all GDF metrics reported on in one database: sum: ~ 250 (Image: a spreadsheet view)
b. Agree on GDF objectives and cluster metrics/KPIs to objectives (Image: sticky notes on a board)
c. Develop detailed KPI tree for each objective (Image: a hierarchical diagram)
d. Streamline detailed trees, excluding activity-related or non-GDF-owned KPIs (Image: a modified hierarchical diagram)
e. Assign owners to, and define review frequency of each KPI (Image: a table with KPI, owner, frequency columns)
f. Develop clear cascade of KPIs from teams up to COO annual performance review (Image: a table showing a cascade of KPIs)
g. Create dashboards and review calendars for each team (Image: a dashboard and a calendar)
h. Hold workshop on conducting performance dialogues (Image: a smaller circular diagram with "Performance dialogue" in the center)
: flowchart::>

<a id='f6ba13a0-34f9-4084-8245-4581bf5f7cdc'></a>

McKinsey & Company | 17

<!-- PAGE BREAK -->

<a id='0c9f8c33-6540-4063-8a58-ae8a7f7bc589'></a>

<::table:7 KPIs give a clear overview of GDF's performance against its 3 main objectives| Objective | KPI ||---|---|| 1 Provide uninterrupted supply of 1st and 2nd line TB drugs and diagnostics:▪ At low-cost▪ At high quality▪ Timely▪ In a demand and customer-driven way▪ To eligible countries | 1a Average cost per patient treatment1b Number of patient treatments delivered || 2 Sustainably strengthen eligible countries' national drug management and procure-ment capacity, and financial self-sufficiency¹ | 2a Number of countries that move to direct procurement || 3 Ensure appropriate and efficient staffing and funding to drive the mission | 3a Organizational health and culture index3b Staff capacity and capability index3c Funds raised vs. required for GDF administrative costs3d Funds raised vs. required for GDF activities |::>

<a id='662b3ebd-f7e7-4ddd-a348-2627a69f064c'></a>

1 Financial self-sufficiency of countries may be an objective for the Partnership as a whole

<a id='159a577f-1d0d-4f48-8cd8-62d7dc1f530d'></a>

McKinsey & Company | 18

<!-- PAGE BREAK -->

<a id='9b299a38-daa5-4bef-9fc5-9073aa8d479f'></a>

The COO's annual dashboard is the output of each team's performance review

<a id='0c8e83e4-bb15-4dad-9f4b-e26a710e351b'></a>

Annual performance reviews

GDF COO
1a Number of patient treatments delivered
1b Average cost per patient treatment
2a Number of grantee countries that move to direct procurement
3a Staff capacity and capability index
3b Organizational health/culture index
3c Ratio of funds raised/required for GDF activities
3d Ratio of funds raised/required for GDF administrative costs

<table id="19-1">
<tr><td id="19-2">Capacity Building</td><td id="19-3">General Management and Support</td><td id="19-4">Portfolio Management</td><td id="19-5">Procurement</td><td id="19-6">Quality Management/ Assurance</td></tr>
<tr><td id="19-7">Annual</td><td id="19-8">Annual</td><td id="19-9">Annual</td><td id="19-a">Annual</td><td id="19-b">Annual</td></tr>
<tr><td id="19-c">2.1.1</td><td id="19-d">3.1.1</td><td id="19-e">1.3.1.1</td><td id="19-f">1.1.1</td><td id="19-g">1.2.1</td></tr>
<tr><td id="19-h">2.1.3</td><td id="19-i">3.1.2</td><td id="19-j">1.3.1.2</td><td id="19-k">1.2.3</td><td id="19-l">1.2.2</td></tr>
<tr><td id="19-m">3.2.1</td><td id="19-n">3.1.3</td><td id="19-o">2.1.2</td><td id="19-p">1.3.1.3</td><td id="19-q">1.4.1.1</td></tr>
<tr><td id="19-r">3.2.2</td><td id="19-s">3.2.2</td><td id="19-t">2.1.4</td><td id="19-u">1.3.1.4</td><td id="19-v">3.2.1</td></tr>
<tr><td id="19-w"></td><td id="19-x"></td><td id="19-y">3.2.1</td><td id="19-z">3.2.1</td><td id="19-A">3.2.2</td></tr>
<tr><td id="19-B"></td><td id="19-C"></td><td id="19-D">3.2.2</td><td id="19-E">3.2.2</td><td id="19-F"></td></tr>
<tr><td id="19-G">Blank (with arrow)</td><td id="19-H">Blank (with arrow)</td><td id="19-I">Blank (with arrow)</td><td id="19-J">Blank (with arrow)</td><td id="19-K">Blank (with arrow)</td></tr>
<tr><td id="19-L">Monthly Quarterly</td><td id="19-M">Semi-annual</td><td id="19-N">Monthly Quarterly</td><td id="19-O">Monthly Semi-annual</td><td id="19-P">Monthly Semi-annual</td></tr>
<tr><td id="19-Q">2.1.3.3</td><td id="19-R">3.1.1</td><td id="19-S">1.3.1.1</td><td id="19-T">1.3.1.3</td><td id="19-U">1.4.1.1</td></tr>
<tr><td id="19-V">3.2.1.1*</td><td id="19-W">3.1.2</td><td id="19-X">1.3.1.2</td><td id="19-Y">1.3.1.4</td><td id="19-Z">1.4.3</td></tr>
<tr><td id="19-10">2.1.3.1</td><td id="19-11">3.1.2.1</td><td id="19-12">2.1.2</td><td id="19-13">3.2.1.1*</td><td id="19-14">3.2.1.1*</td></tr>
<tr><td id="19-15">2.1.3.2</td><td id="19-16">3.1.2.2</td><td id="19-17">2.1.4.2</td><td id="19-18">1.3.1.3</td><td id="19-19">1.4.1.1</td></tr>
<tr><td id="19-1a">2.1.3.4**</td><td id="19-1b">3.1.2.3</td><td id="19-1c">2.1.4.3</td><td id="19-1d">1.3.1.4</td><td id="19-1e">1.4.2</td></tr>
<tr><td id="19-1f">3.1.3.1</td><td id="19-1g">3.2.2</td><td id="19-1h">3.2.1.1*</td><td id="19-1i">3.1.3.1</td><td id="19-1j">1.4.3</td></tr>
<tr><td id="19-1k">3.2.2</td><td id="19-1l"></td><td id="19-1m">2.1.4.3</td><td id="19-1n">3.2.3</td><td id="19-1o">3.1.3.1</td></tr>
<tr><td id="19-1p">3.2.3</td><td id="19-1q"></td><td id="19-1r">2.1.4.4**</td><td id="19-1s"></td><td id="19-1t">3.2.3</td></tr>
</table>

Performance reviews
throughout the year

<a id='b6167b17-758d-4abd-b1a1-967e266dcdda'></a>

* May be reviewed less frequently depending upon team needs
** To be reviewed semi-annually

<a id='a9f26b35-0ac0-4e85-bbd6-3a14477ff7e4'></a>

McKinsey & Company | 19

<!-- PAGE BREAK -->

<a id='3fe3f93a-3c1c-45bb-9d50-4f4ff769404f'></a>

KPI tree for GDF's first objective

<a id='b53aad29-878d-48ac-94c1-039cc3ad384b'></a>

<::An organizational chart detailing Objectives, Categories, High-level KPIs, Detailed KPIs, Owners, and Review Frequencies. The chart is structured with a main objective branching into categories, which then branch into high-level and detailed KPIs. Review frequencies are marked with 'X' in a grid of options (M, 3M, 6M, A).: chart::>

| Objective | Category | High-level KPI | Detailed KPIs | Owner | Review frequency⁷ M | Review frequency⁷ 3M | Review frequency⁷ 6M | Review frequency⁷ A |
|---|---|---|---|---|---|---|---|---|
| Provide uninterrupted supply of 1st and 2nd line TB drugs and diagnostics<br>- At low cost<br>- At high quality<br>- On time<br>- In a demand and customer-driven way<br>- To eligible countries | 1.1 Cost | 1.1.1 Average total patient treatment or diagnostic unit cost:<br>- Prophylaxis (adult and pediatric)<br>- 1st line drugs (adult and pediatric)<br>- 2nd line drugs (adult and pediatric)<br>- Diagnostics | 1.1.1.1 Average product cost per patient/unit | Procurement | option M: [ ] | option 3M: [ ] | option 6M: [ ] | option A: [x] |
| | | | 1.1.1.2 Average additional costs per patient/unit | Procurement | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | 1.2 Product quality and selection | 1.2.1 Percentage of GDF products that meet GDF QA standards | 1.2.1.1 Percentage of suppliers that meet GDF QA standards | Quality Assurance | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | | 1.2.2 Percentage of TB products recommended in WHO/GLC guidelines that are available in GDF catalogue | | Quality Assurance | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | | 1.2.3 Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries (contracted/non-contracted)¹ | | Quality Assurance | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | 1.3 Timeliness | 1.3.1 Percentage of orders delivered within the time stated on signed agreement | 1.3.1.1 Average lead time between receipt of country grant application to delivery of agreement to country for signing | Procurement | option M: [ ] | option 3M: [ ] | option 6M: [ ] | option A: [x] |
| | | | 1.3.1.2 Average lead time between receipt of country-signed agreement and GDF placing order | Procurement and portfolio management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | | 1.3.1.3 Average length of time from GDF placing order to date of order/shipment dispatch | Portfolio Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | | 1.3.1.4 Average length of time from order/shipment dispatch date to proof of delivery to country | Portfolio Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| Overarching KPIs<br>1a Number of patient treatments provided<br>1b Average cost per treatment course | 1.4 Customer demand driven | 1.4.1 Percentage of patient treatments/diagnostics delivered vs. approved through grant/technical agreement | 1.4.1.1 Orders delivered as percent of orders placed | Procurement | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | 1.4.2 Number of country-level stock-outs in countries served by GDF | | Quality Management | option M: [ ] | option 3M: [x] | option 6M: [ ] | option A: [ ] |
| | | 1.4.3 Customer satisfaction "index" (TBD) | | Quality Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |
| | | | | Quality Management | option M: [ ] | option 3M: [ ] | option 6M: [x] | option A: [ ] |
| | | | | Quality Management | option M: [x] | option 3M: [ ] | option 6M: [ ] | option A: [ ] |


<a id='c810e0fc-fe66-4002-a3d9-628b8894d035'></a>

1 Depends upon shortlist of suppliers received from Quality Assurance function
2 M = monthly; 3M = 3 monthly; 6M = 6 monthly; A = annually

<a id='e5c98d1e-f372-4e6d-9be4-917d20d5f239'></a>

SOURCE: Annual GDF report 2008; GDF strategic plan 2006 -10, Standard Operating Procedure for surveillance and measurement (SOP - 40.00); GDF Quality
Management Manual Rev 4.1 issue March 3, 2009; Team analysis

<a id='20060653-1747-4b88-851e-7c717657e4a7'></a>

McKinsey & Company | 20

<!-- PAGE BREAK -->

<a id='6c4e2606-4c32-4be6-ab6a-25aa90ceb1b5'></a>

**_COO - Annual dashboard_**

<a id='43ce1de7-5031-44a8-994b-bff58e411a78'></a>

DUMMY NUMBERS

<a id='797537a4-496b-4822-a380-79b535c1aee6'></a>

<::1a Number of patient treatments delivered: chart::>

Objective 1

| | Target | Actual | YoY trend (2008) | YoY trend (09) | YoY trend (2010) |
|---|---|---|---|---|---|
| **1st line** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.4 | Target: 2.3, Actual: 1.9 | Target: 2.1, Actual: 2.5 |
| **2nd line** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.2 | Target: 1.9, Actual: 1.7 | Target: 2.1, Actual: 2.1 |
| **Prophylaxis** | option X: [ ] | option X: [ ] | Target: 1.1, Actual: 1.2 | Target: 1.9, Actual: 1.7 | Target: 2.1, Actual: 2.1 |
| **Diagnostics** | option X: [ ] | option X: [ ] | Target: 2.0, Actual: 2.3 | Target: 3.8, Actual: 3.5 | Target: 4.0, Actual: 4.1 |

Legend:
option Target: [ ]
option Actual: [ ]
<::

<a id='509269cc-4429-416f-aec7-9c25e914bcbf'></a>

1b Average cost per patient treatment or diagnostic unit ($)
<::
Chart: Average cost per patient treatment or diagnostic unit ($)
Legend:
- Target: Light blue square
- Actual: Dark blue square

| Category      | Target | Actual | YoY trend (2008)        | YoY trend (2009)        | YoY trend (2010)        |
|:--------------|:-------|:-------|:------------------------|:------------------------|:------------------------|
| 1st line      | X      | X      | Target 4.7, Actual 4.1  | Target 4.5, Actual 4.3  | Target 4.4, Actual 4.3  |
| 2nd line      | X      | X      | Target 13.0, Actual 16.0 | Target 12.0, Actual 12.3 | Target 12.0, Actual 11.5 |
| Prophylaxis   | X      | X      | Target 1.6, Actual 1.2  | Target 1.6, Actual 1.4  | Target 1.5, Actual 1.5  |
| Diagnostics   | X      | X      | Target 11.5, Actual 12.0 | Target 11.0, Actual 11.0 | Target 11.0, Actual 12.0 |
: bar chart::>

<a id='f992b935-2a38-42d0-95af-2717cdb04ad3'></a>

<table id="21-1">
<tr><td id="21-2"></td><td id="21-3" colspan="5">2a Number of grantee countries that moved to direct procurement this year</td></tr>
<tr><td id="21-4"></td><td id="21-5">Target</td><td id="21-6">Actual</td><td id="21-7">Countries</td><td id="21-8">Comments</td><td id="21-9"></td></tr>
<tr><td id="21-a">Objective 2</td><td id="21-b">X</td><td id="21-c">X</td><td id="21-d">bullet points</td><td id="21-e">bullet points</td><td id="21-f">... (list of asterisks)</td></tr>
</table>

<a id='52c5ad0a-5f6a-4434-a945-d3baf849f6eb'></a>

Objec-
tive 3

3a Staff capacity and capability index

<::transcription of the content
: The image shows a traffic light icon with the bottom light (green) illuminated, while the top two lights (red and yellow) are unlit.::>

Comments

* ...
* ...

* ...
* ...

3c Ratio of funds raised/required for GDF activities ($M)

Funds raised Funds required Ratio

* X
* Y
* X/Y

<a id='02926522-4a5d-4ff7-8f06-182a07c6dc11'></a>

3b Organizational health/culture index

<::description: A vertical traffic light icon with the middle (yellow) light illuminated.::>

Comments

*   ...
*   ...
*   ...
*   ...

<a id='b7eada80-ecd0-4c31-b4ef-b844ae6bc143'></a>

3d Ratio of funds raised/required for GDF administrative costs ($M)

Funds raised
* X

Funds required
* Y

Ratio
* X/Y

<a id='e51b8e49-9a8c-4b0f-8214-54e82c5cce08'></a>

McKinsey & Company | 21

<!-- PAGE BREAK -->

<a id='7b1b0fd7-8c53-4b7a-9a9c-7582f2d0d62a'></a>

Procurement Team – *Annual dashboard*

<a id='1a695626-1e3d-481e-afbf-c8505ea61209'></a>

DUMMY NUMBERS

<a id='0a4570cb-350f-44c0-9517-0d798eed3172'></a>

Objec-tive 1

1.1.1: Average cost per patient treatment or diagnostic unit (USD)
<::table::>
Legend: Target (light blue square), Actual (dark blue square)

| | | Target | Actual | YoY trend (2008) | YoY trend (2009) | YoY trend (2010) |
|:---|:---|:---|:---|:---|:---|:---|
| **1st line** | Adults | ▪ X | ▪ X | Target 1.1, Actual 1.4 | Target 2.3, Actual 1.9 | Target 2.1, Actual 2.5 |
| | Pediatrics | ▪ X | ▪ X | Target 1.1, Actual 1.4 | Target 2.3, Actual 1.9 | Target 2.1, Actual 2.5 |
| **2nd line** | | ▪ X | ▪ X | Target 1.1, Actual 1.2 | Target 1.9, Actual 1.7 | Target 2.1, Actual 2.1 |
| | |
| **Prophylaxis** | Adults | ▪ X | ▪ X | Target 1.1, Actual 1.2 | Target 1.9, Actual 1.7 | Target 2.1, Actual 2.1 |
| | Pediatrics | ▪ X | ▪ X | Target 0.9, Actual 1.1 | Target 1.6, Actual 1.5 | Target 1.7, Actual 1.6 |
| **Diagnostics** | | ▪ X | ▪ X | Target 2.0, Actual 2.3 | Target 3.8, Actual 3.5 | Target 4.0, Actual 4.1 |
<::/table::>

1.2.3: Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries
<::table::>
| | | Number of products | Percentage with ≥ 2 suppliers |
|:---|:---|:---|:---|
| **1st line** | Adults | X | X% |
| | Pediatrics | X | X% |
| **2nd line** | | X | X% |
| **Prophylaxis** | Adults | X | X% |
| | Pediatrics | X | X% |
<::/table::>

1.3.1.3: Average length of time from GDF placing order to date of order/shipment dispatch (days)
<::table::>
Legend: Production (dark blue line), Average (medium blue line), Stock (light blue line)

| | Target | Actual | Deviation | Trend |
|:---|:---|:---|:---|:---|
| Average | ▪ X | ▪ X | ▪ X% | Line chart showing values between 5 and 15 from J to D. |
| Shipments from stock | ▪ X | ▪ X | ▪ X% | |
| Shipments from production | ▪ X | ▪ X | ▪ X% | |
<::/table::>

1.3.1.4: Average length of time from order/shipment dispatch date to proof of delivery to country (days)
<::table::>
| | Target | Actual | Deviation | Trend |
|:---|:---|:---|:---|:---|
| | ▪ X | ▪ X | ▪ X% | Line chart showing values between 10 and 40 from J to D. |
<::/table::>

Objec-tive 3

3.2.1: Staff satisfaction and motivation
<::visual content::>
Traffic light indicator: option red: [ ] option yellow: [x] option green: [ ]
<::/visual content::>
Comments
*   ...
*   ...
*   ...

3.2.2: Staff retention level/attrition rate
<::visual content::>
Traffic light indicator: option red: [x] option yellow: [ ] option green: [ ]
<::/visual content::>
Comments
*   ...
*   ...
*   ...

<a id='f2eca592-0fe1-495a-b067-d8be07bd8a8c'></a>

McKinsey & Company | 22

<!-- PAGE BREAK -->

<a id='533891b5-645e-4977-abbb-b5644bd31404'></a>

Procurement Team – 1.2.3 Percentage of products in GDF catalogue with ≥ 2 suppliers in all eligible countries

<a id='879f1e69-3f4f-4df5-bc0b-bfeb2578139d'></a>

<::table
Legend: A blue background indicates "Does not meet target".
| | Total number of products | Percentage with ≥ 2 suppliers | Product | Number of suppliers > 4 | Number of suppliers 4 | Number of suppliers 3 | Number of suppliers 2 | Number of suppliers 1 | Number of suppliers 0 |
|:---|:---|:---|:---|:---|:---|:---|:---|:---|:---|
| 1st line | x | x | A | ✓ | | | | | |
| • Adults | | | B | | ✓ | | | | |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | ✓ | | | |
| | | | E | | | | ✓ | | |
| | | | F | ✓ | | | | | |
| | | | G | | ✓ | | | | |
| | | | H (Does not meet target) | | | | | | ✓ |
| | | | I | | | ✓ | | | |
|...|
| 1st line | x | x | A (Does not meet target) | | ✓ | | | | |
| • Paediatrics | | | B | | | ✓ | | | |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | | ✓ | | |
| | | | E | | | | | ✓ | |
|...|
| 2nd line | x | x | A (Does not meet target) | | | | | ✓ | |
| | | | B | | | | | | ✓ |
| | | | C (Does not meet target) | | | | | ✓ | |
| | | | D | | | | ✓ | | |
| | | | E (Does not meet target) | | | | | | ✓ |
::>

<a id='1c064454-3a47-457d-a171-b4908fc473ff'></a>

McKinsey & Company | 23

<!-- PAGE BREAK -->

<a id='c0f37a9b-6a66-47b5-82a6-b1c07d80f327'></a>

GDF performance review calendar



[ ] Combined meetings

<a id='b865bf8f-4dd7-4e35-b248-ce6bf8346d13'></a>

<::Table showing meeting schedules for 2010
: table::>
| Meetings | Jan | Feb | Mar | Apr | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec |
| :-------------------------------------- | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| **Annual review meetings** | | | | | | | | | | | | |
| Coordinating Board | | | | | | | | | | | △ | △ |
| GDF COO | | | | | | | | | | | △ | △ |
| **Team meetings** | | | | | | | | | | | | |
| Annual¹ | | | | △ | | | | | | △ | | |
| Quarterly² | | | △△ | | | △ | | | △△ | | | △ |
| Monthly | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| **Cross-team meetings** | | | | | | | | | | | | |
| Procurement effectiveness | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| Product quality, selection, and supply | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ | △ |
| TA/M+E customer satisfaction | | | △△ | | | △ | | | △△ | | | △ |
| TA/M+E effectiveness | | △ | | | △△ | | | △ | | | △△ | |
| Recommendation implementation | △ | | | △△ | | | △ | | | △△ | | |
<::/Table showing meeting schedules for 2010
: table::>

<a id='26f2e204-e8f3-4b1c-beea-72a62ac61bda'></a>

1. Quarterly and monthly KPIs can be discussed as necessary
2. Monthly KPIs can be discussed as necessary

McKinsey & Company | 24

<!-- PAGE BREAK -->

<a id='a1853459-2a2d-4a7e-9f08-834fc4e47839'></a>

Next steps to implement and capture benefits

<a id='e73c8024-8c7c-4ee0-aba6-e7c272ba660c'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3">Description</td></tr>
<tr><td id="25-4">Share KPI trees with donors</td><td id="25-5">Present GDF KPI tree to donors and compare with KPIs/metrics requested by donors Discuss with donors if streamlined GDF KPIs meet their reporting requirements</td></tr>
<tr><td id="25-6"></td><td id="25-7">Agree on any additional KPIs that need to be reported upon</td></tr>
<tr><td id="25-8">Integrate KPIs into MIS</td><td id="25-9">Establish simple mechanisms within GDF&#x27;s existing MIS system to input and analyze data required for KPIs</td></tr>
<tr><td id="25-a">Complete performance dialogue workshop</td><td id="25-b">Conduct 2 hour workshop with GDF team leads on facilitating constructive performance dialogues with teams</td></tr>
<tr><td id="25-c">Embed KPIs in team performance review</td><td id="25-d">Officially launch new performance management process; next steps are Assign data collection/reporting responsibilities within teams Schedule review meetings or add review to agendas of existing meetings Complete one round of performance reviews Refine KPIs and review process based on team feedback</td></tr>
</table>

<a id='0a931f94-a8de-44ec-a109-e1d289001a4d'></a>

McKinsey & Company | 25

<!-- PAGE BREAK -->

<a id='55d3586c-df85-4e0a-8afe-5c3a3518b5ab'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 26

<!-- PAGE BREAK -->

<a id='5412cf26-d3e2-450a-af98-9d577ed7b616'></a>

Advocacy Team issues and opportunities

<a id='261abb78-ed89-49ab-afa5-cba93ad42436'></a>

GHP performance issue
① Setting advocacy objectives that stay current and relevant in changing external circumstances

① Finding and making visible tactical advocacy opportunities for partners to act

<::Performance management: flowchart::>
1 Set objectives
2 Establish clear metrics
3 Set targets
4 Track and disseminate metrics
5 Review performance
6 Celebrate achievements and take further action
Advocacy improvement opportunities
① Setting advocacy objectives within Stop TB Partnership that stay current and relevant in changing external circumstances

① Finding and making visible tactical advocacy opportunities for Stop TB partners to act 

<a id='3d58e7d6-e176-49ee-ad42-dfc1fd712f5f'></a>

McKinsey & Company | 27

<!-- PAGE BREAK -->

<a id='d4e1258c-8295-452a-b887-463137a79f42'></a>

3 steps ensure that emerging opportunities are incorporated in advocacy partners' plans and/or into the Framework Document

<a id='f24ab5dd-34e7-461e-8456-0d553d0229f1'></a>

1

Get more information

- Make advocacy every partner's business and get them to increase their information sharing
- Extend the reach of TB advocacy beyond the Partnership

"Develop the sunflower"

2

Filter the information received

- To manage the flow of information collected, set up a process that allows the Advocacy Team¹ to filter the information for
  - Validity
  - Impact
  - Global relevance
  - Feasibility

"Filter the intelligence"

3

Create new or adjust current objectives and activity plans

I For tactical opportunities requiring immediate action

- Create new or adjusted objectives and activity plans based on new opportunities
- Define what success looks like, how to track progress

II For all opportunities not requiring immediate action

- Draft adjustments into the Framework Document
- Seek advice from AAC on changes drafted
- Share revised objectives and plans with partners

"Keep the framework relevant"

Review performance on new and adjusted objectives

<::transcription of the content
: The small visual shows "Stop TB Partnership" and text:
FRAMEWORK FOR ADVOCACY 2010
1. Problem: TB Burden (WHO 2009 Report)
- Globally, there were an estimated 9.27 million incident cases of TB (2007). Most of the cases were in Asia (55%), Africa (31%), and Europe (4%). Only 10% of incident cases were smear-positive. The TB incidence rate has remained stable or declined slowly in most regions of the world, except in Africa, where it has increased. The highest burden is in South-East Asia (3.3 million), followed by Africa (3.0 million), Western Pacific (1.8 million), and Europe (0.45 million), Americas (0.31 million), and Eastern Mediterranean (0.26 million).
- The total number of incident cases of TB is decreasing at the global level, but the rate of decline is not sufficient to reach the MDG target of halting and reversing the TB epidemic. The MDG target is to halt and begin to reverse the incidence of TB by 2015. The TB incidence rate declined at an average rate of 1.2% per year between 2000 and 2007.
- The global number of deaths from TB is estimated to be 1.3 million in 2007 (excluding HIV-positive cases).
- The proportion of cases that are HIV-positive is increasing, particularly in Africa.::>

1 Advocacy Team includes Secretariat advocacy and WHO STB department advocacy teams

<a id='92410d99-85b5-41e8-a04b-0f8bc6333192'></a>

SOURCE: Workshops                                                     McKinsey & Company | 28

<!-- PAGE BREAK -->

<a id='da7536af-905a-4b14-9d28-d255e30c53c5'></a>

1 There are 2 steps to get more relevant information, faster

<a id='e4d7ea74-0634-4140-a302-5120c1bcde46'></a>

Make advocacy every partner's business

Advocacy
Network
Working Groups
Ambassadors
STB Leadership
Coordinating
Board

A Present the advocacy framework to the Partnership
B Use recent framework developments to keep partners informed and excited about advocacy priorities
C Foster partner discussions on advocacy priorities/activities on Center for Resource Mobilization website
D Actively engage “Network Stars” within the Partnership

<a id='bec93fbe-b941-4f84-938a-229f4ad517eb'></a>

Extend the reach of TB advocacy beyond the Partnership <::A graphic of a yellow flower-like design with multiple petals arranged in a circle around a central white space.::> E Locate, research and prioritize target Network Stars F Create opportunities to initiate contact with the Network Stars targeted G Nurture relationships with collaborative Network Stars, de-prioritize others

<a id='b6fb2dd5-6fe3-47fb-a0aa-445bd44e70f3'></a>

1 Network Stars are defined as the most highly connected individuals within a network through whom information flows first

SOURCE: Workshops
McKinsey & Company | 29

<!-- PAGE BREAK -->

<a id='309d0887-a359-47e4-9fb3-53329d0c8a96'></a>

2. The information received from an active and extended network needs to be filtered across 4 criteria

<a id='bc55e699-3d30-46f8-a2f8-ceac58fc2c2a'></a>

<::logo: 
PRELIMINARY
The logo features three rectangular bars in a step-like arrangement, with the middle bar highlighted in blue against two lighter grey bars.::>

<a id='3ad8982a-d159-4838-b5aa-bb7a493ffb22'></a>

<::flowchart::>This flowchart illustrates an information filtering process for an advocacy team.The process begins with an input box labeled "Advocacy Team receives unfiltered information".This input feeds into a large, horizontal funnel structure, which represents the filtering process.Along the funnel, there are four distinct filter stages, each with a corresponding label and description below it:1.  **Validity Filter**  The received information is checked for validity with a second source: "Is the information accurate and true?"2.  **Impact Filter**  Once validated, the information is filtered for work plan impact: Can the information affect  *   Policy?  *   Donors?  *   Public opinion?3.  **Global Filter**  The information is filtered for global relevance: "Does it have implications beyond local/national boundaries?"4.  **Feasibility Filter**  Determine whether the information can feasibly and realistically be translated into sufficiently impactful activitiesAt the bottom center, a final action box states: "Apply filter at start of advocacy meetings"<::

<a id='91062f86-999e-4171-a816-d79e9a4c3af3'></a>

SOURCE: Workshops                                               McKinsey & Company | 30

<!-- PAGE BREAK -->

<a id='14f16522-5087-475d-aabe-768fb515e25d'></a>

3 Framework document needs to be refined and revised based on information received <::process diagram: This diagram shows a three-step process depicted as ascending blocks, with an additional review step and a preliminary indicator. Above the steps, a small icon of three ascending bars is present, labeled "PRELIMINARY". The steps are:
1. Get more information
2. Set up process to filter the information received
3. Create new or adjust current objectives and work plans
An additional step, presented in an oval, is: Review performance on adjusted objectives.::>

<a id='aa7d99a8-9360-43f4-9837-ed52c3f71bd9'></a>

For tactical opportunities requiring immediate action
<table id="31-1">
<tr><td id="31-2">Analyze filtered intelligence and create new-or update current-objective</td><td id="31-3">Prompt for rapid input from AAC</td><td id="31-4">Share updates to all relevant stakeholders for immediate buy-in and action</td></tr>
<tr><td id="31-5">■ Create new objectives and plans, define success and how to measure progress (information icon) For all opportunities not requ</td><td id="31-6">As time is limited, input gathering to happen over phone or same day email feedback loop ring immediate action</td><td id="31-7">Share new/adjusted objectives and plans Define success and how to measure/track progress (e.g., how many updates suggested? Pursued? Achieved?)</td></tr>
<tr><td id="31-8">Analyze filtered intelligence and create new-or update current-objective</td><td id="31-9">Share updates with and seek advice from AAC</td><td id="31-a">Input into Framework Document, share with Advocacy Network</td></tr>
<tr><td id="31-b">Secretariat Leadership and Advocacy Team jointly analyze and discuss the filtered information, drafting new or adjusted objectives</td><td id="31-c">Submit changes to AAC for input by next Advocacy Network call More substantial adjustments to be submitted to the Coordinating Board</td><td id="31-d">Share adjusted Framework with Advocacy Network and other partners In monthly Advocacy Network call In monthly email update with link to CRM website</td></tr>
</table>

<a id='0bc34c46-588d-4d2f-a921-e3355ecd4358'></a>

SOURCE: Workshops McKinsey & Company | 31

<!-- PAGE BREAK -->

<a id='2376a162-51c0-4d6d-88d3-44c5b77b3c63'></a>

Next steps and expected impact

<a id='dd8a5366-a713-41dc-ae5e-f22d2eed4ad8'></a>

PRELIMINARY

<a id='85a1caac-d12b-4f01-a7ed-e8e4d0d9a218'></a>

<table id="32-1">
<tr><td id="32-2"></td><td id="32-3">Description</td></tr>
<tr><td id="32-4">Engage the Partnership</td><td id="32-5">▪ Present framework document to – Coordinating Board: Nov 2009 – Advocacy Network: Dec 2009 (Cancun) – Stop TB Leadership: Nov 2009 – Core groups of the Working Groups: Nov 2009 ▪ Set up Advocacy Network calls</td></tr>
<tr><td id="32-6">Identify Network Stars, plan engagement</td><td id="32-7">▪ Map Network Stars within and beyond the Partnership ▪ Link Network Stars to objectives, prioritize outreach ▪ Plan engagement for prioritized Network Stars</td></tr>
<tr><td id="32-8">Develop CRM website section, Standard Operating Procedures</td><td id="32-9">▪ Advocacy Team to determine ideal structure and content of the CRM site section devoted to the framework ▪ Develop and disseminate Standard Operating Procedures for sharing information, updating the website (Nov 2009) ▪ Complete work on CRM website (Dec 2009)</td></tr>
</table>

<a id='d61359de-6d1d-43cd-a373-da6ab06f5e84'></a>

## Expected impact

* Strengthen Advocacy Network ties and increase dialogue between advocacy stakeholders
* Improve the use and increase the sharing of relevant information
* Stay ahead of emerging threats and opportunities
* More efficient use of Advocacy Team's limited time - no extra resources required

<a id='d49ba411-a379-4698-a9cb-4efa14f9f11d'></a>

McKinsey & Company | 32

<!-- PAGE BREAK -->

<a id='d8fdd738-bf5f-464f-8dca-953d85b5a2ad'></a>

Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 33

<!-- PAGE BREAK -->

<a id='2f3a7b11-4178-439a-bfbf-1d67a9b19e73'></a>

Communications Marketing and Branding issues and opportunities

<a id='ad427ab6-fc60-445d-82c6-41041bea7019'></a>

GHP performance issue

① Getting from a vision to the specific objectives for the partnership and its bodies rather than directly to activities

② Agreeing the right metrics for objectives that are difficult to measure, e.g., awareness about TB

Communications, marketing, and branding improvement opportunities

① Determining detailed objectives for each audience group that the Communications, marketing and branding team seeks to address

② Define metrics for each detailed objective

<::Performance management diagram: A circular diagram showing 6 steps.

1. Set objectives (blue arrow)
2. Establish clear metrics (blue arrow)
3. Set targets (grey arrow)
4. Track and disseminate metrics (grey arrow)
5. Review performance (grey arrow)
6. Celebrate achievements and take further action (grey arrow)

In the center of the circle: Performance management
: flowchart::>

<a id='70418b56-a10a-48d4-bd61-57a7790a23f6'></a>

McKinsey & Company | 34

<!-- PAGE BREAK -->

<a id='cc803c8d-99e3-4b6a-ad2e-c36b70427d73'></a>

4 steps lead to clear objectives, metrics and targets, as well as to required activities to deliver

<a id='3b4a7e99-a509-49d1-b873-0480f64c4663'></a>

<::1 Identify audience groups

2 Raise awareness about TB among members of the public in donor countries and selected high-burden countries

High level objective

Stakeholder group/audience

2.1 High net worth individuals, DC

2.2 High net worth individuals, HBC, BRICS

2.3 Students/young adults, DC and HBC, BRICS

2.4 All other adults, DC

2.5 All other adults, HBC and BRICS

2.6 Children, DC and HBC, BRICS

Identified and prioritized all audience groups per high-level objective

SOURCE: Team discussion

2 Define specific objectives per audience group

2 Raise awareness about TB among members of the public in donor countries and selected high-burden countries

PRELIMINARY

High level objective

Stakeholder group/audience

Objective per stakeholder group/audience

2.1 High net worth individuals, DC

Raise awareness about TB via traditional and innovative to increase private donations and penetrate influential net

2.2 High net worth individuals, HBC, BRICS

Raise awareness about TB (focusing on the target's own traditional and innovative channels in order to increase pri and penetrate influential networks

2.3 Students/young adults, DC and HBC, BRICS

Develop and roll out a viral marketing/social media camp
Stimulate commitment and action against TB from sti
Generate student involvement for World TB Day, e
and organization of activities

2.4 All other adults, DC

Raise awareness about the prevalence and the and innovative channels in order to grow dor additional bottom-up pressure on governm

2.5 All other adults, HBC and BRICS

Provide communications marketing support in raising a and familiarity with TB so as to:
Support the increase in detection and treatment (e.g., educating
self-diagnosis, tment steps), understanding of contagion risks
Foster additional pressure from civil society onto HBC governments

2.6 Children, DC and HBC, BRICS

Raise children's awareness for and sensitivity to TB by providing playful educational materials about the threat of TB, preventative measures, and common symptoms (in local language), e.g., using the Figo animated cartoon

Defined key communications/ marketing objectives for each audience group/ stakeholder

SOURCE: Team discussion
: figure::>

<a id='dbbc5ee4-a649-49f6-abad-7412b855ab44'></a>

<::figure
3
Set metrics and targets

1B Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRICS

PRELIMINARY

| High level objective | Stakeholder group/audience | Objective per audience group | Metrics |
| :--- | :--- | :--- | :--- |
| 1B Raise awareness about TB among members of the public in donor countries and selected high-burden countries/BRICS <br><br> Metrics: <br> - Website traffic from DC/BRICS) <br> - Public rating of TB as Global Health priority (in DC/BRICS) | 1B.1 HNWI¹ and highly networked individuals, DC | Raise awareness about TB via traditional and innovative channels | - Number of highly networked individuals reached <br> - Monetary and in kind donations² (e.g., pro bono consultancy, TV placement of public service announcements) |
| | 1B.2 HNWI and highly networked individuals, HBC, BRICS | Raise awareness about TB in individual's country via traditional and innovative channels | - Number of highly networked individuals reached through targeted media <br> - Percentage of target audience reached <br> - old ac Health |
| | 1B.3 Students / young adults, DC and HBC, BRICS | Develop and roll out a viral marketing/social media campaign | - Number of people reached through targeted viral marketing/social media <br> - old ac Health |
| | 1B.4 All other adults, DC | Raise awareness about the prevalence and threat of TB using traditional and innovative communication channels and marketing products | - Number of people reached through World TB Day campaign |
| | 1B.5 All other adults, HBC and BRICS | Provide communications and marketing support in raising awareness of and familiarity with TB (special focus on women) | |
| | 1B.6 Children, DC and HBC, BRICS | Raise children's awareness for and sensitivity to TB by providing playful educational materials about the threat of TB | - Number of children reached through educational projects |

1 High Net Worth Individuals
2 Value of in kind donations to be estimated and translated in dollar amounts

SOURCE: Team discussion

Set specific metrics and S.M.A.R.T. targets for each prioritized objective

4
Define activity plan

1C Raise awareness about TB among selected institutions – Business community (1/2)

| Priority stakeholder group/audience | Objectives | Metrics | Target |
| :--- | :--- | :--- | :--- |
| Business community | - Raise awareness among business people by targeting locations and venues they regularly encounter (restaurants, hotels, conference centers, rental car agencies) | - Number of business people reached through business partners (e.g., Kempinsky, Sixt) <br> - Monetary and in kind contributions¹ (e.g., pro bono consultancy, TV placement of public service announcements) | - 5M (VC to confirm Kempinsky numbers for 2009) <br> - >50% <br> - $2,000 confirm |
| WHO DOO | | | |
| UNAIDS | | | |

1 Value of in kind donations to be estimated and translated into dollar amount

SOURCE: Team discussion

Defined activity plans required to achieve each prioritized target

McKinsey & Company | 5
::>

<a id='e725ec1b-048d-4381-8ba7-4f45b222d9f4'></a>

McKinsey & Company | 35

<!-- PAGE BREAK -->

<a id='8891af2f-05c1-4689-b87c-4e94ba84b3e9'></a>

The high-level objectives are related to 3 areas – raising awareness about TB, engaging TB networks and supporting the Secretariat

<a id='0eb8b4b8-00b0-4491-b1cd-c99daeac9425'></a>

<::High-level objectives flowchart:
Mission
Inspire the world into action against tuberculosis (TB)

High-level objectives
1. Raise awareness about TB among
   A. The "fourth estate" (news media)
   B. Members of the public in donor countries and selected high-burden countries/BRIC+21
   C. Selected institutions
2. Engage, support and foster a shared sense of purpose among partners and other members of TB networks
3. Provide coordinated support for the core work of the Secretariat
: flowchart::>

<a id='0f8fb374-38ca-4f1a-95d9-17766ab2080c'></a>

1 BRIC + 2 = Brazil, Russia, India, China, Indonesia and South Africa

<a id='a7a128ed-2ae8-4cb1-80b2-8279c3c5c35c'></a>

McKinsey & Company | 36

<!-- PAGE BREAK -->

<a id='107b3c5d-ee91-4516-8954-3926ac749fef'></a>

For each high-level objective, audience groups, objectives, metrics, and targets have been defined (1/2)

<a id='f8447231-341c-4e13-9350-d5d56539ae11'></a>

<::Flowchart: Objectives, Audience, Metrics, and Targets for TB Awareness Campaign

| High-level objective | Audience group | Objective | Metric | Target |
|---|---|---|---|---|
| **1B** Raise awareness about TB among members of the public in donor countries and selected high-burden countries/ BRIC + 2 | Students and adults in donor countries | Raise awareness about the prevalence and threat of TB using traditional and innovative communication channels and marketing products in order to grow donations and generate additional bottom-up pressure on social opinion | Total number of people reached through marketing channels | Online viral campaign: 30 million |
| | Students and adults in HBC¹ | Develop and roll out a viral marketing/social media campaign to - Stimulate commitment and action against TB - Generate involvement in World TB Day, e.g. participation in and organization of activities | Number of high profile TB events targeting students and adults successfully planned and executed Total | TV Public Service Announcements (PSAs): 5 million |
| | Highly networked individuals in DC² and HBC | | Percentage of population 18-65 years old acknowledging TB as top 5 Global Health Priority | Internet PSAs: 10 million |
| | | | | Social networking tools/channels, e.g., YouTube, Facebook 5 million |
: flowchart::>

<a id='30ad75ff-3451-449c-86cc-4917abe3f6d0'></a>

1 HBC = High burden countries including BRIC +2
2 DC = Donor countries
<table id="37-1">
<tr><td id="37-2"></td><td id="37-3">McKinsey &amp; Company</td><td id="37-4">37</td></tr>
</table>

<!-- PAGE BREAK -->

<a id='a5c81a98-755b-4898-a861-69427e11e346'></a>

For each high-level objective, audience groups, objectives, metrics,
and targets have been defined (2/2)

<a id='b3cb7649-5d8a-4f9a-a7d4-ad10b3058f6f'></a>

<::High-level objective, Audience group, Objective, Metric, Target diagram
: diagram::>
## High-level objective
1A. Raise awareness about TB among the "fourth estate" (news media)

## Audience group
- Feature writers/magazine editors, DC
- Health/Science/Development journalists, DC
- Editorial page editors, DC
- Influential journalists and editors, HBC²
- Broadcast producers, DC
- Citizen journalists, DC

## Objective
- Meet with editors to encourage TB coverage (focus on women's magazines)
- Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB

## Metric
- Number of personal meetings with editors
- Number of editors engaged in ongoing dialogue following personal meeting

## Target
- 4
- 2

**Connections:**
- The high-level objective "Raise awareness about TB among the 'fourth estate' (news media)" connects to all audience groups.
- The "Feature writers/magazine editors, DC" audience group connects to the objective "Meet with editors to encourage TB coverage (focus on women's magazines)". This objective then connects to the metric "Number of personal meetings with editors" and the target "4".
- The audience groups "Health/Science/Development journalists, DC", "Editorial page editors, DC", "Influential journalists and editors, HBC²", "Broadcast producers, DC", and "Citizen journalists, DC" all connect to the objective "Excite writers into writing about TB by pitching high-impact topics, e.g., growing threat of MDR-TB and XDR-TB". This objective then connects to the metric "Number of editors engaged in ongoing dialogue following personal meeting" and the target "2".

<a id='03877c8b-22f9-41d9-9dae-2dba16df4536'></a>

McKinsey & Company | 38

<!-- PAGE BREAK -->

<a id='cf4b948b-d8cf-46dd-a29a-b72ec78ed265'></a>

The team will finalize execution plans and align with other teams to ensure the right activities get done

<a id='b5712816-e201-4b24-a982-5f74ab6ea3f0'></a>

Execution plans and budgets

<a id='41ca9294-5756-43d6-b28f-3359842114db'></a>

Internal and
cross-
functional
alignment

<a id='aae51f70-ccfa-4bcb-a9f0-a7851cd01b81'></a>

Performance review

<a id='f80163a6-ab49-41cd-8a40-25828abbe900'></a>

Description

* Present updated objectives to Executive Secretary
* Complete detailed execution plans with activities required to meet objectives
* Allocate budgets/resources to activities
* Align with Advocacy and Partnering and Social Mobilization teams to ensure
  - Responsibilities for shared objectives are clear
  - Ownership of activities is transparent
  - Interfaces on joint projects are well managed
* Ensure regular (e.g., quarterly) review to assess progress against objectives

<a id='bfcfe3ea-4e1d-4282-a08e-93a546efaa11'></a>

# Expected impact
- Focus within team on the high-impact activities that directly aim at delivering against objectives
- Clear ownership for deliverables, within and across teams
- Ability to measure and review performance of communication, marketing and branding – functions that are typically difficult to assess

<a id='926f87e5-bb3b-46ae-80e3-b1da68d1c001'></a>

McKinsey & Company | 39

<!-- PAGE BREAK -->

<a id='e21f8aa4-93f6-4f3c-8d27-5ff5042aa86f'></a>

## Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   **Challenge Facility for Civil Society**
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 40

<!-- PAGE BREAK -->

<a id='13953e8b-0d07-40fd-8f02-8ae23703bb07'></a>

CFCS issues and opportunities

<a id='0beb7cc4-1336-4c3f-aa94-127c9ea3f8ec'></a>

<::attestation: Official status mark
Status indicators - Preliminary
Readable Text: PRELIMINARY
Short description of visual elements and positioning: Gray text "PRELIMINARY" underlined, with a vertical line on the left, centered in the image.::>

<a id='cede8619-cc1a-47f1-8a00-46b7d9068f39'></a>

GHP performance issue
① Getting from a vision to the specific
objectives for the partnership and its bodies
rather than directly to activities

CFCS improvement opportunities
① Refine the mission based on experience
and lessons learned in the first two years
of the CFCS program
① Articulate specific objectives around the
newly refined mission statement

<::
chart: Performance Management Cycle

1. Set objectives
2. Establish clear metrics
3. Set targets
4. Track and disseminate metrics
5. Review performance
6. Celebrate achievements and take further action
::>


<a id='72824580-4bc5-4e73-b4dc-4e861cc32806'></a>

McKinsey & Company | 41

<!-- PAGE BREAK -->

<a id='da35783e-9665-401d-aff8-9172d8718302'></a>

The team conducted 4 workshops to revise the CFCS mission, objectives, selection and evaluation criteria

<a id='7f0072c4-8da6-482f-8bcd-65617f495331'></a>

1. Refine current mission based on the experience accumulated since program inception, reviews and lessons from field visits
2. Define objectives based on the newly revised mission
3. Determine the proper set of application selection criteria that best help achieve CFCS objectives
4. Define grant evaluation criteria and template to allow for easy and efficient assessment of individual grant performance

<a id='68e05576-5478-428c-a9d9-489df3504b99'></a>

McKinsey & Company | 42

<!-- PAGE BREAK -->

<a id='27aee168-d7ad-4ff1-9595-fcd75004eb0b'></a>

As a first step, the team clarified the CFCS mission and defined objectives to deliver this mission

<a id='3ebfd588-1bca-46f3-8c18-1c6540c97fef'></a>

<::flowchart
: Mission
: To provide support to community-based organizations engaged in advocacy and social mobilization activities seeking to raise awareness and empower communities to become part of the solution in the fight against TB
: Objectives
:   Assist community-based civil society organizations
:     Detail
:       Provide small grants for projects that
:       - Increase awareness and active participation of local communities
:       - Build capabilities of members of local communities
:       Provide coaching and technical assistance to grant recipients
:       Strengthen links between grant recipients and local authorities
:       Bring together different organizations and grant holders to exchange best practices in mobilizing communities and managing projects
:       Identify and stimulate the submission of high-quality/competitive applications
:   Efficiently manage CFCS resources
:     Detail
:       Develop selection criteria that
:       - Ensure the involvement of local health services and TB programs
:       - Strengthen the autonomy and responsibility of local people
:       - Demonstrate the greatest promise of project sustainability
:       Use simple project evaluation processes and criteria that:
:       - Assess project impact
:       - Extract lessons learned
:       - Integrate lessons learned in subsequent selection and evaluation
:       Hold grantees accountable to abide by project milestones
: flowchart::>

<a id='2d2b7b9b-f2e2-47c5-92dd-9938daff91af'></a>

McKinsey & Company | 43

<!-- PAGE BREAK -->

<a id='208bac82-74c2-4949-a021-49a939ac553a'></a>

The CFCS team can use 2 simple indicators to monitor performance against the objectives

<a id='a6f63943-662b-45cb-a927-8c1545851538'></a>

<table id="44-1">
<tr><td id="44-2">Objectives</td><td id="44-3">Metrics</td></tr>
<tr><td id="44-4">Assist community-based civil society organizations</td><td id="44-5">Percentage of funded projects that have impact, defined as achieving ≥X score on evaluation criteria</td></tr>
<tr><td id="44-6">Efficiently manage CFCS resources</td><td id="44-7">Percentage of funds dispersed to projects that receive ≥Y score on selection criteria</td></tr>
</table>

<a id='5668b268-b87d-47e3-a3e2-4b56e99569ac'></a>

The selection and evalua- tion criteria help to define performance standards

<a id='20e08e20-29e8-45e8-b1f2-8ed539d54faf'></a>

McKinsey & Company | 44

<!-- PAGE BREAK -->

<a id='0d33de2e-06db-442c-8bcf-42899ab9360f'></a>

The selection template will allow the selection committee to assess if proposals aim to deliver against CFCS objectives

<a id='4bb67fdb-619c-433c-b4fa-80be825eaa27'></a>

0 Strongly disagree
4 Strongly agree

<a id='afd82147-7a18-4984-9b82-775b9a761984'></a>

<table id="45-1">
<tr><td id="45-2"></td><td id="45-3"></td><td id="45-4" colspan="5">Score</td></tr>
<tr><td id="45-5">Themes</td><td id="45-6">Detailed criteria</td><td id="45-7">0</td><td id="45-8">1</td><td id="45-9">2</td><td id="45-a">3</td><td id="45-b">4</td></tr>
<tr><td id="45-c" rowspan="4">Contribution of grants to CFCS objectives</td><td id="45-d">The proposal includes advocacy and social mobilization activities within the target community</td><td id="45-e">blank checkbox</td><td id="45-f">blank checkbox</td><td id="45-g">blank checkbox</td><td id="45-h">white rectangle with shadow</td><td id="45-i">white rectangle with shadow</td></tr>
<tr><td id="45-j">The proposal includes activities that build awareness and encourage participation of local community</td><td id="45-k">blank checkbox</td><td id="45-l">blank checkbox</td><td id="45-m">blank checkbox</td><td id="45-n">white rectangle with shadow</td><td id="45-o">white rectangle with shadow</td></tr>
<tr><td id="45-p">The proposal contains capability building/training activities that empower individuals within the target community with practical knowledge about their rights and responsibilities in TB care and control</td><td id="45-q">blank checkbox</td><td id="45-r">blank checkbox</td><td id="45-s">blank checkbox</td><td id="45-t">white rectangle with shadow</td><td id="45-u">white rectangle with shadow</td></tr>
<tr><td id="45-v">The proposal contains activities that strengthen the engagement of local health services and other relevant organizations with the local community</td><td id="45-w">two stacked rectangles (checkboxes)</td><td id="45-x">two stacked rectangles (checkboxes)</td><td id="45-y">two stacked rectangles (checkboxes)</td><td id="45-z">one gray rectangle (visual)</td><td id="45-A">one gray rectangle (visual)</td></tr>
<tr><td id="45-B" rowspan="4">Clarity of objectives and activities</td><td id="45-C">Grant objectives respond to a specific TB control challenge Objectives are S.M.A.R.T.¹</td><td id="45-D">two stacked rectangles (checkboxes)</td><td id="45-E">two stacked rectangles (checkboxes)</td><td id="45-F">two stacked rectangles (checkboxes)</td><td id="45-G">two gray rectangles (visual)</td><td id="45-H">two gray rectangles (visual)</td></tr>
<tr><td id="45-I">Activities are in logical and consistent relation to the objectives</td><td id="45-J">rectangle (checkbox)</td><td id="45-K">rectangle (checkbox)</td><td id="45-L">rectangle (checkbox)</td><td id="45-M">one gray rectangle (visual)</td><td id="45-N">one gray rectangle (visual)</td></tr>
<tr><td id="45-O">Each activity is appropriately budgeted</td><td id="45-P">rectangle (checkbox)</td><td id="45-Q">rectangle (checkbox)</td><td id="45-R">rectangle (checkbox)</td><td id="45-S">one gray rectangle (visual)</td><td id="45-T">one gray rectangle (visual)</td></tr>
<tr><td id="45-U">Administrative costs do not surpass 25% of the total budget</td><td id="45-V">rectangle (checkbox)</td><td id="45-W">rectangle (checkbox)</td><td id="45-X">rectangle (checkbox)</td><td id="45-Y">one gray rectangle (visual)</td><td id="45-Z">one gray rectangle (visual)</td></tr>
<tr><td id="45-10" rowspan="2">Clarity of expected outcomes</td><td id="45-11">The proposal includes metrics and targets</td><td id="45-12">single white square</td><td id="45-13">single white square</td><td id="45-14">single white square</td><td id="45-15">one grey rectangle</td><td id="45-16">one grey rectangle</td></tr>
<tr><td id="45-17">There is a clear plan to measure against metrics</td><td id="45-18">single white square</td><td id="45-19">single white square</td><td id="45-1a">single white square</td><td id="45-1b">one grey rectangle</td><td id="45-1c">one grey rectangle</td></tr>
<tr><td id="45-1d">Project sustainability</td><td id="45-1e">The outcomes generated by the activities in the proposal Can be sustained in a way that meets funding requirements Result from processes that have been institutionalized</td><td id="45-1f">two white squares</td><td id="45-1g">two white squares</td><td id="45-1h">two white squares</td><td id="45-1i">two grey rectangles</td><td id="45-1j">two grey rectangles</td></tr>
</table>

<a id='0a578608-f863-4256-9bd6-8b5a4ee4611d'></a>

1 SMART – Specific, measurable, actionable, realistic, time-bound

<a id='cf83d065-fef9-4e4c-9825-49c1416eb8fd'></a>

<table><thead><tr><th>Total score = TBD</th></tr><tr><th>(Maximum score = 52)</th></tr></thead><tbody><tr><td>McKinsey & Company</td><td>45</td></tr></tbody></table>

<!-- PAGE BREAK -->

<a id='085d04da-a45a-4809-9c9a-85b4f61696a5'></a>

The evaluation criteria template assesses whether grants have performed against CFCS objectives

<a id='67f022a4-02ce-4caa-82a8-21dd8ef8dcae'></a>

0 Strongly disagree
4 Strongly agree

<a id='36ba1dcd-12a7-4b36-a211-feb73a8659bb'></a>

Score

<::transcription of the content
: -----
: 0   1   2   3   4
::>

<a id='ef02bc00-8677-4bae-b109-876aacc0af86'></a>

<table id="46-1">
<tr><td id="46-2">Themes</td><td id="46-3">Detailed criteria</td><td id="46-4">0</td><td id="46-5">1</td><td id="46-6">2</td><td id="46-7">3</td><td id="46-8">4</td></tr>
<tr><td id="46-9" rowspan="3">Empower communities by increasing awareness/participation and by building capabilities</td><td id="46-a">Grant increased awareness within local community</td><td id="46-b">square icon</td><td id="46-c">square icon</td><td id="46-d">square icon</td><td id="46-e">white rectangle with shadow</td><td id="46-f">white rectangle with shadow</td></tr>
<tr><td id="46-g">Grant increased active participation within local community</td><td id="46-h">square icon</td><td id="46-i">square icon</td><td id="46-j">square icon</td><td id="46-k">white rectangle with shadow</td><td id="46-l">white rectangle with shadow</td></tr>
<tr><td id="46-m">Grant provided evidence of knowledge transfer to local community (e.g., examples of activities within local community that were enabled by training)</td><td id="46-n">square icon</td><td id="46-o">square icon</td><td id="46-p">square icon</td><td id="46-q">white rectangle with shadow</td><td id="46-r">white rectangle with shadow</td></tr>
</table>

<a id='e6b8dbe7-379b-46af-bcd6-905f96584be5'></a>

<table id="46-s">
<tr><td id="46-t" rowspan="3">Strengthened links with local health services/ other organizations</td><td id="46-u">Grantee has developed a collaboration mechanism with local health services</td><td id="46-v">(blank square)</td><td id="46-w">(blank square)</td><td id="46-x">(blank square)</td><td id="46-y">rectangle with shadow</td></tr>
<tr><td id="46-z">Local health services endorsed activities and outcomes</td><td id="46-A">(blank square)</td><td id="46-B">(blank square)</td><td id="46-C">(blank square)</td><td id="46-D">rectangle with shadow</td></tr>
<tr><td id="46-E">Grantee proactively engaged and interacted with other local relevant organizations</td><td id="46-F">(blank square)</td><td id="46-G">(blank square)</td><td id="46-H">(blank square)</td><td id="46-I">rectangle with shadow</td></tr>
</table>

<a id='a697ccde-62ac-4fa4-a965-cd0badc23820'></a>

<table id="46-J">
<tr><td id="46-K">Ensured activities are sustainable</td><td id="46-L">Generated outcomes are sustainable/long-lasting (e.g., required funds are in place, processes to sustain outcomes are in place)</td><td id="46-M"></td><td id="46-N"></td><td id="46-O"></td></tr>
</table>

<a id='2768e1b1-671e-4707-b090-1426cb3bf5fc'></a>

Total score = TBD
(Maximum score = 28)

<a id='a4265d10-7588-4f66-b935-dace9f6b26d6'></a>

McKinsey & Company | 46

<!-- PAGE BREAK -->

<a id='99d679fa-94e9-4fcf-a574-cbde62aca80e'></a>

Implementing the selection and evaluation criteria would allow CFCS to fund the right proposals and more easily assess their impact

<a id='93484c94-ab2b-4558-a39c-45e7eef57e06'></a>

<table id="47-1">
<tr><td id="47-2"></td><td id="47-3">Description</td></tr>
<tr><td id="47-4">Implementation Cross-functional alignment</td><td id="47-5">▪ Receive approval to continue CFCS from Coordinating Board ▪ Define list of activities to elicit project proposals that are aligned with objectives and selection criteria ▪ Apply selection template in review of applications for next funding round in Q1 2010 ▪ Apply evaluation templates to assess awarded grants ▪ Discuss short-listed proposals with other Partnership bodies to ensure synergies between activities at local level*</td></tr>
<tr><td id="47-6">Performance review</td><td id="47-7">• Ensure regular (e.g., semi-annual) performance review to assess progress against CFCS objectives</td></tr>
</table>

<a id='3954b030-f6ed-4deb-a791-62c8e423f0d2'></a>

# Expected impact

*   Increase in number
    of high potential,
    relevant applications
*   Decrease in time
    and resources
    needed to
    *   Correctly assess
        potential of an
        application
    *   Evaluate the
        implementation of
        grants
*   Synergies captured
    across CFCS and
    other Partnership
    bodies

<a id='fc184e82-97e5-45c9-af82-69e26e6c109a'></a>

1 E.g., country X to move from GDF grant services to direct procurement; CFCS project supports activities to advocate with local government to increase TB resources

<a id='2ae67ec4-a8d1-4ea6-8d29-df01c0d46ada'></a>

McKinsey & Company | 47

<!-- PAGE BREAK -->

<a id='d735491b-6234-4500-9d47-69f67ec78c7b'></a>

Contents

*   Project overview
*   Global Drug Facility
*   Advocacy
*   Communication, Marketing and Branding
*   Challenge Facility for Civil Society
*   MDR-TB Working Group
*   Next steps

McKinsey & Company | 48

<!-- PAGE BREAK -->

<a id='085a430b-fa53-4f7f-9645-9ce871d8db0c'></a>

MDR-TB Working Group issues and opportunities

<a id='ce0bf2e8-7b53-48c2-bdc3-2abcdc326e42'></a>

GHP performance issue

Enablers
*   **Culture** – Ensuring partners within a loose working group arrangement are engaged and motivated to contribute
*   **Capacity** – Allocating significant resources to performance management given limited resources for internal processes

Processes

② Agreeing the right metrics for objectives that are difficult to measure
③ Committing to targets is difficult because of voluntary nature of partnerships

<::transcription of the content
: chart::>

<::transcription of the content
: flowchart::>

<a id='cb004b8e-d7e6-4b14-b5b6-e48e4b8ee904'></a>

# MDR-TB Working Group improvement opportunities

## Enablers
* Developing a simple survey-based tool to assess the level of working group engagement
* The procedural operations of the WG (e.g., following-up on specific activities) are restricted by limited secretariat/ managerial resources

## Processes
2. Metrics set by the WG could be more explicitly tied to objectives of the WG and its members
3. Accountabilities and timelines for specific actions/outcomes are not always clear

<a id='bac186a7-c315-4f40-8c46-b10f9aa23979'></a>

McKinsey & Company | 49

<!-- PAGE BREAK -->

<a id='0148eae0-124a-4dbf-8619-d64a6d04048a'></a>

Questions for MDR-TB WG team barometer

<a id='a6f76c32-87f5-4b9a-8071-e5250542e26a'></a>

<table id="50-1">
<tr><td id="50-2"></td><td id="50-3" colspan="2">Strongly disagree (arrow pointing left)</td><td id="50-4"></td><td id="50-5" colspan="2">Strongly agree (arrow right)</td></tr>
<tr><td id="50-6"></td><td id="50-7">1</td><td id="50-8">2</td><td id="50-9">3</td><td id="50-a">4</td><td id="50-b">5</td></tr>
<tr><td id="50-c" colspan="6">Objectives and direction</td></tr>
<tr><td id="50-d">The objectives of the WG are clear and members are fully aligned on them</td><td id="50-e">empty checkbox</td><td id="50-f">empty checkbox</td><td id="50-g">empty checkbox</td><td id="50-h">empty checkbox</td><td id="50-i">rectangle shape with shadow</td></tr>
<tr><td id="50-j">The WG&#x27;s leaders provide clear strategic direction</td><td id="50-k">empty checkbox</td><td id="50-l">empty checkbox</td><td id="50-m">empty checkbox</td><td id="50-n">empty checkbox</td><td id="50-o">two stacked rectangles with shadow</td></tr>
<tr><td id="50-p">The Chair of my subgroup provides clear direction</td><td id="50-q">checkbox (empty)</td><td id="50-r">checkbox (empty)</td><td id="50-s">checkbox (empty)</td><td id="50-t">checkbox (empty)</td><td id="50-u">simple rectangle shape</td></tr>
<tr><td id="50-v" colspan="6">Delivery against objectives</td></tr>
<tr><td id="50-w">I believe the WG is making good progress towards achieving its objectives</td><td id="50-x">checkbox (empty)</td><td id="50-y">checkbox (empty)</td><td id="50-z">checkbox (empty)</td><td id="50-A">checkbox (empty)</td><td id="50-B">simple rectangle shape</td></tr>
<tr><td id="50-C">My subgroup meaningfully contributes to the overall objectives of the WG</td><td id="50-D">checkbox (empty)</td><td id="50-E">checkbox (empty)</td><td id="50-F">checkbox (empty)</td><td id="50-G">checkbox (empty)</td><td id="50-H">simple rectangle shape</td></tr>
<tr><td id="50-I">The WG is having a meaningful impact in the fight against MDR-TB</td><td id="50-J">checkbox (empty)</td><td id="50-K">checkbox (empty)</td><td id="50-L">checkbox (empty)</td><td id="50-M">checkbox (empty)</td><td id="50-N">simple rectangle shape</td></tr>
</table>

<a id='db3a82a1-c543-4467-8a55-e5ccafa7d85d'></a>

<table id="50-O">
<tr><td id="50-P" colspan="6">Individual contributions</td></tr>
<tr><td id="50-Q">My role within my subgroup is clearly defined</td><td id="50-R">empty checkbox</td><td id="50-S">empty checkbox</td><td id="50-T">empty checkbox</td><td id="50-U">empty checkbox</td><td id="50-V">rectangular shape (with shadow)</td></tr>
<tr><td id="50-W">The individual contribution of each member of my subgroup meets my expectations</td><td id="50-X">empty checkbox</td><td id="50-Y">empty checkbox</td><td id="50-Z">empty checkbox</td><td id="50-10">empty checkbox</td><td id="50-11">rectangular shape (with shadow)</td></tr>
<tr><td id="50-12">After meetings, accountabilities and deadlines for specific actions are clear</td><td id="50-13">empty checkbox</td><td id="50-14">empty checkbox</td><td id="50-15">empty checkbox</td><td id="50-16">empty checkbox</td><td id="50-17">rectangular shape (with shadow)</td></tr>
<tr><td id="50-18">My contribution to the subgroup receives sufficient recognition</td><td id="50-19">empty checkbox</td><td id="50-1a">empty checkbox</td><td id="50-1b">empty checkbox</td><td id="50-1c">empty checkbox</td><td id="50-1d">rectangular shape (with shadow)</td></tr>
</table>

<a id='ef68c4df-f71c-4aeb-ad51-5b6f7531a8e6'></a>

Mindsets and behaviors

The culture within the WG is collaborative and constructive
option : [ ]
option : [ ]
option : [ ]
option : [ ]
option : [ ]

Members are encouraged to voice their opinions, even if they are controversial
option : [ ]
option : [ ]
option : [ ]
option : [ ]
option : [ ]

<a id='050dbd9a-f8ff-4004-b21f-e4e58a9c1b49'></a>

McKinsey & Company | 50

<!-- PAGE BREAK -->

<a id='30946555-2b55-4266-b65c-c8af08b996d1'></a>

The collaborative work with the MDR-TB Working Group is just beginning
– overview of suggested next steps

<a id='da629106-cd58-47eb-b3dc-225b2e46bc46'></a>

# Next steps
* Launch MDR-TB Working Group "team barometer" survey
* Develop metrics and targets that directly evaluate performance against WG objectives
* Develop further approaches to improve members' participation and accountability
* Assess the implications of MDR-TB scale-up on the WG and assess future capacity requirements
* Develop a "business case" for additional secretariat/managerial resources, if required

<a id='d1665277-cbb7-4423-9484-695c12f239a2'></a>

McKinsey & Company | 51

<!-- PAGE BREAK -->

<a id='d1b50e30-b0ca-499a-b3cb-bd499c933d6b'></a>

# Contents

* Project overview
* Global Drug Facility
* Advocacy
* Communication, Marketing and Branding
* Challenge Facility for Civil Society
* MDR-TB Working Group
* Next steps

McKinsey & Company | 52

<!-- PAGE BREAK -->

<a id='8037f202-fe5d-4bab-b460-52ca3d6e2914'></a>

Project outlook – the next ~ 10 weeks will focus on implementing the solutions developed

<a id='db92d608-83d8-46f0-8e8a-2082d82cfd9d'></a>

<::Process flow diagram or timeline. It shows three main stages represented by horizontal colored blocks:
1.  **Diagnose** (light blue block): August - September
2.  **Design** (light blue block): September - October
3.  **Deliver** (dark blue block, shaped like an arrow pointing right): November - December

A black inverted triangle labeled "Today" points to the transition point between the "Design" and "Deliver" stages, indicating that "Today" is at the end of October or the beginning of November.
: process flow::>

<a id='60873004-bd1e-4514-99fc-78b0b8d55889'></a>

* Implementation within project teams begins
* Problem-solving sessions on findings, lessons learned, and implications are conducted
* Workshops to share achievements with other Partnership bodies are conducted
* Report is produced and findings are published
* Progress is presented to Coordinating Board in March 2010

<a id='43426cc8-d8af-496d-8040-988f328b9688'></a>

McKinsey & Company | 53