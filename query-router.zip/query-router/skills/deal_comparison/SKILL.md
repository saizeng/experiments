---
name: deal_comparison
description: >
  Compares two or more deals side-by-side across key dimensions like
  valuation, timeline, structure, and risk factors. Typically used
  after fetching deal data from structured_data and/or document
  content from unstructured_docs.
trigger: >
  when user asks to compare deals, benchmark a deal against others,
  or wants a side-by-side analysis
category: analysis
parameters:
  - name: query
    type: string
    required: true
    description: The comparison question
  - name: deal_ids
    type: list
    required: false
    description: List of deal identifiers to compare (can also be inferred from upstream)
  - name: dimensions
    type: list
    required: false
    description: Specific dimensions to compare (e.g., valuation, structure, timeline, risk)
---

# Deal Comparison Skill

Produces a structured side-by-side comparison of multiple deals.

## run.py contract

- Reads JSON from stdin with `upstream` containing deal data from prior steps
- Writes JSON to stdout: `{"comparison_table": [...], "summary": "...", "deals_analyzed": N}`
