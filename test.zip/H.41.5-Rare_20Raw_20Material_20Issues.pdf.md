<a id='299d4d26-268b-4c2b-a119-9b84f4ac5e37'></a>

<::A logo for "WORLD MATERIALS FORUM". The logo features a blue 3D cube icon on the left, with the text "WORLD MATERIALS FORUM" to its right. "WORLD" and "FORUM" are in a light gray outline font, while "MATERIALS" is in a solid blue font. The background of the image is an abstract blue pattern, possibly industrial or material-related, with a wavy light gray element at the bottom.: figure::>

<a id='80ca3086-ca97-4043-abc1-da60088642f3'></a>

Challenges in Mining:
Scarcity or Opportunity?

<a id='3596a620-2cd9-4c3f-8fc3-69becf580813'></a>

Contribution of Advanced Technologies

<a id='da9d32a2-aa80-4464-b4d2-44d3cc02a687'></a>

World Materials Forum
June 23, 2015

<a id='a37ad80d-230f-4c74-94e4-26e29aacc117'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='f58f6139-d2b4-4be7-91e6-e56d16a5ee8d'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='27b3510e-06ba-4f25-8ef2-d2f2c81de24a'></a>

**Mining productivity globally has declined ~30% over the past decade**

<a id='36e39cb7-b0fa-4863-9d21-82962f46ab1d'></a>

McKinsey Mining Productivity Index, 2004 = 100<::chart: A line chart titled "McKinsey Mining Productivity Index, 2004 = 100" shows two lines representing productivity trends from 2004 to 2013. The Y-axis ranges from 65 to 110 in increments of 5. The X-axis shows years from 2004 to 2013. The first line starts at 105 in 2004, decreases to around 90 by 2006, then fluctuates, reaching approximately 77 in 2013. The second line starts at 100 in 2004, decreases to around 78 by 2007, then fluctuates, reaching approximately 72 in 2012 and rising slightly to around 73 in 2013. Annotations indicate average annual percentage changes: "-6.0% p.a." is shown for the initial decline of the lower line (approx. 2004-2007), "-3.5% p.a." for the initial decline of the upper line (approx. 2004-2009), and "-0.4% p.a." for a later segment of the upper line (approx. 2009-2013). The background features a faint, stylized image of mining equipment.::>

<a id='15f41f02-fc63-44ff-a424-a699ab16d226'></a>

* Between 2004 and 2013, global mining productivity has fallen ~30%, or 3.5% p.a., even after accounting for geological degradation

<a id='261a1721-c52c-4adc-b9a5-30ea0f75b787'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='a259fe16-ae44-4056-8ecf-39fcad1ec09a'></a>

McKinsey & Company

<a id='6b63a825-3276-4f90-ad50-4f691fa06b2d'></a>

1

<!-- PAGE BREAK -->

<a id='5435248a-4f46-4936-8365-37fd5a628a81'></a>

The decline prevails across most commodities as well as across all major mining geographies

<a id='cdb0b0f4-9feb-496b-be89-3a9b97edcc9d'></a>

McKinsey Mine Productivity Index
CAGR, 2009 - 2013

<a id='24583d83-6dc8-4c34-8474-97e0012451c7'></a>

McKinsey Mine Productivity Index
CAGR²

<a id='9fa2e935-06e0-4994-bf33-3b9d27698cfc'></a>

<::Bar chart with a faded background image of mining machinery. The chart shows four vertical blue bars, each representing a negative value for a different material. Below each bar, there is an image of the corresponding material.

From left to right:
1.  **Copper**: Bar value -1.5, with an image of copper nuggets.
2.  **Iron ore**: Bar value -1.6, with an image of an iron ore rock.
3.  **Coal**: Bar value -1.7, with an image of coal lumps.
4.  **PGMs¹**: Bar value -4.5, with an image of a sample of platinum group metals.
: bar chart::>

<a id='2778bcaa-6f0e-48cf-89c3-97ffd7182137'></a>

* Almost all commodities registered declines in mining productivity - the trend is apparent across precious commodities as well as bulk minerals, indicating a more systemic shift that cuts across different mining methods or processing techniques

<a id='7931c84f-bd75-46d4-9c7f-2416f6de993b'></a>

<::Bar chart showing four vertical blue bars extending downwards from a horizontal line. Below each bar is a numerical value and a geographical region label with a faint map outline.
- Bar 1: Value -4.1, Label: Latin America (with map of South and Central America)
- Bar 2: Value -4.2, Label: Australia (with map of Australia)
- Bar 3: Value -4.8, Label: North America (with map of North America)
- Bar 4: Value -4.8, Label: Sub-Saharan Africa (with map of Africa)
: bar chart::>

<a id='2dc8f5b1-feed-4050-a02e-65d262e5bca6'></a>

* North America and Sub-Saharan Africa experienced the biggest declines in productivity over the period

<a id='dec265cd-2d07-4d5d-bfef-69d24c28e418'></a>

1 Platinum group metals
2 For Latin America CAGR is for 2005 to 2012, for Australia and Subsaharan Africa CAGR is for 2004 to 2013 and for North America CAGR is for 2006 to 2013

<a id='22d523a0-3249-4e43-aa26-e9f99943f3f1'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='b4525e30-ef76-4ed2-a06f-5b64e9c8b263'></a>

McKinsey & Company

<a id='29360179-b9ce-43bb-ac40-e8200c568cba'></a>

2

<!-- PAGE BREAK -->

<a id='04b5ca33-8031-49f3-ba13-308304c07c91'></a>

The industry also faces dramatic capital and operating costs escalations

<a id='28c2ec4e-dd1c-49ea-a9a0-0b5735966a41'></a>

MineLens Productivity Index indexed, 2004 = 100 CAGR,¹ 2004-13 %<::chart: A combined bar chart. The left section shows the "MineLens Productivity Index" with two bars: 2004 at 100 and 2013 at 72. An arrow points from 100 to 72, labeled "-3.5% p.a.". The right section displays four sets of bar charts, each comparing values for 2004 (indexed at 100) and 2013, along with their Compound Annual Growth Rate (CAGR). The categories are: 1. Production, mined volume: 2004 (100), 2013 (345), CAGR 14.8%. 2. Employment, number of workers: 2004 (100), 2013 (178), CAGR 6.6%. 3. Capital expenditures, asset value (indexed, 2004 = 100 in real terms²): 2004 (100), 2013 (1,681), CAGR 36.8%. 4. Operating expenditures, excluding labor cost (indexed, 2004 = 100 in real terms²): 2004 (100), 2013 (446), CAGR 18.1%. The x-axis for both main sections of the chart is labeled "2004" and "2013".::>

<a id='01cf8190-ced8-4b48-aa61-66f5dd5c2d2f'></a>

1 Compound annual growth rate
2 Capital expenditures and operating expenditures adjusted for mine cost inflation

<a id='43f25c66-864a-4e03-9f5b-f1d0efc0f97c'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='3f8a7846-5f86-46d2-9793-3686811908a4'></a>

McKinsey & Company

<a id='95d87aee-6c64-4651-921c-69e7f9448a99'></a>

3

<!-- PAGE BREAK -->

<a id='d16b8bc6-004f-4d11-a944-e8c58226657d'></a>

Mining companies can pursue 4 levers to thrive in
tomorrow's challenging and uncertain mining environment

<a id='2d261f54-7976-4b44-8d9a-51df86a748d3'></a>

Focus of this document

<a id='c42cc985-439c-40ad-bcc6-ac29d03600e6'></a>

<::Diagram titled "Levers for unlocking value": The diagram consists of a central box with the title, surrounded by four other boxes, each detailing a specific lever. The levers are: Embed effective Management Operating systems Free people and resources to prioritize productivity and operational excellence, drive robust performance management, working across silos and data-driven decision making; Focus on innovation Adopt fresh mindset to innovation, including technology adoption, advanced analytics and use of big data; Operations excellence Relentless focus on eliminating waste and variability, and improving productivity of assets through advanced reliability and maintenance approaches.; Capability building Upgrade individual and organizational capabilities to deliver the above.::>

<a id='84049673-58a5-45a4-80b4-b727682924a1'></a>

SOURCE: McKinsey Basic Materials Practice

<a id='5f903d2f-9ac1-4fa3-bf2e-156316cbe361'></a>

McKinsey & Company

<a id='fde21d2d-13be-4449-abf6-ee8a09887873'></a>

4

<!-- PAGE BREAK -->

<a id='818bacbf-224d-47a8-966b-90cb84cf65fa'></a>

Mining companies are increasingly looking at technological innovations to address the declining productivity trends

<a id='5fd66faa-14fd-4f11-b89e-6fe48e271655'></a>

"Now we need to protect our operating margins, we have to improve our working practices",. "**The company is moving towards full automation at it's mines,** "something we have been slow to progress in the past"
– *Diego Hernandez, CEO Antofagasta*

<a id='7dd62f3a-e1cd-449c-a60b-b3998fe90199'></a>

<::logo: Antofagasta PLC
ANTOFAGASTA PLC
The logo features an orange circular emblem with a stylized white mountain over three wavy lines, flanked by purple text.::>

<a id='7d787d48-fcce-4e0d-a1b3-5102c5d21176'></a>

<::SANDVIK
[Solid blue rectangle]
: figure::>

<a id='6352d2e7-15c6-4246-84e2-90d591535305'></a>

"Progressive mining companies are beginning to implement automated systems, with the **rest of the industry expected to follow suit**"
"Autonomous technologies represent a class of innovation that will profoundly change how minerals are mined and processed"

– ***Ken Stapylton, Vice President surface drilling, Sandvik***

<a id='8e76b215-dd63-469d-b172-c2ba94820ca4'></a>

SOURCE: Press search

<a id='d70e5cfd-3378-4644-afb8-d2b409abe825'></a>

McKinsey & Company

<a id='a8fee5ba-c401-4987-af1c-54c13ac300f1'></a>

5

<!-- PAGE BREAK -->

<a id='c27fb395-45da-4903-931f-5698c969ffdf'></a>

NOT EXHAUSTIVE
Focus of this documen

Advanced technologies are being developed and implemented
across all stages of the mining value chain
Commercially available
In testing
In developmer

<a id='6fcc9b18-beee-4a7b-8d5e-8f16a5cfaeaa'></a>

OEMs Status Expected commercial availability

<a id='270c466a-97db-4a18-a6af-94fb5f40b6f7'></a>

Exploration
<::image of two people in mining gear looking at a tablet/device in an outdoor setting; logos: GEOSOFT; progress indicator: dark blue solid circle; icon: compass-like icon::>
- Computer algorithm automatically
  detects patterns in exploration data
  indicative of mineralisation
Drilling
<::image of a drilling rig in an open-pit mine; logos: SANDVIK, CAT, Atlas Copco, FLANDERS; progress indicator: dark blue solid circle; icon: drilling machine icon::>
- All major OEMs offer products with
  various level of automation
- Other firms specialize in retrofitting
  existing drills for automation
Blasting
<::image of an explosion/blasting in a mine; logos: AEL Mining Services; progress indicator: circle with about 25% dark blue (quarter filled); icon: explosion cloud icon::>
- The charging process can be
  automated, with the required amount of
  explosive being entered beforehand
Loading
<::image of a large excavator/shovel loading material; logos: HITACHI, CSIRO; progress indicator: circle with about 50% dark blue (half filled); icon: excavator/shovel icon::>
- OEMs developing autonomous shovels
Hauling
<::image of a large mining haul truck with '131' on the side; logos: HITACHI, CAT, KOMATSU; progress indicator: dark blue solid circle; icon: mining haul truck icon::>
- Komatsu and Caterpillar have
  commercial offerings
- Hitachi running field trials
Other
support
equipment
<::image of a large yellow bulldozer; logos: HITACHI, KOMATSU, CAT; progress indicator: circle with about 50% dark blue (half filled); icon: bulldozer icon with a superscript '1'::>
- All major OEMs developing are
  developing autonomous solutions for
  support equipment like dozers,
  shearers, etc.
2008
2020
2025
1 Tele-remote dozers are already in quite extensive use; autonomous will take longer due to their irregular usage cycles

<a id='fc4943e5-3014-4791-8a2b-54403a6ed969'></a>

SOURCE: Expert interviews; Press search

<a id='fe76bc2f-2eb0-4b8b-94fe-8f60c3032541'></a>

McKinsey & Company

<a id='8bec978f-0b2c-4f6b-bed7-2083c34042e9'></a>

6

<a id='746557d9-abd6-4923-bfaf-cb7471baf2f4'></a>

Examples

<!-- PAGE BREAK -->

<a id='da0c96ba-d9b3-4b47-b335-81dc5baa4b50'></a>

**Multiple categories of advanced mining technologies are reaching commercialization and deployment stages**

<a id='25d7bfd1-41e9-4641-91cb-59dd5371b1e2'></a>

<::Legend: square color codes and their meanings
- Light blue square: Ideas and prototypes
- Medium blue square: Field testing and early adoption
- Dark blue square: Full scale commercialization
: legend::>

<a id='400db2a1-4b88-4ab7-a255-d3ad509a53ef'></a>

<::Timeline chart: The chart shows the evolution of autonomous mining technologies, divided into two main sections: A) Autonomous drills and B) Autonomous Haulage, over a timeline from 1970 to 2015. The x-axis represents years from 1970 to 2015.

A) Autonomous drills:
-   Late 1990s (implied before 2000): Atlas Copco demonstrates prototype at Mini Expo 2000 (with Atlas Copco logo).
-   Early 2000s: Atlas Copco partners with Rio Tinto to prepare drills for testing.
-   Mid 2000s: Sandvik and Atlas Copco developing drills in tandem for UG & OP applications.
-   Late 2000s/Early 2010s: Operational testing of Atlas Copco Pit Vipers (autonomous) by Boliden.
-   Mid 2010s: Rio Tinto tests fully autonomous bench drilling (with Rio Tinto logo).

B) Autonomous Haulage:
-   Early 1990s: CAT begins tests in USA (with CAT logo).
-   Mid 1990s: Komatsu begins tests in Australia (with Komatsu logo).
-   Early 2000s: First major commercialization: 11 trucks at Gaby mine (Codelco) (with Codelco logo).
-   Late 2000s/Early 2010s: Immersive technologies opens AH simulation training school (with Immersive Technologies logo).
: chart::>

<a id='6ce2b45f-efa9-46d5-8a9a-86b3c7547afc'></a>

<table id="7-1">
<tr><td id="7-2">What next?</td></tr>
<tr><td id="7-3">Hitachi is expected to make a number of autonomous solutions commercially available soon: AH trucks (2015), Shovels (2017), Graders and Dozers (2018)Many drills currently being operated semi-autonomously/tele-remotely (e.g., by Barrick, Codelco, Anglo American) but have capacity to be fully autonomous pending labor agreements and/or changes to operations</td></tr>
</table>

<a id='0545e75e-f5eb-44a8-bd17-550f20b82768'></a>

SOURCE: Expert interviews; Press search; McKinsey analysis

<a id='fddffc18-2f78-47cb-a297-f4370e20ea58'></a>

McKinsey & Company

<a id='ef963f3d-12f6-4bd7-81f4-f89db487b253'></a>

7

<!-- PAGE BREAK -->

<a id='d71057c7-6fb8-4ef4-b955-d1fc710c370e'></a>

A Automated drilling is the latest step in the long evolution of drill and blast technology

<a id='a7738673-9ac9-45f7-9f95-aa72be7f796e'></a>

Rio Tinto and Atlas Copco formed an alliance to work together to develop autonomous drilling solutions for surface mining <::A large yellow drilling rig with a tall mast is operating in an open-pit mine, surrounded by grey rock formations and dust.: photo::>

<a id='bcaf04e2-b61d-4f39-85d1-f0aab4894779'></a>

Atlas Copco and Rio Tinto successfully automated surface drilling, completing a computer-generated drill pattern

<::transcription of the content
: photograph of a sandy field with some sparse vegetation and hills in the background under a clear sky::>

<a id='a083bc88-0ef8-4f62-89ed-edf24a630a63'></a>

<::Timeline chart showing key events in the development of autonomous drilling rigs:
- **2006**:
  - Rio Tinto began to explore autonomous drilling rigs at Australia's Pilbara iron ore region.
  - Image: An aerial view of a large drilling rig operating in a reddish-brown open-pit mine, with a series of drilled holes visible on the ground.
- **2008**:
  - No event description provided. This year is marked on the timeline.
- **2011**:
  - Sandvik and Flanders formed a formal partnership to automate surface mining drill rigs and provide autonomous operation.
  - Image: A ground-level view of a yellow drilling rig with a tall mast, situated in an open-pit mine environment with hills or mountains in the background.
: timeline::>

<a id='c46cd3d1-4c8a-4f9a-aa3f-36562f82b74e'></a>

Rio Tinto became the first to achieve **fully automated** production bench **drilling** without human intervention at a test site in Australia <::A person is shown from behind, sitting at a desk in front of multiple computer monitors. One large monitor displays four distinct video feeds or data screens in a quadrant layout. A laptop is also visible on the desk to the right. This setup suggests a control room or monitoring station for the automated drilling operations.: photo::>

<a id='c3c55fea-fe4d-44cc-a8a5-9ae4be35d868'></a>

SOURCE: Press search; Company brochures

<a id='4591bb35-b77a-4232-a116-5eca040998d4'></a>

McKinsey & Company

<a id='638de9d0-d0fa-4c9c-b434-874d025f1857'></a>

8

<a id='4d37ef4f-606d-4555-b88a-ea0c86d932d4'></a>

<::A horizontal timeline with a right-pointing arrow. Two blue circular markers are placed on the timeline. The first marker is associated with the year "2013" written below it, and has a small grey dot above it. The second marker is associated with the year "2014" written below it, and has a small grey dot below it.
: timeline::>

<!-- PAGE BREAK -->

<a id='6a51483c-e596-4a80-802a-483886fe8fc3'></a>

B Autonomous haulage has three key components

<a id='cde2ef6b-ee0c-4859-850b-4240ae4afeed'></a>

Description

<a id='1faf9a0a-4ccd-4bec-98d6-9b01a9a42be3'></a>

1 Base vehicle & automa- tion kit

<::A large yellow mining truck.
: figure::>

2 Critical mine site infra- structure

<::A word cloud with "INFRASTRUCTURE" prominently displayed. Other words include: SUPERSTRUCTURE, ENVIRONMENTAL, MAINTENANCE, DEVELOPMENT, INSTALLATION, SYSTEM, MILITARY, TRANSPORTATION, SNOWBLOWERS, WATER, FINANCING, LAND, STANDARD, TENDERING, BREAKWATERS, GOVERNMENT, PIPELINE, SEWERS, SIGNALLING, ELECTRIC WORK, BUILDINGS, FACILITIES, LICENSING, IRRIGATION, ELECTRICAL, COMMUNICATIONS.
: figure::>

<a id='4fe54da3-38e2-4447-a0ae-f4f99a19b662'></a>

- Standard **truck body**
- Onboard embedded systems and real-time **operating software** informing and controlling the truck's activities (e.g., **sensors**, computers, video system, traction control, **GPS tracking**, and **radio receptivity for remote inputs**)

<a id='b846b810-85b3-4221-94a2-409793e0e2f3'></a>

- High-capacity **communications network**
- **GPS locators** for all vehicles within the orbit of AH trucks

<a id='01541567-8627-43b0-8f38-10d3922bb1f3'></a>

3 Command and control centre <::A photograph of a modern command and control centre. The room features a large, curved white desk equipped with numerous computer monitors displaying blue screens. Several black office chairs are positioned around the desk. In the background, there are larger screens or windows also displaying blue. : photo::>

<a id='929a6884-efbf-4854-8e8c-f1d74264d9ec'></a>

- **Headquarters** from which trucks monitored/remotely controlled
- Can be **on-site or off-site** (e.g., Rio Tinto is experimenting with controlling autonomous equipment from 1500km away)
- Operator ensures **adherence of vehicles to loading, dumping, and traffic management** plans, makes **adjustments** to vehicles' trajectories where necessary, and **restarts** the trucks in case of automatic shutdown triggered by trucks' safety protocols
- 1 operator can track the progress of **numerous vehicles**

<a id='fd839241-d16a-4a43-857f-86f2713cacf9'></a>

SOURCE: Expert Interviews; McKinsey Analysis

<a id='a8902c74-02bc-4e99-94e8-3046773afb24'></a>

McKinsey & Company | 9

<!-- PAGE BREAK -->

<a id='4e6ee57b-f5c0-48ef-9e9c-289afbd3932f'></a>

Innovation is key to overcome scarcity issues in rare raw materials

<a id='53b982be-1baf-4c3f-93ea-0418c0117b4e'></a>

NON-EXHAUSTIVE

<a id='51c1d5df-563b-4165-b527-8c8ed7528fb9'></a>

<::
Solid blue circle: Heavy" 
Outlined blue circle: Light
Icon with circular arrows: Size of the bubble indicates resource size
: chart::>

<a id='5f582976-b10d-4d4c-bf8d-e6d35abdc6d1'></a>

## Levers to drive change

*   Effective management systmens
*   Operational excellence
*   Innovation across the whole supply chain
*   Capacity building

<a id='6671fdee-a729-4677-8970-1c6334b17b75'></a>

<::Bubble chart titled "Ore grade % TREO" on the y-axis (ranging from 0 to 10) versus "Minimum lead time Years" on the x-axis (ranging from 1 to 13). The x-axis also shows project stages: Ramp-up (1 year), Construction (2-5 years), Feasibility (6-7 years), Pre-feasibility (8-10 years), and Drilling (11-13 years). Each bubble represents a project, with its size possibly indicating project scale or resource size. Projects shown include:
- Mount Weld: High ore grade (around 9.5% TREO), 1 year lead time (Ramp-up).
- Mountain Pass: High ore grade (around 6.5% TREO), 1 year lead time (Ramp-up).
- Mount Weld Duncan: Around 5% TREO, 6 years lead time (Feasibility).
- Araxá: Around 4.5% TREO, 10 years lead time (Pre-feasibility).
- Strange Lake: Around 3% TREO, 5-6 years lead time (Construction/Feasibility).
- Ngualla: Around 2% TREO, 10 years lead time (Pre-feasibility).
- Nechalacho: Around 1-2% TREO, 9 years lead time (Pre-feasibility).
- Niobec: Around 1-2% TREO, 7-8 years lead time (Feasibility).
- Dubo: Around 1% TREO, 3-4 years lead time (Construction).

A callout box points to Mount Weld and Mountain Pass, stating: "Two large projects close to production, focused on light rare earths."

Below the chart, there is a caption: "Long term industry sustainability requires additional projects at later stages of the project pipeline.": chart::>

<a id='e2c2b7b2-6131-403c-8ec3-dbc2cdcad9ce'></a>

1 Heavy rare earths projects are the ones with more than 15% of total rare earth content of heavy elements

<a id='00cfe1c4-5c9b-47ef-a41d-e129bc939fc4'></a>

SOURCE: Technology Metals Research, expert interviews

<a id='1162a79f-8c20-47fe-95b5-f6c06471193c'></a>

McKinsey & Company

<a id='cef48b5b-c59e-42bf-afd6-308a5c57527c'></a>

10

<!-- PAGE BREAK -->

<a id='7a74272b-80a4-4641-9c17-16a909b5d103'></a>

BACKUP (Presented on ad-hoc basis if there are questions)

<a id='ae349987-752d-4ab9-9054-236854ffb652'></a>

McKinsey & Company

<a id='a3d54c7b-28d2-4de3-a328-e65ea936f676'></a>

11

<!-- PAGE BREAK -->

<a id='26871963-3e7f-4777-9c25-6e87e1d61994'></a>

Executive summary

<a id='a056e7eb-fb52-41c9-ac1e-910087682562'></a>

▪ Multiple forces at work, such as labour scarcity, rising costs of inputs, increased health and safety standards, and declining productivity, have been putting **significant pressure on the mining industry** in the last decade, e.g.,

	– Average copper mine input costs have risen ~150% in the past 15 years
	– In 10 years, productivity in some of the world's major mining hubs has declined by up to 50%
▪ Mining companies are **increasingly looking at technological innovations** to address these trends, with a view to reducing costs and increasing productivity
▪ Development, testing and implementation of high-tech solutions in mining have **exploded in the past 15 years**, with advanced technologies being developed and implemented across all stages of the mining value chain, from exploration to hauling and dozing
▪ There is an increasing sense among all sizes of mining companies that “**the future is now**”, and that the best-performing companies in the next decades will be the one willing to assume the costs of implementing advanced technologies during this challenging period
▪ Examples of the most promising and most developed advanced technologies include

	– **Autonomous haulage**, which has been implemented at ~25 sites and can **reduce overall haulage costs 10-40%**
	– **Autonomous or tele-remote drilling**, which has been trialled at nearly 20 sites, with demonstrated increase of both available drilling time per shift and **drilling/blasting accuracy**, leading to a **knock-on impact on downstream processes**

<a id='ce86d250-7dd9-4fcc-a4eb-1df3f472e62c'></a>

nging period
dvanced tech
ed at ~25 site:

<a id='0959dd5a-d58e-424c-bc7a-721173668a43'></a>

McKinsey & Company

<a id='6ccde147-e158-445b-a130-0082735b91f4'></a>

12

<!-- PAGE BREAK -->

<a id='21b37049-0861-4e9d-9f49-7fbd19bc6ad3'></a>

The mining industry faces multiple forces which will adversely impact industry economics going forward

<a id='15edad66-7e4b-47ba-aba3-407fc135cd8b'></a>

<::figure: This is a diagram showing a central image of an open-pit mine, surrounded by eight octagonal shapes, each representing a force influencing the future of mining. From top to bottom, clockwise, these forces are:  Continuously increasing safety, health and environment standards (represented by a light blue octagonal shape with light blue wavy lines). Rising cost of production inputs (represented by a light blue octagonal shape with light blue arrows pointing upwards). Demand growth fueled by population growth and socio-economic changes (represented by a light blue octagonal shape with light blue abstract figures and an upward arrow). Declining productivity (represented by a dark blue octagonal shape with a red downward arrow and a grid pattern). Labor scarcity (represented by a grey octagonal shape with light grey human figures). Increasing price volatility (by-product credits) (represented by a light blue octagonal shape with a magnifying glass over a red wavy line graph). Increasingly challenging geologies (represented by a light blue octagonal shape with a light blue maze pattern). Global sourcing changing equipment industry structure (represented by a dark grey octagonal shape with light blue abstract gear-like shapes).::>

These forces will have determine how mines are set up and run in the future

<a id='ad7da551-117d-4094-a33a-9fbb41b5ba47'></a>

SOURCE: McKinsey Basic Materials Practice

<a id='2e176b1c-d84f-4b20-9793-af9973fd3487'></a>

McKinsey & Company

<a id='922e1bc0-b154-4eff-96a0-9472fb3520ea'></a>

13

<!-- PAGE BREAK -->

<a id='4fd2f409-5d8b-4d13-aacd-f101cb57edc9'></a>

The McKinsey Mining Productivity Index reveals that mining productivity
globally has declined 3.5% p.a. over the past decade

<a id='3f23409b-f8b5-4cd7-abbc-2266fe4a5050'></a>

McKinsey Mining Productivity
Index, 2004 = 100

<a id='7fe2b8d7-2015-4432-84ea-2683e66ff535'></a>

Approach
<::line chart: Index, 2004 = 100
Y-axis: Index values from 65 to 110
X-axis: Years from 2004 to 2013

Two lines are plotted:
1. Light blue line: Represents an index starting at 100 in 2004 and fluctuating downwards, ending around 72 in 2013.
2. Dark blue line: Represents an index starting at approximately 105 in 2004 and generally declining.
   - From 2004 to approximately 2008, the average annual decline is indicated as "-6.0% p.a.".
   - From approximately 2008 to 2013, the average annual decline is indicated as "-0.4% p.a.".
   - An overall average annual decline for the period 2004-2013 is indicated as "-3.5% p.a." associated with this dark blue line.::>

*   McKinsey Mining Productivity Index computed using global data set comprising
    *   Detailed data at mine-site level for ~50 mines from all major mining jurisdictions
    *   10 years of performance data
*   All values indexed to 2004 = 100

*   Between 2004 and 2013, global mining productivity has fallen ~30%, or 3.5% p.a., even after accounting for geological degradation

<a id='dac53875-f922-4d17-9bc3-f9991834be4d'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='5194c76f-4db4-49c5-9260-0d0a5ae6fa36'></a>

McKinsey & Company

<a id='f5efa585-d4ea-4742-9e80-3a6d9990e33b'></a>

14

<!-- PAGE BREAK -->

<a id='9b42221f-df55-4110-bcee-b271c98e4aa8'></a>

Mining companies are increasingly looking at technological innovations to address the declining productivity trends

<a id='a791008c-1fcf-4e6f-8ac7-dd3eca8f6b1c'></a>

<table id="15-1">
<tr><td id="15-2">&quot;Where we&#x27;re really behind, shamefully behind, is in the issue of productivity&quot; – Thomas Keller, CEO Codelco; April 2014, CRU World Copper Conference, Santiago</td><td id="15-3">&quot;With our Southdowns project (Western Australia), we are able to vastly improve the economics by steepening the walls and improving the strip ratio because we have proven methods and [remote control drill, rock-breaker and explosives loader] technology to manage those steeper walls&quot; – Matthew Andersson, Mining Manager, Grange Resources</td></tr>
<tr><td id="15-4">&quot;Declining productivity is now a problem we share&quot; - Paul Dowd, Director OZ Minerals</td><td id="15-5">&quot;Progressive mining companies are beginning to implement automated systems, with the rest of the industry expected to follow suit&quot; &quot;Autonomous technologies represent a class of innovation that will profoundly change how minerals are mined and processed&quot; – Ken Stapylton, Vice President surface drilling, Sandvik</td></tr>
</table>

<a id='079d17da-dc96-4c7b-800f-353a92fbef8b'></a>

"Now we need to protect our operating margins, we have to improve our working practices",. "The company is moving towards full automation at it's mines, "something we have been slow to progress in the past"

– *Diego Hernandez, CEO Antofagasta*

<a id='490c963e-ef61-4dfe-8277-721e651a7806'></a>

SOURCE: Press search

<a id='1d1b8eb7-154b-44e1-9ab4-97b5d339e4d1'></a>

McKinsey & Company

<a id='89c3b881-0b97-4382-9b1a-2fb85f0e5353'></a>

15

<!-- PAGE BREAK -->

<a id='71adb829-cb33-4a13-b129-fe3cc003b802'></a>

Autonomous equipment-enabled open-pit mines rely on the careful and coordinated interplay of the mine-wide control systems and equipment

<a id='39eba4d7-6c8f-46ff-8ab4-1a00c96674af'></a>

<::The image is a detailed diagram illustrating a smart mining operation within an open-pit mine. The background shows an aerial view of a large, terraced open-pit mine. Various components of the smart mining system are depicted as icons with accompanying text labels, connected by yellow wavy lines representing wireless communication and data flow. The components are:

- **Control centre**: Located at the top left, an icon shows a control room with multiple monitors, a desk, and a chair, with a person operating it. The text associated is: "Control centre On-site and/or remote. Includes autonomous fleet management software and live monitoring/feedback". Wireless signals emanate from the control centre towards the mine.
- **Mine LAN and radio communications**: A text box in the upper middle of the mine reads: "Mine LAN and radio communications". Yellow wavy lines radiate from this box, indicating network coverage across the mine.
- **Conveyors**: At the top right, an icon displays a conveyor belt system used for transporting materials. The text label is: "Conveyors".
- **Rock breaker**: An icon of a tracked excavator with a breaking attachment is shown on the left side of the mine. The text label is: "Rock breaker".
- **Loaders**: An icon of a front-end loader is depicted in the upper middle left. The text label is: "Loaders".
- **Drills**: An icon of a drilling rig is positioned in the middle right of the mine. The text label is: "Drills".
- **Smart equipment**: This is a general label located in the lower middle, referring to the various pieces of automated mining machinery.
- **Haul trucks**: An icon of two large mining haul trucks is shown in the lower left. The text label is: "Haul trucks".
- **Dozers**: An icon of a bulldozer is located in the bottom middle. The text label is: "Dozers".
- **Ore tagging**: On the right side, an icon depicts an RFID tag with a wireless signal radiating from it. The text associated is: "Ore tagging RFID Tag RFID signal".
- **Blast charging**: At the bottom right, an icon represents an explosion, indicating blasting activities. The text label is: "Blast charging".

All these elements are interconnected by the yellow wavy lines, symbolizing a comprehensive, wirelessly connected smart mining environment.: figure::>

<a id='7f7192ac-989f-4c8f-8066-e625f76e37b2'></a>

Control centre
On-site and/or remote.
Includes autonomous fleet
management software
and live
monitoring/feedback

<a id='b81ed584-0845-4202-9be9-d0bc5fb7efb1'></a>

<::On a textured grey background, partially visible on the top left are two grey wheels with blue centers. Below them, a dark blue rectangular label reads "Haul trucks". On the right, a stylized blue illustration of a tracked vehicle, resembling a bulldozer, is depicted. Partially visible dark blue rectangular shapes are present above and below the bulldozer illustration.: figure::>

<a id='bbe4c4bf-ba8d-49d8-a7bf-67c50ba27a20'></a>

<::logo: [Unknown]Blast chargingA blue cloud-like shape with a dark blue outline is centered over a dark rectangular background with text.::>

<a id='cffe21d1-2007-4a0c-8e6d-3df222fe59c3'></a>

SOURCE: Expert Interviews; Sandvik webpage; Caterpillar webpage; Metso webpage; Transmin webpage

<a id='5cf6db7e-b9c6-4422-9390-6588a8ea1e03'></a>

McKinsey & Company

<a id='96b07e0e-b7c1-4d08-83b8-bf93e797f557'></a>

16

<!-- PAGE BREAK -->

<a id='e5324d9d-c8e7-4861-8561-50b27287b12d'></a>

Different degrees of autonomy in haul trucks

<a id='e6482e72-562e-4b87-ba31-23ca94d2e075'></a>

Semi-autonomous trucks

<a id='833abe5c-06b8-4959-8072-c7cddef8a4f6'></a>

Fully autonomous trucks

<a id='0fe31d7b-c5a0-46bb-a5aa-89d274951144'></a>

<::Image of car steering wheel buttons. The buttons are silver-grey. From top to bottom, left to right:
- Top left: "CRUISE" button.
- Top right: A rocker switch with "RES+" on the upper part and "SET-" on the lower part.
- Bottom left: A button with a steering wheel icon that has a heating symbol (three wavy lines) above it, indicating a heated steering wheel function.
- Bottom right: "CANCEL" button.
The image also shows a reflection of these buttons below them.
: figure::>

<a id='d642e7d8-2f66-49d0-95e9-ce138507e241'></a>

<::A large yellow Caterpillar (CAT) mining dump truck, seen from a rear-three-quarter angle, with "CATERPILLAR" visible on the top of the bed and "CAT" on the side near the cab. The truck has massive wheels and is on a dirt or gravel road, with a reflection of the truck below it.: figure::>

<a id='339352c3-a015-456d-8ffc-c672be318a0c'></a>

* Driver still present in vehicle
* Vehicle has a form of "cruise control" for the length of the haul route
* Driver tends to reassume control for loading and dumping, and whenever an obstacle presents itself (e.g., manned vehicle, obstruction in the road)

<a id='8670d2c3-845c-4f01-b53d-dcea0fb16cdf'></a>

- All stages of haul cycle are autonomous
- No operator is required in vehicle
  - One operator can oversee multiple trucks simultaneously from a remote control centre
  - Command centre can be on- or off-site
- There are currently 3 archetypes of fully autonomous trucks (_detailed next page_)

<a id='9d2dff97-1949-44c9-b4f0-a2edf65c530c'></a>

SOURCE: Expert interviews

<a id='08baf963-ba2b-440a-80b5-8ca93541f695'></a>

McKinsey & Company

<a id='e2ebcaba-7bfa-4129-8cad-647a6a7be8b1'></a>

17

<!-- PAGE BREAK -->

<a id='696eb7ec-e2ee-4569-b4fb-1e4ca6a632db'></a>

BASE VEHICLE AND AUTOMATION KIT
Key on-board components of autonomous haul trucks

<a id='b237e72e-d89e-4ec9-9998-03aa89234818'></a>

Autonomous Control Cabinet
Sealed hydraulic and electronic
controls

GPS
GPS technology is
combined with a
tracking system to
accurately monitor
location of vehicles

Autonomous
Status Lights
Mounted on all
sides of the truck to
safely display truck
operating status

Road Edge
Guidance (REG)
A mounted laser
guidance system
measures the dis-
tance to the road
berm to provide
additional naviga-
tion accuracy

<a id='7e51b0cd-95eb-441a-867b-de4504e6f606'></a>

<::Photograph of a large yellow Komatsu HD985 mining dump truck, with "259" visible on its side. A white oval highlights a cylindrical component near the front wheel.: figure::>
<::Diagram of an optical fiber gyro showing a coiled fiber with an arrow indicating rotational motion. Optical fiber gyro Senses changes in orientation using interference from light: diagram::>

<a id='af68c0e3-ea74-4d7c-912d-0ddc60632ac2'></a>

<::An image showing the front and top view of a yellow autonomous vehicle equipped with multiple sensor units, including what appear to be radar or LIDAR sensors mounted on the front and on an elevated platform. The vehicle has a rugged design. This image illustrates object avoidance sensor technologies.: figure::>
- **Object avoidance** (e.g., radar with 80m range, LIDAR with 20m range at sides and rear)
- These sensor technologies are still in their infancy
  - Overall they have been working effectively in dry, clear climates such as in Australia or the Atacama desert
  - They have much lower reliability in fog or rain, which has impeded adoption of AH technology in more temperate climates
  - In the next few years, some AH sensor manufacturers will likely turn to military sensors to improve availability and reliability; however, doing so is currently cost-prohibitive 

<a id='027c7441-2c62-4c00-8625-02cef1f6b64c'></a>

SOURCE: Expert Interviews; University of British Columbia; Caterpillar; Komatsu

<a id='37de7105-b894-40ff-8294-3de977dffa2d'></a>

McKinsey & Company

<a id='e1cf8c86-139a-4fb4-9dc3-76114bc5f2e5'></a>

18

<!-- PAGE BREAK -->

<a id='75b578a7-ea2b-43c8-ab78-f6134ba9c08a'></a>

Communications technology is vital for relaying commands from the control centre to the vehicles, and for managing vehicle interactions

<a id='ec5e8d5e-0062-4209-8c8c-a1dc2333f9e2'></a>

## Communications technology

-   Open-pit communications tend to rely on **satellite/GPS, wi-fi and/ or RFID**
    -   This requires antennas / **boosters** around the site
    -   Each individual vehicle, and possibly personnel, must also be **tagged** (tele-remote and manned) with **positional trackers**, in order to minimize interactions with operational tele-remote vehicles (for reasons of safety and productivity)
-   System must have enough **bandwidth** to
    -   Relay **live video** feeds to the central control room
    -   Provide up-to-date tracking of all **vehicle locations**
    -   Convey **real-time commands** from the command centre to the tele-remote or autonomous systems

<a id='fda3b91b-9d49-4ded-ac92-636376a5b159'></a>

McKinsey & Company

<a id='9ccc5e7f-1754-4b62-a57e-14da6b6eafc8'></a>

19

<!-- PAGE BREAK -->

<a id='f8818340-a8b8-45f9-9141-61e99f3f09c8'></a>

**Autonomous haulage has multiple safety and efficiency benefits**

<a id='6d4e8bd9-5c2a-4f5e-a42a-597c3a7e9865'></a>

- Favourable impact on economics
- Adverse impact on economics

<a id='307a0223-e049-4323-9951-e6f32da6db76'></a>

<table><thead><tr><th>Category</th><th>Lever</th><th>Impact range</th><th>Rationale for impact</th></tr></thead><tbody><tr><td>Safety</td><td>Safety</td><td><br>Green circle</td><td><ul><li>Fewer people in dangerous areas</li></ul></td></tr><tr><td>Mine design</td><td>Strip ratio</td><td><br>Green circle - 0-5%</td><td><ul><li>Fewer people in pit enables steeper pit walls and thus ability to reduce strip ratio</li></ul></td></tr><tr><td>OEE<sup>1</sup></td><td>Utilization</td><td><br>Green circle - 10-30%</td><td><ul><li>Eliminate shift-change delays; reduce delays due to traffic congestion</li></ul></td></tr><tr><td></td><td>Availability</td><td><br>Green circle - 10-30%</td><td><ul><li>Reduced unscheduled downtime from more consistent usage cycles and reduced damage</li></ul></td></tr><tr><td></td><td>Truck speeds</td><td><br>Green circle TBD</td><td><ul><li>Higher truck speeds as fewer people in mine areas; truck speeds more consistent</li></ul></td></tr><tr><td>Operating and maintenance costs</td><td>Labor</td><td><br>Green circle Up to -95%</td><td><ul><li>Fewer (or zero) operators</li></ul></td></tr><tr><td></td><td>Fuel</td><td><br>Green circle - 5-10%</td><td><ul><li>Lower fuel consumption from more consistent driving cycles</li></ul></td></tr><tr><td></td><td>Tires</td><td><br>Green circle - 5-10%</td><td><ul><li>Improved tire life due to more consistent speeds and driving patterns</li></ul></td></tr><tr><td></td><td>Maintenance</td><td><br>Green circle - 10-20%</td><td><ul><li>Lower maintenance parts and labour costs from reduced wear and accident damage</li></ul></td></tr><tr><td>Capex</td><td>Truck capex</td><td><br>Red circle ~500k autonomy kit</td><td><ul><li>Higher truck cost due to additional equipment and sensors on trucks</li></ul></td></tr><tr><td></td><td>Infrastructure capex</td><td><br>Red circle<ul><li>Hub ~$1m</li><li>Communications upgrade ~$15k</li></ul></td><td><ul><li>Infrastructure costs for communications infrastructure, refueling system</li></ul></td></tr></tbody></table>

"The main benefits are in operating labour costs (down about 2/3) and optimized productivity (avoiding downtime and operating at a faster and safer cycle time)"
- AH electrical systems specialist

"During our first trials, we were already able to reduce exposure of our workers to danger areas by ~70%"
- Mine manager

"Capex costs are high, though of course they also depend on the pre-existing level of infrastructure, like for communications. That said, the upside of AH is significant"
- AH developer

<a id='8af42814-94ca-4d06-9b68-a22af2958691'></a>

1 OEE: Overall Equipment Effectiveness

<a id='8148abb3-636d-4f4a-a6c8-1aee9e914795'></a>

SOURCE: Expert interviews; Press search

<a id='fc11aeb9-808f-4eed-bbf7-a4d0ff3c1886'></a>

McKinsey & Company

<a id='196c22ca-3400-42bb-a880-837b5ff4c985'></a>

20

<!-- PAGE BREAK -->

<a id='1a20335e-406d-416e-8ca6-1456da43359c'></a>

AUTONOMOUS HAULAGE

<a id='767f001a-5c72-4f19-b9bb-454db50fc030'></a>

Autonomous haulage can be a game changer in mining
productivity: 10% to 40% reduction in haulage costs
Hauling costs – USD c/ton

<a id='3ce7fa24-402a-4671-aa04-8dd1ca31fea4'></a>

PRELIMINARY

<a id='e2d9ca6d-f04b-40b2-ad50-bab7def5e24c'></a>

High labor cost locations, e.g. remote
Australian mines, Canadian oil sands
$350K fully loaded, operator cost

<a id='996bc1be-b4b4-4c7b-9809-0a46de954f66'></a>

Low labor cost locations, e.g. Africa, Asia
$35K fully loaded, operator cost

<a id='b970d5b2-6f7c-4dcc-ac86-aeffe341424d'></a>

<::bar chart: Cost breakdown and comparison between Manual Fleet and Autonomous Fleet::>Visual Content: The chart displays a breakdown of costs and operational impacts for a Manual Fleet versus an Autonomous Fleet. It is structured into sections: Mine design, OEE¹, Operating and maintenance costs, and Capex. Each section shows a value for Manual Fleet and Autonomous Fleet, with sub-categories contributing to the total.

**Manual Fleet Data:**
- **Mine design:**
  - Initial value: 67.47
  - Strip ratio: 0
  - Total for Mine design: 67.47
- **OEE¹:**
  - Availability: -0.72
  - Utilization: -3.82
  - Truck speeds: 0
  - Total for OEE¹: 62.93
- **Operating and maintenance costs:**
  - Labor: -20.37
  - Fuel: -1.72
  - Tires: -0.50
  - Maintenance: -0.64
  - Total for Operating and maintenance costs: 39.69
- **Capex:**
  - Truck: 0.96
  - Infrastructure: 0.08
  - Total for Autonomous fleet (likely a cumulative total for Manual Fleet scenario): 40.74
  - Overall change: -40%

**Autonomous Fleet Data:**
- **Mine design:**
  - Initial value: 45.41
  - Strip ratio: 0
  - Total for Mine design: 45.41
- **OEE¹:**
  - Availability: -0.27
  - Utilization: -1.41
  - Truck speeds: 0
  - Total for OEE¹: 43.74
- **Operating and maintenance costs:**
  - Labor: -2.04
  - Fuel: -1.72
  - Tires: -0.50
  - Maintenance: -0.64
  - Total for Operating and maintenance costs: 38.83
- **Capex:**
  - Truck: 0.96
  - Infrastructure: 0.08
  - Total for Autonomous fleet: 39.88
  - Overall change: -12%

Conclusion bar: Autonomous trucks can reduce surface haulage costs by up to 40%

<a id='f4e8c2c5-0b26-4c19-b1c9-8ac09e447dc4'></a>

1 OEE: Overall Equipment Effectiveness

<a id='a2bf68a9-e929-4d63-b30e-a500ca8e7f2a'></a>

SOURCE: Team analysis; based on client mine plan

<a id='087bda68-162d-41d8-961a-465c01c0edd0'></a>

McKinsey & Company | 21

<!-- PAGE BREAK -->

<a id='07a09f95-c7cb-42aa-acb2-4efe52e4f62b'></a>

To date, there have been ~25 autonomous haul truck
trials, most of which have taken place in Australia

<a id='625b1a9b-864a-4353-a19c-894d6670524d'></a>

<::diagram: A grey flag-like shape with two rectangular boxes inside. The top box is empty and has a line pointing to the text "Mine site". The bottom box contains three dots (...) and has a line pointing to the text "Year tests began".::>

<a id='a20c0c58-1c71-4b99-a3c1-f98c01b06799'></a>

Current trial and/or implementation locations

<a id='60cfe0a1-de4b-4c54-bb9c-445fb3ee584d'></a>

<::Logos:
- Orange dot: SANDVIK
- Blue dot: HITACHI Inspire the Next
- Light blue dot: CATERPILLAR
- Dark blue dot: KOMATSU
- Green dot: ASI
- Yellow dot: NB logo::>

<a id='5029e408-3f6c-4c6e-9106-48e1e509aa10'></a>

<::A world map with North America and Europe visible. North America is mostly gray, but the contiguous United States and Alaska are highlighted in blue. In the southwestern USA, a green flag is labeled "Navajo Coal" with the year "2006". Below it, a logo reads "F-M". In the southeastern USA, a light blue flag is labeled "..." with the year "2006". Below it, a logo reads "bhpbilliton". In Europe, the map is gray, but Sweden is highlighted in blue. In northern Sweden, an orange flag is labeled "Kiruna" with the year "2010". Below it, a logo reads "LKAB".
: map::>

<a id='1ca915af-a1c6-4f3e-b39c-38047ace7d4c'></a>

<::A world map displaying various mining locations and their associated companies and years. The map is light grey, with Australia highlighted in dark blue. Mining locations are marked by flags of different colors connected to points on the map. The flags include: Kiruna (orange flag) in Northern Europe, 2010, with the LKAB logo. Finsch (orange flag) in Southern Africa, 2005, with the Petra Diamonds logo. In Australia, locations include: Yandi-coogina (dark blue flag), 2012, Rio Tinto. West Angelas (dark blue flag), 2010, Rio Tinto. Nam-muldi (dark blue flag), 2012, Rio Tinto. Hope Downs (dark blue flag), 2013, Rio Tinto. Meandu (dark blue flag), 2014, with the stanwell logo. Solomon (light blue flag), 2013, with the FMG Fortescue logo. Jimblebar (light blue flag), 2013, with the bhpbillitan logo. Two TBD (yellow flags), both 2015, with the bhpbillitan logo. These Australian locations are predominantly in Western Australia, with Meandu and one TBD location in Eastern Australia.: map::>

<a id='431dde98-1ea0-4423-8a9e-c6848a24025b'></a>

<::Timeline on a map of South America:
- The map shows South America with a portion, likely Chile, highlighted in blue.
- A vertical timeline has two points:
  - Top point: A blue flag with the text "Gabriela Mistral" and the year "2009". Below this, a brown logo with a stylized 'C' and the text "CODELCO".
  - Bottom point: A blue flag with the text "Radomiro Tomic" and the year "2005". Below this, the same brown "CODELCO" logo.
: timeline::>

<a id='0e6f5768-cc44-418d-af96-f678dbca3523'></a>

SOURCE: Press search

<a id='5f8f54db-1eb1-4470-a6e8-92896c9831c7'></a>

McKinsey & Company

<a id='066d6297-651c-4318-98fd-bbb226842065'></a>

22

<!-- PAGE BREAK -->

<a id='26691868-1587-44ea-a269-9a1d5653d12d'></a>

Automated drilling is the latest step in the long evolution of drill and blast technology

<a id='aaf12aa5-e8b0-4eed-9104-5e4caa7db889'></a>

<table id="23-1">
<tr><td id="23-2">Manual drilling and blasting</td><td id="23-3">The beginnings of mechanization</td><td id="23-4">Towards current-day drills</td><td id="23-5">Drill-assist and autonomous drills</td></tr>
<tr><td id="23-6">Gunpowder invented ~1000AD, but are no references to applications to mining until 16th century One man drilling (using a steel drill and sledgehammer) most common approach into the 20th century</td><td id="23-7">First steam driven percussion rock drills were invented in early- 1800s, but adoption slow Alfred Nobel invented the blasting cap and safer dynamite explosives through the 1860s However, mechanized drill productivity still low. In 1870, at a US drilling competition, John Henry hammered through 14 ft of rock in 35 minutes His steam drill &quot;competitor&quot; only managed 9 ft</td><td id="23-8">Late 1800s-early 1900s: steam replaced by compressed air, and invention of the jackhammer 1945: Sandvik, Atlas and Fagersta designed a cemented tungsten carbide drill bit as economical to use as the conventional steel bits Post-war, drill rig mechanization sped up, with a strong emphasis on increasing mobility Hydraulic technology for rotary and downhole drilling also became available in the 1960s</td><td id="23-9">Drive towards automated drills picked up momentum with unveiling of the Atlas Copco Pit Viper 351 with CAN-bus control and 7 on-board computers at MineEXPO 2000 Sandvik and Atlas Copco lead the pack, with automated drills (with various degrees of automation) being tested and implemented around the world</td></tr>
</table>

<a id='c5727fd0-4591-4f3f-b997-944de7319bee'></a>

SOURCE: Atlas Copco Blasthole Reference Book 2013, Sandvik

<a id='d91e98a0-5cf3-46fc-b588-f867bc41aae0'></a>

McKinsey & Company

<a id='cc42ba65-f08d-4332-b0d3-696dab776a17'></a>

23

<!-- PAGE BREAK -->

<a id='e2759cde-925c-41cc-9376-041222028827'></a>

Tele-Remote/Autonomous Drill

<a id='9a328b2d-8c37-46e1-a3af-5aabfc837127'></a>

<::image of a hazard avoidance camera mounted on a yellow/orange structure against a blue sky. Hazard avoidance cameras See depths details and determine hidden range of obstacles::>

<a id='a5c52a0f-5c5a-4aab-ba0b-b6fd41972e21'></a>

**High-resolution video**
Transmit video back to the command center
* Enhance visibility
* No blind spot

<a id='d53ebc68-321f-4fc5-8519-6bab23d57a4e'></a>

<::A large, white and orange tracked drilling rig, labeled "EDD0165", is shown on a dirt or gravel surface under a blue sky. The rig has a prominent drilling mast and a control cabin with windows. Dust is visible around the base of the machine.: figure::>

<a id='d2432219-497b-4dd5-86c0-a7cbff912c3e'></a>

<::An image depicting a drilling rig on a sandy, barren landscape. Red lines crisscross the ground, forming a geo-fence around the rig. Numerous small red markers are scattered across the terrain within the fenced area. Two white circles with light blue outlines highlight specific points along the red geo-fence lines. To the right of the image, the text reads: Geo-fencing sensors Prevent tramming into hazards: figure::>

<a id='d8431efe-b3f8-4810-a77e-9b1192d63aa2'></a>

High-speed on-board computer control
*   Geological information
*   Drilling times
*   Penetration rates
*   Navigation & traffic
*   Machine diagnostics
<::An illustration of a drilling rig, viewed from a slightly elevated angle. The rig is a large, complex piece of machinery with a tall mast, various platforms, and mechanical components. It appears to be situated on a barren, dark ground surface. Overlaid on the rig are glowing blue lines and a prominent glowing blue cube, suggesting digital monitoring, data flow, or sensor points on the equipment.
: illustration::>

<a id='c7897a86-14f3-4427-952f-ade4bbe61cb0'></a>

SOURCE: Sandvik

<a id='23d51ed7-3a55-42d7-a7dc-11778bc997ea'></a>

McKinsey & Company

<a id='326ba556-85ce-4949-8ed5-9a2b4d4f0940'></a>

24

<!-- PAGE BREAK -->

<a id='d145feb9-c4e2-457a-801a-5bcb1780ea55'></a>

Tele-Remote and Autonomous drilling have significant potential

<a id='5b4e9e45-7cb0-4ca8-b4fe-1f5e828de1f4'></a>

Favorable
Adverse

<a id='309e43d3-62d2-469b-aa9a-0c551ef4f69f'></a>

<table id="25-1">
<tr><td id="25-2"></td><td id="25-3"></td><td id="25-4"></td><td id="25-5" colspan="2">Impact range</td><td id="25-6">(image of a gauge)</td></tr>
<tr><td id="25-7">Category</td><td id="25-8">Lever</td><td id="25-9">Impact</td><td id="25-a">Tele-remote</td><td id="25-b">Autonomous</td><td id="25-c">Rationale for impact</td></tr>
<tr><td id="25-d">Safety</td><td id="25-e">Safety</td><td id="25-f">(image of a thumbs up)</td><td id="25-g"></td><td id="25-h"></td><td id="25-i">▪ Fewer people in dangerous areas</td></tr>
<tr><td id="25-j" rowspan="4">OEE¹</td><td id="25-k">Availability</td><td id="25-l">(image of a thumbs up)</td><td id="25-m">0-10%</td><td id="25-n">0-15%</td><td id="25-o">▪ Reduced unscheduled downtime from more consistent usage cycles and reduced damage</td></tr>
<tr><td id="25-p">Utilization</td><td id="25-q">(image of a thumbs up)</td><td id="25-r">0-10%</td><td id="25-s">0-15%</td><td id="25-t">▪ Eliminate shift-change delays; reduce time lost to blast cycle</td></tr>
<tr><td id="25-u">Drill speeds</td><td id="25-v">(image of a thumbs up)</td><td id="25-w">0-3%</td><td id="25-x">0-3%</td><td id="25-y">▪ Algorithm reduces variation across fleet</td></tr>
<tr><td id="25-z">Redrilling and over-drilling</td><td id="25-A">(image of a thumbs up)</td><td id="25-B">50%</td><td id="25-C">75%</td><td id="25-D">▪ Algorithm controls drilling reduces chances of error</td></tr>
<tr><td id="25-E" rowspan="6">Operating and maintenance costs</td><td id="25-F">Drill rig labor</td><td id="25-G">(image of a thumbs up)</td><td id="25-H">Up to 75%</td><td id="25-I">Up to 95%</td><td id="25-J">▪ Operator:Machine ratio reduced to 1:3 for Tele-remote and 1:5 for autonomous</td></tr>
<tr><td id="25-K">Surveying labor</td><td id="25-L">(image of a thumbs up)</td><td id="25-M">100%</td><td id="25-N">100%</td><td id="25-O">▪ GPS positioning system eliminates need for floor demarcation tasks</td></tr>
<tr><td id="25-P">Fuel</td><td id="25-Q">(image of a thumbs up)</td><td id="25-R">0-5%</td><td id="25-S">0-10%</td><td id="25-T">▪ Lower consumption from more consistent operation</td></tr>
<tr><td id="25-U">Lubricants</td><td id="25-V">(Image of a green thumbs-up icon)</td><td id="25-W">0-5%</td><td id="25-X">0-10%</td><td id="25-Y">Lower consumption from more consistent operation</td></tr>
<tr><td id="25-Z">Drilling consumables</td><td id="25-10">(Image of a green thumbs-up icon)</td><td id="25-11">0-10%</td><td id="25-12">0-10%</td><td id="25-13">Lower consumption due to algorithm controlled, more consistent drilling operation</td></tr>
<tr><td id="25-14">Maintenance</td><td id="25-15">(Image of a green thumbs-up icon)</td><td id="25-16">0-10%</td><td id="25-17">0-20%</td><td id="25-18">Lower maintenance parts and labour costs from reduced wear due to more consistent operation</td></tr>
<tr><td id="25-19" rowspan="2">Capex</td><td id="25-1a">Drill rig capex</td><td id="25-1b">(Image of a red thumbs-down icon)</td><td id="25-1c">5-10%</td><td id="25-1d">15-20%</td><td id="25-1e">Higher drill costs due to additional equipment and sensors on drill</td></tr>
<tr><td id="25-1f">Infrastructure capex</td><td id="25-1g">(Image of a red thumbs-down icon)</td><td id="25-1h">~$0.5M</td><td id="25-1i">~$1M</td><td id="25-1j">Infrastructure costs for communications infrastructure, refueling system</td></tr>
</table>

<a id='47ea97dd-7e0f-4a61-84e9-7b077c0b1310'></a>

1 OEE: Overall Equipment Effectiveness

<a id='6ccdf106-c5a4-4bdc-8a6b-9cd6d5e433a1'></a>

SOURCE: Expert interviews; Press search

<a id='dc4d4449-f901-4bae-9f46-7c070699f11a'></a>

McKinsey & Company

<a id='f9d42cf1-23f1-44bc-8ae3-814a3825cd19'></a>

25

<!-- PAGE BREAK -->

<a id='4408985b-7740-442f-90a9-f15934fba823'></a>

OEE improvements account for more than 50% of the productivity
gains with labor savings being the next largest contributor
Drilling costs – USD $/m

<a id='f8950dc3-17bb-4ed0-92f2-e7504bb4487a'></a>

PRELIMINARY

<a id='abe7da80-e918-4ee0-9498-104be5a2b829'></a>

## Tele-Remote Drilling Total Cost of Ownership
3 drilling rigs per operator

<a id='e38e7718-9f23-402c-b52e-05860cbd49e3'></a>

**Autonomous drilling Total Cost of Ownership**
5 drilling rigs per operator

<a id='fdba6776-8113-4d7b-b4fd-1d1e129fa376'></a>

<::transcription of the content: chart::>Waterfall chart showing cost reductions from autonomous drills. The chart compares two scenarios, likely 'Current' (left) and 'Autonomous' (right) based on the reductions.

**Left Scenario (labeled -13% overall reduction):**
- **OEE¹**
  - Manual drilling: 9.76
  - Availability: -0.16
  - Utilization: -0.18
  - Drilling speed: -0.22
  - Redrilling and over-drilling: -0.20
  - Subtotal for OEE¹: 9.00
- **Operating and maintenance costs**
  - Drill rig labor: -0.41
  - Surveying labor: -0.24
  - Fuel: -0.05
  - Lubricant: -0.02
  - Drilling consumables: -0.08
  - Maintenance: -0.01
  - Subtotal for Operating and maintenance costs: 8.19
- **Capex**
  - Drill rig capex: 0.17
  - Infrastructure capex: 0.15
  - Subtotal for Capex: 8.52
- Overall Reduction: -13%

**Right Scenario (labeled -16% overall reduction):**
- **OEE¹**
  - Manual drilling: 9.76
  - Availability: -0.33
  - Utilization: -0.38
  - Drilling speed: -0.22
  - Redrilling and over-drilling: -0.30
  - Subtotal for OEE¹: 8.54
- **Operating and maintenance costs**
  - Drill rig labor: -0.49
  - Surveying labor: -0.24
  - Fuel: -0.10
  - Lubricant: -0.03
  - Drilling consumables: -0.08
  - Maintenance: -0.11
  - Subtotal for Operating and maintenance costs: 7.47
- **Capex**
  - Drill rig capex: 0.41
  - Infrastructure capex: 0.30
  - Subtotal for Capex: 8.18
- Overall Reduction: -16%
::>

In addition to increasing safety by removing personnel from dangerous locations, autonomous drills can reduce drilling costs by up to 15%

<a id='eab9868a-68f1-461c-aa5b-9f94307b1320'></a>

1 OEE: Overall Equipment Effectiveness

<a id='de0da3e9-7d46-483a-af6a-6618c69b6345'></a>

SOURCE: Team analysis; based on client mine plan

<a id='138536ff-06f9-4240-87c4-9464ed3a8b08'></a>

McKinsey & Company | 26

<!-- PAGE BREAK -->

<a id='4f358031-97b0-440a-a8b0-077c500b486e'></a>

ADVANCED TECHNOLOGIES EXAMPLE – TELE REMOTE AND AUTONOMOUS EQUIPMENT

**Tele-Remote and autonomous drilling scenario assumptions**

<a id='93405620-b212-4363-bf06-a38335a74631'></a>

<table id="27-1">
<tr><td id="27-2">Category</td><td id="27-3">Lever</td><td id="27-4">Units</td><td id="27-5">Manual</td><td id="27-6">Tele-remote</td><td id="27-7">Autonomous</td></tr>
<tr><td id="27-8" rowspan="5">OEE¹</td><td id="27-9">Availability</td><td id="27-a">%</td><td id="27-b">80%</td><td id="27-c">85%</td><td id="27-d">90%</td></tr>
<tr><td id="27-e">Utilization</td><td id="27-f">%</td><td id="27-g">77%</td><td id="27-h">82%</td><td id="27-i">87%</td></tr>
<tr><td id="27-j">Drill speed</td><td id="27-k">m/hr</td><td id="27-l">40</td><td id="27-m">41</td><td id="27-n">41</td></tr>
<tr><td id="27-o">Redrilling (short holes)</td><td id="27-p">%</td><td id="27-q">3%</td><td id="27-r">1.5%</td><td id="27-s">0.8%</td></tr>
<tr><td id="27-t">Over drilling (refill long holes)</td><td id="27-u">%</td><td id="27-v">4%</td><td id="27-w">2%</td><td id="27-x">1%</td></tr>
<tr><td id="27-y" rowspan="12">Operating and maintenance costs</td><td id="27-z">Drill rig operator</td><td id="27-A">FTE / shift</td><td id="27-B">1</td><td id="27-C">33%</td><td id="27-D">20%</td></tr>
<tr><td id="27-E">Drill rig operator salary</td><td id="27-F">$/yr</td><td id="27-G">50,000</td><td id="27-H">50,000</td><td id="27-I">50,000</td></tr>
<tr><td id="27-J">Number of shifts</td><td id="27-K">Shifts / day</td><td id="27-L">4</td><td id="27-M">4</td><td id="27-N">4</td></tr>
<tr><td id="27-O">Survey hours</td><td id="27-P">Hr/yr</td><td id="27-Q">4,000</td><td id="27-R">0</td><td id="27-S">0</td></tr>
<tr><td id="27-T">Surveyor rate</td><td id="27-U">$/hr</td><td id="27-V">20</td><td id="27-W">20</td><td id="27-X">20</td></tr>
<tr><td id="27-Y">Drilling consumables</td><td id="27-Z">$/meter</td><td id="27-10">2.5</td><td id="27-11">2.4</td><td id="27-12">2.4</td></tr>
<tr><td id="27-13">Fuel</td><td id="27-14">$/hr of operation</td><td id="27-15">118</td><td id="27-16">115</td><td id="27-17">112</td></tr>
<tr><td id="27-18">Lubricants</td><td id="27-19">$/hr of operation</td><td id="27-1a">41</td><td id="27-1b">40</td><td id="27-1c">39</td></tr>
<tr><td id="27-1d">Over drilled (long hole) fill cost</td><td id="27-1e">$/meter</td><td id="27-1f">5</td><td id="27-1g">5</td><td id="27-1h">5</td></tr>
<tr><td id="27-1i">Maintenance and overhaul parts</td><td id="27-1j">$/hr</td><td id="27-1k">72</td><td id="27-1l">68</td><td id="27-1m">61</td></tr>
<tr><td id="27-1n">Maintenance and overhaul labor</td><td id="27-1o">$/hr</td><td id="27-1p">50</td><td id="27-1q">48</td><td id="27-1r">43</td></tr>
<tr><td id="27-1s">Infrastructure/drill rig IT maintenance</td><td id="27-1t">$/yr</td><td id="27-1u"></td><td id="27-1v">31,000</td><td id="27-1w">62,000</td></tr>
<tr><td id="27-1x" rowspan="2">Capex</td><td id="27-1y">Drill rig initial cost</td><td id="27-1z">$</td><td id="27-1A">5.2m</td><td id="27-1B">5.5m</td><td id="27-1C">6.0m</td></tr>
<tr><td id="27-1D">Infrastructure initial cost</td><td id="27-1E">$ (symbol)</td><td id="27-1F"></td><td id="27-1G">310,000</td><td id="27-1H">620,000</td></tr>
</table>
1 OEE: Overall Equipment Effectiveness

<a id='359fae79-21ef-48f0-a19d-1e3d2f25bb3b'></a>

SOURCE: Expert interviews; Client Latin American Copper Mine parameters; Press search

<a id='85783849-2745-4ef9-be1c-94649c56f4cd'></a>

McKinsey & Company

<a id='93f4d991-9d9e-48dc-9b68-44d1fbb87d64'></a>

27

<!-- PAGE BREAK -->

<a id='addd6184-37d9-4abb-ab57-5fb07786c20a'></a>

Companies are planning for the future with technology
in mind and expect revenues to keep growing at ~4%p.a.

Revenues & EBITDA of the global mining industry
USD billion, real terms 2013

Revenues
EBITDA
Revenue CAGR (%)
X Average industry
EBITDA margin (%)

<a id='107509ae-c87d-40ce-a0bd-1580c42da466'></a>

<::line chart::>The chart displays data over time, with the X-axis representing years from '95 (likely 1995) to '25 (likely 2025), and the Y-axis representing values from 0 to 1,500. There are three lines plotted: a dark blue solid line, a light blue solid line, and a light blue dashed line. The dark blue solid line has several labels indicating annual percentage changes (p.a.): 0.8% p.a. from '95 to approximately '00; 24.5% p.a. from approximately '00 to '08; -5.1% p.a. from approximately '08 to '12; and 3.9% p.a. from approximately '12 to '25. Another label, 3.4% p.a., is associated with the light blue solid line, spanning from approximately '15 to '25. At the bottom of the chart, under the X-axis, there are blue oval shapes with values: '~25' under '95', '~25' under '05', '~40' under '10', '~30' under '15', and '~30' under '20' and '25'. The background features a faint, abstract image of a hand interacting with a digital grid or keyboard.<::

<a id='f07586e1-ed74-4ad8-bd37-31cd72832b3f'></a>

SOURCE: Company annual reports; McKinsey analysis

<a id='9b376a70-aa41-4cfa-ad9e-d80b9dc59949'></a>

McKinsey & Company

<a id='d020ef43-2973-4801-87b1-bce959840f90'></a>

28

<!-- PAGE BREAK -->

<a id='2e05bfc9-6980-4299-bbb4-dc961869618f'></a>

How are you positioning yourself for the future?

<a id='a63ecbec-13d4-4912-b465-67d444511456'></a>

> "I believe we need to hit the reset button in terms of how we think about innovation and mining in the future"

– *Mark Cutifani, CEO Anglo American*

<a id='bfc85e7d-3438-4bd0-b4b9-69f578da867f'></a>

<::logo: Anglo American
Anglo American
The logo features a stylized, dark blue triangular shape with concentric lines, and a small red triangle in the center, alongside the company name in blue text.::>

<a id='17214e33-a6f3-445a-881b-a3eb3257c90e'></a>

SOURCE: Press search

<a id='bdce31cd-2f1a-400f-b9f4-594fe055bd77'></a>

McKinsey & Company

<a id='7318c653-d056-45ea-96e7-fedcaa99fbdc'></a>

29

<!-- PAGE BREAK -->

<a id='25421036-6d9c-407b-8127-4aa811332ac3'></a>

Summary of the rare earth market outlook

<a id='73edb143-d8bd-43ab-a887-41cadd97f75d'></a>

* Rare earths are a group of 17 elements, which are divided into light and heavy rare earths. They are used in a wide range of applications, such as **permanent magnets, metal alloys, catalysts and polishing powders**
* The market is large and growing ($8B and ~113 ktons of demand after separation of individual oxides, growing at a 7% CAGR), with heavy rare earths representing <15% of the volume, but ~50% of revenues
* China holds most of the production along the value chain (~80-100%), as well as most of the known reserves, letting it control prices through management of **export quotas**
* Outside of China, most projects are **focused on light rare earths**
  * Rare earths expected to be critical are mainly heavies (Dysprosium, Yttrium, Terbium and Europium), together with the light element neodymium
  * The pipeline of heavy rare earth projects is limited to less than 10k tons and they are at **very early stages of development**
* If China continues to act rationally (and from expert interviews it seems that it will maintain quotas for heavy rare earths at present levels) **prices should continue at greenfield incentive levels**, allowing some penetration from the rest of the world
* Based on this, a mine that is “heavy on heavies” would find itself in a privileged position

<a id='f192fac5-ccef-4080-b382-0d0af03503fe'></a>

McKinsey & Company

<a id='18c4333b-d72c-4cd8-ba58-616be0ee8398'></a>

30

<!-- PAGE BREAK -->

<a id='5c4a17f5-46bc-4164-968b-480ece575476'></a>

RE are essential in the manufacturing of several products, used every day,which has led to a rapid increase in their demand

<a id='91c86163-933d-4f71-aa10-bc93cac0a325'></a>

NOT EXHAUSTIVE

<a id='f5b0cf03-6ec2-467f-80a3-ba06a55fc344'></a>

# Applications of Light RE Elements

## Lanthanum
<::Image of various lenses and optical components::>
* Used in electric and hybrid vehicles, laptop computers, cameras, high-end camera lenses, telescopes, binoculars – as lanthanum improves visual clarity;
* Used to reduce the level of phosphates in patients with kidney disease

<a id='a1d55814-76ac-4604-9b9b-e9294e897824'></a>

<::image of a bar magnet with magnetic field lines around it, showing the field originating from one end (red) and curving around to the other end (silver) with arrows indicating direction: diagram::>
Samarium
- Primary use is in the production of permanent magnets but also in X-ray lasers
- Precision guided weapons and white-noise production in stealth technology

<a id='b8573857-f7ea-4dbf-8c98-be6fb83fc0d9'></a>

<::An image shows two stacks of circular, silver-colored disc magnets, one stack slightly in front and to the right of the other. Each stack contains multiple individual magnets. : image::>
Neodymium
- The principal use is in the manufacture of the
  strongest magnets in the world. These magnets are
  so strong that one the size of a coin cannot be
  removed from a refrigerator by hand
- Other important applications include laser range
  finders and guidance systems

<a id='00132d14-1c5e-4643-aa2a-349f4c36a246'></a>

<::transcription of the content
: The image shows a colorful, iridescent sphere, possibly a polished gemstone or a marble, with swirling patterns of blue, green, purple, and red.
: figure::>

# Cerium

* Used to polish glass, metal and gemstones, computer chips, transistors and other electronic components
* Automotive catalytic converters to reduce pollution
* Added in glass making process to decolorize it, gives compact fluorescent bulbs the green part of the light spectrum

<a id='fc033641-0bab-4011-831c-a2eefc6f441c'></a>

Applications of Heavy RE Elements

<a id='746852fd-a0f4-40e3-a2cf-ab6feab7dfbd'></a>

<::transcription of the content
iPod nano
: figure::>

# Dysprosium

* Most commonly used in the manufacture of neodymium-iron-boron high strength permanent magnets
* Injected into joints to treat rheumatoid arthritis
* Used in radiation badges to detect and monitor radiation exposure

<a id='831081cc-2301-457b-acb8-f6d62b24b89a'></a>

Yttrium
- Used in energy efficient fluorescent lamps and bulbs
- Used in high temperature applications, such as thermal barrier coating to protect aerospace high temperature surfaces
- Can increase the strength of metallic alloys

<a id='a55dcf86-5ba4-4dfb-be70-2ec8d493b4ec'></a>

<::transcription of the content
: illustration::>

## Gadolinium

*   Used to enhance the clarity of MRI scans by injecting Gadolinium contrast agents into the patient
*   Used in nuclear reactor control rods to control the fission process

<a id='fa02a669-ff0a-4626-b2f5-343d8f3843da'></a>

Europium
- Primarily used in phosphors used in pilot display screens, televisions and energy efficient fluorescent lights

<a id='c0b2b713-442c-486b-a3a2-2812347b086f'></a>

SOURCE: IAMGOLD Report, General Web, team

<a id='d4390e3c-4126-40ea-8912-adf09be7f816'></a>

McKinsey & Company

<a id='fab14b53-46bb-47f1-8771-2a52bce573f7'></a>

31

<!-- PAGE BREAK -->

<a id='659ded92-401d-47f8-afe1-62dbb1f29036'></a>

Increasing demand for RE has led to other countries looking
for potential reserves to reduce their dependency on China
Million metric tons

<a id='2d267c92-cff9-46f3-9624-b840365a99fd'></a>

Rare Earth Reserves¹<::World map illustrating rare earth reserves by region:
- USA & Canada: 14
  - Associated text for USA:
    - Was self-reliant
    - Currently imports 100%
    - Mainly due to lower costs
    - Molycorp owns biggest deposit in USA
- China: 55
  - Associated text for China:
    - Holds 50% of reserves
    - Controls 90% of the supply
- India: 3.1
- Australia: 1.6
- RoW (Rest of World): 22
- Japan:
  - Associated text for Japan:
    - 100% importer
    - Have recently found 80-100 mn metric tons of REE in the Pacific seabed
: map::>

<a id='79d56b34-b28e-4a73-8f22-354b201182a4'></a>

a
1
<::A map showing parts of Asia and Australia. A blue circle is placed over India.
: map::>

<a id='64fe2281-f691-454a-81f7-e791e18f0d76'></a>

With the development of new projects, it is expected that this
scenario, with China being the dominant player, will also change

<a id='b7880520-76ad-487f-8eb0-9b380150cef3'></a>

1 Referring only to the identified RE reserves

<a id='3b7f626d-f872-4136-b55e-1a815f148c30'></a>

SOURCE: USGS, General web and press

<a id='d4902d40-1bff-4e01-ae65-511994bea59a'></a>

McKinsey & Company

<a id='0e1a5c98-10e5-4a8f-b425-51e381d15c10'></a>

32

<!-- PAGE BREAK -->

<a id='acb9d50b-b036-4a75-a244-ef707dca67f7'></a>

SUPPLY

There is a number of projects in the pipeline,
but most focus on light rare earths

<a id='1ee4369e-b0cf-4dae-8ef7-1bf32158c0b8'></a>

<::legend
- Green square: HRE
- Red square: LRE
- Dark blue circle: High
- Light blue circle: Low
: legend::>

<a id='5db72914-37d3-4283-aa32-ce1b5424e1c2'></a>

NOT EXHAUSTIVE

<a id='af3d304e-c52c-4f1a-8844-834a8af4a034'></a>

Company Project Resource TREO Mt Capacity TREO tpa HRE share % Status Likelihood
<::Canadian flag: flag::> IAMGOLD Niobec 7.70 139,597 1.76 Scoping <::Likelihood indicator: a light blue circle with a small dark blue segment: chart::>
<::Greenland flag: flag::> Greenland Minerals and Energy Kvanefjeld 6.55 51,900 11.80 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Avalon Rare Metals Nechalacho 5.64 8,504 13.84 Feasibility <::Likelihood indicator: a light blue circle with a dark blue half: chart::>
<::Canadian flag: flag::> Commerce Resources Eldor 4.69 50,743 4.04 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Tanzanian flag: flag::> Peak Resources Ngualla 3.82 93,519 1.99 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Geomega Resources Montviel 3.65 105,903 1.71 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>
<::Greenland flag: flag::> Greenland Minerals and Energy Sørensen 2.66 N/A 11.72 TBD <::Likelihood indicator: a light blue circle: chart::>
<::Canadian flag: flag::> Quest Rare Minerals Strange Lake 2.10 10,652 39.03 Pre-feasibility <::Likelihood indicator: a light blue circle with a dark blue segment: chart::>
<::USA flag: flag::> Molycorp Mountain Pass 2.07 40,301 0.60 Pre-production <::Likelihood indicator: a dark blue circle: chart::>
<::Australian flag: flag::> Lynas Corporation Mount Weld CLD 1.45 22,165 2.85 Pre-production <::Likelihood indicator: a dark blue circle: chart::>
<::Australian flag: flag::> Arafura Resources Nolans Bore 1.24 19,298 3.34 Pre-feasibility <::Likelihood indicator: a light blue circle with a dark blue segment: chart::>
<::Brazilian flag: flag::> MBAC Fertilizer Araxá 1.19 13,154 2.67 Reserve devpt. <::Likelihood indicator: a light blue circle: chart::>

<a id='836a9ee9-a6f5-4c78-a4c1-5d210ce7d438'></a>

SOURCE: Technology Metals research, expert interviews, companies' reports, press

<a id='32971662-def8-497f-aad8-61701b24b609'></a>

McKinsey & Company

<a id='7856319f-264a-4672-8a44-fdb481f5322a'></a>

33

<!-- PAGE BREAK -->

<a id='e34c8d65-c540-43cc-9b71-94dce2318abe'></a>

**However, exploration successes are becoming expensive and scarce**
10 year period 2003-12

<a id='63398ada-07e9-402d-9eaf-19f2ec9c86da'></a>

<::chart::>Spending, USD Billions | World-class/Other Discoveries
---|---
Lat America | 28 | 15 | 103 | 118
Canada | 22 | 49 | 16 | 65
China + CIS | 22 | 66 | 11 | 77
Africa | 17 | 19 | 97 | 116
Australia | 12 | 13 | 70 | 83
USA | 9 | 9 | 11 | 20
SE Asia/Pacific | 6 | 2 | 21 | 23
W Europe | 3 | 1 | 21 | 22
GLOBAL | 116 | 86 | 438 | 524
NEEDED | 140 | 125 | 625 | 750

- Across all major regions, world-class discoveries cost over 1 billion USD
- Africa and the USA were the most "effective" regions
- Gold deposits still account for nearly half of all discoveries
- .. But only finding 2/3 of the deposits we need<::>


<a id='fd3c6ad5-b710-4429-a9fc-172315ce311f'></a>

SOURCE: McKinsey BMI; MinEx Consulting

<a id='fd74f157-4872-439e-a3c6-96bc4b6f5223'></a>

McKinsey & Company | 34

<!-- PAGE BREAK -->

<a id='918c1552-0403-4a03-8065-162b76f508ec'></a>

New and current mining projects will be face strong market forces, which will have significant impact on the industry over coming decades

<a id='ecbf4b7b-3d88-442f-a0e3-c52a16e2bb71'></a>

1. Continuously increasing safety, health and environment standards
2. High demand and prices but significant volatility
3. Increasingly challenging geologies
4. Polarization of scale creates new challenges
5. Increasingly challenging supply chains
6. Rising energy costs
7. Rising water costs
8. Scarcity of talent
9. Global sourcing

<a id='4afd06ec-adfa-4429-9e36-d8d827de9514'></a>

SOURCE: McKinsey analysis

<a id='65136e42-f72b-4727-a535-1d2cdd7f5f2a'></a>

McKinsey & Company

<a id='ab941bc0-5448-4abe-9cd5-61b730498d2c'></a>

35

<!-- PAGE BREAK -->

<a id='a603b992-c10a-4f4f-ba94-0d6bacfb502e'></a>

PRICING

<a id='0bce5cf8-465e-4c42-90ee-bc825a343a18'></a>

Going forward, a greenfield incentive price scheme is expected for heavy elements and neodymium1

--- Deutsche Bank | ESTIMATES

<a id='66e75df0-6b5b-4366-a256-8db9394dd07b'></a>

Historical and future price estimates
Dollars per kg

<::chart: Line charts showing historical and future price estimates for Yttrium, Dysprosium, Terbium, Neodymium, and Europium. The charts share a common x-axis representing years from 2002 to 2017. Two lines are plotted for each element: CIBC (dashed line) and McKinsey greenfield incentive (solid line).::>

Yttrium
<::chart:
Y-axis: 0, 50, 100, 150 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 67 in 2017.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 89 in 2017.
:chart::>
*   Should be in a greenfield
    incentive regime in the short-
    medium term, until some of
    the new capacity eases the
    supply/demand tightness

Dysprosium
<::chart:
Y-axis: 0, 500, 1000, 1500 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 605 in 2017, with an intermediate value of 688.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 1019 in 2017.
:chart::>
*   Expected to remain in
    greenfield incentive for the
    foreseeable future, with
    eventual fly-ups depending on
    China's export policies

Terbium
<::chart:
Y-axis: 0, 1000, 2000, 3000 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 865 in 2017.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 1144 in 2017, with an intermediate value of 1056.
:chart::>
*   Should be in a greenfield
    incentive regime in the short-
    medium term, until some of
    the new capacity eases the
    supply/demand tightness

Neodymium
<::chart:
Y-axis: 0, 100, 200, 300 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 67 in 2017, with an intermediate value of 77.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 93 in 2017.
:chart::>
*   Tightness to be eased with
    volumes from Lynas and
    Molycorp
*   Should be back to
    greenfield/fly-up in longer term

Europium
<::chart:
Y-axis: 0, 1000, 2000, 3000 Dollars per kg.
Line for CIBC (dashed) shows an estimated value of 1022 in 2017.
Line for McKinsey greenfield incentive (solid) shows an estimated value of 1269 in 2017, with an intermediate value of 1393.
:chart::>
*   Expected to remain in
    shortage in the foreseeable
    future, with demand growth
    out-spacing supply additions

1 Assuming that China will put maximum
2002 03 04 05 06 07 08 09 10 11 12 13 14 15 16 2017

<a id='2910e0c0-f977-4110-9b17-30c9ab191390'></a>

SOURCE: Analyst reports, team analysis

<a id='b5a57d23-adc7-4f41-80c7-3f4a50c5f367'></a>

McKinsey & Company | 36

<!-- PAGE BREAK -->

<a id='0049a81b-3a17-4f2a-b074-e8011a5c63fb'></a>

GLOBAL SUPPLY-DEMAND BALANCE

<a id='e7c6abe4-49af-47c9-a204-22d89f853368'></a>

Mines holding considerable quantities of these five elements will be in a good position in the future

<a id='47dbc994-50fa-42fc-9945-11200743582f'></a>

**Y**
* Yttrium is expected to be in shortage in the short term, with most of the new supply only coming online through the end of the decade
* Expert opinions: "I don't see relevant new capacity outside of China coming online in the next few years"

**Dy**
* Dysprosium is expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
* Severe shortage could trigger investments in magnet recycling technology or even partial substitution/decrease in intensities

**Tb**
* Slower demand growth for Terbium when compared to Dysprosium and Yttrium could lead to a balanced market already in the short term
* Given the relatively low volume of the global terbium market, small amounts as by-product from large light-focused projects such as Mountain Pass and Mount Weld could ease the tightness

**Nd**
* Relevant volumes of Neodymium coming from Mountain Pass and Mount Weld in the short term should ease the tight supply-demand balance
* In the longer term, new projects will probably be needed to meet Nd demand

**Eu**
* Europium is expected to remain in shortage in the foreseeable future, with demand growth out-spacing supply additions
* Severe shortage could trigger investments in phosphors recycling, such as the research conducted by Rhodia in France in the last few years

<a id='43ee8374-8ceb-497d-b594-a62c2a5c19e4'></a>

SOURCE: Expert interviews, McKinsey

<a id='68cf9c9a-3422-419c-b252-ef7d2bca1909'></a>

McKinsey & Company

<a id='623990d1-0b28-4973-8831-dc0d9d0294ad'></a>

37

<!-- PAGE BREAK -->

<a id='e6cc1e88-5e27-44fb-8c8c-679d2580ec88'></a>

SUPPLY
With this relevant position, China controls the current price dynamic

<a id='79436529-aa0d-4108-bd7d-8d754acd5c44'></a>

<::Bar chart showing Export quota evolution of rare earth in China. The y-axis is labeled "Thousand tons" and the x-axis represents years from 2006 to 2012. The bar heights for each year are: 2006: 62, 2007: 60, 2008: 47, 2009: 50, 2010: 30, 2011: 30, 2012: 31. An arrow indicates a -40% decrease from the 2009 level (50 thousand tons) to the 2010/2011 levels (30 thousand tons).
: chart::>
<::Line chart showing Prices of dysprosium oxide in China. The y-axis is labeled "$/kg" and ranges from 0 to 2000. The x-axis represents years from 2006 to 2012. The line shows prices gradually increasing from 2006 to 2010, then a sharp increase to a peak near 2000 $/kg around 2011, followed by a sharp decrease and then a slight rise, ending at 800 $/kg in 2012. Two annotations are present:
- "Peak of prices caused by export quotas reduction" pointing to the peak around 2011.
- "Drop in 2012 as a result of demand decrease due to unsustainably high prices, but still significantly higher than historical levels" pointing to the price drop and the 2012 value.
: chart::>

<a id='6848aa21-f0b7-4150-b8e2-b39a4c0c7a31'></a>

- In 2010, China tightened export quotas for heavy and light rare earths; in the future:
  - Light quotas could be eliminated as new light REO sources are coming online
  - Heavy quotas should remain as China does not have enough reserves and few new heavy rare earth sources are coming online in the future
- If China acts rationally, it will look to maximize profits which would maintain prices at higher than historical levels letting smaller players into the market. However they hold the power to avoid the entry of other players if they wanted to.

<a id='b8c8d0d3-db34-4dfc-8e1e-759960267e53'></a>

SOURCE: MOFCOM, Press search

<a id='ebb9e76c-abbf-4719-ae2d-50f15cff6a0f'></a>

McKinsey & Company

<a id='ec56f151-f80e-4ae7-b410-30c6429a33c0'></a>

38

<!-- PAGE BREAK -->

<a id='1dfee119-7936-47a0-aea7-d9aab2f0dcf8'></a>

This has resulted in companies looking for different
avenues to meet their growing requirements;
for which substitution seems best suited

<a id='8a61e8ab-f0b0-4a65-aba1-6ccf908ed822'></a>

<::logo: Unknown
Fuller the moon, more viable
A blue and light blue circle is split down the middle with a shadow beneath it::>

<a id='9c725d63-f70e-4d58-877f-ef97876aa11e'></a>

Best way forward

<a id='a19e87e4-91a5-48f8-903c-1f97d914dfe2'></a>

3 best measures to adopt to avoid falling into supply shortage problems

Reduction in the usage of RE is a process that is not yet economically tested by many companies

Some areas where this has come useful is in LED television sets, which require lesser RE than LCD sets

Recently, generator manufacturers have reduced RE content and have used other metals like nickel, which provides similar levels of performance

RE used in fluorescent lighting and computer hard drives, can be recycled

Extract RE from used hybrid motors and lithium-ion batteries in addition to nickel-metal hydride batteries

Benefits of recycling RE from batteries is that a supply of recycled lanthanum should be more reliable than relying on new Chinese sources

Recycling also uses less energy and emits less carbon di than mining

<a id='36ae29f7-c219-4c07-b73a-49fac91b804e'></a>

<::A box with a dashed blue border contains text and two icons. On the left, a circular icon with a red left-pointing arrow and a green right-pointing arrow. On the right, a pie chart icon, mostly blue with a small light blue segment, is placed next to the text describing a 5% efficiency improvement. The text inside the box reads: Motor companies are looking towards creating new techniques to substitute RE, like induction motors and nickel-hydride batteries. Some companies have also substituted RE with iron based amorphous core for motors which is 5% more efficient. Companies who are taking the initiative towards substitution are Hitachi, Ford, Continental AG and Honda.
: figure::>

<a id='bfe29b33-9e07-42af-9f4b-c779bbbfeeed'></a>

SOURCE: General web and press, team

<a id='ee83331e-114e-4be0-979b-346459746c1d'></a>

McKinsey & Company

<a id='ea631395-da96-4ba4-8d11-85805cbe6e81'></a>

39

<!-- PAGE BREAK -->

<a id='922f7a02-c864-4cc6-aa89-0ea316eb1966'></a>

SUPPLY
In the rest of the world the pipeline of heavy projects is limited to less than
10k tons

<a id='0a6d885a-0514-4276-af9a-495f50867499'></a>

<::Projects in the pipeline by type. Percent, number of projects, TREO ktpa. The chart displays two stacked bar charts. The first bar, labeled "# of projects," represents 45 total projects (100%). It is divided into "Heavy¹" at 33% and "Light" at 67%. The second bar, labeled "Projected production," represents 112 thousand tons. It is divided into a heavy-focused portion at 7% and a light-focused portion at 93%. A callout box states: "Total production from heavy-focused projects expected to account for only ~7k tons of additional production (55% of current supply)".: chart::>

<a id='6027e59f-0d1e-4154-b9c0-366e94f636a6'></a>

1 Heavy rare earths projects are the ones with more than 15% of total rare earth content of heavy elements

<a id='59fcba84-1473-455a-aba4-8a48c90276cc'></a>

SOURCE: Technology Metals Research, expert interviews, companies' reports, press

<a id='986df04d-8be6-41c3-b9ef-96d32c6dac22'></a>

McKinsey & Company

<a id='203f39ee-7bff-4a52-ada7-7cea7404d632'></a>

40