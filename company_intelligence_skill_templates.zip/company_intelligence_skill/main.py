"""
Main entry point for the company intelligence skill.
"""

from typing import Any, Dict, Optional

from router import choose_source
from capitaliq_retrieval import run_capitaliq
from web_search_retrieval import run_web_search
from internal_api_retrieval import run_internal_api
from result_formatter import normalize_result, merge_results


def run_skill(
    query: str,
    company_name: Optional[str] = None,
    source: str = "auto",
    allow_fallback: bool = True,
) -> Dict[str, Any]:
    """
    Run the company intelligence retrieval workflow.
    """
    selected_source = source if source != "auto" else choose_source(query)

    primary_result = _invoke_source(selected_source, query, company_name)
    normalized_primary = normalize_result(primary_result, selected_source, company_name)

    if not allow_fallback or normalized_primary.get("confidence") == "high":
        return normalized_primary

    fallback_source = _choose_fallback(selected_source)
    if not fallback_source:
        return normalized_primary

    fallback_result = _invoke_source(fallback_source, query, company_name)
    normalized_fallback = normalize_result(fallback_result, fallback_source, company_name)

    return merge_results(normalized_primary, normalized_fallback)


def _invoke_source(
    selected_source: str,
    query: str,
    company_name: Optional[str],
) -> Dict[str, Any]:
    if selected_source == "capitaliq":
        return run_capitaliq(query=query, company_name=company_name)
    if selected_source == "internal_api":
        return run_internal_api(query=query, company_name=company_name)
    if selected_source == "web_search":
        return run_web_search(query=query, company_name=company_name)

    raise ValueError(f"Unsupported source: {selected_source}")


def _choose_fallback(selected_source: str) -> Optional[str]:
    fallback_order = {
        "capitaliq": "web_search",
        "internal_api": "capitaliq",
        "web_search": "capitaliq",
    }
    return fallback_order.get(selected_source)


if __name__ == "__main__":
    example = run_skill(
        query="latest revenue and ownership of Datadog",
        company_name="Datadog",
        source="auto",
        allow_fallback=True,
    )
    print(example)
