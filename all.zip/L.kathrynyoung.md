<a id='e5582bd0-bb75-4610-9a8c-8d3d56def0e3'></a>

<::Two hands holding two puzzle pieces, each piece showing a portion of the Earth. The puzzle pieces are positioned to connect, symbolizing global connection or integration.: figure::>

<a id='90d5f7eb-8162-4bdb-8058-7d08c282d6c1'></a>

What Makes Private Sector
Partnership Works: some
learnings from the field

<a id='d0c2e43f-df48-4300-87c6-b3e4ad2f2099'></a>

Discussion Document
September, 2011

<a id='23357a4a-9fee-4824-a721-202a74930ade'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company is strictly prohibited

<a id='71fc25a8-5fa9-415f-abe6-00bf9dcb148c'></a>

McKinsey&Company

<!-- PAGE BREAK -->

<a id='824dc96b-5647-40c7-8f87-86ecdc06a72a'></a>

CHI-AAA123-20100803-

<a id='696446af-5711-480a-befb-0670058ea787'></a>

The looming demands on agriculture are colossal ...

<a id='f88017a0-f9ce-4f20-9b7c-f57f1e61c8a0'></a>

100% Population dependent on agriculture for nutrition

2bn Number of people that will be added to the planet in the next 40 years

+3bn Number of consumers in developing countries who will demand more and higher-quality food

70% % that **agricultural output must rise** to in the next 40 years vs. 2005-07 production

10,000 Years of historical **food production** that must be matched in the next 40 years

<a id='15ee7332-336b-4fb4-806b-d7ed3460926f'></a>

Sources: World Bank; Food and Agriculture Organization (FAO); McKinsey GHG Abatement Curve and Water Initiative

<a id='292dd2c3-96c9-422b-a953-182ab35d106a'></a>

McKinsey & Company

<a id='ce7556d0-2185-4aa4-8f29-fab23e827466'></a>

1

<!-- PAGE BREAK -->

<a id='02cb7abb-bf51-412d-b7c2-fe54e40f21f6'></a>

CHI-AAA123-20100803-

<a id='955a0c08-1f4e-4d6b-8131-dafec64f7ad7'></a>

McKinsey has been transforming agriculture in Africa by identifying and
championing holistic yet scalable models

Non-exhaustive

<a id='a3985169-de4f-4cb9-b9a2-2c1b673564fc'></a>

# Transformation models

1.  **Value-chain interventions**
    *   Private sector investment into industry gaps to capture value and stimulate growth
2.  **Infrastructure corridors**
    *   Concentrated regional approach of investing in infrastructure to attract ongoing development investment and growth
3.  **Policy facilitation**
    *   Government-encouraged investment packages, taken up by private sector players to address development needs and foster growth

<a id='59b2d290-7fc7-4f77-bf1d-31ee7e4c1b62'></a>

Morocco

- **Scope**: Economic development strategy and actionable implementation plan for North African region where agriculture is critical (approx 20% GDP)
- **Client/partners**: sanitized – contact practice for details

<a id='b57bcbf3-9dfc-41ab-98aa-7b3f3c8fff11'></a>

# Ghana

*   **Scope**: Breadbasket strategy to increase food security, increase smallholder income, and increase GDP
*   **Client/partners**: sanitized – contact practice for details

<a id='c8720654-910b-42cd-be54-75ab03734a52'></a>

<::Map of Africa with two overlaid text boxes. The first box, labeled "Ethiopia," contains details about a national extension program and place-based transformation strategy, with client/partners listed as "sanitized – contact practice for details." The second box, labeled "Mozambique, Zambia," describes a soy-value-chain diagnostic, including economic analysis and strategy for linking the private sector with smallholder farmers, also with client/partners listed as "sanitized – contact practice for details.": figure::>

Ethiopia
■ Scope: National extension program
and place-based transformation
strategy
■ Client/partners: sanitized – contact
practice for details

Mozambique, Zambia
■ Scope: Soy-value-chain diagnostic,
including economic analysis and
strategy for creatively linking private
sector with smallholder farmers
■ Client/partners: sanitized – contact
practice for details

<a id='5b2e2acd-1e38-48b3-87c5-8dcccded2724'></a>

Source: McKinsey

<a id='14f042cf-16f2-45e9-a410-70de200402c8'></a>

McKinsey & Company

<a id='9c59318c-e612-47c8-883a-4b5c62216734'></a>

2

<a id='61337009-7bcc-49de-af37-8110489d72b4'></a>

<::map of North Africa with Morocco highlighted in a lighter shade of blue, with country borders outlined in tan. Overlaid on the map is a text box with the following content:
Morocco
- Scope: Economic development strategy and actionable implementation plan for North African region where agriculture is critical (approx 20% GDP)
- Client/partners: sanitized – contact practice for details
: map::>

<!-- PAGE BREAK -->

<a id='e0ce15e6-77d3-4846-81d7-a4e11e692f45'></a>

CHI-AAA123-20100803-

<a id='085ccf0c-9141-4d6f-8b4b-a8a7f5b1fadc'></a>

Value chain efforts require viable public-private partnership models

<a id='c0a18ca3-0118-4ae1-9474-cb34fb306329'></a>

## Key learnings from the field on partnership models
The social sector is generally excited about the increased emphasis on private sector leverage

- It appears that donors/social institutions most frequently engage in end-user contracts/demand sinks
- The models used have advantages of global reach and smallholder focus, but some sustainability and efficiency questions

Some institutions are exploring a more integrated private-sector led aggregation/extension models. These may add sustainability and efficiency, but have two critical requirements

- The economics must work on a run-rate basis
- There must be the ability to structure and monitor contracts (contract model will depend on number of partners)
- There is a need for innovative models for training entrepreneurs

<a id='b2818dde-dc9f-4f92-b972-ce3c5f502db0'></a>

McKinsey & Company

<a id='007e1057-a132-49a8-a808-9da5c9736b78'></a>

3

<!-- PAGE BREAK -->

<a id='7e5ca77c-2827-468a-9ae8-b6524aef77e6'></a>

CHI-AAA123-20100803-

<a id='09667797-ba99-4eed-8dd5-2d97dab5ec4c'></a>

Currently, most private sector partnerships
appear to focus on either end of the value chain

<a id='a306f1b7-d973-403d-b6fa-a9bb48294047'></a>

THOUGHT STARTER

<a id='04069e84-0f8a-4fae-a00e-baa93a24e826'></a>

<::legend: Most frequently seen NGO/INGO models::>Most frequently seen NGO/INGO models

<::table:
| | Inputs | Input distribution | Agricultural production | Trade/primary processing | Distribution |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Barriers <::icon: A small image of an orange and white striped construction barrier::> | * Lack of improved technology | * Costly distribution * Lack of credit access | * Low yields | * Limited capacity * Poor market linkages | * Limited local expertise/capacity |
| Most common partnership models <::icon: A small image of two men in suits shaking hands::> | * Collaborate/co-invest in R&D (e.g., Harvest Plus) | * Co-invest in multiplication * Co-invest in Kiosks, farm centers (e.g., ITC) | * Production assistance to the farmers generally provided by governments, or NGOs/implementing partners | * Provide financial mechanisms to support infrastructure expansion (e.g., DCA) * Coordinate demand sinks (e.g., Walmart) |
| Emerging partnership models <::icon: A small image of a person in a white shirt and blue jeans, sitting on a bench in front of a building with green grass and trees::> | <::arrow: left to right arrow::> * Entrepreneur/private sector-led aggregation & extension (e.g., processors, warehouses, stand-alone associations, commercial farms) <::arrow: left to right arrow::> |
::>

<a id='432fc388-3875-4f08-af19-943a34af3960'></a>

A Step-by-Step Guide to Filing an S-Corp Election
<::A photograph of two businessmen in suits shaking hands outdoors, with city buildings and trees in the background.
: photograph::>

<a id='cacd36fe-ec1d-4cae-8011-36183e9d47a6'></a>

McKinsey & Company

<a id='f4db261b-175d-46e2-93e6-f72fa1396216'></a>

4

<!-- PAGE BREAK -->

<a id='da5c658d-5fe5-4beb-9e1c-42065f44b201'></a>

CHI-AAA123-20100803-

<a id='905110fd-8b5e-4631-a90a-8946e3e80e2c'></a>

Some donors are exploring involving the private sector along more of the value chain

<a id='dc2a40e5-4e12-47a4-a5b8-e6f6dcf7095c'></a>

THOUGHT STARTER

<a id='c28fbd34-39aa-4977-8df3-c632b2ff9310'></a>

<::Legend for a diagram with four entries:
1. A dark blue parallelogram shape labeled "Primary actor"
2. A light gray solid arrow labeled "Service flow"
3. A dark blue outlined arrow labeled "Product flow"
4. A light blue solid arrow labeled "Fund flow"
: figure::>

<a id='fe9899b2-6aa3-4db6-b6ed-f746cec058cc'></a>

Models of farmer production assistance

1 Implementing partner as “key actor”
<::flowchart
Donor
  - Grant/Contract to implementing partner
  - (arrow) -> Implementing partner

Implementing partner
  - (arrow) -> Private sector demand sinks
    - connection label: Coordinate end-user contracts (globally or locally)
  - (arrow) -> Smallholders
    - connection label: TA, develop associations

Smallholders
  - (arrow) -> Private sector demand sinks

Private sector demand sinks
  - (arrow) -> Finance
    - connection label: Financing support (if necessary)

Finance
: flowchart::>
Most common model that we observed in the field is smallholder-centric, but there are some sustainability questions– who keeps it going?

<a id='0aa10a02-8307-4150-b352-e0cb19786d85'></a>

2 Private sector "aggregator" as key actor
<::flowchart
: A flowchart illustrates the role of a private sector "aggregator".
- A light blue rounded rectangle labeled "Donor" is at the top left.
- Below "Donor" is the text "Contract to private sector".
- An arrow points from "Donor" to a dark blue parallelogram labeled "sector 'Aggregator'".
- The arrow is labeled "Funds (or matched funds) to source from smallholders".
- To the right of the "sector 'Aggregator'" parallelogram, a list of examples for an aggregator is provided:
  - Processor
  - Entrepreneurial warehouse owner
  - Association
  - Commercial farm
  - Service center
- A grey downward arrow points from "sector 'Aggregator'" to a light blue rounded rectangle labeled "Smallholders".
- An upward white arrow with a dark blue outline points from "Smallholders" back to "sector 'Aggregator'".
: flowchart::>

<a id='10a4f496-e58f-4a23-83ad-95db1194fea8'></a>

Private sector-led
models are emerging –
key questions are 1)
economic viability 2)
contract oversight
3) relative scarcity of
qualified entrepreneurs

<a id='593c5d05-1694-4d85-a68e-b18a67ce2cf6'></a>

McKinsey & Company

<a id='399e6ef4-5c98-4c17-a698-d0ba878b8c98'></a>

5

<!-- PAGE BREAK -->

<a id='b6b7e00d-ac0f-4135-9281-cf01118b50d6'></a>

There are multiple types of aggregation models:
Mali example of 3 potential models

<a id='b38778dd-dbe9-4d16-b75c-62b328a07d86'></a>

CHI-AAA123-20100803-

Special aggregation model

Number of projects

<a id='fc770b92-9619-4942-8ce3-f7fa31a9a4d3'></a>

<::Flowchart illustrating a supply chain or business structure.: flowchart::>Midstream<::arrow::>Input<::arrow::>Upstream/production<::arrow::>Collection/stockingIntegrated service centers,Integrated private sector companies<::icon of a house::>Input providers (Agro dealers)<::six stylized user icons (heads and shoulders) arranged in two rows of three::>Large structure "nucleus" farmsWholesalers/tradersCooperatives of critical size<::photograph of a building with text on its facade: "OP DE SIRAMANA", "BOUTIQUE D'INTRANTS ET", "MAGASIN DE WARANTAGE", "DNA-SAA-IER - AGRA", "MAGAS DE WARANTAGE". A person stands in front of the building.::>

<a id='7e1d83a3-38dd-4b63-9faf-3d0f50a209fd'></a>

Whatever
aggregation
model you
choose, the
economics
MUST be
attractive on a
run-rate basis

<a id='05f50bcc-4c6e-45aa-87f8-d5841d4ada7f'></a>

McKinsey & Company

<a id='acf96099-c8a4-49de-b7b6-833d7419b0e6'></a>

6

<!-- PAGE BREAK -->

<a id='4fdd3cb7-16fa-4229-af29-a6384104d79e'></a>

CHI-AAA123-20100803-

<a id='801eb25d-2b55-4099-8b44-a9b5d15589ec'></a>

Example of integrated private sector company: Frigoken integrates across the value chain and links to smallholders

<a id='42236eda-8c94-4d6d-b0f2-ec0d6b4160f0'></a>

<::logo: Frigoken
FRIGOKEN
The logo features a stylized yellow 'Y' shape resembling a plant with green leaves, set against a dark green rectangular background.::>

<a id='5f8f766c-a9d4-404e-93df-8cb200c57d2f'></a>

Frigoken case study: Structured demand leads to catalytic investment in farmers and factories

<a id='4d4db294-c86c-4463-9703-11d767fa2ba1'></a>

## BACKGROUND
### Kenyan smallholders had limited opportunity

*   Kenyan smallholders had limited economic opportunities and there was a prevalence of hunger and poverty
    *   Disaggregation of farmers made it costly to collect output at the individual farm level
    *   Lack of crop management knowledge on the farm led to limited input use and poor and inconsistent quality yields

<a id='0cfcfb17-e973-4b0b-904a-1036d654946c'></a>

## ACTION
Private sector aggregates
demand

*   Frigoken, the largest vegetable processor in Kenya, began offering aggregation services and structured demand contracts to smallholders
    *   Provided inputs, extension services, credit, and spraying
    *   Established collection centers for farmer groups
    *   Collected produce from centers and brought it to factory for processing, packaging, and shipping
    *   Offered smallholders guaranteed income for crops

<a id='c6385171-4acf-45fd-9890-47e2ad4d3d68'></a>

OUTCOME
Smallholder income increases

*   Farmers receive increased income for their bean crop
    *   Beans at 4 X maize income and 2 X coffee income
*   Frigoken expands from just 50 smallholders in 1995 to more than 35,000 smallholders by 2007

<a id='f5428fdf-e1a8-4037-9fc9-07091d8bebc7'></a>

<::Two women harvesting tea leaves in a lush green field under a clear sky. The woman on the left wears a patterned dress and head covering, and has a large woven basket on her back. The woman on the right wears lighter clothing and also has a woven basket on her back. Both are bending over, picking leaves. To the right, a row of large, cylindrical industrial silos with associated buildings and structures under a bright blue sky.: figure::>

<a id='56f606e3-163c-4dc6-a28e-41fe62d6a9e8'></a>

SOURCE: Team analysis; interviews; literature search

<a id='d941f296-8557-4967-b52e-dd3af09880da'></a>

McKinsey & Company

<a id='55c577f9-ed86-4283-9f0d-93771f93811c'></a>

7

<!-- PAGE BREAK -->

<a id='c5c2057d-7d2b-4a6d-9d23-3780e4aef8ad'></a>

CHI-AAA123-20100803-

<a id='14c98ac9-1ce2-47c2-901c-b45c7c727f10'></a>

In addition to economics, contract and oversight is critical: Morocco example

<a id='db2f229e-348f-4995-8e2c-d778db3770c3'></a>

Territorial deepening (Ha by Ha) Standardized tools Standardized off-take contracts with price index <::image of two hands shaking: image::> + <::image of a line graph showing market data with the text "Change in 96": chart::> Regional price index platforms (market based) Deepening of the relationship agregator/aggregated SHF Offtake & Market access (hands-off) Standardized off-take contracts with price index Co-production (hands-on) Concretisation of conventions between state & banks Integrated financing package by crop/subsector Co-investment (hands-on +) Access to financing & subsidies <::image of a stack of US dollar bills: image::> + <::image of hands holding US dollar bills: image::> Deeper standardized contracts co-production & co-investment Structuring & monitoring of contracts more critical as level of integration increases

<a id='3da55f1f-f19b-4b3e-9841-dccf8ead3253'></a>

McKinsey & Company

<a id='b47f2b3e-63f1-48e4-942e-244e40b038ca'></a>

8

<!-- PAGE BREAK -->

<a id='ad3b1568-b8a7-4956-a69e-244d5e5468c5'></a>

CHI-AAA123-20100803-

<a id='afec2e06-bd42-4c7b-9a46-40b171113d46'></a>

There is also a need for building entrepreneurs
& business skills in most developing countries

Promising emerging models

<a id='7c335358-145d-4e29-ac81-430a03790dc0'></a>

<table><thead><tr><th>Some models for training</th><th>Description</th><th>Comments and efficiency for operational transformation purpose</th></tr></thead><tbody><tr><td>Traditional in class training<br><br><::transcription of the content: image of two people studying at a table::></td><td><ul><li>Theoretical training in an engineering school or university</li><li>Trained people receive a diploma or a certificate</li></ul></td><td><ul><li>10 % Recall rate 3 months after training</li><li>Perceived as very scholar</li><li>Little impact regarding real SME transformation</li></ul></td></tr><tr><td>Model factory<br><br><::transcription of the content: image of a large factory building with cars parked outside::></td><td><ul><li>Mix of Theoretical and practical training</li><li>Might be used a a tool to support different programs, from education only to multi SME transformation programs</li></ul></td><td><ul><li>Most scalable option – well adapted to training/scaling existing businesses</li></ul></td></tr><tr><td>End-to-end-support/training<br><br><::transcription of the content: image of a person in a hard hat looking at documents on a construction site::></td><td><ul><li>"Field & forum" training</li><li>Ongoing support, mentoring</li><li>Linkage to finance opportunities</li></ul></td><td><ul><li>Potentially costly model but effective for developing new entrepreneurs</li></ul></td></tr></tbody></table>

<a id='7fff60af-4398-47c0-a6c0-f94db3472495'></a>

SOURCE: McKinsey

<a id='2dcacf6f-19ee-4d78-a09b-1b1ee10a5b01'></a>

McKinsey & Company

<a id='7d5f5637-98fb-4b3b-a6ee-b11c85a1a7a1'></a>

9

<!-- PAGE BREAK -->

<a id='4063c29f-1d81-4278-91cb-a6241e8e9214'></a>

CHI-AAA123-20100803-

<a id='908952c0-bdfa-4d1e-a4fb-428dea84dc4d'></a>

Example: model factory

<a id='bc2564cd-6592-402c-9e69-d3853a773a7f'></a>

<::An overhead view of a busy factory floor shows multiple workers engaged in assembly tasks. In the foreground, a large, multi-tiered mobile rack system holds numerous blue plastic bins, some filled with parts, arranged on roller conveyors. A worker is seated behind this rack, looking towards the viewer. In the mid-ground, several workstations are visible, each with a worker. One female worker stands at a workstation, actively working with small components. Further back, two male workers are also occupied at their respective stations. The workstations are equipped with tools, parts, and what appear to be computer screens. The background reveals more industrial equipment, including conveyor systems, storage racks, and what might be automated machinery, extending into the distance. The floor is concrete with yellow demarcation lines. The overall scene depicts an organized and active manufacturing environment.: figure::>

<a id='98c789c4-31df-4d66-8172-2be9c651467c'></a>

The model factory is an innovative tool to disseminate Lean concepts

<a id='c865e1a4-a702-4b1b-8d6d-6fb7480d09b7'></a>

* Intensive training including line transformation from "current state" to "future state"
* Manufacturing of a real product
* Active qualification trough the concept of "Hearing, Seeing, Doing"
* Mapping the entire value-stream (material and information)
* Visible best-practice-showcases
* Covering all building blocks of a lean production system

<a id='be409a54-ac75-4f0d-b207-8a29b7a9988c'></a>

SOURCE: McKinsey

<a id='d0c941ec-dd79-400b-a9ea-3f12481f5836'></a>

McKinsey & Company

<a id='de9772d9-7044-4117-98f2-634658a1fd9f'></a>

10

<!-- PAGE BREAK -->

<a id='64510328-5094-48e6-ac6a-6b0aab792e8a'></a>

CHI-AAA123-20100803-

<a id='d4abbd1c-6fc5-42e4-a52d-19868004669c'></a>

In summary

<a id='6c59bd65-3daa-4399-9517-d67d884ab503'></a>

<::A photograph shows two women harvesting tea leaves in a lush green tea plantation under a clear blue sky. Both women are bent over, carefully plucking leaves from the tea bushes. The woman on the left wears a red patterned dress and a headscarf, with a large woven basket strapped to her back. The woman on the right wears a light-colored shirt, a light-colored cap, and a skirt, also with a large woven basket on her back. Tall trees are visible in the background.: figure::>

<a id='d879cac0-23c9-4bc2-966f-4a634b5d4ab5'></a>

- We believe private sector offers real opportunity for sustainable change & impact
- Models exist that are working!
- Real challenges exist in
  - Ensuring honest and accurate assessment of economics
  - Contract management and oversight to ensure social benefits
  - Innovative methods of training entrepreneurs

<a id='8779b542-e9fb-4bf5-b4b4-d7108c05da4f'></a>

McKinsey & Company

<a id='5dd5c7d9-f598-4818-97c5-01d72dec6fff'></a>

11