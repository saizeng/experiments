# Query Router & Planner (LangGraph)

An intelligent query routing system built on **LangGraph** that classifies
user questions, plans execution across a registry of skills, and
orchestrates results using a stateful graph.

Every capability — structured data access, document search, web search,
report generation — is a **skill**: a folder with a `SKILL.md` manifest
and a `run.py` entry point.

## Architecture

```
                    ┌────────────────────┐
                    │   START            │
                    └────────┬───────────┘
                             │
                             ▼
                    ┌────────────────────┐
                    │   plan             │  LLM decomposes query,
                    │   (planner node)   │  picks skills, sets deps
                    └────────┬───────────┘
                             │
                             ▼
                    ┌────────────────────┐
                    │   route            │  Conditional edge:
                    │   (router edge)    │  checks ready steps
                    └──┬─────┬─────┬────┘
                       │     │     │
          ┌────────────┘     │     └────────────┐
          ▼                  ▼                  ▼
  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
  │ execute_step │  │ execute_step │  │ execute_step │  Parallel
  │ (skill run)  │  │ (skill run)  │  │ (skill run)  │  fan-out
  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘
         │                 │                 │
         └────────┬────────┘─────────────────┘
                  ▼
         ┌────────────────────┐
         │   route            │  Loop: more steps ready?
         │   (check deps)     │──── yes ──→ execute_step
         └────────┬───────────┘
                  │ no
                  ▼
         ┌────────────────────┐
         │   synthesize       │  LLM merges all step results
         └────────┬───────────┘
                  │
                  ▼
         ┌────────────────────┐
         │   END              │
         └────────────────────┘
```

## Project Structure

```
query-router/
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI entry point
│   ├── config.py             # Settings & env vars
│   ├── state.py              # LangGraph state schema
│   ├── graph.py              # LangGraph graph definition
│   ├── nodes/
│   │   ├── __init__.py
│   │   ├── planner.py        # Plan node: LLM query decomposition
│   │   ├── executor.py       # Execute node: runs a single skill
│   │   └── synthesizer.py    # Synthesize node: merges results
│   └── skill_registry.py     # Discovers & loads SKILL.md files
├── skills/                   # Every capability lives here
│   ├── structured_data/
│   ├── unstructured_docs/
│   ├── web_search/
│   ├── generate_report/
│   └── deal_comparison/
├── tests/
├── pyproject.toml
├── .env.example
└── README.md
```

## Quick Start

```bash
pip install -e ".[dev]"
cp .env.example .env           # add your ANTHROPIC_API_KEY
uvicorn app.main:app --reload

# Full pipeline
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What was Acme revenue last quarter and what does the merger agreement say about earnouts?"}'

# Dry-run (plan only)
curl -X POST http://localhost:8000/plan \
  -H "Content-Type: application/json" \
  -d '{"question": "Compare the Acme and Globex deals"}'
```

## Adding Skills

1. Create `skills/my_skill/SKILL.md` with YAML frontmatter
2. Create `skills/my_skill/run.py` (reads JSON stdin → writes JSON stdout)
3. Restart the server — auto-discovered

See existing skills for the pattern.
