<a id='a69b14ce-efac-4049-b295-4f6a974bfb1b'></a>

<::McKinsey & Company logo
: figure::>

<a id='30be57ee-c4d0-422b-b7ef-41e62373c5d4'></a>

# Transportation and
# Warehousing
# Sector Analysis

Federal City Council

October 2020

<a id='9367244b-03a1-4e44-83ed-e23ddfee8d53'></a>

CONFIDENTIAL AND PROPRIETARY
Any use of this material without specific permission of McKinsey & Company
is strictly prohibited

<a id='80db0612-6435-4d0e-b415-6fe75442e383'></a>

<::Two images. The top image shows a man and a woman riding bicycles, both wearing helmets. The US Capitol building is visible in the background. The woman is on the left, smiling, wearing a striped shirt and a dark jacket. The man is on the right, wearing a white shirt and a blue tie. The bottom image shows the front and side of a red tram or train. The destination sign on the front reads "2018" and "tion to Oklah". The side of the tram has a yellow stripe pattern and the "dc." logo with some text below it.: figure::>

<!-- PAGE BREAK -->

<a id='b1f524c0-8024-4171-902e-f5e9145d641e'></a>

Contents

<a id='6f3c5b0d-1e7f-4dba-8158-e07452f96b1d'></a>

Baseline Conditions

Challenges and trends

Opportunities and best practices

Appendix

<a id='a409ca61-201d-428e-819e-1589de6e00ec'></a>

McKinsey & Company

<a id='5cba64e5-a6b6-49ad-a154-b7a5e29a199e'></a>

2

<a id='63a3a57e-c18d-418a-868b-62204906ce7c'></a>

Last Modified: 1/13/2023 6:03 PM Eastern Standard Time

<a id='b61e16a5-11e1-4d84-b07e-e81183b53b0b'></a>

Printed

<!-- PAGE BREAK -->

<a id='fc130c4e-5b67-4774-9502-0ac8c9cc2fcf'></a>

The transportation sector in DC has modest employment...

<a id='4dc47802-5d48-4149-97e7-946b27853442'></a>

<::Employment growth and specialization by industry
: chart::>

Employment CAGR (2019-24)
3.5
3.0
2.5
2.0
1.5
1.0
0.5
0
-0.5
-1.0
-1.5
-2.0
-2.5
-3.0
-3.5

Employment specialization
0 0.2 0.4 0.6 0.8 1.0 1.2 1.4 1.6 1.8 2.0 2.2 2.4 2.6 2.8

LQ = 1

Legend:
Light gray circle: ~50K jobs

Data points:
- Bubble at (0.3, 3.4): (unlabeled)
- Bubble at (0.4, 2.0): Construction
- Bubble at (0.3, 0.9): (unlabeled)
- Bubble at (0.7, 1.1): Finance and insurance
- Bubble at (0.9, 0.1): Admin. and support and waste management and remediation services
- Bubble at (1.5, 1.7): Other services
- Bubble at (2.2, 1.1): Professional, scientific, and technical services
- Bubble at (2.2, 0.2): Government
- Bubble at (2.7, -0.4): Educational services
- Bubble at (1.5, -0.8): Information
- Bubble at (0.8, -0.6): Real estate and rental and leasing
- Bubble at (0.7, -1.6): (unlabeled, outlined bubble)
- Bubble at (0.4, -2.8): Transportation and warehousing (blue bubble)
- Bubble at (0.1, -3.0): (unlabeled)
- Bubble at (1.1, -3.1): Accommodation and food services
- Bubble at (2.8, -2.5): (unlabeled, large arrow pointing right)
::>

<a id='7ceb0520-a281-4e38-a7b7-8571569b5dfe'></a>

...but is a critical enabler of economic competitiveness

<a id='c356b40f-a281-45db-b417-4b47d0547abf'></a>

Transit solutions are essential to **manage congestion** and support **optimal land use**:

- Reduces congestion by **25%**, saving more than **$1.5 billion** annually in wasted time and fuel
- Saves **1 million+** auto trips per day
- Frees up **200,000** more parking spaces in the core, equivalent of **166 blocks** of five-story garages

<a id='fdd13f73-be10-4a0f-8370-b35b091d2b78'></a>

DC has one of the highest rates of **transit** and **bike** usage among major cities in the US:
*   **34%** of workers commute by public transit (**3rd** highest among large US cities) and **4%** of workers commute by bicycle (**2nd** highest)³

<a id='9c43e5bc-cbba-4f33-b4f5-95e51da8d4c9'></a>

Transit enhances DC's affordability for its residents:
- $342 million/year in auto expenditures saved by households using Metro due to reduced car ownership, operating, and maintenance costs
- 360,000 trips by transit dependents per day

<a id='c20b8352-a39a-483a-ba21-7435f9c92402'></a>

* Transportation and warehousing sector is ~2% of DC employment
* 3% decline in jobs forecasted between 2019-24, largely due to COVID-19
* Low specialization relative to the US as a whole (LQ = 0.4)

<a id='bc8dbf65-be41-4bb4-b056-cb1526796480'></a>

1 Mining, quarrying, and oil and gas extraction not included; Forecast from Moody's Analytics;
2 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole;
3 With working populations greater than 250K

<a id='9fe6ec55-838a-4c1a-b856-ddb125ded25f'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics; WMATA "Why Metro Matters"; US Census

<a id='753f3375-155d-4d88-9518-600c730d3a68'></a>

McKinsey & Company

<a id='89de8574-b267-4422-b733-a9659e5bc218'></a>

3

<!-- PAGE BREAK -->

<a id='1b0cbd19-3d4f-4952-8544-03c646307824'></a>

## Transportation and warehousing is a relatively small sector in DC with low specialization relative to US average
---
Employment, growth, and specialization by major industry

<a id='aadce48f-2e9a-4cf5-a949-f429951b8a62'></a>

option Focus of this document: [x] option Analyses by other firms: [ ]

<::table::>
| Sector | Included in sector analysis | Size Jobs, 2019¹ | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %² | Specialization Jobs LQ³ |
|:---|:---|:---|:---|:---|:---|
| Government and government enterprises | [x] | 248,311 | 0% | 0% | 2.2 |
| Professional, scientific, and technical services | [x] | 147,712 | 3% | 2% | 2.2 |
| Other services (except government and government enterprises)⁴ | [x] | 86,662 | 2% | 1% | 1.6 |
| Health care and social assistance | [ ] | 76,211 | 1% | -2% | 0.7 |
| Accommodation and food services | [x] | 75,933 | 3% | -3% | 1.1 |
| Educational services | [x] | 59,427 | -1% | 0% | 2.7 |
| Admin. and support and waste management and remediation services | [ ] | 52,751 | 0% | -1% | 0.9 |
| Real estate and rental and leasing | [x] | 32,102 | 3% | -2% | 0.7 |
| Finance and insurance | [x] | 27,956 | 3% | 1% | 0.6 |
| Retail trade | [ ] | 26,806 | 2% | 0% | 0.3 |
| Information | [x] | 22,510 | 3% | -1% | 1.4 |
| Arts, entertainment, and recreation | [x] | 19,640 | 6% | 0% | 0.9 |
| Construction | [x] | 17,961 | 1% | 2% | 0.4 |
| Transportation and warehousing | [x] | 15,145 | 13% | -3% | 0.4 |
| Wholesale trade | [ ] | 5,782 | 0% | 1% | 0.2 |
| Management of companies and enterprises | [ ] | 3,489 | 6% | 3% | 0.3 |
| Manufacturing | [ ] | 2,154 | 4% | -3% | 0.0 |
| Utilities | [ ] | 2,116 | 1% | -3% | 0.8 |
| Mining, quarrying, and oil and gas extraction | [ ] | 252 | -10% | -1% | 0.0 |
| Total | | 923,009 | 1% | 0% | 1.0 |
<::/table::>

<a id='791a4950-4a9b-4e6a-a309-31292002e5c5'></a>

Transportation and warehousing represents <2% of total DC employment

1 Full-time and part-time; Includes Wage and salary employment and Proprietors employment;
2 Forecasts from Moody's Analytics;
3 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole;
4 Other services is an especially large sector in DC as it includes NGOs and other institutions

<a id='d6caf686-96e9-4542-ba83-dce9198e9fb1'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics

<a id='523db314-0672-4f15-80a8-e96e8bafcb80'></a>

McKinsey & Company

<a id='82552c71-03ef-413f-ac47-2f4d7290ecd3'></a>

4

<!-- PAGE BREAK -->

<a id='8a6d99f0-5af8-4bf1-ac0e-267a31b6a307'></a>

Transit and ground passenger transportation is by far the largest
employer within this sector in DC
Employment, growth, and specialization by subsector

<a id='7ad39a8e-5cda-40f5-9447-e0ef9737bd00'></a>

<::table::>| Subsector | Size Jobs, 2019¹ | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %² | Specialization Jobs LQ³ ||---|---|---|---|---|| Transit and ground passenger transportation⁴ | 10,156 | 18% | -4% | 1.0 || Couriers and messengers | 1,635⁵ | NA⁶ | 1% | 0.3 || Rail transportation | 1,580 | -2% | -4% | 2.0 || Scenic and sightseeing transportation | 662 | 9% | -4% | 2.8 || Support activities for transportation | 394 | 18% | -1% | 0.1 || Truck transportation | 375 | 5% | -1% | 0.0 || Air transportation | 91 | -2% | -3% | 0.0 || Warehousing and storage | 69 | NA⁶ | 2% | 0.0 || Water transportation | 30 | NA⁶ | -3% | 0.1 || Transportation and warehousing (total) | 15,145 | 13% | -3% | 0.4 <::/table::>

<a id='0eb03fea-3f7a-4c0c-b19c-77721d5c6564'></a>

1. Full-time and part-time; Includes Wage and salary employment and Proprietors employment; Subsector jobs may not add up 100% to total due to data suppression
2. Forecasts from Moody's Analytics
3. Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole
4. Includes transit networks such as WMATA and rideshare such as Uber and Lyft, etc.
5. 2018 data (2019 data suppressed)
6. Historical data points suppressed

<a id='96742037-7e6f-4761-ba2f-3ef29ea29b9a'></a>

Source: Bureau of Economic Analysis (BEA), SAEMP25N Total Full-Time and Part-Time Employment by NAICS Industry; Moody's Analytics

<a id='f2dbc597-34b8-4d28-80da-b11ce09c1892'></a>

McKinsey & Company

<a id='bb8fb772-8423-4e13-9acb-a9e34d3eb82d'></a>

5

<!-- PAGE BREAK -->

<a id='8d7abcd0-5207-4c5e-bad0-1f4d0b67d205'></a>

Top Transportation occupations employ a majority of Black workers, and are at highest risk of displacement from automation

<a id='321018b5-9a63-4c9a-8952-42e919c050ae'></a>

White Black or African American Latinx Other¹
Top 10 Transportation and warehousing occupations
by number of jobs within industry in DC¹
Thousand, 2019

Median annual
earnings
$

Automation
potential
%²

Employment share by race
%

Passenger Vehicle Drivers, Except Bus Drivers, Transit and Intercity
2.1
31,998
76%³
<::bar chart showing Employment share by race for Passenger Vehicle Drivers, Except Bus Drivers, Transit and Intercity: White 10%, Black or African American 82%, Latinx 7%, Other¹ 1%::>
10
82
7
1
Passenger Attendants
0.4
39,499
80%⁴
<::bar chart showing Employment share by race for Passenger Attendants: White 11%, Black or African American 77%, Latinx 9%, Other¹ 3%::>
11
77
9
3
Light Truck Drivers
0.3
38,616
78%
<::bar chart showing Employment share by race for Light Truck Drivers: White 30%, Black or African American 53%, Latinx 12%, Other¹ 5%::>
30
53
12
5
Heavy and Tractor-Trailer Truck Drivers
0.3
52,467
81%
<::bar chart showing Employment share by race for Heavy and Tractor-Trailer Truck Drivers: White 33%, Black or African American 49%, Latinx 14%, Other¹ 4%::>
33
49
14
4
Bus Drivers, Transit and Intercity
0.2
33,495
85%
<::bar chart showing Employment share by race for Bus Drivers, Transit and Intercity: White 14%, Black or African American 78%, Latinx 5%, Other¹ 3%::>
14
78
5
3
Laborers and Freight, Stock, and Material Movers, Hand
0.1
39,251
7%
<::bar chart showing Employment share by race for Laborers and Freight, Stock, and Material Movers, Hand: White 29%, Black or African American 53%, Latinx 13%, Other¹ 5%::>
29
53
13
5
Couriers and Messengers
0.1
34,172
39%
<::bar chart showing Employment share by race for Couriers and Messengers: White 36%, Black or African American 46%, Latinx 11%, Other¹ 7%::>
36
46
11
7
Dispatchers, Except Police, Fire, and Ambulance
0.1
51,693
40%
<::bar chart showing Employment share by race for Dispatchers, Except Police, Fire, and Ambulance: White 36%, Black or African American 49%, Latinx 11%, Other¹ 4%::>
36
49
11
4
General and Operations Managers
0.1
143,716
23%
<::bar chart showing Employment share by race for General and Operations Managers: White 61%, Black or African American 22%, Latinx 8%, Other¹ 9%::>
61
22
8
9
Railroad Conductors and Yardmasters
0.1
71,353
46%
<::bar chart showing Employment share by race for Railroad Conductors and Yardmasters: White 17%, Black or African American 79%, Latinx 3%, Other¹ 1%::>
17
79
3
1

* All top roles (except operations managers) have a higher share of Black workers than DC as a whole, which is 44% Black and 37% White (both non-Latinx)
* These jobs all require a high school diploma, except for heavy truck drivers (certificate) and operations managers (Bachelor's)
* In the medium term, the District can work towards upskilling workers from high automation jobs to those with less risk and higher wages 

<a id='1d3cd660-1988-4477-ac3a-1aec2d4cfe9f'></a>

1. Asian, American Indian or Alaska Native, Native Hawaiian or Other Pacific Islander, Two or More Races; does not include all "Proprietors employment", which includes many small business owners and contractors
2. Dark = lowest risk of automation; preliminary analysis
3. Taxi drivers and chauffeurs used for automation analysis
4. Transportation attendants used for automation analysis

<a id='1888af1f-ce3b-44e4-96a7-014d8583e74f'></a>

Source: EMSI; Bureau of Labor Statistics (BLS); McKinsey Global Institute (MGI)

<a id='5f42c6b8-b934-4c41-ae32-d29fbdd67760'></a>

McKinsey & Company

<a id='ff2f964a-405d-438f-b66a-4d5929cc2647'></a>

6

<!-- PAGE BREAK -->

<a id='a24c9754-3764-41f3-ad82-c5e4e41cf305'></a>

Contents

<a id='043963dd-3d47-4ef8-82e9-d857a3a4270b'></a>

Baseline Conditions
Challenges and trends
Opportunities and best practices
Appendix

<a id='ff73603b-bf72-423a-8b7b-035ac7de149e'></a>

McKinsey & Company

<a id='cd5621e2-8fd4-4844-a139-a02aa9a7b483'></a>

7

<a id='3abdbdcb-e347-4db2-9d92-8b30fd39975e'></a>

Last Modified 7/13/2020 6:00 PM Eastern Standard Time

<a id='dee96f76-0aba-4726-b09b-30e9fb9aa6e9'></a>

Printed

<!-- PAGE BREAK -->

<a id='dfa52485-66e7-4e97-a801-582fe7e27ba7'></a>

Preliminary, proprietary, pre-decisional Non-exhaustive

<a id='4e2da983-506c-4592-b00c-068d5ec0be01'></a>

Mobility in DC: Five core challenges will shape the future of the sector and its ability to support broader economic competitiveness

<a id='9c5de6c5-2b63-4b5c-b571-4e56989965e6'></a>

<table><thead><tr><th>Challenge</th><th>A – Pre-COVID-19 trends</th><th>B – Impacts of COVID-19</th></tr></thead><tbody><tr><td>1<br>$<br>Health and<br>viability of transit</td><td>Strong existing transit base with declining ridership levels<ul><li>34% of workers commute by public transit (3rd highest among large US cities) and 4% of workers commute by bicycle (2nd highest)</li><li>15% and 20% decline in rail and bus ridership from 2011-19</li></ul></td><td>Significant transit ridership drop and funding gaps<ul><li>38% and 13% Metrobus and Metrorail ridership compared to pre-COVID levels as of end of Summer</li><li>~$250 million budget gap forecasted by WMATA through end of FY</li><li>5% decline in Trade, transportation, and utilities jobs (Aug '19-20)</li></ul></td></tr><tr><td>2<br>/\<br>Mitigating<br>Congestion and<br>its impacts on<br>productivity</td><td>Congestion, long commute times and increased TNCs<ul><li>3rd in yearly delays per auto commuter among large metros (~$2K annual cost of congestion per commuter)</li><li>3/4 of public transit riders and 1/2 of drivers face daily commutes over 30 minutes</li></ul></td><td>Short-term congestion decline, rebound expected; rise of telework<ul><li>3% increase in driving demand since the start of the pandemic</li><li>55% of executives said most (60-100%) office employees will work remotely at least one day a week post-COVID-19<sup>1</sup></li></ul></td></tr><tr><td>3<br>Managing the<br>curbside</td><td>Pressure on curb from TNCs, e-commerce and curbside delivery<ul><li>10,000 new rideshare drivers added annually (2014-17) in the D.C. metro area</li><li>98% increase in e-commerce sales from 2014 to 2019<sup>1</sup></li></ul></td><td>Continued rise of e-commerce, with new uses for the curb<ul><li>32% increase in e-commerce sales from 2020 Q1 to Q2<sup>1</sup></li><li>81% of 685 poll respondents support "streeteries" post-COVID</li></ul></td></tr><tr><td>4<br>Ensuring equity<br>in transportation<br>and transit access</td><td>Unequal transit access among communities of color<ul><li>39% of Black residents in low-income neighborhoods lack access to high frequency transit</li><li>33.7 minutes is the average commute time for Black workers, longest among racial groups</li></ul></td><td>Unequal transit access for essential workers<ul><li>62% of jobs requiring less formal training, such as drivers and clerks, can be reached by residents with applicable skills (compared to 72% for high-skill jobs and residents)</li><li>50% of Health technologists (example occupation) in low-income neighborhoods lack access to high frequency transit</li></ul></td></tr><tr><td>5<br>Ensuring safety</td><td>Lagging safety outcomes, most notably for cyclists<ul><li>4.3 bicycling fatalities per 1M population, higher than San Francisco, Seattle, Chicago, New York, Boston, and others</li><li>2nd highest share of bicycle commuters yet 15th and 27th city in number of miles of protected and unprotected bike lanes</li></ul></td><td>Increased demand for walking and biking: safety critical<ul><li>5% increase in biking and walking and 1% increase in shared micromobility expected immediately in the "new normal"<sup>1</sup></li></ul></td></tr></tbody><tfoot><tr><td colspan="3">1. US statistic</td></tr></tfoot></table>

<a id='94ac4f03-7cd4-49e5-80f4-0171e255a4f1'></a>

Source: US Census; WMATA, Regional Reopening Plans; PwC "US Remote Work Survey"; Texas A&M, 2019 Urban Mobility Report; Apple Mobility Trends Report; WUSA9; NHTSA Traffic Safety Facts; McKinsey Center for Future Mobility; Metropolitan Policy Program at Brookings; Barred in DC Twitter poll, accessed through WUSA9; BLS-Current Employment Statistics (CES); DCist

<a id='e285da6e-e43d-4d43-8e35-7a13821f9620'></a>

McKinsey & Company

<a id='ebf04d0e-b716-4eeb-85de-51919c8a1571'></a>

8

<!-- PAGE BREAK -->

<a id='adab2576-44f9-48df-9f6e-e830adec1a07'></a>

1b: WMATA has seen record low ridership that is just beginning to

<a id='69bd2760-7c69-409f-b742-cd802bf66c7e'></a>

recover
WMATA monthly ridership during COVID-19,
% of 2019 ridership, Jan-Jul 2020
<::Line chart showing WMATA monthly ridership during COVID-19 as a percentage of 2019 ridership from January to August 2020.
The x-axis represents months: Jan, Feb, Mar, Apr, May, Jun, Jul, Aug.
The y-axis represents the percentage of 2019 ridership.

Legend:
- Metrobus (black line)
- Metrorail (blue line)

Data points for Metrobus:
- Jan: ~105%
- Feb: 110%
- Mar: 33%
- Apr: 17%
- May: ~18%
- Jun: 19%
- Jul: 33%
- Aug: 38%

Data points for Metrorail:
- Jan: ~100%
- Feb: 112%
- Mar: 49%
- Apr: 5%
- May: ~8%
- Jun: 9%
- Jul: 10%
- Aug: 13%

Vertical dashed lines indicate key events:
- Between Mar and Apr: "Initial regional lockdown"
- Between May and Jun: "Phase 1 reopening (DC)"
- Between Jun and Jul: "Phase 2 reopening (DC)"
: chart::>

<a id='92b816aa-163a-496d-a5ff-0163d12e664d'></a>

Source: WMATA, Regional Reopening Plans

<a id='2b0a11b5-fef1-4d71-83cd-a30dad708d48'></a>

McKinsey & Company

<!-- PAGE BREAK -->

<a id='18f87d19-771b-4fc0-995b-19af07cdef4e'></a>

1b: Employment in Trade, transportation, and utilities declined by 5%, which was not as steep a decline as DC overall

<a id='62de5069-fa88-41af-b497-6ad7c15f1663'></a>

Change in employment by major industry from August 2019 to August 2020¹
% change

<a id='631153a6-fd45-4cca-a5ba-9d09b2ede971'></a>

<::chart: Bar chart comparing percentage changes for various sectors in DC and US::> DC US Leisure and hospitality -47 -23 Manufacturing -8 -6 Total -7 -7 Financial activities -6 -1 Education and health services -6 -5 Trade, transportation, and utilities -5 -4 Professional and business services -4 -6 Construction 1 -4 Government 2 -3 <::/chart::>

<a id='df09ea4d-07fe-44d7-88f9-c7a4dc91dca7'></a>

1. Available sectors with data shown here

<a id='ce420ff9-6d22-4d3a-a916-76b404211232'></a>

Source: Bureau of Labor Statistics (BLS) Current Employment Statistics (CES)

<a id='d2f0ab9f-44e9-4057-aaf5-401864e825ee'></a>

McKinsey & Company

<a id='349d8e5b-c16f-4f06-a64b-bb805b368260'></a>

10

<!-- PAGE BREAK -->

<a id='64c836ed-0e7f-47c7-9eb6-8f01c9dfdec2'></a>

2a: DC faces relatively high congestion delays and costs
National Congestion Table – What congestion means to you, 2017

<a id='2a068d88-1489-4097-ba2d-82af54542da9'></a>

<table id="10-1">
<tr><td id="10-2"></td><td id="10-3" colspan="2">Yearly Delay per Auto Commuter</td><td id="10-4" colspan="2">Travel Time Index</td><td id="10-5" colspan="2">Excess Fuel per Auto Commuter</td><td id="10-6" colspan="2">Congestion Cost per Auto Commuter</td></tr>
<tr><td id="10-7">Urban Area</td><td id="10-8">Hours</td><td id="10-9">Rank</td><td id="10-a">Value</td><td id="10-b">Rank</td><td id="10-c">Gallons</td><td id="10-d">Rank</td><td id="10-e">Dollars</td><td id="10-f">Rank</td></tr>
<tr><td id="10-g">Very Large Average (15 areas)</td><td id="10-h">83</td><td id="10-i"></td><td id="10-j">1.35</td><td id="10-k"></td><td id="10-l">32</td><td id="10-m"></td><td id="10-n">1,730</td><td id="10-o"></td></tr>
<tr><td id="10-p">Los Angeles-Long Beach-Anaheim CA</td><td id="10-q">119</td><td id="10-r">1</td><td id="10-s">1.51</td><td id="10-t">1</td><td id="10-u">35</td><td id="10-v">4</td><td id="10-w">2,676</td><td id="10-x">1</td></tr>
<tr><td id="10-y">San Francisco-Oakland CA</td><td id="10-z">103</td><td id="10-A">2</td><td id="10-B">1.50</td><td id="10-C">2</td><td id="10-D">39</td><td id="10-E">1</td><td id="10-F">2,619</td><td id="10-G">2</td></tr>
<tr><td id="10-H">Washington DC-VA-MD</td><td id="10-I">102</td><td id="10-J">3</td><td id="10-K">1.35</td><td id="10-L">7</td><td id="10-M">38</td><td id="10-N">2</td><td id="10-O">2,015</td><td id="10-P">3</td></tr>
<tr><td id="10-Q">New York-Newark NY-NJ-CT</td><td id="10-R">92</td><td id="10-S">4</td><td id="10-T">1.35</td><td id="10-U">7</td><td id="10-V">38</td><td id="10-W">2</td><td id="10-X">1,947</td><td id="10-Y">4</td></tr>
<tr><td id="10-Z">Boston MA-NH-RI</td><td id="10-10">80</td><td id="10-11">6</td><td id="10-12">1.30</td><td id="10-13">19</td><td id="10-14">31</td><td id="10-15">7</td><td id="10-16">1,580</td><td id="10-17">8</td></tr>
<tr><td id="10-18">Seattle WA</td><td id="10-19">78</td><td id="10-1a">7</td><td id="10-1b">1.37</td><td id="10-1c">5</td><td id="10-1d">31</td><td id="10-1e">7</td><td id="10-1f">1,541</td><td id="10-1g">9</td></tr>
<tr><td id="10-1h">Atlanta GA</td><td id="10-1i">77</td><td id="10-1j">8</td><td id="10-1k">1.30</td><td id="10-1l">19</td><td id="10-1m">31</td><td id="10-1n">7</td><td id="10-1o">1,653</td><td id="10-1p">5</td></tr>
<tr><td id="10-1q">Houston TX</td><td id="10-1r">75</td><td id="10-1s">9</td><td id="10-1t">1.34</td><td id="10-1u">11</td><td id="10-1v">31</td><td id="10-1w">7</td><td id="10-1x">1,508</td><td id="10-1y">10</td></tr>
<tr><td id="10-1z">Chicago IL-IN</td><td id="10-1A">73</td><td id="10-1B">10</td><td id="10-1C">1.32</td><td id="10-1D">16</td><td id="10-1E">30</td><td id="10-1F">12</td><td id="10-1G">1,431</td><td id="10-1H">11</td></tr>
<tr><td id="10-1I">Miami FL</td><td id="10-1J">69</td><td id="10-1K">12</td><td id="10-1L">1.31</td><td id="10-1M">17</td><td id="10-1N">34</td><td id="10-1O">5</td><td id="10-1P">1,412</td><td id="10-1Q">12</td></tr>
<tr><td id="10-1R">Dallas-Fort Worth-Arlington TX</td><td id="10-1S">67</td><td id="10-1T">13</td><td id="10-1U">1.26</td><td id="10-1V">23</td><td id="10-1W">25</td><td id="10-1X">20</td><td id="10-1Y">1,272</td><td id="10-1Z">18</td></tr>
<tr><td id="10-20">San Diego CA</td><td id="10-21">64</td><td id="10-22">16</td><td id="10-23">1.35</td><td id="10-24">7</td><td id="10-25">24</td><td id="10-26">27</td><td id="10-27">1,584</td><td id="10-28">7</td></tr>
<tr><td id="10-29">Philadelphia PA-NJ-DE-MD</td><td id="10-2a">62</td><td id="10-2b">18</td><td id="10-2c">1.25</td><td id="10-2d">25</td><td id="10-2e">26</td><td id="10-2f">15</td><td id="10-2g">1,203</td><td id="10-2h">22</td></tr>
<tr><td id="10-2i">Phoenix-Mesa AZ</td><td id="10-2j">62</td><td id="10-2k">18</td><td id="10-2l">1.27</td><td id="10-2m">22</td><td id="10-2n">26</td><td id="10-2o">15</td><td id="10-2p">1,089</td><td id="10-2q">30</td></tr>
<tr><td id="10-2r">Detroit MI</td><td id="10-2s">61</td><td id="10-2t">20</td><td id="10-2u">1.24</td><td id="10-2v">28</td><td id="10-2w">25</td><td id="10-2x">20</td><td id="10-2y">1,129</td><td id="10-2z">25</td></tr>
</table>

<a id='7fec8a4e-f9cb-41d4-bc16-a1f664f7f941'></a>

Source: Texas A&M, 2019 Urban Mobility Report

<a id='b59cf8c9-034b-4d3c-91d0-320e61120577'></a>

McKinsey & Company

<a id='f8b8c095-39d6-4a55-b15d-302a80f85277'></a>

11

<!-- PAGE BREAK -->

<a id='20808a64-a049-4cb2-93e6-11dd6dfddba8'></a>

**2a: Three-quarters of public transit riders and half of drivers face daily commutes over 30 minutes**---

<a id='6e89653b-6053-46cf-a689-f4560b6dd51d'></a>

51% of DC automobile commuters have trips longer than 30min<::bar chart: Commute time by automobile, 2017. Percent of automobile commuters by commute time: <15 mins (12%), 15-29 mins (38%), 30-44 mins (32%), >45 mins (19%). Commute time by public transportation, 2017. Percent of public transit commuters by commute time: <15 mins (2%), 15-29 mins (22%), 30-44 mins (41%), >45 mins (35%).::>76% of public transportation users have commutes over 30 minutes Travel time

<a id='c5689809-b137-48d1-8ee1-121cdd208fc0'></a>

Walking and
biking are most
common for
commutes less
than 30min

<::
Bar chart showing commute time by walking and by other methods in 2017.

**Commute time by walking, 2017**
Y-axis: % of walking commuters
X-axis: Travel time (minutes)
- <15 mins: 36%
- 15-29 mins: 44%
- 30-44 mins: 14%
- >45 mins: 6%

**Commute time by other methods, 2017**
Y-axis: % of other transit commuters
X-axis: Travel time (minutes)
- <15 mins: 23%
- 15-29 mins: 51%
- 30-44 mins: 21%
- >45 mins: 5%
: chart::>


<a id='d3ed0472-8d42-4715-ab3d-439e68df0a60'></a>

1. Other includes commuters using bicycles, motorcycles, taxicabs, etc.

<a id='dae9ca27-c42f-47d1-a912-adb9c60fe75e'></a>

Source: US Census - American Community Survey; WalletHub

<a id='de4935a7-262a-4d6f-bad9-923b911bf741'></a>

Metro DC commuters mode of transit, % of commuters using specific mode of transit, 2016<::Metro DC commuters mode of transit pie chart, 2016: Automobile 80%, Public transit 14%, Walk 4%, Other 2%: chart::>• DC ranked **86th of 100** cities in WalletHub's “**Best & Worst Cities to Drive in**” in 2020• **14% of DC metro commuters use public transit, which is significantly lower than automobile usage, but still one of the highest rates of public transit usage** among metro areas• As a city, Washington, DC has the **3rd highest public transit usage** in the US (34%), after New York and San Francisco

<a id='2288159e-4d23-4342-a1c1-80137f031cb4'></a>

McKinsey & Company

<a id='1f08ce81-5bda-4cab-9121-1db2422b70d2'></a>

12

<!-- PAGE BREAK -->

<a id='9457d401-aa8a-4fe5-a3ef-f5c40f380654'></a>

2b: Transit demand is down significantly but driving is up since the start of the pandemic

<a id='0fad4c23-5fd8-4fef-af4f-3904e01ede42'></a>

<::line chart::>Mobility trends, Change in routing requests since January 13, 2020. The chart displays three lines representing different modes of transport: Driving (red, +3%), Walking (orange, -15%), and Transit (purple, -55%). The y-axis ranges from -80% to +60%, indicating the percentage change. The x-axis shows months from January to October. All three lines show high volatility in Jan-Feb, then a sharp drop in March, indicating a significant decrease in mobility. Driving and Walking then show a gradual recovery from April to October, with Driving generally returning to pre-March levels and Walking remaining below. Transit remains significantly suppressed throughout the entire period after March, hovering around -60% to -50%::>

<a id='e5937b22-05d9-4e5b-a731-6726fe2a3999'></a>

Source: Apple Mobility Trends Report

<a id='36b25202-8f87-435f-9937-ffd0dfed1896'></a>

McKinsey & Company

<a id='dca09373-a7e5-406d-9885-cb966e6941d2'></a>

13

<!-- PAGE BREAK -->

<a id='82400929-0534-4156-96f9-f791254e9913'></a>

**2b: ~50% of white collar workers are teleworking, and many will continue to work remotely post-COVID part-time**
Teleworking is a challenge and opportunity for transportation systems
---


<a id='130cf3d4-eb11-44ea-9cb7-25aceaeb1881'></a>

Share of teleworkers by industry in the United States, May 2020 to September 2020¹
% of workers within industry

<a id='2ea0f501-7e4c-494a-a8aa-80ce3d1357e8'></a>

Educational services
Finance and insurance
Professional and technical services
Information
Public administration
Real estate and rental and leasing
Arts, entertainment, and recreation
Utilities
Mining, quarrying, and oil and gas extraction
Wholesale trade
Manufacturing
Other services
Health care and social assistance
Management, administrative, and waste services
Retail trade
Construction
Transportation and warehousing
Accommodation and food services

<a id='6cdfaf7f-a4a3-462e-8139-a90cdcf88cfd'></a>

<::Horizontal bar chart titled "May 2020" showing 18 bars with the following values (from top to bottom): 76, 67, 64, 61, 46, 42, 38, 37, 32, 31, 30, 28, 25, 24, 17, 15, 12, 8.

Horizontal bar chart titled "September 2020" showing 18 bars with the following values (from top to bottom): 41, 53, 50, 45, 33, 26, 21, 27, 22, 22, 20, 15, 16, 14, 9, 8, 8, 5.
: bar chart::>

<a id='a32136f2-b04a-4ab2-8744-207b5edcff7e'></a>

According to PwC's US Remote Work Survey:
*   **55%** of executives said most (60-100%) of office employees will work remotely at **least one day a week** post-COVID-19
*   **72%** of surveyed office workers would like to work remotely at **least two days per week**

According to Upwork's The Future of Remote Work
*   **~20%** of the workforce is likely to continue **working remotely** on a **full-time** basis
*   **~33%** will continue doing so **part-time**

<a id='62ff5265-8c06-4a57-8911-d090454df2f5'></a>

The rise in telework presents challenges and opportunities for transit, as people may decide to live further from their employer's offices (swapping a longer, occasional commute for more space), commute to work less times per week, and take more local trips throughout the day during "off-peak" hours

<a id='e3a9e060-1375-4400-accb-1db68d2caeae'></a>

1. Data from BLS - CPS; Full description: Employed persons who teleworked or worked at home for pay at any time in the last 4 weeks because of the coronavirus pandemic

<a id='eb219d5b-a0d7-4e7c-973b-167edfd1c673'></a>

Source: Bureau of Labor Statistics (BLS) - Current Population Survey (CPS); PwC - US Remote Work Survey; Upwork - The Future of Remote Work; government technology magazine

<a id='59bb2f50-cd24-4f8c-9fa0-ba7f99259278'></a>

McKinsey & Company

<a id='71e69ae6-c0f6-4457-ae0b-c8e8831e6a12'></a>

14

<!-- PAGE BREAK -->

<a id='32a23779-8b60-4f58-9db4-3318417f3b3f'></a>

4a: Transit commutes correlate with income and race, though many workers in low-income neighborhoods work outside DC Commute time to work via public transportation % commuters traveling >45 mins Race % Black population Household income % income <$35K 0.6 correlation between Black population and commute time Place of work % work in DC <::Four choropleth maps of Washington D.C. neighborhoods are displayed side-by-side, each illustrating different demographic or commute-related data. From left to right: Map 1: Commute time to work via public transportation, showing the % commuters traveling >45 mins. Map 2: Race, showing the % Black population. Map 3: Household income, showing the % income <$35K. Map 4: Place of work, showing the % work in DC. Maps 1, 2, and 3 share a common legend at the bottom left: <20%, 20-40%, 40-60%, 60-80%, >80%, and No data (gray). Map 4 has its own legend at the top right: <60%, 60-70%, 70-80%, 80-90%, >90%. All maps use a color gradient from light to dark red to represent increasing percentages, with lighter shades indicating lower values and darker shades indicating higher values.: chart::> 

<a id='01cda940-f99c-4dfd-95b2-e3b01874116c'></a>

Source: US Census

<a id='a31f2158-b09a-477d-8ce2-646df3c0b2de'></a>

McKinsey & Company

<a id='f52796d9-2371-460a-bb6c-cac53fff71ca'></a>

15

<!-- PAGE BREAK -->

<a id='9575b799-1797-4208-877b-d0b1996ebc02'></a>

**4a: Swathes of low income districts are under-served by high-frequency transit**

<a id='59484d7f-0460-4f77-8d53-791eac542df2'></a>

Population by household income% income <$35KHigh-frequency bus lines²Metro stops³<20%20-40%40-60%60-80%>80%No data<::A choropleth map of a geographical area, likely Washington D.C., showing the percentage of households with income less than $35,000. The map is divided into numerous smaller regions, colored according to the income percentage: very light orange for <20%, light orange for 20-40%, medium orange for 40-60%, dark red for 60-80%, and maroon for >80%. Some regions are grey, indicating no data. Overlaying this income data are transparent blue shaded paths representing high-frequency bus lines, primarily running vertically through the central-western part of the map and diagonally through the northeastern section. Transparent yellow circles are scattered across the map, indicating metro stops, with notable clusters in the central and southern areas.::>1. Neighborhoods where >40% of households earn <$35K per year; assumption that population in Block Groups is dispersed evenly2. Defined as bus lines with service ~4+ times every hour (~16% of routes); this was estimated by averaging the number of buses on all DC-based routes during 3 sample hours in the day: 8-9 AM, 2-3 PM, and 5-6 PM using WMATA timetables; walking distance of ¼ mile created around bus lines3. Walking distance of ½ mile created around metro stations

<a id='0dbe29c4-414d-40f0-8d80-60c954dd3e64'></a>

Source: US Census; Open Data DC; WMATA District of Columbia Timetables

<a id='d2123f8a-99ba-49f1-ba9e-bde4f4723cce'></a>

Share of residents more than  mile from high-frequency buses and  mile from metro stations in low-income neighborhoods
% by selected characteristics

<a id='e31a3398-2075-43f1-a212-a9250f0fbf12'></a>

<::Race
: bar chart::>
- Latinx: 21
- Asian: 15
- Black: 39
- White: 18


<a id='4ce1b5e8-8ef2-4090-8305-a410eaec53ed'></a>

Occupation<::Health technologists and technicians: 50Protective service occupations: 44Installation maintenance and repair occupations: 39Community and social service occupations: 38Healthcare support occupations: 38Construction and extraction occupations: 36Personal care and service occupations: 36: bar chart::>

<a id='4c35c563-fafe-4fed-b726-87be9e3d2bf3'></a>

McKinsey & Company

<a id='c41b6dd0-f49e-4892-9cfa-9568ebf36e0b'></a>

16

<!-- PAGE BREAK -->

<a id='fa25db0b-4437-44bb-ad67-8cd8114ffe51'></a>

**4b: Southeast DC has a disproportionate share of essential workers**

<a id='2f2d0252-5333-4581-8c60-5ec9fd1345e3'></a>

Neighborhoods where essential workers live¹
% share of workers
in essential industries
<::map: The map displays an area divided into numerous neighborhoods, each colored according to the percentage share of workers in essential industries. A legend indicates the color-coding for these percentages:
<30% (lightest shade of red)
30-40% (light red)
40-50% (medium red)
50-60% (dark red)
>60% (darkest shade of red)
The map shows a general trend where some central and northern areas have lower percentages, while southern and eastern areas show higher concentrations of essential workers.::>
1. Essential industries include: Construction, Educational services, Finance and insurance, Information, Health care and social assistance, Public administration, Transportation and warehousing, Utilities

<a id='afc5eb87-4ad3-40ae-bded-b37a40105672'></a>

Source: US Census; Government of the District of Columbia

<a id='41da8fe5-534e-454c-9bef-8e89e5bbf778'></a>

<::Neighborhoods where Healthcare support workers live¹: choropleth map::> % share of Healthcare support workers. The map displays neighborhoods colored by the percentage of healthcare support workers living there, with a legend indicating the ranges:
<3% (lightest shade)
3-6%
6-9%
9-12%
>12% (darkest shade)

An inset map highlights Southeast DC, where almost all neighborhoods are at least 80% Black (represented by dark red shades on the map).

<a id='88c234a2-e073-434a-ac2c-8cd45946ecfb'></a>

McKinsey & Company

<a id='ce4df030-d490-4b7b-8130-22f295133b32'></a>

17

<!-- PAGE BREAK -->

<a id='8a11b1c6-1097-459d-bcbc-14f4e9cccfb2'></a>

5a: Among peers, Washington DC has the highest share of cyclist fatalities

<a id='1f9addf1-effc-4a0f-a14b-a0c922cf20c2'></a>

<::Fatalities per capita, selected large city peers, 2018. This chart displays two horizontal bar graphs side-by-side, comparing pedestrian and bicyclist fatalities per capita across several large cities in 2018. The city of Washington is highlighted in blue in both charts.

**Pedestrians, per 100K population**
| City          | Fatalities |
| :------------ | :--------- |
| Chicago       | 1.7        |
| San Francisco | 1.6        |
| Washington    | 1.6        |
| Baltimore     | 1.5        |
| New York      | 1.3        |
| Boston        | 1.3        |
| Seattle       | 1.1        |

**Bicyclists, per 1M population**
| City          | Fatalities |
| :------------ | :--------- |
| Washington    | 4.3        |
| San Francisco | 3.4        |
| Seattle       | 2.7        |
| Chicago       | 2.2        |
| New York      | 1.1        |
| Baltimore     | 0          |
| Boston        | 0          |
: bar chart::>

<a id='bfc98c3a-e33e-4f6f-b91f-ac2477982f77'></a>

1. Map from WUSA9 report: "These are DC, Maryland & Virginia's most dangerous roads for cyclists & pedestrians"

<a id='2ab7e496-26bc-4875-b7f6-db2b3a16ed41'></a>

Source: NHTSA Traffic Safety Facts; WUSA9

<a id='f8afec54-d496-4493-8298-4fed0ca79e4b'></a>

Bicycle collisions, 2016-19¹<::A map of Washington D.C. showing bicycle collision density from 2016-2019. A color legend above the map indicates collision frequency, with light pink representing 2 collisions and dark red representing 16 collisions. The map highlights various streets in shades of red, indicating areas with higher collision rates. Prominently marked streets include U Street Northwest, 14th Street Northwest, 15th Street Northwest, 16th Street Northwest, 9th Street Northwest, 6th Street Northwest, 22nd Street Northwest, I Street Northwest, and E Street Northwest. Some of the most dangerous roadways in DC for cyclists are along U Street NW, 14th Street NW, and Dupont Circle.: map::>

<a id='c107bd7a-9b7d-438d-81ff-da543aa4350c'></a>

McKinsey & Company

<a id='e207eb18-1517-47de-8710-85117d1197c5'></a>

18

<!-- PAGE BREAK -->

<a id='e7435337-cde6-4cd0-bef5-8d8bcf08f37a'></a>

5a: While DC has one of the highest shares of bicycle commuters, it has less bike lanes than many peers
US cities by share of bike commuters (%) and bike lanes in number of miles

<a id='299f06ef-c11d-4ad7-804d-04b93fcc5f40'></a>

<::Table: Cities with working population >250K, their share of bicycle commuters, miles of paved public paths, miles of protected bike lanes, miles of unprotected bike lanes, miles of bike infrastructure per square mile, and state passing law. Also includes a note about Washington, DC.|||Cities with working population >250K|Share of bicycle commuters, %¹|Miles of paved public paths²|Miles of protected bike lanes²|Miles of unprotected bike lanes²|Miles of bike infrastructure per square mile²|State passing law³|||Portland|5.2|94|29|208|2.5|"Safe distance"⁴|||Washington|4|60|12⁶|72|2.3|3 feet|||San Francisco|3.8|70|31|153|5.4|3 feet|||Seattle|3.7|48|10|98|1.9|3 feet + change lanes⁴|||Boston|2.5|53|7|102|3.4|"Safe distance"⁵|||Denver|2.4|65|12|330|2.7|3 feet|||Tucson|2.3|132|6|330|2.1|3 feet|||Philadelphia|2.1|Not Reported|24|237|1.9|4 feet|||Chicago|1.5|42|86|99|1.0|3 feet|||Atlanta|1.3|42|9|47|0.7|3 feet|||Note: Washington, DC has the **2nd** highest share of bicycle commuters yet is the **15th** and **27th** city in number of miles of protected and unprotected bike lanes (of 50 large US cities)::>

<a id='22064f78-28cc-4914-ba3b-4aaa3238bc4e'></a>

1. Data from the US Census, Commuting Characteristics by Sex, by Place, 2019 ACS 1-Year Estimate
2. Data from The League of American Bicyclists, "Bicycling and Walking in the United States, 2018 Benchmarking Report"
3. Data from the National Conference of State Legislatures (NCSL) "Safely Passing Bicyclists Chart", 2020
4. Require motorist to completely change lanes when passing a bicycle if there is more than one lane in the same direction
5. A speed less than 35 mph and a "safe distance" means a distance that is sufficient to prevent contact with the person operating the bicycle if the person were to fall into the driver's lane of traffic.
6. Updated from DDOT

<a id='749bb5d9-663f-4612-ad06-2be5f35e5ec6'></a>

Source: US Census; The League of American Bicyclists, "Bicycling and Walking in the United States, 2018 Benchmarking Report"; National Conference of State Legislatures (NCSL)

<a id='097cca02-231e-43cb-873b-6694f9243efd'></a>

McKinsey & Company

<a id='1d8e0a6b-f82b-461b-b63c-17788c3f32d4'></a>

19

<!-- PAGE BREAK -->

<a id='090d7aa8-0e49-40d7-a339-288f73380bb7'></a>

5b: Walking and biking expected to increase 5% in the US post- COVID-19, and micromobility set to rise as well

<a id='2be8ab54-1df1-443b-bf43-bac1e9887c6c'></a>

Results of wave 1 (May 9-18), wave 2 (May 27-29), wave 3 (June 16-18), wave 4 (July 15-17), and wave 5 (Sep 2-4)

<a id='39072665-88a5-48d6-9668-e97d8f6a0775'></a>

Change of transportation modes when returning to "next normal" vs. before COVID-19¹,²
Delta of responses for return to "next normal" vs. before COVID-19 outbreak, in percent points

<a id='805bb015-4600-4f3b-9834-414c1d45c370'></a>

<::Table: Bar chart showing values for different transport modes across various regions/countries.

| | Private car | Public transport | Walking or biking with private bike | Shared micromobility (e.g., e-scooter, e-bike) | Car sharing (e.g., ShareNow) | Ride hailing (e.g., Uber, Lyft, taxis) |
|---|---|---|---|---|---|---|
| Global³ | 0.5 | 0.2 | 5.2 | 1.6 | 1.4 | 1.1 |
| <img src="image_placeholder_USA_flag" alt="USA flag"> | 0.9 | -0.7 | 5.0 | 0.6 | 0.2 | 0.1 |
| <img src="image_placeholder_UK_flag" alt="UK flag"> | 0.5 | -2.7 | 8.4 | 0.9 | 0.6 | 0 |
| <img src="image_placeholder_Germany_flag" alt="Germany flag"> | -0.1 | 1.3 | 5.5 | 1.4 | 1.0 | 0.8 |
| <img src="image_placeholder_Italy_flag" alt="Italy flag"> | 0.9 | 0.3 | 6.1 | 4.1 | 2.8 | 2.9 |
| <img src="image_placeholder_France_flag" alt="France flag"> | 0.3 | 1.1 | 5.9 | 1.2 | 1.2 | 0.9 |
| <img src="image_placeholder_China_flag" alt="China flag"> | 0.7 | 2.3 | 2.1 | 4.1 | 4.0 | 3.8 |
| <img src="image_placeholder_Japan_flag" alt="Japan flag"> | 0.2 | -0.2 | 2.7 | -0.6 | -0.1 | -0.2 |
::>

<a id='d12c548d-b4ac-4173-a829-898d08c03008'></a>

1 Q: Before/today/when you return to "next normal", how often did/do you/do you expect to use the following modes of transportation?
2. Mode usage once or more than once per week
3. US, UK, Germany, Italy, France, China, Japan

<a id='476f49d2-daff-42ef-953c-246dfd93c529'></a>

Source: McKinsey Center for Future Mobility

<a id='8154a905-98bb-40aa-a394-b75e4217687d'></a>

McKinsey & Company

<a id='8801c2ff-4212-4487-a597-ace26771f5b6'></a>

20

<!-- PAGE BREAK -->

<a id='ca29bc42-3848-4f26-8a68-e89d57bbc8b7'></a>

Contents

<a id='34e12cc0-fc96-46c6-93b4-e6943d69aecb'></a>

Baseline Conditions

<a id='87a8cd41-b983-492e-9eeb-64cb92396037'></a>

Challenges and trends

<a id='f35622d5-2ebe-4168-8401-68818497a649'></a>

Opportunities and best practices

<a id='904af82d-3b62-4b7a-827a-0ab538177c9e'></a>

Appendix

<a id='7c5250d0-16c2-4b46-8358-48777c05bb58'></a>

McKinsey & Company

<a id='2fb63bca-04e8-4d69-9ca1-76b45e5e6d4f'></a>

21

<a id='a74584d1-1d1f-4ccd-b2cd-1c0409df69f3'></a>

Last Modified 1/13/2020 6:20 PM Eastern Standard Time

<a id='2d77bcdf-fe60-4f56-9d65-6124308af9fd'></a>

Printed

<!-- PAGE BREAK -->

<a id='a73426fa-f07c-4998-8f41-cda0fbcc8dcb'></a>

Preliminary, proprietary, pre-decisional Non-exhaustive

<a id='0b71c1c6-2f99-46d5-ac36-877cf233b201'></a>

Mobility in DC: opportunities to enhance transportation and economic outcomes across DC

<a id='da034f71-4dc7-4151-8727-297331e0ec58'></a>

Deep dive in Appendix

<a id='5d8657c8-29e7-4b30-beb5-fe9ac302a070'></a>

Challenge Opportunities Details Best practices
1
<::Icon: A dollar sign within a circle.
: figure::> Reaffirm commitment to transit solutions and
robust mix of mobility options A Increase **integration** and **agility** of existing networks for long-term
sustainability and financial viability
B View long-term transit health as integrated with **land use solutions** that
increase density, affordability, and access to transit <::Logos:
- BVG Jelbi logo
- minneapolis | 2040 logo
: figure::>
2
<::Icon: A road with dashed lines in the middle, represented by two parallel lines converging upwards.
: figure::> Increase **supply of mobility solutions** in connection
with **managing congestion and demand** through
pricing C Adopt mobility solutions based on **dynamic pricing**
D Invest in streetscape to support **walking, cycling-, and micro-mobility**
E Develop **employer-back** transit solutions <::Logos:
- MINISTRY OF TRANSPORT CONNECTING SINGAPORE logo
- PARIS logo
- Seattle Office of Labor Standards logo
: figure::>
3
<::Icon: Three stacked boxes or buildings.
: figure::> Adopt new **regulations, uses,** and **pricing** scheme F Dynamically **price** on-street parking to reduce congestion and raise
revenues
G Facilitate **technological** solutions to improve **delivery management** <::Logos:
- LA Express Park logo
- STARSHIP logo
: figure::>
4
<::Icon: Two stylized human figures, one larger and one smaller, representing a family or community.
: figure::> Close **equity gaps** through **new mobility options**
(e.g., microtransit) and target traditional fixed-route
**high-frequency routes** targeting transit “deserts” H Provide **subsidies** for low-income residents for transit usage
I Leverage **microtransit** or **ride-sharing partnerships** for new routes
J Review and redesign traditional **fixed-route high-frequency** routes
targeting **underserved communities** <::Logos:
- orca LIFT logo
- VIA logo
- GO BOSTON 2030 logo
: figure::>
5
<::Icon: A bicycle.
: figure::> Adopt comprehensive **Vision Zero** goals to enhance
safety outcomes K Fastrack **Vision Zero** initiatives (e.g., District-wide reduction of speed
limits, streetscape redesigns) <::Logos:
- Stockholms stad logo
: figure::> 

<a id='5b4ada9e-5784-4a5a-b930-6ac36cf6fe29'></a>

McKinsey & Company

<a id='80b18023-5e33-43a7-b591-d9b690212959'></a>

22

<!-- PAGE BREAK -->

<a id='1f56701f-bf39-4734-b26f-433e75186f42'></a>

<::logo: Jelbi
BVG Jelbi
The logo features a yellow heart with "BVG" inside, next to the word "Jelbi" in black sans-serif font.::>

<a id='9eb6165d-97f3-4395-96fb-c6533af74b62'></a>

1a: Increase integration and agility of existing networks for long-term sustainability and financial viability
---


<a id='71a8dc08-786e-47ee-ab42-5f1cc2cc8125'></a>

Description

* Develop multimodal system that integrates public transit, rideshare, micromobility
* Streamline multimodal transit usage through one-app booking and payments (e.g. Denver residents can use Uber's app to purchase tickets for the local bus and train transit system, RTD)
* Call on regional transit providers (WMATA, MARC, VRE, Circulator) to improve regional integration (e.g., coordinated schedules, increased Union Station capacity and frequency, fare integration, free transfers) and expand nights / weekend service for key residential and employment zones

<a id='65daf9ec-82e7-440f-8cb8-a76c667aac1e'></a>

<::logo: RTD and Uber
RTD
Uber
Two logos are displayed, one with white text "RTD" on a red background and another with white text "Uber" on a black background, set against a blurred cityscape at night::>

<a id='f9435f10-9615-4454-804a-4d9a7db0e42a'></a>

Case example

Berlin

*   In 2019, Berlin introduced a Mobility as a Service (MaaS) app called Jelbi, in partnership with mobility platform Trafi
*   Goal of Berlin public transport authority BVG's smart mobility strategy to connect every shared mobility offer in the German capital into a single marketplace for its residents to provide an attractive alternative to private cars
*   Jelbi integrates all public and shared mobility options, including bike sharing, taxis, carpooling, and public transportation
*   Allows Berliners to register one time for all existing and to-be-integrated mobility services, receive messages from transit (e.g. regarding closures or safety), plan intermodal trips (lowest time, cost), receive real time public transport information, and buy any type of ticket (no need to switch between apps)
*   Employers can provide employee travel allowances on the app

Impact:

*   In the first year of Jelbi:
    *   ~5% of Berliners have used Jelbi
    *   15,500+ vehicles available
    *   51% public transport
    *   49% share mobility

<::Mobile phone screen showing the Jelbi app interface.

Top bar with back arrow and 'Where to?' title.

Input fields for 'Potsdamer Platz' and 'Alexander Platz' with an up/down arrow icon between them.

'Leave now?' with a clock icon.

Below this, a list of mobility options with travel times and prices:

*   Icon with 'U U2' and a star: 18 min, €2.90 (09:41-10:01)
*   Icon with a star: 21 min, €4.99 (09:41-10:02)
*   Icon with 'M 1' and a star: 23 min, €1.00 (09:41-10:03)
*   Icon with a star: 23 min, €4.80 (09:41-10:04)
*   Icon with 'M 1' and a star: 19 min, €2.30 (09:41-10:00)
*   Icon with 'VW Polo' and a star: 22 min, €4.12 (09:41-10:03)
: figure::>

<a id='9cc347ac-cd5a-44fc-b48e-cb7ec347cecf'></a>

Source: The Verge; Unsense; BVG Jelbi website

<a id='540d1544-13da-4f75-8145-2a4962e079f2'></a>

McKinsey & Company
McKinsey & Company

<a id='a44632a5-c39a-4742-92bd-eb0bd2c9919d'></a>

23

<!-- PAGE BREAK -->

<a id='68c1b12f-d788-46e1-83e6-7cc290555675'></a>

1b: View long-term transit health as integrated with land use solutions that increase density, affordability, and access to transit

<a id='8a336a64-f479-459f-a4f1-e2e2431a6c90'></a>

minneapolis | 2040

<a id='7edd91d8-cb10-495f-b11b-b76bc9858b22'></a>

# Description
*   Cities and states such as Minneapolis, Austin, Seattle, Montgomery County MD, Oregon, and more have recently begun implementing changes to land use policy to encourage housing affordability
*   20% of the District's surface area is occupied by single-family units, which increases to 48% of all land not occupied by the federal government (or National Park Service)
*   The District could consider targeted land-use measures near transit to incentivize more housing density and affordability

<a id='64293d45-764d-4a98-85c9-c61a1100032d'></a>

## Case example

### Minneapolis

- In October 2019, Minneapolis became the first city in the U.S. to eliminate single-family zoning

<::Minneapolis skyline at dusk, showing city buildings, a river, and bridges with illuminated lights
: figure::>

- As part of the Minneapolis 2040 comprehensive plan for the city, a package of further reforms includes:
  - Encouraging further density near transit stops
  - Eliminating off-street minimum parking requirements
  - Requiring new developments set aside units for low- and moderate-income households ("inclusionary zoning")
  - Increasing funding for affordable housing
- Before the 2040 Plan, Minneapolis made incremental steps to increasing housing affordability, such as in 2014 expanding the availability of "Accessory Dwelling Units" (ADUs)

<::A color-coded map of Minneapolis showing primary zoning districts, with a legend on the right side indicating different zoning types like R1, R1A, R2, R2B, OR1, OR2, OR3, C1, C2, C3A, C3, C4, C5, C6, I1, I2, I3, B1, B2, B3, BAC-1, BAC-2, BAC-3, S-1, U1, U2, N, O, and W. The map displays a dense urban core with various colors, surrounded by less dense areas.
: figure::>

### Impact:

- Region-wide goal of 37,900 newly constructed affordable housing units between 2021 and 2030
- ~$10M per year from the City budget to an Affordable Housing Trust Fund providing competitive low/no interest deferred loans
- ~$50M per year in Low Income Housing Tax Credits

<a id='44ad6f21-28f3-45d9-847b-2c0ce7e46be8'></a>

Source: Minneapolis 2040; The Century Foundation; D.C. Policy Center

<a id='10fd7d33-89a1-4ce4-aa80-5f59d322708d'></a>

McKinsey & Company
McKinsey & Company

<a id='ba06ae95-b4ab-4eeb-a7d1-0c6977a56b1d'></a>

24

<!-- PAGE BREAK -->

<a id='a7e7a921-c05b-46c2-82d3-c04a33a2de02'></a>

**2c: Adopt mobility solutions based on dynamic pricing (e.g., congestion pricing)**---

<a id='aa6bb7e3-0db3-427a-bbbf-585a37f11cda'></a>

<::logo: Ministry of Transport
MINISTRY OF TRANSPORT
CONNECTING SINGAPORE
This logo features an abstract, intertwined loop design in shades of blue and green.::>

<a id='587816f7-9a44-46c8-bb70-d699e922c097'></a>

## Description
*   Charging for use of roads in an effort to reduce congestion and carbon emissions, increase safety, and generate revenue that can be reinvested into transit infrastructure

## Congestion pricing:
*   System can be cordon fee (e.g., charge to pass a cordon line around city center), area-wide, or corridor/facility specific
*   May include a variable pricing scheme to respond to congestion (using algorithms to determine optimal price and time and transmitting this information to road screens or apps)
*   Requires similar infrastructure as current road tolling (cameras, sensors, and electronic transponder devices for vehicles)

## Revenue generation:
*   Potential to endow the city with a sustainable infrastructure bank
*   Net annual revenue is USD $182M in London, $155M in Stockholm, and $100M in Singapore

<a id='f93d8e81-d985-45aa-975c-5dc85c512e9a'></a>

Case example

Singapore Electronic Road Pricing (ERP)

*   Singapore launched ERP in 1998 to reduce congestion and improve journey time reliability for car users
*   It is an electronic toll collection system with open road tolling, now (as of 2020) using satellite technology instead of cameras and gantries to charge vehicles

<::An image showing a road gantry with a '4.5m' height limit sign and 'ERP' written on it.
: figure::>

*   It uses variable pricing designed to respond to congestion in real-time (charges depend on type of vehicle, congestion, time, and distance travelled)
*   In conjunction with ERP, Singapore doubled parking fees within the restriction zone, established park-and-ride facilities outside the zone, increased bus frequency, and established HOV lanes
*   Hours are 7 AM-8 PM Monday to Saturday
*   Initial investment: $110M USD
*   Annual operating cost: $18.5M USD
*   Annual net revenue: $100M USD

Impact:

*   Reduced traffic in the inner city by 24% and increased average speeds from 18-22 to 24-28 MPH
*   Public transit improvements (expanded bus, rail, biking and pedestrian network), and bus and train ridership has increased by 15%
*   Levels of CO2 and other greenhouse gas emissions have been reduced by 10-15%

<a id='4f8600a4-8c12-4d97-9fd6-666525733dc5'></a>

Source: The Straits Times; Tri-State Transportation Campaign, "ROAD PRICING IN LONDON, STOCKHOLM AND SINGAPORE: A WAY FORWARD FOR NEW YORK CITY"

<a id='7d585e93-5eb2-4d2b-9ffa-826eb1f1495d'></a>

McKinsey & Company McKinsey & Company

<a id='74e98e7f-70b4-4f10-aadb-e953c79c96d7'></a>

25

<!-- PAGE BREAK -->

<a id='edd147bf-5dda-4db2-a522-86e3df057d76'></a>

2d: Invest in streetscape to support walking, cycling-, and micro-mobility

<a id='b77e036b-3b1d-4fc3-b6d8-debee54ab1e2'></a>

<::logo: PARIS
PARIS
A stylized dark blue sailboat icon is positioned to the left of the brand name "PARIS", which is also in dark blue, sans-serif font::>

<a id='a0679025-2a9d-44c9-b31e-4cbd6d821efa'></a>

## Description
*   Increase number and mileage of dedicated bike lanes, especially in neighborhoods and around key amenities (e.g. grocery stores)
*   Create additional mixed-use transit-and-micromobility corridors along key arteries, e.g., bus rapid transit (BRT) lanes and non-traditional vehicle "mobility corridors" for bikes, ride-sharing pools, and scooters
*   Allow for year-round, permanent parklet usage by restaurants (e.g., New York)
*   Improve walkability and neighborhood amenities through more car-free zones, plazas, and more Great Streets east of the river
*   Expand dockless bicycle and scooter parking and charging infrastructure

<a id='a801330d-bf78-4bfb-b0d9-bc3ecbc7c52e'></a>

Case example---Paris has been undergoing a transformation to make the city less congested and more walking- and cycling-friendly. The plan to make Paris a "15-minute city," where a resident's needs are a short walk away, includes:- Pedestrianization of the highways along the Seine's riverbanks- Car-free first Sunday of each month in 10 congested areas of the city- Expansion of the city's bike-share program Vélib'- €350m (£300m) plan to create "a bike lane in every street" by 2024- Plan to do away with 60,000 parking spaces for private cars- Free public transit for kids under eleven and senior citizens- Banned cars near schools when kids are arriving and leaving to make it safe for children to walk and bike- In response to COVID-19, temporary pedestrianized streets and 30 additional miles of dedicated bike lanes<::Diagram titled "LE PARIS DU 1/4 HEURE" (Paris in 1/4 hour) with a "PARIS EN COMMUN" logo. The diagram illustrates a circular concept centered around "CHEZ MOI" (My Home). Various activities are depicted around the circle, accessible within 15 minutes by walking or cycling. The activities and their labels are:- BIEN MANGER (Eat Well): People at market stalls.- APPRENDRE (Learn): A building (school/library) and people reading.- TRAVAILLER (Work): People in an office setting.- PARTAGER ET REEMPLOYER (Share and Reuse): People exchanging items.- S'APPROVISIONNER (Stock Up): A shop with people shopping.- S'AÉRER (Get Fresh Air): A park with people relaxing.- SE CULTIVER, S'ENGAGER (Cultivate Oneself, Get Involved): A cultural building with people engaging.- SE SOIGNER (Take Care of Oneself): A clinic/doctor's office with people receiving care.- CIRCULER (Move Around): People cycling on a bike path.- SE DÉPENSER (Expend Energy/Exercise): People exercising in a sports area.Arrows indicate movement between "CHEZ MOI" and the activity zones, labeled "15mn" (15 minutes).Below the diagram, there is a photograph of two people riding bicycles, with the Eiffel Tower visible in the background.: diagram and photo::>

<a id='1816fed0-17ac-4a03-948e-ec737ebb77c8'></a>

**Impact:**
* Vehicular traffic has decreased by 20 percent in the last five years
* The number of cyclists has grown 54% in 2019
* City has reached 620 total miles of cycle paths in 2019, nearing its goal of 870 miles

<a id='cc8905f3-73f5-461a-a439-34482e89af63'></a>

<::A photo shows people on a bridge in Paris with the Eiffel Tower in the background. In the foreground, a person on a red scooter, wearing a white helmet and face mask, is blurred due to motion. Behind them, another person, also wearing a mask, is partially visible. To the right, a woman in a white shirt and yellow pants, wearing a face mask, rides a green bicycle. The bridge railing is ornate and green with golden accents. The Eiffel Tower is clearly visible in the distance under a partly cloudy sky.: figure::>

<a id='73c193d9-75ce-4ba9-bb1f-3f445b7a8f51'></a>

Source: World Economic Forum; BBC; Ubique; Fast Company

<a id='a32f459b-8cb2-4be5-9f5f-3731db9d1f5a'></a>

McKinsey & Company
McKinsey & Company

<a id='1998e8d3-9343-46eb-a26b-08d1f00cf716'></a>

26

<!-- PAGE BREAK -->

<a id='fe960d98-25ff-4466-ade4-2f7d7c6d8bbf'></a>

3f: Dynamically price on-street parking to reduce congestion and raise revenues

<a id='7ee078ea-b1bd-4886-9a98-341eff6dc2d0'></a>

<::logo: LA Express Park
LA Express Park™
save time, park smarter.™
This logo features a stylized blue and white 'p' within a circular element, accompanied by the brand name and a tagline.::>

<a id='ae232565-5ad6-4c29-a582-4a01c6675c49'></a>

## Description

*What is it?*

A system of sensors that detect open parking spaces and make them visible to citizens looking for parking spaces via mobile applications or vehicle navigation systems, reducing time spent looking for parking; dynamic pricing helps shape demand to meet occupancy goals. Systems may also use analytics to predict future parking availability

<a id='6cb9659c-81a9-4e6f-9489-28e7981f9268'></a>

_What is the city's role?_
Buy and implement (or partner with third party to implement) smart parking sensors, meters, and applications; encourage privately owned garages and lots to implement parking guidance systems through subsidies or regulation; offer parking availability and pricing data for third parties to leverage

<a id='a27f328e-7bdb-4d2a-a4c8-ca569f4c8506'></a>

## Case example
**Los Angeles:** The Los Angeles smart parking program leveraged multiple sensors to provide real-time parking spaces through a mobile app. The smart parking application started as a pilot around 4.5 square miles on the downtown area in 2012

<a id='449d57b6-5f83-43f8-a47e-55ca76fd138c'></a>

## Features and approach:
The application uses parking sensors, dynamic pricing that reacts to demand, a parking guidance system and a mobile app that supplies real-time information about parking availability

<a id='37b6c603-bd46-48d2-b7bd-d78659f5ca73'></a>

The app provides support for mobile payments, current rate, payment methods, voice guidance to
parking spots and spaces available with the option to filter parking searches by permit type

<a id='361de232-9630-4586-9ee2-86a63c1fe834'></a>

Reservations can be made on a daily or monthly basis

<a id='f02b8c8a-9734-40fa-a318-a6e76201c843'></a>

The information helps LA DOT to set enforcement priorities to ensure compliance. All transactions are recorded and then used to optimize operations

AT&T LTE 9:56 AM 75%

<a id='d6108a87-4d24-4968-87db-0b3ca364eff4'></a>

**Operations and cost:**
LA Express Park was founded by grants from the US DOT and the city (~$18M in total). The LA DOT manages the program. The smart parking application uses the parking sensors from Street Line company, and Xerox has helped develop a highly integrated advanced pricing engine

<a id='93eae4d9-9508-4147-a6d3-98502443acc8'></a>

••••• AT&T LTE 9:56 AM 75%
Q Current Map Area
<::map showing an urban area with street names and various parking indicators. A blue pop-up window displays "Navigate" and "1000 S WESTWOOD..." with an information icon. Several street segments are marked with green or red lines, and numerous pins with a "$2" label are scattered across the map, indicating parking spots. Businesses like "Chipotle Mexican Grill", "Fatburger", and "Native Foods Cafe" are visible. Below the map, a blue bar shows "1 Hour. Starting Now". Below that, a horizontal slider with options "DAILY", "RESERVE", "MONTHLY", and "STREET" is displayed, with "STREET" selected and highlighted with a car icon.
: map::>
1 Hour. Starting Now
DAILY RESERVE MONTHLY STREET 

<a id='dfb6d96a-a983-4350-91a1-da34bc6dbc2c'></a>

<::A silver and black parking meter is shown, featuring a large 'P' logo in a blue circle on the side. Various payment card logos (Visa, Mastercard, Discover, American Express) are visible near a card slot. The meter has a digital display and buttons on the top panel, and a slot for tickets or receipts. Text on the meter includes "www.passportparking.com" and "Apple Pay, Google Pay, and more!" It is positioned on a sidewalk next to a street, with a car and a wall in the background.
: photo::>

<a id='4373900d-7c1a-4476-8005-c86427630216'></a>

<::logo: LADOT, Park Smarter
PAY BY APP
LADOT
PARK SMARTER
A rectangular logo with an orange background on the left and a teal background on the right, featuring a QR code, a smartphone icon, and text in white.::>

<a id='3a9fe687-5056-4de1-9b7b-f2497096fdf5'></a>

Source: Laexpresspark.org; McKinsey Global Institute team analysis

<a id='0075cef4-6cf0-427a-9019-6f463a741d4e'></a>

McKinsey & Company McKinsey & Company

<a id='68b32a19-31fc-419b-9bb0-800271c1c94f'></a>

27

<!-- PAGE BREAK -->

<a id='84944303-99df-40ca-89bd-47436a6a8264'></a>

4h: Provide subsidies for low-income residents for transit

<a id='7487d994-4df2-4e89-a388-15bcba801ed1'></a>

<::logo: Seattle
Seattle
The logo features a blue circular icon with a stylized profile of a face facing left, accompanied by the bold black text "Seattle".::>

<a id='2d137a5b-dc25-4553-a6bf-fd7ff3fedca9'></a>

**usage**

<a id='62930473-e6a7-42f9-b25a-b58f1535ab70'></a>

# Description
The District already provides some transit subsidies through a number of sources:

The "Kids Ride Free" program allows students to ride MetroBus, Metrorail, and the DC Circulator for free within the District

SmartBenefits allows employers to offer tax-free commuting to employees – with no fee to employees

The Transportation Benefits Equity Amendment requires companies in the District that offer employees free or subsidized parking to also offer subsidized

<a id='6622c776-226a-4cfb-8797-9b21999a86fb'></a>

The District could consider addressing equity concerns by expanding existing subsidies and providing additional subsidies for low-income residents¹

<a id='2ae106c3-d5f8-4fdf-9036-9652d8c0ff55'></a>

Revenue sources for this program could come from other initiatives, such as dynamic pricing on certain roads or a cordon fee

<a id='4718a8e5-45a9-4bd9-a3ef-3692ba623626'></a>

## Case example
Seattle: "King County Metro has long offered discounted fares to make transit service more affordable and accessible. In addition to existing programs for youth, seniors, and disabled riders, Metro recently expanded the Human Services Ticket Program and introduced the ORCA LIFT low-income fare in 2015."

<a id='fe66808d-ad69-4de7-ac7a-91aa6689e890'></a>

According to King Country Metro, "The ORCA LIFT program offers a reduced transit fare for people with incomes at or below 200% of the federal poverty level. Enrollment is available at locations across King County and partner agencies like King County Public Health verify income of participants through existing benefits programs like Apple Health, Social Security and Employment Security.

<a id='8814c904-398d-40df-9330-7ada3928096c'></a>

Metro reached out to the public in spring 2017 to develop recommendations for simplifying fares. We created a stakeholder advisory group, briefed and interviewed interested groups, and gathered two rounds of public feedback. This led the Executive to propose a simplified fare structure of a flat fare of $2.75 at all times, regardless of time or distance, which was adopted by King County Council and took effect in summer 2017."

<a id='4cc1521d-6391-4f12-869b-614dd38f244d'></a>

<::An image showing two distinct parts. On the left, a blue ORCA card is displayed with the text "orca one regional card for all" and numbers "12345678" and "321". The card has colorful wavy lines across it. From the card, an arrow diagram extends to the right, listing various transportation methods it can be used for: STREET CAR (with a streetcar icon), BUS (with a bus icon), LINK LIGHT RAIL (with a light rail icon), SOUNDER TRAIN (with a train icon), WATER TAXI (with a water taxi icon), STATE FERRY (with a ferry icon), and FAST FERRY (with a fast ferry icon). On the right, a photograph shows a person, partially visible and in motion, wearing a red and black jacket, tapping or swiping a card on a fare reader device inside what appears to be a bus or similar vehicle. The driver's seat and dashboard controls are visible in the foreground.: figure::>

<a id='b783d002-f4ad-4f65-80c8-751b94f45e29'></a>

<::logo: ORCA LIFT
orca LIFT
Reduced Fare.
Increased Possibilities.
A blue circular logo with a white stylized orca whale above the word "orca" and a bus image in the background.::>

<a id='e28e7655-2d70-4c5d-8ed7-7d6c55fbc6e1'></a>

1. Proposals for such a program do exist, such as Councilmember Allen's proposal to provide a $100 monthly transit subsidy to every DC resident

<a id='0ed70a58-bb3f-43fd-8942-915b0198479e'></a>

Source: DDOT; WMATA; DC Council; King County

<a id='b4966574-a7b6-4231-b11e-eb1faa338f25'></a>

McKinsey & Company
McKinsey & Company

<a id='577d20ac-23fd-41e4-9dd3-d9a9e90fabc6'></a>

28

<a id='72e17a39-3a8a-45e9-b7a3-8113a0604f3e'></a>

--- --- --- --- --- ---
transit fare

<!-- PAGE BREAK -->

<a id='62cf0a2e-3df7-4595-a533-83e014a15f57'></a>

<::logo: Stockholms stad
Stockholms stad
The logo features a black shield with a stylized head wearing a crown, next to the words "Stockholms stad" in black text.::>

<a id='f67372d2-8859-428a-8d35-48b83885ee30'></a>

**5k: Fastrack Vision Zero initiatives**

<a id='e8e4951a-95f6-4123-b12a-e7093c26aa15'></a>

## Description

* Fastrack DC Vision Zero safety efforts by redesigning streets and sidewalks to prioritize and protect pedestrians and cyclists
* Develop connected network of cycling and pedestrian infrastructure, and prioritize junctions with high numbers of accidents (through visibility, predictability and speed reduction)
* Entice more residents to cycle, which is proven to increase safety (e.g., survey bike commuters and DC residents to determine what would encourage them to cycle more, such as additional protected bike lanes, more bike parking infrastructure, slower driving speeds, etc.)
* Strengthen enforcement for 20 mph speed limit on DC roads (e.g., traffic enforcement cameras as in NYC)
* Reduce the volume of motorized traffic, especially during peak times (e.g., through use of congestion charge)

<a id='1a413ab0-d104-463f-b1b0-9f3fd827ea07'></a>

Case example

**Stockholm Vision Zero Project**
*   Systems approach to safety: core responsibility for accidents on the overall system design (rather than only faulting drivers)
*   Transport infrastructure redesign to eliminate fatalities and serious injuries
*   The project includes multiple sub-initiatives such as:
    *   Rebuilt intersections: built tighter roundabout focused in slowing speeds which reduced death rate by 90%
    *   Road design: safer cross-walks: Bumps, road narrowing, chicanes, etc. mainly in urban areas

<::A group of people cycling and walking on a pedestrian crossing in an urban area with buildings in the background.
: figure::>

*   Vision Zero 2.0: integrate health benefits of more people walking and cycling

**Impact:**
*   56% of Stockholm residents commute via public transport, cycling, or walking

<::A tree-lined avenue with people walking, suggesting a park or green space.
: figure::>

*   Sweden has one of the lowest annual rates of road deaths in the world (3 out of 100,000 as compared to 12.3 in the United States)
*   Fatalities involving pedestrians have fallen almost 50% in the last five years

<a id='49fcacfb-f28a-48e1-874d-417b03ed6c28'></a>

Source: Stockholm Civitas Database; Center for Active Design; DDOT; International Transport Forum

<a id='ca5c3cc3-887d-4703-8f41-c210f936cf76'></a>

McKinsey & Company McKinsey & Company

<a id='183f2559-f158-42ed-b48b-cb16381bf221'></a>

29

<!-- PAGE BREAK -->

<a id='f5ad3823-1da4-415d-8f78-96b15863e0e5'></a>

Contents

<a id='cafb1b36-5fa2-493b-889b-8343223ab0d8'></a>

Baseline Conditions

<a id='1ac3ad07-a8e2-4f48-bf3b-401bcfd7b4ae'></a>

Challenges and trends

<a id='452b4ad2-e517-4b6e-8a02-db936cb8c192'></a>

Opportunities and best practices

<a id='0077dde3-22ce-4239-aa54-b93a5cc93582'></a>

Appendix

<a id='0bce8a98-3c04-4c93-a3e3-9ffca2d5131a'></a>

McKinsey & Company

<a id='d1b456b6-4979-4647-9844-c3eed187bf5a'></a>

30

<a id='46478efe-b361-489b-90d4-8840492c777b'></a>

Last Modified: 9/13/2020 6:20 PM Eastern Standard Time

<a id='cbfdb252-5716-4089-a060-db2f0770e73b'></a>

Printed

<!-- PAGE BREAK -->

<a id='a0b74a3f-f79e-4106-bd42-f36aba8e4771'></a>

Transportation and warehousing is a relatively small sector with low specialization
GDP, growth, and specialization by major industry

<a id='4da0dd86-9f22-497e-a025-649e6ae2c0e0'></a>

option Focus of this document: [x]option Analyses by other firms: [ ]<::table::>| Sector                                                      | Included in sector analysis | Size             | Growth                         | Specialization |
|:----------------------------------------------------------|:----------------------------|:-----------------|:-------------------------------|:---------------|
|                                                           |                             | GDP, Mil., 2019¹ | CAGR, 2014-19, % | CAGR, 2019-24, %² | GDP LQ³        |
| Government and government enterprises                       | option : [x]                | 40,721           | 1%                             | 2%             | 2.8            |
| Professional, scientific, and technical services            | option : [x]                | 26,407           | 2%                             | 3%             | 2.7            |
| Real estate and rental and leasing                          | option : [x]                | 9,623            | -1%                            | 2%             | 0.6            |
| Information                                               |                             | 9,246            | 9%                             | 3%             | 1.1            |
| Other services (except government and government enterprises)⁴ |                             | 8,479            | 2%                             | 0%             | 3.5            |
| Health care and social assistance                           | option : [x]                | 5,916            | 2%                             | 0%             | 0.6            |
| Finance and insurance                                     |                             | 4,520            | 2%                             | 1%             | 0.6            |
| Accommodation and food services                             | option : [x]                | 4,193            | 2%                             | 0%             | 1.2            |
| Educational services                                        | option : [x]                | 4,086            | 0%                             | 3%             | 2.8            |
| Admin. and support and waste management and remediation services |                             | 3,140            | 0%                             | 0%             | 0.8            |
| Retail trade                                                | option : [x]                | 1,645            | 4%                             | 4%             | 0.2            |
| Wholesale trade                                           |                             | 1,254            | 2%                             | 4%             | 0.2            |
| Construction                                              |                             | 1,248            | -1%                            | 1%             | 0.3            |
| Utilities                                                 |                             | 1,222            | 3%                             | 1%             | 0.7            |
| Arts, entertainment, and recreation                         | option : [x]                | 1,164            | 4%                             | 3%             | 0.9            |
| Management of companies and enterprises                   |                             | 930              | 7%                             | 7%             | 0.3            |
| Transportation and warehousing                              | option : [x]                | 341              | -2%                            | 3%             | 0.1            |
| Manufacturing                                             |                             | 273              | 6%                             | 2%             | 0.0            |
| Total                                                     |                             | 123,929          | 2%                             | 2%             | 1.0            |<::/table::>

<a id='1ab94129-5d05-4632-8681-e5535039e512'></a>

1 Full-time and part-time; Real GDP chained to 2012 USD; Removed Mining, quarrying, and oil and gas extraction sector due to lack of data; Sector GDP may not add up 100% due to data suppression and real GDP calculations;
2 Forecasts from Moody's Analytics; 3 Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole; 4 Other services is an especially large sector in DC as it includes NGOs and other institutions

<a id='ed9d2223-cce0-44e1-a1d1-baa7e9017d35'></a>

Source: Bureau of Economic Analysis (BEA), SAGDP9N Real GDP by state by NAICS industry; Moody's Analytics

<a id='ee37ec21-3a17-4376-87b6-0d8b14a0403e'></a>

McKinsey & Company

<a id='1c074be1-8edb-442b-9773-f8f303d5aae9'></a>

31

<!-- PAGE BREAK -->

<a id='996e6d7b-2bb6-4826-a6e5-7e5af1b272c3'></a>

Transit and ground passenger transportation is the largest contributor to output in DC

GDP, growth, and specialization by subsector

<a id='87d936e1-ba5a-412f-8f2b-f24e6784cf19'></a>

<::
| Subsector | Size GDP, Mil., 2019^1 | Growth CAGR, 2014-19, % | Growth CAGR, 2019-24, %^2 | Specialization GDP LQ^3 |
|---|---|---|---|---|
| Transit and ground passenger transportation^4 | 165 | 4% | 1% | 0.5 |
| Other transportation and support activities^5 | 103 | 3% | 7% | 0.2 |
| Rail transportation | 36 | -18% | 1% | 0.1 |
| Air transportation | 20 | -14% | 3% | 0.0 |
| Truck transportation | 10 | -4% | 5% | 0.0 |
| Water transportation | 3 | 1% | 5% | 0.0 |
| Warehousing and storage | 3 | 0% | 11% | 0.0 |
| Pipeline transportation | 3 | -23% | 8% | 0.0 |
| Transportation and warehousing (total) | 341 | -2% | 3% | 0.1 |
: table::>

<a id='0a46a0a9-db73-4d9e-b88a-8a3ba4450a12'></a>

1. Full-time and part-time; Real GDP chained to 2012 USD; Subsector GDP may not add up 100% due to data suppression and real GDP calculations
2. Forecasts from Moody's Analytics
3. Location Quotient (LQ), or specialization, is measured as the ratio of a sector's share of output/employment in a state to that sector's share of output/employment in the U.S. as a whole
4. Includes transit networks such as WMATA and rideshare such as Uber and Lyft, etc.
5. Other Transportation and Support Activities includes scenic and sightseeing transportation, couriers and messengers, and support activities for transportation (BEA does not have separate data for them)

<a id='0d742ff4-7d36-4e24-be33-754bbffe84bd'></a>

Source: Bureau of Economic Analysis (BEA), SAGDP9N Real GDP by state by NAICS industry; Moody's Analytics

<a id='a3664d76-5521-4f66-b2a7-9cfe7d6ad33a'></a>

McKinsey & Company

<a id='2e4546e0-f576-4a67-b27c-ea507da08d61'></a>

32

<!-- PAGE BREAK -->

<a id='6d826ba1-c3de-4d82-b230-7f6d79439f3c'></a>

Current as of August 5, 2020

<a id='983ad1a3-a86c-4440-9549-86eaa0faa367'></a>

1: DC's most vulnerable jobs are concentrated in sectors with the
lowest wages and lowest educational attainment
Number of vulnerable jobs in DC

<a id='99dddf27-e7e1-4eb3-b265-6eaee8a38267'></a>

Preliminary, proprietary, pre-decisional
<::A bubble chart titled "Median earnings in industry, '000" displays various industries. The y-axis ranges from 10 to 100, representing median earnings in thousands. The x-axis ranges from 0 to 65. Each bubble represents an industry, with its size indicating the number of employees in thousands (K) and its vertical position indicating median earnings.

Data points are as follows:
- Professional services: 29K employees, median earnings around 95K (x-pos ~30)
- Government: 11K employees, median earnings around 87K (x-pos ~7)
- Information: 4K employees, median earnings around 80K (x-pos ~20)
- Finance: 5K employees, median earnings around 80K (x-pos ~27)
- Management: 1K employees, median earnings around 80K (x-pos ~32)
- Utilities: 1K employees, median earnings around 78K (x-pos ~30)
- Religious & Civic: 23K employees, median earnings around 75K (x-pos ~37)
- Mining: 0K employees, median earnings around 75K (x-pos ~57)
- Education: 21K employees, median earnings around 70K (x-pos ~37)
- Wholesale: 2K employees, median earnings around 68K (x-pos ~40)
- Construction: 7K employees, median earnings around 67K (x-pos ~47)
- Real Estate: 5K employees, median earnings around 58K (x-pos ~48)
- Healthcare: 12K employees, median earnings around 55K (x-pos ~18)
- Manufacturing: 0K employees, median earnings around 55K (x-pos ~30)
- Repair & maintenance: 0K employees, median earnings around 47K (x-pos ~28)
- Administrative: 17K employees, median earnings around 45K (x-pos ~38)
- Forestry and Logging: 0K employees, median earnings around 40K (x-pos ~28)
- Transportation: 2K employees, median earnings around 50K (x-pos ~57, highlighted in red)
- Retail: 11K employees, median earnings around 35K (x-pos ~55)
: bubble chart::>

<a id='614585f3-0e22-4adf-94e5-a3158683f5bd'></a>

<::bubble chart: Total jobs at risk in DC 52.6K. The chart includes a legend for 'Number of jobs vulnerable' where circle size indicates quantity (e.g., a grey circle represents 10K). Another legend indicates '% of jobs in industry requiring a bachelors degree' by color: black for >40%, dark blue for 20-40%, and light blue for <20%. The chart displays: personal services with a light blue circle representing 6K jobs; Arts, entertainment, & rec with a dark blue circle representing 8K jobs; and Accomm. & food service with a large light blue circle representing 62K jobs.::>

<a id='ff6b27e6-b835-4dc5-857e-bac8aaf90eb1'></a>

<::85 90 95 100
% of jobs in industry vulnerable
: chart::>

<a id='df5f8eca-dab5-4967-9173-bb8d6765505b'></a>

Note: Vulnerable jobs are those predicted to be furloughed, laid-off, or otherwise unproductive (e.g., kept on payroll but not working) during periods of high social distancing

<a id='129f812a-a9e3-4713-b01e-1a0a77aafc52'></a>

Source: MGI Economics analysis based on scenarios generated by McKinsey in partnership with Oxford Economics, input from Moody's Analytics data

<a id='54792fbf-bcd3-4eaa-a6c8-91a47863e9d3'></a>

McKinsey & Company

<a id='22cc243b-d952-482f-b0c7-d0d9365c10ca'></a>

33

<a id='a38c5967-dca9-4da0-b804-eaa98a8e8c6e'></a>

<::70 75 80
: scale::>

<!-- PAGE BREAK -->

<a id='e7f25989-0ace-4f3d-8cf2-a6f649b02a94'></a>

**DC's GDP can be expected to decline by 6.4% in 2020**
Real GDP, indexed to 2019 Q4

<a id='a7712d34-3920-46e7-b841-795e9539c00b'></a>

<u>Preliminary, proprietary, pre-decisional</u> Real GDP Impacts of COVID-19 Crisis Indexed to 2019 Q4 = 100 <::chart::> This line chart shows Real GDP Impacts of COVID-19 Crisis, indexed to 2019 Q4 = 100. The Y-axis ranges from 85 to 110. The X-axis shows time in quarters: 2019Q4, 2020Q4, 2021Q4, 2022Q4, 2023Q4. The chart includes two lines: a light gray line representing "History" and a dark line representing "Pessimistic scenario". The "History" line starts below 100 before 2019Q4, reaches 100 at 2019Q4, and then remains flat at 100. The "Pessimistic scenario" line starts at 100 in 2019Q4, drops sharply to a low point around 91-92 in 2020Q4, then gradually increases, crossing 100 around 2022Q4, and continues to rise to approximately 104-105 by 2023Q4. ::>

<a id='c19b4703-25fa-4baf-a425-54d20e61095f'></a>

The pessimistic scenario (A1) assumes there is a virus resurgence and a muted recovery through 2022 globally
1.Average annual percent change

<a id='75ba1fb6-fa79-4637-bc5d-14f83ee04121'></a>

Source: MGI Economics analysis based on scenarios generated by McKinsey in partnership with Oxford Economics, input from Moody's Analytics data

<a id='0eb90d7e-ef32-4bd6-8872-4267489c3ed5'></a>

Current as of October, 2020

<a id='c6407725-a59a-498f-9abb-7e562fe987ed'></a>

2020 GDP
change2
% Change

-6.4%

GDP return
to pre-crisis
Quarter

2022Q3

<a id='bf831d59-9478-48e5-bd96-08af7eb20c11'></a>

McKinsey & Company

<a id='52c2b6f6-2fdc-40d2-8415-7495c855042d'></a>

34

<!-- PAGE BREAK -->

<a id='208eba7a-1a16-4f1d-97a3-9d6fcba2830e'></a>

Current as of October, 2020

<a id='ade32822-16d5-43c5-a956-ee023279362a'></a>

Vulnerable jobs and businesses are concentrated disproportionately among Hispanic and Black DC residents

<a id='34613a02-f145-403f-b234-b2d85c832443'></a>

Preliminary, proprietary, pre-decisionalShare of vulnerability of workers and businesses, by race/ethnicity¹ (%)
<::Bar chart showing the share of vulnerability of workers and businesses, by race/ethnicity.

Vulnerable jobs:
- Hispanic: 47% share, 0.05M jobs
- Black: 31% share, 0.06M jobs
- Asian: 31% share, 0.02M jobs
- White: 26% share, 0.09M jobs

Revenue in most vulnerable sectors:
- Hispanic: 26% share, $3.2B revenue
- Black: 47% share, $1.3B revenue
- Asian: 37% share, $53.5B revenue
- White: 19% share, $2.8B revenue
: chart::>

<a id='ef958e5d-a4c6-4ed3-9a9e-742b80f484e3'></a>

Source: LaborCUBE, BLS Occupational Employment Statistics, Moody's Analytics, McKinsey Global Institute analysis
Mc
1. Vulnerability of minority-owned businesses is measured by share of revenue in five sectors with most vulnerable jobs: Accommodation & Food Service, Retail, Construction, Healthcare, and Professional services

<a id='45bf9f5a-e8c7-44ff-a7f8-0dedadad85df'></a>

McKinsey & Company

<a id='6f676bcc-4cea-4cda-8dec-c17ecefa6987'></a>

35

<!-- PAGE BREAK -->

<a id='43c60551-b416-483c-b6a3-e697974d65f9'></a>

Vulnerable jobs analysis: Traditional unemployment does not fully capture the economic risk facing American families

<a id='c755cd76-e99d-4fdb-8694-567785a83e3f'></a>

In addition to traditional unemployment¹, the “vulnerable jobs” metric attempts to capture the **income risk** facing a larger set of American families by reflecting—

<a id='9c306c7d-198a-4d71-af1d-3caabf7ea67f'></a>

Workers placed on **unpaid leave**
Workers facing **cuts to either hourly wages or hours worked**
Workers that **exit the labor force**
Workers that held multiple jobs and **reduced the number of jobs worked** as a result of Covid-19

<a id='59970eec-25f1-4e15-b6e5-838c56518f37'></a>

1. The BLS measure of U3 unemployment includes all jobless persons who are available to take a job and have actively sought work in the past four weeks

<a id='6ac3ee7f-ef9f-40ed-9686-94ea3b2b9a7e'></a>

Source: Pitchbook

<a id='c078762b-71ae-437a-bf8c-3782ad6a0af0'></a>

36

<a id='09c91595-3bfa-454b-babe-6f22680fbc17'></a>

Last Modified 11/3/2020 6:03 PM Eastern Standard Time

<a id='abfb33a5-587c-4d16-aa8b-ba1690ee0815'></a>

Printed

<!-- PAGE BREAK -->

<a id='b977f7a8-0844-4ca6-bc10-61b2515cba8d'></a>

Current as of October, 2020

<a id='cd84f1d5-ee01-4733-a210-e4c743edee93'></a>

Assessing small and medium business vulnerability leads to four
segments that may require different interventions

<a id='e593e0fe-8dc7-4c4a-80b8-d8952f40b76b'></a>

**Preliminary, proprietary, pre-decisional**

<a id='81c59516-1b52-498f-9bb6-1a677bd17d69'></a>

<::Quadrant chart titled "Financial Risk (as indicator of resilience)" on the Y-axis and "Degree affected by COVID-19" on the X-axis.

Y-axis labels: Higher (top), Lower (bottom).
X-axis labels: Lower (left), Higher (right).

Quadrant 1 (Top-Left: Higher Financial Risk, Lower Degree affected by COVID-19):
SMBs with higher financial risk and lower initial COVID-19 effects. Increasing concern with potentially broader and longer economic impacts, given underlying fragility.

Quadrant 2 (Top-Right: Higher Financial Risk, Higher Degree affected by COVID-19):
SMBs with higher financial risk and higher COVID-19 immediate effects. This group is most likely to experience widespread potential vulnerability to closure in the near term.

Quadrant 3 (Bottom-Left: Lower Financial Risk, Lower Degree affected by COVID-19):
SMBs with lower financial risk and lower initial COVID-19 effects. May still need help, and risk may increase as crisis continues.

Quadrant 4 (Bottom-Right: Lower Financial Risk, Higher Degree affected by COVID-19):
SMBs with higher financial risk but also higher COVID-19 immediate effects. Individuals/workers in need of immediate help, though businesses may bounce back more quickly.
: chart::>

<a id='28953f54-dc80-4d4a-9351-9ed108b1b884'></a>

Note: Financial risk as indicator of resilience is based on adapting a Federal Reserve methodology using profitability, credit score, and use of retained earnings. COVID-19 affectedness is based on the US Census Bureau's Small Business Pulse Survey, where business owners indicated the level of effect they are seeing from COVID-19

<a id='80bb24ab-005d-42ba-b30c-3431d914b24b'></a>

McKinsey & Company

<a id='9d45487c-1858-4470-bc9c-28c3822ac626'></a>

37

<a id='a9a0f3b5-7289-44c2-a73d-6f9aca7af708'></a>

Fin
risk
ind
res

<!-- PAGE BREAK -->

<a id='55253068-53d6-4d1a-80a2-9ade448cb8e1'></a>

Current as of October, 2020

<a id='5c32b642-b535-41ed-84f0-0be7924933e2'></a>

**Across sectors, DC has ~4K small-medium businesses with both higher financial risk and COVID-19 immediate impacts**
These SMBs employ ~69K workers, and their workers earn the lowest average income

<a id='0cf413f5-8fa9-463c-b9f9-f833a6cc53ea'></a>

Preliminary, proprietary, pre-decisional

<a id='449f7314-9636-49ec-85a8-a553d0297e87'></a>

<::Quadrant chart showing SMBs categorized by financial risk as an indicator of resilience (Y-axis: Higher, Lower) and degree affected by COVID-19 (X-axis: Lower, Higher). Each quadrant contains a bar chart with three bars representing Firms (thousands), Employment (thousands), and Average income (USD thousands).: chart::>

**Top-Left Quadrant (Higher Financial Risk, Lower COVID-19 Effects)**
SMBs with higher financial risk and lower initial COVID-19 effects. Examples: Smaller apparel factories, local construction companies
- Firms, thousands: 3
- Employment, thousands: 45
- Average income, USD thousands: 55

**Top-Right Quadrant (Higher Financial Risk, Higher COVID-19 Effects)**
SMBs with higher financial risk and higher COVID-19 immediate effects. Examples: Restaurants, barber shops, bed and breakfasts
- Firms, thousands: 4
- Employment, thousands: 69
- Average income, USD thousands: 44

**Bottom-Left Quadrant (Lower Financial Risk, Lower COVID-19 Effects)**
SMBs with lower financial risk and lower initial COVID-19 effects. Examples: Law firms, financial advisors, lessors of residential buildings
- Firms, thousands: 6
- Employment, thousands: 61
- Average income, USD thousands: 89

**Bottom-Right Quadrant (Lower Financial Risk, Higher COVID-19 Effects)**
SMBs with lower financial risk but also higher COVID-19 immediate effects. Examples: Dentist offices, child care centers
- Firms, thousands: 2
- Employment, thousands: 27
- Average income, USD thousands: 57

<a id='a738412b-7ac3-4820-9c81-9d590dcea0f1'></a>

Note: Financial risk as indicator of resilience is based on adapting a Federal Reserve methodology using profitability, credit score, and use of retained earnings. COVID-19 affectedness is based on the US Census Bureau's Small Business Pulse Survey, where business owners indicated the level of effect they are seeing from COVID-19

<a id='5f462f67-d9eb-4c8d-a646-c5ac8c789950'></a>

McKinsey & Company

<a id='ba59904b-e3fb-4c41-a9e4-3109f70dabaf'></a>

38

<!-- PAGE BREAK -->

<a id='5abda068-f172-46f9-9f0c-4c3e4634a97a'></a>

Other: Raleigh Commute Smart Consultants

<a id='086efa6f-3deb-452f-b067-f1a8f1dee227'></a>

<::logo: Raleigh
Raleigh
The logo features a stylized tree or plant design composed of various shades of green squares and rectangles, resembling pixels, with the word "Raleigh" in black text below it::>

<a id='70f42aa3-cf6f-435e-8d6f-caeea3dde8c2'></a>

# Description

* Call on employers to offer paid mobility programs and cash out programs (e.g., providing cash or transit subsidies to employees who do not park at work)

* Pilot employer-centered mobility programs and evaluate the effectiveness, such as through the LAB @ DC

* Launch a dedicated team within the District government focused on assisting employers with commuting programs

* Convene various transit- and commuter-centric organizations to establish an integrated strategy for enhancing commuting in the District

<a id='93bbdeac-85f3-4343-adbb-af660f974545'></a>

## Case example
**Raleigh:** The City of Raleigh has created a dedicated team of "Commute Smart Consultants." This team can assist employers to implement a "Commute Smart Program" for employees, making it easy for companies to support employees in alleviating traffic congestion and commuting stress.

The program offers easy solutions for employers by providing advice and assistance on how to increase the use of transportation options such as walking, biking, transit, carpooling, vanpooling, teleworking, creative work schedules, and parking cash-out.

The City states that "Implementing a Commute Smart Program can:
*   Increase employee satisfaction
*   Reduce the demand for parking
*   Reduce tardiness and absenteeism
*   Reduce employee stress
*   Enhance recruitment and retention
*   Enhance your public image

<::A red and silver city bus with "2 FALLS OF NEUSE" displayed, stopped at a crosswalk with people crossing. : figure::>

<::A person on a bicycle on a dirt path, with other people walking in the background, surrounded by trees. : figure::>

<a id='ddcf0f00-ddbd-448e-beda-76582de86814'></a>

For example, one program the City offers for employers to implement is "Emergency Ride Home" which provides employees a free ride home if an emergency ever strikes. This service is available specifically to those who commuted to work by a method other than driving alone. Employers can register their organization at no cost so that all employees get six free emergency rides home per year.

<a id='95c66330-7d5e-4e63-9270-42287e69ae07'></a>

Source: Commute Smart Raleigh; The LAB @ DC

<a id='229718ab-420c-4c82-9b97-96efbfecc562'></a>

McKinsey & Company
McKinsey & Company

<a id='e292a6ec-154e-4371-a5c5-4512006a223c'></a>

39

<!-- PAGE BREAK -->

<a id='62f0a860-55cf-4927-ad5d-9e26fe4e96cf'></a>

DollarVan.nyc

<a id='64f5222d-8ad5-4303-ad55-0deaffa0c2a8'></a>

Other: New York City's Dollar Vans

<a id='528791da-d6d4-469e-9704-af864e8a2ce1'></a>

## Description
* Provide subsidized microtransit (e.g., shuttles, mini-buses) in underserved communities
* City or transit agency can run the service or regulate private player(s) who run operations (e.g., NYC Dollar Vans, Via, etc.)
* Cross between legacy bus and ridesharing (e.g., Uber Pool)
* Can have fixed routes, fixed stops, or use algorithms to determine routes, vehicle size, and trip frequency
* Can supplement existing bus route capacity along with providing services to under-served areas
* Potential to generate employment and increase business ownership among underserved communities

<a id='42a15467-56fd-4449-91c1-5537c8c6dae0'></a>

Case example New York City's Dollar Vans
▪ Dollar Vans first appeared in New York City during a transit strike, and currently serve ~120K riders per day in areas of the city with transit gaps, primarily in Queens and Brooklyn
▪ Initially unregulated, the TLC (NYC Taxi & Limousine Commission) provides licenses to van owners, running background checks on all drivers, vehicle safety checks, and checking for proper insurance and licensing
  ▪ Note that the strict requirements and high cost of insurance means that many vans continue to operate without permits
▪ Follow fixed routes linking key hubs and under-served areas, such as Sunset Park, Flushing, Flatbush, and Eastern Queens
▪ Dollaride, an app, allows users to locate licensed vans, determine their arrival time, and pay the fare
▪ Cost for riders:
  ▪ Queens, Flatbush: $2
  ▪ Chinatown, Flushing, Sunset Park: $3-4
<::A map of New York City showing various dollar van routes in different colors (orange, red, blue, green) connecting key hubs and under-served areas. Locations visible include Fort Lee, George Washington Bridge, North Bergen, Fort Authority Bus Terminal, Newport Square, Chinatown Flushing, Jamaica Center Parsons Blvd, Atlantic Ave Barclays Ctr, Fulton Hall, Church Ave & 48th Street, Flatbush, Eastern Queens, 33rd St, Green Acres Hall, Rockaway, Beach 98. Below the map, a smartphone screen displays the 'dollaride' app. The app shows a green dollar van icon with a dollar sign and the text 'Ease your daily commute with NYC's network of dollar vans.': figure::>
Impact:
▪ 120K riders daily
▪ 2K drivers

<a id='3c7dd3d7-d4c1-4c90-9f38-a7b54598fbb7'></a>

Source: DollarVan.nyc; Dollaride; New York Times; The New Yorker

<a id='ea830eec-b472-484f-ad65-9730ab42a56a'></a>

McKinsey & Company
McKinsey & Company

<a id='bed893a8-18af-4a99-86bd-fe3a06dda92b'></a>

40