<a id='bfeb6ba5-a13f-4341-ab41-e9ed9bef7fe4'></a>

Morgan Stanley

<a id='f208f6c2-8f0a-4226-bb46-da2288459076'></a>

Morgan Stanley First Quarter 2025 Earnings Results

<a id='647ac4ec-c6af-4745-8f5d-2f23de2131ea'></a>

Morgan Stanley Reports Net Revenues of $17.7 Billion, EPS of $2.60 and ROTCE of 23.0%

<a id='b6a6e9aa-b922-49fd-82d7-316137fadf93'></a>

NEW YORK, April 11, 2025 - Morgan Stanley (NYSE: MS) today reported net revenues of $17.7 billion for the first quarter ended March 31, 2025 compared with $15.1 billion a year ago. Net income applicable to Morgan Stanley was $4.3 billion, or $2.60 per diluted share,¹ compared with $3.4 billion, or $2.02 per diluted share,¹ for the same period a year ago.

<a id='e866b4bb-e25e-4190-9f21-373a5f0f9dad'></a>

Ted Pick, Chairman and Chief Executive Officer, said, "The Integrated Firm delivered a very strong quarter with record net revenues of $17.7 billion and EPS of $2.60, and an ROTCE of 23.0%. Institutional Securities strong performance was led by our Markets business with Equity reporting a record $4.1 billion in revenues. Total client assets of $7.7 trillion across Wealth and Investment Management were supported by $94 billion in net new assets. These results demonstrate the consistent execution of our clear strategy to drive durable growth across our global footprint."

<a id='e58ee59e-662c-4f2d-a5e2-e1eaac9845d8'></a>

<table id="0-1">
<tr><td id="0-2" colspan="3">Financial Summary²,³</td></tr>
<tr><td id="0-3">Firm ($ millions, except per share data)</td><td id="0-4">1Q 2025</td><td id="0-5">1Q 2024</td></tr>
<tr><td id="0-6">Net revenues</td><td id="0-7">$17,739</td><td id="0-8">$15,136</td></tr>
<tr><td id="0-9">Provision for credit losses</td><td id="0-a">$135</td><td id="0-b">$(6)</td></tr>
<tr><td id="0-c">Compensation expense</td><td id="0-d">$7,521</td><td id="0-e">$6,696</td></tr>
<tr><td id="0-f">Non-compensation expenses</td><td id="0-g">$4,539</td><td id="0-h">$4,051</td></tr>
<tr><td id="0-i">Pre-tax income⁶</td><td id="0-j">$5,544</td><td id="0-k">$4,395</td></tr>
<tr><td id="0-l">Net income app. to MS</td><td id="0-m">$4,315</td><td id="0-n">$3,412</td></tr>
<tr><td id="0-o">Expense efficiency ratio⁸</td><td id="0-p">68%</td><td id="0-q">71%</td></tr>
<tr><td id="0-r">Earnings per diluted share¹</td><td id="0-s">$2.60</td><td id="0-t">$2.02</td></tr>
<tr><td id="0-u">Book value per share</td><td id="0-v">$60.41</td><td id="0-w">$55.60</td></tr>
<tr><td id="0-x">Tangible book value per share⁴</td><td id="0-y">$46.08</td><td id="0-z">$41.07</td></tr>
<tr><td id="0-A">Return on equity</td><td id="0-B">17.4%</td><td id="0-C">14.5%</td></tr>
<tr><td id="0-D">Return on tangible common equity⁴</td><td id="0-E">23.0%</td><td id="0-F">19.7%</td></tr>
<tr><td id="0-G" colspan="3">Institutional Securities</td></tr>
<tr><td id="0-H">Net revenues</td><td id="0-I">$8,983</td><td id="0-J">$7,016</td></tr>
<tr><td id="0-K">Investment Banking</td><td id="0-L">$1,559</td><td id="0-M">$1,447</td></tr>
<tr><td id="0-N">Equity</td><td id="0-O">$4,128</td><td id="0-P">$2,842</td></tr>
<tr><td id="0-Q">Fixed Income</td><td id="0-R">$2,604</td><td id="0-S">$2,485</td></tr>
<tr><td id="0-T" colspan="3">Wealth Management</td></tr>
<tr><td id="0-U">Net revenues</td><td id="0-V">$7,327</td><td id="0-W">$6,880</td></tr>
<tr><td id="0-X">Fee-based client assets ($ billions)⁹</td><td id="0-Y">$2,349</td><td id="0-Z">$2,124</td></tr>
<tr><td id="0-10">Fee-based asset flows ($ billions)¹⁰</td><td id="0-11">$29.8</td><td id="0-12">$26.2</td></tr>
<tr><td id="0-13">Net new assets ($ billions)¹¹</td><td id="0-14">$93.8</td><td id="0-15">$94.9</td></tr>
<tr><td id="0-16">Loans ($ billions)</td><td id="0-17">$162.5</td><td id="0-18">$147.4</td></tr>
<tr><td id="0-19" colspan="3">Investment Management</td></tr>
<tr><td id="0-1a">Net revenues</td><td id="0-1b">$1,602</td><td id="0-1c">$1,377</td></tr>
<tr><td id="0-1d">AUM ($ billions)12</td><td id="0-1e">$1,647</td><td id="0-1f">$1,505</td></tr>
<tr><td id="0-1g">Long-term net flows ($ billions)13</td><td id="0-1h">$5.4</td><td id="0-1i">$7.6</td></tr>
</table>

<a id='9fb70d61-5219-42aa-b4e6-d04b8741c7ad'></a>

# Highlights

* Net revenues for the first quarter were a record $17.7 billion, demonstrating the strength of our Integrated Firm with robust results across our business segments.²⁰
* The Firm delivered ROTCE of 23.0% during the first quarter.²,⁴
* The Firm expense efficiency ratio was 68% for the first quarter. Expenses for the quarter included $144 million of severance costs related to a March employee action across our business segments.³,⁸,¹⁹
* During the quarter, the Firm accreted $1.9 billion of Common Equity Tier 1 capital and ended the quarter with a Standardized Common Equity Tier 1 capital ratio of 15.3%.¹⁶
* Institutional Securities reported record net revenues of $9.0 billion reflecting record performance in Equity and strong Investment Banking results on higher fixed income underwriting.²⁰
* Wealth Management delivered a pre-tax margin of 26.6% for the quarter.⁷ Net revenues of $7.3 billion reflect strong asset management revenues and higher levels of client activity. The business added net new assets of $94 billion and fee-based asset flows were $30 billion for the quarter.¹⁰,¹¹
* Investment Management results reflect net revenues of $1.6 billion, primarily driven by asset management fees on higher average AUM of $1.7 trillion. The quarter included positive long-term net flows of $5.4 billion.¹³

<a id='d0f412b3-a038-446f-83ac-834b19348cb8'></a>

Media Relations: Wesley McDade 212-761-2430

<a id='04c02835-36d3-4873-9ac3-576c1c1b81bc'></a>

Investor Relations: Leslie Bazos 212-761-5352

<!-- PAGE BREAK -->

<a id='a5d8274e-e499-425b-a5e2-1d43dfc15996'></a>

Morgan Stanley

<a id='c423cce7-6d36-4b49-a00c-80c1fc5732a1'></a>

First Quarter Results

<a id='8f395aa0-21cc-4516-99d0-5a1f9843d2c9'></a>

## Institutional Securities

Institutional Securities reported record net revenues for the current quarter of $9.0 billion compared with $7.0 billion a year ago.20 Pre-tax income was $3.3 billion compared with $2.4 billion a year ago.6

<a id='7ca26dfd-b9d4-42cf-97f7-6a2c0b3e53c3'></a>

## Investment Banking revenues up 8%:

* Advisory revenues increased on higher completed M&A transactions.
* Equity underwriting revenues decreased from a year ago as issuers and investors evaluated market uncertainty.
* Fixed income underwriting revenues increased from a year ago on higher non-investment grade loan issuances.

<a id='9fe5ce68-5fe9-4570-9c9a-282c32995a48'></a>

Equity net revenues up 45%:

* Record Equity net revenues reflect increases across business lines and regions, particularly in Asia, with outperformance in prime brokerage and derivatives driven by strong client activity amid a more volatile trading environment.²⁰

<a id='3b3f25fa-ce21-45f8-96a6-fc0236ff3815'></a>

**Fixed Income net revenues up 5%:**
* Fixed Income net revenues reflect strong results in foreign exchange in a more volatile trading environment and in securitized products on higher lending revenues, partially offset by lower results in credit products.

<a id='6d1cfa48-6145-40af-ba15-3e61b1028538'></a>

Other:

* Other revenues increased principally driven by realized gains on the sale of corporate loans held-for-sale compared to mark-to-market losses, net of hedges, a year ago.

<a id='3abeb4fd-2f50-4346-8102-235197daac06'></a>

<table id="1-1">
<tr><td id="1-2">($ millions)</td><td id="1-3">1Q 2025</td><td id="1-4">1Q 2024</td></tr>
<tr><td id="1-5">Net Revenues</td><td id="1-6">$8,983</td><td id="1-7">$7,016</td></tr>
<tr><td id="1-8">Investment Banking</td><td id="1-9">$1,559</td><td id="1-a">$1,447</td></tr>
<tr><td id="1-b">Advisory</td><td id="1-c">$563</td><td id="1-d">$461</td></tr>
<tr><td id="1-e">Equity underwriting</td><td id="1-f">$319</td><td id="1-g">$430</td></tr>
<tr><td id="1-h">Fixed income underwriting</td><td id="1-i">$677</td><td id="1-j">$556</td></tr>
</table>

<a id='fa434d58-a5d9-4be2-a255-c084c412b614'></a>

<table id="1-k">
<tr><td id="1-l">Equity</td><td id="1-m">$4,128</td><td id="1-n">$2,842</td></tr>
<tr><td id="1-o">Fixed Income</td><td id="1-p">$2,604</td><td id="1-q">$2,485</td></tr>
<tr><td id="1-r">Other</td><td id="1-s">$692</td><td id="1-t">$242</td></tr>
<tr><td id="1-u">Provision for credit losses</td><td id="1-v">$91</td><td id="1-w">$2</td></tr>
</table>

<a id='16ea238f-2f91-421e-81d3-5dfcac3bc926'></a>

<table id="1-x">
<tr><td id="1-y">Total Expenses</td><td id="1-z">$5,611</td><td id="1-A">$4,663</td></tr>
<tr><td id="1-B">Compensation</td><td id="1-C">$2,854</td><td id="1-D">$2,343</td></tr>
<tr><td id="1-E">Non-compensation</td><td id="1-F">$2,757</td><td id="1-G">$2,320</td></tr>
</table>

<a id='d6b5d226-7fcd-4dbb-a4f3-02571a786048'></a>

Provision for credit losses:

* Provision for credit losses increased from a year ago, primarily driven by growth in secured lending facilities and in the corporate loan portfolio as well as the impact of a weakening macroeconomic forecast.

<a id='2d330569-cb98-4738-9a07-b970938bb160'></a>

Total Expenses:

* Compensation expense increased from a year ago on higher revenues.19
* Non-compensation expenses increased from a year ago on higher execution-related expenses.

<a id='77cce2d2-e8a2-4e1a-bd71-f48199f7501b'></a>

2

<!-- PAGE BREAK -->

<a id='b86c357d-b97b-40e9-a69d-7e884a126be5'></a>

Morgan Stanley

<a id='c478d756-f5e6-4714-808a-dace530a465b'></a>

## Wealth Management

Wealth Management reported net revenues of $7.3 billion in the current quarter compared with $6.9 billion a year ago. Pre-tax income of $2.0 billion in the current quarter resulted in a pre-tax margin of 26.6%.6, 7

<a id='9f789dbb-cc57-4bac-96ea-191b987a1d0a'></a>

**Net revenues up 6%:**

*   Asset management revenues increased on higher asset levels and the cumulative impact of positive fee-based flows.10
*   Transactional revenues increased 13% excluding the impact of mark-to-market on investments associated with DCP.5,14 The increase was driven by higher levels of client activity, particularly in equity-related products.
*   Net interest income increased from a year ago primarily driven by lending growth and higher yields on the investment portfolio, partially offset by lower average sweep deposits.

<a id='cc84a9b6-5915-4be2-9027-989680da4356'></a>

**Provision for credit losses:**
* Provision for credit losses increased from a release a year ago driven by higher individual assessments in our loan portfolio, inclusive of residential mortgages related to the California wildfires.

<a id='d1ed2040-4573-4152-a70f-363538af06a1'></a>

**Total Expenses:**
*   Compensation expense increased from a year ago on higher compensable revenues, partially offset by lower expenses related to DCP.5, 19
*   Non-compensation expenses were essentially unchanged from a year ago.

<a id='3709e694-2f10-4287-98a0-515f045c6936'></a>

<table id="2-1">
<tr><td id="2-2">($ millions)</td><td id="2-3">1Q 2025</td><td id="2-4">1Q 2024</td></tr>
<tr><td id="2-5">Net Revenues</td><td id="2-6">$7,327</td><td id="2-7">$6,880</td></tr>
<tr><td id="2-8">Asset management</td><td id="2-9">$4,396</td><td id="2-a">$3,829</td></tr>
<tr><td id="2-b">Transactional 14</td><td id="2-c">$873</td><td id="2-d">$1,033</td></tr>
<tr><td id="2-e">Net interest</td><td id="2-f">$1,902</td><td id="2-g">$1,856</td></tr>
<tr><td id="2-h">Other</td><td id="2-i">$156</td><td id="2-j">$162</td></tr>
<tr><td id="2-k">Provision for credit losses</td><td id="2-l">$44</td><td id="2-m">$(8)</td></tr>
<tr><td id="2-n">Total Expenses</td><td id="2-o">$5,332</td><td id="2-p">$5,082</td></tr>
<tr><td id="2-q">Compensation</td><td id="2-r">$3,999</td><td id="2-s">$3,788</td></tr>
<tr><td id="2-t">Non-compensation</td><td id="2-u">$1,333</td><td id="2-v">$1,294</td></tr>
</table>

<a id='9ebe5642-a559-47ff-9bc7-8141bac8581b'></a>

## Investment Management

Investment Management reported net revenues of $1.6 billion compared with $1.4 billion a year ago. Pre-tax income was $323 million compared with $241 million a year ago.⁶

<a id='431ab046-2639-4ae8-8128-c52497f53312'></a>

**Net revenues up 16%:**

*   Asset management and related fees increased from a year ago on higher average AUM primarily driven by higher market levels. 12
*   Performance-based income and other revenues increased from a year ago on higher accrued carried interest in our infrastructure funds.

<a id='dae195d6-54cb-487b-94ca-500d5e451ba7'></a>

## Total Expenses:

* Compensation expense increased from a year ago primarily driven by higher compensation associated with carried interest. 5, 19
* Non-compensation expenses increased from a year ago primarily driven by higher distribution expenses on higher average AUM.

<a id='5694d4d9-c7db-4b2d-bf5d-027f2b2be9a6'></a>

<table id="2-w">
<tr><td id="2-x">($ millions)</td><td id="2-y">1Q 2025</td><td id="2-z"></td></tr>
<tr><td id="2-A">Net Revenues</td><td id="2-B">$1,602</td><td id="2-C">$1,377</td></tr>
<tr><td id="2-D">Asset management and related fees</td><td id="2-E">$1,451</td><td id="2-F">$1,346</td></tr>
<tr><td id="2-G">Performance-based income and other</td><td id="2-H">$151</td><td id="2-I">$31</td></tr>
<tr><td id="2-J">Total Expenses</td><td id="2-K">$1,279</td><td id="2-L">$1,136</td></tr>
<tr><td id="2-M">Compensation</td><td id="2-N">$668</td><td id="2-O">$565</td></tr>
<tr><td id="2-P">Non-compensation</td><td id="2-Q">$611</td><td id="2-R">$571</td></tr>
</table>

<a id='2d50d8d8-f0d8-4eeb-bab6-c722526f8a19'></a>

3

<!-- PAGE BREAK -->

<a id='0c840019-9eeb-48bc-9c66-c2539733973f'></a>

Morgan Stanley

<a id='9aeae8f2-4844-4aab-8835-530eebb74721'></a>

# Other Matters

* The Firm repurchased $1.0 billion of its outstanding common stock during the quarter as part of its Share Repurchase Program.

* The Board of Directors declared a $0.925 quarterly dividend per share, payable on May 15, 2025 to common shareholders of record on April 30, 2025.

* The effective tax rate for the current quarter was 21.2%, which reflects a benefit associated with employee share-based compensation payments.21

<a id='4b5f83a2-dc76-49a9-8117-62b95ee1b7fb'></a>

<table id="3-1">
<tr><td id="3-2">Common Stock Repurchases</td><td id="3-3">1Q 2025</td><td id="3-4">1Q 2024</td></tr>
<tr><td id="3-5">Repurchases ($MM)</td><td id="3-6">$1,000</td><td id="3-7">$1,000</td></tr>
<tr><td id="3-8">Number of Shares (MM)</td><td id="3-9">8</td><td id="3-a">12</td></tr>
<tr><td id="3-b">Average Price</td><td id="3-c">$125.88</td><td id="3-d">$86.79</td></tr>
<tr><td id="3-e">Period End Shares (MM)</td><td id="3-f">1,607</td><td id="3-g">1,627</td></tr>
<tr><td id="3-h">Tax Rate</td><td id="3-i">21.2%</td><td id="3-j">21.2%</td></tr>
<tr><td id="3-k" colspan="3">Capital</td></tr>
<tr><td id="3-l" colspan="3">Standardized Approach</td></tr>
<tr><td id="3-m">CET1 capital 16</td><td id="3-n">15.3 %</td><td id="3-o">15.0 %</td></tr>
<tr><td id="3-p">Tier 1 capital 16</td><td id="3-q">17.2 %</td><td id="3-r">16.9 %</td></tr>
<tr><td id="3-s" colspan="3">Advanced Approach</td></tr>
<tr><td id="3-t">CET1 capital 16</td><td id="3-u">15.7 %</td><td id="3-v">15.4 %</td></tr>
<tr><td id="3-w">Tier 1 capital 16</td><td id="3-x">17.7 %</td><td id="3-y">17.3 %</td></tr>
<tr><td id="3-z" colspan="3">Leverage-based capital</td></tr>
<tr><td id="3-A">Tier 1 leverage 17</td><td id="3-B">6.9 %</td><td id="3-C">6.7 %</td></tr>
<tr><td id="3-D">SLR 18</td><td id="3-E">5.6 %</td><td id="3-F">5.4 %</td></tr>
</table>

<a id='6f593034-c8cd-4217-851d-a1be131ee646'></a>

4

<!-- PAGE BREAK -->

<a id='1c9375e5-bef5-43ad-a746-ab87461ef7bf'></a>

Morgan Stanley

<a id='ef18896c-ac04-425f-8f2c-8e8f460f6049'></a>

Morgan Stanley (NYSE: MS) is a leading global financial services firm providing a wide range of investment banking, securities, wealth management and investment management services. With offices in 42 countries, the Firm's employees serve clients worldwide including corporations, governments, institutions and individuals. For further information about Morgan Stanley, please visit www.morganstanley.com.

<a id='8817bcf8-dc99-4111-ab53-e937d0e33153'></a>

A financial summary follows. Financial, statistical and business-related information, as well as information regarding business and segment trends, is included in the financial supplement. Both the earnings release and the financial supplement are available online in the Investor Relations section at www.morganstanley.com.

<a id='3385d58f-5017-45c4-bb48-54e5a8c2bebb'></a>

NOTICE:

The information provided herein and in the financial supplement, including information provided on the Firm's earnings conference calls, may include certain non-GAAP financial measures. The definition of such measures or reconciliation of such measures to the comparable U.S. GAAP figures are included in this earnings release and the financial supplement, both of which are available on www.morganstanley.com.

<a id='3f47bb58-dbf7-4895-80c3-dba2a1d3e8be'></a>

This earnings release may contain forward-looking statements, including the attainment of certain financial and other targets, objectives and goals. Readers are cautioned not to place undue reliance on forward-looking statements, which speak only as of the date on which they are made, which reflect management's current estimates, projections, expectations, assumptions, interpretations or beliefs and which are subject to risks and uncertainties that may cause actual results to differ materially. For a discussion of risks and uncertainties that may affect the future results of the Firm, please see "Forward-Looking Statements" preceding Part I, Item 1, "Competition" and "Supervision and Regulation" in Part I, Item 1, "Risk Factors" in Part I, Item 1A, "Legal Proceedings" in Part I, Item 3, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in Part II, Item 7 and "Quantitative and Qualitative Disclosures about Risk" in Part II, Item 7A in the Firm's Annual Report on Form 10-K for the year ended December 31, 2024 and other items throughout the Form 10-K, the Firm's Quarterly Reports on Form 10-Q and the Firm's Current Reports on Form 8-K, including any amendments thereto.

<a id='84d95462-e97c-4412-b780-3f1cad4ca11d'></a>

5

<!-- PAGE BREAK -->

<a id='c8c7c4e0-695d-4195-b234-9224279767aa'></a>

Morgan Stanley

<a id='56864665-74be-43d4-9d81-92d604d487a3'></a>

1 Includes preferred dividends related to the calculation of earnings per share for the first quarter of 2025 and 2024 of approximately $158 million and $146 million, respectively.

<a id='75f5980e-a07c-4850-a7c2-fc983cf7b9a6'></a>

2 The Firm prepares its Consolidated Financial Statements using accounting principles generally accepted in the United States (U.S. GAAP). From time to time, Morgan Stanley may disclose certain "non-GAAP financial measures" in the course of its earnings releases, earnings conference calls, financial presentations and otherwise. The Securities and Exchange Commission defines a "non-GAAP financial measure" as a numerical measure of historical or future financial performance, financial position, or cash flows that is subject to adjustments that effectively exclude, or include amounts from the most directly comparable measure calculated and presented in accordance with U.S. GAAP. Non-GAAP financial measures disclosed by Morgan Stanley are provided as additional information to analysts, investors and other stakeholders in order to provide them with greater transparency about, or an alternative method for assessing our financial condition, operating results, or capital adequacy. These measures are not in accordance with, or a substitute for U.S. GAAP, and may be different from or inconsistent with non-GAAP financial measures used by other companies. Whenever we refer to a non-GAAP financial measure, we will also generally define it or present the most directly comparable financial measure calculated and presented in accordance with U.S. GAAP, along with a reconciliation of the differences between the non-GAAP financial measure we reference and such comparable U.S. GAAP financial measure.

<a id='7b953926-89c8-4109-8aa2-b12bbc4802d7'></a>

3 Our earnings releases, earnings conference calls, financial presentations and other communications may also include certain metrics which we believe to be useful to us, analysts, investors, and other stakeholders by providing further transparency about, or an additional means of assessing, our financial condition and operating results.

<a id='cc3350e6-73f4-478e-be5e-996895904747'></a>

4 Tangible common equity is a non-GAAP financial measure that the Firm considers useful for analysts, investors and other stakeholders to allow comparability of period-to-period operating performance and capital adequacy. Tangible common equity represents common equity less goodwill and intangible assets net of allowable mortgage servicing rights deduction. The calculation of return on average tangible common equity, also a non-GAAP financial measure, represents full year or annualized net income applicable to Morgan Stanley less preferred dividends as a percentage of average tangible common equity. The calculation of tangible book value per common share, also a non-GAAP financial measure, represents tangible common shareholder's equity divided by common shares outstanding.

<a id='cac2ed09-b30a-4ff0-88ab-16ec18382384'></a>

5 "DCP" refers to certain employee deferred cash-based compensation programs. Please refer to "Management's Discussion and Analysis of Financial Condition and Results of Operations - Other Matters - Deferred Cash-Based Compensation" in the Firm's Annual Report on Form 10-K for the year ended December 31, 2024.
6 Pre-tax income represents income before provision for income taxes.
7 Pre-tax margin represents income before provision for income taxes divided by net revenues.
8 The expense efficiency ratio represents total non-interest expenses as a percentage of net revenues.
9 Wealth Management fee-based client assets represent the amount of assets in client accounts where the basis of payment for services is a fee calculated on those assets.
10 Wealth Management fee-based asset flows include net new fee-based assets (including asset acquisitions), net account transfers, dividends, interest, and client fees, and exclude institutional cash management related activity.
11 Wealth Management net new assets represent client asset inflows, inclusive of interest, dividends and asset acquisitions, less client asset outflows, and exclude the impact of business combinations/divestitures and the impact of fees and commissions.
12 AUM is defined as assets under management or supervision.
13 Long-term net flows include the Equity, Fixed Income and Alternative and Solutions asset classes and excludes the Liquidity and Overlay Services asset class.
14 Transactional revenues include investment banking, trading, and commissions and fee revenues.
15 Capital ratios are estimates as of the press release date, April 11, 2025.
16 CET1 capital is defined as Common Equity Tier 1 capital. The Firm's risk-based capital ratios are computed under each of the (i) standardized approaches for calculating credit risk and market risk risk-weighted assets (RWAs) (the "Standardized Approach") and (ii) applicable advanced approaches for calculating credit risk, market risk and operational risk RWAs (the "Advanced Approach"). For information on the calculation of regulatory capital and ratios, and associated regulatory requirements, please refer to "Management's Discussion and Analysis of Financial Condition and Results of Operations - Liquidity and Capital Resources - Regulatory Requirements" in the Firm's Annual Report on Form 10-K for the year ended December 31, 2024.

<a id='aea6a6fe-d5f7-42d6-93fc-41e2c396c50e'></a>

6

<!-- PAGE BREAK -->

<a id='91c21268-dc6f-4536-87c3-7c073ed54c7a'></a>

Morgan Stanley

<a id='342daa78-8abe-4a86-a575-c22e74ca229c'></a>

17 The Tier 1 leverage ratio is a leverage-based capital requirement that measures the Firm's leverage. Tier 1 leverage ratio utilizes Tier 1 capital as the numerator and average adjusted assets as the denominator.

<a id='851cf390-5318-46eb-9069-161812c9f20f'></a>

18 The Firm's supplementary leverage ratio (SLR) utilizes a Tier 1 capital numerator of approximately $86.7 billion and $79.0 billion, and supplementary leverage exposure denominator of approximately $1.55 trillion and $1.46 trillion, for the first quarter of 2025 and 2024, respectively.

<a id='d80c70cb-0d7d-4e84-9c7b-47481169cab6'></a>

19 During the current quarter as a result of a March employee action, we recognized severance costs associated with a reduction in force ("RIF") of $144 million, included in Compensation and benefits expenses. The RIF occurred across our business segments and geographic regions and impacted approximately 2% of our global workforce at that time. The RIF was related to performance management and the alignment of our workforce to our business needs, rather than a change in strategy or exit of businesses. We recorded severance costs of $78 million in the Institutional Securities business segment, $50 million in the Wealth Management business segment, and $16 million in the Investment Management business segment for the current quarter. These costs were incurred across all regions, with the majority in the Americas.

<a id='a03c11c8-36b1-49c4-9811-7c6e2a77be5e'></a>

20 Institutional Securities and Equity net revenues represent records for a reported quarterly period after excluding the impact of debt valuation adjustments (DVA), which were previously reflected in net revenues in prior periods before 2016, and reflecting the current reporting structure of the Firm (i.e. exclusive of discontinued operations). Net revenues and net income applicable to Morgan Stanley, excluding the impact of DVA, were non-GAAP financial measures in those prior periods that were reconciled to the comparable GAAP financial measures in the respective quarterly reports filed on Form 10-Q.

<a id='68716998-8b30-4534-bf2c-429f4c03fb7a'></a>

21 The income tax consequences related to employee share-based compensation payments are recognized in Provision for income taxes in the consolidated income statement, and may be either a benefit or a provision. The impacts of recognizing excess tax benefits upon conversion of awards are $208 million and $77 million for the first quarter of 2025 and 2024, respectively.

<a id='e2d74420-6812-48fa-b5d4-e67b0c288e82'></a>

7

<!-- PAGE BREAK -->

<a id='9a98fe61-575f-4add-9f06-150d5769262a'></a>

Morgan Stanley

<a id='43e58f9e-c5c7-4282-a1e8-199360ee144c'></a>

Consolidated Income Statement Information
(unaudited, dollars in millions)

<table id="7-1">
<tr><td id="7-2"></td><td id="7-3" colspan="3">Quarter Ended</td><td id="7-4" colspan="2">Percentage Change From:</td></tr>
<tr><td id="7-5"></td><td id="7-6">Mar 31, 2025</td><td id="7-7">Dec 31, 2024</td><td id="7-8">Mar 31, 2024</td><td id="7-9">Dec 31, 2024</td><td id="7-a">Mar 31, 2024</td></tr>
<tr><td id="7-b" colspan="6">Revenues:</td></tr>
<tr><td id="7-c">Investment banking</td><td id="7-d">$ 1,711</td><td id="7-e">$ 1,791</td><td id="7-f">$ 1,589</td><td id="7-g">(4%)</td><td id="7-h">8%</td></tr>
<tr><td id="7-i">Trading</td><td id="7-j">5,111</td><td id="7-k">3,778</td><td id="7-l">4,852</td><td id="7-m">35%</td><td id="7-n">5%</td></tr>
<tr><td id="7-o">Investments</td><td id="7-p">369</td><td id="7-q">2</td><td id="7-r">137</td><td id="7-s">72%</td><td id="7-t">169%</td></tr>
<tr><td id="7-u">Commissions and fees</td><td id="7-v">1,481</td><td id="7-w">1,390</td><td id="7-x">1,227</td><td id="7-y">7%</td><td id="7-z">21%</td></tr>
<tr><td id="7-A">Asset management</td><td id="7-B">5,963</td><td id="7-C">6,059</td><td id="7-D">5,269</td><td id="7-E">(2%)</td><td id="7-F">13%</td></tr>
<tr><td id="7-G">Other</td><td id="7-H">751</td><td id="7-I">438</td><td id="7-J">266</td><td id="7-K">71%</td><td id="7-L">182%</td></tr>
<tr><td id="7-M">Total non-interest revenues</td><td id="7-N">15,386</td><td id="7-O">13,671</td><td id="7-P">13,340</td><td id="7-Q">13%</td><td id="7-R">15%</td></tr>
<tr><td id="7-S">Interest income</td><td id="7-T">13,748</td><td id="7-U">13,491</td><td id="7-V">12,930</td><td id="7-W">2%</td><td id="7-X">6%</td></tr>
<tr><td id="7-Y">Interest expense</td><td id="7-Z">11,395</td><td id="7-10">10,939</td><td id="7-11">11,134</td><td id="7-12">4%</td><td id="7-13">2%</td></tr>
<tr><td id="7-14">Net interest</td><td id="7-15">2,353</td><td id="7-16">2,552</td><td id="7-17">1,796</td><td id="7-18">(8%)</td><td id="7-19">31%</td></tr>
<tr><td id="7-1a">Net revenues</td><td id="7-1b">17,739</td><td id="7-1c">16,223</td><td id="7-1d">15,136</td><td id="7-1e">9%</td><td id="7-1f">17%</td></tr>
<tr><td id="7-1g">Provision for credit losses</td><td id="7-1h">135</td><td id="7-1i">115</td><td id="7-1j">(6)</td><td id="7-1k">17%</td><td id="7-1l">* (asterisk)</td></tr>
<tr><td id="7-1m">Non-interest expenses:</td><td id="7-1n"></td><td id="7-1o"></td><td id="7-1p"></td><td id="7-1q"></td><td id="7-1r"></td></tr>
<tr><td id="7-1s">Compensation and benefits</td><td id="7-1t">7,521</td><td id="7-1u">6,289</td><td id="7-1v">6,696</td><td id="7-1w">20%</td><td id="7-1x">12%</td></tr>
<tr><td id="7-1y" colspan="6">Non-compensation expenses:</td></tr>
<tr><td id="7-1z">Brokerage, clearing and exchange fees</td><td id="7-1A">1,222</td><td id="7-1B">1,180</td><td id="7-1C">921</td><td id="7-1D">4%</td><td id="7-1E">33%</td></tr>
<tr><td id="7-1F">Information processing and communications</td><td id="7-1G">1,050</td><td id="7-1H">&lt;MISSING CELL VALUE&gt;</td><td id="7-1I">976</td><td id="7-1J">(1%)</td><td id="7-1K">8%</td></tr>
<tr><td id="7-1L">Professional services</td><td id="7-1M">674</td><td id="7-1N">798</td><td id="7-1O">639</td><td id="7-1P">(16%)</td><td id="7-1Q">5%</td></tr>
<tr><td id="7-1R">Occupancy and equipment</td><td id="7-1S">449</td><td id="7-1T">527</td><td id="7-1U">441</td><td id="7-1V">(15%)</td><td id="7-1W">2%</td></tr>
<tr><td id="7-1X">Marketing and business development</td><td id="7-1Y">238</td><td id="7-1Z">279</td><td id="7-20">217</td><td id="7-21">(15%)</td><td id="7-22">10%</td></tr>
<tr><td id="7-23">Other</td><td id="7-24">906</td><td id="7-25">1,070</td><td id="7-26">857</td><td id="7-27">(15%)</td><td id="7-28">6%</td></tr>
<tr><td id="7-29">Total non-compensation expenses</td><td id="7-2a">4,539</td><td id="7-2b">4,913</td><td id="7-2c">4,051</td><td id="7-2d">(8%)</td><td id="7-2e">12%</td></tr>
<tr><td id="7-2f">Total non-interest expenses</td><td id="7-2g">12,060</td><td id="7-2h">11,202</td><td id="7-2i">10,747</td><td id="7-2j">8%</td><td id="7-2k">12%</td></tr>
<tr><td id="7-2l">Income before provision for income taxes</td><td id="7-2m">5,544</td><td id="7-2n">4,906</td><td id="7-2o">4,395</td><td id="7-2p">13%</td><td id="7-2q">26%</td></tr>
<tr><td id="7-2r">Provision for income taxes</td><td id="7-2s">1,173</td><td id="7-2t">1,182</td><td id="7-2u">933</td><td id="7-2v">(1%)</td><td id="7-2w">26%</td></tr>
<tr><td id="7-2x">Net income</td><td id="7-2y">$ 4,371</td><td id="7-2z">$ 3,724</td><td id="7-2A">$ 3,462</td><td id="7-2B">17%</td><td id="7-2C">26%</td></tr>
<tr><td id="7-2D">Net income applicable to nonredeemable noncontrolling interests</td><td id="7-2E">56</td><td id="7-2F">10</td><td id="7-2G">50</td><td id="7-2H">*</td><td id="7-2I">12%</td></tr>
<tr><td id="7-2J">Net income applicable to Morgan Stanley</td><td id="7-2K">4,315</td><td id="7-2L">3,714</td><td id="7-2M">3,412</td><td id="7-2N">16%</td><td id="7-2O">26%</td></tr>
<tr><td id="7-2P">Preferred stock dividend</td><td id="7-2Q">158</td><td id="7-2R">150</td><td id="7-2S">146</td><td id="7-2T">5%</td><td id="7-2U">8%</td></tr>
<tr><td id="7-2V">Earnings applicable to Morgan Stanley common shareholders</td><td id="7-2W">$ 4,157</td><td id="7-2X">$ 3,564</td><td id="7-2Y">$ 3,266</td><td id="7-2Z">17%</td><td id="7-30">27%</td></tr>
</table>

<a id='3a2765e4-7ab6-4166-9ed2-7dee2ba2966e'></a>

Notes:

*   Firm net revenues excluding mark-to-market gains and losses on deferred cash-based compensation plans (DCP), which represents a non-GAAP financial measure, were: 1Q25: $17,888 million, 4Q24: $16,232 million, 1Q24: $14,949 million.
*   Firm compensation expenses excluding DCP, which represents a non-GAAP financial measure, were: 1Q25: $7,523 million, 4Q24: $6,197 million, 1Q24: $6,447 million.
*   The End Notes are an integral part of this presentation. Refer to pages 12-17 of the Financial Supplement for Definition of U.S. GAAP to Non-GAAP Measures, Definitions of Performance Metrics and Terms, Supplemental Quantitative Details and Calculations, and Legal Notice.

<a id='6def86d9-03e1-47c0-9912-dad3005a6864'></a>

8

<!-- PAGE BREAK -->

<a id='738707de-330f-4fdd-a86f-f6b66e9c0ae8'></a>

Morgan Stanley

<a id='dfca5148-dd6d-4bfe-8d84-f702ec37767b'></a>

Consolidated Financial Metrics, Ratios and Statistical Data
(unaudited)

<table id="8-1">
<tr><td id="8-2"></td><td id="8-3" colspan="3">Quarter Ended</td><td id="8-4" colspan="2">Percentage Change From:</td></tr>
<tr><td id="8-5"></td><td id="8-6">Mar 31, 2025</td><td id="8-7">Dec 31, 2024</td><td id="8-8">Mar 31, 2024</td><td id="8-9">Dec 31, 2024</td><td id="8-a">Mar 31, 2024</td></tr>
<tr><td id="8-b" colspan="6">Financial Metrics:</td></tr>
<tr><td id="8-c">Earnings per basic share</td><td id="8-d">$ 2.62</td><td id="8-e">$ 2.25</td><td id="8-f">$ 2.04</td><td id="8-g">16%</td><td id="8-h">28%</td></tr>
<tr><td id="8-i">Earnings per diluted share</td><td id="8-j">$ 2.60</td><td id="8-k">$ 2.22</td><td id="8-l">$ 2.02</td><td id="8-m">17%</td><td id="8-n">29%</td></tr>
<tr><td id="8-o">Return on average common equity</td><td id="8-p">17.4%</td><td id="8-q">15.2%</td><td id="8-r">14.5%</td><td id="8-s"></td><td id="8-t"></td></tr>
<tr><td id="8-u">Return on average tangible common equity</td><td id="8-v">23.0%</td><td id="8-w">20.2%</td><td id="8-x">19.7%</td><td id="8-y"></td><td id="8-z"></td></tr>
<tr><td id="8-A">Book value per common share</td><td id="8-B">$ 60.41</td><td id="8-C">$ 58.98</td><td id="8-D">$ 55.60</td><td id="8-E"></td><td id="8-F"></td></tr>
<tr><td id="8-G">Tangible book value per common share</td><td id="8-H">$ 46.08</td><td id="8-I">$ 44.57</td><td id="8-J">$ 41.07</td><td id="8-K"></td><td id="8-L"></td></tr>
<tr><td id="8-M" colspan="6">Financial Ratios:</td></tr>
<tr><td id="8-N">Pre-tax margin</td><td id="8-O">31%</td><td id="8-P">30%</td><td id="8-Q">29%</td><td id="8-R"></td><td id="8-S"></td></tr>
<tr><td id="8-T">Compensation and benefits as a % of net revenues</td><td id="8-U">42%</td><td id="8-V">39%</td><td id="8-W">44%</td><td id="8-X"></td><td id="8-Y"></td></tr>
<tr><td id="8-Z">Non-compensation expenses as a % of net revenues</td><td id="8-10">26%</td><td id="8-11">30%</td><td id="8-12">27%</td><td id="8-13"></td><td id="8-14"></td></tr>
<tr><td id="8-15">Firm expense efficiency ratio</td><td id="8-16">68%</td><td id="8-17">69%</td><td id="8-18">71%</td><td id="8-19"></td><td id="8-1a"></td></tr>
<tr><td id="8-1b">Effective tax rate</td><td id="8-1c">21.2%</td><td id="8-1d">24.1%</td><td id="8-1e">21.2%</td><td id="8-1f"></td><td id="8-1g"></td></tr>
<tr><td id="8-1h" colspan="6">Statistical Data:</td></tr>
<tr><td id="8-1i">Period end common shares outstanding (millions)</td><td id="8-1j">1,607</td><td id="8-1k">1,607</td><td id="8-1l">1,627</td><td id="8-1m">-%</td><td id="8-1n">(1%)</td></tr>
<tr><td id="8-1o">Average common shares outstanding (millions)</td><td id="8-1p"></td><td id="8-1q"></td><td id="8-1r"></td><td id="8-1s"></td><td id="8-1t"></td></tr>
<tr><td id="8-1u">Basic</td><td id="8-1v">1,584</td><td id="8-1w">1,583</td><td id="8-1x">1,601</td><td id="8-1y">-%</td><td id="8-1z">(1%)</td></tr>
<tr><td id="8-1A">Diluted</td><td id="8-1B">1,600</td><td id="8-1C">1,608</td><td id="8-1D">1,616</td><td id="8-1E">-%</td><td id="8-1F">(1%)</td></tr>
<tr><td id="8-1G">Worldwide employees</td><td id="8-1H">81,023</td><td id="8-1I">80,478</td><td id="8-1J">79,610</td><td id="8-1K">1%</td><td id="8-1L">2%</td></tr>
</table>

<a id='14a095f0-e10c-4c38-97b5-71c958b8ed7e'></a>

The End Notes are an integral part of this presentation. Refer to pages 12 - 17 of the Financial Supplement for Definition of U.S. GAAP to Non-GAAP Measures, Definitions of Performance Metrics and Terms, Supplemental Quantitative Details and Calculations, and Legal Notice.

<a id='3cd1be58-240c-493a-921e-bcb163f83517'></a>

9