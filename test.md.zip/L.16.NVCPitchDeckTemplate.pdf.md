<a id='4ad9d537-a05f-4153-b85f-46c1ed64c411'></a>

Harvard Business School logo
Harvard Business School
NEW
VENTURE
COMPETITION

<a id='7fa7eda7-6f69-493f-afe2-4ebba1245262'></a>

<::logo: [Unidentifiable] 
 A light blue shield with a pattern of crosses and squares, topped with three indistinct shapes.::>

<a id='a5b42732-849c-4a4e-ad3e-a14a56767779'></a>

Pitch Deck Example

<a id='1b6bb3bc-8148-4301-927c-394ad97eb692'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem to the left of the text, with the word "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='3255c92a-d2a5-40cb-ae33-7dce7e1acd16'></a>

GOAL

<a id='046dda46-e760-4d05-b0a2-15eed41f65ba'></a>

* The goal of your pitch deck is to give a snapshot of your investment opportunity, taking into consideration your impact, growth potential, viability, and the ability of your team to execute your plan.

<a id='17cd4035-3fba-4528-856b-83df8439c875'></a>

- Think of this as the most compelling elements of your executive summary presented visually and verbally.

<a id='921be4f3-497c-4bd2-b884-b56d97d8b120'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='8101c892-ce63-4d35-951a-ce85941ccf67'></a>

Housekeeping

<a id='f3b7af7f-903c-4029-8cb2-5c5c78c8f39b'></a>

- Keep in mind that you will be allotted 10 minutes or less to present and may need to adjust the content and number of slides accordingly.

<a id='dbd10ae0-0ffc-48d3-8eec-3431fbfc6b48'></a>

* Ensure slides are not text or data heavy and use at least a 30pt font.

<a id='986869e8-ee46-479b-8638-16f6a12513cd'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='fbb8365a-3a84-44da-a50e-af34ef4028e7'></a>

Cover page

<a id='3e823588-4a0e-4670-b5fd-595f73187d24'></a>

TAGLINE: Define your
venture with a short
declarative sentence,
getting to the heart of
your venture's unique
advantage.

<a id='2daeb024-19e8-4eff-810b-cc0e0f3a0a5c'></a>

Harvard
Business
School
NEW
VENTURE
COMPETITION

<a id='70a91c63-ab26-4527-b035-eb3dd6bf6edd'></a>

<::logo: Unidentified Company/Organization/Brand
Unreadable text
A light blue shield with an unreadable inscription at the top and a stylized cross pattern with leaves in the main field.:>

<a id='4067e73c-06c7-4e7c-b631-79a31d96f35d'></a>

DATE:
PRESENTER NAME:

<a id='5b4431c6-9c73-46d4-abe7-89967e024766'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, three containing books and one with crossed axes, beside the institution's name in red and black text.::>

<!-- PAGE BREAK -->

<a id='4a32e15b-d5a0-491d-8def-e5f561e4fc7b'></a>

Problem

<a id='cbe9b38b-3d54-468c-990d-50c692e65fd5'></a>

"The goal is to get everyone nodding and buying in."
- Guy Kawasaki, The Art of the Start

<a id='862f4b80-e8ff-41bb-91dd-e8e1a0560680'></a>

* Describe the pain of the customer (or the customer's customer)
* Outline how the customer addresses the issue today and why current solutions don't work.
* Is it costing the customer time, money, frustration...
Define the pain point. ($ amount, time lost, etc.)

<a id='a31d5f60-9b8c-4a0d-acc0-cd2899391d70'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='466794da-9f29-429b-b45b-e95f129b11e5'></a>

Solution

<a id='b3d16e13-3acf-4d14-9377-e41959004f21'></a>

- Demonstrate your company's value proposition to make the customer's life better
- Provide cases, customer insights, case studies
- Show scalability

<a id='6644e0dc-5dd3-4c19-8b34-369951ce5ee7'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='accbd39e-0bf0-4d03-a8ed-ba4669c77665'></a>

Market Size/Dynamic

<a id='500dcba3-2e43-4fd9-a16e-cf5cb7bafed4'></a>

_"Good analysis will therefore involve careful segmentation of the true addressable market and thoughtful descriptions of how those customers will pay for the solution over time to build up a picture of a realistic market size." - Michael Skok_

<a id='594a9e64-86e5-45eb-88f4-dfeb95da7198'></a>

* Identify/profile the customer you cater to
* Provide bottoms-up market sizing: the number of potential customers and the price of the product sold into those customers. * The government census data is a good resource for this analysis.

<a id='a40087ec-a055-419f-85d8-41f675d3b7a4'></a>

- Changing trends, new technologies, and forces driving this segment

<a id='4bc5a7e1-9977-45ee-b3df-3b02ad437ba3'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='e258afbb-28b5-4b9e-b205-66ab7bdc7f2c'></a>

Competition

<a id='3d9b6bf8-5d66-4a93-8c55-a39f4d92fdff'></a>

* Give a list of direct competitors, substitutes, or those about to emerge
* Why hasn't anyone done this before? What are the barriers to entry that keep someone from doing this and/or what would keep a competitor from imitating your product or entering your market?

<a id='9a77982f-1075-4182-8a4f-551ef5d1ceef'></a>

* Highlight your venture's competitive advantages

<a id='aa64075c-e692-4d7b-9de8-0854168e10e8'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='269c2f00-0be3-4b58-a781-decfe6a2412b'></a>

Go-to-Market Strategy

<a id='b79bb111-b572-460e-8221-5bad260dc245'></a>

Tip: What are you selling?
Who are you selling it to?
How will you reach your target market?
Where will you promote your product?

<a id='88c4e512-80db-4662-92b4-1170c35da2f7'></a>

- What is your plan for execution?
- Summarize sales, marketing, and partnership plans

<a id='a71bca25-30d5-4586-a040-0a2491524d4d'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='167572f0-f1ea-4e4c-be73-08b5077a830f'></a>

Product

<a id='41b9a84b-66a8-4574-b8d5-456eb234c928'></a>

* Product line-up (form factor, functionality, features, architecture, intellectual property)

<a id='3c5b809a-c7cd-42bd-8b7d-86f3e47e48bf'></a>

* Development roadmap

<a id='765e1d7b-b3d5-41af-bc53-9f8222cb9caf'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four symbols, accompanied by the words "Harvard Business School" in red and black text.::>

<!-- PAGE BREAK -->

<a id='60fdcfc2-98cf-4081-999c-64f6c57026dd'></a>

Business Model

<a id='41d63819-b727-40c1-b678-192bf92df874'></a>

"Explain how you make money –who pays you, your channels of distribution, and your gross margins." - Guy Kawasaki, The Art of the Start

<a id='89edefb1-3db8-4e02-95a3-fee80e61fdd3'></a>

* Revenue model
* Pricing
* Average account size and/or lifetime value
* Sales & distribution model
* Customer/pipeline list

<a id='dc912fbe-7fdb-43c5-93c1-916ec2a5937b'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='4755642a-a769-4f26-8faa-7f2c05e4b052'></a>

Key Milestones

<a id='00cbced5-bcda-4fc2-b4ef-cf96e1d2f56a'></a>

* Outline current milestones achieved and future milestones.
* Customer research
* MVP development
* Product launch
* Beta users
* Market testing
* Marketing role out/CAC

<a id='61e694c8-e6c8-4079-a52b-30d8003a3996'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='5be5f616-4891-486b-a530-1153561269d2'></a>

Financial Snapshot

<a id='a2a83f64-b76c-4449-ab37-15ea9c7c9eb0'></a>

Tip: "Define assumptions so it's clear that you've developed a realistic model."

*   Provide a 3 year forecast, including annual revenue,
    net income, and key metrics (customers and
    conversion rates).

<a id='7859ea64-f3f4-454f-98f3-bcbe6b5c1d5b'></a>

- Prepare supplemental information such as
  - Product launch
  - Go-to-market execution
  - Other?

<a id='2ee4a9b9-cb4b-4c03-a9f9-7f2489458c7e'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with a cross design and four book icons, accompanied by the institution's name in a sans-serif font, with "Harvard" in a reddish hue and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='5989e999-8fec-41dd-b995-ce196791760a'></a>

Capital Requirements

<a id='d3abf943-73b6-4e03-9018-16ae4feaf2db'></a>

Tip: How much capital will you need prior to becoming cash flow positive and how will your funds be applied? You need to explain the minimum required equity you need to reach your next key milestone.

<a id='fed9f740-0665-4056-8cc0-ca32e7f113cb'></a>

* Customer research- focus groups, surveys
* MVP development
* Product launch
* Go-to-market execution
* Other?

<a id='186898de-e446-4297-ab5e-f5e2c464c917'></a>

<::logo: Harvard Business School
Harvard Business School
A shield emblem with a cross pattern and four books is placed to the left of the institution's name in red and black text.::>

<!-- PAGE BREAK -->

<a id='8f13f4ba-0918-47d6-884b-3fd77e32c059'></a>

Team

<a id='f55cf09b-426d-4170-a200-1fca2c13c664'></a>

Tip: You need to convey that you are the team to execute this venture!

<a id='51b48bcb-8b50-4340-878e-42f7f21edf61'></a>

*   Founders & Management
    *   What key skills or experience that relate to the product or leading of the company
*   Board of Directors/Board of Advisors
    *   Highlight spheres of influence

<a id='7a89203c-99a6-4640-bd1e-72c98222694c'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with four quadrants, each containing a book, positioned to the left of the text "Harvard Business School" with "Harvard" in red and "Business School" in black.::>

<!-- PAGE BREAK -->

<a id='4306647c-2e59-4d14-9eb0-bc5fb420bc5a'></a>

Appendix

<a id='4874bf8d-8450-48a6-902e-ec5176fb291d'></a>

Additional slides that can be used for follow-up questions.

<a id='6a5b80a9-2182-4881-9b7d-11c8aace3870'></a>

<::logo: Harvard Business School
Harvard Business School
The logo features a shield emblem with three open books above a black cross-like symbol, accompanied by the institution's name in red and black text.::>